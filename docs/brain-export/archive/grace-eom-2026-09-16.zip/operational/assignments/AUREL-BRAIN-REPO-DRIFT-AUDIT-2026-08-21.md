# Aurel — brain repo drift audit

**Date:** 2026-08-21

**Context:** Aurel · `pkt-contexts-fitness`
**Operator request:** verify ten reported drift classes; repair confirmed context/front-door issues; route owner-governed cleanup through Grace.

## Verdict

| # | Claim | Verdict | Evidence | Action |
|---|-------|---------|----------|--------|
| 1 | Thinking-map pin drift | **CONFIRMED, broader than reported** | `requirements-thinking-map.txt` and current wide-use policy said 1.9.5; `INDEX.md`, workflow passport text, current MCP/entity docs, project payload metadata, and current specs carried 1.9.2/1.9.3/1.6.0/1.4.3 claims. | Made `requirements-thinking-map.txt` the single canonical pin; aligned current enforcement/compatibility references and the ops-method payload to 1.9.5; retained historical version facts only when labeled as adoption/history; added dynamic context-fitness checks. Runtime verify: 35/35. |
| 2 | Live vs archive classification uneven | **CONFIRMED** | `INDEX.md` called completed registers active; governance index mixed closed registers with current policy; a workflow architecture report still presented superseded future-tense facts. | Defined live/historical precisely in `INDEX.md` and governance index; marked the architecture report historical; left physical archive migrations to Grace. |
| 3 | Root README/entry docs stale | **CONFIRMED** | Root README used `/data/workspaces/cursor`, `/home/igareosh/cursor`, the two-assistant model, old release/repo framing, and mutable service inventories; the MCP/Chroma persistence guide still called alunel the primary Cursor home. | Replaced README with a compact current landing page; aligned `docs/README.md`, `REPO-SELF-SERVICE.md`, `PROJECT-STRUCTURE.md`, `INDEX.md`, and the persistence guide with altitudine as the daily dev office. |
| 4 | Ownership/task routing duplicated or ambiguous | **CONFIRMED** | Current docs alternated between Grace-only row creation and “Grace or Cursor”; older automation docs treated `report_done` as future/optional. | Added one canonical owner + row + `report_done` flow to `OPERATIONAL-LAYER.md`; aligned active header and automation policy; marked the old architecture narrative historical. |
| 5 | Agent context mirrors diverge | **CONFIRMED** | `docs/AGENTS-USAGE.md` counted Cursor twice (claimed 15 from a 16-item formula); README/REPO/CLAUDE and entity mirrors alternated between two/four assistants, external/company-employed, and old paths. | Reconciled current front doors and named-entity mirrors: 15 = Cursor main + Team 10 + four employed assistants; default Cursor is not item 16; assistants are company-employed outside Team 10; Aurel/Aegle remain outside the count. |
| 6 | Active board stale/superseded rows | **CONFIRMED** | Audit snapshot: **522 DONE**, **15 PAUSED**, **0 OPEN/IN_PROGRESS**. During this pass, a separate Grace triage added the ALT-DISK wave; the later live count was **523 DONE**, **15 PAUSED**, **6 OPEN**, **0 IN_PROGRESS**. Prior controlled archive precedent: `archive/active-history-20260807.md`. | Did not mass-delete under Aurel. Grace must run a controlled archive cycle, preserve PAUSED/current rows, verify SuiteCRM projections, and leave only current executable units. |
| 7 | Placeholder/TODO debris | **PARTIAL; blanket claim rejected** | Root/front-door docs had no active TODO/FIXME markers. Most hits are intentional templates, schema placeholders, gates, issue forms, or explicitly historical material. A few live-folder stubs/TODO docs require owner classification. | No broad deletion. Grace should include only verified active debris in the archive pass; historical/intentional markers remain untouched. |
| 8 | Too many overlapping entry docs | **CONFIRMED** | README, INDEX, docs/README, AGENTS, OPERATIONAL-LAYER, and PROJECT-STRUCTURE each competed as a start point. | Established three entry documents: `AGENTS.md` (agent authority), `OPERATIONAL-LAYER.md` (workflow), `INDEX.md` (directory map), all reached through the single root README landing page. |
| 9 | Historical and operational content mixed | **CONFIRMED** | Closed registers and historical reports remain in `governance/`; active board is mostly DONE history; some reports still say live. | Classification fixed now; physical migration and Chroma-default exclusion require a Grace-owned archive/ingest-scope pass. |
| 10 | Pointer map inconsistent | **CONFIRMED** | README/INDEX/PROJECT-STRUCTURE emphasized different entry points and project bootstrap details; PROJECT-STRUCTURE omitted mandatory CONTEXT-PACKET and treated RELEASE-CHECKLIST as bootstrap. | Root README is the single landing page; INDEX is the detailed map; PROJECT-STRUCTURE now matches OPERATIONAL gate order and release trigger. |

## Grace triage — residual executable work

Create rows only after Grace reviews scope and archive safety:

1. **Board archive cycle:** move historical DONE rows to a dated history file; keep and revalidate PAUSED plus current executable rows; verify SuiteCRM links and workflow parser behavior before/after. Counts must be refreshed immediately before the move because the board is live.
2. **Historical tree pass:** move closed registers/reports/stubs from live folders only when link preservation and default Chroma exclusion are verified. Prefer pointer documents when paths are widely referenced.
3. **Placeholder pass:** inspect active-path TODO/TBD/PLACEHOLDER hits; archive only stale debris, preserve intentional templates/gates/schema vocabulary.
4. **Secondary context pass:** continue path/persona cleanup beyond the current front-door set, prioritizing files consumed by agent rules or runtime passport generation.
5. **Chroma boundary verification:** confirm archive exclusion in the actual CHROMA-1 ingest source list; mass/delta ingest remains Abelard-owned.

## Verification evidence

- `bash scripts/brain/verify/context-fitness.sh` → PASS, 30-key catalog, 27 front doors, canonical pin checks across current consumers.
- `python3 -m fpf_thinking_map.verify` → 35/35 PASS.
- Canonical root/origin → `/data/altitudine/CC_.com`, `Consolidare-Continuum/CC_`.
- Concurrent workflow-state and unrelated cluster changes were not included in this audit scope.

SIGNED: OpenAI/Codex (Aurel) | context-fitness audit | 2026-08-21 | ten drift classes verified and routed
