# Ethan — scripts inventory permanent re-drain (2026-09-04)

**Authority:** Ethan (operator: “scripts address, archive, move, or trash moveout permanently”)  
**Wave:** SCRIPTS-FIT remains **CLOSED** — this is maintenance re-apply of [ETHAN-SCRIPTS-ROOT-DRAIN-2026-08-13.md](archive/2026-08-closed/ETHAN-SCRIPTS-ROOT-DRAIN-2026-08-13.md), not a new FIT wave.  
**SoT:** [SPEC-ETHAN-SCRIPTS-TOPIC-LAYOUT.md](../../governance/SPEC-ETHAN-SCRIPTS-TOPIC-LAYOUT.md)

## Problem

EOD 2026-09-04: `scripts_inventory_count=58` (SOFT >40). Drift: non-hot root symlinks + orphan root files + extra topic dirs at depth-1.

## Decision (permanent)

1. **Inventory** = topic dirs + `README.md` + **hot allowlist** only. Exclude `_compat/`, `__pycache__/`, `_layout_stash/`.
2. Non-hot root symlinks → `scripts/_compat/` (legacy basename; not inventory).
3. Orphan root files → topic path + `_compat` alias (no delete).
4. Nest low-traffic topic dirs under parents (pointers in `_compat`).
5. Expand hot allowlist for **rule/EOD-cited** entrypoints added after 2026-08-13 drain.

## Hot allowlist (root) — 2026-09-04

**Original (2026-08-13):**  
`detect-cursor-session-mode.sh` · `agent-print-execution-context.sh` · `agent-telegram.sh` · `agent-ssh-cert-renew.sh` · `agent-cluster-access-preflight.sh` · `deploy-mcp-config-global.sh` · `end_of_day_run.sh` · `end_of_week_run.sh` · `eod-folder-ls-cap-check.sh` · `thinking-map-hard-gate.sh` · `workflow_run.sh` · `trustmaster-hub` · `malus-dockhand-scope-audit.sh` · `suitecrm_sync_on_triage.sh`

**Added (rule/EOD cited):**  
`pdf-to-md.sh` · `book-ocr-run.sh` · `pre-eod-compliance-dump.sh` · `thinking-map-blockers-eod.sh`

## Nests (this pass)

| From | To |
|------|-----|
| `grace/` | `workflow/grace/` |
| `alunel-python/` | `cluster/alunel-python/` |
| `lan-replication/` | `cluster/lan-replication/` |
| `workflow_tests/` | `workflow/workflow_tests/` |
| `cron/` | `ops/cron/` |

## Relocates (orphan files)

| From | To |
|------|-----|
| `abelard-routine-inspection.sh` | `ops/abelard/` |
| `conn-action.sh` | `conn/` |
| `lamaita-ethernet-wifi-prefer.ps1` | `cluster/lamaita/` |
| root `workflow_*` stubs | removed; `_compat` → `workflow/core/automation/` |
| root `trust-plane-clamav-ensure.sh` | `_compat` → `ops/misc/compliance/` |

## Acceptance

- `scripts_inventory_count` ≤ soft **40** — evidence **40** (2026-09-04).
- Hot `bash scripts/<hot>` still works.
- No content trashed — move/archive/`_compat` only.

SIGNED: Architecture (Ethan) | scripts inventory re-drain | 2026-09-04 | permanent
