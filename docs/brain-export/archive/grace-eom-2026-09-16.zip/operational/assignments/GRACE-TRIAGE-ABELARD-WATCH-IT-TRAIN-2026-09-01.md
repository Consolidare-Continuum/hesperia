# Grace triage — Abelard WATCH items · IT TRAIN full team (no Abelard)

**Date:** 2026-09-01  
**Trigger:** Operator — Grace full AWP; team alone; Abelard **not** executor  
**Mode:** IT TRAIN · orchestration elevations/fixes/provisions/decisions at home

## Wave ABEL-WATCH-00..06

| ID | Owner | Task |
|----|-------|------|
| ABEL-WATCH-00 | Grace | Triage + orchestration |
| ABEL-WATCH-01 | Liam | tersagor disk audit + safe hygiene |
| ABEL-WATCH-02 | Daniel | altitudine disk audit + safe hygiene |
| ABEL-WATCH-03 | Noah | dnsmaster AdGuard conn.local live confirm (patch rewrites script — not full yaml scp) |
| ABEL-WATCH-04 | Ethan | Cloudflare Zone DNS token — provision decision + paths |
| ABEL-WATCH-05 | Emma | Fleet bare `.local` DNS roll (reachable Linux + LAMAITA doc) |
| ABEL-WATCH-06 | Marcus | conn catalog v2 — mx mailcow/docker actions + deploy smoke |
| ABEL-WATCH-07 | Ava | Verification pass — disk % + conn list + dns dig |

**Abelard:** sleep / not owner — team closes Abelard WATCH exit.

SIGNED: Triage (Grace) | IT TRAIN Abelard watch wave | 2026-09-01
