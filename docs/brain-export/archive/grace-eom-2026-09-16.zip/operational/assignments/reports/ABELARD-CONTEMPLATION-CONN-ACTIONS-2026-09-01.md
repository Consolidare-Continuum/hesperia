# Abelard contemplation — conn.local read + write muscle

**Date:** 2026-09-01 (PM, post CONN-ACT wave)  
**Trigger:** Operator — adjust QUICK OPS and Abelard contexts for conn.local tools awareness  
**Session:** execution_host=altitudine · dev_office=true · connectivity=lan  
**Prior:** [ABELARD-CONTEMPLATION-2026-09-01-PM.md](./ABELARD-CONTEMPLATION-2026-09-01-PM.md) · [CONN-ACTIONS-WAVE-CLOSEOUT-2026-09-01.md](./CONN-ACTIONS-WAVE-CLOSEOUT-2026-09-01.md)

---

## 1. conn.local is now two layers (not one)

| Layer | Surface | Auth | Abelard use |
|-------|---------|------|-------------|
| **Read grip** | `GET /api/status` · `/api/pyramid` · `/api/host` · `/api/dbs` · `/api/github` · `/api/services` | none | **First** — before SSH loops; MCP `get_conn_*` |
| **Write fast-ops** | `GET /api/actions` · `POST /api/action/run` | `X-Conn-Token` | **Second** — allowlisted reload/restart only |

**Read** = awareness (what is up, where, problems[]).  
**Write** = shaped ops (fixed argv catalog — not a shell).

MCP inquiry packet stays **read-only**. Actions are **CLI/UI + token**, not silent default agent write.

---

## 2. Officer post adjustment — when to reach for what

```
Session open:
  detect-cursor-session-mode → abelard-routine-inspection (conn read + malus + ssh trust + prom + disk)

Service bounce / reload (catalogued):
  conn-action.sh list --host <id>
  conn-action.sh run <action_id> [--dry-run]
  shortcuts: reload-nginx · restart-conn-hub

Not in catalog / pillar / novel:
  SSH + runbook (trustmaster-hub preflight if access)
  malus for prod Docker inventory — not restart substitute
  Grace row if new action class needed → edit actions_catalog.json + hub deploy

NEVER via conn.local:
  alunel (Proxmox holy cow)
  trustmaster (access / CA / Authentik / credentials)
```

**Shape for team:** teach **read grip → allowlisted action → verify conn status again** — not ad-hoc `systemctl` SSH chains for catalogued paths.

---

## 3. Pillars — zero tolerance (operator 2026-09-01)

**alunel** and **trustmaster** are **forbidden_hosts** in code + catalog.  
403 on run; not listed in `/api/actions`.  
Proxmox/Authentik/CA work stays **direct SSH + runbooks + thinking_map cluster_ops** — never conn fast-ops buttons.

---

## 4. Context files updated this pass

| File | Change |
|------|--------|
| [ABELARD_QUICK_OPS.md](../../agents/abelard/ABELARD_QUICK_OPS.md) | §0 conn.local read+write; session sequence; action groups; deploy |
| [ABELARD.md](../../agents/abelard/ABELARD.md) | conn actions pointer |
| [abelard-cluster.mdc](../../.cursor/rules/abelard-cluster.mdc) | Flow: read grip + conn-action fast-ops |
| [SPEC-ETHAN-CONN-LOCAL-ACTIONS-API.md](../../governance/SPEC-ETHAN-CONN-LOCAL-ACTIONS-API.md) | Ethan canon (unchanged) |

---

## 5. Catalog v1 inventory (21 actions)

| Group | Hosts | Examples |
|-------|-------|----------|
| **conn** | prichindel | conn-hub restart, conn-agent restart |
| **web** | prichindel | nginx reload, apache2 reload |
| **mail** | prichindel | postfix reload |
| **docker** | prichindel | mysql_db, postgres_db, mariadb_db, php81_fpm, suitecrm, n8n restart |
| **agent** | scope Linux | conn-agent restart on altitudine, tersagor, librarymaster, dnsmaster, mediamaster, cloudmaster, mx1, mx2, actarus, chronomaster |

**Expand path:** edit `cluster/conn/hub/actions_catalog.json` → rsync/deploy hub on prichindel → `conn-action.sh list` verify.

---

## 6. Verdict

conn.local graduated from **map only** to **map + shaped buttons**. Abelard session muscle is now:

1. **Read** — status/pyramid/problems  
2. **Act** — catalogued reload/restart when fit  
3. **SSH** — everything else (pillars, novel, deep debug)

QUICK OPS and entity rule updated so future Abelard does not SSH-reload nginx when `conn-action.sh reload-nginx` suffices.

---

SIGNED: DevOps (Abelard) | conn.local contemplation | 2026-09-01 | read+write muscle
