# Abelard contemplation — operational surface, capacity, backlog

**Date:** 2026-09-01  
**Trigger:** Operator — conn.local proved useful; reinspect QUICK OPS, duties, tooling; plan absent capacity.  
**Session:** altitudine (dev office) · LAN

---

## 1. What I actually use (session-open muscle)

| Layer | Tool | Role |
|-------|------|------|
| **Grip** | `https://conn.local/` · MCP `get_conn_status` | First move before SSH loops — **proven today** (routine inspection) |
| **Access** | `trustmaster-hub` · `cluster-ssh-routine.sh` | Agent CA, 13/16 trust, Authentik health — **mandatory** when cert stale |
| **Prod Docker** | malus · `malus-dockhand-scope-audit.sh` | 5/5 Hawser ONLINE; fleet shape without 5-host hop |
| **Alerts** | Prometheus `:9090` on prichindel | Firing=0 gate in routine |
| **Mail** | mx1/mx2 tandem spot checks | 18 Up each — standing Abelard duty |
| **Notify** | `agent-telegram.sh` | Operator phone — not headless/Tersagor |
| **Thinking map** | `cluster_ops` on SSH/destructive | When mode=1 |
| **Runbooks** | `get_runbook` backup · maintenance · trustmaster-access · connection-resolution | Liam pack still valid |

**Three main hands** (mental model holds): **altitudine** dev · **prichindel** prod · **trustmaster** access/credentials. **alunel** = holy cow only.

---

## 2. QUICK OPS — drift found (needs refresh wave)

| Area | Issue | Action |
|------|-------|--------|
| CHROMA-1 | §3 one-liners still live (decommissioned 2026-08-30) | Retire block; point team brain → Postgres; library → CHROMA-2/librarymaster |
| Headless | Docker exec one-liners (archived 2026-02-14) | Move to archive pointer only |
| cloudflared | Health/tokens in §2 table; prichindel has **no** cloudflared units (vaporas gate since 2026-05-15) | Split: legacy tunnel doc vs **vaporas/nginx** gate reality |
| Context lock | "grandfathered CHROMA-1 on alunel" | Update to decommissioned warm backup |
| Workspace path | "run from `/data/workspaces/cursor`" | Dual path: **altitudine** `/data/altitudine/CC_.com` primary |
| conn.local | One-liners present ✓ | Add **session-start** line: status → pyramid → problems[] before any multi-host work |
| Bare `.local` DNS | Not documented for dev office | **Today fixed on altitudine** — roll pattern to fleet (see backlog) |
| `cluster-hostname-compliance.sh` | Referenced in HOSTNAME-AND-HOSTS-STANDARD — **script absent** | Restore or fix doc refs |
| `cluster-lan-dns-rewrites.sh` | Referenced — **absent** | Restore; conn.local/suite.local missing from repo AdGuardHome.yaml |

---

## 3. Duties reinspection (SPEC + ABELARD.md)

**Still mine (unchanged):** cluster maintenance/backup, connection resolution, Cloudflare when required, trustmaster/Authentik, malus infra, mx tandem, cc-site watchover, LAN DNS enforcement, agent CA, conn hub deploy, cold backup line (fluturas), SuiteCRM volume catastrophe awareness.

**Officer+manager shape:** team grinds; I shape practices — not all-alone dump. Sleep gate relaxed; explicit invoke still wakes.

**Not mine:** client code (Gena), Hesperia product (Felix/Gena), books ingest operator path (Colombo/CHROMA-2), team operational file edits without row.

**Custo intake (2026-09-01, status=1):** altitudine Mullvad exit policy verify; LAMAITA Windows Tailscale NoState hygiene — **Abelard lasting**, not one-off.

---

## 4. Operational surface — gaps and wants

### A. Present and good — keep

- conn hub permanent on prichindel (`conn-hub.service`)
- malus prod fleet (5 hosts)
- trustmaster-hub + cluster SSH routine
- conn `/api/github` for repo inventory
- LAN HTTPS CA on trustmaster for `*.local`

### B. Absent or broken — want

| ID | Want | Why |
|----|------|-----|
| **ABEL-01** | **`abelard-routine-inspection.sh`** — one entry: conn status → malus audit → cluster-ssh-routine → prometheus firing → disk soft/hard thresholds → telegram summary optional | Today's "full capacity" was manual chain; should be one command |
| **ABEL-02** | **Fleet bare-`.local` client fix** — script from altitudine pattern: `cluster-merge-lan-hosts.sh` + nsswitch `NOTFOUND=continue` + `resolved-10-local.conf` | conn.local failed on altitudine until fixed; izvoras/mugurel/LAMAITA likely same class |
| **ABEL-03** | **conn.local in dnsmaster git** — AdGuardHome.yaml rewrites for `conn.local` / `conn.prichindel.local` | dig works live; repo drift; compliance `--dns-patch` path broken (missing scripts) |
| **ABEL-04** | **Restore `cluster-hostname-compliance.sh` + `cluster-lan-dns-rewrites.sh`** | HOSTNAME-AND-HOSTS-STANDARD cites them; SCRIPTS-FIT may have dropped |
| **ABEL-05** | **QUICK OPS refresh wave** — CHROMA-1/headless/cloudflared retirement; conn-first session block; three-main-hands | Reduce wrong-muscle calls from future Abelard |
| **ABEL-06** | **Cloudflare token renewal** | QUICK OPS §2: Zone DNS Edit **expired 2026-07-26**; certbot ini invalid |
| **ABEL-07** | **tersagor disk** — 87% `/` | Watch → cleanup or expand before hard gate |
| **ABEL-08** | **system_maintenance/latest** empty on prichindel | Maintenance brain empty — restore run or document why |
| **ABEL-09** | **prometheus-mcp** in Abelard preflight packet when session exposes it | PromQL without SSH curl parse |
| **ABEL-10** | **LAMAITA conn.local** — Windows hosts + LAN HTTPS CA (script exists); document in QUICK OPS §1 | Dev office on laptop same grip as altitudine |
| **ABEL-11** | **Custo intake** — Mullvad exit on altitudine; LAMAITA Tailscale NoState | Stamp `custo_abelard_intake_lamaita_egress_2026-09-01.txt` |
| **ABEL-12** | **cert status stamp auto-sync** — `agent_ssh_cert_status.txt` stale after hub renew | hub `refresh_cert_status_from_alunel` failed when alunel has no repo clone |

### C. Nice — not blocking

- conn MCP in every IDE session (exposure ≠ deployed capacity — verify client)
- malus API wrapper script (curl Dockhand `:3000` via SSH) vs raw audit
- IRC `#hosts` reporter verify (`conn_hosts_reporter.txt`)

---

## 5. Proposed session-open sequence (Abelard v1.08 intent)

```
1. detect-cursor-session-mode.sh → state host/connectivity
2. curl -skS https://conn.local/api/status  (or get_conn_status)
3. bash scripts/trustmaster-hub status  (cert not expired?)
4. bash scripts/malus-dockhand-scope-audit.sh  (when prod Docker in scope)
5. bash scripts/cluster/cluster-ssh-routine.sh  (before SSH-heavy work)
6. proceed task
```

---

## 6. Grace triage backlog (propose rows — Abelard does not create active.md)

| Priority | Summary | Owner | Est |
|----------|---------|-------|-----|
| P1 | ABEL-01 routine inspection script | Abelard | 1 pass |
| P1 | ABEL-02 fleet bare-`.local` DNS roll (izvoras, mugurel, LAMAITA doc) | Abelard | 1 pass |
| P1 | ABEL-05 QUICK OPS refresh (CHROMA-1/headless/cloudflared/conn-first) | Abelard | 1 pass |
| P2 | ABEL-03 + ABEL-04 dnsmaster yaml + missing compliance scripts | Abelard | 1 pass |
| P2 | ABEL-06 Cloudflare token renewal | Abelard | operator trustmaster |
| P2 | ABEL-07 tersagor disk hygiene | Abelard | 1 pass |
| P2 | ABEL-11 Custo intake Mullvad/LAMAITA Tailscale | Abelard | 1 pass |
| P3 | ABEL-08 system_maintenance restore | Abelard | 1 pass |
| P3 | ABEL-12 cert stamp sync fix in trustmaster-hub | Gena/Abelard | small |
| P3 | ABEL-09 prometheus-mcp packet note | Ethan/Cursor | doc |

---

## 7. Contemplation verdict

**conn.local is now first-class DevOps muscle** — not optional garnish. It belongs in session-open, QUICK OPS lead, and Abelard routine script.

**Biggest doc debt:** QUICK OPS still teaches CHROMA-1, headless, and cloudflared-on-prichindel — all retired paths. That is active harm for fast ops.

**Biggest tooling debt:** no single routine inspection entrypoint; missing hostname/dns compliance scripts cited in canon.

**Ask Grace:** triage P1 block as **ABELARD-OPS-WAVE-2026-09-01** (~3 execution rows or one drain row).

---

SIGNED: DevOps (Abelard) | contemplation | 2026-09-01 | QUICK OPS + conn.local + capacity backlog
