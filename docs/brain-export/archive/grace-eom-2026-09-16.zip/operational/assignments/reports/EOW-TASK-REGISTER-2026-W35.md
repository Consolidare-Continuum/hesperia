# EOW task register — 2026-W35

**Generated**: 2026-08-30T18:53:42Z  
**Wave**: REPO-EOW 2026-W35  
**Model**: 5 rows × 10 team entities = **50** (Grace triage → active.md → execute until DONE).  
**Scope**: **compress, compact, integrate, evolve** using defined contexts — not Palantir, not weekly doc churn.

## Repo-state signals

- **git_dirty**: 8 uncommitted path(s) — `M governance/workflow_automation_state.txt,  M governance/workflow_context_current.md,  M governance/workflow_driver_current.txt,  M governance/workflow_heartbeat.txt,  M scripts/cluster/eow-eod/end_of_week_collect.sh'
- **active_md**: OPEN rows=0; repo-wave mentions=0
- **cluster_audit_stale**: 30/30 cluster READMEs need REPO-EOW 2026-W35 audit — `actarus, altitudine, alunel, ceres, chroma-server'
- **index_governance_gap**: 8 governance doc(s) not in INDEX — `ADEV-2026-REGISTER.md, ADR-CHROMA-CANONICAL-ALUNEL.md, ADR-FPF-THINKING-MAP-CROSS-MAP-TASK-BRIDGE-REJECTED.md, ADR-IM-IRC-T07-AUTH-PATTERN.md, AGENT-AUTHENTIK-VAULT.md'
- **folder_ls_soft**: folder LS capacity WARN (2 line(s)) — `SOFT	59	operational/assignments/reports, SOFT	52	scripts/ (inventory excl. _compat,__pycache__,_layout_stash)'
- **inbox_attention**: inbox.md may need weekly triage pass
- **chroma_policy_week**: CHROMA-USAGE-POLICY has no this-week EOW touch marker

## Tasks by entity

### Ethan (Chief Architect)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-001 | pathing | Run verify-host-role-separation.sh | Script exit 0 or gaps logged in closure; fix wiring only if broken |
| REPO-EOW-35-002 | integration | Match WORKFLOW-SCRIPT-NAMES to scripts/ on disk | Stale names fixed or listed in closure; no new governance file |
| REPO-EOW-35-003 | awareness | Workflow driver entry points resolve | Each named script in WORKFLOW-SCRIPT-NAMES exists; broken refs fixed |
| REPO-EOW-35-004 | execution | Append EOW compliance row | One row in CURSOR-REPO-COMPLIANCE-CHECK.md with N/50 + what ran |
| REPO-EOW-35-005 | awareness | CCB note only if contract changed | If execution changed governance/contracts this week: one line in closure; else skip |
### Grace (Product Director)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-006 | execution | Triage register → active.md | 50 REPO-EOW rows triaged OPEN; DONE only after verified execution |
| REPO-EOW-35-007 | awareness | active.md OPEN row integrity | Each OPEN row has owner + project; non-repo OPEN counted for closure |
| REPO-EOW-35-008 | integration | Workflow context path alive | Read workflow_heartbeat + workflow_driver_current; stale driver noted or refreshed via workflow_run |
| REPO-EOW-35-009 | execution | until-done gate | end_of_week_run.sh until-done exit 0 before closure |
| REPO-EOW-35-010 | awareness | inbox → active path | Blocking inbox items linked or triaged; no new assignment markdown unless required |
### Olivia (Backend Lead)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-011 | execution | Run workflow_run.sh one pass | Driver current step file updated or autonomous_idle confirmed |
| REPO-EOW-35-012 | integration | Workflow API 9096 reachability | curl heartbeat or documented skip in closure |
| REPO-EOW-35-013 | integration | workflow_driver.py script refs | Imports/paths match repo; fix broken wiring only |
| REPO-EOW-35-014 | awareness | Context passport path | workflow_context_current.md present when driver has OPEN step |
| REPO-EOW-35-015 | integration | abelard_executor path | cluster/workflow-automation/abelard_executor.py referenced and reachable |
### Ava (Frontend Lead)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-016 | integration | Browser MCP in deployed config | mcp.json template includes cursor-ide-browser; deploy if drift |
| REPO-EOW-35-017 | integration | docs/CURSOR.md matches MCP deploy paths | Fix drift in existing doc; no new doc unless MCP setup broken |
| REPO-EOW-35-018 | execution | Browser runbook → script path check | SCRIPT-RUNBOOK-* with browser_* reference real commands |
| REPO-EOW-35-019 | awareness | Web task MCP five-tool path | query_brain_fts + pipeline + runbook + approval + browser reachable or noted |
| REPO-EOW-35-020 | awareness | Telegram closure readable | agent-telegram message is operator-facing summary of execution |
### Marcus (DB Lead)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-021 | execution | Postgres cc_brain stamp + FTS path | cc_brain_pg_main status=1; query_brain_fts returns hits |
| REPO-EOW-35-022 | integration | CHROMA-INSTANCES vs chroma-instances rule | Team=Postgres; CHROMA-1 decommissioned; CHROMA-2=books; fix naming drift only |
| REPO-EOW-35-023 | execution | colombo-library / CHROMA-2 status | get_colombo_library_status OK or skip reason in closure |
| REPO-EOW-35-024 | integration | CHROMA-2 / BIOPOLE-OP env stamps | Default-env docs match CHROMA-INSTANCES; no team path to CHROMA-1 |
| REPO-EOW-35-025 | awareness | Brain vs library territory | Postgres=team; CHROMA-2=library; no query_knowledge calls |
### Sophia (DevOps Lead)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-026 | execution | Cluster README audit stamp (15 stale) | Stamp wave_label or today on stale cluster/*/README; JSON note in closure |
| REPO-EOW-35-027 | pathing | Run detect-cursor-session-mode.sh | cursor_session_mode.txt current; host/path warning respected |
| REPO-EOW-35-028 | pathing | agent SSH CA path valid | valid_until future or renew/escalate noted |
| REPO-EOW-35-029 | awareness | Cluster node registry vs disk | cluster/*/README count matches glob; gaps logged |
| REPO-EOW-35-030 | integration | Prod touch via Abelard path only | Any prichindel/alunel prod step escalated; not faked DONE |
### Liam (Automation)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-031 | execution | Run mcp_config_drift_check; deploy if drift | deploy-mcp-config-global.sh if drift_detected=1 |
| REPO-EOW-35-032 | execution | Run end_of_week_run.sh execute | Mechanical wave JSON written (manual_owner_execute stamp) |
| REPO-EOW-35-033 | integration | SCRIPT-RUNBOOK → script path verify | Each runbook's commands/paths resolve; tiny runbooks flagged |
| REPO-EOW-35-034 | execution | EOW scripts smoke | collect, research, until-done runnable from repo root |
| REPO-EOW-35-035 | integration | workflow_automation_run.sh in canon | Listed in WORKFLOW-SCRIPT-NAMES and exists on disk |
### Daniel (Security Lead)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-036 | pathing | Review agent_ssh_cert_status.txt | Future valid_until or renew script path executed/noted |
| REPO-EOW-35-037 | awareness | Approval gates before destructive | No EOW DONE on destructive rows; pending approvals respected |
| REPO-EOW-35-038 | execution | Compliance row execution log | CURSOR-REPO-COMPLIANCE row states what ran not what was written |
| REPO-EOW-35-039 | awareness | Protected paths check | olgahere G:, /data/ untouched without approval |
| REPO-EOW-35-040 | awareness | Product OPEN rows not faked | Hesperia/Tailscale/etc. remain OPEN unless really executed |
### Noah (AI Systems)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-041 | execution | Postgres brain query path alive | query_brain_fts via pg-knowledge OK |
| REPO-EOW-35-042 | integration | MCP pg-knowledge wiring | Template matches repo; deploy if drift |
| REPO-EOW-35-043 | execution | Post-push brain sync note | Git→PG sync path noted; CHROMA-1 ingest skip (decommissioned) |
| REPO-EOW-35-044 | awareness | fpf_mode context | Read governance/fpf_mode; books via colombo-library if fpf_mode=1 |
| REPO-EOW-35-045 | integration | CHROMA-USAGE-POLICY execution refs | Policy matches Postgres main + CHROMA-2 books; fix links only |
### Emma (Integrations)

| ID | Kind | Summary | Acceptance |
|----|------|---------|------------|
| REPO-EOW-35-046 | execution | deploy-mcp-config-global if drift | MCP configs synced; restart Cursor noted for operator |
| REPO-EOW-35-047 | execution | Telegram closure | scripts/agent-telegram.sh with N/50 summary (n8n path) |
| REPO-EOW-35-048 | integration | Workflow API token path | 9096 contract matches scripts; env path in existing runbook |
| REPO-EOW-35-049 | integration | MCP catalog parity | Repo template vs session catalog; fix not duplicate |
| REPO-EOW-35-050 | integration | Mail MCP integration path | cursor-postfix-mail reachable or documented skip |

## Grace triage

1. Copy rows into `active.md` (project **cursor-repo**, P1, status OPEN).
2. Triage packet: `operational/assignments/GRACE-TRIAGE-REPO-EOW-WAVE-2026-W35.md`
3. Cursor main executes with owner **CSP** per row until **zero OPEN** REPO-EOW rows.

SIGNED: Research (Cursor main) | EOW register | 2026-08-30 | 2026-W35
