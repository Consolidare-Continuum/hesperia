# CHROMA-1 full decommission — secondary mirror closeout

**Date:** 2026-09-01  
**Wave:** CHROMA1-DECOM-00..10 (Grace team AWP)  
**Session:** execution_host=altitudine, dev_office=true, connectivity=lan

## Verdict

**DONE.** Live ops path = Postgres **`pg-knowledge`** (`query_brain_fts` / `query_fpf_catalog`). CHROMA-1 services/MCP retired 2026-08-30; this wave purged **session-open secondary mirrors** that still instructed `query_knowledge` / `chroma-knowledge`.

## What changed

| Area | Files |
|------|-------|
| `.cursor/` entry | `README.md` — pg-knowledge, EOD step wording |
| EOD workflow | `END-OF-DAY-WORKFLOW.md` — step 5 → git→Postgres sync; no CHROMA-1 ingest |
| Context archive | `CONTEXT-ARCHIVE.md` — current-brain tombstone header |
| Abelard mirrors | `DEVOPS-AI-GUIDELINES-AWARENESS.md`, `VERSUS-INCIDENT-AWARENESS.md` (prior pass) |
| Colombo | `COLOMBO-CHROMA-2.md`, `COLOMBO-LIBRARY-RESEARCH-SCHEMA.md` |
| Surveillance | `docs/SURVEILLANCE.md` §18 MCP health — pg-knowledge + CHROMA-2 |
| Ops report tombstone | `governance/MCP-CHROMA-OPERATIONAL-REPORT.md` |
| Staging copies | `governance/ingest_staging/*` — RETIRED banners |
| LAMAITA | `cluster/lamaita/README.md` |
| OverAPI | `governance/OVERAPI-CHEATSHEETS-EXTERNAL-REFERENCE.md` |
| Stamps/specs | `chroma_books_home.txt`, FPF/Gena/MCP-advise specs (prior pass) |
| Fitness gate | `scripts/brain/verify/context-fitness.sh` — secondary_mirror forbid list |

## Verification

- `bash scripts/brain/verify/context-fitness.sh` → **PASS**
- Ingest scripts under `cluster/chroma-server/ingest-*.sh` → REFUSED at top (pre-existing)
- `governance/mcp-config.json` → no `chroma-knowledge` key

## Intentionally kept (tombstone / history)

- `projects/cc-brain-pg/*`, `cluster/alunel/CHROMA-1.md`, `governance/CHROMA-1-DEFAULT-ENV.md`
- `active.md` DONE rows referencing historical PGK/CCB waves
- EOD historical "Last run" log blocks (dated archive prose)
- biopole-op seat `chroma-knowledge` → **CHROMA-BIOPOLE-OP** (separate instance, not team CHROMA-1)

## Residual tails (non-blocker)

- `agents/abelard/notes/CUSTO-MCP-01-*` — dated note; not session-open
- `inbox.md` historical entries — archive lane
- Prometheus metric names `cursor_mcp_chroma_ok` — legacy gauge label; runtime uses pg-knowledge

SIGNED: Triage (Grace) | CHROMA-1 mirror purge closeout | 2026-09-01
