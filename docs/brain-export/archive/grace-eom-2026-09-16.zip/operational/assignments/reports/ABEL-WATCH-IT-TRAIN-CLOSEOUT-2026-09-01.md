# ABEL-WATCH IT TRAIN closeout — team alone (no Abelard executor)

**Date:** 2026-09-01  
**Wave:** ABEL-WATCH-00..07  
**Triage:** [GRACE-TRIAGE-ABELARD-WATCH-IT-TRAIN-2026-09-01.md](../GRACE-TRIAGE-ABELARD-WATCH-IT-TRAIN-2026-09-01.md)  
**Trigger:** Operator — Grace full AWP; close Abelard WATCH exit without Abelard as row owner.

---

## Verdict

| Area | Status |
|------|--------|
| Disk (altitudine, tersagor) | **GREEN** — altitudine 81%→76%; tersagor 83%→60% |
| dnsmaster AdGuard conn.local | **GREEN** — live rewrite confirmed; patch script reload OK |
| Fleet `.local` DNS | **PARTIAL** — altitudine, prichindel, librarymaster, tersagor rolled; izvoras/mugurel offline; LAMAITA pending |
| conn catalog v2 | **GREEN** — 27 actions live (was 21); mx tunnel + mailcow postfix/dovecot added |
| Cloudflare Zone DNS token | **GREEN** — `dry-glitter-7293` installed 2026-09-01; certbot ini + `zone_dns_edit.token`; zones API OK from prichindel (egress 89.28.74.161) |
| Routine inspection | **GREEN** — `abelard-routine-inspection.sh` VERDICT: GREEN |

**Exit:** WATCH → **GREEN** (CF token installed 2026-09-01); fleet `.local` still **PARTIAL** on offline edges.

---

## ABEL-WATCH-04 addendum — CF token install (2026-09-01 PM)

Operator token **dry-glitter-7293** (expires **2026-11-30**):

| Check | Result |
|-------|--------|
| Egress IP (prichindel) | `89.28.74.161` — matches IP filter |
| `GET /zones?name=prichindel.com` | **success** — certbot-compatible |
| `/user/tokens/verify` | **fails** (account-scoped `cfat_*` — use zones API or account verify endpoint) |
| Installed paths | `/root/.secrets/certbot/cloudflare.ini`, `/root/.secrets/cloudflare/zone_dns_edit.token` |

**Scope note (Abelard):** token carries account-wide Write on many resources — broader than Zone DNS Edit alone. Acceptable if intentional single prod token; narrow later if desired. **R2 S3 keys** shown in dashboard are separate credentials — not installed to certbot path.

## ABEL-WATCH-01 — Liam · tersagor disk

- **Before:** ~83% SOFT (prior pass); audit showed `/home/igareosh/imirc-*` ~11G legitimate product data.
- **Action:** `journalctl --vacuum-size=100M` (safe).
- **After:** **60%** `/` — below soft threshold.
- **Decision:** No deletion of imirc product dirs without operator scope.

---

## ABEL-WATCH-02 — Daniel · altitudine disk

- **Before:** **81%** SOFT — churn in `/data/altitudine` (CC_.com, chroma-venv) + `/home/igareosh` (.vscode-server, .cache, .pyenv).
- **Action:** journal vacuum (~334M freed), `apt-get clean`, pip/npm cache trim (safe).
- **After:** **76%** `/` — below soft threshold.
- **Decision:** No chroma-venv / CC_.com tree deletion without approval; .vscode-server left (dev office).

---

## ABEL-WATCH-03 — Noah · dnsmaster AdGuard

- **Policy:** Never scp full repo yaml onto dnsmaster ([cluster/dnsmaster/README.md](../../../cluster/dnsmaster/README.md)).
- **Action:** `scripts/cluster/misc/dnsmaster/dnsmaster-agh-patch-rewrites.sh` for `conn.local` + `conn.prichindel.local` → **no changes** (already live); AdGuardHome reloaded.
- **Verify:** `dig +short conn.local @127.0.0.1` → `192.168.100.21`.

---

## ABEL-WATCH-04 — Ethan · Cloudflare Zone DNS token (decision)

| Path | State |
|------|--------|
| `/root/.secrets/certbot/cloudflare.ini` | **Exists** — certbot flat format (`dns_cloudflare_api_token = …`) |
| `/root/.secrets/cloudflare/cf-api-token` | Exists (separate network token family) |
| `/root/.secrets/cloudflare/zone_dns_edit.token` | **Never provisioned** — not in repo scripts; aspirational path only |

**Live verify (2026-09-01):** certbot DNS token → Cloudflare `/user/tokens/verify` → **401 Invalid API Token**.

**Decision (Ethan):**

1. **Canonical write path for DNS-01 / zone edits:** renew **Zone DNS Edit** token in Cloudflare dashboard → update `/root/.secrets/certbot/cloudflare.ini` on prichindel (mode 600, root).
2. **Optional:** after renew, add symlink or copy to `/root/.secrets/cloudflare/zone_dns_edit.token` for scripts that expect that filename — Grace can triage if needed.
3. **Agents:** do not invent tokens; cert renew / DNS automation stays **BLOCKED** until operator renews.

**Resolved 2026-09-01 PM:** Operator provisioned **dry-glitter-7293** (intentional 90d full-scope); **SOT trustmaster** `~/.secrets/cloudflare/` → mirrored prichindel; zones API **OK**. Stamp: [governance/cloudflare_prod_token_status.txt](../../../governance/cloudflare_prod_token_status.txt).

Ref: [docs/CLOUDFLARE.md](../../../docs/CLOUDFLARE.md) § Zone DNS.

---

## ABEL-WATCH-05 — Emma · fleet bare `.local` DNS

**Rolled (conn.local HTTPS OK after fix):**

| Host | Repo path used |
|------|----------------|
| altitudine | local `/data/altitudine/CC_.com` |
| prichindel | `/data/workspaces/cursor` |
| librarymaster | `/data/workspaces/cursor` |
| tersagor | `/data/workspaces/cursor` |

**Not rolled (expected / offline):**

| Host | Reason |
|------|--------|
| izvoras | SSH unreachable (no route) |
| mugurel | SSH unreachable (no route) |
| mediamaster | agent SSH not enrolled |
| dnsmaster | DNS server — AdGuard rewrites sufficient; no client hosts fix required |

**LAMAITA (Windows) — operator or next Abelard pass:**

1. Ensure DNS points at dnsmaster (`192.168.100.25`) on LAN or use Tailscale + dnsmaster-ts.
2. Optional: merge cluster LAN block into `C:\Windows\System32\drivers\etc\hosts` (conn.local → 192.168.100.21) when off-LAN without split DNS.
3. Runbook anchor: [cluster/lamaita/README.md](../../../cluster/lamaita/README.md) · script: `scripts/cluster/dns-cluster/bin/cluster-bare-local-dns-fix.sh` (Linux only).

---

## ABEL-WATCH-06 — Marcus · conn catalog v2

**Added to** `cluster/conn/hub/actions_catalog.json`:

- `mx1-vaporas-smtp-tunnel-restart` / `mx2-vaporas-smtp-tunnel-restart`
- `mx1-mailcow-postfix-restart` / `mx2-mailcow-postfix-restart`
- `mx1-mailcow-dovecot-restart` / `mx2-mailcow-dovecot-restart`

**Deployed:** rsync hub → `prichindel:/data/docker/conn/hub/` + `systemctl restart conn-hub`.

**Live:** `GET https://conn.local/api/actions` → **count=27** (includes mx actions).

**Note:** mx1/mx2 SSH fast-ops require agent cert on mx hosts; direct SSH from altitudine to mx1 currently **Permission denied** — enroll agent CA on mx VMs for conn-action SSH mode (Abelard infra tail, not catalog gap).

**Tests:** `cluster/conn/tests/test_hub_actions.py` — 6 passed.

---

## ABEL-WATCH-07 — Ava · verification

`bash scripts/abelard-routine-inspection.sh`:

- conn.local: 14 hosts up, 0 problems
- agent cert: valid
- prometheus firing: 0
- disk: prichindel 67%, altitudine **76%**, tersagor **60%**, librarymaster 68%, trustmaster 23%
- **VERDICT: GREEN**

---

## Operator touch (single tail)

~~**Cloudflare Zone DNS Edit token**~~ — **CLOSED 2026-09-01** (dry-glitter-7293 on prichindel).

Remaining optional tails: fleet `.local` on izvoras/mugurel/LAMAITA when hosts online; mx agent SSH for conn-action mail ops.

---

SIGNED: Triage (Grace) | IT TRAIN Abelard watch closeout | 2026-09-01 | cluster hygiene + conn v2
