# Gena handoff — grace_trashout_ops thinking map afterburn

**Date:** 2026-09-02  
**From:** Grace trash-out slice1 session  
**To:** Gena (main dev) — map + operability fixes landed

```
From: Grace Context | To: Gena Context | Reason: operator handoff — afterburn trash-out into thinking map | What changes: new grace_trashout_ops map; registry v10; operability blockers addressed
```

## Delivered

| Item | Path |
|------|------|
| Domain map | `thinking_maps/grace_trashout_ops/map.py` |
| Session variables store | `thinking_maps/grace_trashout_ops/thinking-map-store/variables.json` |
| Tests | `thinking_maps/tests/test_grace_trashout_ops.py` |
| Collect script | `scripts/workflow/grace/grace-trashout-collect.sh` |
| MCP wiring | `agent_mcp_thinking_map/__main__.py`, `thinking_maps/mcp_inquiry.py` |
| CLI | `scripts/thinking-map/thinking_map_cli.py` |
| Registry v10 | `governance/mcp_thinking_map_registry.json` — chain `grace_brain_trashout` |
| Grace duties | `agents/grace/GRACE-DUTIES.md` §Brain trash-out thinking map |

## Operability blockers fixed

| Blocker (Grace slice1) | Fix |
|------------------------|-----|
| Wrong map (`eod_ops` / `team_ops`) | Dedicated `grace_trashout_ops` — no `task_id` |
| `eod_collect_done` token mismatch | `grace_trashout_collect_done` + collect script |
| Full EOD chain too heavy | Lighter states: plan → collect → archive → destructive? → wrap |
| No inquiry chain | `grace_brain_trashout` chain + `library_params.grace_brain_trashout` |
| Destructive without workflow row | `archive_only` vs `enter_destructive` + existing `destructive_gate` chain |

## Next slice usage

1. Fill `thinking-map-store/variables.json` (`~intent`, storage, trash, optional gap).
2. `thinking_map_verify` → folder LS cap → approval (if purge) → `grace-trashout-collect.sh`.
3. `thinking_map_step(map_id=grace_trashout_ops, …)` — pass honest evidence tokens.
4. Archive push → `grace_trashout_archive_pushed` → destructive or `archive_only` → wrap + stamp `status=0`.

SIGNED: Developer (Gena) | Cursor handoff | 2026-09-02 | grace_trashout_ops afterburn
