# Abelard — olgahere → altitudine SSH permanent fix

**Date:** 2026-09-09 · **Owner:** Abelard

## Issues found

1. Windows agent cert expired (~07:17 local); interactive SSH failed with `Certificate invalid: expired`.
2. trustmaster daily renew succeeded for Linux but did not push to olgahere.
3. `~/.ssh/config.d/cluster-agent-ca.conf` on trustmaster had `Host olgahere` → **192.168.100.5** (Wi‑Fi). SSH target is USB GbE **192.168.100.9**.
4. Monument sync returned OK when unreachable (`return 0`).
5. Pull task exited 0 while cert still valid (06:00) — no refresh before hard expiry.
6. Scripts topic layout broke brain-path sync helpers (`olgahere-ensure-up`, renew→sync sibling paths).

## Fix applied

- Fresh cert + `altitudine` / `altitudine-admin` client config on Olga.
- trustmaster include + fragment: HostName **.9**, User **Olga**, agent CA.
- Live cron sync (monument): hard-target `Olga@192.168.100.9`, fail loud.
- Brain: renew/sync/deploy path fixes; pull refreshes when Valid &lt; 6h; PowerShell Log must not use Write-Output into assigned returns.
- Docs/registry/QUICK_OPS/runbook updated — SSH = `.9`, Wi‑Fi = `.5` only.

## Verify

`ssh altitudine` → `olga` · `ssh altitudine-admin` → `igareosh`

Canon: [cluster/olgahere/ALTITUDINE-SSH-HANDOFF.md](../../cluster/olgahere/ALTITUDINE-SSH-HANDOFF.md)

SIGNED: DevOps (Abelard) | cluster context | 2026-09-09 | olgahere altitudine SSH
