# Gena handoff — book-ocr-tools + PDF→md brain muscle

**Date:** 2026-09-01  
**Owner:** Gena → Cursor (brain-wide wiring)  
**Inbox:** Operator→Gena reprogram `book-ocr-tools/` (2026-09-01)

## Delivered

| Item | Path |
|------|------|
| OCR repair pipeline (5 scripts + common) | `book-ocr-tools/` |
| Pipeline runner | `scripts/book-ocr/book-ocr-run.sh` · hot `scripts/book-ocr-run.sh` |
| PDF→md + optional cleanup | `scripts/book-ocr/pdf-to-md.sh` · hot `scripts/pdf-to-md.sh` |
| Smoke test | `scripts/book-ocr/smoke-test.sh` |
| Agent skill | `.cursor/skills/book-ocr-tools/SKILL.md` |
| Runbooks | `SCRIPT-RUNBOOK-book-ocr-tools` · **`SCRIPT-RUNBOOK-pdf-to-md`** |
| Brain-wide rule | `.cursor/rules/cursor-pdf-to-md-tools.mdc` |
| Key resolution | `book_ocr_common.load_openai_api_key()` — env, Hesperia local file, ops-method |

## Pipeline order

1. **MarkItDown** — PDF/Office/ePub → `.md` (`pdf-to-md.sh` or MCP `convert_file`)
2. **repair_text** — encoding, hyphen joins
3. **clean_corpus_artifacts** — headers, page nums, ligatures
4. **fix_ocr_word_errors** — mechanical confusion table
5. **fix_ocr_word_errors_llm** — short-token LLM (optional)
6. **fix_ocr_word_errors_llm_longrun** — glued-run LLM (optional)

## Verified (2026-09-01, altitudine)

- Mechanical + LLM short on fixture: `Ulliversity`→`University`, `historyoofinsanity`→`history of insanity`
- Key via Hesperia local `openai_api_key.txt` (gitignored) — not committed to any repo

## Out of scope / unchanged

- **Hesperia syzif originals** — stay at `hesperia/modules/default/corpus/syzif/` (127 = 120 books + 7 tools)
- **Photo OCR** — `projects/olga-tfp-book-ocr/`
- **CHROMA-2 ingest** — Colombo / colombo-library
- **Security:** old CC git key revoked; rotation of exposed history = trustmaster (inbox item)

## Cursor brain-wide action

Any agent task requiring **PDF→md**: follow `cursor-pdf-to-md-tools.mdc` → `SCRIPT-RUNBOOK-pdf-to-md`. No ad-hoc convert stacks.

SIGNED: Developer (Gena) | book-ocr + PDF→md handoff | 2026-09-01 | brain muscle delivery
