# Thinking-map technical blockers — EOD queue (2026-09-01T17:23:19Z)

Pending (open + fixed_runtime): **20**
Registry: governance/thinking_map_blockers.jsonl

| blocker_id | status | class | task_id | outcome | registered |
|---|---|---|---|---|---|
| 007f4241336f | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-30T15:41:47Z |
| 9e3059b71128 | open | collect_evidence |  | OutcomeKind.COLLECT_EVIDENCE | 2026-08-30T15:41:47Z |
| af6e144a3186 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-30T15:41:47Z |
| eb841b2c43d0 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-30T15:41:19Z |
| 6e0fce18731b | open | collect_evidence |  | OutcomeKind.COLLECT_EVIDENCE | 2026-08-30T15:41:19Z |
| 6de3e4486854 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-30T15:41:19Z |
| ebefde0945ef | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-30T15:26:55Z |
| 77cf4cce453d | open | collect_evidence |  | OutcomeKind.COLLECT_EVIDENCE | 2026-08-30T15:26:55Z |
| 529514280a73 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-30T15:26:55Z |
| 64c85ee10c4f | open | collect_evidence |  | OutcomeKind.COLLECT_EVIDENCE | 2026-08-29T06:29:25Z |
| 23694efa543b | open | collect_evidence | AGT-AGRO | OutcomeKind.COLLECT_EVIDENCE | 2026-08-29T06:09:17Z |
| f3bcda03b679 | open | collect_evidence | AGT-SHA | OutcomeKind.COLLECT_EVIDENCE | 2026-08-29T06:09:17Z |
| e0b97936b7b5 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-29T06:04:00Z |
| 86378053f636 | open | collect_evidence |  | OutcomeKind.COLLECT_EVIDENCE | 2026-08-29T06:04:00Z |
| 5c9160041ade | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-29T06:04:00Z |
| 936448f60b28 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-29T05:55:31Z |
| 6a4a58c05be4 | open | collect_evidence |  | OutcomeKind.COLLECT_EVIDENCE | 2026-08-29T05:55:31Z |
| ec4ac8fe17ff | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-29T05:55:31Z |
| e841ae3fbe31 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-29T05:43:40Z |
| 85b56a4bd3b6 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-08-29T05:43:40Z |

### 007f4241336f (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_brain_fts_done, runbook_read

### 9e3059b71128 (collect_evidence) — open
- task: workflow_execute
- reason: Evidence gaps: ['destructive_scope']
- missing_evidence: destructive_scope

### af6e144a3186 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_brain_fts_done, runbook_read

### eb841b2c43d0 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_brain_fts_done, runbook_read

### 6e0fce18731b (collect_evidence) — open
- task: workflow_execute
- reason: Evidence gaps: ['destructive_scope']
- missing_evidence: destructive_scope

### 6de3e4486854 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_brain_fts_done, runbook_read

### ebefde0945ef (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_brain_fts_done, runbook_read

### 77cf4cce453d (collect_evidence) — open
- task: workflow_execute
- reason: Evidence gaps: ['destructive_scope']
- missing_evidence: destructive_scope

### 529514280a73 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_brain_fts_done, runbook_read

### 64c85ee10c4f (collect_evidence) — open
- task: workflow step
- reason: Evidence gaps: ['eod_collect_done']
- missing_evidence: eod_collect_done

### 23694efa543b (collect_evidence) — open
- task: AGROPLAN
- reason: Evidence gaps: ['chat_map_bottom_up_done', 'fpf_verify_ok']
- missing_evidence: chat_map_bottom_up_done, fpf_verify_ok

### f3bcda03b679 (collect_evidence) — open
- task: SHA
- reason: Evidence gaps: ['draft_v11_exists', 'fpf_verify_ok', 'sha_pack_indexed']
- missing_evidence: draft_v11_exists, fpf_verify_ok, sha_pack_indexed

### e0b97936b7b5 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 86378053f636 (collect_evidence) — open
- task: workflow_execute
- reason: Evidence gaps: ['destructive_scope']
- missing_evidence: destructive_scope

### 5c9160041ade (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 936448f60b28 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 6a4a58c05be4 (collect_evidence) — open
- task: workflow_execute
- reason: Evidence gaps: ['destructive_scope']
- missing_evidence: destructive_scope

### ec4ac8fe17ff (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### e841ae3fbe31 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 85b56a4bd3b6 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read
