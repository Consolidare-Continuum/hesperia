# Conn actions wave closeout — 2026-09-01

**Wave:** CONN-ACT-00..04 · [GRACE-TRIAGE-CONN-ACTIONS-WAVE-2026-09-01.md](../GRACE-TRIAGE-CONN-ACTIONS-WAVE-2026-09-01.md)

## Delivered

| ID | Result |
|----|--------|
| CONN-ACT-00 | Grace triage + active.md rows |
| CONN-ACT-01 | [SPEC-ETHAN-CONN-LOCAL-ACTIONS-API.md](../../governance/SPEC-ETHAN-CONN-LOCAL-ACTIONS-API.md) — alunel/trustmaster hard forbid |
| CONN-ACT-02 | `hub/actions_catalog.json` (21 actions) · `actions_runner.py` · `/api/actions` · `/api/action/run` |
| CONN-ACT-03 | `scripts/conn-action.sh` · QUICK OPS · conn UI Fast ops panel |
| CONN-ACT-04 | Deployed live on prichindel — `/api/actions/policy` count=21 · dry-run OK |

## Usage (Abelard session-wide)

```bash
bash scripts/conn-action.sh list --host prichindel --group docker
bash scripts/conn-action.sh run prichindel-nginx-reload --dry-run
bash scripts/conn-action.sh reload-nginx
```

Token: `/etc/conn/token` on prichindel or `CONN_TOKEN` env.

SIGNED: DevOps (Abelard) | conn actions wave | 2026-09-01
