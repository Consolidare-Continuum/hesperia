# Biopole cold flash backup — LAMAITA closeout

**finished_at_utc:** 2026-09-01T17:09:51Z
**flash:** `D:\github_flash\clients\biopole`
**stage:** `/tmp/biopole-cold-flash-2026-09-01`

## Counts
- altitudine-home-biopole-repos: **13/13** repo dirs
- prichindel-biopole-op-repos: **13/13** repo dirs
- github-mirrors: **13** `.git` bare repos
- github-bundles: **13** `.bundle` files
- prichindel-clients-biopole: extracted; `planfix-workspace/`, `ops-method-bpm/`, `scripts/` present
- secrets-backup: present on flash

## Manifest
- `BIOPOLE-COLD-BACKUP-2026-09-01.txt` sha256: `c4938eb13ad4949bac2d6a71ba7a3c247fd315506dfde89797fa28e713b64ee7`

## Log
- altitudine: `/data/tmp/biopole-flash-transfer/finish-verify.log`

SIGNED: DevOps (Abelard) | cluster context | 2026-09-01 | Biopole cold flash LAMAITA
