# Grace next run — brain trash-out

**Date:** 2026-09-02  
**Stamp:** [grace_brain_trashout_next.txt](../../governance/grace_brain_trashout_next.txt) (`status=1`)  
**Policy:** [BRAIN-OPERATIONAL-SLIM-PERMANENT.md](../../governance/BRAIN-OPERATIONAL-SLIM-PERMANENT.md)

```
From: Grace Context | To: Grace Context | Reason: operator — next run trash out | What changes: archive closed waves; project home pointers; brain slim
```

## Mandate

1. **Temporal / project stuff → proper repos** — deliverables live under `projects/<name>/` or client repos; not flat `operational/assignments/` churn.
2. **Closed waves → archive tarball** — hesperia `docs/brain-export/archive/operational-assignments-*.tar.gz`; keep register pointer + wrap + awareness stub in brain.
3. **Trash out of brain** — no re-expand closed waves; folder LS soft 40 / hard 60 before happy exit.

## Archive candidates (first trash-out slice)

| Wave | Register | Project home | Action |
|------|----------|--------------|--------|
| CONN-FIT | [CONN-FIT-2026-REGISTER.md](conn-local/CONN-FIT-2026-REGISTER.md) | [projects/conn-local/](../../projects/conn-local/) | Tarball `conn-local/` assignment subtree; keep README + awareness |
| CONN-TIME | [CONN-TIME-2026-REGISTER.md](conn-local/CONN-TIME-2026-REGISTER.md) | projects/conn-local | Same |
| CONN-MAP | [CONN-MAP-2026-REGISTER.md](conn-local/CONN-MAP-2026-REGISTER.md) | projects/conn-local | Same |
| CC-CONT-01 | note only | CC_/AVAILABILITY.md | Keep note + keeper; no active row churn |

**Not trash-out yet:** ALT-DISK (02–06 PAUSED on board) — register only, no archive.

## Thinking-map / conn

- `conn_time` + `conn_names` chains **filled** in [mcp_thinking_map_registry.json](../../governance/mcp_thinking_map_registry.json) v9 (2026-09-02).

## Postgres brain mirror

Routine git→PG sync (Abelard/Felix) — no Grace row. Repo markdown remains SOT until sync.

## Execute checklist

- [x] `bash scripts/eod-folder-ls-cap-check.sh` — assignments OK 23
- [x] Tarball closed conn-local + mcp-ops + mcp-runbook → hesperia archive
- [x] Cold stubs → [projects/conn-local/cold-backup/](../../projects/conn-local/cold-backup/)
- [x] Purge `__pycache__` (3925) + root `venv/` (5.1G)
- [x] Set `grace_brain_trashout_next.txt` `status=0`
- [x] Wrap [GRACE-WRAP-BRAIN-TRASHOUT-2026-09-02.md](GRACE-WRAP-BRAIN-TRASHOUT-2026-09-02.md)

**DONE 2026-09-02** · approval-8e77bf1be163 · hesperia tip `5bc3451`

SIGNED: Triage (Grace) | trash-out executed | 2026-09-02
