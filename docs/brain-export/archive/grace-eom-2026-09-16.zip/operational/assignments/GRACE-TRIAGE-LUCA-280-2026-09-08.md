# Grace triage — LUCA-280 (Luca accountant Employ 5)

**Date:** 2026-09-08  
**From:** Operator (Cursor chat) — name Luca; BI path C; budget 250–300; Grace proceed triage; teamwork proceed  
**Outcome:** PROJECT-CREATED  
**Register:** [LUCA-280-2026-REGISTER.md](../../governance/LUCA-280-2026-REGISTER.md)  
**SPEC:** [SPEC-ETHAN-LUCA-ACCOUNTANT-EMPLOY-5.md](../../governance/SPEC-ETHAN-LUCA-ACCOUNTANT-EMPLOY-5.md)  
**Design:** [docs/superpowers/specs/2026-09-08-luca-accountant-employ-5-design.md](../../docs/superpowers/specs/2026-09-08-luca-accountant-employ-5-design.md)

---

## Triage

| Field | Value |
|-------|--------|
| Type | Feature / program |
| Project | `cursor-repo` (+ cluster MSSQL + Lightdash) |
| Budget | **LUCA-000..279** (**280**) |
| Pilot on active.md | **LUCA-000..019** (W0 Meta) |
| Later waves | Grace opens W1+ after W0 gate |

## Pillars

1. **Entity** — Luca Employ 5; AGENTS 15→16; wide MCP/cluster.  
2. **MSSQL native** — AccountingDB insert + report.  
3. **BI path C** — Lightdash agentic after basic; Superset continuity only.

## Owners (pilot W0)

| IDs | Owner | Action |
|-----|-------|--------|
| 000, 009, 014, 019 | Grace | Triage / Suite / LS / W0 wrap |
| 001–002, 013 | Ethan | SPEC + design + authority |
| 003–008, 010–012, 015–018 | Team | Meta awareness / security / runbook / DoD |

## Do not

- Dump all 280 onto active.md — **W0 only**.  
- Create new SQL engines.  
- Ship secrets in repo/Telegram.

## SuiteCRM

`SUITE: YES` on pilot rows · `bash scripts/suitecrm_sync_on_triage.sh --task-id LUCA-000` (batch as available).

SIGNED: Triage (Grace) | LUCA-280 bootstrap | 2026-09-08 | W0 OPEN · budget 280

**Amend 2026-09-08:** Operator teamwork proceed — Grace opened **W1 (LUCA-020..049)** on active.md after W0 bootstrap (000–002 DONE, Suite sync 003+).
