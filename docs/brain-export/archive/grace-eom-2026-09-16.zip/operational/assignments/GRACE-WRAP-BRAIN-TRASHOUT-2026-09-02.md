# Grace wrap — brain trash-out slice 1

**Date:** 2026-09-02  
**Approval:** `approval-8e77bf1be163` (operator destructive + map)  
**Stamp:** [grace_brain_trashout_next.txt](../../governance/grace_brain_trashout_next.txt) `status=0`  
**Collect:** [GRACE-TRASHOUT-COLLECT-2026-09-02.txt](reports/GRACE-TRASHOUT-COLLECT-2026-09-02.txt)

## Did

| Action | Destination |
|--------|-------------|
| Archive closed CONN wave smokes/evidence/cold stubs + `mcp-ops-state` + `mcp-runbook-wave` | **igareosh/hesperia** `docs/brain-export/archive/operational-assignments-conn-closed-2026-09-02.tar.gz` (SHA256 `4c965910…` · tip `5bc3451`) |
| Relocate cold-backup stubs | [projects/conn-local/cold-backup/](../../projects/conn-local/cold-backup/) |
| Relocate wave smokes/evidence | [projects/conn-local/qa/reports/archived-wave-2026-09-02/](../../projects/conn-local/qa/reports/archived-wave-2026-09-02/) |
| Delete brain `__pycache__` | **3925 → 0** |
| Delete brain root `venv/` | **5.1G removed** (policy: no local venv) |

## KEEP in brain

- `operational/assignments/conn-local/` — registers + triage + wraps + README
- ALT-DISK (live PAUSED rows)
- Awareness / Grace notes

## Deferred (not this slice)

- `projects/ops-method` BAN 246 depth-1 — separate Ethan/Grace archive pass
- Full `operational/assignments/` wipe script — not used (would kill live ALT-DISK)

SIGNED: Triage (Grace) | brain trash-out wrap | 2026-09-02
