# Grace triage — LUCA PG mirror (`pg_accounting`) + Lightdash dbt fill

**Date:** 2026-09-08  
**From:** Operator — MS-SQL AccountingDB mirror in **postgres_db** (`pg_*`) to feed Lightdash dbt (“Waiting for data” / CLI deploy)  
**Outcome:** DEPLOYED — project `Luca accounting` (`34d7e509-7633-4993-940e-ac715b1fd645`); report [LUCA-W8b-PG-MIRROR-DEPLOY-2026-09-08.md](reports/luca/LUCA-W8b-PG-MIRROR-DEPLOY-2026-09-08.md)  
**Parent:** [LUCA-280](../../governance/LUCA-280-2026-REGISTER.md) · path C amend

---

## Triage

| Field | Value |
|-------|--------|
| Type | Feature |
| Project | `cursor-repo` |
| Engine | Existing **postgres_db:5432** — DB name **`pg_accounting`** (no new Postgres container) |
| Source SoT | **mssql_db:1433** / **AccountingDB** (unchanged) |
| BI | Lightdash self-host + dbt project → `lightdash deploy` |
| Board IDs | **LUCA-245..252** (W8b) — W9 Superset shifted to **253..259** |

## Why

Lightdash project UI waits on dbt. Native MSSQL warehouse optional later; **PG mirror** is the fast path for CLI `@lightdash/cli@1.237.0` + models.

## Do not

- New SQL engine/sidecar.
- Commit Lightdash PAT / passwords (trustmaster / `/root/.secrets/luca/` only).
- Treat mirror as write SoT — writes stay MSSQL + approval.

## SuiteCRM

`SUITE: YES` on wave rows.

SIGNED: Triage (Grace) | LUCA W8b pg_accounting | 2026-09-08
