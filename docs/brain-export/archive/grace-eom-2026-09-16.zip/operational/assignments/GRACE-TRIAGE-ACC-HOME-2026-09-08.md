# Grace triage — ACC home repo (2026-09-08)

**Asked:** Operator — create folder for https://github.com/Consolidare-Continuum/acc ; push session; forever accounting home until move/abandon; TREE the mix (agentics · ui · msdb · pg · lightdash); Lightdash fork stays fork.

## Did

1. Cloned → `/data/consolidare-continuum/acc` (was `leftover_name` / no local folder).
2. TREE + DEPLOY + HOME stamped in `acc`.
3. Session push: Lightdash pre-aggregate SPEC + MCP client + thinking-map/packet docs under `acc/agentics/` + `acc/docs/sessions/`.
4. Removed tracked `.env` from git index (gitignored); added `.env.example` keys-only.
5. conn `github_accounts.json` → `live` + folder path; brain `agents/luca/ACC-REPO.md`.

## Boundaries

| Path | Role |
|------|------|
| `Consolidare-Continuum/acc` | CC_ accounting product + deploy TREE |
| `biopoleMD/acc` | Biopole client Acc (unchanged) |
| Lightdash upstream fork | Stays fork — use; do not absorb into `acc` |
| Brain `CC_` | Luca entity, MCP launchers, stamps until cutover |

## Next (not blocking)

- Abelard: optional deploy-key Host alias for `acc` (today: `gh` HTTPS push).
- Felix: cutover note when MCP source-of-truth moves fully under `acc/agentics/mcp`.
- Archive `operational/assignments/reports/luca/` over-soft (46) in later trash-out.

## Propagate (2026-09-08) — DONE

Operator: Grace propagate `acc` to accounting awareness surfaces.

| Surface | Update |
|---------|--------|
| `cc_accounting_permanent.txt` | `acc_repo=Consolidare-Continuum/acc` · local path · TREE · Grace card |
| `CC-ACCOUNTING-OPERATOR-AWARENESS.md` | Product home = CC_ `acc`; biopole fence |
| `agents/grace/CC-ACC-REPO-MANAGER.md` | New Lane B card |
| `agents/luca/*` | ACC-REPO, LUCA, SOURCE-MAP, one-pager, rule |
| `AGENTS.md` / `INDEX.md` / SPEC | Product home pointers |
| conn `github_accounts` + `services_catalog` + LIGHTDASH note | live brief + links |
| `library_params.acc_home` | thinking-map registry |
| Lightdash README | product home line |

SIGNED: Grace | ACC home triage + propagate | 2026-09-08
