# Grace triage — conn.local Abelard actions API wave

**Date:** 2026-09-01  
**Trigger:** Operator — Grace AWP; Ethan advise simple robust conn.local command API; Abelard session-wide fast ops; **no alunel/trustmaster** remote command.

## Wave rows

| ID | Owner | Summary |
|----|-------|---------|
| CONN-ACT-00 | Grace | Triage this wave |
| CONN-ACT-01 | Ethan | SPEC — conn actions API policy + forbidden pillars |
| CONN-ACT-02 | Abelard | `actions_catalog.json` + hub `/api/actions` + `/api/action/run` |
| CONN-ACT-03 | Abelard | `scripts/conn-action.sh` + QUICK OPS + UI fast-ops panel |
| CONN-ACT-04 | Abelard | Deploy hub on prichindel + live smoke |

**Policy:** alunel + trustmaster = **hard forbidden** (403, not in catalog). All other registered hosts may receive allowlisted actions only — fixed argv, no shell injection.

SIGNED: Triage (Grace) | conn actions wave | 2026-09-01
