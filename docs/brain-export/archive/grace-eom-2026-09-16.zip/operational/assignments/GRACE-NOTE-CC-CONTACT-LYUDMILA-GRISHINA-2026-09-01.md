# Grace note — CC_ company contact awareness

**Date:** 2026-09-01  
**Source:** Operator → Grace  
**Type:** Contact awareness + CRM todo  
**Status:** **DONE** — **CC-CONT-01** closed 2026-09-02 · SuiteCRM Contact `6e14bdbd-cf85-4d32-9e51-f22887acba95`

## Task

| ID | Owner | Action |
|----|-------|--------|
| **CC-CONT-01** | Grace | Add **Contact** in SuiteCRM (`https://suite.prichindel.local`) — name, mobile, title *Avocat/advocate*; link to CC_ context as appropriate. CRM UI or Grace pass. Ref: [SUITECRM-CRM-UI-TRIAGE-RULE.md](../../governance/SUITECRM-CRM-UI-TRIAGE-RULE.md). |

## Contact

| Field | Value |
|-------|-------|
| **Name** | Людмила Гришина (Lyudmila Grishina) |
| **Mobile** | +373 691 09 383 |
| **Known role** | Avocat / advocate (lawyer) |
| **Relation** | Personal/professional contact — not a CC_ employee or vendor |
| **SuiteCRM Contact id** | `6e14bdbd-cf85-4d32-9e51-f22887acba95` |

## Use

- **Awareness only** — operator-supplied contact for CC_ context.
- **Optional later:** SuiteCRM **Contacts** (company CRM UI add) when useful for legal/good-practices outreach — does not create an active.md row. Ref: [governance/SUITECRM-CRM-UI-TRIAGE-RULE.md](../../governance/SUITECRM-CRM-UI-TRIAGE-RULE.md).
- **Lane A:** do not copy into MinIO dossier unless operator assigns a legal pack.

## Grace action

| Step | When |
|------|------|
| Keep this note | Done |
| **CC-CONT-01** SuiteCRM Contact | **DONE** 2026-09-02 |
| active.md row | **CC-CONT-01** DONE |
| Awareness | [GRACE-AWARENESS-TRIAGE-CLOSED-2026-09-02.md](GRACE-AWARENESS-TRIAGE-CLOSED-2026-09-02.md) |

SIGNED: Triage (Grace) | CC_ contact awareness | 2026-09-02 | CC-CONT-01 closed
