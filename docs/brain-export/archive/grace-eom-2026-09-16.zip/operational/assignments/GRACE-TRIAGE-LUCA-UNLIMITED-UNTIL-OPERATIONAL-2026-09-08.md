# Grace triage — LUCA budget unlimited until operational

**Date:** 2026-09-08  
**From:** Operator — Grace triage; budget unlimited until accounting is operational  
**Outcome:** PROJECT-CREATED  
**Parent:** [cc_accounting_permanent.txt](../../governance/cc_accounting_permanent.txt) · [LUCA-280-2026-REGISTER.md](../../governance/LUCA-280-2026-REGISTER.md)

---

## Triage

| Field | Value |
|-------|--------|
| Type | Policy + Feature |
| Project | `cursor-repo` / CC_ accounting |
| Budget | **Unlimited** until **operational gate** PASS — then Grace re-caps or closes OPS wave |
| Legacy cap | **LUCA-000..279** remains historical register; **does not** block new work |
| New series | **`LUCA-OPS-000`…** (no upper bound while `operational=0`) |
| PM | **Grace** (features above SQL + wave gating) |
| DB operator | **Luca** |
| Infra | **Abelard** |

## Operational gate (Definition of Done)

Accounting is **operational** when **all** are true:

1. **SoT live** — AccountingDB on `mssql_db:1433` with real CoA (chart.xlsx path) and documented post path for Documents/JournalEntries.
2. **Amounts** — at least one posted document/journal path produces non-empty `JournalEntries.Amount` (or accepted staging→process procedure from `biopoleMD/acc`).
3. **Mirror** — `pg_accounting` sync job green (MSSQL→PG); no demo seed.
4. **Lightdash** — explores query CoA + journals; chart with Amount metric returns rows; warehouse host `postgres_db`.
5. **Luca write path** — approval-gated insert/update proven once (number adjustment smoke).
6. **Secrets hygiene** — chat-exposed Lightdash PAT rotated; trustmaster/LOCATION pointers OK.
7. **Permanence** — stamp `cc_accounting_permanent.txt` status=1; service treated like SuiteCRM/mail (Abelard uptime).
8. **Grace wrap** — `operational=1` stamped; budget may be re-capped.

Until then: Grace may open further **LUCA-OPS-*** waves without asking for a new numeric budget.

## Board (pilot OPS wave — active.md)

| ID | Owner | Task |
|----|-------|------|
| **LUCA-OPS-000** | Grace | This triage + unlimited budget stamp |
| **LUCA-OPS-001** | Ethan | Amend SPEC §5 — unlimited until operational gate |
| **LUCA-OPS-002** | Marcus | Sign operational gate checklist (DoD) |
| **LUCA-OPS-003** | Abelard | Finish LUCA-249 PAT rotate + LOCATION |
| **LUCA-OPS-004** | Abelard | Cron/timer MSSQL→`pg_accounting` sync |
| **LUCA-OPS-005** | Felix | Acc post path: document how Documents/JE get Amount (schema/procs) |
| **LUCA-OPS-006** | Luca | Smoke post or import staging→journal (approval-gated) |
| **LUCA-OPS-007** | Luca | Lightdash chart: Amount from journal_entries |
| **LUCA-OPS-008** | Ava | Smoke CoA 671 + Amount chart / empty-honest |
| **LUCA-OPS-009** | Felix | Fix dbt schema doubling `analytics_analytics` → `analytics` |
| **LUCA-OPS-010** | Abelard | malus/conn catalog permanence check Lightdash |
| **LUCA-OPS-011** | Daniel | Write-gate list for Luca number adjustments |
| **LUCA-OPS-012** | Liam | Runbook SCRIPT-RUNBOOK-luca-accounting-operational |
| **LUCA-OPS-013** | Emma | Update LUCA-215 smoke for real CoA (not empty project) |
| **LUCA-OPS-014** | Ethan | Close or supersede LUCA-198 (MSSQL warehouse) via PG path |
| **LUCA-OPS-015** | Colombo | Metric defs: Amount / CoA A|P|AP |
| **LUCA-OPS-016** | Noah | Prompt smoke: Luca adjust number → report |
| **LUCA-OPS-017** | Olivia | Operator one-pager: when accounting is “operational” |
| **LUCA-OPS-018** | Grace | Unpause LUCA-244 only when OPS gate mid-green |
| **LUCA-OPS-019** | Grace | Wrap OPS pilot → open next LUCA-OPS wave or set operational=1 |

## Do not

- Dump unlimited rows onto active.md — Grace gates waves (~20).
- Invent second SQL engine.
- Treat PG mirror as write SoT.
- Bypass Grace for features above SQL.

## SuiteCRM

`SUITE: YES` on OPS rows.

SIGNED: Triage (Grace) | LUCA unlimited until operational | 2026-09-08
