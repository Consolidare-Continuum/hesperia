# Grace triage — CHROMA-1 full decommission mirrors (anywhere → Postgres)

**Date:** 2026-09-01  
**Trigger:** Operator — Grace team AWP; purge live `query_knowledge` / CHROMA-1 ops path; Postgres `pg-knowledge` where required.

**Already done (2026-08-30):** Services stopped; `chroma-knowledge` removed from `mcp-config.json`; seals [chroma1_no_return.txt](../../governance/chroma1_no_return.txt). **This wave:** secondary mirrors + agent-facing docs.

| ID | Owner | Task |
|----|-------|------|
| CHROMA1-DECOM-00 | Grace | Triage + orchestration |
| CHROMA1-DECOM-01 | Ethan | Stamps + governance specs (chroma_books_home, FPF, Gena entity, MCP advise) |
| CHROMA1-DECOM-02 | Daniel | Abelard secondary mirrors (DEVOPS-AI, VERSUS-INCIDENT) |
| CHROMA1-DECOM-03 | Noah | Colombo library schema + source map tails |
| CHROMA1-DECOM-04 | Emma | `.cursor/` README + ingest_staging rule copies |
| CHROMA1-DECOM-05 | Liam | docs/SURVEILLANCE + MCP operational report tombstone |
| CHROMA1-DECOM-06 | Felix | Ingest/chroma scripts RETIRED banners; preflight notes |
| CHROMA1-DECOM-07 | Marcus | conn/workflow grep sanity |
| CHROMA1-DECOM-08 | Sophia | EOD/EOW workflow headers |
| CHROMA1-DECOM-09 | Ava | `context-fitness.sh` + grep residual report |
| CHROMA1-DECOM-10 | Grace | Closeout + active.md DONE |

**Keep historical:** `projects/cc-brain-pg/*`, `cluster/alunel/CHROMA-1.md`, `governance/CHROMA-1-DEFAULT-ENV.md`, archive/ — tombstone only, no delete.

SIGNED: Triage (Grace) | CHROMA-1 mirror purge | 2026-09-01
