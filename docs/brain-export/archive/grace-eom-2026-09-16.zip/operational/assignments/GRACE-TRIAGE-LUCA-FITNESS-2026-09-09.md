# Grace triage — Luca context fitness (2026-09-09)

**Asked:** Operator — Grace triage fixes from Luca operational report (post-build context/tools).

**Evidence:** Luca full run 2026-09-09 — AccountingDB + Lightdash MCP green; context fitness red.

## Problems → rows

| ID | Problem | Owner | DoD |
|----|---------|-------|-----|
| **LUCA-FIT-00** | Triage bootstrap | Grace | This packet + OPEN rows + Suite sync |
| **LUCA-OPS-020** | Postgres brain lag — `query_brain_fts`/`get_doc_by_path`/`list_stamps(luca*)` empty while disk has `agents/luca/**` + Luca stamps | Abelard | `cc-brain-sync` (or equiv) so FTS hits Luca docs; stamps `luca_onboard` / `luca_accounting_operational` / `cc_accounting_permanent` via `get_stamp`/`list_stamps` |
| **LUCA-OPS-021** | Runbook MCP gap — `get_runbook(SCRIPT-RUNBOOK-luca-accountant-session\|operational\|mssql-access)` miss; prichindel clone only had `lightdash-preaggregate-api` | Abelard | `sync-prichindel-mcp-brain` (or pull `/data/workspaces/cursor` to tip with Luca runbooks); `list_runbooks` lists all `scripts/runbooks/workflow/luca/SCRIPT-RUNBOOK-*.md`; `get_runbook` returns session runbook |
| **LUCA-OPS-022** | Session stamp drift — detector `agent_cert=expired` vs live cert valid through 2026-09-10 | Felix | `detect-cursor-session-mode.sh` writes truth matching local/live cert; re-run detector → `agent_cert` not falsely expired |
| **LUCA-OPS-023** | Residual OPS-019 — `lightdash_pat_ui_rotate_recommended` | Abelard | Rotate Lightdash PAT under trustmaster custody; update env; `luca_lightdash_ping` still OK; clear residual on operational stamp/wrap note. Gate: `approval-ef32da8edcdc` (pending record_approval) |
| **LUCA-OPS-024** | conn.local — `mssql_db` in `dbs.json` but thin/missing on services plane (`q=mssql` weak) | Abelard | Dedicated `mssql_db` / AccountingDB service card; `get_conn_services(q=mssql)` returns mssql (not only lightdash) |
| **LUCA-OPS-025** | Smoke after fitness | Ava | `query_brain_fts` Luca hit; `get_doc_by_path(agents/luca/LUCA.md)`; `get_runbook(SCRIPT-RUNBOOK-luca-accountant-session)`; `luca_ping` + `luca_lightdash_ping` |

## Root cause (triage)

prichindel MCP brain clone `/data/workspaces/cursor` at old tip (`b239b8c8`) — **no** `agents/luca/LUCA.md`, only one Luca runbook file. Altitudine tip has Luca operational close (`80bbcb44` class). Brain PG sync + runbook MCP both read from stale/deploy path → dual lag.

## Boundaries

- SoT AccountingDB / Lightdash path stays **operational** — do not reopen LUCA-280 pilot.
- Product home remains `Consolidare-Continuum/acc`.
- No CHROMA-1. Brain = Postgres `cc_brain` sync only.
- PAT values never in chat/Telegram.

## Priority

P1 fitness blockers **020–021** first (unlock Luca context). **022** detector truth. **023** residual (security hygiene). **024** conn grip. **025** smoke closes wave.

## Operator mandate 2026-09-09

**Budget:** `unlimited_until_fixed` — team executes until **LUCA-OPS-020..025** all **DONE**.  
PAT gate: `approval-ef32da8edcdc` **approved**.

SIGNED: Triage (Grace) | LUCA fitness | 2026-09-09 | context+tools
