# GRACE REVISE — DET-RAISE product identity (before grind)

**Date:** 2026-08-12  
**From:** Operator → Grace  
**Ask:** Bot is **not** a DevOps/IT bot. It is a **talky** bot with secretary / manager / sales focus. Those three roles **mostly deny** rather than add. Adjust existing tasking; revise before grind.

## Product identity (locked for this wave)

| Is | Is not |
|----|--------|
| Talky office bot (@BiopoleBot / Detelina face) | DevOps / cluster / IT executor |
| Roles: **secretary · manager · sales** (unknown mix; those three dominate) | Agent that ships code, SSH, deploy, infra |
| Capability posture: **deny-first** (refuse IT/dev/ops actions) | Feature-add / tool sprawl |
| Platform raise on prichindel = **hosting only** (Abelard) | Bot *identity* = Abelard/tersagor SDK twin |

## Tasking adjust (same DET-001..060 IDs)

1. **Ethan DET-002/003** — ratify placement **and** product identity + deny-first boundaries.  
2. **Abelard W1–W4** — keep as **platform** (vault, unit, chroma seat, IRC peer plumbing). No “make it a devops bot.”  
3. **Gena/Felix** — drop IT glue framing; Gena = talk/Planfix **deny contracts**; Felix IRC docs only / no helper sprawl.  
4. **DET-020 / DET-023 / DET-029** — N/A or deny-first (no Prometheus grind, no Python devops helper, no ingest smoke as product goal).  
5. **Ava E2E** — talky path + deny IT; not mesh-executor smoke.  
6. **Runbook/docs** — office talk bot raise, not devops bot raise.

Register: [DET-RAISE-2026-REGISTER.md](../../governance/DET-RAISE-2026-REGISTER.md) (revised).  
Expand packet stays; this revise governs grind.

**Grind gate:** Do **not** grind Abelard runtime until Ethan DET-002/003 absorb identity (or operator GO). Platform vault confirm (DET-009) may proceed.

SIGNED: Triage (Grace) | DET product identity revise | 2026-08-12 | before grind
