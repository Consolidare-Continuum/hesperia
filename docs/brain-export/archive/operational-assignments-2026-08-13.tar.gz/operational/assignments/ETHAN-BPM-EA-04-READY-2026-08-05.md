# BPM-EA-04 READY — expert-artifact rebuild

**Date:** 2026-08-05  
**Spec:** [ETHAN-BPM-EA-01-EXPERT-ARTIFACT-SOT-2026-08-05.md](ETHAN-BPM-EA-01-EXPERT-ARTIFACT-SOT-2026-08-05.md)  
**Impl:** `projects/ops-method/scripts/export_accepted_map.py` + `agv_api.py`  
**Smoke:** [BPM-EA-03-SMOKE.md](../projects/ops-method/BPM-EA-03-SMOKE.md) **PASS**

## Exit criteria

- [x] EA-01 SOT ratified (department-accepted checkout)
- [x] EA-02 live HTML/JSON rebuilt; max-seq filter removed
- [x] EA-03 smoke PASS (n=27, CEO/LEGAL, no false Покупка claim)

**READY** for operator use: http://biopole.prichindel.local/company/CLI-BIOPOLE/expert-artifact

SIGNED: Architecture (Ethan) | BPM-EA-04 | 2026-08-05 | expert-artifact READY
