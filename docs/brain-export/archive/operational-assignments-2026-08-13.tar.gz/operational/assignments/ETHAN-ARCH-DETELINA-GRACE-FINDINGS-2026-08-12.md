# Ethan ARCH — Detelina Grace findings (2026-08-12)

**Trigger:** Operator AWP — Ethan locomotive first, then align Grace Asked items.  
**Grace audit:** ACCEPT with findings on Opus assistant-framed knowledge work (`a6cb3f1`).

## Decisions

| # | Finding | Decision | Owner execute |
|---|---------|----------|---------------|
| 1 | `biopole-50-RU.md` live in locked TG folder but **not in git** | **Commit** into `detelina_agent_brain` — authority must have custody | Cursor (this AWP) |
| 2 | RAG sorted `primary` before distance → knowledge cards buried | **Distance-first** rank; `primary` secondary key only; widen candidate pool (`RAG_CANDIDATE_MULT`) | Cursor (this AWP) |

## Non-goals (this pass)

- DET-036 Ava lounge — remains OPEN; operator redirected AWP off that row.
- Weak embed hit on exact phrase `валовой запас` — embedding/corpus density, not rank; track later if needed.
- Orphan last chunks from blind 1200 splitter — deferred.

## Result

- Live: `detelina-rag` restarted; collection re-ingested (130 chunks, `embed_model` on metas).
- Git: commit with `biopole-50-RU.md` + `rag_server.py` + `ingest_public_agrobiotech.py`.

SIGNED: Team lead (Ethan) | Detelina Grace findings ARCH | 2026-08-12 | locomotive AWP
