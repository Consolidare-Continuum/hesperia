# Grace triage — conn.local agentic API + MCP

**Date:** 2026-08-11  
**CSP:** From: Cursor Context → To: Grace triage | Reason: operator accepted agentic API advice; AWP drain | What changes: active.md rows  

**Project:** `cluster` · **ID prefix:** `CONN-A-`  
**Prior:** CONN-00..02 (hub live)

## Trigger

Operator accepted Cursor advice for fast agent inspections of https://conn.local/ — AWP Gena create/test, Abelard redeploy.

## Rows

| ID | Owner | Scope | Status |
|----|-------|-------|--------|
| **CONN-A-00** | Grace | This triage | DONE |
| **CONN-A-01** | Gena | Hub: `/api/status`, `/api/map?view=compact\|full`, `/api/host/{id}`, schema_version/age_sec/expected_reporter; UI uses full; unit/smoke tests | DONE |
| **CONN-A-02** | Gena | MCP `get_conn_status` / `get_conn_map` on cursor-cluster-snapshot; one-line in `get_cluster_snapshot` | DONE |
| **CONN-A-03** | Abelard | Redeploy hub on prichindel; ensure MCP module on prichindel picks up tools; verify live | DONE |

**Wrap:** [CONN-LOCAL-WRAP-2026-08-11.md](reports/CONN-LOCAL-WRAP-2026-08-11.md) — prichindel MCP smoke OK; IDE reconnect for in-session `get_conn_*`.

## Exit criteria

1. `GET /api/status` tiny problems payload.
2. `GET /api/map?view=compact` ≪ full; UI still full-detail.
3. `GET /api/host/<id>` works; `?detail=1` returns services/connections.
4. MCP tools return plain text/JSON usable by agents; snapshot mentions conn.
5. Live https://conn.local after redeploy.

SIGNED: Triage (Grace) | conn agentic API | 2026-08-11 | CONN-A-00
