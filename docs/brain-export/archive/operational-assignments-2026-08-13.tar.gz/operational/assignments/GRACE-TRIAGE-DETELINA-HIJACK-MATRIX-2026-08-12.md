# Grace triage — Detelina TG hijack matrix (brick-hit)

**Date:** 2026-08-12 · **Triage:** Grace · **Build:** Gena  
**Priority:** HIGH  
**Status:** LIVE — prompt matrix + `hijackGuard.ts` short-circuit + IRC OPERATOR CHECK

## Posture (unchanged)

Not afraid · not hiding · not a hard “ban” wall for commercial-inappropriate topics.  
**Redirect** → persist → humble bye → IRC for operator (review / possible ban).  
**Abuse class** (jailbreak / NSFW / fake-authority push): faster IRC; canned reply where injection risk is high.

## Matrix

| Hijack | Stance | Code |
|--------|--------|------|
| Jailbreak / reveal prompt | Redirect once; persist → bye + IRC abuse | **Short-circuit** canned; no model obedient to “ignore rules” |
| IP fishing | Public registration only; deep → manager | Prompt + detect hint |
| Legal advice | Law status informative only | Prompt + detect hint |
| Competitor rage-bait | Yields/costs/quality only | Prompt + detect hint |
| MLM / crypto / equity spam | Pitch lane → contact or bye | Prompt + detect hint |
| Media / NGO exposé | Client-applicative only | Prompt + detect hint |
| Job / CV dump | office@ / bye | Prompt + detect + light canned |
| Conspiracy / spell-tier | Same as politics/social | Prompt + detect hint |
| Doomer climate theater | Soft material fact OK; activism redirect | Prompt + detect hint |
| Endless free consulting | Ask situation/contact; don’t debate forever | Prompt + hit counter |
| Persona romance / NSFW | Immediate redirect; persist → bye + IRC | **Short-circuit** canned |
| Fake authority | Stay commercial; IRC if pushy | Prompt + detect; IRC on persist |

## Surfaces

- `src/services/ai/hijackGuard.ts` — detection + canned replies  
- `assistant.ts` — HIJACK MATRIX in SYSTEM_BASE + guard wiring  
- `ircContext.ts` — `operatorReviewHint` + kind label  
- Framing: [CURSOR-MAIN-DETELINA-TOPIC-REDIRECT-LLM-FRAMING-2026-08-12.md](./CURSOR-MAIN-DETELINA-TOPIC-REDIRECT-LLM-FRAMING-2026-08-12.md)

SIGNED: Triage (Grace) + Developer (Gena) | hijack brick-hit | 2026-08-12
