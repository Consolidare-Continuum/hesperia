# Detelina public compartment (HARD — Gena / operator)

**Rule:** Public TG content is **not** a semantic/LLM classification.
It is an **SDK folder allowlist** + **dedicated Chroma collection**.

**Folder lock (Gena 2026-08-12):** TG edge may access **exactly one** path:
`/home/biopole-op/repos/detelina_agent_brain/content/assistant-data`
— no siblings, no parent repos, no seat home, no host volumes into the bot. `DETELINA_PUBLIC_ROOT` env must equal that path or be unset (`assert_tg_folder_lock`). Bot compose: **no volumes**; knowledge only via RAG collection `agrobiotech_public`.

**Public / internal border (HARD — Grace wrap 2026-08-12):** TG edge is **public-faced only**. Detelina on volition **must not** cross into internal office capacity — no exceptions (VIP / authority irrelevant). Full office manager / CRM / email / Drive = **IDE + agents only** (Cursor, VS, seat brain). TG = **narrow** medium extension (Telegram + OpenAI `gpt-5.6-sol` + this public RAG). Wrap: [GRACE-WRAP-DETELINA-TG-PUBLIC-EDGE-2026-08-12.md](./GRACE-WRAP-DETELINA-TG-PUBLIC-EDGE-2026-08-12.md).

| | |
|--|--|
| Instance | **CHROMA-BIOPOLE-OP** (`127.0.0.1:8002`) |
| Collection | **`agrobiotech_public`** (dedicated — not shared `knowledge`) |
| Root | `/home/biopole-op/repos/detelina_agent_brain/content/assistant-data` |
| Env | `DETELINA_PUBLIC_ROOT` · `DETELINA_PUBLIC_COLLECTION` |
| Module | `public_compartment.py` |

**Primary (she may scrub end-to-end):** `biopole-50-RU.md`, `basic_process.md`, `микобакт.md`, `ризобакт.md`, **`service_knowhow.md`** (integration / accompaniment / service primacy — Grace HIGH 2026-08-12), `10-связанных-тезисов-агробиотехнологии-Биополе.md`  
**Also OK:** public **https://biopole.md/** site (same or lesser sensitivity) — cite `biopole.md` only, **not** `*.tilda.ws`. Contacts: `https://biopole.md/contacts`. Map: [GRACE-DETELINA-SITE-MAP-BIOPOLE-MD-2026-08-12.md](./GRACE-DETELINA-SITE-MAP-BIOPOLE-MD-2026-08-12.md).  
**Speech hierarchy:** know-how + integration **as service** (365 accompaniment to result) **>** products alone — [GRACE-DETELINA-SERVICE-KNOWHOW-PRIMACY-2026-08-12.md](./GRACE-DETELINA-SERVICE-KNOWHOW-PRIMACY-2026-08-12.md).  

**Supporting in folder:** `for_mission_discussion.md` (mission / worldview — operator wording locked; five variants; pick one), `Обращение.md`, knowledge mechanism files — **supporting only**; TG speech stays primary + public site. Full map: biopoleMD `docs/tg-public-edge/ASSISTANT-DATA-MAP.md`. Rest of Detelina scopes = **out of TG**.

**Speech redirect:** off-scope / office-help asks → science of the product (effects, how-to, quality, eco/bio/real). Never offer Excel/office-admin help on TG.

**Egress (operator 2026-08-12):**
- Discussions → **IRC `#detelina`** context (daily review). **No** cognitive Q&A to Planfix CRM.
- Planfix **contact registration / shadowing** may stay (non-cognitive).
- Sales speech may advise manager follow-up **without** IT/CRM jargon; do not claim CRM filing.

**Drift policy:** if any chunk source is outside the folder → **FAIL** → wipe collection → re-ingest from folder alone.

```bash
/data/chroma/venv/bin/python /data/CLIENTS/biopole/detelina_rag/verify_public_compartment.py
/data/chroma/venv/bin/python /data/CLIENTS/biopole/detelina_rag/verify_public_compartment.py --wipe --reingest
/data/chroma/venv/bin/python /data/CLIENTS/biopole/detelina_rag/ingest_public_agrobiotech.py
```

**Wording:** product/process claims near-verbatim to primary sources (esp. `basic_process.md`).

SIGNED: Developer (Gena) | Detelina public compartment HARD | 2026-08-12
