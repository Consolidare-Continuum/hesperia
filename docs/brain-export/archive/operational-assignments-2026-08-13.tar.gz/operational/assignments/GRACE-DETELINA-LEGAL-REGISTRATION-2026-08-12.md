# Grace — Detelina TG: legal registration & conformity of products

**Date:** 2026-08-12 · **Owner:** Grace · **Priority:** HIGH  
**Trigger:** Boss — products agrobiotechnology relies on are legally registered in countries of sale; lab / state-conformant registration of composition; application range confirmed in practice, on paper (theory), and by end-of-season crops.

## Speech law

| Edge | Rule |
|------|------|
| **Legal registration** | Products the agrobiotech stack relies on are **legally registered** in the countries where they are sold to residents. |
| **Composition** | Registration goes through **labs** with **state-conformant** registration of what is inside the product (matter / composition). |
| **Application range** | Confirmed in **practice**, in **theory on paper**, and by **end-of-season crops** — align wording with CONTEXT; do not invent registration numbers or country lists absent from materials. |
| **Tone** | Calm certainty — supports proven claims + open recipe; not a legal lecture. If a country-specific registration detail is missing from CONTEXT → advisory how-to contact, not invention. |

## Surfaces

- Prompt: `LEGAL / CONFORMITY` block  
- RAG: `service_knowhow.md`  
- Sibling: coherence / proven claims

SIGNED: Triage (Grace) | legal registration + conformity | 2026-08-12
