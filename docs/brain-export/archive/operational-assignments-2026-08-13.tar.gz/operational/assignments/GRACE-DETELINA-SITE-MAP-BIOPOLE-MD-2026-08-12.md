# Grace — Detelina TG public site map (`biopole.md`)

**Date:** 2026-08-12 · **Owner:** Grace (Detelina TG entity manager)  
**Trigger:** Operator — public contact/source URL is **`https://biopole.md`**, **not** `biopole-md.tilda.ws`.  
**Status:** DONE · prompt + settings live on `@BiopoleBot`

## Law

| Cite in TG speech | Do not cite |
|-------------------|-------------|
| `https://biopole.md/` | `https://biopole-md.tilda.ws/` |
| `https://biopole.md/contacts` | any `*.tilda.ws` path |

Platform hosting under the hood is irrelevant to Detelina speech. **Public source host = `biopole.md`.**

## Public map (verified 2026-08-12)

| Path | Role for TG |
|------|-------------|
| `https://biopole.md/` | Company home (RU) |
| `https://biopole.md/md` | Company home (RO) |
| `https://biopole.md/contacts` | **Canonical contacts** — phone, email, address |
| `https://biopole.md/rizobact` | Public Rizobact product page (supporting; primary RAG = folder) |
| `https://biopole.md/mikobact` | Public Micobact product page |
| `https://biopole.md/mycobact-marka-kf` | Micobact KF — supporting only (not primary four) |
| `https://biopole.md/request` | Purchase request form |
| `https://biopole.md/suggestions` | Feedback form |

## Contacts lock (from `/contacts`)

- **Phone:** `+373 691 37 123`
- **Email:** `office@biopole.md`
- **Address:** Chișinău, bd. Dacia 12/2 (prompt: `bd. Dacia, 12/2, MD2043, Chișinău`)
- **Public bot speech:** Biopole consulting / agrobiotech; multi-country (no Moldova-first). Site-true company/legal OK when asked — do not blend into chat (not accountant). Contacts: office@biopole.md · biopole.md. See [GRACE-TRIAGE-DETELINA-MULTI-COUNTRY-LEGAL-SITE-TRUE-2026-08-12.md](./GRACE-TRIAGE-DETELINA-MULTI-COUNTRY-LEGAL-SITE-TRUE-2026-08-12.md).

## Surfaces patched

| Surface | Change |
|---------|--------|
| `telegram_ai_bot_repo/src/services/ai/assistant.ts` | Company site + public-website rules → `biopole.md` / `…/contacts` |
| `telegram_ai_bot_repo/settings/private_en.yaml` | Contact / site strings → `https://biopole.md/` |
| Brain compartment + public-edge wrap | “tilda site” → **`biopole.md` site** |
| `detelina_agent_brain/docs/tg-public-edge/` | This map + mirror notes |

## Relation to RAG

Primary product mastery remains **folder** `assistant-data` (`basic.md`, `basic_process.md`, `микобакт.md`, `ризобакт.md`).  
Site pages = **already-public** company info of **same or lesser** sensitivity — cite URLs on `biopole.md` only; do not invent beyond CONTEXT + this contact lock.

SIGNED: Triage (Grace) | Detelina TG site map biopole.md | 2026-08-12
