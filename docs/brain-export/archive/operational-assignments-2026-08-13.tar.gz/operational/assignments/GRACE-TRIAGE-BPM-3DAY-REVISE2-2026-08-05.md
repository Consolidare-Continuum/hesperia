# Grace triage — 3-day main tasking (REVISE 2)

**Date:** 2026-08-05 · **Revise:** after operator stack lock  
**Id:** BPM-3DAY-01  
**Upstream:** [GRACE-TRIAGE-BPM-PH-3DAY-TEAM-2026-08-05.md](GRACE-TRIAGE-BPM-PH-3DAY-TEAM-2026-08-05.md) (v1)  
**CSP:** From Cursor → Grace | Reason: re-triage 3-day mains on locked local stack

## Ownership

| Role | Who |
|------|-----|
| Product governor / SOT | **CC_** → `Consolidare-Continuum/bpm` |
| Client / method subject | **Biopole** — full product copy allowed on request |
| Not BPM subject | **CC_** itself |
| Workbench runtime | **altitudine** only (this revise) |

## Runtime stack (locked — do not invent LAN/public)

Canon: [RUNTIME-STACK.md](../../projects/ops-method/RUNTIME-STACK.md)

| Piece | Fact |
|-------|------|
| Host | **altitudine** |
| Postgres | `ops-method-pg` · `pgvector/pgvector:pg16` · [`docker/docker-compose.yml`](../../projects/ops-method/docker/docker-compose.yml) |
| Bind | `127.0.0.1:5433` → 5432 · DB/user **`ops_method`** · password **`ops_method_dev`** (local only) |
| Schema | through **`034_subtask_source_state_v0_1.sql`** |
| AGV | [`agv_api.py`](../../projects/ops-method/scripts/agv_api.py) · **`127.0.0.1:8765`** · `ops_method_env.dsn()` |
| UI | [`agv_ui/`](../../projects/ops-method/agv_ui/) · `/` `/full` `/night` `/cta-lab` **`/company-ui`** |
| Shop client | **`CLI-BIOPOLE`** · start [BIOPOLE-SHOP-START.md](../../projects/ops-method/BIOPOLE-SHOP-START.md) |

**Out of Day 1–3 mains:** LAN bind, `biopole.prichindel.local`, public expose, invent-extract, MCP packaging.

```
D1 local shop GREEN → D2 clone-recipe + CC policy → D3 bpm SOT + deliver path → Biopole gets copy on request
```

---

## Day 1 — product face GREEN (local loopback)

**Exit:** Ava smoke stamp PASS on `127.0.0.1:8765` · shop→cart→LLM→agent for `CLI-BIOPOLE`.

| ID | Owner | Status | Main task |
|----|-------|--------|-----------|
| **BPM-PH-01** | Felix | **DONE** | Cart UI restore + LLM promote + `cart_agent_runner.py` |
| **BPM-D1-03** | Felix | **DONE** | Stack docs: README · RUNTIME-STACK · docker README · BIOPOLE-SHOP-START · AGV unit → `127.0.0.1` |
| **BPM-D1-02** | Ava | **DONE · Day1 MAIN** | Smoke shop→cart→dept→promote→agent (`CLI-BIOPOLE`) on **local** AGV — [BPM-D1-02-SMOKE.md](../../projects/ops-method/BPM-D1-02-SMOKE.md) |
| **BPM-D1-04** | Ava | **DONE · Day1** | UI smoke: Корзина + Checkout on `/company-ui` — [BPM-D1-04-SMOKE.md](../../projects/ops-method/BPM-D1-04-SMOKE.md) |

---

## Day 2 — on-demand DB recipe + CC policy

**Exit:** Abelard recipe for **clone of this docker posture** + Ethan policy ratified.  
On-demand DB ≠ new public host — dump/clone `ops_method` from `ops-method-pg` @ `127.0.0.1:5433`, new DB name optional, same compose pattern.

| ID | Owner | Status | Main task |
|----|-------|--------|-----------|
| **BPM-D2-01** | Abelard | **DONE · Day2 MAIN** | [ON-DEMAND-DB-RECIPE.md](../../projects/ops-method/ON-DEMAND-DB-RECIPE.md) |
| **BPM-D2-02** | Ethan | **DONE · Day2 MAIN** | [ETHAN-BPM-CC-SOT-BIOPOLE-FENCE-2026-08-05.md](ETHAN-BPM-CC-SOT-BIOPOLE-FENCE-2026-08-05.md) |
| **BPM-D2-03** | Ava | **DONE · Day2** | [BPM-D2-03-DRYRUN.md](../../projects/ops-method/BPM-D2-03-DRYRUN.md) |
| **BPM-D2-04** | Felix | **DONE · Day2** | Local cart path in [BIOPOLE-SHOP-START.md](../../projects/ops-method/BIOPOLE-SHOP-START.md) |

---

## Day 3 — CC/bpm SOT + Biopole deliver pack

**Exit:** Lane B wire ready; deliver path documented; Ethan HANDOFF-READY when D1–D2 mains GREEN.  
**Operator gate:** `CC_PUSH_PERMISSION=1` for first GitHub seed (not a team row).

| ID | Owner | Status | Main task |
|----|-------|--------|-----------|
| **BPM-D3-01** | Abelard | **DONE · Day3 MAIN** | [BPM-D3-01-CC-BPM-CLONE.md](../../projects/ops-method/BPM-D3-01-CC-BPM-CLONE.md) · mirror stub `scripts/bpm/mirror-ops-method-to-cc-bpm.sh` |
| **BPM-D3-02** | Grace | **DONE · Day3 MAIN** | [CC-BPM-REPO-MANAGER.md](../../agents/grace/CC-BPM-REPO-MANAGER.md) · consolidare-continuum README `bpm/` |
| **BPM-D3-03** | Ethan | **DONE · Day3** | [ETHAN-BPM-LICENSE-NOTICE-CHECKLIST-2026-08-05.md](ETHAN-BPM-LICENSE-NOTICE-CHECKLIST-2026-08-05.md) |
| **BPM-D3-04** | Grace+Gena | **DONE · Day3 MAIN** | [BIOPOLE-DELIVER-PACK.md](../../projects/ops-method/BIOPOLE-DELIVER-PACK.md) (on-request path ready) |
| **BPM-D3-05** | Ethan | **DONE · Day3** | [BPM-HANDOFF-READY.md](BPM-HANDOFF-READY.md) |

---

## Already closed (do not re-open)

BPM-PH-00 · BPM-3DAY-00 · BPM-PH-01..06 · **BPM-D1-03**

---

## Assign digest (mains bold)

- **Ava** — **D1-02**, D1-04, D2-03  
- **Felix** — D2-04 (D1-03 DONE)  
- **Abelard** — **D2-01**, **D3-01**  
- **Ethan** — **D2-02**, D3-03, D3-05  
- **Grace** — **D3-02**; co-**D3-04** with Gena  
- **Gena** — co-**D3-04**

SIGNED: Triage (Grace) | BPM-3DAY-01 revise 2 | 2026-08-05 | stack-locked · 3-day mains
