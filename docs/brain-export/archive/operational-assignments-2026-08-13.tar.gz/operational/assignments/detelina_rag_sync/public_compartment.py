#!/usr/bin/env python3
"""Deterministic public compartment for Detelina TG (CHROMA-BIOPOLE-OP).

HARD RULE (Gena / operator 2026-08-12):
  TG bot edge may access ONE folder only:
    /home/biopole-op/repos/detelina_agent_brain/content/assistant-data
  No other folder — not siblings, not parent repos, not seat home.
  Env DETELINA_PUBLIC_ROOT may only equal that path (or be unset).
  Collection agrobiotech_public = files from that folder alone.
  Drift → wipe collection and re-ingest from that folder alone.
"""
from __future__ import annotations

import os
from pathlib import Path

LAYER = "agrobiotech_public"
COLLECTION = os.environ.get("DETELINA_PUBLIC_COLLECTION", "agrobiotech_public")
EMBED_MODEL = os.environ.get("DETELINA_EMBED_MODEL", "all-MiniLM-L6-v2")

# Locked canon — TG edge folder access ends here.
CANON_PUBLIC_ROOT = Path(
    "/home/biopole-op/repos/detelina_agent_brain/content/assistant-data"
).resolve()


def _locked_public_root() -> Path:
    env = os.environ.get("DETELINA_PUBLIC_ROOT")
    if env is None or not str(env).strip():
        return CANON_PUBLIC_ROOT
    p = Path(env).expanduser().resolve()
    if p != CANON_PUBLIC_ROOT:
        raise RuntimeError(
            "REFUSED (TG public edge): DETELINA_PUBLIC_ROOT must be exactly "
            f"{CANON_PUBLIC_ROOT}, got {p}"
        )
    return CANON_PUBLIC_ROOT


PUBLIC_ROOT = _locked_public_root()

PRIMARY_NAMES = frozenset(
    {
        "biopole-50-RU.md",
        "basic_process.md",
        "service_knowhow.md",
        "10-связанных-тезисов-агробиотехнологии-Биополе.md",
        "микобакт.md",
        "ризобакт.md",
    }
)

# Legacy names removed from live assistant-data (archived 2026-08-13).
SKIP_NAMES = frozenset({"основное.md", "basic.md"})

TEXT_EXT = frozenset({".md", ".txt", ".markdown"})


def is_under_public_root(path: Path | str) -> bool:
    try:
        p = Path(path).resolve()
        p.relative_to(PUBLIC_ROOT)
        return True
    except Exception:
        return False


def assert_no_foreign_folder(path: Path | str) -> Path:
    """Raise if path is not under the single allowed TG folder."""
    p = Path(path).resolve()
    if not is_under_public_root(p):
        raise RuntimeError(
            f"REFUSED (TG public edge): no folder access outside {PUBLIC_ROOT}: {p}"
        )
    return p


def allowed_public_file(path: Path) -> bool:
    if not path.is_file():
        return False
    # Reject symlink escapes (resolve then relative_to).
    if not is_under_public_root(path):
        return False
    # Direct children of PUBLIC_ROOT only — no nested foreign trees.
    try:
        if path.resolve().parent != PUBLIC_ROOT:
            return False
    except OSError:
        return False
    if path.suffix.lower() not in TEXT_EXT:
        return False
    if path.name in SKIP_NAMES:
        return False
    if path.name.startswith("."):
        return False
    name = path.name.lower()
    if "secret" in name or "credential" in name:
        return False
    try:
        if path.stat().st_size > 2_000_000:
            return False
    except OSError:
        return False
    return True


def priority_for(path: Path) -> str:
    return "primary" if path.name in PRIMARY_NAMES else "optional"


def list_public_files() -> list[tuple[Path, str]]:
    """Only list files in PUBLIC_ROOT — never walk parent or sibling folders."""
    if not PUBLIC_ROOT.is_dir():
        return []
    out: list[tuple[Path, str]] = []
    # iterdir only — no rglob, no parent walk
    for p in sorted(PUBLIC_ROOT.iterdir()):
        if allowed_public_file(p):
            out.append((p, priority_for(p)))
    return out


def metadata_source_allowed(source: str | None) -> bool:
    """RAG filter: every chunk source must resolve under PUBLIC_ROOT. No seeds."""
    if not source:
        return False
    return is_under_public_root(source)


def audit_collection_metadatas(metadatas: list[dict | None]) -> list[tuple[str, str]]:
    """Return list of (title, source) that violate the folder-only rule."""
    bad: list[tuple[str, str]] = []
    for m in metadatas:
        m = m or {}
        src = str(m.get("source") or "")
        title = str(m.get("title") or "")
        if not metadata_source_allowed(src):
            bad.append((title, src))
    return bad


def assert_tg_folder_lock() -> dict:
    """Startup / verify: locked root exists and matches canon."""
    if PUBLIC_ROOT != CANON_PUBLIC_ROOT:
        raise RuntimeError(
            f"REFUSED: PUBLIC_ROOT drift {PUBLIC_ROOT} != {CANON_PUBLIC_ROOT}"
        )
    if not PUBLIC_ROOT.is_dir():
        raise RuntimeError(f"REFUSED: PUBLIC_ROOT missing: {PUBLIC_ROOT}")
    return {
        "ok": True,
        "public_root": str(PUBLIC_ROOT),
        "canon": str(CANON_PUBLIC_ROOT),
        "file_count": len(list_public_files()),
    }
