# Grace triage — HES-TFP-OPS100 (TFP operational full wave)

**Date:** 2026-08-10  
**Operator:** Grace triage ~100 tasks — Hesperia TFP operational by **agent + API + teacher + inspector + corpus + structure + dicts A/B**; **core stays core** (params, no expansion beyond available); **module side** keeps wiring and residual.  
**Plan base:** [ETHAN-HESPERIA-TFP-BUNDLE-PLAN-2026-08-10.md](operational/assignments/reports/ETHAN-HESPERIA-TFP-BUNDLE-PLAN-2026-08-10.md)  
**Supersedes:** thin HES-TFP-BUNDLE-* OPEN rows → this OPS100 wave.

## Hold the line

- `:18880` Class A sealed — grain 12 / A_CORE / core params.
- `:18881` Class B TFP — grain 10 / structure / DLCR CAB / interpret+OpenAI / CHROMA-2 retrieve.
- Geometry lock 12/288 always.
- Corpus SoT = **CHROMA-2** `colombo-library` `profile=tfp_ru`.
- No sealed merge of TFP into core.

## Task catalog (HES-TFP-100-00 … 100)

| ID | Owner | Pri | Task |
|----|-------|-----|------|
| **HES-TFP-100-00** | Grace | P0 | Triage OPS100 wave — TFP operational agent+API+teacher+inspector+corpus+structure+dicts; core sealed. |
| **HES-TFP-100-01** | Ethan | P0 | Ratify OPS100 charter: core=:18880 sealed params; module=:18881 Class B wiring only. |
| **HES-TFP-100-02** | Olivia | P0 | Publish dual-face honesty labels (core vs TFP claims) for agents/API docs. |
| **HES-TFP-100-03** | Ethan | P0 | Freeze out-of-scope list: no sealed merge, no medicine framing, geometry 12/288 lock. |
| **HES-TFP-100-04** | Ethan | P0 | Inventory core params/wiki live set — what core keeps vs module must not steal. |
| **HES-TFP-100-05** | Felix | P0 | Assert :18880 analyze_profile=default grain=12 in unit tests + smoke script. |
| **HES-TFP-100-06** | Felix | P0 | Guard: TFP env vars must not leak into hesperia-analyze-dev (:18880) EnvironmentFile. |
| **HES-TFP-100-07** | Abelard | P0 | Verify systemd units: analyze-dev vs analyze-tfp env isolation. |
| **HES-TFP-100-08** | Ava | P0 | Smoke :18880 20 sentences — grain 12, no lexical_resolution TFP claim. |
| **HES-TFP-100-09** | Gena | P0 | Core health contract endpoint check /health pack 12/288. |
| **HES-TFP-100-10** | Sophia | P0 | Runtime awareness: core params remain core wiki/param path. |
| **HES-TFP-100-11** | Noah | P0 | AI-TEST note: core responses must not advertise TFP dict_mode. |
| **HES-TFP-100-12** | Liam | P0 | SCRIPT-RUNBOOK dual-api smoke (core half). |
| **HES-TFP-100-13** | Felix | P0 | Block accidental HESPERIA_ANALYZE_PROFILE=tfp on default shipping entrypoint. |
| **HES-TFP-100-14** | Ethan | P0 | Sign CORE-GUARD: core does not expand beyond available params. |
| **HES-TFP-100-15** | Grace | P0 | Mark CORE-GUARD gate complete when 05–14 green. |
| **HES-TFP-100-16** | Ethan | P0 | Dual-API contract doc finalize (ports, URLs, instructor path). |
| **HES-TFP-100-17** | Felix | P0 | Shared client helper: CoreClient(:18880) + TfpClient(:18881). |
| **HES-TFP-100-18** | Abelard | P0 | Document systemd + ports in cluster/altitudine Hesperia README. |
| **HES-TFP-100-19** | Gena | P0 | HTTP smoke matrix F1/F2 both ports. |
| **HES-TFP-100-20** | Ava | P0 | Compare response meta keys side-by-side (diff sheet). |
| **HES-TFP-100-21** | Olivia | P0 | Public schema note: analyze_profile_meta allowed on both faces. |
| **HES-TFP-100-22** | Felix | P0 | Optional /product/tfp mount OR document-only decision recorded. |
| **HES-TFP-100-23** | Abelard | P0 | Restart/reload playbook for both units without cross-stop. |
| **HES-TFP-100-24** | Emma | P0 | Agent request stub: into Hesperia with face=core|tfp. |
| **HES-TFP-100-25** | Grace | P0 | Dual-API gate check. |
| **HES-TFP-100-26** | Ethan | P0 | Confirm area_structure_tfp + families_structure_tfp as module SoT. |
| **HES-TFP-100-27** | Felix | P0 | Expose structure_map paths on every TFP /health + /analyze meta. |
| **HES-TFP-100-28** | Felix | P0 | Interpret envelope includes structure_map coherence_hints (already/partial — complete). |
| **HES-TFP-100-29** | Colombo | P0 | Validate 10×24 family naming vs structure YAMLs (spot audit). |
| **HES-TFP-100-30** | Gena | P0 | Assert pack_areas=10 pack_families=240 on :18881. |
| **HES-TFP-100-31** | Felix | P0 | Geometry lock fields always present (12/288) on TFP responses. |
| **HES-TFP-100-32** | Ava | P0 | Smoke RU text → dominant area within TFP 10-pack. |
| **HES-TFP-100-33** | Noah | P0 | Params label: module structure ≠ core 12-area names when grain=10. |
| **HES-TFP-100-34** | Colombo | P0 | Short structure map legend for teachers/agents (EN). |
| **HES-TFP-100-35** | Grace | P0 | Structure gate check. |
| **HES-TFP-100-36** | Ethan | P0 | Ratify Dict A/B TFP full_stack = module CAB; core keeps A_CORE curated. |
| **HES-TFP-100-37** | Felix | P0 | Prove DLCR on :18881 loads full dict_a_tfp* merge (no tiny calib). |
| **HES-TFP-100-38** | Felix | P0 | Prove dict_b_tfp* merge + anchors filter healthy. |
| **HES-TFP-100-39** | Felix | P0 | Populate resource_versions in lexical_resolution for provenance. |
| **HES-TFP-100-40** | Gena | P0 | Smoke matched_span_count≥1 on fixed RU probe set (n=10). |
| **HES-TFP-100-41** | Felix | P0 | Schema-safe DLCR keys regression test (no ambiguous weight). |
| **HES-TFP-100-42** | Abelard | P0 | Env: HESPERIA_DLCR_STRUCTURAL=1 only on tfp unit. |
| **HES-TFP-100-43** | Felix | P0 | internal.dlcr capability remains true; default unit still off without env. |
| **HES-TFP-100-44** | Colombo | P0 | Dict CAB honesty note: sidecar ≠ sealed lexicon replace. |
| **HES-TFP-100-45** | Felix | P0 | Optional: TFP-only curated overlay path — propose only, no core edit. |
| **HES-TFP-100-46** | Ava | P0 | Negative smoke: :18880 has no payload.lexical_resolution. |
| **HES-TFP-100-47** | Liam | P0 | Runbook: enable/disable DLCR on TFP lane. |
| **HES-TFP-100-48** | Gena | P0 | Batch-analyze on :18881 with DLCR spot-check. |
| **HES-TFP-100-49** | Felix | P0 | dict_mode=full_stack in meta always when TFP + DLCR. |
| **HES-TFP-100-50** | Grace | P0 | Dicts CAB gate check. |
| **HES-TFP-100-51** | Colombo | P0 | Inventory CHROMA-2 TFP-normalized docs (profile=tfp_ru) — catalog MVP list. |
| **HES-TFP-100-52** | Colombo | P0 | Define corpus_snapshot_id scheme for CHROMA-2 retrieve packs. |
| **HES-TFP-100-53** | Felix | P0 | Library retrieve helper: colombo-library → allowlisted context_packet.retrieval. |
| **HES-TFP-100-54** | Felix | P0 | Auto-attach CHROMA-2 retrieval on TFP interpret when profile=tfp. |
| **HES-TFP-100-55** | Felix | P0 | Agent inquire TFP-bound: same retrieval attach. |
| **HES-TFP-100-56** | Abelard | P0 | Ensure :18881 can reach chroma-2.prichindel.local:8002. |
| **HES-TFP-100-57** | Gena | P0 | Smoke interpret shows retrieval doc_count≥1 from CHROMA-2. |
| **HES-TFP-100-58** | Ava | P0 | Smoke: retrieval docs are TFP-normalized (name/theme check). |
| **HES-TFP-100-59** | Colombo | P0 | Honesty: disk sessions empty ≠ corpus missing; SoT=CHROMA-2. |
| **HES-TFP-100-60** | Felix | P0 | Cap retrieval size under HESPERIA_MAX_CONTEXT_PACKET_BYTES. |
| **HES-TFP-100-61** | Felix | P0 | Fallback to inspector_exports only if CHROMA-2 unreachable. |
| **HES-TFP-100-62** | Noah | P0 | LLM sees retrieval snippets labeled as library evidence. |
| **HES-TFP-100-63** | Liam | P0 | Runbook: TFP retrieve from CHROMA-2. |
| **HES-TFP-100-64** | Emma | P0 | Agent contract: corpus_home=chroma-2_colombo_library. |
| **HES-TFP-100-65** | Grace | P0 | Corpus gate check. |
| **HES-TFP-100-66** | Ethan | P0 | Teacher = interpret mode=llm on TFP face; same for agents. |
| **HES-TFP-100-67** | Abelard | P0 | Confirm CC openai_api_key.txt + openai_key_load on TFP unit. |
| **HES-TFP-100-68** | Felix | P0 | Teacher prompt: ground in engine_trace + retrieval only. |
| **HES-TFP-100-69** | Gena | P0 | Live OpenAI smoke 5 RU texts on :18881. |
| **HES-TFP-100-70** | Ava | P0 | Router decision ALLOW|WARN acceptable; BLOCK empty narrative fails. |
| **HES-TFP-100-71** | Felix | P0 | Record call_status/model/latency in smoke sheet. |
| **HES-TFP-100-72** | Noah | P0 | No invented measurements in teacher narrative (audit sample). |
| **HES-TFP-100-73** | Felix | P0 | KSI/IRC teacher: leave OFF; ticket residual only. |
| **HES-TFP-100-74** | Sophia | P0 | Prod awareness: teacher OpenAI only on TFP unit by default. |
| **HES-TFP-100-75** | Grace | P0 | Teacher gate check. |
| **HES-TFP-100-76** | Ethan | P0 | Inspector = output_views session inspector against TFP lane exports. |
| **HES-TFP-100-77** | Abelard | P0 | Bring output_views service up on altitudine (dev) or PAUSED+reason. |
| **HES-TFP-100-78** | Felix | P0 | Wire inspector data source to TFP analyze/interpret JSON. |
| **HES-TFP-100-79** | Gena | P0 | Smoke open inspector page for one session/export. |
| **HES-TFP-100-80** | Ava | P0 | Verify params pane shows grain/pack/dict_mode/structure. |
| **HES-TFP-100-81** | Felix | P0 | Export path: inspector_exports remain valid sample inputs. |
| **HES-TFP-100-82** | Olivia | P0 | Inspector UX contract delta (if UI changes). |
| **HES-TFP-100-83** | Abelard | P0 | systemd unit or compose for output_views if brought up. |
| **HES-TFP-100-84** | Liam | P0 | Runbook: start inspector for TFP review. |
| **HES-TFP-100-85** | Grace | P0 | Inspector gate check (GO or PAUSED OK for bundle PARTIAL). |
| **HES-TFP-100-86** | Felix | P0 | Bind hesperia-router inquire to TFP (:18881 or profile=tfp). |
| **HES-TFP-100-87** | Abelard | P0 | MCP wrapper env HESPERIA_ENGINE_URL / ANALYZE_PROFILE for TFP sessions. |
| **HES-TFP-100-88** | Felix | P0 | thinking_map_step outcome → context_packet.thinking_map_outcome → interpret. |
| **HES-TFP-100-89** | Felix | P0 | hesperia_fpf_map_step chain documented + one scripted run. |
| **HES-TFP-100-90** | Colombo | P0 | Honesty NEXT: FPF Move ≠ TFP measure. |
| **HES-TFP-100-91** | Ava | P0 | Agent smoke: inquire default=core; inquire tfp=TFP evidence. |
| **HES-TFP-100-92** | Gena | P0 | Agent smoke: map→inquire→interpret TFP LLM. |
| **HES-TFP-100-93** | Emma | P0 | Agent stub: face selector core|tfp mandatory. |
| **HES-TFP-100-94** | Noah | P0 | AI-TEST: agent packet labeled params only. |
| **HES-TFP-100-95** | Grace | P0 | Agentics+FPF gate check. |
| **HES-TFP-100-96** | Felix | P0 | Module misc: testing_params_emit on TFP interpret when HESPERIA_TESTING=1. |
| **HES-TFP-100-97** | Felix | P0 | Module misc: residual tfp.v1 project envelope note (no sealed merge). |
| **HES-TFP-100-98** | Gena | P0 | Full OPS100 smoke matrix (core+TFP+OpenAI+agent+retrieve). |
| **HES-TFP-100-99** | Ava | P0 | Sign OPS100 smoke sheet GO/PARTIAL. |
| **HES-TFP-100-100** | Grace | P0 | Wrap OPS100 digest — TFP operational by agent+API+teacher+inspector+corpus+structure+dicts; core sealed. |

## Owner load

- **Felix**: 30
- **Grace**: 10
- **Gena**: 10
- **Ethan**: 9
- **Abelard**: 9
- **Ava**: 9
- **Colombo**: 7
- **Noah**: 5
- **Liam**: 4
- **Olivia**: 3
- **Emma**: 3
- **Sophia**: 2

## Invoke

`AWP` / `AWP drain` — execute OPEN in ID order within gates; CORE-GUARD before module expansion claims.

SIGNED: Triage (Grace) | HES-TFP-OPS100 | 2026-08-10 | ~100 tasks TFP operational / core sealed
