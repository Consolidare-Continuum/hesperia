# Ethan — OverAPI brain integration (2026-08-07)

**From**: Cursor (operator invoke) → **Ethan** (Chief Architect)  
**Ask**: Integrate [https://overapi.com/](https://overapi.com/) into the brain.  
**Outcome**: **DONE** (pointer-only). No active.md row invented (Grace owns triage).

## Decision

Wire OverAPI as the **default external cheat-sheet index**. Do **not** scrape/mirror the site, do **not** add an OverAPI MCP.

Canon: [governance/OVERAPI-CHEATSHEETS-EXTERNAL-REFERENCE.md](../../governance/OVERAPI-CHEATSHEETS-EXTERNAL-REFERENCE.md)

## Bytes landed

| Path | Change |
|------|--------|
| `governance/OVERAPI-CHEATSHEETS-EXTERNAL-REFERENCE.md` | New policy |
| `governance/DECISION-LOG.md` | Decision row 2026-08-07 |
| `INDEX.md` | Quick entry |
| `team/Ethan/README.md` | Ethan awareness |
| `docs/README.md` | Docs pointer |
| `inbox.md` | Grace awareness (optional CHROMA delta) |

## Grace (optional follow-up)

- Triage inbox row → optional docs-only `SUITE: NO` awareness or Abelard ingest note.  
- Abelard: include the new governance file on next CHROMA-1 delta/whole-repo ingest (file only — not OverAPI HTML).

## Hold the line

Cluster/runbooks/Hesperia wiki remain above OverAPI for process and product truth.

SIGNED: Architecture (Ethan) | OverAPI brain integration | 2026-08-07 | pointer-only
