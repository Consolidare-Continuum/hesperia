# COLOMBO — HWIKI-TRIZ-08 leftovers (novelty / time / meta / thresholds / sparsify)

**Date:** 2026-08-07  
**Owner:** Colombo  
**Wave:** HWIKI-TRIZ-08  
**Upstream:** Coverage-Ledger leftovers · operator chose NEXT item 1

## INVENTORY

| Module | Symbols |
|--------|---------|
| `novelty_engine.py` | density, CC clusters, innovation scores (Louvain already wikified) |
| `time_series.py` | history + persistent_* + EMA |
| `meta_synthesis.py` | `aggregate_cross_domain_signals` |
| `signal_normalization.py` | MIN_* thresholds (+ core math re-exports) |
| `family_weights_sparsify.py` | `build_sparse_family_weights` |

## LANDING

Hub **TRIZ leftovers hub** + 5 symbol pages.

## NEXT (Colombo)

1. Abelard — Chroma `hesperia_wiki` re-ingest when requested  
2. Optional depth — per-field Theory Explainers on TRIZDirectMetrics scalars; Mixing revival decision (separate wave)

SIGNED: Research (Colombo) | Hesperia science wiki | 2026-08-07 | HWIKI-TRIZ-08
