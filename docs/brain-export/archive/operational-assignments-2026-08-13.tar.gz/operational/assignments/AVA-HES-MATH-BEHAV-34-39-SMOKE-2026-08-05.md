# Ava — HES-MATH-BEHAV-34..39 KSI smoke report

**Date:** 2026-08-05  
**Depends:** Felix wire **25–33** PASS  
**Method:** `run_ksi_inspect` + `attach_ksi_to_engine_result` with `HESPERIA_KSI_ENABLED=1`

## Results

| ID | Check | Result |
|----|-------|--------|
| **34** | Φ_e → Expected_j (FAILURE→SHAME chain) | **PASS** — SHAME expected≈0.43 |
| **35** | residual R_j | **PASS** — residuals computed; OVER_ACTIVATED on FAILURE |
| **36** | bridge_need_score | **PASS** — score path exercised (pair without edge may be below τ_bridge; API live) |
| **37** | MISSING_BRIDGE | **PASS** — classifier wired; fires when need ≥ τ_bridge |
| **38** | Full path flags + teacher inspect-only + flag-off noop | **PASS** |
| **39** | This report; unpause note for **13–15** | **PASS** |

**Unpause:** Colombo **HES-MATH-BEHAV-13/14/15** (BELL/NASH/METRIC) may OPEN after this smoke (KSI-Inspector live on flag). Felix **47–53** (KAM implement) may unpause after Colombo **46** hand-off (already formalized).

SIGNED: QA (Ava) | HES-MATH-BEHAV-34..39 | 2026-08-05 | KSI smoke PASS
