# Colombo — HES-MATH-BEHAV-13..15 neighbour formalizations (post-KSI smoke)

**Date:** 2026-08-05  
**Gate:** Ava **39** PASS — KSI-Inspector live under flag  
**CSP:** From: Cursor drain → To: Colombo | Reason: unpause BELL/NASH/METRIC formalize | What changes: formal packets only

---

## 13 — BELL BCI-HP

**Product name:** BCI-HP (path-bundle consistency) — **not** Bell EPR.

| Symbol | Contract |
|--------|----------|
| `path_mass` | Aggregate mass along concept-triplet path bundle |
| `bell_path_residual` | Bundle consistency residual vs observed activations |
| Placement | Optional **before** KSI-Inspector in stack (Ethan ratify §21) |
| v0.1 | Formalize + schema stub; implement in later wave |

**Schema id (proposed):** `hesperia.bci_hp_report.v01`

---

## 14 — NASH field

**Product name:** NASH sealed-path field equilibrium — **not** Guards ΣΓΘ alone.

| Symbol | Contract |
|--------|----------|
| Propagated ↔ corrected area/family equilibrium | Pre-KSI settlement of field vs correction |
| Placement | Optional before KSI-Inspector |
| v0.1 | Formalize; do not conflate with apply-gate |

**Schema id (proposed):** `hesperia.nash_field_report.v01`

---

## 15 — METRIC HesperiaMetric / S_path

| Symbol | Contract |
|--------|----------|
| `HesperiaMetric` | Layered distance registry (`metric_layer` required) |
| `S_path` | Path action / cost along registered metric |
| Placement | Neighbour lens; not Riemannian g_ij as product claim |
| v0.1 | Formalize registry contract; L5 metric residuals already live in pipeline |

**Schema id (proposed):** `hesperia.metric_registry.v01`

---

## NEXT

- Felix/Gena implement only when product consumer named.
- Ethan **67** may note these as formalized-not-wired.

SIGNED: Researcher (Colombo) | HES-MATH-BEHAV-13..15 | 2026-08-05 | BELL·NASH·METRIC formalize
