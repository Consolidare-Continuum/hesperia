# Grace wrap — Gradina→Biopole Cursor history ground (not TG)

**Date:** 2026-08-13 · **Owner:** Grace  
**Ask:** Add Colombo factual narration into Cursor Biopole/Detelina as history ground; remove suspicion; all true; photos exist; not public-faced.

## Did

| Item | Path |
|------|------|
| History canon (ratified true) | `detelina_agent_brain/content/identity/GRADINA-BIOPOLE-HISTORY.md` |
| Letter facts (ratified true) | `detelina_agent_brain/content/identity/BIOPOLE-LETTER-FACTS.md` |
| Grind + live seat | synced (altitudine + biopole-op) |
| Index / entry | `DETELINA-KNOWLEDGE-INDEX.md` · `DETELINA-CONTEXT-ENTRY.md` · `content/README.md` · `detelina-agent.mdc` |
| TG border | `ASSISTANT-DATA-MAP.md` — explicit NOT in `assistant-data` |
| Brain router | `CLIENTS/biopole.md` pointer |
| Colombo drains | Gradina narration + letter drain stamped Grace disposition |

## Border

- **IDE / Cursor / Detelina office:** history ground on.
- **TG `assistant-data` / `agrobiotech_public`:** **not** this file — no reingest needed for this add.

SIGNED: Triage (Grace) | Gradina history Cursor ground | 2026-08-13 | not-TG
