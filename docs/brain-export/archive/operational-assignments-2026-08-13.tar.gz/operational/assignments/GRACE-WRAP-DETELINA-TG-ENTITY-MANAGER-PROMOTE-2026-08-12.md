# Grace wrap — Detelina TG entity manager + biopoleMD promote

**Date:** 2026-08-12 · **Owner:** Grace  
**Status:** DONE

## Declaration

**Grace** is **entity manager** behind Detelina Telegram (**external adjusting**) and **prichindel.com representative** for this Biopole project.

**Deploy** remains administered on the **prichindel cluster** (Abelard) — not via GitHub deploy automation.

## Promoted to biopoleMD

| Repo | Commit / path |
|------|----------------|
| [`biopoleMD/detelina_agent_brain`](https://github.com/biopoleMD/detelina_agent_brain) | `17e729c` — `docs/tg-public-edge/` · `sdk/detelina_rag/` · ROSTER/AGENTS |
| [`biopoleMD/main_data`](https://github.com/biopoleMD/main_data) | `cca1918` — `docs/detelina-tg/` · `detelina_rag/` · `planfix-workspace/telegram_ai_bot` (prompt/handlers/IRC) |
| [`biopoleMD/tersagor-bot`](https://github.com/biopoleMD/tersagor-bot) | `91e1d17` — legacy telegram mirrors + README note |

## Brain pointers

- [agents/grace/DETELINA-TG-ENTITY-MANAGER.md](../../agents/grace/DETELINA-TG-ENTITY-MANAGER.md)  
- [CLIENTS/biopole.md](../../CLIENTS/biopole.md)

SIGNED: Triage (Grace) | Detelina TG entity manager + biopoleMD promote | 2026-08-12
