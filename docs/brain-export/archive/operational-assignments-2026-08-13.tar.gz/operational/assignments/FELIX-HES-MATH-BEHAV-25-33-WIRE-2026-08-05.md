# Felix — HES-MATH-BEHAV-25..33 wire outcome

**Date:** 2026-08-05  
**CSP:** From Cursor drain → To Felix | Reason: wire `core.domain.ksi` | Product: `/data/workspaces/hesperia`  
**Preflight:** Class **A** / Core sealed analyze — package at `core/domain/ksi/` (drain present; not re-scaffolded)  
**Session:** execution_host=altitudine, role=dev_vm_ulim, dev_office=true, connectivity=lan

---

## PASS/FAIL per ID

| ID | Task | Status |
|----|------|--------|
| **25** | Modular-architecture preflight (Class A, `core/domain/ksi`) | **PASS** / DONE-ready |
| **26** | Map sealed `/analyze` hook points | **PASS** — hooks: `sphere/router/engine_analyze_bridge.build_engine_analyze_from_raw`, `runtime/pipeline/analyze.analyze`, `runtime/irc_teacher/analyze_adapter.retrieve` |
| **27** | Wire hybrid_retriever → `core.domain.ksi` entry | **PASS** |
| **28** | Wire phi_trace + `HESPERIA_KSI_*` end-to-end | **PASS** |
| **29** | Align env_guard allowlist with live KSI flags | **PASS** (+ `TEACHER_INSPECT_ONLY`, `TEACHER_PACKET`) |
| **30** | Teacher packet inspect-only (no apply before 0.7.0) | **PASS** — `apply_allowed=false`, `apply_gate=blocked_until_0.7.0` |
| **31** | Gena API/contract review note | **PASS** (draft) — `GENA-HES-MATH-BEHAV-31-REVIEW-NOTES.md`; Gena marks DONE separately |
| **32** | Unit tests for analyze-path KSI wire | **PASS** — `tests/domain/ksi/test_ksi_analyze_wire.py` |
| **33** | Document wire surface + flags (module pointer) | **PASS** — `docs/specs/KSI-WIRE-SURFACE.md` + pointer in `HESPERIA-CORE-MODULES-AND-BRANCHES.md` |

**Blocked:** none for 25–33.

---

## Files changed (product `/data/workspaces/hesperia`)

| Path | Change |
|------|--------|
| `core/domain/ksi/flags.py` | **new** — `HESPERIA_KSI_*` readers |
| `core/domain/ksi/pipeline.py` | **new** — `run_ksi_inspect` / `attach_ksi_to_engine_result` / aliases |
| `core/domain/ksi/__init__.py` | export wire entry + flags |
| `sphere/router/engine_analyze_bridge.py` | attach KSI on sealed envelope (flag-gated) |
| `runtime/pipeline/analyze.py` | attach via `attach_ksi_to_extended` |
| `runtime/irc_teacher/analyze_adapter.py` | hybrid_retriever → same entry |
| `runtime/shipping/env_guard.py` | allowlist `TEACHER_INSPECT_ONLY`, `TEACHER_PACKET` |
| `tests/domain/ksi/test_ksi_analyze_wire.py` | **new** wire tests |
| `docs/specs/KSI-WIRE-SURFACE.md` | **new** surface + flags |
| `docs/specs/HESPERIA-CORE-MODULES-AND-BRANCHES.md` | module pointer |

**Brain (this packet + Gena note):**

| Path |
|------|
| `operational/assignments/FELIX-HES-MATH-BEHAV-25-33-WIRE-2026-08-05.md` |
| `operational/assignments/GENA-HES-MATH-BEHAV-31-REVIEW-NOTES.md` |

**Note:** workspace also has unrelated dirty files from parallel L5/L6 stub work (`core/layers/layer_5.py`, `layer_6.py`, …) — **not** part of this wire; leave for that owner.

---

## Pytest

```text
cd /data/workspaces/hesperia
.venv/bin/python -m pytest tests/domain/ksi/ tests/test_engine_analyze_contract.py -q
# → all passed (domain/ksi including wire tests + engine analyze contract)
```

Domain/ksi suite: **49 passed** (includes wire tests).

---

## Suggested commit message (parent; do not commit unless green + requested)

```
feat(ksi): wire core.domain.ksi into sealed analyze (HES-MATH-BEHAV-25..33)

Additive default-off HESPERIA_KSI_* path: pipeline entry, engine envelope +
hybrid_retriever attach, inspect-only teacher packet, env_guard + wire tests.
```

**Push target:** `igareosh/hesperia` from `/data/workspaces/hesperia`  
**report_done:** parent Cursor after verify — Felix did **not** call report_done / edit active.md.

SIGNED: Developer (Felix) | Claude Code context | 2026-08-05 | HES-MATH-BEHAV-25..33 wire
