# Grace triage — Hesperia math-behaviour bundle (KSI-Inspector · KAM · L5/L6 stubs · KME gate · BELL/NASH/METRIC)

**Date:** 2026-08-04  
**CSP:** From: Colombo research Context → To: Grace triage Context | Reason: operator asked Grace to triage the whole Colombo gap bundle with terminology | What changes: row creation + wave routing; no product code in this packet  

**Project:** `hesperia` · **ID prefix:** `HES-MATH-BEHAV-`  
**Exit stamp:** `MATH-BEHAVIOUR-BUNDLE-READY` — signed 2026-08-05 ([MATH-BEHAVIOUR-BUNDLE-READY-2026-08-05.md](../../governance/MATH-BEHAVIOUR-BUNDLE-READY-2026-08-05.md))

---

## Terminology (mandatory)

| Canonical term | Meaning | Do **not** say |
|----------------|---------|----------------|
| **KSI-Inspector** | Kolmogorov Semantic Inspection — deterministic edge transfer inspector | bare “KSI” alone |
| **KME-KSI-score** | KME derived fingerprint scalar | “KSI” when meaning the inspector |
| **Φ_e** / **Expected_j** / **residual R_j** / **bridge_need_score** | Inspector pipeline | — |
| **KAM (research)** | Kolmogorov–Arnold–Moser-**inspired** semantic perturbation stability lens | “KAM theorem implemented” |
| **SISR** / **KAM_semantic_score** / **kam_verdict** | Apply-gate lens | — |
| **BCI-HP (BELL)** / **NASH field** / **HesperiaMetric (METRIC)** | Neighbour lenses | Bell EPR / bare distance |

**Stack order:** `/analyze` → optional NASH/BCI → KSI-Inspector → Teacher inspect-only → KAM → 0.7.0 sandbox apply.

**Canonical path:** `core/domain/ksi/` (`core.domain.ksi`) — see retriage.

---

## Rows (00–16) — historical wave

See [active.md](../../active.md) `HES-MATH-BEHAV-*`. Parents later decomposed into **20–69** ([TEAM-EXPAND](GRACE-TRIAGE-HESPERIA-MATH-BEHAV-TEAM-EXPAND-2026-08-05.md)).

## Retriage

Claude found KSI at `core/domain/ksi/` — [GRACE-RETRIAGE-HESPERIA-MATH-BEHAV-KSI-FOUND-2026-08-04.md](GRACE-RETRIAGE-HESPERIA-MATH-BEHAV-KSI-FOUND-2026-08-04.md).

SIGNED: Triage (Grace) | Hesperia math-behaviour bundle | 2026-08-04 | HES-MATH-BEHAV-00
