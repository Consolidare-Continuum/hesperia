# Grace triage — CC_ Hesperia science reintegration B0–B3

**Date:** 2026-08-10  
**CSP:** From: Ethan Context → To: Grace triage Context | Reason: operator GO on B0–B3 | What changes: active.md rows + SuiteCRM; no product code in this packet  

**Project:** `hesperia` · **ID prefix:** `HES-SCI-`  
**Ethan packet:** [ETHAN-CC-HESPERIA-SCIENCE-REINTEGRATION-B0-B3-2026-08-10.md](ETHAN-CC-HESPERIA-SCIENCE-REINTEGRATION-B0-B3-2026-08-10.md)

---

## Trigger

Operator accepted Ethan continuation plan waves **B0 B1 B2 B3** after CC 0.7.2 consolidation inspect. OPEN was 0 — new executable path required.

## Rows

| ID | Owner | Scope | Status |
|----|-------|-------|--------|
| **HES-SCI-00** | Grace | This triage + SuiteCRM bootstrap | DONE on write |
| **HES-SCI-B0-01** | Colombo | B0 audit: Felix gaps 1–4 vs live wiki; close residuals only (KSI pages + structure already largely present); list remaining PARTIAL register holes for papering | OPEN |
| **HES-SCI-B0-02** | Cursor | After B0-01: wiki regen + `ingest-hesperia-wiki.sh`; smoke `query_hesperia_wiki` / `query_knowledge(layer=hesperia_wiki)` | OPEN (after B0-01) |
| **HES-SCI-B0-03** | Ethan | Sign B0 exit (wiki truthful for KSI/KAM/BELL/NASH/METRIC + structure hub) | OPEN (after B0-02) |
| **HES-SCI-B1-01** | Felix | B1: implement L6 perturbation series `E(x±ε)` for HES-MATH-BEHAV-55/56/57 PARTIAL slots; keep sealed default off until green | OPEN |
| **HES-SCI-B1-02** | Ava | Smoke L6 ε battery + sealed defaults unchanged when flag off | OPEN (after B1-01) |
| **HES-SCI-B1-03** | Colombo | Wiki PARTIAL→LIVE for closed L6 slots; formula notes for any still deferred | OPEN (after B1-02) |
| **HES-SCI-B1-04** | Ethan | Sign B1 exit | OPEN (after B1-03) |
| **HES-SCI-B2-01** | Felix | B2: wire IPoV/METRIC live emit on `/analyze` (METRIC-22/23 path; flag-gated; sync root `VERSION.yaml` if seal bump) | OPEN |
| **HES-SCI-B2-02** | Ava | Smoke `HESPERIA_METRIC_EMIT` / related flags; public API snapshot discipline | OPEN (after B2-01) |
| **HES-SCI-B2-03** | Colombo | Docs/wiki for live emit contract + ENGINE-ANALYZE-CONTRACT alignment | OPEN (after B2-02) |
| **HES-SCI-B2-04** | Ethan | Sign B2 exit; note promote-ready tip for operator GO (do not promote) | OPEN (after B2-03) |
| **HES-SCI-B3-01** | Colombo | B3: paper draft v0 — methods + systems outlines from `docs/publication/` (EN; RO abstract optional) | OPEN |
| **HES-SCI-B3-02** | Ethan | Novelty claim lock against `NOVELTY_AND_POSITIONING.md` (composition only) | OPEN (after B3-01) |
| **HES-SCI-B3-03** | Grace | File paper draft pointer to CC_ Lane A awareness / MinIO only if operator asks disclosure pack — else mark N/A DONE | OPEN (after B3-02) |
| **HES-SCI-99** | Ethan | Wave closure when B0–B3 signed | OPEN (last) |

**Order:** B0 → B1 → B2 sequential preferred; **B3 may start in parallel** with B0 (docs-only; no sealed code).

## Exit criteria

1. **B0:** Wiki search for KSI-Inspector / KAM battery / BELL·NASH·METRIC is non-empty and structure hub does not claim “unwired” falsely.
2. **B1:** At least gradient + curvature L6 slots move PARTIAL→LIVE under explicit ε path **or** Ethan records permanent deferral with paper-safe wording.
3. **B2:** Flag-gated live IPoV/METRIC emit on `/analyze` with Ava PASS; defaults off preserve sealed contract.
4. **B3:** Draft paper pack exists under brain `operational/assignments/reports/` or Colombo research tree; Ethan signed novelty line.

## Do not

- Fold clinical TFP into sealed core (B4 out of scope).
- Promote to CC without operator `CC_PUSH_PERMISSION` + chat GO.
- Invent formulas to clear PARTIAL without `E(x±ε)`.

SIGNED: Triage (Grace) | CC_ Hesperia science B0–B3 | 2026-08-10 | HES-SCI-00
