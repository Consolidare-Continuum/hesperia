# Ethan — CC_ Hesperia science reintegration B0–B3

**Date:** 2026-08-10  
**CSP:** From: Ethan advisory → To: Grace triage | Reason: operator selected Rail B waves B0 B1 B2 B3 | What changes: architecture-bound wave scope for team rows  

**Project:** `hesperia` (CC_ product grind · science reintegration)  
**Baseline:** CC tip sync `81c26053` / seal **0.7.2** · advisory chat 2026-08-10  

---

## Operator selection

Rail **B0 · B1 · B2 · B3** (not B4 Class-B clinical; not Ask#1 VERSION hygiene as a separate wave — fold VERSION sync into B2 seal if touched).

| Wave | Intent | Primary owners |
|------|--------|----------------|
| **B0** | Wiki register catch-up vs shipped KSI/KAM/IPoV — **verify + residual close** (much already present 2026-08-05) | Colombo → Cursor ingest → Ethan sign |
| **B1** | L6 PARTIAL → LIVE where `39_SPEC` finite differences need `E(x±ε)` (HES-MATH-BEHAV-55/56/57 deferred) | Felix → Ava → Colombo wiki → Ethan |
| **B2** | IPoV / METRIC **live emit wiring** on `/analyze` (code in-tree; 0.7.2 deferred METRIC-22/23 path) | Felix → Ava → Colombo → Ethan |
| **B3** | Paper pack v0 from `docs/publication/` (SCIENCE + NOVELTY + METHODS + VALIDATION + REPRO) | Colombo → Ethan novelty lock |

## Hard lines

- Novelty = **composition** (pre-LLM measure → governed LLM → re-measure). No invented formulas.
- Class A only for B1/B2 sealed paths. Class B TFP stays out of this wave.
- Dev = `igareosh/hesperia`. Promote to `Consolidare-Continuum/hesperia` only on explicit operator GO.
- Paper drafts cite extent taxonomy in `docs/publication/SCIENCE.md`.

## Source pointers

- Felix wiki gaps (B0 source): [FELIX-COLOMBO-WIKI-KSI-KAM-GAPS-SPEC-2026-08-05.md](FELIX-COLOMBO-WIKI-KSI-KAM-GAPS-SPEC-2026-08-05.md)
- Prior Grace wiki triage: [GRACE-TRIAGE-HESPERIA-WIKI-KSI-KAM-GAPS-2026-08-05.md](GRACE-TRIAGE-HESPERIA-WIKI-KSI-KAM-GAPS-2026-08-05.md)
- L6 deferred: [FELIX-HES-MATH-BEHAV-54-62-L5-L6-2026-08-05.md](FELIX-HES-MATH-BEHAV-54-62-L5-L6-2026-08-05.md)
- Release scope: Hesperia `release/v0.7.2/RELEASE_SCOPE.md`
- Publication: Hesperia `docs/publication/{SCIENCE,NOVELTY_AND_POSITIONING,METHODS,VALIDATION_EVIDENCE,REPRODUCIBILITY_PACKAGE}.md`

SIGNED: Governance (Ethan) | CC_ Hesperia science reintegration B0–B3 | 2026-08-10 | operator-selected waves
