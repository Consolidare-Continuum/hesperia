# Grace — BIOPOLE-HOME-01 triage

**Date:** 2026-08-06  
**Status:** LOCAL OFFICE OPERATIONAL · GitHub push partial (main_data only)

## Intent

Hand off Biopole (+ Gradina) operations from prichindel brain bloating to **altitudine `/home/biopole`** with nine **biopoleMD** repos, clean structure, cold move-out cache.

## Rows

| ID | Owner | Task | Status |
|----|-------|------|--------|
| **BIOPOLE-HOME-00** | Grace | Triage + lock 9-repo map + Cursor home path | DONE |
| **BIOPOLE-HOME-01** | Cursor/Abelard | Bootstrap `/home/biopole`, migrate content, workspace | IN_PROGRESS (local DONE; remote push gate) |
| **BIOPOLE-HOME-02** | Operator | Invite **igareosh** Admin on 8 repos **or** paste deploy keys; create **gradina** if missing | OPEN / ASKED |
| **BIOPOLE-HOME-03** | Abelard | `bash /home/biopole/scripts/push-all.sh` after access | BLOCKED on HOME-02 |
| **BIOPOLE-HOME-04** | Grace | Slim brain CLIENTS routers only; cold-cache any further .md exits | OPEN after push |

## Open Cursor

`/home/biopole/biopole.code-workspace` on **altitudine**.

## ASK (operator)

Login **biopoleMD** → for `acc`, `branding-media`, `tersagor-bot`, `superset`, `agroplan`, `agrobiotech-calc`, `detelina_agent_brain`, `gradina`:

1. Create **gradina** if missing  
2. Add **igareosh** as **Admin** collaborator **or** deploy keys from `/home/biopole/docs/DEPLOY-KEYS-PUBLIC.md` (write)

Then agents run `push-all.sh`.

SIGNED: Triage (Grace) | BIOPOLE-HOME-01 | 2026-08-06 | /home/biopole
