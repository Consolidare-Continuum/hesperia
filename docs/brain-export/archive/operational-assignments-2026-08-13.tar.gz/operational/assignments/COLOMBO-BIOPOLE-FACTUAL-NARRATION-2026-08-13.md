---
title: Biopole / Gradina — source drain + factual narration
date: 2026-08-13
tags:
  - biopole
  - gradina
  - colombo
  - awareness
status: drain-inventory
grace_disposition: 2026-08-13 — operator ratified true; Cursor ground = detelina_agent_brain content/identity/GRADINA-BIOPOLE-HISTORY.md (NOT TG public)
sources_fetched:
  - agroexpert-2023-12-26
  - novostipmr-wheat
  - novostipmr-seminar
  - agri-bg-snippets
  - gradina-site
  - letter-2026-outreach
---

# Biopole / Gradina — source drain + factual narration

**Owner:** Colombo · **Date:** 2026-08-13  
**Rule (drain):** Existing facts only. No plans, scenarios, or advice.  
**Grace 2026-08-13:** Operator ratified these events/results as **true** (photos exist). Cursor/Detelina IDE ground: `detelina_agent_brain/content/identity/GRADINA-BIOPOLE-HISTORY.md` — **not** TG `assistant-data`. This file remains the press/site drain inventory.

## Source status

| Source | Fetch | Notes |
|--------|-------|-------|
| [AgroExpert 26 Dec 2023](https://agroexpert.md/rus/partnerskie-materialy/sergey-salabash-biotehnologii-sleduyushchiy-etap-evolyutsii-zemledeliya) | Full body | Primary long interview |
| [NovostiPMR — wheat ~100 c/ha](https://novostipmr.com/ru/content/v-gradine-ozhidayut-urozhaynost-poryadka-100-centnerov-pshenicy-s) | Full body | Dateline: Slobodzeya raion, **7 June** (year not in page body; secondary indexes attribute **2017**) |
| [NovostiPMR — Parkany seminar](https://novostipmr.com/ru/content/v-parkanakh-proshyol-seminar-posvyaschyonnyy-primeneniyu-v-selskom) | Full body | Dateline: Tiraspol, **18 May** (year not in page body; secondary indexes attribute **2018**) |
| [Agri.BG — Biopole costs](https://agri.bg/novini/iskate-li-da-namalite-direktnite-razxodi-za-proizvodstvo-do-5-pieti) | **Snippets only** | Direct HTTP **403**; used search/snippet extract |
| Gradina site (`biopoleMD/gradina`) | Local HTML | about / index / contacts |
| Outreach letter (Sergey Salabash → Marina) | Provided in chat | Present-tense only |

---

## Fact drain by source

### A. Gradina site (local)

- Company **«Градина»** founded **2001**; agricultural production in **Приднестровье**, **с. Парканы**.
- Board chair: **Салабаш Сергей Дмитриевич**.
- Address: **5722, Приднестровье, с. Парканы, ул. Северная, 1**.
- Vineyard **~60 ha**, **20+** grape varieties (Italian, Ukrainian, Bulgarian selection).
- From **2014**: emphasis on seed wheat + resource-saving biotech to minimize mineral fertilizers and chemical plant protection.
- Site notes first Paulownia plantation in Moldova on their enterprise; dump site turned into office/warehouse/repair/vegetable store/weighbridge.

### B. NovostiPMR — wheat (dateline 7 June; year ~2017 by secondary index)

- Farm **«Градина»** (Parkany) expected wheat yield about **100 centners/ha** that year.
- Speaker: board chair / director **Сергей Салабаш**.
- Tech described then as **classical**: disking in two passes; minimal fertilizer (early spring + one **КАС 32** treatment).
- Success attributed to seed quality — **Institute of Plant Physiology and Genetics, NAS of Ukraine** — used actively **3–4 years**, plus timely ops.
- Part of crop for grain sale, part as **seed** for other farms (special plots).
- First sowing that year of large-seed **chickpea** and **lentil** for planting material for Transnistrian producers; firm ready to buy back harvest if growers want; chickpea aimed at eastern export markets (Arab countries, Turkey, Israel); preliminary sale agreement for chickpea as commodity mentioned.
- Interest in gradual **No-Till** stated as intention in that article (**excluded from narration as plan** except as reported interest at that time).
- Market pressure noted: falling grain prices, rising fuel and fertilizer costs, thin margins.

### C. NovostiPMR — Parkany seminar (dateline 18 May; year ~2018 by secondary index)

- Seminar on bacteriological preparations in agriculture, held in **Parkany**; chosen by **Ministry of Agriculture and Natural Resources of PMR**.
- **ООО «Градина»** described as one of **two** farms in the republic actively introducing bacteriological preparations from **ООО «Петербургские биотехнологии»** for several years.
- Speakers: **Александр Попов** (commercial director, Petersburg Biotechnologies); **Федот Цыбульский** (ministry innovation/info dept); **Сергей Салабаш** (Gradina); **Виктор Христин** (agronomist, Dubossary **ООО «Эксимагроплюс»**).
- Field part on Gradina land using the technology.
- Popov: works across Russia; exports to Ukraine, Kazakhstan, EU; adapting preparations to local conditions; effect in Gradina “great”; cooperation with Transnistria continues.
- Preparations named: **«Ризобакт»**, **«Минобакт»** (also spelled Минобакт in article) — Russian development.
- Rizobact: bacteria accumulate N from air; convert soil elements to plant-available forms.
- Khristin claim: Rizobact savings vs traditional feeding ≈ **USD 65/ha** for wheat.
- Salabash: advantage not only money; intensive mineral fertilizer use raises future dose demand and affects soil.
- Minobact: processes stubble/residues toward useful carbon for plants; stubble otherwise plowed or burned — carbon lost as CO₂.
- Then applied at Gradina and Eximagroplus on cereals, legumes, some technical crops; Popov notes Stavropol vegetable use.
- Participants: farm leaders republic-wide; scientists from Agricultural Research Institute and PSU Shevchenko; goal: links between Russian bio-prep producers and Transnistrian scientists.
- Some skepticism among attendees noted; first deputy minister **Олег Дилигул** compared to past innovations that were once doubted.

### D. AgroExpert interview (26 Dec 2023)

- **Сергей Салабаш**, head of **ООО «Градина»** (Parkany); family enterprise since **2001**.
- Early path: potato (~50 ha then irrigated expansion); to **2006–2007** produced **2–3 thousand tonnes** potato/year; then potato less attractive.
- Partner/representative of Kyiv **IFRG** for seed wheat multiplication/commercial push — systemic seed business not built; experience retained.
- Found classical agrochemistry model unstable for budget/logistics/expiry; sought alternative → project **«Биополе»**.
- Intellectual base: innovative solutions/products of **«Петербургские Биотехнологии»** (SPb Agrarian University experts); Gradina built logistics into Moldova incl. Transnistria; distribution + consulting inside country under construction as long-term task.
- Land in use (then): ~**60 ha** perennials (vineyard, orchard, Paulownia) + ~**25 ha** field mainly as demo plots.
- Claims (as stated): fertilizer+fungicide direct spend cut **5–6×**; winter wheat yields **7.5 t/ha** (chickpea predecessor) and **5–6 t/ha** other backgrounds; product cost of production **40–50%** below classical intensive (analyze over ~5 years).
- Combinable with usual insecticides; herbicides allowed but stressful; bioproducts help exit stress.
- Critical mass of Biopole business processes “already formed”; Petersburg Biotechnologies has industrial production base; trial use already successful in a **Bulgarian** farm; comparative demos that season with other bioproducts on a No-Till farm.

### E. Agri.BG (snippets; mid-June tour context; year in snippet synthesis ~2026)

- Title framing: farmers cut direct production costs up to **5×**.
- **«БиоПоле»** = complex resource-saving agrobiotechnology based on live-microorganism biopreparations + whole soil/plant approach.
- Mid-June: tour and plant control on **«БиоПолета»** in **Bulgaria**; for all crops finishing **third vegetative treatment with Rizobact**.
- Team claim: with correct application, from first season can cut direct costs for fertilizers, chemical plant protection, and part of processes **several times**; cereals **30–40%** lower cost of production.
- Stated operating geography in article: **Bulgaria, Romania, Moldova**; seeking commercial representatives (people oriented to regenerative practice, not “just sellers”).

### F. Outreach letter (present-tense slice)

- Author **Сергей Салабаш**; Gradina founded **2001** with father; Biopole project grew from Gradina.
- Markets being developed: **Moldova, Romania, Bulgaria**.
- Operating pressure: organic growth only so far; inbound demand exceeds capacity; seasonal deliveries **2×/year**; new pilots need personal control; founder-led bottleneck.
- Claim set: cereal cost **−30–40%**; vineyard plant-protection cost **−20–30%**; **100%** soil chem-fertilizer substitution possible with their tech; efficacy **4–5×** market analogues; model = accompaniment to financial result + repeat annual sales.
- Channels: Facebook share; Telegram **`t.me/BiopoleBot`**.

---

## Factual narration (as the facts go)

In **2001**, in **Parkany** (Transnistria), the family agricultural enterprise **ООО «Градина»** was founded. Sergey Salabash (Сергей Дмитриевич Салабаш) became its board chair / director. The firm’s public materials describe building an office–warehouse base on a former dump site and, over the years, a vineyard of about **sixty hectares** with more than twenty grape varieties, plus orchard and Paulownia plantings.

Early production emphasized potato — first about fifty hectares, then with irrigation — and by the mid-2000s Gradina was shipping on the order of **two to three thousand tonnes** of potato a year. That line later lost economic appeal. The farm worked with Kyiv’s Institute of Plant Physiology and Genetics on seed wheat; a full regional seed system did not lock in, but seed genetics stayed central to Gradina’s results.

By a **June** season reported by Novosti PMR (indexed as **2017**), Gradina expected wheat near **100 centners per hectare**. Salabash described classical soil work (double disking), light fertilizer use including **КАС 32**, and Ukrainian NAS seed genetics used for three to four years. That same season the farm first sowed large-seed chickpea and lentil for planting material, with export-oriented chickpea talks already underway. Market pressure — soft grain prices, dearer fuel and fertilizer — was already pushing the farm to study lower-cost soil systems.

By a **May** seminar in Parkany (indexed as **2018**), Gradina was publicly one of only **two** Transnistrian farms actively running bacteriological preparations from **ООО «Петербургские биотехнологии»**. The Ministry of Agriculture hosted the day; Petersburg Biotechnologies’ commercial director Alexander Popov joined Salabash and agronomist Viktor Khristin of Dubossary’s **Eximagroplus**. Preparations named on record were **Rizobact** and **Minobact**: nitrogen fixation and nutrient unlocking on one side, stubble-carbon cycling on the other. Khristin put wheat savings versus traditional feeding at about **USD 65/ha**. Popov said Gradina’s effect was strong and that the company’s products already moved to Ukraine, Kazakhstan, and the EU as well as Russia. Some seminar guests remained skeptical; ministry speakers framed that as normal for agricultural innovations.

From that cooperation Gradina’s story and the brand **«Биополе» / «БиоПоле»** fused: Petersburg Biotechnologies as product and know-how base; Gradina as practicing farm, logistics into Moldova including Transnistria, and field demonstration. Gradina’s own site marks **2014** as the turn toward seed wheat plus resource-saving biotech to cut mineral fertilizers and chemical plant protection.

In the **December 2023** AgroExpert interview, Salabash stated the farm then held about **60 ha** of perennials and about **25 ha** of field used mainly as demo. He reported fertilizer-and-fungicide cash spend cut **five to six times**, wheat yields of **7.5 t/ha** after chickpea and **5–6 t/ha** on other backgrounds, and product cost of production **40–50%** below classical intensive practice when averaged over years. He said Biopole’s critical business processes were already in place, that industrial production capacity existed at Petersburg Biotechnologies, and that trial use in **Bulgaria** had already succeeded, with further comparative demos underway.

An **Agri.BG** piece (snippet extract; full page blocked 403) places **БиоПоле** as a complex live-microorganism system already working in **Bulgaria, Romania, and Moldova**. It reports a mid-June plant-control tour of Bulgarian “Biopole fields,” with crops finishing a **third vegetative Rizobact** treatment, and repeats the cost framing: direct costs cut several times from the first season when applied correctly, and **30–40%** lower cereal cost of production. The same piece says the team was seeking commercial representatives in that geography.

Salabash’s later outreach letter restates the same chain without adding a new origin story: Gradina (2001) → Biopole project; markets **Moldova, Romania, Bulgaria**; public press links matching the articles above; Telegram **@BiopoleBot**. Present operating facts in that letter are capacity strain (inbound demand above ops), **twice-yearly** seasonal deliveries, pilots needing personal control, and a founder-led bottleneck. Performance numbers in the letter (cereal **−30–40%**, vineyard plant-protection **−20–30%**, **100%** soil chem-fertilizer substitution, **4–5×** efficacy vs analogues) sit in the same claim class as the press figures — attributed to the project, not independently audited in this drain.

**What this narration does not assert:** equity or tokenization paths, IT-platform completion, horizontal/game-team design, mentorship outcomes, or any future commitment beyond what the sources already recorded as done or then underway.

---

## Performance register (operator-ratified true — see Gradina history ground)

| Fact | Where said |
|------|------------|
| Direct fertilizer+fungicide spend −5–6× | AgroExpert 2023 |
| Direct costs up to −5× / “several times” from season one | Agri.BG; practice |
| Cereal cost of production −30–40% | Letter; Agri.BG |
| Product cost −40–50% vs classical intensive | AgroExpert 2023 |
| Vineyard plant-protection cost −20–30% | Letter |
| Rizobact ≈ USD 65/ha wheat savings | NovostiPMR seminar (Khristin) |
| 100% substitution of all soil chem fertilizers | Letter / practice |
| Efficacy 4–5× market analogues | Letter / practice |
| Expected wheat ~100 c/ha (that season) | NovostiPMR wheat |

**Cursor SOT (internal):** `detelina_agent_brain/content/identity/GRADINA-BIOPOLE-HISTORY.md`

---

SIGNED: Researcher (Colombo) | Biopole source drain + factual narration | 2026-08-13 | drain-inventory  
SIGNED: Triage (Grace) | Gradina history → Cursor Detelina identity (not TG) | 2026-08-13 | operator-ratified-true
