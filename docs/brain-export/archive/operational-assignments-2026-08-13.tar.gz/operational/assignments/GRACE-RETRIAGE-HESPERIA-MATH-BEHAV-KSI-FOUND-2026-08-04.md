# Grace retriage — HES-MATH-BEHAV after Claude found KSI

**Date:** 2026-08-04 (late)  
**CSP:** From: Felix/Claude Context → To: Grace triage Context | Reason: operator — Claude finished and found KSI; retriage wave | What changes: row status + remaining scope; path correction  
**Parent:** [GRACE-TRIAGE-HESPERIA-MATH-BEHAVIOUR-BUNDLE-2026-08-04.md](GRACE-TRIAGE-HESPERIA-MATH-BEHAVIOUR-BUNDLE-2026-08-04.md)

---

## Finding

| Was assumed | Actual |
|-------------|--------|
| `hesperia/ksi/` missing → full W1–W3 revive | **KSI-Inspector** at **`core/domain/ksi/`** |
| H62 path string was lookup key | Wrong path — false “absent” |

**Evidence:** drain commit `7056953c`; modules `phi_e`, `expected_j`, `bridge`, `mirror`, `bundle`, `gate`, `teacher`, …; tests `tests/domain/ksi/`.

**Remaining gap (closed 2026-08-05):** wire + smoke on sealed analyze path — Felix **25–33**, Ava **34–39**.

## Row decisions

| ID | Ruling |
|----|--------|
| **17** | DONE — this retriage |
| **02–04** | DONE — package present |
| **05–06** | Retargeted to wire+smoke (later expand **25–39**) |

SIGNED: Triage (Grace) | HES-MATH-BEHAV retriage after Claude found KSI | 2026-08-04 | HES-MATH-BEHAV-17
