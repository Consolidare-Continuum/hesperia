# Gena — TG edge folder lock (DONE)

**Date:** 2026-08-12 · **Owner:** Gena  
**Ask:** No other folder access for TG bot edge other than  
`/home/biopole-op/repos/detelina_agent_brain/content/assistant-data`

## Programmed

| Guard | Behaviour |
|-------|-----------|
| `CANON_PUBLIC_ROOT` | Hardcoded absolute path |
| `DETELINA_PUBLIC_ROOT` env | Must equal canon or unset — else **REFUSED** at import |
| `list_public_files` | `iterdir` of that folder only — no rglob / parent walk |
| Symlink escape | `resolve()` + `relative_to` / parent must be PUBLIC_ROOT |
| RAG | Filters every chunk `source` via `metadata_source_allowed`; startup `assert_tg_folder_lock` |
| Ingest / verify | Lock assert before work |
| Bot compose | **No volumes**; env pins `DETELINA_PUBLIC_ROOT` + collection |

## Verify

```text
PASS folder_only · public_root=/home/biopole-op/repos/detelina_agent_brain/content/assistant-data
health.folder_lock = same path
foreign DETELINA_PUBLIC_ROOT=/tmp → import RuntimeError REFUSED
mounts=[]
```

Live code: `/data/CLIENTS/biopole/detelina_rag/public_compartment.py`  
Brain sync copy: `operational/assignments/detelina_rag_sync/public_compartment.py`  
Canon: [DETELINA-PUBLIC-COMPARTMENT.md](./DETELINA-PUBLIC-COMPARTMENT.md)

SIGNED: Developer (Gena) | TG folder lock one-path | 2026-08-12
