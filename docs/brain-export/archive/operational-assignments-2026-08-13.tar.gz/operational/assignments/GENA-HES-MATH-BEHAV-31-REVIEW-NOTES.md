# Gena — HES-MATH-BEHAV-31 review notes (API / contract)

**Date:** 2026-08-05  
**From:** Felix (wire 25–33)  
**To:** Gena — API/contract review  
**Scope:** Additive `ksi` block on sealed engine `/analyze` envelope when `HESPERIA_KSI_ENABLED=1`

---

## Contract delta (additive)

When flag **off** (default): envelope **unchanged** — no `ksi` key.

When flag **on**, sealed engine envelope (`run_engine_analyze` / `build_engine_analyze_from_raw`) may include:

| Key | Type | Notes |
|-----|------|-------|
| `ksi` | object | KSI-Inspector bundle §15 |
| `ksi.version` | `"0.1"` | |
| `ksi.concepts` | map → `{expected, observed, residual, incident}` | |
| `ksi.areas` | map (same shape) | |
| `ksi.incidents` | array | deterministic classifiers |
| `ksi.missing_bridges` | array | |
| `ksi.phi_trace` | object \| null | only if `HESPERIA_KSI_PHI_TRACE=1` |
| `ksi.teacher_packet` | object \| omitted | inspect-only; `apply_allowed=false` |
| `temp_relation_overlay` | array (optional) | echoed when overlay passed into builder |

Public FastAPI `POST /hesperia/analyze` still goes through `project_to_public` — **confirm** whether `ksi` must stay engine-sidecar only vs public schema allowlist.

---

## Ask Gena

1. Should `ksi` appear on **public** `/hesperia/analyze` schema, or only on engine contract / IRC hybrid_retriever `context_package`?
2. Any OpenAPI / Java client impact if `temp_relation_overlay` is echoed on the envelope?
3. Teacher packet fields (`apply_gate`, `mode`) — freeze names before IRC Teacher consumers?

---

## Pointers

- Wire surface: `docs/specs/KSI-WIRE-SURFACE.md` (product repo)
- Entry: `core.domain.ksi.pipeline.attach_ksi_to_engine_result`
- Flags allowlist: `runtime/shipping/env_guard.py`

SIGNED: Developer (Felix) | Claude Code context | 2026-08-05 | GENA-31 review draft
