# Grace — Detelina TG context routing (office@ vs user contact)

**Date:** 2026-08-12 · **Owner:** Grace (Detelina TG entity manager)  
**Status:** LIVE in prompt + lead store  
**Trigger:** Operator — for obvious/in-scope things Detelina may give `office@biopole.md`; for out-of-context proposals / unrelated tasks be cunning: collect **their** contact, store it, then say a manager will address it.

## Context split (speech)

| Case | Detelina does |
|------|----------------|
| **In-scope / obvious** (Micobact, Rizobact, soil, farm coop, product how-to, buying interest) | Answer from CONTEXT. May freely give public Biopole contacts: `office@biopole.md`, `+373 691 37 123`, `https://biopole.md/contacts`. Plain text — no Markdown stars. |
| **Out-of-context / unrelated** (service proposals, brand-dev plans, partner pitches, IT offers, anything not product sales consultation) | Do **not** open the topic. Do **not** evaluate the proposal. Softly close the channel purpose. **Cunning:** ask the user for **their** email (or phone). When they give a more-or-less real email/phone/contact → **store** it → say she **noted** the contact and a **manager will address** this as soon as they can. Keep inviting product/sales questions here. |

## Anti-patterns

- Dumping only `office@biopole.md` and ending the thread for unrelated proposals (too blunt / loses the lead).
- Discussing internal brand plans or evaluating third-party service proposals on TG.
- Claiming CRM filing / Planfix / tickets.
- Markdown `**bold**` or `*.tilda.ws` URLs.

## Store

Runtime file (same volume as chat history):  
`/data/CLIENTS/biopole/detelina_tg_runtime/lead_contacts.json` → `/app/data/lead_contacts.json`  
Fields: chatId, email?, phone?, raw, notedAt, telegramUser?  
IRC `#detelina` still gets discussion context for daily review.

## Surfaces

- Prompt: `assistant.ts` SYSTEM_BASE — CONTEXT ROUTING block  
- Code: `leadContactStore.ts` + capture in `runAssistantForText`  
- Wrap sibling: [GRACE-WRAP-DETELINA-TG-PUBLIC-EDGE-2026-08-12.md](./GRACE-WRAP-DETELINA-TG-PUBLIC-EDGE-2026-08-12.md)

SIGNED: Triage (Grace) | Detelina TG context routing | 2026-08-12
