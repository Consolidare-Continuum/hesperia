# Grace triage — inbox New 2026-08-06 (Detelina path · Aurel defects · cluster alerts)

**Date:** 2026-08-07  
**From:** Cursor main EOM → operator direct  
**CSP:** From Cursor | To Grace | Reason: inbox New → active.md | What changes: triage authority; row creation allowed

## Inbox sources

1. **2026-08-06 Detelina** — client-local `DET-AUDIT-2026-08-06` on `biopoleMD/detelina_agent_brain/active.md` vs central workflow API task-not-found / zero OPEN. Runtime work complete (n8n/MCP/PRs); path visibility split remains.
2. **2026-08-06 Aurel** — three platform defects after Biopole consolidation pass: (a) Codex session missing `query_knowledge`; (b) runbook MCP misses mandatory ids; (c) cluster preflight: mediamaster VmOffline, certbot failed, librarymaster host-key on LRP.

Related awareness (already filed, not re-opened as duplicate permanence): [GRACE-TRIAGE-DETELINA-PERMANENCE-2026-08-06.md](GRACE-TRIAGE-DETELINA-PERMANENCE-2026-08-06.md).

## Triage outcome → active.md

| ID | Owner | Intent |
|----|-------|--------|
| **INBOX-DET-01** | Ethan | Spec/policy: client-local boards vs central `active.md` / workflow API (single tasking path) |
| **INBOX-DET-02** | Abelard | Wire Detelina/client brain so central heartbeat sees or formally excludes client-local IDs |
| **INBOX-AUR-01** | Abelard | Codex/Aurel MCP: ensure `query_knowledge` (chroma-knowledge) in Aurel/Codex MCP config on office hosts |
| **INBOX-AUR-02** | Felix | Runbook MCP: resolve mandatory ids (`mcp-chroma-session`, `cluster-proceed-preflight`, `operational-deliverables`, `escalate-grace`, `workflow-proceed-gates`) or fix registry |
| **INBOX-AUR-03** | Abelard | Cluster alerts from Aurel pass: mediamaster VmOffline · certbot.service · librarymaster LRP host-key |

## Abelard live notes (same session)

- **mediamaster** VMID 101 was **stopped** → `qm start 101` → SSH OK (`mediamaster` up). Alert should clear after probe `for: 5m`.
- **BiopoleUnreachable**: Tailscale peer `100.92.158.21` **offline ~1d** — **client-owned** host (not LAN `.65`). Not altitudine:8765. No agent power on remote client without operator.
- **CHROMA-1 books+fpf restore**: separate P0 rows **CHROMA1-RESTORE-01/02** (this wave).

## Inbox footers

Apply on `inbox.md` rows 2026-08-06 Detelina + Aurel:

`**Triage outcome**: PROJECT-CREATED — 2026-08-07 — this packet; rows INBOX-DET-* / INBOX-AUR-* on active.md`

SIGNED: Triage (Grace) | inbox New Detelina+Aurel | 2026-08-07 | operator EOM ask
