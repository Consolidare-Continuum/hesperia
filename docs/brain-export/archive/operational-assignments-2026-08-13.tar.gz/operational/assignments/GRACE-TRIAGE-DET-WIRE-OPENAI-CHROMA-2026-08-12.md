# Grace triage — Detelina TG wire today (OpenAI + CHROMA-BIOPOLE-OP + agrotech)

**Date:** 2026-08-12 · **Owner:** Grace  
**Trigger:** operator — wire OpenAI sol model + CHROMA-BIOPOLE-OP SDK + agrotech layer; deploy Detelina today; use Tersagor SDK patterns (not Assistants API).

## Product

| | |
|--|--|
| **Face** | @BiopoleBot / Detelina — talky TG assistant |
| **LLM** | OpenAI API via **Responses/Chat Completions** (Assistants discontinued path) — model from `OPENAI_MODEL` (default **gpt-5.4-mini** / sol-line; override in `.env`) |
| **Memory** | **CHROMA-BIOPOLE-OP** `127.0.0.1:8002` collection `knowledge` |
| **Layer** | `layer=agrotech` (AGROPLAN + office science KB) |
| **SDK borrow** | Tersagor `ChromaAdapter` / `openai_raw_adapter` **pattern only** — not tersagor nick/identity |

## Rows

| ID | Owner | Task |
|----|-------|------|
| **DET-WIRE-00** | Grace | This triage |
| **DET-WIRE-01** | Abelard/Felix | Ingest agrotech into CHROMA-BIOPOLE-OP |
| **DET-WIRE-02** | Felix | RAG sidecar + replace Assistants in TG bot |
| **DET-WIRE-03** | Abelard | Compose env CHROMA/OPENAI_MODEL; deploy recreate |
| **DET-WIRE-04** | Ava | Smoke: health + one RAG ask (agrotech) |
| **DET-WIRE-05** | Ethan | Sign DETELINA-TG-WIRE READY (optional same-day) |

## Hold

Deny-first secretary/manager/sales. No CHROMA-1. No Assistants dependency.

SIGNED: Triage (Grace) | DET-WIRE | 2026-08-12
