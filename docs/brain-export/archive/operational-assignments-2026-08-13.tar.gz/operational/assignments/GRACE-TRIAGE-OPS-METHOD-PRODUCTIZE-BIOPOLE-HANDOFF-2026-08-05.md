# Grace triage — Ops Method productize → Biopole handoff (few days)

**Date:** 2026-08-05  
**Trigger:** Operator — Cursor go; productize so Biopole can shop cards → cart → LLM → agentize in a few days.  
**CSP:** From Cursor → Grace (triage) → Felix/Ava/Abelard/Ethan execution.

## Ownership law (operator lock)

| Role | Who |
|------|-----|
| Product governor / SOT | **CC_** → `Consolidare-Continuum/bpm` (empty shell → seed) |
| Client / method subject | **Biopole** — may receive **full** product + on-demand DB |
| Not BPM subject | CC_ itself |
| Workbench | `projects/ops-method/` |

One-way fence: Biopole dirt does not enter CC/bpm SOT. Full product **out** to Biopole is allowed.

## Day-0 audit result (Cursor 2026-08-05)

**Finding:** Shop/cart stack was **discarded** into `git stash@{0}` (“clear-tree-2026-08-05”) while AGV kept running with catalog in memory. Disk lacked `company.html`, truncated `agv_api.py`, schemas 027–034, seed/LLM scripts.

**Did:** Restored from stash; restarted AGV; seeded/confirmed `CLI-BIOPOLE`; smoked shop→cart→inspect.

| Check | Result |
|-------|--------|
| `/catalog/slots` · `/catalog/todos` · inspect | PASS |
| `POST /catalog/add-to-cart` (`CLI-BIOPOLE`) | PASS |
| `/company-ui` (68750 B, loadCart present) | PASS |
| `/company/CLI-BIOPOLE/stats` · todos | PASS (cart populated) |
| `POST …/promote` without departments | **409** `no_departments_assigned` — expected gate |
| `cta_agent_runner.py --n 1` | PASS |
| AGV DSN | `ops_method` · `lab/status.operational=false` (flag; shop works on this DB) |
| Wrong client id `BIOPOLE` | FK fail — correct id **`CLI-BIOPOLE`** |

**Gap list (handoff blockers):**

1. **UI polish** — verify cart button opens cart; shop/checkout modes; Biopole start URL on LAN (`0.0.0.0:8765` / `biopole.prichindel.local`).
2. **LLM path** — document/smoke: assign dept → promote → accept; bulk promote; no mandatory taxonomy engine.
3. **Agentize** — cart-scoped agent loop (today: scheme CTA runner + `/tasks/*`; wire cart→agent explicitly if missing).
4. **Lab vs prod DSN** — decide handoff DB (`ops_method` vs `ops_method_lab` clone); on-demand DB recipe.
5. **CC/bpm SOT** — Lane B wire + gated first push.
6. **Deliver pack** — full tree + DB into Biopole Cursor workspace on request.
7. **Docs** — README freeze drift; restore SCOPE-CARD + PROMOTE stamps to tree (done Day 0).

## Rows (active.md)

| ID | Owner | Task |
|----|-------|------|
| **BPM-PH-00** | Grace | This triage |
| **BPM-PH-01** | Felix | Handoff blockers — cart UI + LLM promote path + cart-scoped agentize |
| **BPM-PH-02** | Ava | Smoke shop→cart→LLM→agent GREEN (CLI-BIOPOLE) |
| **BPM-PH-03** | Abelard | On-demand DB recipe + AGV service DSN/hand-off bind |
| **BPM-PH-04** | Ethan | Policy: CC/bpm SOT + Biopole full-copy delivery |
| **BPM-PH-05** | Grace + Abelard | Wire `Consolidare-Continuum/bpm` + gated promote (operator `CC_PUSH_PERMISSION`) |
| **BPM-PH-06** | Grace + Gena | Biopole deliver pack path (full product into client / main_data on request) |

## Exit (few-day bar)

Biopole can open company-ui, shop catalog into cart, LLM/promote cards, agentize; receive full copy + on-demand DB; CC/bpm seeded as SOT.

SIGNED: Triage (Grace) | BPM productize Biopole handoff | 2026-08-05 | ops-method · CC_
