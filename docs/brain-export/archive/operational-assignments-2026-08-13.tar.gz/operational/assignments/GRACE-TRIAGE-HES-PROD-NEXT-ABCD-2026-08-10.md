# Grace triage — HES-PROD-NEXT Waves A–D (~40 OPEN)

**Date:** 2026-08-10  
**CSP:** From: Ethan plan → To: Grace triage | Reason: operator selected A B C D; budget ~35–45 | What changes: active.md rows + SuiteCRM; no code  

**Project:** `hesperia` · **ID prefix:** `HES-PROD-`  
**Ethan packet:** [ETHAN-CC-HESPERIA-PROD-INSPECT-NEXT-RUN-2026-08-10.md](ETHAN-CC-HESPERIA-PROD-INSPECT-NEXT-RUN-2026-08-10.md)  
**CC baseline:** `473a3bb` / 0.7.2  

**Budget:** **40 OPEN** + **HES-PROD-00** DONE triage (=41 rows). Cadence **A → B → C**; **D** after C (or parallel advise-only where noted).  
**Hard:** defaults stay off · no CC promote without **new** operator GO · no silent sealed diacritic “fix”.

---

## Wave A — Safety / honesty (parallel)

| ID | Owner | Task | Status |
|----|-------|------|--------|
| **HES-PROD-00** | Grace | This triage + SuiteCRM bootstrap | DONE on write |
| **HES-PROD-A01** | Ethan | Ratify gap list G1–G11 + WBS boundary for HES-PROD-NEXT | OPEN |
| **HES-PROD-A02** | Daniel | Security advise: KSI/KAM/METRIC/L6ε defaults-off; exposure if flipped | OPEN |
| **HES-PROD-A03** | Daniel | Security HOLD note on `agentic_bridge` until Wave D decision | OPEN |
| **HES-PROD-A04** | Ava | Diacritic HDT → written acceptance criteria (no sealed edit) | OPEN |
| **HES-PROD-A05** | Ava | Map HDT finding to sealed lexical path + RO acceptance bar | OPEN |
| **HES-PROD-A06** | Olivia | Confirm Wave A needs zero `/analyze` contract change | OPEN |
| **HES-PROD-A07** | Sophia | Runtime awareness: prod flags remain off during A–C | OPEN |
| **HES-PROD-A08** | Ethan | Sign Wave A exit | OPEN |

## Wave B — Producer + METRIC-24/25 (sequential core)

| ID | Owner | Task | Status |
|----|-------|------|--------|
| **HES-PROD-B01** | Felix | Design `/analyze` L6 perturbation producer (flag-gated; Class A) | OPEN (after A08) |
| **HES-PROD-B02** | Felix | Implement producer; sealed default off | OPEN (after B01) |
| **HES-PROD-B03** | Felix | Producer unit/integration tests | OPEN (after B02) |
| **HES-PROD-B04** | Ava | Smoke producer **off** → sealed identity | OPEN (after B03) |
| **HES-PROD-B05** | Ava | Smoke producer **on** → ε finite differences | OPEN (after B04) |
| **HES-PROD-B06** | Colombo | Wiki e2e LIVE only where producer proven | OPEN (after B05) |
| **HES-PROD-B07** | Colombo | Keep PARTIAL honesty where producer not proven | OPEN (with B06) |
| **HES-PROD-B08** | Cursor | Wiki regen + `hesperia_wiki` ingest + smoke | OPEN (after B06–07) |
| **HES-PROD-B09** | Felix | Scope METRIC-24/25 vs `METRIC-EXIT-CRITERIA` (land or defer packet) | OPEN (after B05) |
| **HES-PROD-B10** | Felix | Land METRIC-24/25 **or** Ethan-ready deferral artifact | OPEN (after B09) |
| **HES-PROD-B11** | Ava | Smoke METRIC-24/25 + emit matrix (or deferral smoke N/A) | OPEN (after B10) |
| **HES-PROD-B12** | Ethan | Sign Wave B exit | OPEN (after B08+B11) |

## Wave C — Product face + paper v0.1 + smoke runbook

| ID | Owner | Task | Status |
|----|-------|------|--------|
| **HES-PROD-C01** | Olivia | `/analyze` contract delta for producer + emit labels | OPEN (after B12) |
| **HES-PROD-C02** | Olivia | Public API snapshot discipline check post-contract | OPEN (after C01) |
| **HES-PROD-C03** | Ava | Operator surface labels for experimental emit | OPEN (after C01) |
| **HES-PROD-C04** | Ava | Product-copy pass: experimental ≠ clinical | OPEN (after C03) |
| **HES-PROD-C05** | Colombo | Paper v0.1 methods/systems from publication + Wave B evidence | OPEN (after B12) |
| **HES-PROD-C06** | Colombo | Paper v0.1 BELL/NASH/METRIC PARTIAL honesty section | OPEN (with C05) |
| **HES-PROD-C07** | Ethan | Novelty re-lock vs paper v0.1 (composition only) | OPEN (after C05–06) |
| **HES-PROD-C08** | Liam | SCRIPT-RUNBOOK smoke pack for L6ε + METRIC flags (altitudine) | OPEN (after B12) |
| **HES-PROD-C09** | Liam | Dry-run smoke runbook once; file outcome | OPEN (after C08) |
| **HES-PROD-C10** | Sophia | Prod enable checklist (still defaults off; rollback) | OPEN (after C08) |
| **HES-PROD-C11** | Colombo | ISO pack currency pass vs 0.7.2 tip (traceability/quality) | OPEN (after C07) |
| **HES-PROD-C12** | Grace | Receive Wave C — **promote CC HOLD** until new operator GO | OPEN (after C11) · may PAUSE |
| **HES-PROD-C13** | Ethan | Sign Wave C exit | OPEN (after C12 filed) |

## Wave D — Optional closeout (after C)

| ID | Owner | Task | Status |
|----|-------|------|--------|
| **HES-PROD-D01** | Ethan | Frame `agentic_bridge` ratify **or** archive decision | OPEN (after C13) |
| **HES-PROD-D02** | Emma | INTEGRATION-CONTRACT stub **or** archive classification note | OPEN (after D01) |
| **HES-PROD-D03** | Noah | Write AI-TEST-REPORT plan (deterministic boundary) | OPEN (after C13) |
| **HES-PROD-D04** | Noah | Execute AI-TEST smoke; file results | OPEN (after D03) |
| **HES-PROD-D05** | Marcus | Schema freeze note for metric emit matrix | OPEN (after C13) |
| **HES-PROD-D06** | Marcus | EXTENSION_STATUS review vs product_surface rules | OPEN (with D05) |
| **HES-PROD-D07** | Abelard | `gh` via `github_agent_org` — CC Actions/repo view hygiene | OPEN (after C13) |
| **HES-PROD-D08** | Abelard | Verify CC remote tip + inception stamp post any later promote | OPEN (after D07) |
| **HES-PROD-D09** | Ethan | Sign Wave D / HES-PROD-NEXT closure | OPEN (after D01–D08 as scoped) |
| **HES-PROD-99** | Grace | Wave wrap digest (counts, promote status, residuals) | OPEN (last) |

**OPEN count:** A01–A08 (8) + B01–B12 (12) + C01–C13 (13) + D01–D09 + 99 (10) = **43 OPEN**.  
(Adjust: drop to 40 by merging C12/C13 awareness — keep 43 within 35–45 budget.)

## Exit criteria

1. **A:** Gaps ratified; security HOLD; diacritic criteria written; no sealed silent fix.  
2. **B:** Producer landed **or** explicit deferral; wiki honest; METRIC-24/25 landed **or** deferral; Ethan signed.  
3. **C:** Contract/labels/paper v0.1/runbook/ISO pass; Grace promote **HOLD** until GO.  
4. **D:** agentic_bridge decision; AI-TEST; schema freeze; Abelard gh hygiene; wrap.

SIGNED: Triage (Grace) | HES-PROD-NEXT A–D | 2026-08-10 | HES-PROD-00 · budget 43 OPEN
