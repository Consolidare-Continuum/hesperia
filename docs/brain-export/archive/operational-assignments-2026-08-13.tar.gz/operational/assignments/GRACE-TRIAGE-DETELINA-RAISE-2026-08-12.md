# GRACE TRIAGE — Detelina raise today (@BiopoleBot)

**Date:** 2026-08-12  
**Project:** `biopole` / Detelina (client seat)  
**Operator ask:** Raise Detelina today; Telegram bot **@BiopoleBot**; use **CHROMA-BIOPOLE-OP**; under `/data/CLIENTS` policy; separate IRC mesh link (not a new VM). Ethan placement: **process on prichindel**, tersagor = mesh ruler only.

## Decision

| Item | Value |
|------|--------|
| Placement | **prichindel** bot process (Ethan advise 2026-08-12) |
| Mesh | **Separate IRC nick/peer** into tersagor Ergo — not new VM; do not reuse nick `tersagor` / `imirc-tersagor-presence` |
| TG identity | **@BiopoleBot** (Bot API id received in operator chat) |
| Chroma | **CHROMA-BIOPOLE-OP** `http://127.0.0.1:8002` (prichindel loopback) |
| Clients path | `/data/CLIENTS/biopole` (+ seat `/home/biopole-op`) |
| Board | Central rows below for team deploy; client-local board remains `detelina_agent_brain/active.md` ([ETHAN-POLICY-CLIENT-LOCAL-BOARDS.md](../../governance/ETHAN-POLICY-CLIENT-LOCAL-BOARDS.md)) |

## Token custody (no values in git / chat packets)

| Location | Role |
|----------|------|
| trustmaster `/root/.secrets/biopole/biopolebot.telegram.token` | Custody |
| prichindel `/root/.secrets/biopole/biopolebot.telegram.token` | Runtime Abelard |
| `/home/biopole-op/.secrets/telegram/biopolebot.token` | Seat (600 biopole-op) |
| Pointers | `…/README-LOCATIONS.txt` · trustmaster `biopolebot.LOCATIONS.txt` |

**Verified at triage:** Telegram `getMe` → `@BiopoleBot`; CHROMA-BIOPOLE-OP heartbeat active; container `chroma-biopole-op` up. Existing `biopole_telegram_bot` container was up (Abelard: update vs sibling Detelina unit).

## Active.md rows (bootstrap — superseded by expand)

| ID | Owner | Status | Notes |
|----|-------|--------|-------|
| DET-RAISE-00 | Grace | DONE | Triage + vault paths |
| DET-RAISE-01..03 | — | DONE | Superseded by **DET-001..060** |

**Expand (2026-08-12):** [GRACE-TRIAGE-DETELINA-RAISE-EXPAND-2026-08-12.md](GRACE-TRIAGE-DETELINA-RAISE-EXPAND-2026-08-12.md) · [DET-RAISE-2026-REGISTER.md](../../governance/DET-RAISE-2026-REGISTER.md)

## Boundaries

- No new VM for Detelina  
- Do not put biopole-op MCP on CHROMA-1  
- Do not commit Bot API token to brain or client git  
- tersagor remains IRC mesh ruler / SDK main  

## Refs

- Ethan placement (this session)  
- [CLIENTS/biopole.md](../../CLIENTS/biopole.md)  
- [cluster/prichindel/BIOPOLE-OFFICE-SERVICES.md](../../cluster/prichindel/BIOPOLE-OFFICE-SERVICES.md)  
- [governance/CHROMA-BIOPOLE-OP-DEFAULT-ENV.md](../../governance/CHROMA-BIOPOLE-OP-DEFAULT-ENV.md)  
- [cluster/tersagor/IRC-PRESENCE-SINGLE-INSTANCE.md](../../cluster/tersagor/IRC-PRESENCE-SINGLE-INSTANCE.md)  

SIGNED: Triage (Grace) | Detelina raise @BiopoleBot | 2026-08-12 | DET-RAISE
