# Grace triage — Hesperia wiki gaps post KAM/KSI-Inspector prod promotion

**Date:** 2026-08-05  
**CSP:** From: Felix Context → To: Grace triage Context | Reason: operator asked Grace to task team on Felix wiki-gap spec | What changes: row creation + wave routing; no product code in this packet  

**Project:** `hesperia` · **ID prefix:** `HWIKI-KSI-`  
**Source spec:** [FELIX-COLOMBO-WIKI-KSI-KAM-GAPS-SPEC-2026-08-05.md](FELIX-COLOMBO-WIKI-KSI-KAM-GAPS-SPEC-2026-08-05.md) (local commit `00507edc`; push blocked until DNS restored)  
**Hub:** [wiki/CLAUDE.md](../../colombo_research/hesperia/wiki/CLAUDE.md) · live `http://wiki.hesperia.local/`

---

## Trigger

Promoted `81c26053` (KSI-Inspector + KAM lens + L5/L6 stubs) to `Consolidare-Continuum/hesperia`. Wiki register check found four catch-up gaps — code/research real, wiki silent or stale. Not re-litigation of HES-MATH-BEHAV.

## Terminology (carry forward)

| Canonical | Do **not** |
|-----------|------------|
| **KSI-Inspector** | bare “KSI” |
| **KME-KSI-score** | calling it “KSI” when meaning the inspector |

## Rows

| ID | Owner | Scope | Status target |
|----|-------|-------|---------------|
| **HWIKI-KSI-00** | Grace | This triage | DONE on write |
| **HWIKI-KSI-01** | Colombo | Gap 1+2 — KSI-Inspector wiki items (`Φ_e`, Expected_j, residual, MirrorCause, bridge_need_score, MISSING_BRIDGE) + disambiguation vs `KSI-KME-derived` | OPEN |
| **HWIKI-KSI-02** | Colombo | Gap 3 — amend `structure/SYSTEM-STRUCTURE-0.7.0.md` (wired KSI + KAM + 0.7.2 note) | OPEN |
| **HWIKI-KSI-03** | Colombo | Gap 4 — remaining `sphere/kam/*` wiki items + BELL/NASH/METRIC formalized-not-wired placeholders | OPEN |
| **HWIKI-KSI-04** | Cursor | After wiki regen — `ingest-hesperia-wiki.sh` + smoke `query_knowledge(layer=hesperia_wiki)` / `query_hesperia_wiki` | OPEN (after 01–03) |
| **HWIKI-KSI-05** | Ethan | Sign wiki-gap wave when 01–04 exit criteria met | OPEN |

**Order:** 01 → 02 → 03 → 04 → 05 (matches Felix suggested order).

## Exit criteria

1. `query_hesperia_wiki` / `get_hesperia_wiki_page` returns KSI-Inspector pipeline symbols (not empty).
2. `KSI-KME-derived` and KSI-Inspector pages cross-link / disambiguate.
3. SYSTEM-STRUCTURE no longer claims KSI “isn't wired into /analyze”.
4. KAM battery files + BELL/NASH/METRIC have wiki footprint (placeholder OK for neighbours).
5. CHROMA-1 `hesperia_wiki` re-ingest smoked.

## Parallel infra (separate project)

Felix push blocked: dnsmaster Unbound SERVFAIL for external names. Abelard owns — see **DNS-UNBOUND-01** on `active.md` (cluster).

SIGNED: Triage (Grace) | Hesperia wiki KSI-KAM gaps | 2026-08-05 | HWIKI-KSI-00
