# КОРПОРАТИВНЫЙ ИНЦИДЕНТНЫЙ ОТЧЁТ

**Документ:** GRACE-BIOPOLE-HOST-DISK-SSH-2026-08-06  
**Классификация:** Operational Incident / Infrastructure Reliability  
**Статус:** CLOSED (симптомы устранены перезапуском) · ROOT CAUSE OPEN (диск)  
**Дата отчёта:** 2026-08-06  
**Автор:** Grace (операционная triage / corporate reporting)  
**Техническое расследование:** Abelard (DevOps)  
**Заказчик / контур:** Biopole (клиентский host) · доступ через Tailscale  
**Рассылка:** igareosh@igareosh.com · serghei.s@biopole.md · office@biopole.md  
**From:** agents@prichindel.com  

---

## 1. Резюме для руководства (Executive Summary)

В период до **2026-08-06 ~13:04 UTC** удалённый доступ по **SSH** к клиентскому серверу **biopole** (Tailscale IP `100.92.158.21`) был невозможен: соединение на порт **22** устанавливалось, но рукопожатие SSH обрывалось (`Connection reset` на этапе `kex`). При этом **ICMP / Tailscale ping** оставался успешным, что создавало ложное впечатление «сервер онлайн».

После аппаратного/ручного **restart** сервера доступ по SSH восстановлен. Расследование показало: это **не отказ в доступе** (не ключи, не firewall, не fail2ban), а **деградация накопителя** (HDD Seagate ST3250318AS) с ошибками ATA, остановкой записи логов и последующим «зависшим» состоянием ОС при живом сетевом стеке Tailscale.

**Прямой вывод:** без замены диска инцидент может повториться; хранить на этом host критичные данные **нельзя**.

---

## 2. Затронутые объекты

| Объект | Деталь |
|--------|--------|
| Host | `biopole` (Ubuntu server, **client-owned**, не cluster CA / Authentik) |
| Tailscale | MagicDNS `biopole` · IP `100.92.158.21` |
| LAN (office) | `eno1` → `192.168.0.72/24` (сеть office / Woxtel) |
| Диск | `/dev/sda` · **Seagate Barracuda 7200.12 ST3250318AS** · S/N **9VMTKX8L** · 250 GB |
| Сервис | `ssh.service` / `ssh.socket` (OpenSSH; после reboot — `OpenSSH_10.2p1`) |
| Мониторинг | Prometheus blackbox ICMP к `100.92.158.21` оставался `probe_success=1` |

---

## 3. Хронология (Timeline)

| Время (UTC) | Событие |
|-------------|---------|
| 2026-07-17 05:30 | Старт предыдущего boot (journal boot −1) |
| 2026-07-19 ~12:30–12:35 | Массовые ошибки ядра: `ata1.00` / `WRITE FPDMA QUEUED` / `Emask 0x40 (internal error)` |
| 2026-07-19 12:35:23 | **Последняя** запись journal предыдущего boot |
| 2026-07-20 → 2026-08-05 | **Нет** логов в `/var/log` и journal за этот период |
| 2026-08-06 (до ~13:04) | Tailscale/ICMP OK · SSH: `kex_exchange_identification: Connection reset` (cluster + LAMAITA) |
| 2026-08-06 ~13:04 | Restart host · EXT4 orphan cleanup · sshd снова обслуживает banner |
| 2026-08-06 13:05+ | SSH OK с ключом `agent-biopole` · установлен `smartmontools` · SMART собран |

---

## 4. Прямые причины (Direct Causes)

1. **Отказы записи/чтения HDD** на `ata1.00` (команды `WRITE FPDMA QUEUED` / uncorrectable LBA).  
2. **Остановка устойчивой записи логов** после ~2026-07-19 12:35 UTC → слепая зона диагностики до reboot.  
3. **Деградированное/зависшее состояние ОС**: сетевой путь Tailscale (ICMP) жив, **sshd** не завершает handshake → клиент видит reset, не «Permission denied».  
4. **Нечистая файловая система** при старте после reboot (`EXT4 orphan cleanup`) — следствие аварийной остановки записи.

---

## 5. Противоречия (Contradictions) — почему это выглядело иначе

| Наблюдение | Ожидание | Факт |
|------------|----------|------|
| Host «online» в Tailscale / Prometheus ICMP | SSH должен работать | SSH reset на kex |
| SMART overall-health: **PASSED** | Диск «здоров» | Self-test **read failure**; **99** Reported_Uncorrect; ATA Error Count **99** |
| Симптом «Connection closed / reset» | Часто думают про ключи / ban / firewall | `fail2ban` inactive · `ufw` inactive · после reboot ключ `agent-biopole` принят |
| DNS-имя `biopole` / `biopole.prichindel.local` в LAN | Кажется, что это тот же host | В корпоративном DNS `biopole.prichindel.local` → **Ops Method shop на altitudine** (`192.168.100.65`) — **другой объект**; клиентский server — только Tailscale IP / MagicDNS |

Эти противоречия — главная операционная ловушка: **мониторинг «живости» по ICMP не равен доступности SSH и здоровью диска**.

---

## 6. Причины / корневой анализ (Reasons / Root Cause)

**Корневая причина (most probable):** аппаратная деградация HDD **ST3250318AS** (модель ~конца 2000-х, Barracuda 7200.12).

Подтверждения:

- Kernel ATA internal errors на write queue.  
- SMART attribute **187 Reported_Uncorrect = 99** (VALUE **001** — критично).  
- Short offline self-test: **Completed: read failure** @ LBA **3283225**.  
- SMART error log: UNC/WP на том же LBA.  
- Collateral: повреждённые apt lists + прерванный `dpkg` (типично для I/O hang во время package operations).

**Не является причиной:** отказ SSH-ключей, политика CA cluster, Authentik, fail2ban, UFW, «не тот пароль».

---

## 7. Доказательная база (Evidence — выдержки)

### 7.1 Kernel (диск)

```
ata1.00: failed command: WRITE FPDMA QUEUED
… Emask 0x40 (internal error)
ata1.00: status: { DRDY }
```

(многократно, 2026-07-19 ~12:34–12:35 UTC)

### 7.2 Клиент SSH (до reboot)

```
kex_exchange_identification: read: Connection reset by peer
Connection reset by 100.92.158.21 port 22
```

### 7.3 SMART self-test

```
# 1  Short offline  Completed: read failure  90%  7724  3283225
```

### 7.4 SMART attributes (ключевые)

| ID | Attribute | VALUE | RAW |
|----|-----------|-------|-----|
| 187 | Reported_Uncorrect | 001 | 99 |
| 183 | Runtime_Bad_Block | 099 | 1 |
| 188 | Command_Timeout | 100 | 2 |
| 5 | Reallocated_Sector_Ct | 100 | 0 |
| 197 | Current_Pending_Sector | 100 | 0 |

### 7.5 После reboot (контроль доступа)

```
Accepted publickey for igareosh … ED25519 SHA256:0qacZztiN/D6+JK+IYQgUuE3UfPLzWxfNi9sqViXImk
```

(`agent-biopole` — штатный agent key; не cluster CA.)

---

## 8. Рекомендации (Recommendations)

1. **Немедлено:** считать host **unstable storage**; не сохранять production / бухгалтерию / единственные копии на этом диске.  
2. **Заменить HDD** на новый SSD/HDD enterprise или качественный SATA SSD (см. §9).  
3. После замены: чистая установка Ubuntu LTS **или** clone только после `badblocks`/`smartctl` на новом носителе; проверить EXT4.  
4. Мониторинг: добавить не только ICMP, но **SSH blackbox** / process check `sshd` + **SMART** (`smartd` уже установлен).  
5. Документация: различать **biopole (Tailscale client host)** и **biopole.prichindel.local (LAN shop на altitudine)**.  
6. Операционно: при «ICMP OK / SSH reset» — сначала disk/dmesg/SMART, не ротация ключей.

---

## 9. Варианты постоянного устранения (Options)

| Опция | Описание | Плюсы | Минусы | Рекомендация |
|-------|----------|-------|--------|--------------|
| **A. Замена диска + reinstall** | Новый SSD ≥256–512 GB, чистая OS, Tailscale rejoin, ключи заново | Максимальная чистота, предсказуемость | Время простоя, ручная настройка | **Предпочтительно** |
| **B. Замена диска + clone/restore** | `dd`/`clonezilla` или restore с backup на новый диск | Быстрее вернуть «как было» | Риск переноса скрытой порчи FS | Только при наличии свежего backup |
| **C. Новый физический server** | Другое железо office | Обход старого SATA/контроллера | Стоимость | Если корпус/БП/SATA тоже сомнительны |
| **D. Только reboot / «пока работает»** | Ничего не менять | 0 затрат сейчас | **Повтор инцидента высоковероятен** | **Неприемлемо** как постоянное решение |
| **E. Облако / VPS вместо office box** | Вынести workload с office HDD | Меньше зависимости от office hardware | Стоимость, политика данных Biopole | Оценить с владельцем данных |

**Постоянный fix = Option A (или C), плюс мониторинг SSH+SMART. Option D закрывает только симптом.**

---

## 10. Текущее состояние (на момент отчёта)

- SSH с prichindel (`agent-biopole`) — **работает**.  
- `smartmontools` — **установлен**, `smartd` — **active**.  
- Диск — **PASSED** по overall SMART, но **фактически defective** по self-test и attr 187.  
- Apt/dpkg повреждения, обнаруженные при установке smartmontools, — **исправлены** (`dpkg --configure -a`, очистка lists).

---

## 11. Запрос решения (Decision needed)

Просим Biopole / ответственных подтвердить выбранную опцию (**A / B / C / E**) и окно работ на замену носителя. До замены host трактовать как **temporary / testing only** (как и зафиксировано ранее в инвентаре).

---

## 12. Подпись

```
SIGNED: Triage / Corporate Reporting (Grace)
        | prichindel.com operational context
        | 2026-08-06
        | Biopole host disk/SSH incident — causes, contradictions, options
Technical investigation support: Abelard (DevOps)
```

---

*Конец отчёта.*
