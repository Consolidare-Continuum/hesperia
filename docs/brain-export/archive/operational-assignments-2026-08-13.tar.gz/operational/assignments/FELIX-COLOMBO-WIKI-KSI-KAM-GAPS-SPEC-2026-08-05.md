# Spec — what Colombo has to address better, and where in the wiki (post KAM/KSI-Inspector promotion)

**Date:** 2026-08-05
**Author:** Felix (Claude Code) — written while doing the drift-check/promote pass on `igareosh/hesperia` → `Consolidare-Continuum/hesperia`
**Trigger:** Promoted `81c26053` ("wire KSI-Inspector + KAM lens + L5/L6 stub fills") to prod today. Checking the wiki (`colombo_research/hesperia/wiki/`) for whether it gives a full picture of that landing surfaced four gaps — none are re-litigation of HES-MATH-BEHAV, all are "the code and research exist, the wiki register doesn't say so yet."
**Hub:** [wiki/CLAUDE.md](../../colombo_research/hesperia/wiki/CLAUDE.md) · live `http://wiki.hesperia.local/`

---

## Gap 1 — KSI-Inspector has no wiki item of its own (highest priority)

`core/domain/ksi/pipeline.py` and `flags.py` (drained 2026-08-04, wired into `/analyze` + `hybrid_retriever` + `phi_trace` 2026-08-05, smoke-PASSed by Ava, now live in prod) implement a real pipeline: `Φ_e → sat → Expected_j → residual R_j → incident classifiers → MirrorCause → bridge_need_score → MISSING_BRIDGE`. None of that is a wiki *item* — it exists only as:

- one prose line in `structure/SYSTEM-STRUCTURE-0.7.0.md:75`
- one prose line in `CLASS-AB-SCIENCE-NARRATIVE-HUB.md:19`
- narrative research docs (`KAN_research/*`, `NASH_research/*`) — hypothesis-stage prose, not the parameter register

Anyone using the intended lookup path (`query_hesperia_wiki("Φ_e")`, `get_hesperia_wiki_page("bridge_need_score")`, or browsing categories) gets nothing. That's the exact failure mode the wiki exists to prevent (per its own `CLAUDE.md`: "the thing to open before re-deriving an answer that's already been found once").

**Address:** add `generate_wiki.py` items for at minimum: `Φ_e` (edge transfer function, `phi_e.py::phi_e_trace`/`sat`/`r_e_for_type`), `Expected_j`/`residual R_j` (`pipeline.py::run_ksi_inspect`, `compute_residual`), `MirrorCauseCandidate`, `bridge_need_score`/`compute_bridge_need`, `MISSING_BRIDGE` incident. Category: probably a new "KSI-Inspector" hub under Stability/Evidence-and-Trust rather than folding into existing KME categories — see Gap 2.

## Gap 2 — Terminology collision the ratification named but the wiki didn't resolve

`HES-MATH-BEHAV-20` (Ethan, ratified) exists specifically because **KSI-Inspector ≠ KME-KSI-score** and bare "KSI" was colliding. The wiki currently has exactly one page with "KSI" in the title — [`KSI-KME-derived.md`](../../colombo_research/hesperia/wiki/pages/KSI-KME-derived.md), i.e. the *other* one. A reader who searches "KSI" in the wiki today finds only KME-KSI-score, with nothing pointing at KSI-Inspector or flagging the two are unrelated. This is the collision the ratification banned, still live in the one place meant to prevent exactly this kind of confusion.

**Address:** once Gap 1's KSI-Inspector item(s) exist, add an explicit cross-note on `KSI-KME-derived.md` ("not to be confused with KSI-Inspector, see [[...]]") and vice versa — the wiki generator already supports `[[Page Name]]` auto-linking in `notes`.

## Gap 3 — `structure/SYSTEM-STRUCTURE-0.7.0.md` is now describing a superseded state

Line 77 of that hub currently reads: *"Neither is wired into `/analyze` or `/product/interpret` yet — code landed, live-emit wiring is a separate follow-on step."* That was true 2026-08-04. As of today it is wrong on both counts it names:

- KSI-Inspector: wired (`HES-MATH-BEHAV-05`, DONE) and smoke-verified (`HES-MATH-BEHAV-06`, PASS) into `/analyze`.
- The hub also predates KAM entirely (`sphere/kam/*`, apply-gate lens) and the `system_version` bump from `0.7.0` to `0.7.2` (seal commit `1d89c146`, "module boundary + KSI/IPoV drain").

This is the single page meant to answer "how does the system work right now" — it's the one an operator or new agent would read first, and it's two waves stale. Low reader traffic doesn't fix a wrong "not wired yet" claim sitting at the top of the canonical structure doc.

**Address:** an amendment pass (not a rewrite — the 0.7.0 architecture description itself is still accurate) updating the "2026-08-04 additions" section to reflect: KSI-Inspector now wired + live-flag-gated (`HESPERIA_KSI_ENABLED`), KAM apply-gate lens added (`HESPERIA_KAM_ENABLED`), version note bumped/cross-referenced to `1d89c146`/`81c26053`.

## Gap 4 — `sphere/kam/` is ~20% wikified; BELL/NASH/METRIC are 0%

Only `kam_score.py` and `sisr.py` are cited as "Responsible module" anywhere in the wiki (3 pages: `SISR`, `KAM-semantic-score`, `kam-verdict`). Eight more files shipped in the same wave with zero wiki footprint: `apply_gate.py`, `bounds.py`, `critical_paths.py`, `flags.py`, `perturbation_battery.py`, `pipeline.py`, `report.py`, `trajectory_fingerprint.py` — i.e. the actual battery mechanics (how perturbations are generated, how critical paths are selected, what a trajectory fingerprint is), not just the two headline scalars.

Separately: [`COLOMBO-HES-MATH-BEHAV-13-15-NEIGHBOURS-2026-08-05.md`](COLOMBO-HES-MATH-BEHAV-13-15-NEIGHBOURS-2026-08-05.md) formalized BELL (`path_mass`/`bell_path_residual`), NASH (sealed-path field equilibrium), and METRIC (`HesperiaMetric`/`S_path`) — all three marked DONE on `active.md` (HES-MATH-BEHAV-13/14/15). Zero wiki footprint for any of them, not even a placeholder. That doc's own NEXT section says *"Ethan 67 may note these as formalized-not-wired"* — worth confirming whether that note landed, but either way the wiki (not just active.md) should carry a "formalized v0.1, schema-stub only, not yet implemented" status for these three, the same way KAM itself was correctly wikified as inspect-only before it got the full apply-gate build. Silence in the wiki reads as "doesn't exist," not "exists at spec stage" — that's a worse failure than an explicit PARTIAL/⚪ entry.

**Address:**
1. Wikify the remaining `sphere/kam/*` files as their own items (battery mechanics), linked from `KAM_semantic_score`'s `produced_from`.
2. Add three placeholder items — BELL / NASH / METRIC — status reflecting "formalized (SPEC v0.1), not implemented," each linking to the neighbours doc above, so a wiki search doesn't come back empty for concepts that already have a ratified name and schema id.

---

## Suggested order

1. **Gap 1 + Gap 2 together** (KSI-Inspector items, then the cross-note disambiguating it from KME-KSI-score) — highest value, closes the biggest silent hole and the named collision in one pass.
2. **Gap 3** (structure hub amendment) — cheap, high-visibility correctness fix.
3. **Gap 4** (KAM battery internals + BELL/NASH/METRIC placeholders) — larger but mechanical, same pattern as existing KAM pages.

None of this blocks anything already marked DONE on `active.md` — it's wiki-register catch-up on work that's real and already shipped/promoted, not new product scope.

SIGNED: Developer (Felix) | Claude Code context | 2026-08-05 | wiki gap spec for Colombo, post KAM/KSI-Inspector prod promotion
