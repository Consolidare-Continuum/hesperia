# COLOMBO — HES-MATH-BEHAV-40..46 KAM product contract (apply-gate formalization)

**Date:** 2026-08-05  
**CSP:** From: Cursor drain → To: Colombo | Reason: formalize KAM SISR + KAM_semantic_score product contract | What changes: research/formal packets in brain; **no** hesperia product code  
**Owner:** Colombo (formalization)  
**Downstream implement:** Felix **HES-MATH-BEHAV-47..53** (this packet = hand-off)  
**Status:** **FORMALIZED** (contract for implement; product code **does not** ship KAM yet)

---

## Sources (read / bound)

| Source | Role |
|--------|------|
| [KAM_research_SPEC-v01.md](../../colombo_research/hesperia/KAM_research/KAM_research_SPEC-v01.md) | Normative research: SISR, composite, bands, perturbations, placement |
| [KAM_research_INVENTORY.md](../../colombo_research/hesperia/KAM_research/KAM_research_INVENTORY.md) | Verified surfaces + **gap**: no `sphere/kam/` |
| [schemas/KAM_research_perturbation_report.v01.example.json](../../colombo_research/hesperia/KAM_research/schemas/KAM_research_perturbation_report.v01.example.json) | Report shape `hesperia.kam_perturbation_report.v01` |
| [HES-MATH-BEHAV-RATIFY-2026-08-05.md](../../governance/HES-MATH-BEHAV-RATIFY-2026-08-05.md) | Ethan **RATIFIED** terminology + stack order (rows 20–23) |
| [APPLY-ALLOWLIST-0.7.0.md](../../colombo_research/hesperia/wiki/structure/APPLY-ALLOWLIST-0.7.0.md) | 0.7.0 sandbox apply allowlist (inspect ≠ mutate) |

**Missing on disk (soft):** `operational/assignments/GRACE-TRIAGE-HESPERIA-MATH-BEHAVIOUR-BUNDLE-2026-08-04.md` — not present in this workspace; terminology taken from Ethan ratify stamp (same terms).

**Product evidence (2026-08-05, `/data/hesperia/hesperia`):** `sphere/kam/` **ABSENT**; no `SISR` / `KAM_semantic_score` / `kam_verdict` symbols in tree. KSI-Inspector package **present** at `core/domain/ksi/` (ratify §22).

---

## Ratified terminology (mandatory)

| Canonical | Meaning | Forbidden |
|-----------|---------|-----------|
| **KAM (research)** | Kolmogorov–Arnold–Moser-**inspired** semantic perturbation-stability **lens** | “KAM theorem implemented” |
| **SISR** | Semantic Invariant Survival Rate | inventing alternate acronyms |
| **KAM_semantic_score** | Composite apply-gate scalar | calling L6 `GLOBAL_STABILITY_SCORE` “KAM” |
| **kam_verdict** | Band label from `KAM_semantic_score` | free-form prose verdicts in the gate path |
| **KSI-Inspector** | Φ_e → Expected_j → R_j → bridge_need package | bare “KSI” alone in product comments |
| **Teacher** | Inspect-only proposal packet until 0.7.0 apply gates | auto-mutate from Teacher |

Stack order (**Ethan §21 — normative**):

```text
/analyze envelope
  → [optional NASH field settlement]
  → [optional BCI-HP path-bundle]
  → KSI-Inspector: Φ_e → Expected_j → R_j → bridge_need / incidents
  → Teacher packet (inspect-only until 0.7.0 apply gates)
  → KAM: perturbation battery → SISR → KAM_semantic_score (apply-gate lens)
  → [Nash repair stability]
  → 0.7.0 sandbox apply (allowlist)
```

**Hard rule:** KAM runs **AFTER** KSI-Inspector + Teacher inspect-only. KAM is a **neighbour lens**, not a replacement for L1–L9.

---

## 40 — KAM SPEC-v01 → product delta inventory

| Contract element (SPEC-v01) | Research status | Product status (2026-08-05) | Delta for Felix |
|-----------------------------|-----------------|-----------------------------|-----------------|
| Doctrine: stability-inspection lens | Formalized | Not wired | Keep lens; no new propagation physics |
| Baseline trajectory `T₀` fingerprint | Specified | Scattered (activation / trace / corridors); **no** single fingerprint object | Build `SemanticTrajectoryFingerprint` from analyze bundle |
| Critical paths `Π*` | Specified | Partial corridor/trace surfaces | Extract `baseline.critical_paths[]` with `τ_crit` |
| Perturbation battery P1–P6 | Catalogued | Hooks scattered (`perturb_shadow`, Φ_e coeffs, Teacher packet, sandbox); **no** orchestrator | `perturbation_battery.py` + versioned bounds JSON |
| Per-p measures (path_survival, concept_flip, …) | Defined | Absent as KAM report fields | Emit per-`p` row in report schema |
| **SISR** (`SISR_min`, `SISR_mean`) | Defined | **DEAD** in product | `sisr.py` |
| **KAM_semantic_score** | Defined | **DEAD** in product | `kam_score.py` |
| **kam_verdict** bands | Defined | **DEAD** in product | Map score → enum |
| Report `hesperia.kam_perturbation_report.v01` | Example JSON | Not emitted | `report.py` + optional `engine_result.kam_stability` |
| Apply-gate consumer | Placement in SPEC §8 | 0.7.0 allowlist exists; **no** KAM gate input | Pre-0.7.0: **inspect-only** expose; apply consumes only when gate contract met |
| Module tree `sphere/kam/` | Proposed | **Absent** | Scaffold read-only package |

**Non-goals (carry forward):** prove KAM theorem; replace ΣΓΘ / KSI-Inspector / sealed multiscale; unbounded LLM paraphrase in v0.1.

---

## 41 — SISR definition (product contract)

### 41.1 Name and type

- **Name:** `SISR` — Semantic Invariant Survival Rate  
- **Type:** dimensionless scalar ∈ `[0, 1]`  
- **Also emit:** `SISR_min`, `SISR_mean` (both required in report)

### 41.2 Inputs

| Symbol | Definition |
|--------|------------|
| `Π*` | Critical paths from baseline `T₀` (top-k corridor edges / dominant area–family chain / trace segments with mass ≥ `τ_crit`) |
| `Π_p` | Critical-path set (or weighted support) after perturbation `p` |
| `τ_path` | Path-preservation threshold; **default `0.7`** (calibration knob; version with bounds file) |
| `𝒫` | Active perturbation set for the run (subset of P1–P6 that executed) |

### 41.3 Formula

```text
path_overlap(p) = |Π_p ∩ Π*| / |Π*|     # Jaccard or weighted overlap; document choice in code
preserved_p     = 1 if path_overlap(p) ≥ τ_path else 0   # for count form
# Continuous form (preferred for scoring):
path_survival_p = path_overlap(p)        # already in [0,1]

SISR_mean = mean_{p ∈ 𝒫} path_survival_p
SISR_min  = min_{p ∈ 𝒫} path_survival_p
```

**Conservative apply lens uses `SISR_min`.** Report **both**. Product comments must not call this a theorem quantity.

### 41.4 Empty / edge cases

| Case | Contract |
|------|----------|
| `\|Π*\| = 0` | Emit `SISR_min = SISR_mean = null` + `kam_verdict = insufficient_baseline`; **do not** invent 1.0 |
| Perturbation failed / skipped | Exclude from `𝒫`; list in `fragile_points` or run errors |
| Single perturbation | `SISR_min == SISR_mean` |

### 41.5 Distinct from live neighbours

| Live metric | Why not SISR |
|-------------|--------------|
| L6 `GLOBAL_STABILITY_SCORE` / Lyapunov proxy | Single-pass perturbation-growth proxy; **not** trajectory battery |
| L6 `INPUT_PERTURBATION_RESPONSE` | Stubbed first-order amplitude; not path survival |
| Nash `equilibrium_score` | Field settlement residual; different object |
| BCI-HP `bell_path_residual` | Triplet path bundle; not whole-trajectory battery |

---

## 42 — KAM_semantic_score composite (product contract)

### 42.1 Name and type

- **Name:** `KAM_semantic_score`  
- **Type:** dimensionless scalar ∈ `[0, 1]`  
- **Kind:** governed **inspection** scalar for apply gating — **not** a theorem

### 42.2 Formula (normative product)

```text
KAM_semantic_score =
    path_survival
  × area_stability
  × contradiction_non_growth
  × resonance_penalty_inverse
  × drift_penalty_inverse
```

All factors ∈ `[0, 1]`. Product of factors (multiplicative) — any near-zero factor collapses the score (intentional).

### 42.3 Component contracts

| Component | Formula (conceptual) | Source measures |
|-----------|----------------------|-----------------|
| `path_survival` | `SISR_mean` **or** `SISR_min` (config; **default `SISR_min` for apply-gate**) | §41 |
| `area_stability` | `1 − clamp01(area_drift_mean)` | mean `area_drift_p` over `𝒫` |
| `contradiction_non_growth` | `1 − clamp01(contradiction_growth_mean)` | mean `contradiction_growth_p` |
| `resonance_penalty_inverse` | `clamp01(family_resonance_mean)` | mean `family_resonance_p` |
| `drift_penalty_inverse` | `1 − clamp01(dominant_area_flip_rate)` | fraction of `p` with dominant-area change |

`clamp01(x) = max(0, min(1, x))`.

### 42.4 Calibration hooks (Ethan / config — not Felix invent)

Versioned file (target): `kam_perturbation_bounds_v01.json` (Ethan owns bounds; Felix loads):

- `ε_shadow`, `ε_edge`, `ε_bias`
- `τ_path`, `τ_crit`
- which factor uses `SISR_min` vs `SISR_mean` for `path_survival`
- band thresholds (§43) if overridden from defaults

### 42.5 Report fields (minimum)

From schema `hesperia.kam_perturbation_report.v01`:

- `schema`, `baseline_id`, `baseline` summary  
- `perturbations[]` with per-p measures  
- `SISR_min`, `SISR_mean`  
- `KAM_semantic_score`, `kam_verdict`  
- `stable_islands[]`, `fragile_points[]`

Future wire: `engine_result.kam_stability` ← same block (read-only).

---

## 43 — kam_verdict bands

| `KAM_semantic_score` | `kam_verdict` | Gate semantics (product) |
|----------------------|---------------|---------------------------|
| ≥ **0.75** | `structurally_robust` | May proceed to Nash repair stability + **then** 0.7.0 sandbox apply **if** allowlist + other gates OK |
| **0.45** – **&lt; 0.75** | `conditionally_stable` | Sandbox **inspect / preview only** by default; operator review required before apply |
| **&lt; 0.45** | `fragile_trajectory` | **Block apply**; more inspection / rework proposal |
| `null` / missing components | `insufficient_baseline` | **Block apply**; fix fingerprint / `Π*` |

**Boundaries:** lower inclusive on mid band (`0.45 ≤ score < 0.75`); upper band `score ≥ 0.75`. Document ties in code tests.

**Not interchangeable with** L9 brand words (`BRAND_WORD_TRUST`, etc.) — different spine.

---

## 44 — Apply-gate pre-0.7.0 contract (inspect vs apply)

### 44.1 Phases

| Phase | KAM behaviour | Mutates graph? |
|-------|---------------|----------------|
| **pre-0.7.0 / observe** | Run battery (or offline fixtures); emit report; surface in inspect envelope | **No** |
| **0.7.0 sandbox apply** | Consume `KAM_semantic_score` + `kam_verdict` as **one** gate input alongside Nash repair stability + allowlist | Only via `runtime/h070_apply` allowlist |

### 44.2 Inspect vs apply (hard)

| Mode | Allowed | Forbidden |
|------|---------|-----------|
| **Inspect** | Compute `T₀`, run `𝒫`, write report, attach to analyze/Teacher preview | Calling apply executor; writing edges |
| **Apply** | Read prior KAM report for same `baseline_id` / proposal id; enforce verdict | Re-running KAM *inside* apply without inspect evidence; ignoring `fragile_trajectory` |

### 44.3 Gate predicate (normative intent)

```text
allow_sandbox_apply_candidate =
    (kam_verdict == structurally_robust)
    ∧ Nash_repair_stability_OK
    ∧ action ∈ VERSION.yaml apply.allowlist
    ∧ G1–G9 chain OK
```

`conditionally_stable` → **not** auto-apply; operator / explicit review path only.  
`fragile_trajectory` / `insufficient_baseline` → **hard block**.

### 44.4 Stack dependency (re-state)

KAM **must not** run as a substitute for KSI-Inspector. Ordering: KSI-Inspector → Teacher (inspect-only) → **KAM**. P4/P5 perturbations require Teacher / sandbox proposal surfaces; if proposal absent, skip P4/P5 and mark battery incomplete (do not pretend full `𝒫`).

### 44.5 Alignment with allowlist hub

See [APPLY-ALLOWLIST-0.7.0.md](../../colombo_research/hesperia/wiki/structure/APPLY-ALLOWLIST-0.7.0.md): live allowlist currently `update_edge_weight` only. KAM does **not** widen the allowlist; it only adds a **stability lens** before allowlisted apply.

---

## 45 — Wiki stubs (SISR + KAM_semantic_score)

**Generator pattern is clear** (`tools/generate_wiki.py` `ITEMS` → regen). This pass adds **DEAD** stubs (honest: not implemented) under **Stability and Control Theory**:

| Wiki name | Status | Notes key |
|-----------|--------|-----------|
| `SISR` | `DEAD` | Product contract this packet §41; implement → flip to LIVE_FULL |
| `KAM_semantic_score` | `DEAD` | Product contract §42–43; implement → LIVE_FULL |
| `kam_verdict` | `DEAD` | Band enum companion |

**Regen:** `python3 colombo_research/hesperia/wiki/tools/generate_wiki.py` then `render_wiki_html.py` as needed.

**Coverage-Ledger:** generator `render_coverage_ledger()` updated with DONE line for HES-MATH-BEHAV KAM stubs (2026-08-05).

---

## 46 — Hand-off packet for Felix (HES-MATH-BEHAV-47..53)

### 46.1 Implement checklist (ordered)

1. **Scaffold** `sphere/kam/` (read-only; no new propagation physics):
   - `trajectory_fingerprint.py` — `T₀` from analyze / invariant / sealed stack  
   - `critical_paths.py` — `Π*` extraction  
   - `perturbation_battery.py` — P1..P6 runners (start **P2** `perturb_shadow` + **P3** edge ε offline)  
   - `sisr.py` — `SISR_min` / `SISR_mean`  
   - `kam_score.py` — `KAM_semantic_score` + `kam_verdict`  
   - `report.py` — `hesperia.kam_perturbation_report.v01`
2. **Bounds:** load `kam_perturbation_bounds_v01.json` (Ethan) — do not hard-code ε without version key.
3. **Offline first:** battery on E2E / `invariant_path_effect` fixtures → JSONL under `KAM_research/offline_runs/` (see offline README).
4. **Wire inspect-only:** attach report to analyze / Teacher preview path; **no** apply mutation.
5. **Apply-gate hook (0.7.0):** feed verdict into sandbox apply preflight per §44; keep allowlist unchanged.
6. **Tests:** empty `Π*`; single-p; band boundaries `0.45` / `0.75`; multiplicative collapse when one factor → 0.
7. **Wiki flip:** after LIVE wire, Colombo/Felix update generator stubs DEAD → LIVE_FULL + module paths.
8. **Naming:** comments/docs use **KAM (research)**, **SISR**, **KAM_semantic_score**, **kam_verdict**, **KSI-Inspector** — Ethan ratify.

### 46.2 Suggested row mapping (47–53 — for Grace/parent; Colombo does not edit active.md)

| ID (suggested) | Focus |
|----------------|-------|
| 47 | `sphere/kam/` scaffold + fingerprint + `Π*` |
| 48 | Perturbation battery P2+P3 offline |
| 49 | SISR + report schema emit |
| 50 | `KAM_semantic_score` + `kam_verdict` |
| 51 | Inspect-only envelope wire |
| 52 | Pre-0.7.0 / 0.7.0 apply-gate consume |
| 53 | Pytest + offline fixture golden |

*(Exact active.md wording = Grace; this table is implement intent only.)*

### 46.3 Handoffs

| Need | Owner |
|------|-------|
| Bounds JSON + τ defaults | Ethan |
| Trajectory fingerprint from `invariant_path_effect` rows (if shared) | Gena (assist) |
| Apply executor / allowlist infra | Abelard only if deploy/runtime packaging |
| Formalization / wiki LIVE flip | Colombo |

### 46.4 Acceptance for “KAM implement done”

- Offline battery produces valid `hesperia.kam_perturbation_report.v01`  
- `SISR_*` + `KAM_semantic_score` + `kam_verdict` populated under non-empty `Π*`  
- Inspect path never mutates graph  
- Apply path blocks on `fragile_trajectory` / `insufficient_baseline`  
- Wiki status flipped when code is LIVE  

---

## Closure matrix (40–46)

| ID | Deliverable | Status |
|----|-------------|--------|
| **40** | SPEC → product delta inventory | **COMPLETE** (this packet §40) |
| **41** | SISR product contract | **COMPLETE** (§41) |
| **42** | KAM_semantic_score composite | **COMPLETE** (§42) |
| **43** | kam_verdict bands | **COMPLETE** (§43) |
| **44** | Apply-gate inspect vs apply | **COMPLETE** (§44) |
| **45** | Wiki stubs SISR + KAM_semantic_score | **COMPLETE** (generator stubs + ledger note; regen in same pass) |
| **46** | Felix hand-off 47–53 | **COMPLETE** (§46) |

---

## Blockers / notes for parent

| Item | Severity | Note |
|------|----------|------|
| Grace triage MD missing on disk | Soft | Terms from Ethan ratify; parent may restore triage file later |
| Product KAM absent | Expected | Formalize-only; Felix 47–53 implement |
| Agent SSH cert expired (session) | Out of scope | No cluster SSH required for this formalization |
| Ethan bounds JSON not authored yet | Soft | Felix blocks on ε/τ file for production wire; offline can use SPEC defaults with version tag `spec-v01-defaults` |

---

## NEXT

1. **Parent / Cursor:** mark HES-MATH-BEHAV-40..46 DONE (`report_done`); do not invent product code here.  
2. **Felix:** execute §46 checklist (47–53) against `/data/hesperia/hesperia` — start P2+P3 offline.  
3. **Ethan:** author `kam_perturbation_bounds_v01.json` (ε, τ, band overrides).  
4. **Colombo (later):** after LIVE wire, flip wiki DEAD → LIVE_FULL and re-verify against code.  
5. **Grace (optional):** restore missing MATH-BEHAVIOUR triage MD if still needed as SOT pointer.

---

SIGNED: Researcher (Colombo) | HES-MATH-BEHAV-40..46 KAM product contract | 2026-08-05 | SISR · KAM_semantic_score · kam_verdict · apply-gate · Felix hand-off
