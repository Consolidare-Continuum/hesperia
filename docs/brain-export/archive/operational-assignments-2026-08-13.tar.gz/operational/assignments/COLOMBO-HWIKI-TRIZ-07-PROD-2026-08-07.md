# COLOMBO — HWIKI-TRIZ-07 product / export / reports / guards

**Date:** 2026-08-07  
**Owner:** Colombo  
**Wave:** HWIKI-TRIZ-07  
**Upstream:** TRIZ-01 inventory TRIZ-PROD · operator chose NEXT item 1

## INVENTORY

| Module | Symbols |
|--------|---------|
| `commercial_intelligence.py` | `build_commercial_intelligence_bundle`, corpora compare / product slice |
| `exporters.py` | `export_policy_report`, `export_innovation_radar`, `export_narrative_monitor`, `triz_topology_csv_bundle` |
| `report_builders.py` | `build_contradiction_report`, `build_innovation_report`, `build_narrative_report`, `build_all_reports` |
| `report_extractors.py` | `extract_triz_from_metric_report`, `extract_triz_summary` |
| `guards.py` | meta-area / adjacency / read-only guards (`TrizStructuralViolation`) |

## LANDING

Hub **TRIZ product-export hub** + 5 symbol pages.

## NEXT (Colombo)

1. Leftovers batch (optional): novelty non-Louvain · `time_series` · `meta_synthesis` · `signal_normalization` · `family_weights_sparsify`  
2. Abelard — Chroma `hesperia_wiki` re-ingest when requested  
3. Grace — optional KEEP cycle if further TRIZ depth needed

SIGNED: Research (Colombo) | Hesperia science wiki | 2026-08-07 | HWIKI-TRIZ-07
