# Grace triage — OverAPI + Cursor home giveback (2026-08-07)

**From:** Operator → Grace  
**Budget:** ~70 tasks  
**Scope:** [https://overapi.com/](https://overapi.com/) brain deepen (pointer-only) + Cursor home / brain-repo giveback enhancements.

## Triage outcome

**PROJECT-CREATED** — register [governance/OGH-2026-REGISTER.md](../../governance/OGH-2026-REGISTER.md); exit [governance/OGH-2026-EXIT-CRITERIA.md](../../governance/OGH-2026-EXIT-CRITERIA.md); live **OGH-001..070** on [active.md](../../active.md).

## Prior art

- Ethan pointer landed: [OVERAPI-CHEATSHEETS-EXTERNAL-REFERENCE.md](../../governance/OVERAPI-CHEATSHEETS-EXTERNAL-REFERENCE.md)
- Packet: [ETHAN-OVERAPI-BRAIN-INTEGRATION-2026-08-07.md](ETHAN-OVERAPI-BRAIN-INTEGRATION-2026-08-07.md)

## Execution order

1. **W0** meta (OGH-001..008) — Grace/Ethan/Cursor authority
2. **W1** OverAPI (009..028) — wire/runbook/ingest/rules
3. **W2** home giveback (029..058) — fitness compress/integrate
4. **W3** team stubs (059..066)
5. **W4** close (067..070)

## SuiteCRM

All rows `SUITE: YES` · `TYPE: triage|spec|task`. Post-land: `bash scripts/suitecrm_sync_on_triage.sh` / cron batch.

## Hygiene

- Repaired corrupted **TSDK-066** Link cell on land (**OGH-046 DONE**).
- **OGH-001 DONE** on land (this triage).
- **OGH-006 DONE** — inbox footers + SuiteCRM.
- **OGH-069 DONE** — SuiteCRM batch sync 70/70 (SUITE NR write-back).
- Remaining **66 OPEN** for owners.

SIGNED: Triage (Grace) | OverAPI home giveback | 2026-08-07 | 70-task wave
