# ETHAN — BPM-EA-01 Expert-artifact SOT (department-accepted checkout)

**Date:** 2026-08-05 · **Id:** BPM-EA-01  
**Upstream:** [GRACE-TRIAGE-BPM-EXPERT-ARTIFACT-REBUILD-2026-08-05.md](GRACE-TRIAGE-BPM-EXPERT-ARTIFACT-REBUILD-2026-08-05.md)  
**Live:** `/company/{client}/expert-artifact` · JSON `?format=json`

## Decision (ratified)

**SOT for expert-artifact = department-accepted checkout** — every row where `company_card_department.status = 'accepted'` for the client (same cohort as `GET /company/{client}/accepted`).

| Rule | Spec |
|------|------|
| Include | Bind + template_step origins with dept status `accepted` |
| Exclude | `candidate` / `promoted` / `rejected` dept rows; inventing empty closing-stage cards |
| **Deprecate** | `max(stage_seq)` among accepted rows as “closing hand-off” (lied when mid-funnel had accepts and STAGE-*-6 was empty) |
| Closing stage | Document true last stage (e.g. STAGE-BIOPOLE-6) in caption **only when** it has ≥1 accepted; otherwise caption states checkout-accepted across stages, not «Покупка» |

## Layout (HTML)

1. Header: client name · generated_at · **n** = accepted row count · by_department counts.
2. Body: sections **by `stage_seq` then `department_id`** (stable order). Each card: promoted do_ru (fallback original), subtasks, dept label, reviewed_by/at, artifact/done_when when present.
3. Footer: live snapshot note + link to `?format=json`. Do **not** claim «последний этап» unless last-stage cohort is non-empty **and** page is restricted to it (not default).

## JSON contract (`?format=json`)

```json
{
  "client_id": "CLI-BIOPOLE",
  "client_name": "...",
  "sot": "department_accepted_checkout",
  "n": 27,
  "by_department": {"CEO": 11, "LEGAL": 11, "...": 0},
  "by_stage": {"STAGE-BIOPOLE-4": 22, "...": 0},
  "cards": [ /* same fields as today's expert_artifact_rows objects */ ]
}
```

- `cards` length **MUST** equal `GET /accepted` → `n` (and `accepted` array length).
- Optional future (out of EA-02): `?scope=closing` = accepted rows on client's max stage_seq from `company_stage` only — **not** default.

## Implementation target (EA-02)

- `expert_artifact_rows(rows)` → map **all** `data["rows"]` (already dept-accepted from `fetch`), no max-seq filter.
- `render_expert_artifact_page` + API docstring: SOT language above.
- Restart AGV after code change.

## Acceptance for EA-03 smoke

1. `len(json.cards) == accepted.n` for CLI-BIOPOLE.
2. CEO and LEGAL appear in `by_department`.
3. Page does not title itself as Покупка/оплата unless stage-6 has accepts.

SIGNED: Architecture (Ethan) | BPM-EA-01 | 2026-08-05 | expert-artifact SOT = department-accepted checkout
