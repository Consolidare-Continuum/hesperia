# Biopole outreach letter — fact drain (existing only)

**Superseded for full source set + narration:** [COLOMBO-BIOPOLE-FACTUAL-NARRATION-2026-08-13.md](./COLOMBO-BIOPOLE-FACTUAL-NARRATION-2026-08-13.md) (2026-08-13 press fetch pass).

**Grace 2026-08-13:** Operator ratified letter content as **facts** for Cursor/Detelina IDE. Canon: `detelina_agent_brain/content/identity/BIOPOLE-LETTER-FACTS.md` — **not TG public**. This file remains the drain inventory.

**Role:** Colombo · awareness research  
**Date:** 2026-08-13  
**Source:** Outreach letter (RU) from Сергей Салабаш → Марина (Miro / Khusid intro ask)  
**Rule:** Existing facts only — **no plans, scenarios, asks, or roadmaps**.

**Corroboration keys:**  
- L = asserted in letter  
- G = Gradina site (`/home/biopole/repos/gradina`, about/index/contacts)  
- A = AgroExpert interview 2023-12-26 (agroexpert.md)  
- B = brain/client router (`CLIENTS/biopole.md`, `CLIENTS/gradina2001.md`, AGENTS.md)

---

## 1. Identity / entities (present)

| Fact | Class |
|------|--------|
| Author name: **Сергей Салабаш** (letter) · Gradina board chair **Салабаш Сергей Дмитриевич** (G) · Biopole CEO/founder **Serghei S.** in brain (B) — same person, name variants | L·G·B |
| Family agro enterprise **«Градина»** founded **2001** with father; location **Приднестровье** / **с. Парканы** | L·G·A |
| Gradina contact address: **5722, Приднестровье, с. Парканы, ул. Северная, 1** | G |
| From Gradina arose international project **«БиоПоле» / «Биополе»** promoting own complex resource-saving adaptive agrobiotechnology under that name | L·A |
| Gradina remains agricultural producer; Biopole is the biotech / project brand layered on that history | L·A·B |

## 2. Geography / markets (present-tense in letter)

| Fact | Class |
|------|--------|
| Markets being developed now: **Moldova, Romania, Bulgaria** | L |
| Public press cited for history / activity (URLs in letter): AgroExpert Salabash; NovostiPMR Gradina wheat ~100 c/ha; NovostiPMR Parkany seminar; agri.bg Bulgaria cost article | L (URLs asserted; AgroExpert body fetched OK) |
| AgroExpert (2023): products already trialled in a Bulgarian farm; Gradina supplies Moldova incl. Transnistria; dialogue with other countries | A |

## 3. Production footprint (external corroboration, not in letter numbers)

| Fact | Class |
|------|--------|
| Gradina founded 2001; vineyard **~60 ha**, **20+** grape varieties (IT/UA/BG selection) | G·A |
| AgroExpert: ~**60 ha** perennial (vineyard, orchard, Paulownia) + ~**25 ha** field as demo/experimental | A |
| From 2014 Gradina emphasizes seed wheat + resource-saving biotech to minimize mineral fertilizers / chemical plant protection | G |

## 4. Product / model (letter — facts for IDE; see BIOPOLE-LETTER-FACTS)

| Fact (as stated) | Class |
|------|--------|
| Technology brand: complex resource-saving adaptive agrobiotechnology **«БиоПоле»** | L·A |
| Intellectual / product base historically tied to **ООО «Петербургские Биотехнологии»** (SPb Agrarian University experts) — Gradina = logistics + distribution + consulting in MD/PMR | A (not named in this letter) |
| Cost cut cereals **30–40%**; vineyards plant-protection cost cut **20–30%** | L |
| AgroExpert parallel: fertilizer+fungicide direct spend cut **5–6×**; product cost of production **40–50%** below classical intensive; wheat yields cited **7.5 t/ha** / **5–6 t/ha** (2023 season narrative) | A |
| Only their agrobiotech (today) allows **100% substitution of all soil chemical fertilizers** | L |
| Product efficacy **4–5×** above average market analogues | L |
| Business model: not one-shot prep sales — **ecosystem accompaniment to financial result** + **repeat annual sales** | L |
| Competitors mostly one-shot prep sales | L |
| Mineral fertilizer prices up **70–100%** (macro backdrop cited) | L |
| Crops scope named as addressable without soil chem fertilizers / without fungicides / without insecticides: cereals, legumes, potato, vegetables, vineyards, berries, coffee, etc. | L |
| Regenerative agriculture / non-GMO agro BioTech framed as sector trend | L |

## 5. Value propositions listed (letter)

1. Sharp production cost reduction  
2. Clean / high-nutrition agro product  
3. Soil fertility restore + carbon accumulation + soil microbiome  
4. Ecosystem restore/protect  
5. Stop poisoning groundwater aquifers  
6. Safer labor conditions  
7. Brand image for producers  
8. Competitiveness / resilience  
9. Access to better markets for higher-quality product  

## 6. Operating constraints (present, letter-stated)

| Fact | Class |
|------|--------|
| Growth to date described as **organic only** | L |
| Inbound demand volume **multiples operational capacity** | L |
| Sales cycle **seasonal**; deliveries **2× / year** | L |
| New-farm pilots require **personal control** | L |
| **Founder-led** management is currently a scaling bottleneck (self-assessment) | L |

## 7. Channels / artifacts cited as live

| Artifact | Class |
|------|--------|
| Facebook share URL in letter | L |
| Telegram **`t.me/BiopoleBot`** / **`@BiopoleBot`** | L·B (brain: public sales bot) |
| Public site awareness (brain): **https://biopole.md** | B |
| Client stacks (brain): biopoleMD org, Gradina site repo, AGROPLAN SoftVoya vendor program, Detelina, PlanOffice, Method | B |

## 8. Explicitly **excluded** from this drain (plans / asks — not facts-of-now)

- Universal IT platform build (soil/plant monitoring, C dynamics, green certificates, tech maps, cost analysis…) — **work started** in letter; delivery not established here  
- Horizontal management + game mechanics team model  
- Maximal AI in business processes  
- Smart Money / equity partner scenario  
- Tokenization / community-drive capital scenario  
- Mentorship / strategic partnership ask re: **Andrey Khusid** (Miro) via Marina  
- Advice requests on scaling path  

## 9. Notes

- Letter does **not** name SoftVoya / AGROPLAN / PlanOffice / Detelina (those are B-side facts).
- **Cursor SOT (internal):** `detelina_agent_brain/content/identity/BIOPOLE-LETTER-FACTS.md`

---

SIGNED: Researcher (Colombo) | Biopole letter fact drain | 2026-08-13 | awareness drain-inventory  
SIGNED: Triage (Grace) | Letter facts → Detelina IDE identity (not TG) | 2026-08-13 | operator-ratified-true