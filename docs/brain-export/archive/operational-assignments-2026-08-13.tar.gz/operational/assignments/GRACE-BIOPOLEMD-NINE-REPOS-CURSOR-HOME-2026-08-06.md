# Grace — biopoleMD nine repos + altitudine Cursor home

**Date:** 2026-08-06  
**Invoker:** Operator → Grace  
**Status:** Shells created on GitHub; Cursor home + cold cache bootstrapped on altitudine

## Locked: 9 repos (biopoleMD)

1. `main_data`
2. `acc`
3. `branding-media`
4. `tersagor-bot` (grind+reconfig before deploy)
5. `superset`
6. `agroplan`
7. `agrobiotech-calc`
8. `detelina_agent_brain`
9. `gradina` (gradina2001.md site) — **create if not yet on GitHub**

## Cursor home (end state)

| Item | Path |
|------|------|
| Host | **altitudine** |
| Home | `/home/biopole` |
| Clones | `/home/biopole/repos/` |
| Cold cache | `/home/biopole/upstream/cache_move_out_biopole/` |
| Ledger | `…/ledger/MOVE_LOG.md` |

**End state:** login / Remote-SSH altitudine → open `/home/biopole` in Cursor → all required repos under `repos/` → **do not** operate client work from prichindel brain.

## Cold cache rule

Any brain `.md` / `CLIENTS/` content moved out for Biopole or Gradina → copy into `cache_move_out_biopole` **first**, append `MOVE_LOG.md`, then slim brain to pointer.

## Bootstrap done (this pass)

- User `biopole` on altitudine; group `biopole`; `igareosh` in group
- `/home/biopole/{README,WORKSPACE,docs,repos,upstream/cache_move_out_biopole}`
- Seeded cold copies of `CLIENTS/biopole.md` + `CLIENTS/gradina2001.md/`
- Brain routers updated: `CLIENTS/biopole.md`, `CLIENTS/gradina2001.md/README.md`, `CLIENTS.md`

## Next (fill wave — not this pass)

1. Confirm GitHub `biopoleMD/gradina` exists (operator)
2. Clone nine repos into `/home/biopole/repos/`
3. Migrate disk content from prichindel `/data/CLIENTS/biopole` (+ gradina) into matching repos
4. Detelina contexts + n8n → `detelina_agent_brain`
5. Keep brain as routers only

SIGNED: Triage (Grace) | biopoleMD ×9 + /home/biopole cold cache | 2026-08-06 | Cursor home
