# Grace triage packet — NTP MD curtain (SUITE: NO)

**Date:** 2026-08-05  
**From:** Ethan  
**Triage:** awareness only — **do not** put client IPs/hostnames in active.md or SuiteCRM  
**SUITE:** **NO**

## What

Permanent behind-curtain named NTP client inspect for `ntp1` + chronomaster. Spec + collector live.

- Spec: [governance/SPEC-ETHAN-NTP-MD-CURTAIN-CLIENT-INSPECT.md](../../governance/SPEC-ETHAN-NTP-MD-CURTAIN-CLIENT-INSPECT.md)
- Runbook: `SCRIPT-RUNBOOK-ntp-md-curtain`
- Cron: altitudine `*/15` → `scripts/ntp-md-curtain-collect.sh`
- Durable: `prichindel:/home/igareosh/ntp-md-curtain/` (chmod 700)

## Curtain

Internal MD pool inspection. Never public site, Telegram, CRM, or git commit of lists.

## Status

Implemented 2026-08-05. First verified run: named_ratio ~0.86, majority `.md` ISPs. Abelard owns cron/ops; Ethan owns curtain definition.

SIGNED: Governance (Ethan) | NTP MD curtain | 2026-08-05 | Grace awareness SUITE:NO
