# Grace triage — Rebuild CLI-BIOPOLE expert-artifact from accepted checkout

**Date:** 2026-08-05 · **Id:** BPM-EA-00  
**CSP:** From Cursor → Grace | Reason: operator asked Grace triage to rebuild expert-artifact properly from checked-out accepted  
**Live URL:** http://biopole.prichindel.local/company/CLI-BIOPOLE/expert-artifact  
**JSON:** `?format=json`

## Defect (verified 2026-08-05)

| Fact | Value |
|------|--------|
| Department **accepted** (checkout SOT) | **27** rows · by dept CEO 11 · LEGAL 11 · +5 other · stages 1/2/4 |
| Distinct binds with ≥1 dept accepted | 11 on **STAGE-BIOPOLE-4**, plus stage 1/2 |
| Real closing stage | **STAGE-BIOPOLE-6** «Покупка/оплата» · **0** accepted |
| Current expert-artifact | **22** cards · label «Планирование дальнейших действий» |

**Root:** `expert_artifact_rows()` in `projects/ops-method/scripts/export_accepted_map.py` takes `max(stage_seq)` **among accepted rows**, not the client's true last stage and not the full accepted checkout. Docstring claims “closing / buying-paying”; live page actually dumps mid-funnel stage 4. Operator checkout Accept writes `company_card_department.status=accepted` — that set is the hand-off truth.

## Product intent (locked for this wave)

Rebuild `/company/{client}/expert-artifact` so it is a **proper hand-off document of what is checked out as accepted** — same SOT as `/company/{client}/accepted` (department status = accepted), structured for an outside expert.

**Not:** invent stage-6 cards. **Not:** pretend stage 4 is closing. **Not:** bind-level `status=accepted` only (only 2 legacy binds).

## Wave — BPM-EA

| ID | Owner | Pri | Status intent | Task |
|----|-------|-----|---------------|------|
| **BPM-EA-00** | Grace | P0 | DONE (this packet) | Triage rebuild onto active.md |
| **BPM-EA-01** | Ethan | P0 | OPEN | Spec: expert-artifact SOT = department-accepted checkout; layout (by stage × dept); JSON contract; deprecate max-seq-among-accepted heuristic |
| **BPM-EA-02** | Felix | P0 | OPEN | Implement rebuild in `export_accepted_map.py` + live `/expert-artifact` HTML/JSON; align copy with SOT |
| **BPM-EA-03** | Ava | P1 | OPEN | Smoke: artifact cohort ≡ `/accepted` (or Ethan-ratified subset); CEO/LEGAL present; stamp |
| **BPM-EA-04** | Ethan | P1 | OPEN | Sign READY when EA-02+03 GREEN |

## Acceptance (wave)

1. Opening expert-artifact shows **all current department-accepted** checkout cards (or Ethan-ratified explicit subset documented in EA-01) — **not** only max-seq-among-accepted.
2. Page does **not** claim «последний этап / Покупка» unless STAGE-BIOPOLE-6 actually has accepted rows.
3. `?format=json` same cohort; counts match `/company/CLI-BIOPOLE/accepted`.
4. Smoke stamp under `projects/ops-method/`.

## Code pointers

- `projects/ops-method/scripts/export_accepted_map.py` — `expert_artifact_rows`, `render_expert_artifact_page`
- `projects/ops-method/scripts/agv_api.py` — `GET /company/{client_id}/expert-artifact`, `GET /company/{client_id}/accepted`
- UI entry: Checkout header «Artifact» → new tab

## Assign digest

- **Ethan** — EA-01 · EA-04  
- **Felix** — EA-02  
- **Ava** — EA-03  
- **Grace** — EA-00

SIGNED: Triage (Grace) | BPM-EA-00 | 2026-08-05 | expert-artifact rebuild from accepted checkout
