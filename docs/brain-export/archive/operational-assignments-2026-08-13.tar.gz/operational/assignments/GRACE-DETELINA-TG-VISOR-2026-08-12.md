# Grace — Detelina Telegram back in office visor

**Date:** 2026-08-12 · **Owner:** Grace  
**Trigger:** operator — “Grace detelina telegram back in visor.”  
**Maps to:** DET-046 (office index lists TG health) · product identity DET-REV / DET-044

```
CSP:
From: Operator
To: Grace (triage) → office visor content (+ Abelard deploy path)
Reason: TG face raised; restore P0 visibility on /office/
What changes: triage + www index/SERVICES; not bot runtime
```

## Did

1. Confirmed live `/office/` listed **Telegram bot** as **P2** only.
2. Promoted **@BiopoleBot / Detelina TG** to **P0** on office visor (index + SERVICES) with health link `/tg-bot/health`.
3. Aligned brain copies under `cluster/prichindel/biopole-office-www/` + `BIOPOLE-OFFICE-SERVICES.md`.
4. Deployed to `prichindel:/var/www/biopole-office/`.
5. Closed **DET-046**.

## Result

Visor: https://prichindel-1.tail947b40.ts.net/office/ — P0 row **Detelina TG (@BiopoleBot)** + health.

SIGNED: Triage (Grace) | office visor TG P0 | 2026-08-12 | DET-046
