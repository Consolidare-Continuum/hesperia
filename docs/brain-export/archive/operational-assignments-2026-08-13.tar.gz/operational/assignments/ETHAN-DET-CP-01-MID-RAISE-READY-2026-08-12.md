# Ethan — DET-CP-01 mid-raise READY (platform + IRC peer)

**Date:** 2026-08-12 · **Owner:** Ethan · **Task:** DET-CP-01  
**Parent wrap:** [GRACE-WRAP-DET-RAISE-PLATFORM-2026-08-12.md](GRACE-WRAP-DET-RAISE-PLATFORM-2026-08-12.md)  
**Prior identity:** [ETHAN-DET-RAISE-PLACEMENT-IDENTITY-2026-08-12.md](ETHAN-DET-RAISE-PLACEMENT-IDENTITY-2026-08-12.md) (DET-002/003)

```
CSP:
From: Cursor (AWP)
To: Ethan (architecture / team lead)
Reason: DET-CP-01 mid-raise sign
What changes: authorize resume DET smoke/n8n/seat rows; hold deny-first
```

## Live evidence (2026-08-12)

| Check | Result |
|-------|--------|
| TG health `127.0.0.1:18080/health` | **OK** |
| Container `biopole_telegram_bot` | Up |
| CHROMA-BIOPOLE-OP unit | **active** |
| IRC nick `detelina` | WHOIS logged-in (prichindel→tersagor path) |
| Peer unit on prichindel | `imirc-detelina-presence` **active** |
| tersagor-local detelina peer | **off** (single-instance) |
| `imirc-tersagor-presence` | **active** (untouched) |

## Decision — SIGNED READY

**Mid-raise platform + IRC peer plumbing is READY.**

Resume AWP on held DET rows (smoke / n8n / seat / close): DET-036..038, 040, 042..043, 046..054, 057..060 — still under **talky deny-first** (secretary · manager · sales). Abelard = platform only. IRC peer = observability only.

## Hold the line (unchanged)

- Not a DevOps/IT bot; no IT action surface growth.
- No CHROMA-1 for seat/bot; no new VM.
- Secrets: paths only; never in git/chat.
- Final wave exit remains **DET-060** (full READY) after smokes.

SIGNED: Team lead (Ethan) | architecture context | 2026-08-12 | DET-CP-01 mid-raise READY
