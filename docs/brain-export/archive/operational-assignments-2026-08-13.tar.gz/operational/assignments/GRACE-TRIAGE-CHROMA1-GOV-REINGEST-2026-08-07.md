# Grace triage — CHROMA-1 governance reingest (books-home stamp)

**Date:** 2026-08-07  
**From:** Cursor main EOM pass 3 residual  
**Owner execute:** Abelard  
**Operator:** Grace-triaged now (chat)

## What to triage

CHROMA-1 still retrieves **stale** governance prose that lists IT books on CHROMA-1. Repo stamp [`governance/chroma_books_home.txt`](../../governance/chroma_books_home.txt) + routing contract say **books = CHROMA-2 / colombo-library**. Need **governance (+ related routing docs) delta reingest** into CHROMA-1 so retrieval matches canon.

## Do / Do not

| Do | Do not |
|----|--------|
| Ingest `governance/` (+ `.cursor/rules` chroma routing if needed) to CHROMA-1 with `--keep-layer fpf` | Ingest books / ownCloud BOOKS into CHROMA-1 |
| Verify `query_knowledge` on books-home / CHROMA-2 routing returns stamp-aligned text | Touch CHROMA-2 Papra reindex |
| Keep fpf frozen | Full wipe of knowledge without keep-layer fpf |

## Rows

| ID | Owner | Status seed |
|----|-------|-------------|
| **CHROMA1-GOV-00** | Grace | triage |
| **CHROMA1-GOV-REINGEST-01** | Abelard | OPEN → execute |

## Acceptance

- [ ] `query_knowledge` for books home / chroma routing cites CHROMA-2 / colombo-library (or `chroma_books_home` stamp)
- [ ] No new `layer=books` on CHROMA-1
- [ ] `report_done` + SuiteCRM when SUITE: YES

SIGNED: Triage (Grace) | CHROMA1-GOV | 2026-08-07 | EOM residual
