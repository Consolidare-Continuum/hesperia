# Grace — Detelina TG prompt alignment (corporate sales voice)

**Date:** 2026-08-12 · **Owner:** Grace  
**Trigger:** operator — no technical bot anywhere; corporate-grade seller; deep on primary trio; polite, respectful, insightful, welcoming, informative; no dead 1-sentence answers.

## Aligned surfaces

| Surface | Change |
|---------|--------|
| `src/services/ai/assistant.ts` | SYSTEM_BASE = senior B2B sales consultant; rich answers; tech from CONTEXT; soft multi-paragraph handoff |
| `settings/private_en.yaml` | help / errors / default prompt / assistant_instruction — sales language, no ChatGPT/admin/ИИ |
| `messageHandlers.ts` | user-facing media refusals without “ИИ” tech tone |

## Hold

- Public compartment still deterministic (`assistant-data` only).
- Primary knowledge: `basic.md`, `basic_process.md`, `микобакт.md`, `ризобакт.md`.
- **2026-08-12 green CLEAN EDGE** (follow-on): [GRACE-DETELINA-PROMPT-GREEN-EDGE-2026-08-12.md](./GRACE-DETELINA-PROMPT-GREEN-EDGE-2026-08-12.md) — green company, chemistry→bio redirect without fighting conventional agri.

SIGNED: Triage (Grace) | DETELINA-PROMPT-ALIGN | 2026-08-12
