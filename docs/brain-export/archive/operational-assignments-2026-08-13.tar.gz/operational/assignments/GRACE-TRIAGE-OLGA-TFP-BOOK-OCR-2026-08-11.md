# GRACE TRIAGE — Olga TFP book OCR (signed conference copy)

**Date:** 2026-08-11  
**Project:** `olga-tfp-book-ocr`  
**Operator ask:** Move source from cache; Grace make project for Olga’s book copy; continue when more photos arrive.

## Decision

| Item | Value |
|------|--------|
| Project | **olga-tfp-book-ocr** |
| Source home | `projects/olga-tfp-book-ocr/source/photos/` (batch-1 moved from `.cache_to_sort_out`) |
| Deliverable | `projects/olga-tfp-book-ocr/deliverables/TFP-narcissism-OCR-BOOK.md` |
| Batch 1 | **DONE** — 61 pages (0…60) |
| Next | Operator photo batches → `batch-2+` → Gena OCR from index **61** |

## Active.md rows

| ID | Owner | Status | Notes |
|----|-------|--------|-------|
| OLGA-TFP-OCR-00 | Grace | DONE | Triage + project bootstrap + source move |
| OLGA-TFP-OCR-01 | Gena | OPEN | Continue OCR on next photo batches (append from page 61) |
| OLGA-TFP-OCR-02 | Grace | OPEN | Keep project; intake new batches; remap page subjects when ready |

## Boundaries

- Not Hesperia product; not ops-method invent (#1–#6)
- Transcription fidelity only
- Signed physical book remains operator/Olga custody

## Paths

See [projects/olga-tfp-book-ocr/CONTINUATION.md](../../projects/olga-tfp-book-ocr/CONTINUATION.md).

SIGNED: Triage (Grace) | Olga TFP book OCR | 2026-08-11 | project live
