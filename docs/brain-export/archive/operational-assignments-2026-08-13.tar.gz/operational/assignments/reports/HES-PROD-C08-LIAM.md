# HES-PROD-C08 — Liam: SCRIPT-RUNBOOK smoke pack

**Date:** 2026-08-10

## Smoke pack (altitudine / runtime)

```bash
cd /data/workspaces/hesperia   # or /data/hesperia/hesperia
unset HESPERIA_L6_PERTURBATION HESPERIA_METRIC_EMIT
python3 -c "from runtime.services.engine_analyze_contract import run_engine_analyze as a; r=a('smoke'); assert 'layer_6' not in (r.get('meta') or {}); print('OFF ok')"
HESPERIA_L6_PERTURBATION=1 python3 -c "from runtime.services.engine_analyze_contract import run_engine_analyze as a; r=a('smoke'); assert 'layer_6' in (r.get('meta') or {}); print('ON ok')"
HESPERIA_METRIC_EMIT=1 python3 -c "from runtime.services.engine_analyze_contract import run_engine_analyze as a; r=a('smoke'); assert 'hesperia_metric' in (r.get('meta') or {}); print('METRIC ok')"
python3 -m pytest -q tests/test_l6_perturbation_producer.py tests/test_v7_engine_foundations.py::test_serialize_hex_outputs_includes_path_metric
```

Also file: `scripts/SCRIPT-RUNBOOK-hesperia-l6-metric-smoke.md` (created this pass).

SIGNED: Ops (Liam) | HES-PROD-C08 | 2026-08-10 | runbook
