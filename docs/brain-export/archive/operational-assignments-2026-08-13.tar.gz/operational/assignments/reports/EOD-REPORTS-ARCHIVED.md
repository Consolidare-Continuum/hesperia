# EOD reports — archived 2026-08-11

**Moved out of brain** (not deleted). Canonical:

→ https://github.com/igareosh/hesperia/tree/main/docs/brain-export/archive/eod-reports-2026-08-11.tar.gz

**SHA256:** `e464859d1db816f3af322ea168c4d5b2a311bd071539b8d87eab97a37b78f1a6`

Live EOD blockers: regenerate via `bash scripts/thinking-map-blockers-eod.sh` when needed.
