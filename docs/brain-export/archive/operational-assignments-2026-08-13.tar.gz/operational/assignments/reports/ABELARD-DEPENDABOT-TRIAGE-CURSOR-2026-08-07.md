# Dependabot triage — igareosh/cursor (IDE-only) · 2026-08-07

**Owner:** Abelard · **Cloud Agent:** FORBIDDEN (allowlist stand)  
**Source:** GitHub Dependabot / vulnerabilityAlerts OPEN · `total=22`

## Severity rollup

| Sev | Count | Packages (unique) |
|-----|------:|-------------------|
| CRITICAL | 2 (dup advisory) | **chromadb** (GHSA-f4j7-r4q5-qw2c) |
| HIGH | 11 | brace-expansion, js-yaml, setuptools, wheel, ws |
| MODERATE | 8 | pip, brace-expansion, ws, js-yaml, setuptools |
| LOW | 1 | pip |

## Disposition (IDE)

| Package | Action | Notes |
|---------|--------|-------|
| **chromadb** CRITICAL (GHSA-f4j7-r4q5-qw2c / CVE-2026-45829) | **PIN 0.6.3 — operator hard stop 2026-08-07.** Advisory range `>=1.0.0,<=1.5.9` (0.6.3 out of range). **No bump** until clean crash-fix evidence; **no mass reingest** as bump side-effect. Stamp [chroma_client_pin.txt](../../../governance/chroma_client_pin.txt). LAN-only remains. |
| setuptools / wheel / pip | Bump in `requirements-mcp-venv.txt` on next venv rebuild | Build tooling; not brain runtime surface |
| brace-expansion / js-yaml / ws | Inventory which npm tree owns them; bump or dismiss if unused lockfile noise | Prefer `npm audit` / lockfile on any JS MCP helpers; no Cloud Agent PR |

## Rules

1. Triage and fix **only from IDE / SSH** on this brain.
2. Do **not** open Cloud Agent / Builds on `igareosh/cursor`.
3. Do not auto-merge Dependabot PRs without Abelard review.

## Evidence

- GraphQL `vulnerabilityAlerts` OPEN = 22 (igareosh token).
- REST Dependabot alerts API may 404 without `security_events` scope — GraphQL path is sufficient for triage.

SIGNED: DevOps (Abelard) | dependabot IDE triage | 2026-08-07 | GB-DEP-01
