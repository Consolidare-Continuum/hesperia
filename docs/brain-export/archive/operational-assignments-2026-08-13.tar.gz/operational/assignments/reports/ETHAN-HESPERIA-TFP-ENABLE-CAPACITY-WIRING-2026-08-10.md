# Ethan — Disable default / enable TFP (capacity + dictionaries + wiring)

**Date:** 2026-08-10  
**Board:** `HES-MODTEST-01`  
**CSP:** Grace core GO → Ethan TFP module enable report  
**Repo tip:** `igareosh/hesperia` `e25965a` · runtime `/data/hesperia/hesperia`  
**Speech:** Operator addressed **TFP** — TFP/field-module language allowed; still **not** a medicine-industry product claim.

## Hold the line

| Do | Do not |
|----|--------|
| Enable **TFP as Class B** (module + envelope + TFP packs) | Merge TFP into sealed `/analyze` core physics |
| Switch **session lane** off default Class A lexicon/profile | Pretend geometry lock is 10 areas |
| Use grain **10** for TFP operational pack | Teach 10+2 as default core identity |

**Geometry lock stays:** `AREAS=12`, `FAMILIES_PER_AREA=24`, `TOTAL_FAMILIES=288` (`core/topology/invariant_catalog.py`).  
**TFP operational pack:** 10 areas × 24 families = **240** (indices 0–9); sealed slots 10–11 out of pack via `HESPERIA_AREA_MATH_GRAIN=10`.

---

## 1. What “disable default / enable TFP” means

### Disable default (session lane)

Live `hesperia-analyze-dev` today:

| Knob | Current |
|------|---------|
| Lexicon for sealed `/analyze` | `assets/lexicon/curated` (`A_CORE_STAR_MAP_v0_4_1_3` — **3456** concept keys) |
| `VERSION.yaml` | `calibration.active_profile: default_v1` · `active_calibration_dict_pack: v0_6_0_clr_v052_5` |
| Area-math grain | unset → **12** |
| `HESPERIA_TFP_MODULE_SEALED` | unset → seal **off** |
| Module pipeline list (`assets/config/pipeline.yaml`) | includes `tfp`, but sealed analyze path does **not** drive Class B outputs into public measurement |

**Disable default** = stop treating the **universal Class A lexicon + default_v1 profile** as the active TFP session source of lexical/ontology meaning.

### Enable TFP (Class B)

| Switch | Value / target |
|--------|----------------|
| `HESPERIA_AREA_MATH_GRAIN` | **`10`** (TFP operational pack; legacy `HESPERIA_TEN_AREA_MODULE=1`) |
| Dict / calibration lane | TFP jsonl packs and/or `v0_tfp_cal_wave_002` / pinned TFP pack — **not** bare `dict_*_seed` |
| Module | `hesperia.modules.tfp` (`tfp` / `tfp.v1`) registered; `HESPERIA_TFP_MODULE_SEALED` leave **off** or `warn` for module project; **`block` only for prod freeze** |
| Ontology YAML | `assets/specs/canon/area_structure_tfp.yaml` + `families_structure_tfp.yaml` |
| Data root | `HESPERIA_TFP_MODULE_DATA_ROOT` → `hesperia/modules/tfp/data/tfp_v1` (optional override) |
| Execution face | TFP pipeline / interpret envelope / KME TFP bridge — **not** silent rewrite of sealed `/analyze` A_CORE |

---

## 2. Areas capacity

### Geometry (always)

| Constant | Capacity |
|----------|----------|
| Areas (icosahedral lock) | **12** |
| Default sealed names | GOOD…DECEIT (incl. CREATION, DECEIT) |

### TFP operational pack (`area_structure_tfp.yaml`)

| Item | Capacity |
|------|----------|
| `public_area_count` / listed areas | **10** |
| Domain | `TFP_KERNBERG` · language `ru` |
| Indices | **0–9** only |

| Index | Name (EN) |
|------:|-----------|
| 0 | Drives & Affects |
| 1 | Object Relations |
| 2 | Defensive Operations |
| 3 | Aggression |
| 4 | Perversions |
| 5 | Narcissism |
| 6 | Love / Relational Capacity |
| 7 | Structural Diagnosis |
| 8 | Therapeutic Technique |
| 9 | Treatment Process |

Neighbor notes in YAML still reference full topology vertices 10–11 for graph completeness; **pack math excludes them under grain 10**.

---

## 3. Families capacity

| Layer | Capacity |
|-------|----------|
| Geometry lock | **288** (12 × 24) |
| TFP operational (`families_structure_tfp.yaml`) | **240** (10 × 24) |
| Per TFP area A1–A10 | **24** each (verified) |
| Grain-10 family slice | indices **0–239**; **240–287** pack-excluded |

Also present: `family_embedding_tfp.yaml`, `assets/data/engine_dynamics_v060/tfp/area_inhibition_matrix_tfp.json`, `tfp_signal_calibration_v2.json`, `contradiction_calibration_v1.json`.

---

## 4. Dictionaries available

### A. Engine-dynamics TFP jsonl (primary TFP lexical packs)

| Pack | Rows (approx) | Role |
|------|--------------:|------|
| `dict_a/dict_a_seed.jsonl` | 10 | Tiny default stub — **not** TFP capacity |
| `dict_a/dict_a_tfp.jsonl` | 220 | TFP Dict A |
| `dict_a/dict_a_tfp_ru_core.jsonl` | 119 | RU core |
| `dict_a/dict_a_tfp_ru_speech.jsonl` | 95 | RU speech |
| `dict_a/dict_a_tfp_ru_aligned.jsonl` | 1100 | RU aligned |
| `dict_a/dict_a_tfp_ru_variants.jsonl` | 1632 | RU variants |
| `dict_a/dict_a_tfp_ru_negative.jsonl` | 6 | Negatives |
| `dict_b/dict_b_seed.jsonl` | 10 | Stub |
| `dict_b/dict_b_tfp.jsonl` | 283 | TFP Dict B |
| `dict_b/dict_b_tfp_ru_v060.jsonl` | 9 | RU B thin |

Path prefix: `assets/data/engine_dynamics_v060/dict_{a,b}/`.

### B. Calibration dict packs (`assets/calibration/dicts/`)

| Pack | dict_a | dict_b | notes |
|------|-------:|-------:|-------|
| `v0_6_0_clr_v052_5` (VERSION pin) | 10155 | 62316 | Large default calib (+ dict_c 24000, links 34155) |
| `v0_tfp_cal_wave_002` | 35 | 17 | Explicit TFP wave (small) |
| Also present | | | `v0_6_0_clr_v052_2`, `v0_6_0_clr_v052_4`, `archive_063_minimal` |

Env: `HESPERIA_CALIB_DICT_VERSION=<pack>` → `resolve_dict_file` in Class A `dict_*_module`.

### C. Sealed lexicon maps (default live `/analyze`)

| Asset | Size |
|-------|------|
| `assets/lexicon/curated/A_CORE_STAR_MAP_v0_4_1_3.json` | **3456** concepts |
| Companion B0/B1 family maps under curated/frozen | present |

These are **default Class A** surface — not the TFP RU session dictionaries.

### D. Module data tree

`hesperia/modules/tfp/data/tfp_v1/` — layout live (`corpus/`, `dict_a/`, `dict_b/`, `nlp/`, `provenance/`), but **dict_a/dict_b dirs are empty placeholders** (`.gitkeep`). Lexical mass still lives under `assets/data/engine_dynamics_v060/dict_*_tfp*`.

### E. External brain corpus

CHROMA-1 layer **`tfp_corpus_ru`** (theory/session MD) — research retrieve; not a substitute for Dict A/B wiring into runtime.

---

## 5. Wiring required (execution checklist)

Ordered for Felix / Gena / Abelard after this report:

1. **Grain** — set `HESPERIA_AREA_MATH_GRAIN=10` on the TFP session host (analyze-dev or dedicated TFP unit). Verify USF `macro_domain_vector` len **10**.  
2. **Dict bind** — point Dict A/B loaders (module config `path` and/or calib version) at **`dict_*_tfp*`** (recommend start: `dict_a_tfp_ru_aligned` + `dict_b_tfp`, or promote a merged TFP pack). Do **not** leave `dict_*_seed`.  
3. **Pipeline config** — `assets/config/pipeline.yaml` `module_config.topology.core.area_count` / `metrics.base` still say **12**; for TFP module face, set operational **10** / family pack **240** (or read from classifier) so module math matches grain.  
4. **Ontology load** — ensure TFP faces (`clinical_bridge` / KME / `sphere.topology.load_area_structure_tfp` / file pipeline) load `area_structure_tfp.yaml` + `families_structure_tfp.yaml`, not default GOOD…DECEIT names.  
5. **Module project** — run `tfp.v1` `project()` with seal **off** (or warn); keep `block` for sealed prod only.  
6. **Envelope** — expose TFP vector/profile/conflicts on interpret / TFP pipeline outputs; do not claim sealed `/analyze` A_CORE run is “TFP mode” until lexicon bind is real.  
7. **Optional** — `HESPERIA_TFP_MODULE_DATA_ROOT`, `HESPERIA_TFP_DLCR=1` for DLCR session bundles, signal calib under `assets/data/engine_dynamics_v060/tfp/`.  
8. **Abelard** — if flipping `hesperia-analyze-dev`, write EnvironmentFile then restart; prefer a **separate** TFP port/unit so default core GO lane stays green.  
9. **Grace** — open thin execution rows (Felix dict bind + pipeline config; Abelard unit) after operator picks “same port vs side-by-side”.

### Gap (honest)

There is **no single env today** that flips sealed `/analyze` from A_CORE → TFP RU packs. “Enable TFP” is a **bundle of knobs + loader paths**, not one flag. That wiring is the remaining engineering work.

---

## 6. Recommended next move

**Argue:** Do not overwrite the green default analyze-dev core lane.  
**Propose:** Side-by-side TFP enable (new unit or env profile) with grain 10 + TFP dict bind; keep `:18880` as default grain-12 core.

SIGNED: Architect (Ethan) | TFP enable capacity + wiring | 2026-08-10 | HES-MODTEST-01
