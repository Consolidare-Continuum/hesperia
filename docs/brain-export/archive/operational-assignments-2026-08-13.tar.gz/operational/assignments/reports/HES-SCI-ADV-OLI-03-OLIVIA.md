# HES-SCI-ADV-OLI-03 — Olivia

## read

- `/data/consolidare-continuum/hesperia/tools/verify_public_api_snapshot.py`
- `/data/consolidare-continuum/hesperia/.github/workflows/sealed-runtime-gate.yml`
- `/data/consolidare-continuum/hesperia/assets/schemas/public/public_output_schema.json`
- `/data/consolidare-continuum/hesperia/release/v0.7.2/RELEASE_SCOPE.md`

The snapshot gate requires byte-for-byte equality between the canonical public schema and its frozen snapshot, and CI runs it on main. Version 0.7.2 reports the snapshot unchanged.

## risks/gaps

- `additionalProperties: true` permits additive runtime fields without documenting their contract, so snapshot green alone is insufficient.
- Regenerating the snapshot can normalize intentional drift instead of proving compatibility unless accompanied by explicit review.
- Metric schema validation is separate from the frozen public-output snapshot.

## recommend

**proceed** — keep the existing public snapshot unchanged for default-off B2, add focused metric-envelope schema tests, and require explicit contract/version review before any intentional canonical snapshot update.
