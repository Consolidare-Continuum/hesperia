# HES-SCI-ADV-MAR-03 — Marcus

## read

- `/data/consolidare-continuum/hesperia/EXTENSION_STATUS.yaml`
- `colombo_research/hesperia/HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md` §2c
- `/data/consolidare-continuum/hesperia/docs/iso/ARCHITECTURE_DESCRIPTION.md` §8

The registry marks `clinical_tfp`, `agentic_bridge`, and `hesperia_dev_test` as product-surface `none`; dynamics is internal; TRIZ is optional; fpf_bridge is internal Layer 11. Class B domain/theme/corpus data must remain outside sealed measurement.

## risks/gaps

- Experimental/tooling payloads can become accidental public contracts if emitted under generic `meta` without explicit registration.
- Clinical TFP data or claims would violate the selected B0–B3 scope and sealed data boundary.
- Unwired dynamics and agentic bridge state cannot support current product claims.

## recommend

**proceed** — keep product-surface `none` extensions and all Class B/domain payloads out of sealed contracts; B2 may expose only the versioned Class A metric/IPoV block behind explicit default-off flags.
