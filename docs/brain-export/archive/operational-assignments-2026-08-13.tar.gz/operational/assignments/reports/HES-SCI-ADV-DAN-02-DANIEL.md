# HES-SCI-ADV-DAN-02 — Daniel

## read
- `/data/consolidare-continuum/hesperia/docs/publication/NOVELTY_AND_POSITIONING.md` limits novelty to architectural composition and governance boundary, explicitly not new mathematics.
- `/data/hesperia/hesperia/EXTENSION_STATUS.yaml` marks `clinical_tfp` experimental with `product_surface: none`.
- `/data/altitudine/prichindel.com/colombo_research/hesperia/HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md` keeps TFP clinical work Class B and outside sealed measurement truth.

## risks/gaps
- Market or paper wording can imply clinical capability, efficacy, or product behavior from research collateral that has no product surface.
- Claims about BELL/full IPoW/GCS conflict with the publication document's own deferred-work register.
- “Deterministic” can be overread as clinically validated unless bounded to replayable software outputs.

## recommend
**proceed** — lock claims to deterministic/audited composition; state that clinical TFP is experimental, branch-scoped, and not a product capability; exclude efficacy, diagnosis, treatment, and new-mathematics language.
