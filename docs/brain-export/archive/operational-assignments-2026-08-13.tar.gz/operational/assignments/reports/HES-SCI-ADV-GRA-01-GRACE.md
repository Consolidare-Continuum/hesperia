# HES-SCI-ADV-GRA-01 — Grace

## read

- `active.md` HES-SCI rows 80–126
- `operational/assignments/GRACE-TRIAGE-CC-HESPERIA-SCIENCE-B0-B3-2026-08-10.md`
- SuiteCRM `hesperia` Todo tree (2026-08-10 query)

The board and SuiteCRM both contain the HES-SCI and ADV rows, but the Todo tree also contains older HES-MATH work. The parent sequence is B0 → B1 → B2, with B3 docs allowed in parallel; ADV rows are advisory and non-blocking.

## risks/gaps

- Treating “45 OPEN” as one flat queue hides dependency gates and mixes executable work with advice.
- SuiteCRM listing is awareness, not execution order; `active.md` and parent-wave prerequisites remain authoritative.
- Older HES-MATH rows can compete with B1/B2 unless their overlap is explicitly recognized.

## recommend

**change scope** — prioritize parent P0 gates first (B0 chain, B1 chain, B2 chain), allow B3/ADV read-only work in parallel, and use SuiteCRM only to confirm mirror coverage rather than select execution order.
