# Ethan — TFP separate profile/port (deployed)

**Date:** 2026-08-10  
**Follows:** [ETHAN-HESPERIA-TFP-ENABLE-CAPACITY-WIRING-2026-08-10.md](ETHAN-HESPERIA-TFP-ENABLE-CAPACITY-WIRING-2026-08-10.md)

## Lanes

| Lane | Unit | Port | Profile | Grain pack |
|------|------|-----:|---------|------------|
| **Default core** | `hesperia-analyze-dev` | **18880** | `default` (Class A) | 12 / 288 |
| **TFP Class B** | `hesperia-analyze-tfp` | **18881** | `tfp` | 10 / 240 |

## Env (TFP unit)

File: `/data/hesperia/hesperia/.env.tfp` (canon copy: `cluster/altitudine/systemd/hesperia-analyze-tfp.env`)

- `HESPERIA_ANALYZE_PROFILE=tfp`
- `HESPERIA_AREA_MATH_GRAIN=10`
- `HESPERIA_CALIB_DICT_VERSION=v0_tfp_cal_wave_002`
- `HESPERIA_TFP_MODULE_SEALED=0`

## Code

- `runtime/shipping/analyze_profile.py`
- `/health` announces `analyze_profile`, `pack_areas`, `pack_families`
- Product tip includes `HESPERIA_ANALYZE_PROFILE` in env allowlist

## Install (altitudine)

```bash
sudo cp cluster/altitudine/systemd/hesperia-analyze-tfp.service /etc/systemd/system/
sudo cp cluster/altitudine/systemd/hesperia-analyze-tfp.env /data/hesperia/hesperia/.env.tfp
sudo systemctl daemon-reload && sudo systemctl enable --now hesperia-analyze-tfp
curl -sS http://127.0.0.1:18881/health
curl -sS http://127.0.0.1:18880/health
```

SIGNED: Architect (Ethan) | TFP side-by-side port | 2026-08-10 | :18881
