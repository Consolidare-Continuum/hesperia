# HES-PROD-C04 — Ava: experimental ≠ clinical

**Date:** 2026-08-10

Product copy: L6 producer and metric emit are **experimental inspect faces**, not clinical TFP outputs. RO diacritic path still acceptance-blocked per A04.

SIGNED: QA (Ava) | HES-PROD-C04 | 2026-08-10 | copy
