# Ethan — HES-TFP-OPS100 charter + dual-API + CORE-GUARD (2026-08-10)

**Wave:** HES-TFP-100-00 … 100  
**Status:** Ratified for AWP drain execution.

## CORE-GUARD (sealed)

| Lane | Port | Profile | Pack | Dicts | Notes |
|------|------|---------|------|-------|-------|
| Class A core | **:18880** | `default` | 12 / 288 | A_CORE curated | No TFP `lexical_resolution`; params stay on core |
| Class B TFP | **:18881** | `tfp` | 10 / 240 | `dict_*_tfp*` full_stack + DLCR | Structure maps + interpret/OpenAI + CHROMA-2 retrieve |

- Geometry lock **always 12/288**.
- No sealed merge of TFP into core physics.
- No medicine-industry framing (speech ban until operator addresses TFP framing separately).
- Corpus SoT = **CHROMA-2** `colombo-library` `profile=tfp_ru` (disk `tfp_v1/corpus/sessions` empty ≠ corpus missing).

## Dual-API contract

| Surface | Core | TFP |
|---------|------|-----|
| Health | `analyze_profile=default` pack 12 | `analyze_profile=tfp` pack 10 |
| Analyze | POST `/analyze` | POST `/analyze` |
| Instructor | — | POST `/product/interpret` `mode=deterministic|llm` |
| Agent inquire | `hesperia_router_inquire(face=core)` | `hesperia_router_inquire(face=tfp)` |
| Client helper | `CoreClient(:18880)` | `TfpClient(:18881)` |

**`/product/tfp`:** document-only decision — **not mounted**. Use `/analyze` + `/product/interpret` on `:18881`.

## Module SoT

- Structure: `assets/specs/canon/area_structure_tfp.yaml`, `families_structure_tfp.yaml`
- Dict CAB: sidecar full_stack ≠ sealed lexicon replace
- Teacher = interpret `mode=llm` on TFP face (OpenAI via CC tip key + `.env.openai`)
- Inspector = optional PARTIAL — `output_views` may stay PAUSED without blocking GO

## Agentics

- `thinking_map_outcome` travels in `context_packet` → interpret (existing HSR-11)
- FPF Move ≠ TFP measure (honesty)

SIGNED: Ethan | HES-TFP-OPS100 charter | 2026-08-10 | core sealed / module Class B
