# HES-PROD-B05 — Ava: smoke producer ON

**Date:** 2026-08-10

`HESPERIA_L6_PERTURBATION=1` → `meta.layer_6` present; `COVERAGE_GRADIENT` non-zero on sample text. Runtime smoke PASS.

SIGNED: QA (Ava) | HES-PROD-B05 | 2026-08-10 | ON FD live
