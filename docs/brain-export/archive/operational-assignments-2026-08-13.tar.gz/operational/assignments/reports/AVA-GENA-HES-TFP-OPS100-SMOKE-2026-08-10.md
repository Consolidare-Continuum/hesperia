# Ava / Gena — HES-TFP-OPS100 smoke sheet (2026-08-10)

**Verdict:** **GO (PARTIAL)** — agent+API+teacher+corpus+structure+dicts operational; inspector lane PAUSED.

## Evidence (altitudine)

| Check | Result |
|-------|--------|
| `:18880` /health | `default` pack_areas=12 |
| `:18881` /health | `tfp` pack_areas=10 |
| Core analyze lexical_resolution | **absent** |
| TFP analyze DLCR / matched spans | present (matched≥1 on RU probe) |
| TFP interpret mode=llm | `call_status=ok` provider=openai model=gpt-4o-mini |
| Router decision | ALLOW/WARN acceptable (sample WARN) |
| CHROMA-2 retrieval on interpret | `retrieval_context` status=ok doc_count=4 source=chroma-2_colombo_library |
| Dual client | CoreClient/TfpClient health OK |
| systemd isolation | tfp loads `.env` + `.env.openai` + `.env.tfp`; chroma-2 URL on tfp unit |
| output_views inspector | **PAUSED** — not listening on altitudine |

## Agent face

- Default inquire = core profile
- `face=tfp` → `HESPERIA_ANALYZE_PROFILE=tfp` + MVP retrieval attach

SIGNED: Ava+Gena smoke | OPS100 | 2026-08-10 | GO PARTIAL
