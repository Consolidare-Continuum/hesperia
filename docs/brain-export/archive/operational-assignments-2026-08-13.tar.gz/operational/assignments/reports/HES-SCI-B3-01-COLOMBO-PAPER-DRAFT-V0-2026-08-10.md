# Hesperia: A Deterministic Measurement Boundary for Governed Language-Model Narration

**Paper draft:** v0 — Methods + Systems  
**Date:** 2026-08-10  
**Language:** English  
**Novelty discipline:** architectural composition only; no claim of new mathematics

## Abstract

Language models can produce fluent explanations without exposing a falsifiable relation between the input, the evidence used, and the resulting narration. Hesperia addresses this systems problem by placing a deterministic semantic measurement pipeline before language-model narration and an audit step after it. Raw text is first resolved through controlled lexical evidence and transformed by a fixed, ordered measurement cascade. Certified measurements are then projected into a bounded set of evidence-gated states and legal transitions rather than passed to a model as an unconstrained internal dictionary. The generated narration is subsequently re-measured and compared with the pre-narration state to produce an `ALLOW`, `WARN`, `REVIEW`, or `BLOCK` verdict. The contribution is not a new entropy measure, graph algorithm, dynamical law, or trust calculus. It is the composition of established techniques into an enforceable pre-LLM/post-LLM measurement boundary with deterministic execution, explicit guards, bounded narration, and replayable audit evidence. This draft describes the method, system boundaries, current validation evidence, and reproducibility limits without extending claims beyond verified artifacts.

## Rezumat scurt (RO)

Hesperia introduce o frontieră arhitecturală deterministă între textul brut și narațiunea generată de un LLM. Textul este măsurat printr-un pipeline ordonat și verificabil; numai o proiecție limitată, bazată pe evidence, poate ajunge la LLM, iar rezultatul este re-măsurat și auditat. Contribuția este compoziția sistemului și governance boundary, nu o matematică nouă.

## 1. Problem and design objective

The target problem is not natural-language generation by itself. It is the absence of a mechanically inspectable boundary between source text, structural evidence, permitted interpretation, and generated claims. A post-hoc explanation layer cannot by itself establish that a model used the evidence it cites or stayed within an authorized interpretation scope.

Hesperia therefore treats narration as a downstream, governed operation. Its design objective is:

> Given free text, produce a bounded and replayable structural measurement; certify that measurement; allow optional language-model narration only through evidence-gated states; then compare the narration with the pre-narration measurement.

The founding constraint is that raw wording cannot directly activate semantic families unless it passes through resolved concept evidence or an explicitly marked fallback. This constraint is architectural: it determines what can enter the measurement substrate and what may later be narrated.

## 2. System boundary and execution surfaces

The system is divided into four surfaces that must not be conflated:

1. **Controlled lexical resolution** maps surface spans to resolved concept evidence.
2. **Deterministic measurement** computes the ordered L1–L9 structural read.
3. **Certification and governed narration** expose a bounded state/transition projection to an LLM.
4. **Post-narration audit** re-measures generated output and issues a governance verdict.

The sealed core is distinct from domain branches. TFP and COBALT are applications over core semantics, while MRT is a closed branch on a different grid. A mechanism validated first in one branch does not thereby become branch-exclusive science.

Two read-only analytical subsystems sit beside the core cascade:

- **KME** reduces six bounded primitives into 35 algebraic derived metrics and a fixed-order fingerprint for cross-run comparison.
- **TRIZ analytics** apply a deliberately narrow subset of contradiction and innovation techniques over the concept graph.

Neither subsystem writes new state back into the deterministic measurement cascade.

## 3. Method

### 3.1 Controlled lexical resolution

Raw text is handled only by the lexical resolution stage. Dict A performs surface-span matching but has no direct authority to activate families or areas. Dict B performs concept resolution and disambiguation. The output is attributed concept evidence rather than unqualified word presence.

This separation prevents a surface token from silently becoming a semantic conclusion. Any fallback must be explicit and auditable.

### 3.2 Deterministic measurement cascade

The certified pipeline executes nine ordered layers:

1. **L1 — structural activation census:** coverage, dominance, entropy, concentration, and altitude statistics over attributed tokens.
2. **L2 — topology traversal:** bounded breadth-first traversal over fixed graph topology, with reachability, clustering, and cross-area leakage.
3. **L3 — baseline/shadow comparison:** cosine similarity, Jaccard overlap, signed deltas, and an acceptability gate for a perturbed comparison run.
4. **L4 — evidence retrieval quality:** BM25 retrieval measured for structural family/area alignment and integrity.
5. **L5 — counter-evidence and axiom self-test:** negative-evidence retrieval plus numerical checks of the metric identities required by the system's own vector operations.
6. **L6 — dynamical stability:** depth-growth and coherence measures plus an opt-in finite-difference interface for caller-supplied measured `E(x±ε)` snapshots. The normal path preserves sealed identity defaults when the flag or required measurements are absent.
7. **L7 — cross-layer consistency and decision:** ordered boolean gates, trust classification, aggregate confidence, and a priority-encoded decision status.
8. **L8 — unit standardization:** deterministic projection to fixed integer/percentage scales under declared rounding and clamping.
9. **L9 — human-facing labels:** confidence bands, governance pillars, categorical labels, and action triggers derived from L1–L8 without additional measurement.

Execution order is an invariant enforced by the pipeline runner, not a documentation convention.

### 3.3 L6 perturbation boundary

The L6 interface requires special care because mathematical formulas and end-to-end production are different claims. Commit `29c4350` in the development repository implements flag-gated finite differences from caller-supplied measured base, plus-ε, and minus-ε snapshots. It does not recursively invoke the engine and does not synthesize perturbation values.

When sufficient data are supplied, L6 can compute first differences, central second differences, one-step response magnitude, a Lyapunov-named one-step proxy, dominant-family stability, escape threshold, monotonicity, and explicit fixed-point/period-3 checks. When data are absent or incomplete, each slot keeps its sealed default. The normal `/analyze` path still lacks a producer that executes the perturbed runs. Accordingly, this draft treats the L6 formulas as implemented but the system-level perturbation production path as incomplete.

### 3.4 Certification by ordered guards

Before narration, three distinct guard classes are evaluated in sequence:

- **Sigma:** static artifact shape and schema invariants;
- **Gamma:** execution-order and runtime soundness;
- **Theta:** release and governance eligibility.

The sequence is part of the method. A structurally valid artifact is not automatically execution-sound, and an execution-sound artifact is not automatically eligible for release or narration.

### 3.5 Governed narration

Certified measurements are projected into a bounded state representation. The language model receives evidence primitives, calibrated trust information, and a finite menu of legal transitions; it does not receive unrestricted authority over the raw pipeline dictionary. FGR trust semantics are borrowed from FPF, while their use as a narration-permission boundary is Hesperia-specific composition.

After narration, the output is measured against the pre-narration structural state. Divergence and governance checks produce one of four outcomes: `ALLOW`, `WARN`, `REVIEW`, or `BLOCK`.

## 4. Composition-level contribution

Hesperia does not claim invention of Shannon entropy, Gini concentration, BFS, clustering coefficient, BM25, Jaccard similarity, cosine similarity, Louvain community detection, propositional operators, TRIZ, FPF, or classical metric identities.

The contribution is the following composition:

1. **A pre-LLM/post-LLM measurement boundary:** deterministic structural evidence precedes narration, and generated output is measured afterward.
2. **A sequenced guard triad:** artifact shape, execution soundness, and governance eligibility are separate verdict classes evaluated in order.
3. **Shadow divergence as a governance gate:** perturbation comparison is used to decide whether a result is acceptable for interpretation, not merely to report robustness.
4. **A cross-layer contradiction signal:** contradiction is carried as a measured governance quantity rather than an incidental annotation.
5. **A fixed comparability artifact:** bounded KME primitives and derived metrics form a deterministic cross-run fingerprint.
6. **FGR-calibrated narration permission:** an external trust calculus is applied as the literal boundary for what an LLM may narrate and at what confidence.

These are systems and engineering claims. They do not imply a new theorem or a new foundational mathematical framework.

## 5. Validation evidence

The publication evidence set records a focused router/calibration/product-interpret run of 76 collected tests with exit code 0 at source commit `63a2295b`. This supports the governed LLM-boundary path, not the full repository and not product-market claims.

Additional verified mechanisms include:

- a source-of-truth verification script for router structure and package pinning;
- release-scope records that distinguish shipped features from deferred features;
- build-level determinism checks and a determinism report;
- restored L1–L9 canonical specifications for independent formula inspection.

The L6 perturbation hook was separately verified in development commit `29c4350` by five focused tests, a 37-test layer suite, and Python compilation, as recorded in the Felix outcome report.

The following claims remain outside current validation:

- a separately counted full L1–L9 pipeline test pass in the publication evidence index;
- calibration at the documented 20–50-transcript scale;
- an end-to-end `/analyze` perturbation producer for L6;
- performance and latency benchmarks;
- product-surface claims for the unwired field-dynamics subsystem.

## 6. Reproducibility

Reproduction requires a pinned source revision, version metadata, deterministic seeds, declared numerical tolerances, and the restored layer specifications. The current source set exposes a version-drift issue that this draft does not hide:

- the publication package records values read at commit `63a2295b`, including `system_version 0.6.5`;
- the inspected corporate clone is at commit `38a055652c09abff8e7a36fd2216894f2a795d0b`;
- its working-tree `VERSION.yaml` currently states `system_version 0.7.2` and `release_stage: modular_branches`.

Therefore, the exact version table in `REPRODUCIBILITY_PACKAGE.md` must be treated as a historical snapshot until refreshed against a clean, chosen publication revision. This v0 draft makes no numeric reproduction claim across those revisions.

Stable reproducibility controls documented by the source set include:

- `LOUVAIN_SEED = 42`;
- explicit division guards (`1e-9` or `1e-12` by layer);
- a declared energy-conservation tolerance of `1e-6`;
- fixed calibration/profile pins checked for consistency;
- canonical `34_SPEC`–`42_SPEC` texts for L1–L9.

## 7. Limitations

The method measures structure under a controlled vocabulary and fixed graph; it does not establish semantic truth in an open-world sense. “Markov-like” describes a deterministic transition-matrix shape, not a statistically fitted Markov model. The Lyapunov-named L6 value is a one-step finite-difference proxy, not a literal long-horizon Lyapunov exponent. TFP literature provides domain grounding for downstream interpretation but is not implemented as clinical theory in the core engine. The field-dynamics extension is tested internally but unwired to live product surfaces and is excluded from the evaluated method.

The current evidence supports architecture, deterministic mechanisms, and a focused governed-router test surface. It does not yet support clinical efficacy, comprehensive calibration validity, performance superiority, or market claims.

## 8. Conclusion

Hesperia's defensible novelty is a systems composition: deterministic semantic measurement, ordered certification, bounded LLM narration, and post-narration audit joined into one enforceable boundary. Its scientific credibility depends on preserving the distinction between borrowed techniques, Hesperia-specific wiring, implemented formulas, and end-to-end product integration. The available artifacts support a methods-and-systems paper centered on that boundary, provided that the publication revision is pinned and validation gaps remain explicit.

## Source basis

Primary composition set inspected from `/data/consolidare-continuum/hesperia/docs/publication/`:

- `SCIENCE.md`
- `NOVELTY_AND_POSITIONING.md`
- `METHODS.md`
- `VALIDATION_EVIDENCE.md`
- `REPRODUCIBILITY_PACKAGE.md`

Implementation delta:

- `/data/workspaces/hesperia` commit `29c4350`
- `operational/assignments/reports/HES-SCI-B1-01-FELIX-2026-08-10.md`
- `operational/assignments/reports/HES-SCI-B1-03-COLOMBO-2026-08-10.md`

Library LOCATE note: CHROMA-2 was queried for scientific-software validation and reproducibility context; no external library text was used to enlarge the novelty claim. This v0 remains a composition of the specified project sources.

## NEXT (Colombo)

1. [ ] Refresh the publication package against one clean chosen revision, especially `REPRODUCIBILITY_PACKAGE.md` and the L6 paragraph in `METHODS.md` — owner: Colombo + Felix.
2. [ ] Add a conventional Related Work and bibliography pass using primary sources already registered in `SCIENCE.md`, without changing the composition-only novelty claim — owner: Colombo.
3. [ ] Add full-pipeline and calibration evidence only after exact commands, datasets, counts, and outputs are independently rerun — owner: Ava/Felix.

**Verified exists:** the five publication source documents, governed router evidence, deterministic controls, canonical L1–L9 specs, and flag-gated L6 implementation.  
**Still unverified:** clean publication revision alignment, full-pipeline count, target-scale calibration, performance benchmarks, and end-to-end L6 perturbation production.

SIGNED: Research (Colombo) | Hesperia/scientific context | 2026-08-10 | HES-SCI-B3-01 paper draft v0
