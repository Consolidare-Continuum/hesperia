# Ethan — HES-TEST A01/A02 + E01 (2026-08-10)

## A01 WBS
Ratified Grace triage WBS. **No freezes** confirmed in writing: no corpus/schema/VERSION freeze gates on this board.

## A02 Envelope shape
- Flag: `HESPERIA_TESTING_PARAMS` (default off)
- Analyze attach: `meta.testing_params`
- Interpret/inquire attach: top-level `testing_params` (+ retrieval_context when missing)
- Keys: `testing_params_version`, `calibrated_product_claim`, `freeze`, `honesty_policy`, `parameter_count`, `status_counts`, `parameters[]` (`name`,`value`,`status`,`note?`), `books_areas_inventory`
- Statuses: `live` | `stub` | `uncalibrated` | `partial`

## E01 Agent path
Ratify: **router inquire + product interpret** (+ optional `context_json` / context_rag). Read-only bridge optional later. No act/real-data.

SIGNED: Ethan | HES-TEST A/E | 2026-08-10
