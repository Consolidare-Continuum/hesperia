# HES-SCI-ADV-AVA-02 — Ava

## read

- `/data/consolidare-continuum/hesperia/docs/specs/HSR-V7-OPERATOR-SURFACE-LABELS.md`
- `/data/consolidare-continuum/hesperia/docs/specs/HSR-V7-PRODUCT-COPY.md`
- `scripts/SCRIPT-RUNBOOK-hsr-v7-product-interpret-operator.md`
- `/data/consolidare-continuum/hesperia/runtime/services/hesperia_metric_emit.py`

Existing wording clearly distinguishes generated LLM text, provenance, unsupported evidence, and router decisions. Metric flags currently expose implementation names rather than operator-facing copy.

## risks/gaps

- “Enable IPoV” or “enable metric” can imply validated interpretation rather than an experimental additive measurement block.
- GCS and IPoV have different maturity and should not share one ambiguous switch label.
- UX must not call generated narration a Hesperia answer or call internal geometry “reasoning.”

## recommend

**change scope** — add explicit operator labels: “Emit metric metadata (experimental, default off)” and “Include geodesic descriptor (requires frozen anchor map),” with generated text/provenance wording unchanged.
