# Ethan — HES-TFP-BUNDLE plan (one run · full wiring)

**Date:** 2026-08-10  
**Class:** B (TFP) **with** Class A core — **side-by-side**, not sealed merge  
**Operator ask:** One full bundle so TFP module runs **with** Hesperia core, against **dual API**, **OpenAI API**, **own Hesperia TFP API**, with **agentics** + **FPF thinking MCP**.  
**Board:** Superseded thin BUNDLE rows → **[GRACE-TRIAGE-HES-TFP-OPS100-2026-08-10.md](../GRACE-TRIAGE-HES-TFP-OPS100-2026-08-10.md)** (`HES-TFP-100-00`…`100`, ~101 rows).  

**Operator addendum:** Core stays core (params, no expansion beyond available). Module side keeps wiring + residual. Corpus SoT = CHROMA-2.

```
From: Cursor Context | To: Ethan Context
Reason: Operator asked Ethan plan for full TFP bundle
What changes: architecture authority + acceptance; no sealed-core merge
```

---

## 0. Hold the line (non-negotiable)

1. **Core stays sealed** on `:18880` — grain **12** / 288 · A_CORE curated multiscale.  
2. **TFP stays Class B** on `:18881` — grain **10** / 240 · structure maps · DLCR TFP dict stack · interpret/LLM.  
3. Geometry lock always **12/288**.  
4. Do **not** fold TFP theme into sealed `/analyze` physics.  
5. OpenAI key SoT = CC tip `openai_api_key.txt` (operator override).  
6. Speech: TFP / field module only — no medicine-industry framing.

---

## 1. Target architecture (one bundle · three faces)

```mermaid
flowchart LR
  subgraph agents [Agentics]
    TM[cursor-thinking-map]
    FI[hesperia-fpf-inspect]
    HR[hesperia-router inquire]
  end
  subgraph dual [Dual shipping API]
    C18880[":18880 core Class A"]
    T18881[":18881 TFP Class B"]
  end
  OAI[OpenAI API]
  agents -->|profile=default or explicit| C18880
  agents -->|profile=tfp HESPERIA_ANALYZE_PROFILE / URL| T18881
  T18881 -->|interpret mode=llm| OAI
  C18880 -->|optional interpret| OAI
```

| Face | URL / surface | Role |
|------|----------------|------|
| **Core API** | `http://127.0.0.1:18880` | Hesperia core measurement · grain 12 · no TFP claim |
| **TFP API** | `http://127.0.0.1:18881` | Own Hesperia TFP lane · grain 10 · DLCR dicts · structure · interpret |
| **OpenAI API** | via `HESPERIA_LLM_PROVIDER=openai` + CC key | Teacher narrative on interpret (TFP primary) |
| **Agentics** | MCP `hesperia-router` · `hesperia-fpf-inspect` · `cursor-thinking-map` | Same instructor contract as HTTP when pointed at TFP |

**Instructor (ratified):** `analyze → interpret` same for API and agents.  
**Bundle rule:** Every agentic call that claims TFP **must** bind profile `tfp` or base URL `:18881`.

---

## 2. Baseline (already true — do not re-litigate)

| Piece | State |
|-------|--------|
| Dual ports | `:18880` default · `:18881` tfp |
| TFP math + structure meta | Live |
| TFP Dict A/B via DLCR | Live (sidecar; full stack) |
| `/product/interpret` + OpenAI | Live on `:18881` |
| CC `openai_api_key.txt` + loader | Live |
| Corpus sessions **on disk** | Empty under `tfp_v1/corpus/sessions` — not the library SoT |
| **TFP corpus / library** | **CHROMA-2** via `colombo-library` (`profile=tfp_ru`, `[TFP normalized]` docs) — **present**; **not yet wired** into `:18881` retrieve/teacher |
| Disk inspector_exports | Sample only (6 files) |
| Agent MCP → TFP | **Gap** — router inquire still in-process **default** core |
| Inspector Django | Inactive |
| `/product/tfp` | Not mounted |
| KSI/IRC teacher | Off |

---

## 3. Bundle phases (one run · ordered)

### Phase A — Dual-API contract (Ethan + Olivia)

**Goal:** Written dual-face contract agents and scripts must obey.

| Deliverable | Owner |
|-------------|--------|
| `ETHAN-HESPERIA-DUAL-API-TFP-CONTRACT` — ports, profile env, honesty labels, forbidden claims | Ethan |
| Contract delta note (BF columns / public meta keys) | Olivia |

**Acceptance:** Doc lists exact env (`HESPERIA_ANALYZE_PROFILE`, `HESPERIA_ENGINE_URL` or equivalent) for core vs TFP; says agents must not claim TFP when hitting default.

---

### Phase B — Agentics → TFP binding (Felix + Abelard)

**Goal:** MCP agent path uses **TFP API** when task is TFP.

| Task | Owner | Work |
|------|-------|------|
| B1 | Felix | `hesperia-router` / inquire: honor `HESPERIA_ANALYZE_PROFILE=tfp` **or** `HESPERIA_ENGINE_URL=http://127.0.0.1:18881` (HTTP client to shipping TFP preferred over silent default in-process) |
| B2 | Felix | Pass allowlisted `context_packet` + optional `thinking_map_outcome` into inquire/interpret (already schema-ready) |
| B3 | Abelard | Cursor MCP env / wrapper scripts: TFP profile vars for agent sessions; document in Abelard quick ops |
| B4 | Ava | Smoke: inquire with TFP bind → grain/pack meta or engine fingerprint ≠ default synthetic-only silence; compare `:18880` vs `:18881` |

**Acceptance:** `hesperia_router_inquire` under TFP bind returns TFP-lane evidence (profile meta or lexical_resolution / pack 10) — not default `corpus-unset` + synthetic_family-only as the only story.

---

### Phase C — FPF thinking MCP join (Felix + Colombo)

**Goal:** Agentic FPF thinking map **feeds** TFP instructor, does not replace measurement.

| Task | Owner | Work |
|------|-------|------|
| C1 | Felix | Document + code path: `thinking_map_step` / `hesperia_fpf_map_step` outcome → `context_packet.thinking_map_outcome` → `/product/interpret` on `:18881` |
| C2 | Colombo | Honesty: FPF Move ≠ TFP measurement; NEXT block for research agents |
| C3 | Noah | AI-TEST: LLM sees labeled params + map outcome only; no invented engine numbers |

**Acceptance:** One scripted chain: map step → inquire/interpret on TFP → response carries snapshot id + non-empty LLM narrative grounded in envelope.

**Pin note:** Brain thinking-map pin vs Hesperia `pyproject` pin — Felix records actual versions; do not silently diverge.

---

### Phase D — TFP module + core coexistence (Felix + Ethan)

**Goal:** Module register/envelope clear; core unchanged.

| Task | Owner | Work |
|------|-------|------|
| D1 | Ethan | Ratify: sealed path keeps A_CORE; TFP dicts = DLCR Class B sidecar (already) — optional later “TFP lexicon preference” **only** on `:18881`, never `:18880` |
| D2 | Felix | Optional mount or thin proxy `/product/tfp` → same envelope as interpret+module project **or** document “no mount; use interpret” (pick one; prefer document-first if time) |
| D3 | Felix | Attach testing/params envelope on TFP interpret when `HESPERIA_TESTING=1` (reuse existing testing_params_emit) |

**Acceptance:** `:18880` smoke unchanged grain 12 · `:18881` still 10 + DLCR · no cross-contamination.

---

### Phase E — Corpus + inspector MVP (Colombo + Felix + Abelard)

**Goal:** Ground TFP teacher/API on the **real corpus home** — not empty `tfp_v1/corpus/sessions`.

**Correction (operator 2026-08-10):** TFP library/corpus for this bundle lives on **CHROMA-2** (librarymaster Papra · `colombo-library` MCP · prefer `profile=tfp_ru` / `[TFP normalized]` docs). Disk `inspector_exports` = sample only. CHROMA-1 `tfp_corpus_ru` remains research/brain layer if used — **not** the operator library SoT. Gap was **API/agent retrieval not wired to CHROMA-2**, not “corpus missing from Chroma.”

| Task | Owner | Work |
|------|-------|------|
| E1 | Colombo | Inventory CHROMA-2 TFP-normalized set via `colombo-library` (`profile=tfp_ru`); list doc_ids / themes for MVP retrieve |
| E2 | Felix | Wire TFP interpret `context_packet.retrieval` from **colombo-library** (CHROMA-2) on `:18881` / agent inquire — allowlisted keys only |
| E3 | Abelard | Bring `output_views` inspector **up on altitudine** (dev) against TFP exports — or mark BLOCKED if Django scope too large this run |
| E4 | Ava | Smoke: interpret/inquire TFP-bound body has retrieval from CHROMA-2 (doc_count ≥ 1, snapshot id set) |

**Acceptance:** Teacher/API may claim **CHROMA-2 TFP-normalized library grounding**; must **not** claim full sessions tree on disk until sessions populated. MVP label: `corpus_home=chroma-2_colombo_library`.

---

### Phase F — Bundle smoke matrix (Gena + Ava)

**One run checklist (must all pass):**

| # | Call | Expect |
|---|------|--------|
| F1 | `:18880` `/analyze` | profile default · grain 12 · no TFP dict claim |
| F2 | `:18881` `/analyze` | profile tfp · grain 10 · `lexical_resolution` matched ≥ 0 (prefer ≥ 1 on RU sample) |
| F3 | `:18881` `/product/interpret` `mode=llm` | openai ok · snapshot set · decision ALLOW\|WARN |
| F4 | OpenAI key | loads from CC tip / `.env.openai` |
| F5 | Agent inquire **TFP-bound** | TFP evidence (B4) |
| F6 | thinking_map → interpret chain | C3 |
| F7 | Agent inquire **default** | still core (proves dual, not overwrite) |

**Owner:** Gena execute · Ava sign smoke sheet · Grace wrap.

---

## 4. Board wave (Grace triage IDs)

| ID | Owner | Task |
|----|-------|------|
| **HES-TFP-BUNDLE-00** | Grace | Triage this plan |
| **HES-TFP-BUNDLE-A1** | Ethan | Dual-API + TFP contract (Phase A) |
| **HES-TFP-BUNDLE-A2** | Olivia | Contract delta note |
| **HES-TFP-BUNDLE-B1** | Felix | Bind hesperia-router / inquire to TFP profile or `:18881` |
| **HES-TFP-BUNDLE-B2** | Abelard | MCP/env wrappers for TFP agent sessions |
| **HES-TFP-BUNDLE-B3** | Ava | Dual-API agent smoke |
| **HES-TFP-BUNDLE-C1** | Felix | FPF map outcome → TFP interpret chain |
| **HES-TFP-BUNDLE-C2** | Colombo | Honesty + NEXT (map ≠ measure) |
| **HES-TFP-BUNDLE-D1** | Ethan | Ratify core/TFP coexistence (sidecar forever unless new gate) |
| **HES-TFP-BUNDLE-E1** | Colombo | Corpus MVP inventory |
| **HES-TFP-BUNDLE-E2** | Felix | Retrieval wire into TFP interpret |
| **HES-TFP-BUNDLE-E3** | Abelard | Inspector up **or** PAUSED with reason |
| **HES-TFP-BUNDLE-F1** | Gena | Full bundle smoke matrix F1–F7 |
| **HES-TFP-BUNDLE-99** | Grace | Wrap digest · GO / PARTIAL |

---

## 5. Out of scope this bundle (explicit)

- Merging TFP into sealed core physics  
- Full sessions corpus population (unless E1 finds ready pack)  
- KSI/IRC teacher enable (separate gate)  
- Promoting to `Consolidare-Continuum/hesperia` beyond key file (needs promote gate)  
- Changing `:18880` defaults  

---

## 6. Definition of DONE (bundle GO)

**GO** when F1–F7 green **and** B1 TFP bind landed **and** C1 chain documented+smoked.  
**PARTIAL** allowed if E3 inspector PAUSED — must not block agentics/API GO.  
**NO-GO** if agent MCP still cannot select TFP lane, or `:18880` regresses.

---

## 7. Invoke

Operator: **`AWP`** / **`AWP drain`** after Grace triage rows are OPEN → execute owners in order A → B → C → D → E → F → 99.

SIGNED: Architect (Ethan) | HES-TFP-BUNDLE plan | 2026-08-10 | dual API + OpenAI + TFP API + agentics + FPF MCP
