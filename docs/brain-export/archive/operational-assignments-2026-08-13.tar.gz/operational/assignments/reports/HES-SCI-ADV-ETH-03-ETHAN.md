# HES-SCI-ADV-ETH-03 — Ethan

## read

- `/data/consolidare-continuum/hesperia/VERSION.yaml`
- `/data/consolidare-continuum/hesperia/hesperia/VERSION.yaml`
- `governance/SPEC-ETHAN-HESPERIA-REPO-STATE-MACHINE.md`
- `/data/consolidare-continuum/hesperia/.github/workflows/sealed-runtime-gate.yml`

The root version is `0.7.1` while the mirrored package version is `0.7.2`; the sealed runtime gate includes `validate_version_consistency.py`. Dev is the default state; corporate prod-of-record promotion is deliberate, gated, and only through the approved mirror script after explicit operator GO.

## risks/gaps

- A seal or paper pack built with split version authorities cannot give an unambiguous build/release provenance.
- A version bump alone must never imply promotion.
- The corporate clone's disabled push remote is a structural safeguard and must remain intact.

## recommend

**hold** — do not call the tip seal-ready or promote-ready until version consistency is green and the seal evidence names one commit/version; promotion remains a separate operator-authorized event.
