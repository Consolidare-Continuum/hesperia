# HES-SCI-ADV-DAN-01 — Daniel

## read
- `/data/hesperia/hesperia/core/domain/ksi/flags.py` and `/data/hesperia/hesperia/sphere/kam/flags.py` keep inspect surfaces off by default.
- `/data/hesperia/hesperia/runtime/services/hesperia_metric_emit.py` adds metric/IPoV/GCS data only when emit flags are enabled.
- `/data/hesperia/hesperia/runtime/shipping/env_guard.py` allow-lists KSI/KAM but not METRIC/GCS emit flags.

## risks/gaps
- Flipping defaults would expose new response keys, geometry constants, fingerprints, teacher packets, and potentially configured file-derived bounds.
- KSI enabled-path exceptions are swallowed in `/data/hesperia/hesperia/sphere/router/engine_analyze_bridge.py`, weakening fail-visible security/audit behavior.
- Missing strict-env registration encourages ad-hoc deployment exceptions.

## recommend
**change scope** — retain defaults off; require response-data classification, strict-env allow-listing, explicit per-flag authorization, enabled-path error visibility, schema/payload limits, and logs that record flag state without recording sensitive input.
