# Olivia/Ava — HES-TEST schema + honesty (2026-08-10)

## A04 / C03
Public analyze/interpret schemas stay thin. Testing packet is optional (`HESPERIA_TESTING_PARAMS`); OFF path byte-compatible for absence of `testing_params`.

## C01 / C02
Statuses: live | stub | uncalibrated | partial.  
Operator: `calibrated_product_claim=false` — testing dump ≠ calibrated product claim.

SIGNED: Olivia+Ava | HES-TEST C | 2026-08-10
