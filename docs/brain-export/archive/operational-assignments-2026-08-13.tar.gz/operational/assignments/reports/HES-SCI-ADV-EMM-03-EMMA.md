# HES-SCI-ADV-EMM-03 — Emma

## read
- `/data/hesperia/hesperia/runtime/services/hesperia_metric_emit.py` defines flag behavior and the `meta.hesperia_metric` shape.
- `/data/hesperia/hesperia/runtime/services/engine_analyze_contract.py` is the current attach point.
- `/data/hesperia/hesperia/sphere/router/pre_llm_compiler.py` bypasses that attach point for product interpretation.
- `/data/hesperia/hesperia/tools/verify_public_api_snapshot.py` freezes canonical versus snapshot schema bytes.

## risks/gaps
- Flag semantics, attachment location, router propagation, public-schema status, versioning, and consumer compatibility are spread across code/tests rather than one frozen boundary.
- `HESPERIA_METRIC_EMIT` and `HESPERIA_GCS_EMIT` are missing from strict shipping env allow-list.
- Ethan cannot safely freeze B2 while `/analyze` and `/product/interpret` can expose different metric surfaces.

## recommend
**change scope** — draft an `INTEGRATION-CONTRACT` before Ethan freeze covering flags/defaults, exact JSON paths and optionality, `/analyze`↔router propagation, schema/version rules, env-guard registration, consumer compatibility, off/on acceptance tests, and rollback.
