# HES-PROD-C01 — Olivia: /analyze contract delta

**Date:** 2026-08-10

Documented optional `meta.layer_6` when `HESPERIA_L6_PERTURBATION=1` in ENGINE-ANALYZE-CONTRACT + DOC_INDEX. Public schema snapshot unchanged (meta additive experimental). Emit labels remain experimental.

SIGNED: Product (Olivia) | HES-PROD-C01 | 2026-08-10 | contract delta
