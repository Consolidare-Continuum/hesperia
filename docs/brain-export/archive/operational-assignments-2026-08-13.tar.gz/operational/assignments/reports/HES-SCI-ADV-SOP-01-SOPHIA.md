# HES-SCI-ADV-SOP-01 — Sophia

## read
- `/data/hesperia/hesperia/core/domain/ksi/flags.py`: `HESPERIA_KSI_ENABLED=0`; teacher output remains inspect-only by default.
- `/data/hesperia/hesperia/sphere/kam/flags.py`: `HESPERIA_KAM_ENABLED=0`; KAM is inspect-only by default.
- `/data/hesperia/hesperia/runtime/services/hesperia_metric_emit.py`: `HESPERIA_METRIC_EMIT=0` and `HESPERIA_GCS_EMIT=0`; enabling adds `meta.hesperia_metric` and optional geodesic data.
- `/data/hesperia/hesperia/runtime/shipping/env_guard.py`: KSI/KAM are allow-listed, but METRIC/GCS emit flags are absent.

## risks/gaps
- A prod flag flip changes response shape and compute/data volume; strict shipping mode may reject METRIC/GCS as unknown.
- KSI attachment catches broad exceptions in `/data/hesperia/hesperia/sphere/router/engine_analyze_bridge.py`, so an enabled-path failure can look like a successful response with missing inspection data.

## recommend
**change scope** — permit prod enablement only after env-guard registration, off/on contract diff, load/size checks, and an explicit rollback-to-off smoke; do not treat “default off” alone as readiness.
