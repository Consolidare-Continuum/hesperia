# HES-PROD-B10 — Felix: land METRIC-24/25

**Date:** 2026-08-10
**Commit:** `4e9b296`

`serialize_hex_outputs` now emits `path_metric_cost` / `path_metric_layers` / `path_action_version`. xfail removed; test green. core↛runtime preserved (inline hex_graph formula).

SIGNED: Developer (Felix) | HES-PROD-B10 | 2026-08-10 | landed
