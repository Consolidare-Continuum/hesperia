# HES-PROD-A07 — Sophia: runtime awareness flags off A–C

**Date:** 2026-08-10

## Awareness

| Host | Path | Flags during A–C |
|------|------|------------------|
| Runtime | `/data/hesperia/hesperia` | `HESPERIA_METRIC_EMIT` unset/0; L6 producer unset/0; KSI/KAM off |
| Dev | `/data/workspaces/hesperia` | same defaults; smoke may flip locally only |
| CC tip | `473a3bb` / 0.7.2 | no auto-enable |

Rollback: unset env; restart service if Abelard deployed with flags (should not happen in A–C).

SIGNED: Ops awareness (Sophia) | HES-PROD-A07 | 2026-08-10 | flags remain off
