# Abelard — CHROMA-1 governance reingest 2026-08-07

**Task:** `CHROMA1-GOV-REINGEST-01`  
**Triage:** [GRACE-TRIAGE-CHROMA1-GOV-REINGEST-2026-08-07.md](../GRACE-TRIAGE-CHROMA1-GOV-REINGEST-2026-08-07.md)

## Did

1. Deleted **86** stale chunks matching books-home / routing source prefixes.
2. Ingested refreshed governance routing docs (**100** + **50** chunks) with `--keep-layer fpf`.
3. Staged `.mdc` rules as `governance/ingest_staging/*-rule.txt` (ingest.py only collects `.md`/`.txt`).
4. **No** books ingest; fpf untouched.

## Verify

`query_knowledge` top hit = `governance/chroma_books_home.txt` (`books_home=CHROMA-2`, `forbid_books_ingest_chroma1=1`). BOUNDARIES / USAGE / SPEC layers align.

## SuiteCRM

`CHROMA1-GOV-REINGEST-01` → `b66e5550-d2a5-46cd-8e67-8e4777439396`

SIGNED: DevOps (Abelard) | CHROMA1-GOV-REINGEST-01 | 2026-08-07 | governance delta
