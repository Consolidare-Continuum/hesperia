# HES-SCI-ADV-EMM-02 — Emma

## read
- `/data/altitudine/prichindel.com/governance/SUITECRM-OPERATOR-AWARENESS.md` defines active.md as execution truth and SuiteCRM as a mirrored human-awareness board.
- `/data/altitudine/prichindel.com/governance/DECISION-LOG.md` classifies external-integration-only work as `INTEGRATION-ONLY`.
- HES-SCI ADV rows use `SUITE: YES`, but CRM state does not define Hesperia runtime or science state.

## risks/gaps
- Treating CRM as a product dependency would couple Hesperia delivery to an internal operations UI.
- CRM task status can lag active.md and must not be used as scientific evidence or release eligibility.
- Automatic CRM-to-active backfill is explicitly absent.

## recommend
**proceed** — classify SuiteCRM sync as `INTEGRATION-ONLY` awareness plumbing: one-way active.md metadata mirror, no Hesperia code/runtime dependency, no science-state authority, and no release/promote gate derived from CRM availability.
