# Wrap — conn.local awareness map + agentic API

**Date:** 2026-08-11  
**Session:** execution_host=altitudine · AWP idle (0 OPEN)

## Board

| ID | Status |
|----|--------|
| CONN-00..02 | DONE (active.md) |
| CONN-A-00..03 | DONE (active.md) |

## Live verify

| Check | Result |
|-------|--------|
| DNS `conn` / `conn.local` / `conn.prichindel.local` | → `192.168.100.21` |
| `https://conn.local/` + `/api/map` + `/api/status` | HTTP 200 |
| Hub + agent on prichindel | systemd active |
| Linux reporters (reachable) | up (13) |
| MCP module on prichindel | `get_conn_status` / `get_conn_map` smoke OK; snapshot line present |

## Known offline / optional (not problems)

| Host | Class |
|------|-------|
| izvoras, mugurel | operator edges — intermittent |
| fluturas, fulgusor | cold backup — offline by default |
| lamaita, olgahere | Windows edges |

mx2 is permanent hot tandem with mx1 (Abelard keep-up) — not an expected-offline host.

SIGNED: Cursor | conn.local wrap | 2026-08-11 | CONN + CONN-A
