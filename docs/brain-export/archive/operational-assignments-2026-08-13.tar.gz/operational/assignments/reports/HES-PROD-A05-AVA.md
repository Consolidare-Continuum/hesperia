# HES-PROD-A05 — Ava: HDT → sealed lexical path + RO bar

**Date:** 2026-08-10

## Map

| Item | Path / bar |
|------|------------|
| Sealed normalize | `core.pipeline.lexical.normalize_text` / tokenize path via `r1_r4_pipeline` + lexical_concept pipeline |
| Pattern class | ASCII `[a-z0-9]+`-style strip → diacritics drop |
| RO acceptance bar | Fail closed for “RO product ready” claims until fix or documented canary |
| Owner for fix | Felix + Ethan architecture gate (future row; not silent in B/C) |

SIGNED: QA (Ava) | HES-PROD-A05 | 2026-08-10 | path mapped
