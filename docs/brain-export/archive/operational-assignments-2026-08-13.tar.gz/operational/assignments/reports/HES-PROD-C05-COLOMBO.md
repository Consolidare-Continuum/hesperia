# HES-PROD-C05 — Colombo: paper v0.1 methods

**Date:** 2026-08-10

Paper v0.1 methods note: L6 E(x±ε) producer now available behind `HESPERIA_L6_PERTURBATION` @ `4e9b296`; METRIC-24/25 path cost on hex serialize; METRIC-22/23 emit unchanged (flag). Composition novelty only.

Artifact: extend B3 draft claims with Wave B evidence matrix — see C06 for PARTIAL section.

SIGNED: Researcher (Colombo) | HES-PROD-C05 | 2026-08-10 | v0.1 methods
