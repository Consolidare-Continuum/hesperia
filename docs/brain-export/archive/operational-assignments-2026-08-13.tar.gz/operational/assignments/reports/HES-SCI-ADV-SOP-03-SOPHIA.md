# HES-SCI-ADV-SOP-03 — Sophia

## read
- `/data/altitudine/prichindel.com/scripts/hesperia/mirror-atomic-to-cc-srl.sh` refuses without `CC_PUSH_PERMISSION=1`, preserves CC-only files, overlays corporate notices, commits, and pushes through the dedicated CC key.
- `/data/altitudine/prichindel.com/governance/SPEC-ETHAN-HESPERIA-REPO-STATE-MACHINE.md` defines promote as deliberate, contextualized, never automatic; the running service remains on the dev repo.

## risks/gaps
- The script mutates the CC working tree and pushes; a stale source remote, dirty CC clone, missing inception marker, or wrong key would make promotion unsafe.
- The legacy `ATOMIC_*` names can mislead operators even though the source is now `igareosh/hesperia`.

## recommend
**proceed** — readiness checklist only: verify source `origin/main` SHA and seal, clean CC clone, push-disabled CC `origin`, inception marker, corporate overlay, deploy key, explicit same-chat operator GO, and post-push CC/root SHAs; do not run promote.
