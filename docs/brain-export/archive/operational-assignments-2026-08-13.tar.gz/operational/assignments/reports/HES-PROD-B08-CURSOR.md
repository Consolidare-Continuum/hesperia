# HES-PROD-B08 — Cursor: wiki regen + ingest

**Date:** 2026-08-10

**Outcome:** Deferred full wiki regen this pass (producer honesty captured in B06/B07 reports). Existing `hesperia_wiki` chunks remain authoritative for PARTIAL BELL/NASH; L6 producer LIVE claim is report-backed pending next wiki regen when Colombo schedules HWIKI pass.

SIGNED: Cursor | HES-PROD-B08 | 2026-08-10 | regen deferred; honesty filed
