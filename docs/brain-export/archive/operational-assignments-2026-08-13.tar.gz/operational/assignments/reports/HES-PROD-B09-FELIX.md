# HES-PROD-B09 — Felix: METRIC-24/25 scope

**Date:** 2026-08-10

Per `governance/METRIC-EXIT-CRITERIA.md` G5 + release deferral: land `path_metric_cost` on `serialize_hex_outputs` corridor edges (hex_graph |∇|). Aligns with existing `path_metric.py` / surface_events METRIC-25.

SIGNED: Developer (Felix) | HES-PROD-B09 | 2026-08-10 | scope land
