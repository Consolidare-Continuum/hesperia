# HES-SCI-B3-02 — Ethan novelty claim lock

**Read:** docs/publication/NOVELTY_AND_POSITIONING.md + Colombo paper draft v0.
**Lock:** Novelty = architectural composition only (pre-LLM measure → governed LLM → re-measure). No invented formulas. Cite SCIENCE.md extent taxonomy.
**Decision:** NOVELTY LOCK SIGNED for draft v0.
SIGNED: Governance (Ethan) | AWP | 2026-08-10 | HES-SCI-B3-02
