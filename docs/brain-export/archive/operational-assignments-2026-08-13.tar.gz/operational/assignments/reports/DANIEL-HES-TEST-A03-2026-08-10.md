# Daniel — HES-TEST-A03 security (2026-08-10)

- `HESPERIA_TESTING_PARAMS` default off.
- Allowlisted in `runtime/shipping/env_guard.py`.
- Does not enable act/real-data / write paths.
- Dump is additive metadata for testing loops only.

SIGNED: Security (Daniel) | HES-TEST-A03 | 2026-08-10
