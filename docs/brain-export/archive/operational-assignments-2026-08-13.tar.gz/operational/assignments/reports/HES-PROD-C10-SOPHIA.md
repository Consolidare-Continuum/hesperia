# HES-PROD-C10 — Sophia: prod enable checklist

**Date:** 2026-08-10

| Step | Status |
|------|--------|
| Defaults remain off in systemd/env | REQUIRED |
| Enable only with operator GO + rollback unset | HOLD |
| Runtime tip | `4e9b296` |
| CC promote | separate GO (C12) |

SIGNED: Ops (Sophia) | HES-PROD-C10 | 2026-08-10 | checklist
