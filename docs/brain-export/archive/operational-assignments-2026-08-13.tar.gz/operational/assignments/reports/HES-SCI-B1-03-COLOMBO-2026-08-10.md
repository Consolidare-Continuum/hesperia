# HES-SCI-B1-03 — L6 wiki closure report

**Date:** 2026-08-10  
**Owner:** Colombo  
**Product evidence:** `/data/workspaces/hesperia` commit `29c435038f4a027edbccaaec2f880e619139e9c6`  
**Implementation report:** [HES-SCI-B1-01-FELIX-2026-08-10.md](HES-SCI-B1-01-FELIX-2026-08-10.md)

## Result

The wiki now distinguishes three different facts that were previously collapsed:

1. the L6 formula is implemented in `core/layers/layer_6.py::compute_L6`;
2. execution requires `l6_perturbation_enabled` plus caller-supplied measured `E(x±ε)` snapshots or iterate vectors;
3. the normal `/analyze` path still has no perturbation-run producer and therefore preserves sealed identity defaults.

This supports `LIVE_FULL` at the L6-slot level for formulas that now execute from sufficient measured inputs, while every affected page retains an explicit system-integration limitation.

## PARTIAL → LIVE_FULL

- `COVERAGE_GRADIENT`
- `ENTROPY_GRADIENT`
- `SECOND_ORDER_RESPONSE`
- `DOMINANCE_CURVATURE`
- `ENTROPY_CURVATURE`
- `POTENTIAL_GRADIENT`

Each page now records the exact finite-difference formula, the flag gate, commit `29c4350`, the caller-measurement requirement, and the unchanged default `/analyze` behavior.

## Existing LIVE pages refreshed

- `INPUT_PERTURBATION_RESPONSE`
- `DOMINANT_FAMILY_STABILITY`
- `STABILITY_RADIUS`
- `LYAPUNOV_ESTIMATE / GLOBAL_STABILITY_SCORE`
- `ESCAPE_ENERGY_THRESHOLD`
- `FORCE_ANALOG_MAGNITUDE`
- `MONOTONICITY_CHECK`
- `FIXED_POINT_DETECTION`
- `CYCLE_DETECTION_FUNCTIONAL`

The refreshed text removes obsolete “deferred” language and states what data each computation actually consumes. `LYAPUNOV_ESTIMATE` remains explicitly a one-step finite-difference proxy, not a literal iterated Lyapunov exponent.

## Honest non-closures

`HIT_VECTOR_RANK` and `PRINCIPAL_COMPONENT_ENERGY_RATIO` were incorrectly grouped with LIVE Group-IV pages although commit `29c4350` does not compute rank or PCA. Their wiki status is now `PARTIAL`, with identity constants `1` and `1.0` documented. `EXPONENTIAL_FIT_ERROR` and `POWER_LAW_FIT_ERROR` remain `PARTIAL`.

No claim was made that `/analyze` generates perturbations. No value is inferred from `MASS_AT_DEPTH`.

## Durable source and regeneration

Updated:

- `colombo_research/hesperia/wiki/tools/generate_wiki.py`

Regenerated:

- `pages/`
- `categories/`
- `index.md`
- `index.json`
- `Coverage-Ledger.md`
- `colombo_research/hesperia/wiki_site/` HTML

Commands completed:

- `python3 -m py_compile tools/generate_wiki.py`
- `python3 tools/generate_wiki.py` → 458 pages, 12 category hubs
- `python3 tools/render_wiki_html.py` → 484 HTML files

## Evidence boundary

Verified in source:

- flag default is off;
- missing or incomplete measurements preserve sealed defaults;
- scalar gradients consume measured L1 snapshots;
- second-order response consumes equal-length base/plus/minus output vectors;
- escape and monotonicity consume classified/sample points;
- fixed-point and cycle checks consume explicit iterate vectors.

Still unverified as a product-surface claim:

- a full `/analyze` producer that executes the perturbed runs and supplies the L6 series.

## NEXT (Colombo)

1. [ ] Reclassify the pages from gated-L6 LIVE to end-to-end LIVE only if a future owner wires and validates the `/analyze` perturbation producer — owner: Felix.
2. [ ] Re-run the wiki generator after any rank/PCA or fit-error implementation lands — owner: Colombo.
3. [ ] Refresh the CHROMA-1 wiki mirror after the normal ingest gate permits it — owner: Abelard.

**Verified exists:** flag-gated L6 computation and tests at commit `29c4350`; durable wiki generator records; regenerated Markdown/JSON/HTML.  
**Still unverified:** end-to-end `/analyze` perturbation production.

SIGNED: Research (Colombo) | Hesperia/scientific context | 2026-08-10 | HES-SCI-B1-03 L6 wiki closure
