# HES-PROD-B11 — Ava: smoke METRIC-24/25

**Date:** 2026-08-10

`test_serialize_hex_outputs_includes_path_metric` PASS. Emit matrix: path fields on propagation_corridors; `/analyze` metric emit still flag-gated separately.

SIGNED: QA (Ava) | HES-PROD-B11 | 2026-08-10 | PASS
