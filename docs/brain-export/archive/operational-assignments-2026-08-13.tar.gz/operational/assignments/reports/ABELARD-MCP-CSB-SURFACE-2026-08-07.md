# Abelard — MCP toy surface (altitudine / prichindel / LAMAITA) 2026-08-07

## Did
- Reverted `cursor-thinking-map` in `governance/mcp-config.json` to **SSH prichindel** (local bash launcher correlated with user-MCP drop).
- Synced CSB thinking-map code to prichindel `/data/workspaces/cursor` (`get_cheatsheet_topic`, `library_params`).
- Deployed mcp.json on **altitudine** (user+project); drift=0.
- Handshake: **cursor-thinking-map OK**; chroma/tailscale FAIL separate (alunel path / module).
- LAMAITA: deployed `mcp-config-windows-lamaita.json` (+ thinking-map) to `BvSsh_lamaita` and `igare` `.cursor/`; agent key SSH works.

## Asked
- Full quit+reopen Cursor on **altitudine** (Remote-SSH) so user MCPs reload.
- If Cursor runs **native on LAMAITA**: same full restart after mcp.json deploy.

SIGNED: DevOps (Abelard) | MCP CSB surface | 2026-08-07

## Handshake re-verify (after verify script align to mcp-config)
See agent run 2026-08-07 — chroma→prichindel agent-mcp-knowledge; tailscale→prichindel; thinking-map OK.
