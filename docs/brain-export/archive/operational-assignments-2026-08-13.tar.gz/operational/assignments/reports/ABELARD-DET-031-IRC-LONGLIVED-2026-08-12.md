# DET-031 — Long-lived IRC client prichindel → tersagor

**Owner:** Abelard · **Date:** 2026-08-12

## Did

1. Preflight: cert OK; snapshot critical=0; thinking_map `cluster_ops` → ready.
2. Stopped tersagor-local `imirc-detelina-presence` (single nick).
3. Deployed peer on **prichindel**: TLS `tersagor.prichindel.local:6697` → Ergo.
4. Unit `imirc-detelina-presence` enable+linger; Restart=always.
5. Verified WHOIS `detelina` logged-in; joins `#detelina` / `#biopole-office`.

## Result

| | |
|--|--|
| **Process host** | prichindel `~/imirc-bots/detelina_presence.py` |
| **Mesh** | tersagor Ergo TLS :6697 |
| **Unit** | `imirc-detelina-presence.service` (user, linger) |
| **tersagor local peer** | disabled/stopped |
| **tersagor presence** | untouched (`imirc-tersagor-presence` active) |

SIGNED: DevOps (Abelard) | cluster context | 2026-08-12 | DET-031
