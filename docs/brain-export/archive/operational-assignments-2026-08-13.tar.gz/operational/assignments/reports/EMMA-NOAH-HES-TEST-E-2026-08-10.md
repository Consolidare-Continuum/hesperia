# Emma/Noah — agent contract + AI-TEST (2026-08-10)

## E03 Agent request stub
Request **into** Hesperia: `router-inquire` / `POST /product/interpret` with `HESPERIA_TESTING_PARAMS=1`. Packet returns **along with** sealed envelope (`testing_params` + optional `retrieval_context`).

## E04 AI-TEST plan
1. OFF: no testing_params key.  
2. ON: LLM/agent consumes labeled params only.  
3. Assert no invented “calibrated” claims when `calibrated_product_claim=false`.  
4. Prefer mock LLM / deterministic interpret for CI.

SIGNED: Emma+Noah | HES-TEST E | 2026-08-10
