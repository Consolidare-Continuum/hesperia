# DET-WIRE — Detelina OpenAI + CHROMA-BIOPOLE-OP + agrotech (2026-08-12)

**Owners:** Abelard (platform/ingest/deploy) · Felix (bot path) · Ava (smoke)  
**Face:** @BiopoleBot / Detelina  
**Status:** DEPLOYED (same-day)

## Did

1. **Ingest** `layer=agrotech` into **CHROMA-BIOPOLE-OP** (`127.0.0.1:8002` / collection `knowledge`) — ~422 chunks / 34 files via `/data/CLIENTS/biopole/detelina_rag/ingest_agrotech.py`.
2. **RAG sidecar** `detelina-rag.service` → `http://0.0.0.0:18081` (`/health`, `POST /rag`) — Docker bridge reach via `172.17.0.1:18081`.
3. **Bot path** replaced OpenAI **Assistants** with **Chat Completions** + RAG (`src/services/ai/assistant.ts`). Model **`gpt-5.6-sol`**. No Assistants dependency.
4. **Compose/env:** `OPENAI_MODEL`, `CHROMA_*`, `DETELINA_RAG_*`; container `biopole_telegram_bot` recreated; health `http://127.0.0.1:18080/health` → OK.
5. **Fix:** `gpt-5.6-sol` rejects non-default `temperature` — omit param (API default=1).

## Smoke

| Check | Result |
|-------|--------|
| RAG `/health` | ready, collection `knowledge` |
| RAG ask AGROPLAN | `ok` n=6, `layer=agrotech` |
| OpenAI chat `gpt-5.6-sol` + RAG context | OK (RU agrotech answer) |
| Container → RAG | OK (`fetch` health from container) |
| Bot started + `@BiopoleBot` getMe | OK; webhook empty (long-poll) |

## Hold

- Deny-first secretary/manager/sales (no DevOps).
- No CHROMA-1. No Assistants API.
- RAG bound `0.0.0.0:18081` for Docker — LAN exposure note for Abelard harden later if needed.

## Paths

| | |
|--|--|
| Bot | `/data/CLIENTS/biopole/telegram_ai_bot_repo/` |
| RAG + ingest | `/data/CLIENTS/biopole/detelina_rag/` |
| Pattern borrow | Tersagor chroma/openai adapters (pattern only) |

SIGNED: DevOps (Abelard) + Developer (Felix) | DET-WIRE | 2026-08-12 | OpenAI sol + CHROMA-BIOPOLE-OP agrotech TG

## Follow-up 2026-08-12 — public layer

Operator: public TG must not serve AGROPLAN plans.

- Deleted prior `layer=agrotech` (422 chunks incl. AGROPLAN plans).
- Ingested `layer=agrobiotech_public` (469 chunks): content/science, content/marketing, knowledge science/terminology, marketing brand; seed public-sales-face.
- Bot `DETELINA_RAG_LAYER=agrobiotech_public` + prompt hard-refuse AGROPLAN/SoftVoya/PM.
- Smoke: “what you sell” → Rizobact/Micobact; “What is AGROPLAN?” → refuse + sales redirect.

Internal AGROPLAN corpus = not on public TG (re-ingest as `agrotech_internal` only if a gated face needs it).

## Follow-up — assistant-data primary trio

Canon folder: `/home/biopole-op/repos/detelina_agent_brain/content/assistant-data`

- Added `basic.md` + `biopole-50-RU.md` (from `.cache_to_sort_out`).
- Re-ingest `agrobiotech_public` **137** chunks: **primary** = `basic.md`, `микобакт.md`, `ризобакт.md`; optional = rest of assistant-data + b2b Biopole UTP.
- RAG ranks `priority=primary` first; HNSW miss falls back to primary get.

## Follow-up — deterministic public compartment + soft sales denial

- SDK allowlist: `detelina_rag/public_compartment.py` → only `…/content/assistant-data`.
- Ingest/RAG refuse anything outside that folder (no semantic public/private debate).
- Empty/weak CONTEXT → soft sales handoff (EN/RU), never technical denial.
- Canon note: `operational/assignments/DETELINA-PUBLIC-COMPARTMENT.md`
