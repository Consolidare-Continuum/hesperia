# Ethan — TFP instructor contract (API = agent)

**Date:** 2026-08-10  
**Lane:** `:18881` · profile `tfp` · Class B  

## Contract (ratified for MVP)

| Step | Surface | Role |
|------|---------|------|
| 1 | `POST http://127.0.0.1:18881/analyze` | Measurement — grain-10 pack + structural DLCR `payload.lexical_resolution` when enabled |
| 2 | `POST http://127.0.0.1:18881/product/interpret` | Instructor/teacher — router envelope over the same measurement; `mode=deterministic` or `mode=llm` |
| 3 | `context_packet` | Shared grounding — structure map + corpus MVP under allowlisted keys (`retrieval`, `coherence_hints`, `corpus_snapshot_id`, `observability`) |

**Agents** use the same two HTTP faces (or equivalent in-process `run_structural_analysis` + `run_product_interpret` with `build_tfp_mvp_context_packet()`). No separate agent teacher stack for MVP.

## Pack pins (MVP)

| Asset | Pin |
|-------|-----|
| Area math grain | `10` |
| Structure | `assets/specs/canon/area_structure_tfp.yaml` + `families_structure_tfp.yaml` |
| Dicts | Full merge stack under `assets/data/engine_dynamics_v060/dict_{a,b}/dict_*_tfp*` — **unset** tiny calib OR only use calib as additive when explicitly chosen |
| Corpus snapshot | `tfp_mvp_inspector_exports_v1` (inspector_exports; sessions empty) |

## Honesty labels

- MVP = calibrated **dict stack + structure map + sample exports**, not full `tfp_corpus_ru` / sessions corpus.  
- LLM teacher requires `HESPERIA_LLM_PROVIDER=openai|anthropic` + keys; otherwise mock observe still exercises the instructor path.

SIGNED: Architect (Ethan) | TFP instructor contract | 2026-08-10 | API=agent same path
