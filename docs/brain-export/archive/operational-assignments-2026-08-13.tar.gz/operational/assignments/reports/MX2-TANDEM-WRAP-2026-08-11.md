# Wrap — mx2 permanent hot tandem + Abelard ownership

**Date:** 2026-08-11  
**Session:** `execution_host=altitudine` · `connectivity=lan`  
**CSP:** From: Cursor → To: wrap + Abelard ownership stamp | Reason: operator wrap after mx2 enable

## Mandate

Operator: enable **mx2** permanently as prod alongside **mx1** (tandem good practices). Abelard owns keep-up and failover path from this date.

## Live verify (wrap time)

| Check | Result |
|-------|--------|
| Proxmox VM 109 | `running`, **`onboot=1`** |
| mx2 Docker + Mailcow | **18** containers up |
| `vaporas-smtp-tunnel` on mx2 | active → vaporas `:21026` SMTP, `:21083` ACME |
| mx1 primary tunnel | still `:21025` / `:21082` (unchanged) |
| vaporas promote map | `/etc/postfix/transport.failover` → `:21026` (manual) |
| https://conn.local/api/status | **ok=true**, problems **[]**, mx2 **up** |
| Agent SSH to mx2 | CA + `/etc/ssh/auth_principals/igareosh` |

## Abelard responsibility (from 2026-08-11)

| Duty | Detail |
|------|--------|
| Keep mx2 up | VM onboot, docker enabled, Mailcow stack, tunnel, conn-agent |
| Keep mx1 primary | Do **not** auto-switch transport to mx2 (split-brain) |
| Failover | Manual promote via `transport.failover` only on mx1 outage; then mailbox sync before long-term primary on mx2 |
| Health | conn.local + tunnel banners (`220 mx1` / `220 mx2` on 21025/21026) |
| Canon | [cluster/alunel/MAILCOW-MX-CLUSTER.md](../../../cluster/alunel/MAILCOW-MX-CLUSTER.md) |

## Docs / scripts touched

- `cluster/alunel/MAILCOW-MX-CLUSTER.md` — warm standby → permanent hot tandem
- `cluster/CLUSTER-HOST-REGISTRY.md` · `CLUSTER-NETWORK-INVENTORY-LIVE.md`
- `scripts/cluster/agent-ssh-install-trust.sh` — write `igareosh` principals
- `scripts/cluster/agent-ssh-verify-trust.sh` · bootstrap — mx2 IP **`.71`**
- `scripts/cluster-enforce-dnsmaster-dns.sh` — mx2 no longer “down on purpose”
- Abelard: quick ops + cold-backup inventory + ownership note below

## Explicit non-goals (this wrap)

- No mailbox replication mx1↔mx2 yet
- No automatic `smtp_fallback_relay` to mx2
- No change to Cloudflare MX priorities (51/52)

SIGNED: Cursor | mx2 tandem wrap | 2026-08-11 | Abelard ownership
SIGNED: DevOps (Abelard) | mail tandem keep-up | 2026-08-11 | mx1 primary · mx2 hot
