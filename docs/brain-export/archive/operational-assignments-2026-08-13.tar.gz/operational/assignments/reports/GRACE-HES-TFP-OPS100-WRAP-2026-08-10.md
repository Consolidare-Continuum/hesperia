# Grace wrap — HES-TFP-OPS100 digest (2026-08-10)

**Asked:** AWP drain OPS100 — TFP operational by agent+API+teacher+inspector+corpus+structure+dicts; core sealed.

**Did:** Triage already on board; critical wiring completed in drain:

1. CHROMA-2 retrieve → TFP interpret / agent inquire (`tfp_chroma2_retrieve` + `tfp_mvp_context`)
2. Dual-face clients `CoreClient` / `TfpClient`
3. `hesperia-router` `face=core|tfp` + MCP wrapper env
4. TFP unit `CHROMA_SERVER_URL` / `HESPERIA_TFP_CHROMA_URL` → chroma-2
5. Live smokes: core sealed; TFP OpenAI teacher ok; retrieval doc_count=4

**Result:** **GO (PARTIAL)** — inspector (`output_views`) PAUSED; all other gates green for operational claim.

**Refs:**
- [ETHAN-HESPERIA-TFP-OPS100-CHARTER-2026-08-10.md](ETHAN-HESPERIA-TFP-OPS100-CHARTER-2026-08-10.md)
- [AVA-GENA-HES-TFP-OPS100-SMOKE-2026-08-10.md](AVA-GENA-HES-TFP-OPS100-SMOKE-2026-08-10.md)

SIGNED: Grace | OPS100 wrap | 2026-08-10 | GO PARTIAL
