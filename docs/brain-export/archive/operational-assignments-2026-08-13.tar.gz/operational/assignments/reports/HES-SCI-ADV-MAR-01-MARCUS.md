# HES-SCI-ADV-MAR-01 — Marcus

## read

- `colombo_research/hesperia/wiki/Coverage-Ledger.md`
- `colombo_research/hesperia/wiki/index.json` PARTIAL records
- `operational/assignments/FELIX-HES-MATH-BEHAV-54-62-L5-L6-2026-08-05.md`
- `/data/consolidare-continuum/hesperia/docs/publication/SCIENCE.md`

The current ledger reports 31 PARTIAL items, not the triage estimate of ~38. PARTIAL spans conditional L1/L7 fields, L6 stubs, local/tool-only formulas, and specified-but-unimplemented BELL/NASH/METRIC pieces.

## risks/gaps

- L6 gradient/curvature and `POTENTIAL_GRADIENT` block claims of live perturbation stability.
- BELL `path_mass`, BCI-HP residual, NASH field, and broad HesperiaMetric/IPoV behavior block present-tense implementation claims.
- Conditional profile fields do not block all papers, but must be described as conditional rather than guaranteed output.

## recommend

**change scope** — build a claim-linked PARTIAL annex: block only claims depending on L6 perturbation, BELL/NASH, or unwired metric/IPoV; qualify conditional fields and exclude unrelated tool-local PARTIALs from the B3 blocker set.
