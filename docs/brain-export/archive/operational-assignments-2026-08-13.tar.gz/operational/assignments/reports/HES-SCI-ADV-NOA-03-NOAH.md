# HES-SCI-ADV-NOA-03 — Noah

## read
- `/data/altitudine/prichindel.com/colombo_research/hesperia/wiki/tools/generate_wiki.py` emits source pages plus the exact structured `index.json`.
- `/data/altitudine/prichindel.com/cluster/chroma-server/ingest_hesperia_wiki.py` chunks markdown, deletes the prior `hesperia_wiki` layer, and adds new vector records with source/hash metadata.
- `/data/altitudine/prichindel.com/scripts/SCRIPT-RUNBOOK-hesperia-parameter-wiki.md` requires exact wiki lookup and CHROMA semantic smoke.

## risks/gaps
- Exact register truth and vector retrieval can drift after partial/failed replace-layer ingest.
- Chunk IDs depend on source, index, and prefix text; regeneration can change vector identity even when the semantic item remains.
- A semantic hit does not prove every generated page was ingested.

## recommend
**change scope** — after B0-02 compare generated file count, ingested source set, chunk count, and sampled content hashes; smoke exact `index.json` lookup plus semantic retrieval for KSI/KAM/BELL/NASH/METRIC and one PARTIAL item; assess content consistency, not vector ordering or ID equality.
