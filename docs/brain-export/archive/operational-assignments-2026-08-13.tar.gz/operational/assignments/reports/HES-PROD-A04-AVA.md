# HES-PROD-A04 — Ava: diacritic HDT → acceptance criteria

**Date:** 2026-08-10
**Ref:** HES-SCI-ADV-AVA-03

## Acceptance criteria (written; no sealed edit)

1. **Known failure:** Romanian diacritics `ă â î ș ț` (and uppercase) may silently truncate under sealed `[a-z0-9]+` normalization while HTTP 200.
2. **Product bar (RO path):** RO acceptance **BLOCKED** until architecture/Felix gate lands a sealed lexical fix **or** an explicit canary documents known-failure with operator-visible warning.
3. **This wave:** Criteria only — **no** sealed path mutation in A–C code rows unless a dedicated Felix task + Ethan gate exists (out of HES-PROD-NEXT code scope for silent fix).
4. **Canary:** Wave C smoke / Liam runbook SHOULD include one RO diacritic input and record truncate vs warn outcome.

SIGNED: QA (Ava) | HES-PROD-A04 | 2026-08-10 | criteria written; no sealed edit
