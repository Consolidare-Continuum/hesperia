# Abelard — CHROMA-1 shrink explanation + restore (2026-08-07)

**CSP:** From Cursor | To Abelard | Reason: EOM P0 restore books+fpf | What changes: DevOps authority; mass ingest allowed  
**Operator ask:** restore CHROMA-1 `books`+`fpf` and explain shrink

---

## Shrink explanation

| Metric | 2026-07-14 EOM | 2026-08-07 pre-restore |
|--------|----------------|-------------------------|
| `knowledge` count | **23715** | **7246** |
| `layer=books` | present (QA pass cited) | **0** |
| `layer=fpf` | freeze stamp **288** | **0** |
| `layer=tfp_corpus_ru` | (not audited this pass) | **0** |

**What remained (pre-restore):** only brain-side layers:

`operational` 3079 · `governance` 1545 · `cluster` 1306 · `project` 688 · `hesperia_wiki` 569 · `agents` 59 → **7246**.

**Cause class (factual):** not a CHROMA-1 container death — HTTP 200, sqlite ~7GB on alunel `/data/chroma/data` still growing. Corpus is a **layer-selective loss / non-re-ingest**:

1. **`books` / `fpf` / `tfp_corpus_ru` absent** while governance/ops/wiki present → consistent with whole-repo or selective ingest that **never re-wrote** those layers after a wipe/replace, or an explicit layer delete, followed by continued brain/wiki ingest only.
2. **prichindel `/data/chroma/books_staging` was missing/empty** before this run → books pipeline had nothing to ingest from; BOOKS still live on **cloudmaster** (ex-fulgusor path) `…/igareosh/files/BOOKS` (**997** files, **19G**).
3. **FPF catalog** still locked on **altitudine** `/data/workspaces/fpf/fpf-catalog.jsonl` (**288** rows); freeze stamp claimed 288 while live store had 0 → **stamp/store desync**, not missing source.
4. sqlite mtime **2026-08-07** shows ongoing writes (wiki/brain), not a frozen dead volume.

**Not claimed:** exact one-liner “who deleted books on date X” without journal forensics. Enough for repair: sources exist; layers empty; restore by re-ingest.

---

## Restore actions

### fpf — DONE

- Ingested locked catalog via `agent_mcp_knowledge.ingest --fpf-catalog` → **288** chunks `layer=fpf`.
- MCP `query_knowledge layer=fpf` returns hits.
- Total count **7534** post-fpf (7246+288).
- `governance/fpf_layer_freeze.txt` rewritten FROZEN with restored counts (Spec **not** git-refreshed).

### books — ABORTED (operator 2026-08-07)

- Operator: **books belong on CHROMA-2**, not CHROMA-1. Stop ingest.
- Killed `ingest_books.py` / wrapper on prichindel.
- Purged **1015** partial `layer=books` chunks from CHROMA-1. Post-purge: total **7534** (brain + fpf 288); `books_remaining=0`.
- Staging `/data/chroma/books_staging` left on disk (19G) — not deleted unless asked; CHROMA-2/Papra path is Colombo territory.

### tfp_corpus_ru

- Still **0**. Out of this ask unless operator extends. Script: `cluster/chroma-server/ingest-tfp-corpus-ru.sh`.

---

## Related cluster (same ask)

| Item | Result |
|------|--------|
| **mediamaster** VmOffline | VMID **101** was **stopped** → `qm start 101` → SSH OK. **Alert cleared** (only BiopoleUnreachable remains firing). |
| **BiopoleUnreachable** | Tailscale `100.92.158.21` **offline ~1d** — **client-owned**; not LAN `.65`. Needs operator/client bring-up. |
| **certbot.service** failed | prichindel: renew **trustmaster.prichindel.com** challenges failed (2026-08-07 00:02Z). Tracked **INBOX-AUR-03** — LE/DNS path, not mass restart. |
| **librarymaster LRP host-key / SSH** | From prichindel: `Permission denied (publickey)` after keyscan. Needs agent trust reinstall on librarymaster (**INBOX-AUR-03**). |

SIGNED: DevOps (Abelard) | CHROMA-1 restore | 2026-08-07 | EOM P0
