# HES-PROD-B02 — Felix: implement producer

**Date:** 2026-08-10
**Commit:** `4e9b296` on `igareosh/hesperia`
**Runtime:** `/data/hesperia/hesperia` @ `4e9b296` (Abelard ff-only)

Landed producer + env allowlist + docs flags. Default off; sealed identity unchanged.

SIGNED: Developer (Felix) | HES-PROD-B02 | 2026-08-10 | 4e9b296
