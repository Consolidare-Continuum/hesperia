# Abelard — DET-RAISE platform AWP pass (2026-08-12)

**CSP:** Ethan DET-002/003 SIGNED → Abelard platform  
**Product:** talky secretary/manager/sales deny-first — **not** devops bot identity

## Done this run

| ID | Result |
|----|--------|
| DET-009 | Vault OK: trustmaster + prichindel root + seat |
| DET-010 | Seat `docs/CREDENTIALS-LOCATIONS.md` paths-only |
| DET-011 | `.env` TELEGRAM_BOT_TOKEN from vault |
| DET-012 | trustmaster LOCATIONS + token present |
| DET-013 | `/root/.secrets/biopole/DET-RAISE-TOKEN-TRAIL.txt` |
| DET-014 | **Retarget** existing `biopole_telegram_bot` (no sibling) |
| DET-015 | Unit recreated under `/data/CLIENTS/biopole/telegram_ai_bot_repo` |
| DET-016 | getMe `@BiopoleBot` / id 7803297911 |
| DET-017 | `http://127.0.0.1:18080/health` → **200 OK** |
| DET-018 | nginx `/tg-bot/` present in biopole-method-mesh.conf |
| DET-019 | restart=`always` |
| DET-024 | chroma-biopole-op-docker **active** + heartbeat |
| DET-026 | `CHROMA_SERVER_URL=http://127.0.0.1:8002` + INSTANCE in `.env` |
| DET-044 | BIOPOLE-OFFICE-SERVICES TG row raised / talky label |

## After / still OPEN

| ID | Note |
|----|------|
| DET-020 | PAUSED (Prometheus N/A) |
| DET-021 | Maintenance report line — next maintenance pass |
| DET-025 | Verify seat `mcp.json` chroma → BIOPOLE-OP (check in report) |
| DET-027 | Collection smoke if API shape differs |
| DET-030..036 | IRC peer nick — **not** done this pass (plumbing after) |
| DET-037..040 | n8n/gateway smoke — Ava/Abelard follow |
| Gena DET-022/039 | Deny-lists — not Abelard |

SIGNED: DevOps (Abelard) | DET-RAISE platform AWP | 2026-08-12 | biopole_telegram_bot
