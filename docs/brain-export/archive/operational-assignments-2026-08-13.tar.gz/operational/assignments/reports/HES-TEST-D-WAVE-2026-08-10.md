# D-wave books/areas + honesty (2026-08-10)

## D01 inventory (Cursor)
Reachable without freeze:
- `/data/workspaces/hesperia/assets/lexicon/curated`
- `/data/workspaces/hesperia_mrt/51_DATA__areas_120_authors_books.csv`
- `/data/workspaces/hesperia_mrt/50_DATA__120_books_authors_raw.txt`
Emitted under `books_areas_inventory` when testing ON.

## D02 Abelard
Runtime path uses sealed curated assets; optional mrt maps discovered by absolute path from emit helper (mutable OK). No freeze ceremony. Prod leave flag unset.

## D03 Felix
`retrieval_context` attached on interpret/inquire when testing ON and missing.

## D04 Colombo
Empty retrieval vs attached pack: inventory may be `partial`/`stub`; not a calibrated corpus claim.

SIGNED: Cursor/Abelard/Felix/Colombo | HES-TEST D | 2026-08-10
