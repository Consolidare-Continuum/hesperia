# HES-PROD-B04 — Ava: smoke producer OFF

**Date:** 2026-08-10

`unset HESPERIA_L6_PERTURBATION` → `run_engine_analyze` → no `meta.layer_6`. Runtime + workspace smoke PASS.

SIGNED: QA (Ava) | HES-PROD-B04 | 2026-08-10 | OFF sealed
