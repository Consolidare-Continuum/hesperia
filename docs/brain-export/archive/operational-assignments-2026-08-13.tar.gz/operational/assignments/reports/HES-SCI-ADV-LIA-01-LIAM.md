# HES-SCI-ADV-LIA-01 — Liam

## read
- `/data/altitudine/prichindel.com/colombo_research/hesperia/wiki/tools/generate_wiki.py` is the durable source and regenerates pages, categories, index, coverage ledger, and `index.json`.
- `/data/altitudine/prichindel.com/scripts/SCRIPT-RUNBOOK-hesperia-parameter-wiki.md` requires generator + HTML render, then CHROMA ingest and query smoke.
- `/data/altitudine/prichindel.com/cluster/chroma-server/ingest_hesperia_wiki.py` deletes the whole `hesperia_wiki` layer before rebuilding it in batches.

## risks/gaps
- The ingest has no staged collection/swap or rollback; a failure after deletion leaves the semantic mirror empty or partial.
- The runbook lacks pre-ingest source counts/hash capture and post-ingest count comparison.
- Exact `index.json` MCP and CHROMA semantic queries can diverge without a dual-path smoke.

## recommend
**change scope** — B0-02 automation should preflight generated artifacts, capture file/chunk counts and hashes, ingest only after generation succeeds, then smoke exact wiki MCP plus CHROMA semantic retrieval; document restore/retry for mid-replace failure.
