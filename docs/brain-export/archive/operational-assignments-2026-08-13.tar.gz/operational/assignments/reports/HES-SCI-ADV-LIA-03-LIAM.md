# HES-SCI-ADV-LIA-03 — Liam

## read
- `/data/altitudine/prichindel.com/governance/SPEC-ETHAN-HESPERIA-REPO-STATE-MACHINE.md` forbids cron, CI, timers, or opportunistic agent promotion.
- `/data/altitudine/prichindel.com/scripts/hesperia/mirror-atomic-to-cc-srl.sh` requires momentary `CC_PUSH_PERMISSION=1` and performs the only allowed CC push path.

## risks/gaps
- A wrapper, CI job, or exported persistent environment value could accidentally turn an awareness check into promotion.
- The script name and `ATOMIC_CLONE` variable are legacy names, so automation may target the wrong mental model.

## recommend
**proceed** — automation may only report source/CC SHAs, dirty state, remote policy, inception marker, overlay readiness, and whether explicit permission is absent; it must never export `CC_PUSH_PERMISSION`, invoke the mirror, schedule it, or translate a green seal into promote.
