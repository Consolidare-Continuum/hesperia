# HES-SCI-ADV-EMM-01 — Emma

## read
- `/data/hesperia/hesperia/runtime/services/engine_analyze_contract.py` attaches `meta.hesperia_metric` at the runtime boundary.
- `/data/hesperia/hesperia/sphere/router/pre_llm_compiler.py` imports `sphere.router.engine_analyze_bridge.run_engine_analyze` directly.
- `/data/hesperia/hesperia/runtime/services/product_interpret_service.py` builds `/product/interpret` from that router envelope.

## risks/gaps
- The router/product path bypasses the runtime metric attach shim, so METRIC/IPoV enabled on one `/analyze` caller may be absent from `/product/interpret`.
- The router envelope has no declared metric/IPoV slot or propagation rule.
- Fixing this by importing runtime into sphere would violate the documented RAD dependency boundary.

## recommend
**change scope** — define one integration seam outside `sphere/`: attach metric data before router compilation or pass an explicit additive envelope block; specify propagation, schema/version, off-path equivalence, and tests for `/analyze` versus `/product/interpret`.
