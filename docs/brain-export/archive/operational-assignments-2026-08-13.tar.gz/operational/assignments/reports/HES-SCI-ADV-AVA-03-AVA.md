# HES-SCI-ADV-AVA-03 — Ava

## read

- `inbox.md` entry dated 2026-07-26
- `/data/consolidare-continuum/hesperia/EXTENSION_STATUS.yaml`
- `operational/assignments/ETHAN-HESPERIA-DEV-TEST-APPROVAL-2026-07-26.md`

HDT found that sealed normalization uses `[a-z0-9]+`; Romanian `ă/â/î/ș/ț` can silently truncate while the API still returns 200. The diagnostic tool is approved, but sealed correction requires a separate architecture/Felix gate.

## risks/gaps

- Successful HTTP status masks semantic data loss.
- RO paper abstracts or smoke strings could appear accepted while being normalized incorrectly.
- Fixing normalization inside B1/B2 would expand sealed-code scope and confound regression attribution.

## recommend

**hold** — keep RO-path product acceptance blocked and run an explicit diacritic canary/known-failure check during the B wave; do not fold the sealed normalization fix into B1 or B2.
