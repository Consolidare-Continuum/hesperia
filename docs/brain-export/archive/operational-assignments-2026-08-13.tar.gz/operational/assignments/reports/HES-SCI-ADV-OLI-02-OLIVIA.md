# HES-SCI-ADV-OLI-02 — Olivia

## read

- `/data/consolidare-continuum/hesperia/docs/specs/KSI-WIRE-SURFACE.md`
- `/data/consolidare-continuum/hesperia/tests/domain/ksi/test_ksi_analyze_wire.py`
- `/data/consolidare-continuum/hesperia/runtime/shipping/env_guard.py`

KSI is additive and default-off. Existing tests cover no key when off, an inspect-only `ksi` block when on, optional `phi_trace`, env allowlisting, hybrid-retrieve reuse, and `apply_allowed=false`.

## risks/gaps

- Test coverage is fixture-heavy and does not by itself prove live endpoint parity, malformed config behavior, or simultaneous KSI/METRIC flags.
- `HESPERIA_KSI_TEACHER_PACKET` defaults on when KSI is enabled, increasing response size and nested schema surface.
- Any live LLM-teacher path must remain separate from sealed apply.

## recommend

**proceed** — add an off/on matrix for KSI × METRIC on `/analyze`, assert no mutation when off, stable additive keys when on, fail-safe config handling, and permanent inspect-only/apply-blocked behavior.
