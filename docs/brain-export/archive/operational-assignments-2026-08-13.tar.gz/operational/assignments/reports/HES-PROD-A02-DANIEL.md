# HES-PROD-A02 — Daniel: security advise flags defaults-off

**Date:** 2026-08-10

## Advise

| Flag / face | Default | Exposure if flipped |
|-------------|---------|---------------------|
| `HESPERIA_METRIC_EMIT` | off | Adds `meta.hesperia_metric` — experimental inspect surface only |
| L6 `perturbation_enabled` / future producer env | off | Extra L1/L2 work + finite-diff fields; not clinical |
| KSI / KAM | off | Additive inspect; keep off in prod A–C |
| `agentic_bridge` act/real-data | off | HOLD — Wave D |

**Recommendation:** Keep all defaults off through Waves A–C. No prod enable without Sophia checklist + operator GO.

SIGNED: Security (Daniel) | HES-PROD-A02 | 2026-08-10 | defaults-off ratified
