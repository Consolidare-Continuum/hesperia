# DET-036 — Ava: Lounge peer nick visible, no flap

**Owner:** Ava · **Date:** 2026-08-13 · **AWP** · packet `pkt-workflow-proceed` · thinking_map `team_ops` CONTINUE

## Did

Smoke against live Ergo (same mesh Lounge uses as **tersagor-ergo**):

1. **Unit** `imirc-detelina-presence` on prichindel: `active (running)` since 2026-08-12 19:54:55 UTC (~2h20m); **NRestarts=0**.
2. **Journal** last 2h: no reconnect/disconnect/flap lines.
3. **WHOIS `detelina`:** account online; channels `#detelina` `#biopole-office` `#agents-debug`; secure connection; idle ~8431s (stable session).
4. **NAMES:** `detelina` present in all three channels alongside Lounge operator nick `@igareosh` (Lounge user `igareosh.json` / container `thelounge` Up).

## Result

| Check | Outcome |
|-------|---------|
| Peer nick visible on mesh | **PASS** |
| Visible in Lounge-relevant channels | **PASS** (`detelina` in NAMES; `igareosh` already joined — Lounge sees same roster) |
| No flap | **PASS** (NRestarts=0; continuous WHOIS idle; empty reconnect journal) |

**Note:** Fresh TLS client with default CA verify failed (`certificate has expired` on leaf). Presence unit already connected; smoke used unverified TLS for WHOIS only. Leaf renew = Abelard if browsers/Lounge complain — out of DET-036 scope.

SIGNED: Frontend/UX (Ava) | DET-036 Lounge smoke | 2026-08-13 | peer nick stable
