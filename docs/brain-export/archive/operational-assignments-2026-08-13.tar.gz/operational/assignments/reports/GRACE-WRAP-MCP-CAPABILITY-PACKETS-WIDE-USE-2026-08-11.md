# Grace wrap — MCP capability packets · APPROVED for wide use

**Date:** 2026-08-11  
**From:** Cursor (AWP drain + proceed wire)  
**To:** Grace (wrap / approve)  
**Status:** **APPROVED · WIDE USE**  
**Authority:** Grace triage wrap (operator invoke 2026-08-11) · Cursor happy report prior

---

## Decision

**ADOPTED — prichindel.com-wide** when fit.

MCP **capability packets** (Goose-drain absorb: recipes → packets, tool allowlist mindset, payload distrust, second-look intent — **no Goose entity**) are **approved for wide use** by all agents under this brain.

| Layer | Binding |
|-------|---------|
| **Hard on AWP/proceed** | `SCRIPT-RUNBOOK-mcp-capability-packets` — mandatory Table A |
| **Wide use (adds permission)** | Any agent may select/compose a `packet_id` for multi-step MCP work when fit — not only AWP |
| **SOT** | [CURSOR-MCP-WIDE-CAPABILITY-PACKETS.md](../../governance/CURSOR-MCP-WIDE-CAPABILITY-PACKETS.md) · wide-use [MCP-CAPABILITY-PACKETS-WIDE-USE.md](../../governance/MCP-CAPABILITY-PACKETS-WIDE-USE.md) |

Hard gates (cluster preflight, approvals, thinking-map, CI soft) are **not** weakened.

---

## Received artifacts (canon)

| Artifact | Role |
|----------|------|
| [CURSOR-MCP-WIDE-CAPABILITY-PACKETS.md](../../governance/CURSOR-MCP-WIDE-CAPABILITY-PACKETS.md) | Drain + seed packets + reject list |
| [MCP-CAPABILITY-PACKETS-WIDE-USE.md](../../governance/MCP-CAPABILITY-PACKETS-WIDE-USE.md) | Wide-use decision (this wrap) |
| [SCRIPT-RUNBOOK-mcp-capability-packets.md](../../scripts/SCRIPT-RUNBOOK-mcp-capability-packets.md) | AWP/proceed required runbook |
| [ETHAN-TARGETED-RUNBOOKS-MANDATORY.md](../../governance/ETHAN-TARGETED-RUNBOOKS-MANDATORY.md) | Table A trigger |
| [SCRIPT-RUNBOOK-workflow-proceed-gates.md](../../scripts/SCRIPT-RUNBOOK-workflow-proceed-gates.md) | Umbrella gate row |
| `scripts/workflow_driver.py` | Passport `packet_id` hard gate |
| `.cursor/rules/cursor-mcp-capability-packets.mdc` | Always-on agent rule |
| [ETHAN-MCP-PLUGIN-SHORTLIST.md](../../governance/ETHAN-MCP-PLUGIN-SHORTLIST.md) | Goose entity reject / packets adopt |

**Explicit rejects (hold the line):** Goose entity · Goose Desktop/CLI/Bot · recipe YAML as second SOT · fail-open silent adversary LLM.

---

## Outcome

| Gate | Status |
|------|--------|
| Drain absorbed (no entity) | **DONE** |
| AWP hard gate + passport | **DONE** |
| Mandatory runbook Table A | **DONE** |
| Wide use approved | **DONE** (this wrap) |
| Commit/push to prichindel for remote `get_runbook` | **OPEN** — Abelard/Cursor when operator asks push |
| Ethan CCB Arch Impact YES row | **optional ratify** — Grace ops wide-use stands |

---

## Assign

**Assign to: All agents (Cursor, Abelard, Gena, Felix, Colombo, team)** — use capability packets on AWP/proceed (mandatory) and elsewhere when fit (wide use).  
**Assign to: Cursor / Abelard** — commit+push when operator requests so prichindel MCP runbook discovery sees the new file.

---

SIGNED: Triage (Grace) | MCP capability packets wide use | 2026-08-11 | APPROVED · no Goose entity

**CCB / Cursor main (2026-08-11):** Operator AWP — polish required. **Ethan CCB ratified** Arch Impact YES row (AWP integrate packets). **Cursor main endorses** commit/push so prichindel `get_runbook` sees the runbook. Neither blocks daily use on altitudine; push completes remote discoverability.