# HES-SCI-B0-02 — Cursor wiki ingest

**Date:** 2026-08-10
**Did:** `bash cluster/chroma-server/ingest-hesperia-wiki.sh` → Removed layer=hesperia_wiki; Added **569** chunks.
**Smoke:** `query_hesperia_wiki(KSI-Inspector)` LIVE_FULL; `query_knowledge(layer=hesperia_wiki)` returns KSI-Inspector/MISSING_BRIDGE/bridge_need_score.
**Result:** PASS. B0-03 clear.

SIGNED: Cursor | AWP drain | 2026-08-10 | HES-SCI-B0-02
