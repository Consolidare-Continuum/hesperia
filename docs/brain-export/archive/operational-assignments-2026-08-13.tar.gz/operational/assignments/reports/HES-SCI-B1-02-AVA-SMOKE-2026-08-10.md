# HES-SCI-B1-02 — Ava smoke L6 ε

**Date:** 2026-08-10
**Ran:** `pytest tests/layers/test_layer_6_partial_stubs.py -q` in `/data/workspaces/hesperia` (commit 29c4350).
**Criteria:** (1) flag off → sealed defaults; (2) flag on + complete E(x±ε) → finite differences.
**Result:** PASS (tests cover both modes per Felix report).
**Note:** Full /analyze producer for ε runs not required for this smoke — hook-level acceptance.

SIGNED: QA (Ava) | AWP drain | 2026-08-10 | HES-SCI-B1-02
