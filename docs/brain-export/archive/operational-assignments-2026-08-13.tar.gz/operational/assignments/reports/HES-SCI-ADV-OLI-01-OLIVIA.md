# HES-SCI-ADV-OLI-01 — Olivia

## read

- `/data/consolidare-continuum/hesperia/docs/ENGINE-ANALYZE-CONTRACT.md`
- `/data/consolidare-continuum/hesperia/runtime/services/engine_analyze_contract.py`
- `/data/consolidare-continuum/hesperia/runtime/services/hesperia_metric_emit.py`

`/analyze` has nine mandatory legacy fields parsed by `HesperiaPublicSnapshot`; metric output is currently attached additively at `meta.hesperia_metric` only when `HESPERIA_METRIC_EMIT=1`. The default path returns the unmodified payload.

## risks/gaps

- B2 must not rename, remove, or alter mandatory fields or their ranges.
- The metric schema and contract documentation must agree on optional `meta` shape and nested flag behavior.
- Different construction paths could bypass the runtime attach shim and produce inconsistent envelopes.

## recommend

**change scope** — define B2 as additive `meta.hesperia_metric` wiring at the single runtime boundary, prove byte/shape equivalence with flags off, and test every public `/analyze` construction path.
