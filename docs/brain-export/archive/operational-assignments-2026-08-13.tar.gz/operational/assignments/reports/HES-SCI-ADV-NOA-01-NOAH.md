# HES-SCI-ADV-NOA-01 — Noah

## read
- `/data/hesperia/hesperia/core/domain/ksi/` is a default-off Class A inspection neighbor attached to the engine envelope.
- `/data/hesperia/hesperia/sphere/kam/` is a default-off, inspect-only stability lens.
- `/data/hesperia/hesperia/tests/domain/ksi/test_ksi_analyze_wire.py` and `/data/hesperia/hesperia/tests/kam/test_apply_gate_flags.py` cover basic flag gating.

## risks/gaps
- Unit gating alone does not prove deterministic equivalence of the sealed base envelope when inspectors are off.
- Combined KSI+KAM behavior, malformed overrides/bounds, missing evidence, and output-order stability need explicit coverage.
- Inspector scores must not become labels or ground truth for an AI evaluator.

## recommend
**proceed** — AI tests should be differential/metamorphic: same input off/on, identical sealed base and trace hash, additive namespaced blocks only, deterministic repeats, combined-flag matrix, malformed-config degradation, and missing-evidence behavior without invented semantic conclusions.
