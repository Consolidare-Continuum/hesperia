# Cursor main — EOM system address (2026-08-07)

**Session:** `execution_host=altitudine`, `dev_office=true`, `connectivity=lan`  
**Mode:** Cursor main EOM residual items → system fitness

## Wider picture

| Signal | Verdict |
|--------|---------|
| Thinking-map “~70 blockers” | **Not 70 product defects.** Queue = COLLECT_EVIDENCE hygiene: agents omitting comma-separated evidence tokens (`task_id`, `agent_cert_valid`, `snapshot_fresh`). Registry grew; work often continued anyway. |
| books_staging ~19G | Correctly nuked (approval `approval-7db05981421a`). CHROMA-2 is books home. |
| `/data/chroma/venv` nuke | **Misclassified as legacy.** It is the **MCP host Python**. Hold the line: do not delete with books staging. Restored lean (~1.6G, CPU torch, `mcp==1.29.0`, `fpf-thinking-map==1.9.5`). |
| Runbook short-id misses | Fixed earlier (promote `scripts/runbooks/` → `scripts/`). Optional Cursor MCP restart still picks up `active_md_anchor` match. |
| Hard gate after 1.9.5 | Fixed (35/35). |

## Did

1. **Blockers:** Closed **79** pending on live registry (`prichindel:/data/workspaces/cursor/governance/thinking_map_blockers.jsonl`); synced to altitudine brain. Digest **pending=0**.
   - task_id-only 38 · cert/snapshot 13 · fixed_runtime 9 · eod_ops 5 · other/theme/trust 14
2. **MCP venv:** Recreated `/data/chroma/venv`; pinned `mcp[cli]<2` (2.0 breaks FastMCP); CPU torch only; hard-gate green; `agent_mcp_*` imports OK.
3. **Canon:** `requirements-mcp-venv.txt`, `scripts/rebuild-prichindel-mcp-venv.sh`, MCP-PYTHON doc + agent_mcp requirements pin `mcp<2`.
4. **Disk:** `/data` on prichindel ~38% after staging+old-venv nuke and lean restore.

## System address (product)

- Treat thinking-map blocker registry as **evidence-token debt**, not alert flood — EOM/EOD close by pattern after review.
- Protect `/data/chroma/venv` in approvals/copy: label **MCP runtime**, never “legacy chroma leftover.”
- Agents: pass `agent_cert_valid,snapshot_fresh,task_id` as comma tokens on cluster/team maps.

## Asked

- **Cursor IDE:** full MCP restart once so runbook server reloads `active_md_anchor` matching (promoted files already resolve short ids without it).
- Commit/push of brain changes: executing as part of this EOM address.

SIGNED: Cursor main | EOM system address | 2026-08-07 | blockers+venv
