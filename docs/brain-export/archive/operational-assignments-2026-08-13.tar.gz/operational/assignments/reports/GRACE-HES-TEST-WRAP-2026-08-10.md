# HES-TEST drain digest — no freeze (2026-08-10)

**CSP:** AWP drain | owners Ethan→Daniel→Olivia→Felix→Ava→Cursor→Abelard→Colombo→Emma→Noah→Liam→Sophia→Grace  
**Constraint:** No corpus/schema/VERSION freezes. Speech ban (no medicine framing) stays.

## Wave A — ratify

| ID | Result |
|----|--------|
| A01 | WBS ratified; freeze gap remains DROPPED |
| A02 | Envelope = `meta.testing_params` / top-level `testing_params`; statuses `live\|stub\|uncalibrated\|partial`; `freeze=false`; `calibrated_product_claim=false` |
| A03 | Flag default-off; allowlisted in `env_guard`; act/real-data untouched |
| A04 | Public schema thin; packet additive only |

## Wave B — Felix land

- `runtime/services/testing_params_emit.py`
- Wire: `engine_analyze_contract`, `product_interpret_service`, `tool_inquiry_service`
- Flag: `HESPERIA_TESTING_PARAMS` in `ALLOWED_HESPERIA_ENV`
- Tests: `tests/test_testing_params_emit.py` green

## Wave C — labels / contract

- Honesty matrix embedded in envelope `honesty_policy` + per-param `status`
- Operator label: `calibrated_product_claim=false` always on this dump
- Contract delta: optional meta; OFF path unchanged

## Wave D — books/areas (mutable)

- Inventory via `inventory_default_books_areas()` — curated assets + optional `hesperia_mrt` 120-book maps
- No freeze id required; mutable OK
- Attach `retrieval_context` when testing ON and missing
- Empty vs attached: `status=partial|stub` allowed (Colombo honesty)

## Wave E — agent/LLM path

- Ratified: router inquire + interpret (+ optional context_rag JSON); no act tier
- Agent contract stub: request **into** Hesperia via inquire/interpret with flag ON; packet rides along response
- AI-TEST: LLM must treat statuses as labels — no inventing calibrated claims

## Wave F — smoke

- Runbook: `SCRIPT-RUNBOOK-hesperia-testing-mode-smoke`
- Dry-run OFF/ON green on altitudine tip
- Prod: leave flag unset unless explicit GO

## Residuals

- Full concept↔source↔family↔area retrieval still partial (inventory attach, not full RAG default pack)
- Optional later: read-only bridge; deeper context_rag default-on
- **No CC promote** on this board

SIGNED: Wrap (Grace) | HES-TEST-99 | 2026-08-10 | no-freeze drain
