# HES-SCI-ADV-ETH-02 — Ethan

## read

- `colombo_research/hesperia/HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md` §2c
- `/data/consolidare-continuum/hesperia/release/v0.7.2/RELEASE_SCOPE.md`
- `operational/assignments/FELIX-HES-MATH-BEHAV-54-62-L5-L6-2026-08-05.md`

Class A is universal measurement plumbing under `hesperia/modules/default/`; Class B remains branch-owned and must not enter sealed physics. Release 0.7.2 landed KSI/IPoV code but explicitly deferred live request-path emit. L6 finite differences remain PARTIAL because `E(x±ε)` is absent.

## risks/gaps

- B1 changes sealed Class A layer math and needs an explicit perturbation-series design, off-path default, tests, and wiki truthfulness.
- B2 is additive runtime-envelope wiring, not permission to alter the nine mandatory `/analyze` fields.
- Combining B1 and B2 in one architecture gate would blur different rollback and evidence requirements.

## recommend

**change scope** — gate B1 and B2 independently: B1 on lawful `E(x±ε)` plus sealed-default equivalence; B2 on additive `meta` emit, flags default-off, snapshot/API compatibility, and no Class B data.
