# HES-SCI-ADV-MAR-02 — Marcus

## read

- `/data/consolidare-continuum/hesperia/assets/schemas/anchor_map_v1.json`
- `/data/consolidare-continuum/hesperia/assets/schemas/hesperia_metric_v01.json`
- `/data/consolidare-continuum/hesperia/runtime/services/hesperia_metric_emit.py`
- `/data/consolidare-continuum/hesperia/docs/specs/24_SPEC__Hesperia_Metric_and_Distance_v0_1.md`

`anchor_map_v1` is frozen with explicit semantic/geodesic counts. The metric schema fixes allowed layers and nested IPoV/GCS shapes; runtime emits version `0.1.0`, the frozen anchor id, and an optional geodesic block.

## risks/gaps

- B2 consumers could bind to fields before runtime, schema, docs, and fixtures are demonstrated identical.
- `layers_active`, always-present `gcs_surface`/`ipow_volume`, and conditional `geodesic_sphere` need one documented interpretation.
- Any anchor assignment or count change is a schema/version event, not incidental wiring.

## recommend

**hold** — freeze a B2 contract matrix for flag combinations and validate runtime blocks against `hesperia_metric_v01.json` before live emit; keep `anchor_map_v1` immutable and version any shape change.
