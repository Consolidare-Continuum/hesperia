# Cursor main — August giving-back gate (2026-08-07)

**After:** EOM passes 1–5 CLOSED.  
**Voice:** Cursor main (product + place-care), not a new defect hunt.

## Done right (do not churn)

- CHROMA-1 brain / CHROMA-2 books split is **true in retrieval**, not only on paper.
- MCP host Python is a protected runtime again (venv ≠ staging).
- Thinking-map blocker flood treated as evidence-token debt and cleared.
- Workflow idle with honest PAUSED set; OPEN 0.
- Biopole host offline documented as expected (HDD replace).
- Cloud Agent allowlist stand (brain + cluster = IDE forever) remains correct product posture.

## Proposals (optional — your call)

| # | Proposal | Why | Owner if you say go |
|---|----------|-----|---------------------|
| 1 | **PAUSED 5 decision pass** — keep / reopen / ARCHIVED each of AGRO-MEMO-V3-02/03, CC_-ACCOUNTS-03, ATM-WP-PROD-03/04 | Heartbeat hygiene; “unpaused” link text vs PAUSED status is confusing | Grace + you |
| 2 | **Dirty-tree wave** (~240 files: wiki / ops-method / clients) — one Grace triage to commit or park | Prevents false “repo messy = product broken” signal next month | Grace → owners |
| 3 | **GitHub Dependabot on `igareosh/cursor`** — triage only in IDE (not Cloud Agent) | Push hooks keep reporting vulns; brain stay allowlist-forbidden for Cloud | Grace → Abelard/Felix scoped |
| 4 | **Agent cert cadence awareness** — renew before `2026-08-08T04:17Z` (hours left) | Avoid next-session Permission denied drama | Abelard / trustmaster-hub (routine) |
| 5 | **ingest.py collect `.mdc`** (or keep `governance/ingest_staging` forever) | Avoid silent skip of Cursor rules on next governance ingest | Abelard/Felix |
| 6 | **Win register one line** for August: books-home CHROMA-2 + EOM clean close | Product memory; complaint register already exists for dislike | Cursor main on ask |

## Advice (Cursor main)

1. **Stop iterating EOM for its own sake.** Pass 5 is enough; next invoke when the calendar month turns or something real breaks.
2. **Prefer hard fitness over more audit prose** — you already got the valuable pills (venv, books home, blockers, stamp ingest). Soft essays are not a second product.
3. **Keep Cloud Agent off the brain.** Dual-path (IDE + cloud) on `igareosh/cursor` would reintroduce the exact compliance fog you just cleared.
4. **Router Balance is fine** for daily; pin Intelligence only for Hesperia theory / destructive ambiguity — not for every chat.
5. **Marketplace:** do not add a second Chroma/MCP “library” plugin; `colombo-library` is the books path. Marketplace only for gaps brain MCP does not cover.

## Not covered (honest gaps — not FAIL)

- Full **Marketplace plugin inventory** vs `mcp-config.json` (brief §6) — not deep-scanned this month beyond harness OK + Cloudflare dual-class known.
- **CHROMA-1 full whole-repo reingest** — only governance/routing delta; older brain chunks may still lag other topics (not books).
- **SuiteCRM operator board** vs active.md DONE counts — not re-verified end-to-end this pass.
- **PAUSED vs “Grace unpaused” wording** inconsistency on those five rows.
- **Human life of Biopole host** — waits on physical HDD; software cannot close it.

## Blocked on you (only if you want movement)

- Whether PAUSED 5 stay intentional.
- Whether Dependabot / dirty-tree get a Grace wave now or wait for EOW.
- When Biopole host returns (hardware).

No subscription/cost talk (M9).

SIGNED: Cursor main | giving-back gate | 2026-08-07 | post EOM5
