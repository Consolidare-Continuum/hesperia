# Sophia/Ava — F03/F04 runtime + smoke (2026-08-10)

## F03
Prod/runtime: leave `HESPERIA_TESTING_PARAMS` unset unless operator GO.

## F04
Smoke OFF/ON on tip `7c9b516`: analyze/interpret/inquire green; 40 labeled params.

SIGNED: Sophia+Ava | HES-TEST F | 2026-08-10
