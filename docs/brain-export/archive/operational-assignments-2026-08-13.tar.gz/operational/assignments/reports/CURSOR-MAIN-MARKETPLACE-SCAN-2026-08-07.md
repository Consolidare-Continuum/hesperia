# Marketplace vs mcp-config scan · 2026-08-07

**Voice:** Cursor main · **GB-MKT-01**

## Brain MCP (`governance/mcp-config.json`)

23 servers: chroma-knowledge, colombo-library, cursor-* suite (pipeline, runbook, approvals, suitecrm, thinking-map, cluster-snapshot, …), hesperia-*, cloudflare-* (5), cursor-tailscale, mail.

## Local harness

- `~/.cursor/plugins/local/prichindel-brain-harness` — **present**

## Marketplace cache (`~/.cursor/plugins/cache/cursor-public`)

| Plugin | Dup vs brain? | Verdict |
|--------|---------------|---------|
| cloudflare | Yes (class overlap with brain cloudflare-*) | Keep brain harness MCP; Marketplace OK for docs/skills — **do not dual-wire second Chroma** |
| continual-learning | No | Optional; no brain MCP conflict |
| cursor-team-kit | No | Skills only — keep |
| docs-canvas | No | Skills only — keep |
| merge-agent-handler | No | OK |
| orchestrate | No | OK |
| parallel | No | Research skills — keep |
| slack | No | Not wired in brain MCP — leave |
| superpowers | No | Process skills — keep |

## Gaps filled by Marketplace (not in brain MCP)

- None that require a **second library/Chroma** path.
- Books path remains **colombo-library** only.

## Action

No new Marketplace MCP dual-wire. Cloudflare class already accepted as dual (docs + bindings). Re-scan next EOM.

SIGNED: Cursor main | marketplace scan | 2026-08-07 | GB-MKT-01
