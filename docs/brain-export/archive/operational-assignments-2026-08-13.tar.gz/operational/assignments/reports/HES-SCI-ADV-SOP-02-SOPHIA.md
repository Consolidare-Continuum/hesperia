# HES-SCI-ADV-SOP-02 — Sophia

## read
- `/data/hesperia/hesperia/Dockerfile.product` and `/data/hesperia/hesperia/Dockerfile.shipping` build the same runtime slice: `runtime/`, `core/`, `hesperia/`, `assets/`, and `VERSION.yaml`.
- Both images use `requirements/shipping.txt`, set only `PYTHONPATH` and `HESPERIA_ASSETS_ROOT`, and start `runtime.shipping.api_main:app`.
- Emit behavior is runtime-env controlled in `/data/hesperia/hesperia/runtime/services/hesperia_metric_emit.py`.

## risks/gaps
- No Dockerfile change is intrinsically required for emit flags, but deploy configuration must inject them deliberately and consistently.
- Image parity can conceal runtime drift: `/data/hesperia/hesperia/runtime/shipping/env_guard.py` currently omits `HESPERIA_METRIC_EMIT` and `HESPERIA_GCS_EMIT`.
- The product/shipping comments and copyright headers differ, increasing maintenance drift without changing the executable surface.

## recommend
**change scope** — keep Dockerfiles unchanged; define deploy checks for image parity, strict-env acceptance, flag-off startup, flag-on response smoke, payload-size observation, and immediate flag rollback.
