# HES-PROD-C03 — Ava: operator surface labels

**Date:** 2026-08-10

| Flag | Label |
|------|-------|
| `HESPERIA_L6_PERTURBATION` | Experimental L6 perturbation inspect |
| `HESPERIA_METRIC_EMIT` | Experimental metric / IPoV meta |
| path_metric_cost on serialize | Internal corridor cost (METRIC-24/25) |

SIGNED: QA/Product (Ava) | HES-PROD-C03 | 2026-08-10 | labels
