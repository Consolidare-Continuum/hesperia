# Ethan — TFP wiring audit (corpus / dictionaries / math / teachers)

**Date:** 2026-08-10  
**Lanes checked:** `:18880` default · `:18881` TFP (`hesperia-analyze-tfp`)  
**Runtime tip:** `4b1d5bd`  

## Verdict (plain)

| Question | Answer |
|----------|--------|
| New area-math grain wired on TFP API? | **YES** — `:18881` USF `area_math_grain=10`, macro len **10**, pack meta 10/240; geometry lock 12/288 preserved |
| TFP dictionaries wired into shipping `/analyze`? | **NO** — not on the sealed multiscale path |
| TFP corpus wired into API / teachers? | **NO** — module corpus tree empty; CHROMA `tfp_corpus_ru` not on this unit |
| Ready to start API + agent teachers for Hesperia TFP? | **PARTIAL** — structural API + `/product/interpret` (llm observe) usable on `:18881`; **not** ready for TFP-dict / corpus-grounded teacher claims |

---

## 1. Math (last grain switch) — wired back

Live `:18881` `/analyze`:

- `analyze_profile=tfp`, `calibration_profile=tfp_v1`
- `usf.raw_metrics.area_math_grain=10`
- `macro_domain_vector` length **10**
- `analyze_profile_meta.pack_areas=10`, `pack_families=240`, `geometry_*_lock=12/288`

`:18880` remains grain **12**. Side-by-side proposal holds.

---

## 2. Dictionaries — present on disk, not on sealed analyze path

### On disk (usable inventory)

| Asset | Status |
|-------|--------|
| `assets/data/engine_dynamics_v060/dict_a/dict_a_tfp*.jsonl` | Present (220 + RU layers) |
| `assets/data/engine_dynamics_v060/dict_b/dict_b_tfp*.jsonl` | Present |
| `assets/calibration/dicts/v0_tfp_cal_wave_002` | Present but **tiny** (dict_a≈35, dict_b≈17) |
| `hesperia/modules/tfp/data/tfp_v1/dict_*` | **Empty** placeholders |

### What `:18881` actually uses today

| Path | Lexical source |
|------|----------------|
| Sealed `/analyze` (multiscale) | `assets/lexicon/curated` (**A_CORE** / family maps) — Class A surface |
| TFP Dict A/B stack (`run_dlcr_pipeline`) | Only if `HESPERIA_DLCR_STRUCTURAL=1` → `structural_dlcr_allowed()` |
| Live TFP unit env | **DLCR structural = off** → no `lexical_resolution` / no `calibration_dicts` in response |

**Hold the line:** Setting `HESPERIA_CALIB_DICT_VERSION=v0_tfp_cal_wave_002` without DLCR does nothing for sealed analyze. Turning DLCR on **with that pin** would load the **tiny** calib pack and **suppress** the full `dict_a_tfp_*` merge stack (loader prefers calib file when set). That is a wiring defect for “enable TFP dicts,” not a GO.

---

## 3. Corpus — not wired for API teachers

| Source | Status |
|--------|--------|
| `tfp_v1/corpus/original/{ru,en}` · `sessions/` | **0** content files (gitkeep only) |
| `tfp_v1/inspector_exports/` | 6 sample export files (not a live corpus feed) |
| CHROMA-1 `tfp_corpus_ru` | Research/brain layer — **not** attached to `:18881` retrieve/teacher |
| Shipping API | No corpus retrieval block on `/analyze` |

---

## 4. Agent teachers / API surfaces

| Surface | On `:18881`? | Notes |
|---------|--------------|-------|
| `POST /analyze` | YES | Grain-10 structural; A_CORE lexicon |
| `POST /product/interpret` (incl. `mode=llm`) | YES | Returns `decision=ALLOW`, router observe; **no** area-math grain in interpret body today |
| `POST /product/tfp` (`runtime.api.main`) | **NO** | Explicitly **not mounted** on shipping `api_main` |
| KSI / IRC Teacher env | **OFF** | No `HESPERIA_KSI_*` / teacher packet flags on TFP unit |
| DLCR + TFP dict teachers | **OFF** | Needs structural DLCR + correct dict pin |

---

## 5. May we start using API and agent teachers?

**Allowed now (narrow):**

- Use `:18881` for **structural** TFP-lane API (grain-10 pack math + profile banner).
- Use `/product/interpret` as **router/LLM observe** over that measurement (honesty: not TFP-dict calibrated).

**Not allowed to claim yet:**

- “TFP dictionaries are live on analyze”
- “TFP corpus grounds the teacher”
- “Agent teachers are TFP-ready end-to-end”

---

## 6. Remaining wiring (GO blockers for full TFP teachers)

1. **Dict bind (Felix):** On TFP unit, enable `HESPERIA_DLCR_STRUCTURAL=1` **and** either unset tiny `v0_tfp_cal_wave_002` or replace with a pack that merges full `dict_a_tfp_*` / `dict_b_tfp*` (do not let 35-row calib win).  
2. **Corpus (Felix/Colombo + Abelard ingest):** Populate `tfp_v1/corpus` and/or wire CHROMA `tfp_corpus_ru` into interpret `context_packet.retrieval`.  
3. **Teacher flags (Ethan ratify → Abelard env):** Decide KSI/IRC teacher inspect packet on `:18881` only; keep sealed apply off.  
4. **Optional:** Mount or proxy `/product/tfp` on shipping lane, or fold `tfp.v1` module project into interpret envelope.  
5. **Verify:** Response must show `lexical_resolution` + non-empty TFP dict provenance; interpret must carry grain/pack meta.

SIGNED: Architect (Ethan) | TFP wiring audit | 2026-08-10 | PARTIAL — math yes, dict/corpus/teachers not yet
