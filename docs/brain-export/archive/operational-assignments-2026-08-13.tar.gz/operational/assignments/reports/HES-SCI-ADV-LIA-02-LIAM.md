# HES-SCI-ADV-LIA-02 — Liam

## read
- `/data/hesperia/hesperia/EXTENSION_STATUS.yaml` marks `hesperia_dev_test` experimental, non-product, but approved for team use with synthetic inputs.
- `/data/altitudine/prichindel.com/operational/assignments/GRACE-TRIAGE-CC-HESPERIA-SCIENCE-B0-B3-2026-08-10.md` requires B1 ε/default-off smoke and B2 METRIC flags/API snapshot smoke.
- `/data/altitudine/prichindel.com/scripts/hesperia/verify-hesperia-dev-pytest.sh` still SSHes `alunel` and uses `/data/workspaces/hesperia`; current dev office is altitudine.

## risks/gaps
- Existing verification does not exercise B1 ε tests, METRIC/GCS off/on behavior, or `tools/verify_public_api_snapshot.py`.
- The alunel execution path is stale against current host-role policy.
- No standard artifact names capture env matrix, command, SHA, and pass/fail evidence for Ava.

## recommend
**change scope** — add one B1/B2 smoke runbook for altitudine/dev repo: targeted pytest selectors, explicit flag-off baseline, each flag-on delta, public snapshot gate, deterministic repeat, and a timestamped evidence report; leave `hesperia_dev_test` non-product.
