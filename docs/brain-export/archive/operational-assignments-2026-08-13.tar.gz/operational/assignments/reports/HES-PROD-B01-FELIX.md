# HES-PROD-B01 — Felix: design L6 producer

**Date:** 2026-08-10

## Design

- Env: `HESPERIA_L6_PERTURBATION` (default off) + optional `HESPERIA_L6_PERTURBATION_EPS` (default 0.05).
- Module: `runtime/services/l6_perturbation_producer.py`.
- Mode: scale sealed hit vector ±ε → re-run `compute_L1`/`compute_L2` → pass measured series into `compute_L6(perturbation_enabled=True)`.
- Call sites: `r1_r4_pipeline` always uses helper; shipping `/analyze` attaches `meta.layer_6` only when flag on (keeps monkeypatchable default path).
- Does not invent FD from MASS_AT_DEPTH alone; does not flip prod defaults.

SIGNED: Developer (Felix) | HES-PROD-B01 | 2026-08-10 | design
