# HES-SCI-ADV-AVA-01 — Ava

## read

- `operational/assignments/GRACE-TRIAGE-CC-HESPERIA-SCIENCE-B0-B3-2026-08-10.md`
- `operational/assignments/FELIX-HES-MATH-BEHAV-54-62-L5-L6-2026-08-05.md`
- `/data/consolidare-continuum/hesperia/tests/domain/ksi/test_ksi_analyze_wire.py`
- `/data/consolidare-continuum/hesperia/tools/verify_public_api_snapshot.py`

B1 must turn selected L6 finite-difference slots live without changing sealed defaults. B2 must emit metric/IPoV data only behind flags and preserve the public snapshot.

## risks/gaps

- “Tests pass” is too broad unless values, flag-off equivalence, and schema shape are asserted.
- L6 tests can pass with reserved zeros while failing the scientific acceptance intent.
- B2 needs combined-flag and repeated-run determinism coverage.

## recommend

**proceed** — PASS only if B1 proves nontrivial `E(x±ε)` outputs plus zero/default parity, and B2 proves flags-off identity, flags-on schema validity, deterministic repeat output, mandatory-field preservation, and snapshot green; otherwise FAIL with the exact gate.
