# Grace wrap — prometheus-mcp + Docker MCP Gateway · APPROVED for wide agentic use

**Date:** 2026-08-11  
**From:** Cursor (operator ask)  
**To:** Grace (wrap / approve)  
**Status:** **APPROVED · WIDE AGENTIC USE**  
**Authority:** Operator explicit “approve” + Grace record  
**Approval:** `approval-7a7d9734b6fe` → **approved**  
**Deploy:** Abelard permanence on main `21bffdc1` (plugin + mcp-config + deploy)

---

## Decision

**ADOPTED — prichindel.com-wide** when fit (muscles / hands — not spam every turn).

| MCP | Server key | Wide-use role |
|-----|------------|---------------|
| **prometheus-mcp** | `prometheus-mcp` | PromQL / metrics depth against cluster Prometheus |
| **Docker MCP Gateway** | `MCP_DOCKER` | Secure agent↔MCP catalog gateway (`docker mcp gateway run`) |

| Boundary | Prefer instead |
|----------|----------------|
| Alert peek only | `list_firing_alerts` (cursor-cluster-snapshot) |
| Prod fleet containers/stacks | **malus** (Dockhand + Hawser) |

Hard gates (cluster preflight, approvals, thinking-map, CI soft) are **not** weakened.

---

## Canon / stamp

| Artifact | Role |
|----------|------|
| [DOCKER-MCP-GATEWAY-AND-PROMETHEUS-MCP.md](../../governance/DOCKER-MCP-GATEWAY-AND-PROMETHEUS-MCP.md) | Product framing + wiring |
| [docker_prometheus_mcp_wide_use.txt](../../governance/docker_prometheus_mcp_wide_use.txt) | `status=1` wide-use stamp |
| [MCP-COMPLIANCE-AND-OPERATIONAL.md](../../governance/MCP-COMPLIANCE-AND-OPERATIONAL.md) | MCP table rows |
| Docker blog SoT | https://www.docker.com/blog/docker-mcp-gateway-secure-infrastructure-for-agentic-ai/ |

**OPEN active.md row:** not created — meta-approval + stamp only (`OPEN=0`).

---

## Assign

**Assign to: All agents** — treat both MCPs as first-class optional muscles when the task needs them.  
**Operator remaining:** full Cursor restart if session predates deploy (tools appear after restart).

---

SIGNED: Triage (Grace) | prometheus-mcp + MCP_DOCKER wide use | 2026-08-11 | approval-7a7d9734b6fe APPROVED
