# HES-PROD-D05 — Marcus: schema freeze note

**Date:** 2026-08-10

Metric emit matrix + optional `meta.layer_6` are additive experimental. Public schema snapshot frozen (unchanged). Do not fold experimental keys into required public schema without Olivia gate.

SIGNED: Schema (Marcus) | HES-PROD-D05 | 2026-08-10 | freeze note
