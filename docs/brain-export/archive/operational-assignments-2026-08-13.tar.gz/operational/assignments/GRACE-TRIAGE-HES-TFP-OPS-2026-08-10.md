# Grace triage — HES-TFP-OPS (TFP operational MVP)

**Date:** 2026-08-10  
**Operator:** AWP drain — Hesperia TFP operational for **agent + API** (same instructor: analyze → interpret/teacher) on TFP structure map + most complete calibrated dict/corpus MVP.  
**Lane:** `:18881` only (`hesperia-analyze-tfp`). Keep `:18880` default core untouched.  
**Prior:** [ETHAN-HESPERIA-TFP-WIRING-AUDIT-2026-08-10.md](reports/ETHAN-HESPERIA-TFP-WIRING-AUDIT-2026-08-10.md) — PARTIAL.

## Goal

TFP Class B MVP try that is honest and usable:

1. **Math** — grain 10 / pack 240 (already live).  
2. **Dictionaries** — full `dict_a_tfp*` / `dict_b_tfp*` stack via structural DLCR; **not** tiny `v0_tfp_cal_wave_002` as sole winner.  
3. **Structure map** — `area_structure_tfp` + `families_structure_tfp` announced on profile + interpret context.  
4. **Corpus** — best available on disk (`tfp_v1/inspector_exports` + snapshot id); sessions tree still empty — label as MVP, not full corpus GO.  
5. **Instructor** — same path for API and agents: `POST /analyze` → `POST /product/interpret` (`mode=llm` when keys present; else mock).

## Rows

| ID | Owner | Task |
|----|-------|------|
| HES-TFP-OPS-00 | Grace | Triage this wave |
| HES-TFP-OPS-01 | Ethan | Ratify instructor contract (API=agent) |
| HES-TFP-OPS-02 | Felix | Profile: full TFP dict stack + DLCR defaults; drop tiny calib pin |
| HES-TFP-OPS-03 | Abelard | `.env.tfp` + capabilities `internal.dlcr`; restart `:18881` |
| HES-TFP-OPS-04 | Felix | Structure map + corpus MVP → interpret/agent context_packet |
| HES-TFP-OPS-05 | Gena | Smoke analyze + interpret (llm/mock) on `:18881`; confirm lexical_resolution |
| HES-TFP-OPS-99 | Grace | Wrap digest |

## Hold the line

- Do not merge TFP into sealed `:18880` core.  
- Do not claim full corpus teacher GO while `corpus/sessions` empty.  
- Geometry lock remains 12/288.

SIGNED: Triage (Grace) | HES-TFP-OPS | 2026-08-10 | Class B MVP operational wave
