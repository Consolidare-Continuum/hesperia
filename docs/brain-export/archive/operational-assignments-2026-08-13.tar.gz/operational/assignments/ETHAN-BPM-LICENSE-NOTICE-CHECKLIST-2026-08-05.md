# Ethan — LICENSE / NOTICE overlay checklist (Ops Method → CC/bpm)

**Task:** BPM-D3-03 · **Date:** 2026-08-05

Before first gated promote to `Consolidare-Continuum/bpm`, ensure corporate overlay (pattern: Hesperia CC clone):

| # | Artifact | Intent | Status |
|---|----------|--------|--------|
| 1 | `LICENSE` | Proprietary CC_ SRL | **TODO at first push** |
| 2 | `NOTICE` | Attribution / third-party | **TODO at first push** |
| 3 | `LEGAL_NOTICE.md` | Short SRL notice | **TODO at first push** |
| 4 | `.cc-corporate-inception` | Genesis marker (empty commit 0) | **TODO at first push** |
| 5 | Preserve across mirror | Same set as hesperia mirror PRESERVE | Script stub aware |
| 6 | No Biopole client paths in tree | Fence | Policy RATIFIED |

Workbench may ship without overlay; **CC/bpm** must carry overlay before/with first public-to-org commit.

SIGNED: Ethan | BPM-D3-03 LICENSE/NOTICE checklist | 2026-08-05 | CC/bpm
