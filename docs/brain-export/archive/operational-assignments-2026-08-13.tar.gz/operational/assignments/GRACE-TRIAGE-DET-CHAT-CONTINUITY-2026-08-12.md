# Grace triage — Detelina TG chat continuity (Gena)

**Date:** 2026-08-12 · **Owner:** Grace (triage) · **Execute:** **Gena**  
**Project:** biopole · Detelina Telegram `@BiopoleBot`  
**Trigger:** Operator — every reply re-greets («Здравствуйте!»); need normal LLM chat continuity; keep discussion frame; relax context window.

## Evidence (operator sample)

1. First reply: full intro OK.  
2. «Пришли мне прайс» → again **Здравствуйте!** + price denial (frame broken).  
3. «Пришли мне файлом…» → again **Здравствуйте!** (sounds like new chat each time).

## Acceptance

| # | Must |
|---|------|
| A | Mid-thread replies **never** open with Здравствуйте / Hello / Bună ziua unless user greets first or chat is truly new. |
| B | Bot **continues the discussion frame** (crop/area/price ask already in play → answer in that thread). |
| C | Context window **relaxed** for normal multi-turn chat (not 1–2 turns of amnesia). |
| D | History survives bot restart (not only in-memory Map). |
| E | Still public-edge law (no files if policy says so — but answer in-thread without re-intro). |

## Grace already (speech — entity manager)

Live prompt patch deployed: **CHAT CONTINUITY** + greeting rule + `THREAD STATE` hint; default `DETELINA_HISTORY_TURNS=24` in compose. Gena still owns **persist** (DET-CHAT-02), smoke (04), GitHub mirror (05), and verify 01/03 as complete.

## Tasks for Gena (OPEN)

| ID | Task | Done when |
|----|------|-----------|
| **DET-CHAT-00** | Grace triage this packet; land rows; SuiteCRM sync | Rows OPEN |
| **DET-CHAT-01** | Raise default `DETELINA_HISTORY_TURNS` (e.g. **24–32**); wire compose env; document | Env live + docs |
| **DET-CHAT-02** | Persist per-`chatId` history to disk (or existing chatState) across container recreate; TTL optional | Restart keeps last N turns |
| **DET-CHAT-03** | Inject continuity hint into system when `prior.length > 0` («continue thread; no greeting») | Code |
| **DET-CHAT-04** | Smoke: 3-turn RU script (intro → price → micobact) — no mid-thread Здравствуйте | Log/paste PASS |
| **DET-CHAT-05** | Mirror fix to biopoleMD `main_data` + `tersagor-bot` legacy (deploy still cluster) | Push |

## Out of scope

- Changing public folder lock / green CLEAN EDGE.  
- Cognitive Planfix Q&A sync.  
- Abelard redeploy except as needed after Gena ships.

## Link

- Entity manager: [agents/grace/DETELINA-TG-ENTITY-MANAGER.md](../../agents/grace/DETELINA-TG-ENTITY-MANAGER.md)  
- Live: `/data/CLIENTS/biopole/telegram_ai_bot_repo/src/services/ai/assistant.ts`

SIGNED: Triage (Grace) | DET-CHAT continuity → Gena | 2026-08-12
