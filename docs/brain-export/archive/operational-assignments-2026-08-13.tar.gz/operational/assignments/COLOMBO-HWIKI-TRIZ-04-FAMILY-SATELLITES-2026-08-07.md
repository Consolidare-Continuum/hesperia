# COLOMBO — HWIKI-TRIZ-04 family / hex / contradiction satellites

**Date:** 2026-08-07  
**Owner:** Colombo  
**Wave:** HWIKI-TRIZ-04  
**Upstream:** [TRIZ-MODULE-INVENTORY-2026-07-23.md](../../colombo_research/hesperia/wiki/TRIZ-MODULE-INVENTORY-2026-07-23.md) · Coverage-Ledger TRIZ gap · operator *Colombo hesperia science wiki grind*

```
CSP:
From: Cursor Context
To: Colombo Context
Reason: operator invoked Colombo science wiki grind
What changes: wiki content authority; durable edits via generate_wiki.py only
```

## INVENTORY (verified)

Checkout: `/data/hesperia/hesperia` · package `hesperia/extensions/triz/` (35 `.py` files).

Already wikified before this pass: Louvain · TRIZ contradiction core (TRIZ-02) · three named export products (CATALOG-BRIDGE).

This pass closes inventory sub-batches **TRIZ-FAM** + remaining **TRIZ-CONTRA** satellites (not the export products).

## LOCATE

Direct module read + `rg '^(def |class |[A-Z].*=)'` on altitudine, 2026-08-07:

| Module | Primary symbols wikified |
|--------|--------------------------|
| `family_contradiction.py` | `build_family_contradiction_pressure` (+ matrix/fragmentation/bridge/concentration in notes) |
| `family_clustering.py` | `cluster_contradictions_by_family / get_conflict_hotspots` |
| `hex_signals.py` | `aggregate_hex_pressure` (+ peaks/volatility in notes) |
| `contradiction_calibration.py` | `get_default_contradiction_calibration / validate_contradiction_calibration` |
| `contradiction_coupling.py` | `apply_contradiction_coupling` |
| `contradiction_feedback.py` | `build_contradiction_feedback_signals` |
| `contradiction_negation.py` | `classify_contradiction_mode / OppositionMode` |
| `contradiction_uncertainty.py` | `build_uncertainty_package` |
| `crossplane_contradiction.py` | `build_crossplane_contradiction_package` |
| `conflict_release_gating.py` | `evaluate_conflict_integrity / release gates` |

Plus hub page: **TRIZ family-hex-satellite hub**.

## FORMALIZE

- Status: all **LIVE_FULL** or hub **BEYOND** (Hesperia-native; no Java ancestor).
- Class B inventives — not sealed `/analyze` physics.
- Cross-links: core detect → family/coupling → crossplane → release gates → export products.
- Explicitly **not** claimed DONE: TRIZ-TOPO, TRIZ-PIPE, TRIZ-PROD, novelty non-Louvain, models/time_series/meta/signal_normalization.

## DRAFT / LANDING

Durable: `colombo_research/hesperia/wiki/tools/generate_wiki.py` ITEMS block `# ===== TRIZ family / hex / contradiction satellites (HWIKI-TRIZ-04) =====`  
Regen: `python3 tools/generate_wiki.py` + `python3 tools/render_wiki_html.py`.

## NEXT (Colombo)

1. **HWIKI-TRIZ-05 (TOPO)** — `topology_binding`, `topology_metrics`, `topology_activation_pipeline`, `topology_contradiction_coupling`, `propagation_engine`, `narrative_routes` (Colombo content + Felix pins optional).
2. **HWIKI-TRIZ-06 (PIPE)** — `triz_pipeline`, `kme_bridge`, `direct_outputs`, `models` surface types.
3. **Abelard** — after material regen, `ingest-hesperia-wiki.sh` when VECTOR-STORAGE-APPROVAL path allows re-ingest.

SIGNED: Research (Colombo) | Hesperia science wiki | 2026-08-07 | HWIKI-TRIZ-04
