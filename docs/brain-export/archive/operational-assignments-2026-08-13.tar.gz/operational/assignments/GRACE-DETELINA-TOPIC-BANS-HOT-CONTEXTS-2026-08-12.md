# Grace — Detelina TG: topic directions & hot contexts

**Date:** 2026-08-12 · **Owner:** Grace · **Priority:** HIGH  
**LLM framing:** [CURSOR-MAIN-DETELINA-TOPIC-REDIRECT-LLM-FRAMING-2026-08-12.md](./CURSOR-MAIN-DETELINA-TOPIC-REDIRECT-LLM-FRAMING-2026-08-12.md)

## Stance

Not afraid · not hiding · not a ban.  
Commercial agrobiotech advisory (profit is one goal) → many hot frames are **inappropriate** (often manipulative for LLM).  
**Redirect** → if persists → **humble bye** → **IRC `#detelina` OPERATOR CHECK** (review / possible ban). Never tell the user about ops.

SIGNED: Triage (Grace) + Cursor main | redirect · bye · IRC | 2026-08-12

## Hijack matrix (2026-08-12)

Full brick-hit table + code: [GRACE-TRIAGE-DETELINA-HIJACK-MATRIX-2026-08-12.md](./GRACE-TRIAGE-DETELINA-HIJACK-MATRIX-2026-08-12.md) (`hijackGuard.ts` short-circuit for jailbreak/NSFW/hard-illegal; lane hints + IRC kind labels for the rest).
