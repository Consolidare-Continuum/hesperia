# operational/assignments — slim index (archived 2026-07-30)

**Full tree archived** — not deleted. Canonical copy:

| Artifact | Location |
|----------|----------|
| **Tarball** | [`docs/brain-export/archive/operational-assignments-2026-07-30.tar.gz`](https://github.com/igareosh/hesperia/tree/main/docs/brain-export/archive) on **igareosh/hesperia** |
| **Checksums** | `operational-assignments-2026-07-30.SHA256SUMS.txt` (SHA256 `0a1c08dbe4aea78938380ba16aa1890e734677d14a25af0ddf277850078cb0c8`) |

## Live triage (brain only)

Policy: Grace triage packets for **active waves** (ops-method, HWIKI finish, CC branding, PAPRA) stay here. Closed-wave packets → tarball. Re-archive when folder grows past ~live triage again.

Live files restored this pass: **44** (see directory listing).

Historical `active.md` links to moved paths → open tarball on **igareosh/hesperia**.

**Do not** re-expand closed waves into brain.
