# COLOMBO — HWIKI-TRIZ-06 pipeline / KME bridge / direct metrics

**Date:** 2026-08-07  
**Owner:** Colombo  
**Wave:** HWIKI-TRIZ-06  
**Upstream:** TRIZ-01 inventory TRIZ-PIPE · operator chose NEXT item 1

## INVENTORY

| Module | Symbols |
|--------|---------|
| `models.py` | MatrixCoordinate, ConceptActivation, ConceptRelation, ContradictionSignal, InnovationCluster, NarrativeSignal, TRIZSignals |
| `triz_pipeline.py` | `run_triz_analysis` |
| `kme_bridge.py` | `run_triz_for_kme`, topology-from-trace/graph, attach direct_metrics |
| `direct_outputs.py` | `TRIZDirectMetrics`, `build_triz_direct_metrics`, `compare_triz_direct` |

## LANDING

Hub **TRIZ pipeline-KME hub** + 4 symbol pages in `generate_wiki.py`.

## NEXT (Colombo)

1. **HWIKI-TRIZ-07 (PROD)** — `commercial_intelligence`, `exporters`, `report_builders`, `report_extractors`, `guards`  
2. Optional leftovers — novelty non-Louvain / `time_series` / `meta_synthesis` / `signal_normalization`

SIGNED: Research (Colombo) | Hesperia science wiki | 2026-08-07 | HWIKI-TRIZ-06
