# Grace triage — Hesperia wiki catalog absorption (parameter_catalog.md + output_catalog.md → wiki)

**Date:** 2026-08-04
**CSP:** From Felix Context → To Felix (content+verify collapsed) Context | Reason: operator direct instruction to embark on a full parameter census, both commercial-faced and system-faced | What changes: normal Colombo/Felix split collapses for this wave — one session doing both content transcription and code-anchor verification, since the research is already done in the source docs, not being re-derived
**Operator mandate (2026-08-04):** "well we embark on census of parameters both commercial faced system faced, and any." — confirmed via AskUserQuestion: start the wiki-absorption wave now, not just verify-and-stop.

**Hub:** [wiki/CLAUDE.md](../../colombo_research/hesperia/wiki/CLAUDE.md) · live `http://192.168.100.65:8901/` · prior waves [GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md](GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md), [GRACE-TRIAGE-HESPERIA-WIKI-STRUCT-070-2026-07-26.md](GRACE-TRIAGE-HESPERIA-WIKI-STRUCT-070-2026-07-26.md)

---

## Why this wave exists

The wiki's own `Coverage-Ledger.md` names its biggest open gap as "L1–L11 pipeline layer variables... full census still open" and "TRIZ extension internals... remaining novelty/topology/commercial modules still open." Discovered 2026-08-04: that research is **already done**, just not in the wiki — `/data/hesperia/hesperia/docs/foundations/output_catalog.md` (513 lines, "every aggregated variable that reaches a consumer, ground up from L1 to the LLM," source-verified not paraphrased) already covers L1–L9, KME (already wikified separately), TRIZ, and `fpf_bridge` with exact names/formulas/meanings. `parameter_catalog.md` (132 lines) is the input/calibration-constant counterpart, already substantially wikified via earlier waves (geometry, activation thresholds, propagation weights, Core Math contract, diagnostic thresholds — see existing wiki categories).

**This wave is transcription + verification, not re-research.** Source of truth for each item: `output_catalog.md`'s per-layer section (name, formula/composition, meaning) cross-checked directly against the implementing `core/layers/layer_N.py` file before writing the `add(...)` call — same standard the wiki already holds itself to ("every claim traces to a grep/file-read done during that research").

Both `parameter_catalog.md` and `output_catalog.md` had 5 stale `specs/canon/` path references (pre-`assets/` fold) — fixed same day, commit `2564c502` on `igareosh/hesperia`, before this wave started, so the source docs being transcribed from are themselves current.

---

## Wave identity

| Field | Value |
|-------|-------|
| **Project** | `hesperia` |
| **ID prefix** | `HWIKI-CATALOG-` |
| **Batches** | L1, L2, L3, L4, L5, (L6 — already wikified, verify only), L7, L8, L9, fpf_bridge+TRIZ-exports |
| **Exit** | Coverage-Ledger's "L1–L11 full census" and "TRIZ extension internals" gaps closed or the remaining scope explicitly narrowed; every new page's module citation code-anchor-verified against the current tree (post 2026-08-04 core restructure) |

## Rows

| ID | Theme | Count (approx) | Status |
|----|-------|-----------------|--------|
| **HWIKI-CATALOG-L1** | L1 structural activation census (`core/layers/layer_1.py`) | 36 pages (27 base + 6 profile + hub, excl. GINI_COEFFICIENT already wikified) | **DONE** |
| **HWIKI-CATALOG-L2** | L2 topology traversal (`core/layers/layer_2.py`) | 25 pages (24 vars + hub, excl. LOCAL_CLUSTERING_COEFFICIENT/LOOP_COUNT/LOOP_DENSITY) | **DONE** |
| **HWIKI-CATALOG-L3** | L3 baseline/shadow comparison (`core/layers/layer_3.py`) | 26 pages (25 vars + hub) | **DONE** |
| **HWIKI-CATALOG-L4** | L4 evidence retrieval (`core/layers/layer_4.py`) | 26 pages (25 vars + hub) | **DONE** |
| **HWIKI-CATALOG-L5** | L5 counter-evidence & trig invariants (`core/layers/layer_5.py`) | 26 pages (25 vars + hub, 6 trig residuals marked PARTIAL — hardcoded 0.0 reserved placeholders) | **DONE** |
| **HWIKI-CATALOG-L6** | L6 dynamical stability — **already wikified** (17 pages, prior HWIKI-L6 wave) | 25 | verify-only, not re-touched this wave |
| **HWIKI-CATALOG-L7** | L7 consistency and decision (`core/layers/layer_7.py`) | 27 pages (23 gates + 3 conditional + hub, excl. 2 already wikified) | **DONE** |
| **HWIKI-CATALOG-L8** | L8 unit standardization (`core/layers/layer_8.py`) | 28 pages (27 vars + hub, excl. 3 already wikified) | **DONE** |
| **HWIKI-CATALOG-L9** | L9 pillars, brand labels, action triggers — terminus (`core/layers/layer_9.py`) | 26 pages (25 vars + hub) | **DONE** |
| **HWIKI-CATALOG-BRIDGE** | `fpf_bridge` 5 structural states + TRIZ 3 export product shapes | 10 pages (2 hubs + 5 states + 3 exports) | **DONE** |

**Wave total: 230 new pages** (163 → 393). All batches closed same session, 2026-08-04.

**Correction discovered mid-wave**: the wiki's own Coverage-Ledger had described the gap as "L1–L11 pipeline layer variables" — this was stale/aspirational. `core/layers/` only has `layer_1.py` through `layer_9.py`; `output_catalog.md` itself calls L9 "the terminus." There is no L10/L11. Fixed in the Coverage-Ledger output during this wave.

**Not in scope for this wave** (already covered or explicitly excluded upstream, per `output_catalog.md` itself): `/analyze` legacy contract (9 fields — already wikified as part of earlier core-math/contract passes, verify only if a gap surfaces), KME primitives+derived (41 — already fully wikified), Field Dynamics extension (~47 constants — deliberately excluded from `output_catalog.md`'s own count too, "no path to a consumer today"; stays a `parameter_catalog.md` §8-only citation, not wiki pages, unless the extension ships).

## Process per batch

1. Read the layer's section in `output_catalog.md` in full.
2. Cross-check each named variable against `core/layers/layer_N.py` directly (grep the actual field/computation, not just trust the doc).
3. Add via `generate_wiki.py` — one `add(...)` per variable (or a data-driven loop where the layer is homogeneous enough, matching the `_KME_DERIVED` pattern already in the generator).
4. Regenerate (`generate_wiki.py` + `render_wiki_html.py`), commit brain, re-export to dev mirror, commit+push dev. Promote to CC only on a fresh explicit operator decision per batch or batch group (per `governance/SPEC-ETHAN-HESPERIA-REPO-STATE-MACHINE.md` — not assumed carried over from earlier today).
5. Update this doc's row status and `Coverage-Ledger.md`.

SIGNED: Developer (Felix) | Claude Code context | 2026-08-04 | HWIKI-CATALOG wave opened, operator-directed
