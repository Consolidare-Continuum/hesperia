# Gena — Detelina TG public face: blast impact if allowed sources go “anywhere”

**Date:** 2026-08-12 · **Owner:** Gena  
**Scope:** Public Telegram (@BiopoleBot / Detelina) + RAG + Planfix + OpenAI  
**Question:** Blast if the interface improperly sends **allowed** public sources (or their paths) beyond intended sales speech.

## Verdict

Allowed folder content is **meant** for public sales speech. The real blast is not “secret AGROPLAN leak” (that is already folder-gated), but:

1. **Infrastructure fingerprint** (absolute paths under `/home/biopole-op/...`) reaching TG / Planfix / OpenAI / LAN RAG.  
2. **Uncontrolled verbatim dump** of carefully worded primary files (boss wording risk).  
3. **Wide audience + multi-egress copy** of every reply (TG anyone + OpenAI; historically Planfix Q&A).  
4. **RAG sidecar** if bound too wide — raw chunks+paths without Detelina prompt filters.

## Mitigations applied (2026-08-12)

| Item | State |
|------|--------|
| CONTEXT paths | **title-only** (basename scrub) |
| Planfix cognitive Q&A | **removed** from text handlers (`syncPlanfixConversation` not called on replies) |
| Discussions | **IRC `#detelina`** via `postDetelinaIrcContext` → presence `:18082` on docker bridge |
| Planfix contacts | **keep** `ensureContactByTelegram` + file upload shadowing |
| RAG bind | `172.17.0.1:18081` (docker bridge) |
| Primary mastery | four files end-to-end + public biopole site OK |

## Intended data plane

| Item | State |
|------|--------|
| Chroma collection | `agrobiotech_public` only (folder `assistant-data`) |
| Primary | `basic.md`, `basic_process.md`, `микобакт.md`, `ризобакт.md` |
| TG role | Corporate public seller |

## Egress map (where a reply / chunk can land)

| Channel | What leaves | Audience | Blast if source/path improperly included |
|---------|-------------|----------|------------------------------------------|
| **Telegram reply** | `replyText` to whoever messaged `@BiopoleBot` | **Any Telegram user** (no allowlist found) | Full product text + possible path echo; competitive / wording / fingerprint |
| **OpenAI API** | System prompt + **CONTEXT chunks** (today includes **absolute `source` paths**) + user text + history | OpenAI processing/retention | Paths + full retrieved excerpts leave Biopole perimeter |
| **Planfix comment** | ~~Q&A sync~~ **OFF** for text; contact register / file upload only | CRM users | Cognitive Q&A no longer amplified in CRM |
| **IRC `#detelina`** | Short TG context lines via presence HTTP | Team daily review | Preferred discussion store |
| **Docker logs** | Errors / some logs | Host operators | Lower; still path/PII if logged |
| **n8n `/start`** | chat_id / username metadata only | n8n if URL set | Low for source text |
| **POST `/crm` → TG** | Planfix → bot → Telegram | Target chat | CRM can push text out; not source files directly |
| **CLI `send-message`** | Arbitrary text to a chat_id (default hardcoded) | That chat | Operator misuse blast |
| **RAG `0.0.0.0:18081`** | Raw JSON chunks + **absolute paths** | LAN / Docker peers | **Bypasses** sales prompt; highest improper “source to anywhere” path |

## Improper-send scenarios (ranked)

| # | Scenario | Likelihood | Impact | Notes |
|---|----------|------------|--------|-------|
| 1 | RAG open on LAN dumps allowed sources + paths | **High (config)** | High fingerprint + raw text | `ss` shows `0.0.0.0:18081`; TG bot uses it; any LAN client can POST `/rag` |
| 2 | Absolute paths injected into LLM CONTEXT, echoed to TG/Planfix | **Medium** | Med–High fingerprint | `fetchRag` formats `[i] ${source}` with full filesystem path |
| 3 | Model pastes near-entire primary file into one TG answer | **Medium** (prompt asks fidelity) | Med wording/IP control | Content is “allowed public”, but boss is careful with **placement of words** — uncontrolled dump still hurts |
| 4 | Open TG bot + no user ACL | **High (by design)** | Content reaches strangers | Public face — accept for sales; do not put non-customer text in folder |
| 5 | Planfix retains every Q/A | **High** | Lateral inside CRM | Amplifies any bad reply |
| 6 | Collection drift / wrong folder | **Low now** | High if returns | Mitigated: dedicated collection + verify wipe-on-drift |
| 7 | Dual text handlers / error strings | Low | Low–Med | Technical “Ассистент” string still on one error path |

## What is *not* in this blast (if gates hold)

- AGROPLAN / SoftVoya / PM plans (not in public collection).  
- Shared `knowledge` mix (purged; only `agrobiotech_public` collection present at last verify).

## Hardening (recommended order)

1. **RAG bind:** `127.0.0.1` + docker bridge only — not `0.0.0.0` world/LAN.  
2. **CONTEXT to model:** pass **`title` only**, never absolute `source` path.  
3. **Reply scrubber:** strip `/home/biopole-op/`, `assistant-data/`, `chroma` paths before TG + Planfix.  
4. **Folder discipline:** only customer-safe files in `assistant-data` (optional docs = still public).  
5. **Optional:** TG allowlist / rate limit if public scrape risk rises.  
6. Fix leftover technical error string on text-handler catch.

## Did (same session if approved)

- Assessment only unless operator asks to apply hardenings 1–3 immediately.

SIGNED: Developer (Gena) | Detelina TG blast assessment | 2026-08-12 | public source egress
