# FELIX — HES-MATH-BEHAV-47..53 KAM module implement (DONE-ready)

**Date:** 2026-08-05  
**CSP:** From: Colombo contract → To: Felix | Reason: implement KAM research lens 47–53 | What changes: product code under `/data/workspaces/hesperia/sphere/kam/`  
**Owner:** Felix  
**Contract:** [COLOMBO-HES-MATH-BEHAV-40-46-KAM-PRODUCT-CONTRACT-2026-08-05.md](COLOMBO-HES-MATH-BEHAV-40-46-KAM-PRODUCT-CONTRACT-2026-08-05.md)  
**Status:** **DONE-ready** (scaffold + offline battery + SISR/score/verdict + inspect-only gate + tests + env_guard)

---

## Doctrine (hard)

- **KAM (research)** = Kolmogorov–Arnold–Moser-**inspired** semantic perturbation-stability **lens**
- Does **not** claim or implement the KAM theorem
- Flag-gated **default OFF**: `HESPERIA_KAM_ENABLED`
- Pre-0.7.0: **inspect-only** (`HESPERIA_KAM_INSPECT_ONLY` default `1`) — never mutates graph; does not widen allowlist
- Stack order: after **KSI-Inspector** + Teacher inspect-only; neighbour lens, not L1–L9 replacement

---

## Checklist map (47–53)

| ID | Focus | Result |
|----|-------|--------|
| **47** | `sphere/kam/` scaffold + fingerprint + `Π*` | **DONE** — `trajectory_fingerprint.py`, `critical_paths.py` |
| **48** | Perturbation battery P2+P3 offline | **DONE** — `perturbation_battery.py` (P1/P6 skip stubs; P4/P5 skip without Teacher/sandbox) |
| **49** | SISR + report schema emit | **DONE** — `sisr.py`, `report.py` → `hesperia.kam_perturbation_report.v01` |
| **50** | `KAM_semantic_score` + `kam_verdict` | **DONE** — `kam_score.py` bands 0.75 / 0.45 |
| **51** | Inspect-only envelope wire | **DONE** — `pipeline.attach_kam_to_engine_result` → `kam_stability` when enabled |
| **52** | Pre-0.7.0 apply-gate consume | **DONE** — `apply_gate.inspect_apply_gate` inspect-only lens; hard block fragile / insufficient |
| **53** | Pytest + offline fixture golden | **DONE** — `tests/kam/` (30 passed); bounds asset `assets/data/kam/kam_perturbation_bounds_v01.json` (`version=spec-v01-defaults`) |

---

## Files (product repo `/data/workspaces/hesperia`)

### Package `sphere/kam/`

| File | Role |
|------|------|
| `__init__.py` | Public exports |
| `flags.py` | `HESPERIA_KAM_ENABLED` (default 0), `HESPERIA_KAM_INSPECT_ONLY` (default 1), `HESPERIA_KAM_BOUNDS` |
| `bounds.py` | Load versioned bounds JSON (SPEC defaults fallback) |
| `trajectory_fingerprint.py` | `SemanticTrajectoryFingerprint` / `T₀` |
| `critical_paths.py` | `Π*` extraction |
| `perturbation_battery.py` | P1–P6 runners (P2+P3 offline active) |
| `sisr.py` | `SISR_min` / `SISR_mean` |
| `kam_score.py` | `KAM_semantic_score` + `kam_verdict` |
| `report.py` | `hesperia.kam_perturbation_report.v01` |
| `apply_gate.py` | Inspect-only apply-gate lens |
| `pipeline.py` | `run_kam_inspect` / `attach_kam_to_engine_result` |

### Assets / shipping

| File | Role |
|------|------|
| `assets/data/kam/kam_perturbation_bounds_v01.json` | ε/τ/band defaults (`spec-v01-defaults`) |
| `runtime/shipping/env_guard.py` | Added `HESPERIA_KAM_ENABLED`, `HESPERIA_KAM_BOUNDS`, `HESPERIA_KAM_INSPECT_ONLY` |

### Tests

| File | Coverage |
|------|----------|
| `tests/kam/test_sisr.py` | empty `Π*`, single-p, min/mean |
| `tests/kam/test_kam_score.py` | band boundaries 0.45/0.75; multiplicative collapse; SISR_min default |
| `tests/kam/test_battery_report.py` | P2+P3 offline; schema populate; P4 skip |
| `tests/kam/test_apply_gate_flags.py` | default OFF; env_guard; inspect-only; hard block; attach |

---

## Pytest summary

```text
cd /data/workspaces/hesperia && python3 -m pytest tests/kam/ -q
..............................                                           [100%]
30 passed
```

---

## Acceptance vs contract §46.4

| Criterion | Status |
|-----------|--------|
| Offline battery → valid `hesperia.kam_perturbation_report.v01` | **PASS** |
| `SISR_*` + `KAM_semantic_score` + `kam_verdict` under non-empty `Π*` | **PASS** |
| Inspect path never mutates graph | **PASS** (`mutates_graph=False`; no executor calls) |
| Apply path blocks on `fragile_trajectory` / `insufficient_baseline` | **PASS** (lens hard_block) |
| Wiki DEAD → LIVE_FULL | **Deferred** — Colombo after LIVE product wire confirmation |

---

## Non-goals / deferred

- Ethan production bounds authoring (beyond `spec-v01-defaults`)
- Full pipeline re-run of sealed `/analyze` inside battery (offline stubs only for P2/P3)
- Wiki generator flip (Colombo)
- Widening 0.7.0 allowlist (forbidden by contract)
- Claiming KAM theorem (forbidden)

---

## NEXT

1. Parent / Cursor: `report_done` on HES-MATH-BEHAV-47..53 when Grace row exists (this packet does **not** edit `active.md`).
2. Ethan: replace/confirm `kam_perturbation_bounds_v01.json` production values.
3. Colombo: wiki stubs SISR / KAM_semantic_score / kam_verdict → LIVE_FULL when ready.
4. Optional: wire `run_kam_inspect` into analyze envelope next to KSI-Inspector attach (still flag-gated).

---

SIGNED: Developer (Felix) | Claude Code context | 2026-08-05 | HES-MATH-BEHAV-47..53 KAM research lens · sphere/kam · inspect-only
