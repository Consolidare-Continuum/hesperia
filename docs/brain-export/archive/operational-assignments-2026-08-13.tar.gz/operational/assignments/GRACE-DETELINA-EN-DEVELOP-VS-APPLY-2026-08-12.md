# Grace — Detelina TG: EN “develop” vs inspect/apply vs agrobiotech project

**Date:** 2026-08-12 · **Owner:** Grace (speech) · **Priority:** HIGH  
**Trigger:** operator — current EN “we develop a comprehensive agrotechnology” is wrong calque; clarify.

## Problem

RU canon «Мы **развиваем** комплексную агротехнологию…» must **not** become EN **“we develop a comprehensive agrotechnology.”**  
In English, **develop** reads as product/R&D “dev,” not Biopole client speech.

## Law (HIGH)

| Lane | Use |
|------|-----|
| **Client how-to (default EN)** | **Inspect** the situation / state → **apply** properly (+ 365 accompaniment to result). |
| **Developmental / building side** | Name it **agrobiotech project** — that is the “dev” part. |
| **Forbidden default EN** | “We develop a comprehensive agrotechnology” (and similar “we develop …” for the offer). |
| **RU** | Keep near-verbatim «развиваем комплексную агротехнологию…» when speaking Russian. |

## Preferred EN sense of the canon line

We do not promote biopreparations as bottles alone. We work a comprehensive agrobiotech approach: inspect the situation, apply properly, with year-round accompaniment through to results across the full crop life cycle.

## Live

- `assistant.ts` Canon framing + informative structure updated 2026-08-12  
- Pointer: [GRACE-DETELINA-SERVICE-KNOWHOW-PRIMACY-2026-08-12.md](./GRACE-DETELINA-SERVICE-KNOWHOW-PRIMACY-2026-08-12.md)

SIGNED: Triage (Grace) | EN develop→inspect/apply / agrobiotech project | 2026-08-12
