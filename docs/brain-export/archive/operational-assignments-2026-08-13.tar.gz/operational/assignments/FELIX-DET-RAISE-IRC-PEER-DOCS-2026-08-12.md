# Detelina IRC peer — observability plumbing only (not devops identity)

**Date:** 2026-08-12 · **Task:** DET-034  
**Host:** tersagor Ergo (mesh ruler) · **Bot process:** prichindel `@BiopoleBot` (talky office)

## Rule

| | |
|--|--|
| **Peer nick** | `detelina` (or operator-approved) — **separate** from `tersagor` |
| **Purpose** | Lounge/mesh **observability** for office bot traffic if/when bridged |
| **Not** | DevOps agent · SDK twin · second `imirc-tersagor-presence` |
| **Forbidden** | Reusing `tersagor` nick; enabling tombstoned `tersagor-presence.service`; join/quit loops |

## Deploy notes (Abelard DET-030..033 — still OPEN)

1. Long-lived client → Ergo (`127.0.0.1:6667` on tersagor, or `tersagor:6697` TLS from peer host).  
2. Channels: `#detelina`, `#biopole-office`, and **`#agents-debug`** (notice awareness only — same mesh as tersagor; **no planned interaction** with `tersagor`; office context stays on `#detelina`).  
3. Single-instance unit for nick `detelina` only — do **not** share `:18096` with tersagor presence.  
4. Smoke: Ava DET-036 Lounge visibility, no flap.

## Refs

- [IRC-PRESENCE-SINGLE-INSTANCE.md](../../cluster/tersagor/IRC-PRESENCE-SINGLE-INSTANCE.md)  
- [ETHAN-DET-RAISE-PLACEMENT-IDENTITY-2026-08-12.md](ETHAN-DET-RAISE-PLACEMENT-IDENTITY-2026-08-12.md)  
- [SCRIPT-RUNBOOK-detelina-biopolebot-raise.md](../../scripts/SCRIPT-RUNBOOK-detelina-biopolebot-raise.md)

SIGNED: Developer (Felix) | detelina IRC peer docs | 2026-08-12 | DET-034
