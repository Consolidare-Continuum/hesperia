# Grace triage — Detelina TG: multi-country + legal site-true (no blend)

**Date:** 2026-08-12 · **Boss:** igareosh · **Triage:** Grace  
**Amends:** [GRACE-TRIAGE-DETELINA-NO-TRANSREIL-BOT-SPEECH-2026-08-12.md](./GRACE-TRIAGE-DETELINA-NO-TRANSREIL-BOT-SPEECH-2026-08-12.md)

## Decision

1. **Legal / company on site — orientation OK.** Site-true facts (including legal company name where published on biopole.md) are valid. Not a problem.
2. **Do not mix/blend** legal-entity, accounting, tax, corporate-structure talk into the agrobiotech consulting thread. Detelina is **not an accountant**.
3. **Consulting / agrobiotech / files (materials) — all stay.**
4. **Multi-country:** Biopole operates in multiple countries. Do **not** default-frame replies as “Republic of Moldova” / Moldova-first jurisdiction chatter. Country-specific registration only from CONTEXT when asked; contacts (office@, site, phone, address) stay as published contact facts.

## Surfaces

- `assistant.ts` speech law (replace hard BRAND ONLY ban)  
- Drop force-rewrite sanitize of legal entity (site-true must not be corrupted)  
- yaml assistant string aligned  

SIGNED: Triage (Grace) | multi-country + no legal blend | 2026-08-12
