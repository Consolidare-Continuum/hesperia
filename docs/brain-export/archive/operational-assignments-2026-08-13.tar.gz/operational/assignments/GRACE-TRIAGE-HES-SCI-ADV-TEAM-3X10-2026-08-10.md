# Grace triage — HES-SCI advisory overlay (3×10 team roles)

**Date:** 2026-08-10  
**CSP:** From: Operator → To: Grace triage | Reason: ask team for 3 read/advise tasks per role atop HES-SCI B0–B3 | What changes: +30 OPEN advisory rows → target 45 OPEN  

**Project:** `hesperia` · **ID prefix:** `HES-SCI-ADV-`  
**Parent wave:** [GRACE-TRIAGE-CC-HESPERIA-SCIENCE-B0-B3-2026-08-10.md](GRACE-TRIAGE-CC-HESPERIA-SCIENCE-B0-B3-2026-08-10.md)  
**Ethan scope:** [ETHAN-CC-HESPERIA-SCIENCE-REINTEGRATION-B0-B3-2026-08-10.md](ETHAN-CC-HESPERIA-SCIENCE-REINTEGRATION-B0-B3-2026-08-10.md)

---

## Trigger

Operator: *Grace ask team for 3 tasks per team role atop existing 15, to read and advise depending on context. 30 total thus 45 in open.*

Team = prichindel **10** (Ethan, Grace, Olivia, Ava, Marcus, Sophia, Liam, Daniel, Noah, Emma). Assistants (Felix/Colombo/…) keep execution rows on parent wave; this overlay is **role-context advise only**.

## Deliverable (every ADV row)

Short advise note (≤1 page) under `operational/assignments/reports/HES-SCI-ADV-<ID>-<OWNER>.md` covering: **read** | **risks/gaps** | **recommend** (one of: proceed / hold / change scope). Then `report_done(DONE)`.

**Do not:** edit sealed Hesperia code, invent formulas, promote to CC, create extra active.md rows.

## Rows (30)

### Ethan (architecture)
| ID | Task |
|----|------|
| **HES-SCI-ADV-ETH-01** | Read `docs/publication/NOVELTY_AND_POSITIONING.md` + `docs/iso/ARCHITECTURE_DESCRIPTION.md` (CC/dev tree). Advise novelty claim risks for B3. |
| **HES-SCI-ADV-ETH-02** | Read Class A/B + `release/v0.7.2/RELEASE_SCOPE.md`. Advise arch gates for B1 L6 ε and B2 live emit. |
| **HES-SCI-ADV-ETH-03** | Read VERSION.yaml drift (root 0.7.1 vs hesperia 0.7.2) + `SPEC-ETHAN-HESPERIA-REPO-STATE-MACHINE.md`. Advise seal/promote hygiene. |

### Grace (ops / triage)
| ID | Task |
|----|------|
| **HES-SCI-ADV-GRA-01** | Read HES-SCI board sequencing vs SuiteCRM. Advise blocker/priority order for 45 OPEN. |
| **HES-SCI-ADV-GRA-02** | Read B3 paper path + CC Lane A disclosure rules. Advise secretar gate for paper packs. |
| **HES-SCI-ADV-GRA-03** | Read PAUSED rows vs new HES-SCI load. Advise capacity: what stays PAUSED vs what yields. |

### Olivia (backend)
| ID | Task |
|----|------|
| **HES-SCI-ADV-OLI-01** | Read `ENGINE-ANALYZE-CONTRACT.md` + metric emit flags. Advise `/analyze` contract impact for B2. |
| **HES-SCI-ADV-OLI-02** | Read KSI flag-gated path (`HESPERIA_KSI_ENABLED`). Advise backend test surface for B1/B2. |
| **HES-SCI-ADV-OLI-03** | Read public API snapshot discipline (`verify_public_api_snapshot`). Advise regression risks. |

### Ava (QA / UX smoke)
| ID | Task |
|----|------|
| **HES-SCI-ADV-AVA-01** | Read B1-02 / B2-02 smoke scopes. Advise acceptance bars (pass/fail criteria). |
| **HES-SCI-ADV-AVA-02** | Read HSR-V7 operator surface labels / product copy. Advise UX wording for emit flags. |
| **HES-SCI-ADV-AVA-03** | Read HDT diacritic finding (inbox 2026-07-26). Advise QA awareness for RO path while B-wave runs. |

### Marcus (schema / data)
| ID | Task |
|----|------|
| **HES-SCI-ADV-MAR-01** | Read wiki PARTIAL census (~38). Advise which PARTIALs block paper claims. |
| **HES-SCI-ADV-MAR-02** | Read `anchor_map` / metric JSON schemas. Advise schema freeze needs before B2 emit. |
| **HES-SCI-ADV-MAR-03** | Read `EXTENSION_STATUS.yaml`. Advise what must stay out of sealed data contracts. |

### Sophia (infra / runtime)
| ID | Task |
|----|------|
| **HES-SCI-ADV-SOP-01** | Read defaults: KSI/KAM/METRIC flags off. Advise runtime risk if enabled in prod. |
| **HES-SCI-ADV-SOP-02** | Read `Dockerfile.product` / `Dockerfile.shipping`. Advise deploy surface for new emit flags. |
| **HES-SCI-ADV-SOP-03** | Read CC promote gate (mirror script + `CC_PUSH_PERMISSION`). Advise infra readiness checklist (no promote). |

### Liam (scripts / automation)
| ID | Task |
|----|------|
| **HES-SCI-ADV-LIA-01** | Read B0-02 wiki regen + ingest path. Advise automation / runbook gaps. |
| **HES-SCI-ADV-LIA-02** | Read `hesperia_dev_test` + Ava smoke path. Advise SCRIPT-RUNBOOK needs for B1/B2 smokes. |
| **HES-SCI-ADV-LIA-03** | Read `mirror-atomic-to-cc-srl.sh` policy. Advise awareness-only automation (never auto-promote). |

### Daniel (security)
| ID | Task |
|----|------|
| **HES-SCI-ADV-DAN-01** | Read flag-gated inspect surfaces (KSI/KAM/METRIC). Advise exposure if defaults flip. |
| **HES-SCI-ADV-DAN-02** | Read publication market claims vs `clinical_tfp` product_surface none. Advise overclaim / disclosure risk. |
| **HES-SCI-ADV-DAN-03** | Read `agentic_bridge` experimental status. Advise security hold for product surface. |

### Noah (AI / vector)
| ID | Task |
|----|------|
| **HES-SCI-ADV-NOA-01** | Read KSI/KAM as inspect neighbours. Advise AI-test angles for B1/B2. |
| **HES-SCI-ADV-NOA-02** | Read fpf_bridge L11 vs deterministic novelty claim. Advise AI-TEST-REPORT focus for B3 papers. |
| **HES-SCI-ADV-NOA-03** | Read CHROMA `hesperia_wiki` ingest path. Advise register/vector consistency after B0-02. |

### Emma (integration)
| ID | Task |
|----|------|
| **HES-SCI-ADV-EMM-01** | Read product interpret / router envelope. Advise integration gaps for metric/IPoV emit. |
| **HES-SCI-ADV-EMM-02** | Read SuiteCRM sync as awareness-only. Advise INTEGRATION-ONLY classification vs product path. |
| **HES-SCI-ADV-EMM-03** | Read METRIC emit contract pieces. Advise whether INTEGRATION-CONTRACT draft is needed before Ethan freeze. |

## Meta

| ID | Owner | Scope |
|----|-------|-------|
| **HES-SCI-ADV-00** | Grace | This triage + SuiteCRM bootstrap | DONE on write |

**Order:** ADV rows may run **in parallel** with HES-SCI execution; they do not block B0-01. Ethan signs parent wave exits; ADV advises only.

SIGNED: Triage (Grace) | HES-SCI advisory 3×10 | 2026-08-10 | HES-SCI-ADV-00
