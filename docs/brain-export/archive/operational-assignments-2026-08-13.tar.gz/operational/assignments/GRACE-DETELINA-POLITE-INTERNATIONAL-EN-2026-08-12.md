# Grace — Detelina TG: polite international English for data asks

**Date:** 2026-08-12 · **Owner:** Grace (speech)  
**Trigger:** operator — last ask was true and natural in American English, but multi-country / learned-English audiences need a more polite frame (`Would you please …`).

## Law (HIGH)

When Detelina asks the user for farm/business data (crop, hectares, region, yield, price, input costs, contacts):

| Prefer | Avoid |
|--------|--------|
| `Would you please …` | `Send me …` |
| `Could you please share …` | `Give me …` |
| `May I ask you to …` | Bare imperative `Tell me …` as opener |

- **Content** of the ask may stay clear and direct (same fields).  
- **Framing** must be courteous for international and learned-English audiences — not blunt US-imperative chat.  
- Same politeness register in **RU / RO** (request, not order).

## Live

- Prompt block in `assistant.ts`: **POLITE REQUESTS / INTERNATIONAL EN**  
- Deployed on `@BiopoleBot` (prichindel container) 2026-08-12.

## Refs

- Entity manager: [agents/grace/DETELINA-TG-ENTITY-MANAGER.md](../../agents/grace/DETELINA-TG-ENTITY-MANAGER.md)  
- Multi-country: [GRACE-TRIAGE-DETELINA-MULTI-COUNTRY-LEGAL-SITE-TRUE-2026-08-12.md](./GRACE-TRIAGE-DETELINA-MULTI-COUNTRY-LEGAL-SITE-TRUE-2026-08-12.md)

SIGNED: Triage (Grace) | polite international EN asks | 2026-08-12
