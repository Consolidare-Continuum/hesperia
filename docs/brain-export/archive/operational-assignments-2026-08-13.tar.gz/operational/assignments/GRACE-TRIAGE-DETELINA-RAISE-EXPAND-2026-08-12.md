# GRACE TRIAGE EXPAND — Detelina raise (60-task budget)

**Date:** 2026-08-12  
**From:** Operator → Grace — “usual budget 50/70~ tasks, proceed tasking”  
**Outcome:** PROJECT wave **DET-001..060** on [active.md](../../active.md)  
**Register:** [DET-RAISE-2026-REGISTER.md](../../governance/DET-RAISE-2026-REGISTER.md)  
**Bootstrap (kept):** [GRACE-TRIAGE-DETELINA-RAISE-2026-08-12.md](GRACE-TRIAGE-DETELINA-RAISE-2026-08-12.md)

## Decision

| Item | Value |
|------|--------|
| Budget | **60** tasks (band 50–70) |
| IDs | **DET-001..060** |
| Placement | prichindel process · tersagor IRC ruler · no new VM |
| Bot | @BiopoleBot · vault paths only |
| Chroma | CHROMA-BIOPOLE-OP |
| Coarse DET-RAISE-01..03 | **DONE** — superseded by fine rows |

## Execution order

1. **W0** DET-001..008 — Grace/Ethan/Liam/Noah/Cursor spine (001 DONE on land)  
2. **W1–W2** DET-009..023 — Abelard (+ Gena/Felix as needed) runtime  
3. **W3–W4** DET-024..036 — chroma + IRC peer  
4. **W5–W6** DET-037..046 — n8n/Planfix/seat  
5. **W7** DET-047..054 — Ava/Olivia/Daniel smoke  
6. **W8** DET-055..060 — close / Ethan exit  

## SuiteCRM

All `SUITE: YES`. Batch: `bash scripts/suitecrm_sync_on_triage.sh` (wave) / per-id.

## Product revise (same day — before grind)

Operator: bot is **talky** secretary/manager/sales (**deny-first**), **not** DevOps/IT.  
Packet: [GRACE-REVISE-DETELINA-PRODUCT-IDENTITY-2026-08-12.md](GRACE-REVISE-DETELINA-PRODUCT-IDENTITY-2026-08-12.md). Abelard = platform only. Grind after Ethan DET-002/003.

## Assign

**Abelard** owns W1–W4 **platform** raise. **Gena** deny contracts. **Ava** talky smokes. **Ethan** identity + exit.

SIGNED: Triage (Grace) | DET-RAISE expand 60 | 2026-08-12 | proceed tasking
