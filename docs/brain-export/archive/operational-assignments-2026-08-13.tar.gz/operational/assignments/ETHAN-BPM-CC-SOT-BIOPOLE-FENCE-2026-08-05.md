# Ethan — Ops Method / BPM ownership + Biopole delivery fence

**Task:** BPM-D2-02 · **Date:** 2026-08-05 · **Status:** RATIFIED (operator lock + REVISE2)

## Law

| Role | Who |
|------|-----|
| Product governor / SOT | **CC_** → GitHub **`Consolidare-Continuum/bpm`** |
| Workbench (daily) | brain `projects/ops-method/` on **altitudine** |
| Client / method subject | **Biopole** — first engagement; may receive **full** product tree + on-demand DB |
| Not a BPM subject | **CC_ itself** (company is governor, not a shop client) |

## One-way fence

1. **Allowed out:** full product copy + DB recipe → `/data/CLIENTS/biopole` and/or `biopoleMD/main_data` **on request**.
2. **Forbidden in:** Biopole client dirt, Planfix secrets, engagement dumps, client-only cards → must **not** enter `Consolidare-Continuum/bpm` SOT.
3. **Promote to CC/bpm:** Hesperia-style gate only — operator chat permission + `CC_PUSH_PERMISSION=1` on the bpm mirror script. No blind `git push`.

## Runtime (this engagement)

Locked local stack only — [RUNTIME-STACK.md](../../projects/ops-method/RUNTIME-STACK.md). LAN/public bind is a separate Abelard decision, not implied by delivery.

## Refs

- [GRACE-TRIAGE-BPM-3DAY-REVISE2-2026-08-05.md](GRACE-TRIAGE-BPM-3DAY-REVISE2-2026-08-05.md)
- [ETHAN-POLICY-CC-GITHUB-ORG.md](../../governance/ETHAN-POLICY-CC-GITHUB-ORG.md) (pattern)
- On-demand DB: [ON-DEMAND-DB-RECIPE.md](../../projects/ops-method/ON-DEMAND-DB-RECIPE.md)

SIGNED: Ethan | BPM-D2-02 CC/bpm SOT + Biopole fence | 2026-08-05 | policy
