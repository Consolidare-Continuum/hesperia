# Grace triage — Detelina TG: no TRANSREIL legal entity in bot speech

**Date:** 2026-08-12 · **Boss:** igareosh · **Triage:** Grace  
**Status:** LIVE

## Decision

Public Detelina Telegram (and same bot speech in other environments) speaks as **Biopole** brand only.

**Remove** from bot-facing speech / prompts / help strings: **TRANSREIL-SERVICE S.R.L.** / Transreil-Service / Trans-Reil Service (any spelling).

**Keep:** `office@biopole.md` · `https://biopole.md` / `/contacts` · phone · Biopole / Биополе product voice.

## Why

Bot will run in different environments; legal-entity parent name is not part of the public multi-env consultant surface.

## Surfaces touched

- `assistant.ts` SYSTEM_BASE + sanitize scrub  
- `settings/private_en.yaml` help / assistant strings  
- `src/config/index.ts` HELP_MESSAGE fallback  
- Grace site-map note  
- planfix-workspace telegram_ai_bot mirror  

IDE/office Detelina identity rules outside the TG public edge are out of this ticket unless boss expands scope.

SIGNED: Triage (Grace) | no-TRANSREIL bot speech | 2026-08-12


## AMENDED 2026-08-12 (boss)

Hard “never name legal entity” **superseded**. Site-true company name OK; do not blend into discussion. Multi-country — no Moldova-first. See [GRACE-TRIAGE-DETELINA-MULTI-COUNTRY-LEGAL-SITE-TRUE-2026-08-12.md](./GRACE-TRIAGE-DETELINA-MULTI-COUNTRY-LEGAL-SITE-TRUE-2026-08-12.md).
