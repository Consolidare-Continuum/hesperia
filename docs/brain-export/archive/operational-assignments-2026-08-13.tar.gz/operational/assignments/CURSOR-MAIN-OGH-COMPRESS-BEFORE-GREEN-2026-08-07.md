# Cursor main — OGH compress before green (2026-08-07)

**Authority:** Operator — "Cursor main, allowed to adjust list where needed before green."

## Verdict

**ARGUE stood.** List adjusted. **Green-set = 24 OPEN** fitness rows. **42 SKIP/DONE** (soft notes, W3 stubs, pointer spray, negative affirms).

## Keep (execute)

OGH-002, OGH-003, OGH-005, OGH-009, OGH-010, OGH-011, OGH-012, OGH-013, OGH-014, OGH-015, OGH-016, OGH-017, OGH-018, OGH-020, OGH-025, OGH-026, OGH-029, OGH-037, OGH-038, OGH-039, OGH-047, OGH-048, OGH-068, OGH-070

## SKIP clusters

1. **W3 entity stubs** OGH-059..066 — theater  
2. **Pointer spray / FAQ / topic maps** — canon OVERAPI § already  
3. **Negative affirms** (no MCP in harness, no service row, etc.) → **OGH-009**  
4. **Thinking-map / MCP library params** — **deferred** (not OGH); was only OGH-044

## G4 redefine

Wave closes when **green-set** DONE + SKIP accepted — **not** when all 70 were executed as prose.

## Next

Operator/Cursor: proceed green-set (Ethan **002** first). **Deferred ADDRESSED** — CSB wave [GRACE-TRIAGE-CSB-ATM-MCP-LIBRARY-PARAMS-2026-08-07.md](GRACE-TRIAGE-CSB-ATM-MCP-LIBRARY-PARAMS-2026-08-07.md) · [SPEC-ETHAN-CSB-CHEATSHEET-BRICK-MUSCLE.md](../../governance/SPEC-ETHAN-CSB-CHEATSHEET-BRICK-MUSCLE.md).

SIGNED: Cursor main | OGH compress before green | 2026-08-07 | compliance cut
