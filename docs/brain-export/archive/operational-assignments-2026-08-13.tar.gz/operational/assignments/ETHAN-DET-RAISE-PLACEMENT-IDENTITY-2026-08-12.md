# Ethan — DET-RAISE placement + product identity (SIGNED)

**Date:** 2026-08-12  
**Tasks:** DET-002 · DET-003  
**Refs:** [GRACE-REVISE-DETELINA-PRODUCT-IDENTITY-2026-08-12.md](GRACE-REVISE-DETELINA-PRODUCT-IDENTITY-2026-08-12.md) · [DET-RAISE-2026-REGISTER.md](../../governance/DET-RAISE-2026-REGISTER.md)

## DET-002 — Placement + identity (RATIFIED)

| Item | Decision |
|------|----------|
| Process host | **prichindel** under `/data/CLIENTS/biopole` (+ seat `/home/biopole-op`) |
| Mesh ruler | **tersagor** Ergo/SDK — **not** bot identity host |
| VM | **No** new VM |
| Kind | **Talky** office bot (@BiopoleBot / Detelina face) |
| Roles | **secretary · manager · sales** (mix unknown; those three dominate) |
| Posture | **Deny-first** — refuse IT / dev / ops / cluster / deploy actions |
| Not | DevOps bot · IT agent · tersagor SDK twin · Abelard executor |

## DET-003 — Boundaries (RATIFIED)

1. No new VM for Detelina/@BiopoleBot.  
2. Seat/bot Chroma = **CHROMA-BIOPOLE-OP** only — **never** CHROMA-1.  
3. IRC: separate peer nick on tersagor Ergo = **observability plumbing only**; do **not** reuse `tersagor` / `imirc-tersagor-presence`.  
4. Bot **MUST deny** IT/dev/ops tool surface (SSH, deploy, docker, cluster, code-ship). Prefer refuse over add.  
5. Abelard wave rows = **platform** (vault, unit, health, chroma URL, IRC peer process) — not product personality.  
6. Client-local board stays out of central heartbeat merge.

## Grind unlock

Ethan DET-002/003 **SIGNED** → Abelard platform grind (DET-009+) may proceed under AWP.

SIGNED: Architecture (Ethan) | DET-RAISE placement+identity | 2026-08-12 | DET-002 DET-003
