# Ethan → Grace → Abelard — Node ≥20 for Defuddle CLI (altitudine)

**Date:** 2026-08-13  
**From:** Ethan (operator: “inbox task to abelard”)  
**Intended owner after triage:** Abelard  
**Host:** altitudine (`execution_host=altitudine`)

## Context

Portable Agent Skills harvested from kepano/obsidian-skills into:

- `.cursor/skills/defuddle/`
- `~/.cursor/skills/defuddle/`

Defuddle CLI install under `$HOME/.local` failed usability on **Node v18.19.1** (`ERR_REQUIRE_ESM` / linkedom↔css-select). Skill docs already require **Node ≥ 20**.

## Ask (Abelard)

1. Provide a supported **Node ≥ 20** path on **altitudine** for agent/user tooling (nvm/nodesource/distro — Abelard choice; prefer non-destructive to system Node 18 if other stacks depend on it).
2. Install `defuddle` so `defuddle parse <url> --md` works for `igareosh` (user prefix `$HOME/.local` OK).
3. Verify once: `defuddle parse https://example.com --md | head`.
4. Note PATH (`~/.local/bin`) in a one-liner under `cluster/altitudine/` or Abelard quick ops if not already covered — no product Obsidian work.

## Out of scope

- Obsidian purchase / Bases / Obsidian CLI
- Changing brain skill content except if install path differs from skill text (then patch `.cursor/skills/defuddle/SKILL.md` + re-sync `~/.cursor/skills/`)

## Done when

`which defuddle` resolves and a sample `--md` parse succeeds on altitudine as `igareosh`.

SIGNED: Team lead (Ethan) | inbox → Abelard | 2026-08-13 | defuddle Node20
