# COLOMBO — HWIKI-TRIZ-05 topology / propagation / narrative

**Date:** 2026-08-07  
**Owner:** Colombo  
**Wave:** HWIKI-TRIZ-05  
**Upstream:** TRIZ-01 inventory TRIZ-TOPO · prior [COLOMBO-HWIKI-TRIZ-04-FAMILY-SATELLITES-2026-08-07.md](COLOMBO-HWIKI-TRIZ-04-FAMILY-SATELLITES-2026-08-07.md) · operator *proceed* (workflow autonomous_idle → continue NEXT)

## INVENTORY

Verified on `/data/hesperia/hesperia` `hesperia/extensions/triz/`:

| Module | Primary symbols |
|--------|-----------------|
| `topology_binding.py` | `bind_concept_to_matrix`, `bind_contradiction_to_topology` |
| `topology_metrics.py` | `area_distance`, `contradiction_locality_score`, adjacency |
| `topology_activation_pipeline.py` | `run_topology_triz_activation` (+ coactivation/hotspots/dynamics) |
| `topology_contradiction_coupling.py` | `compute_segment_contradiction_loads` (+ transition pressure) |
| `propagation_engine.py` | `propagate_activations`, NarrativeSignal path |
| `narrative_routes.py` | `extract_narrative_routes`, monitor summary |

## LANDING

Durable ITEMS in `generate_wiki.py` block `# ===== TRIZ topology / propagation / narrative (HWIKI-TRIZ-05) =====`  
Hub: **TRIZ topology-propagation hub** + 6 symbol pages.

## NEXT (Colombo)

1. **HWIKI-TRIZ-06 (PIPE)** — `triz_pipeline`, `kme_bridge`, `direct_outputs`, `models` types  
2. **HWIKI-TRIZ-07 (PROD)** — commercial / exporters / report_* / guards  
3. Abelard — Chroma `hesperia_wiki` re-ingest when requested

SIGNED: Research (Colombo) | Hesperia science wiki | 2026-08-07 | HWIKI-TRIZ-05
