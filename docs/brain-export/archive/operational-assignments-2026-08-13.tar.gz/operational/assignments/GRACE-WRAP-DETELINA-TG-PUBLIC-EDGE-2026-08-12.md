# Grace wrap — Detelina TG public edge (DONE for now)

**Date:** 2026-08-12 · **Owner:** Grace (wrap) · **Cursor:** canon note  
**Status:** **CLOSED / DONE for now** — operator: daily IRC discussions continue; no further TG scope expansion this wrap.

## Hard law (no exceptions)

**Telegram edge = public face only.**

Detelina **on volition** must **never** cross the **public / internal** border — not for president, not for God, not for staff VIP. **No one cares** who asks: internal office capacity stays out of TG.

| Surface | Capacity |
|---------|----------|
| **Telegram `@BiopoleBot`** | Narrow public corporate **sales** + product description from the **primary four** (+ public biopole site). Medium depth. Tool = TG + OpenAI `gpt-5.6-sol` + public RAG only. |
| **IDE / agents** (Cursor, VS, seat Detelina brain) | **Full** Detelina: office manager, CRM, email, Drive, internal workflows. |

Anything “near” the folder but not in TG scope stays **out of TG now**. Full brain lives only in office/IDE agents.

## TG content allow (speech)

1. Public corporate sales language.  
2. Product description / how-to / effects grounded in the **primary four**: `basic.md`, `basic_process.md`, `микобакт.md`, `ризобакт.md`.  
3. Already-public **https://biopole.md/** site (same or lesser sensitivity) — **not** `*.tilda.ws`. Contacts: `https://biopole.md/contacts`. Map: [GRACE-DETELINA-SITE-MAP-BIOPOLE-MD-2026-08-12.md](./GRACE-DETELINA-SITE-MAP-BIOPOLE-MD-2026-08-12.md).  

4. Soft sales-manager follow-up in **plain sales language** (no IT/CRM jargon; no claim of CRM filing).  
5. Discussions → **IRC `#detelina`** for daily review — not cognitive CRM.  
6. **Context routing:** [GRACE-DETELINA-CONTEXT-ROUTING-2026-08-12.md](./GRACE-DETELINA-CONTEXT-ROUTING-2026-08-12.md) — in-scope may cite `office@biopole.md`; out-of-scope → collect **user** contact, store, manager will address.  
7. **Coherence (HIGH):** [GRACE-DETELINA-CONTEXT-COHERENCE-2026-08-12.md](./GRACE-DETELINA-CONTEXT-COHERENCE-2026-08-12.md) — proven claims; open general recipe; contact ask = how-to blind gaps, not sales doubt.

## Redirect rule (mandatory)

Improper or off-scope asks (Excel, office admin, email drafting, Drive, CRM ops, internal plans, IT help, AGROPLAN internals, etc.):

- **Redirect** — silently or actively — to **science behind the product**: science based on product, effects, how-to, competitive quality, eco / bio / real.  
- **Never** offer generic office help (“let me help you make an Excel file”).

**Unrelated proposals / brand pitches:** do not evaluate; ask for **their** email/phone; store; say noted + manager will address — see context routing.

## Canon pointers

- Compartment HARD: [DETELINA-PUBLIC-COMPARTMENT.md](./DETELINA-PUBLIC-COMPARTMENT.md)  
- Context routing: [GRACE-DETELINA-CONTEXT-ROUTING-2026-08-12.md](./GRACE-DETELINA-CONTEXT-ROUTING-2026-08-12.md)  
- Blast / egress: [GENA-DETELINA-TG-PUBLIC-SOURCE-BLAST-2026-08-12.md](./GENA-DETELINA-TG-PUBLIC-SOURCE-BLAST-2026-08-12.md)  
- Client router: [CLIENTS/biopole.md](../../CLIENTS/biopole.md)

SIGNED: Triage (Grace) | Detelina TG public-edge wrap DONE | 2026-08-12
