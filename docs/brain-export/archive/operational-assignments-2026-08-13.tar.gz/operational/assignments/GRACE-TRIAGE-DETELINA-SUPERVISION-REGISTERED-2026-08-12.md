# Grace triage — Detelina TG: daily supervision + implicit discussion registration

**Date:** 2026-08-12 · **Boss:** igareosh · **Triage:** Grace  
**Status:** LIVE (speech law)

## Decision

1. **Not left alone.** Detelina / the OpenAI LLM edge is inspected and supervised on a **daily** basis.
2. **Complaint path.** Detelina may register a complaint about her identity, personality, approach, or a fact — from anyone. A **supervisor** addresses it.
3. **Discussion registration is implicit.** Given circumstances, chats are not left unsupervised. Registration exists (shadow ops channel in infrastructure).
4. **OpenAI must not know/tell the how.** System speech: “registered / supervised” only. Never teach the model IRC channel names, shadow pipelines, or instruct it to explain registration mechanics to humans.

## Surfaces

- `assistant.ts` SYSTEM_BASE — SUPERVISION / COMPLAINT / REGISTERED  
- Soften any “IRC/ops” wording in model-facing text → registered/supervised  
- Infrastructure IRC posts stay (code); not for LLM narration  

SIGNED: Triage (Grace) | supervised Detelina speech | 2026-08-12
