# Grace triage — conn.local cluster awareness map

**Date:** 2026-08-11  
**CSP:** From: Cursor Context → To: Grace triage Context | Reason: operator AWP for conn.local | What changes: active.md rows; execution Gena then Abelard  

**Project:** `cluster` · **ID prefix:** `CONN-`  
**Domain:** `conn.local` / `conn.prichindel.local` → prichindel `192.168.100.21`

---

## Trigger

Operator AWP: Gena create agentic/human UI map of all cluster hosts (LAN, Tailscale, connections, services carried, active connections); permanent per-host reporter to awareness map; Abelard deploy on prichindel `.local`; dnsmaster domain.

## Rows

| ID | Owner | Scope | Status |
|----|-------|-------|--------|
| **CONN-00** | Grace | This triage + SuiteCRM bootstrap | DONE |
| **CONN-01** | Gena | Hub + map UI + agent reporter + host registry (brain `cluster/conn/`) | DONE |
| **CONN-02** | Abelard | Deploy hub on prichindel; nginx TLS; DNS rewrites; roll agent systemd on Linux hosts | DONE |

**Wrap:** [CONN-LOCAL-WRAP-2026-08-11.md](reports/CONN-LOCAL-WRAP-2026-08-11.md) — live HTTPS + DNS + reporters verified 2026-08-11.

## Exit criteria

1. `https://conn.prichindel.local` (and `conn.local`) serves map UI + `/api/map` JSON.
2. Registry lists canonical LAN hosts; live reports mark availability.
3. At least hub host + altitudine agent report permanently (systemd).
4. dnsmaster AdGuard rewrites: `conn`, `conn.local`, `conn.prichindel.local` → `192.168.100.21`.

## Do not

- Expose on vaporas / public internet.
- Replace Prometheus or malus — this is awareness map only.

SIGNED: Triage (Grace) | conn.local awareness map | 2026-08-11 | CONN-00
