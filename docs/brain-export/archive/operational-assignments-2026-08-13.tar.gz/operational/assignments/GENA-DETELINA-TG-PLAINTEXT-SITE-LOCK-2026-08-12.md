# Gena — Detelina TG: plain text + site URL hard lock

**Date:** 2026-08-12 · **Owner:** Gena  
**Trigger:** Operator sample still showed `**…**` and `https://biopole-md.tilda.ws/contacts` despite Grace site map.

## Fix

| Layer | Change |
|-------|--------|
| Prompt | `SITE URL LOCK` — only `biopole.md` / `/contacts`; never `*.tilda.ws` |
| Prompt | `TELEGRAM PLAIN TEXT` — no Markdown stars |
| Code | `sanitizePublicReply()` — rewrite tilda→biopole.md, strip `**` / `__` / etc. |
| Send | `reply()` default = **plain text** (no `parse_mode: Markdown`) |
| Runtime | scrubbed `detelina_tg_runtime/chat_history.json` |

## Advertised surface (checked)

Canonical: `https://biopole.md/` · `https://biopole.md/contacts`  
Legacy `biopole-md.tilda.ws` must not appear in outbound TG text (sanitizer + prompt).

SIGNED: Developer (Gena) | Detelina TG plain-text + site lock | 2026-08-12
