# Grace triage — HES-TEST (LLM/agent yield) — **no freezes**

**Date:** 2026-08-10  
**CSP:** From: Ethan gap list → To: Grace triage | Reason: operator *triage but no freezes* | What changes: active.md OPEN; no freeze gates  

**Project:** `hesperia` · **ID prefix:** `HES-TEST-`  
**Ethan ask (chat):** What is missing before testing mode — general default ~100 books + areas structure vs LLM/agents — all params (even uncalibrated) yielded on LLM API / agent requests into or along with Hesperia.  

**Hard operator constraint:** **No freezes** — do **not** invent corpus-freeze ceremonies, schema freezes, VERSION freezes, or “freeze date” gates. Use live default packs and labeled dumps; snapshots if any are **optional labels only**, never blockers.

**Out of this board:** field-module productization; act/real-data enablement; CC promote; medicine-market framing (speech ban stamp).

---

## WBS (Ethan gaps → rows; freeze gap dropped)

| Gap | Action |
|-----|--------|
| Testing envelope | Design + land `meta.testing_params` (or equiv.) — full/wide params + status live/stub/uncalibrated |
| Corpus freeze | **DROPPED** per operator |
| Books ↔ matrix on live path | Attach retrieval/bounding **without** freeze gate |
| Default books pack | Load/use existing ~100/120 mapping + available chunks as **default testing pack** (mutable OK) |
| Agent request path | Standardize router + context_rag (+ optional read-only bridge later) — **no act tier** |
| LLM API attach | product/interpret / inquire carry testing packet |
| Uncalibrated honesty | Labels on every stub/PARTIAL |
| matrix_run / context_rag | Default-on in testing mode flag |

**Cadence:** A (ratify) → B (envelope) → C (contract/labels) → D (books/matrix attach) → E (agent/LLM path) → F (smoke) → wrap.  
**Budget:** ~24 OPEN (+ triage DONE).

---

## Rows

| ID | Owner | Task | Status |
|----|-------|------|--------|
| **HES-TEST-00** | Grace | This triage (no-freeze testing mode) | DONE on write |
| **HES-TEST-A01** | Ethan | Ratify HES-TEST WBS; confirm no-freeze constraint in writing | OPEN |
| **HES-TEST-A02** | Ethan | Define testing envelope shape (keys + honesty statuses) — no freeze | OPEN |
| **HES-TEST-A03** | Daniel | Security advise: testing dump default-off; act/real-data stay off | OPEN |
| **HES-TEST-A04** | Olivia | Confirm public schema stays thin; testing packet additive/optional | OPEN |
| **HES-TEST-B01** | Felix | Implement flag-gated testing envelope emit (`HESPERIA_TESTING_PARAMS` or agreed name) | OPEN |
| **HES-TEST-B02** | Felix | Map parameter_catalog / output slots → envelope with live\|stub\|uncalibrated | OPEN |
| **HES-TEST-B03** | Felix | Unit tests: flag off = no dump; flag on = labeled params | OPEN |
| **HES-TEST-C01** | Ava | Honesty labels matrix (stub/PARTIAL/uncalibrated/live) | OPEN |
| **HES-TEST-C02** | Ava | Operator labels: testing dump ≠ calibrated product claim | OPEN |
| **HES-TEST-C03** | Olivia | Contract delta note for optional testing meta | OPEN |
| **HES-TEST-D01** | Cursor | Inventory default books/areas assets (120 map + Chroma families/books) — no freeze | OPEN |
| **HES-TEST-D02** | Abelard | Make default pack reachable to runtime/router path (mutable OK; no freeze) | OPEN |
| **HES-TEST-D03** | Felix | Attach retrieval_context / bounding on inquire+interpret when testing on | OPEN |
| **HES-TEST-D04** | Colombo | Honesty note: empty retrieval vs attached pack (PARTIAL allowed) | OPEN |
| **HES-TEST-E01** | Ethan | Ratify agent path: router+context_rag (+ read-only bridge optional later) | OPEN |
| **HES-TEST-E02** | Felix | Wire testing envelope onto `/product/interpret` and router inquire path | OPEN |
| **HES-TEST-E03** | Emma | Agent request contract stub: request into / along with Hesperia | OPEN |
| **HES-TEST-E04** | Noah | AI-TEST plan: LLM sees labeled params; no invented calibrated claims | OPEN |
| **HES-TEST-F01** | Liam | SCRIPT-RUNBOOK testing-mode smoke (flags + inquire + interpret) | OPEN |
| **HES-TEST-F02** | Liam | Dry-run smoke once; file outcome | OPEN |
| **HES-TEST-F03** | Sophia | Runtime awareness: testing flags off in prod unless GO | OPEN |
| **HES-TEST-F04** | Ava | Smoke OFF/ON testing envelope | OPEN |
| **HES-TEST-99** | Grace | Wrap digest (no freeze; residuals) | OPEN |

**OPEN count:** 23 (+ HES-TEST-00 DONE).

## Exit criteria

1. Testing envelope flag-gated and labeled.  
2. Default books/areas path attachable **without** freeze ceremony.  
3. LLM/agent inquire/interpret can carry the packet.  
4. Act/real-data remain off.  
5. **No** corpus/schema/VERSION freeze tasks on this board.

SIGNED: Triage (Grace) | HES-TEST no-freeze | 2026-08-10 | HES-TEST-00
