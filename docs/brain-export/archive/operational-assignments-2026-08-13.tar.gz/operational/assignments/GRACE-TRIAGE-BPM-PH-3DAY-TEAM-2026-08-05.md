# Grace triage expand — 3-day team wave (Ops Method → Biopole handoff)

**Date:** 2026-08-05  
**Operator:** Grace task team for all 3 days main tasks  
**Upstream:** [GRACE-TRIAGE-OPS-METHOD-PRODUCTIZE-BIOPOLE-HANDOFF-2026-08-05.md](GRACE-TRIAGE-OPS-METHOD-PRODUCTIZE-BIOPOLE-HANDOFF-2026-08-05.md)  
**CSP:** From Cursor → Grace (triage expand) → team execute by day

## Ownership (unchanged)

CC_ governs product · `Consolidare-Continuum/bpm` = SOT · Biopole = first client / method subject (full copy allowed) · CC_ is **not** BPM subject.

## Day map (main tasks only)

| Day | Theme | Exit |
|-----|--------|------|
| **D1** | Shop → cart → LLM → agent **GREEN** on lab | Ava smoke PASS; Biopole can open UI and shop |
| **D2** | On-demand DB + CC policy | Abelard recipe + Ethan policy ratified |
| **D3** | CC/bpm seed + Biopole deliver pack | Wire ready; push on operator `CC_PUSH_PERMISSION`; deliver path documented |

```
D1 product face → D2 reliability/policy → D3 SOT + handoff pack → Biopole shops
```

---

## Day 1 — product face (shop / cart / LLM / agent)

| ID | Owner | Status | Main task |
|----|-------|--------|-----------|
| **BPM-PH-01** | Felix | **DONE** | Cart UI + LLM promote + `cart_agent_runner.py` |
| **BPM-D1-02** | Ava | OPEN | **Main:** Smoke shop→cart→LLM→agent GREEN (`CLI-BIOPOLE`); stamp smoke report |
| **BPM-D1-03** | Felix | OPEN | **Main:** README freeze drift + LAN/DNS start URL (`company-ui`, `CLI-BIOPOLE`) aligned with [BIOPOLE-SHOP-START.md](../../projects/ops-method/BIOPOLE-SHOP-START.md) |
| **BPM-D1-04** | Ava | OPEN | Cart-button / checkout-mode UI smoke (header Корзина opens cart; shop↔checkout) |

*Supersedes loose BPM-PH-02 → retarget as BPM-D1-02 (same work; PH-02 closed as duplicate).*

---

## Runtime stack lock (operator revise 2026-08-05)

Canonical: [RUNTIME-STACK.md](../../projects/ops-method/RUNTIME-STACK.md) — altitudine · `ops-method-pg` @ `127.0.0.1:5433` · AGV `127.0.0.1:8765` · `ops_method_dev` local only · schema through **034** · UI from `agv_ui/` including `company.html`. Day-2 “on-demand DB” = **copy/clone of this local docker posture**, not a new public host.

## Day 2 — DB recipe + policy

| ID | Owner | Status | Main task |
|----|-------|--------|-----------|
| **BPM-D2-01** | Abelard | OPEN | **Main:** On-demand Postgres recipe = dump/clone of altitudine `ops-method-pg` (`127.0.0.1:5433` / `ops_method`) for Biopole engagement copy + AGV DSN bind doc |
| **BPM-D2-02** | Ethan | OPEN | **Main:** Ratify policy — `Consolidare-Continuum/bpm` SOT + Biopole full-copy delivery (addendum to CC GitHub org policy) |
| **BPM-D2-03** | Ava | OPEN | Smoke dry-run: recipe steps readable; AGV health against intended handoff DSN note |
| **BPM-D2-04** | Felix | OPEN | Export/cart session log path documented for Biopole Cursor agents (`cart_agent_runner --allow-remote`) |

*BPM-PH-03 → D2-01 · BPM-PH-04 → D2-02 (close PH as superseded).*

---

## Day 3 — CC seed + deliver

| ID | Owner | Status | Main task |
|----|-------|--------|-----------|
| **BPM-D3-01** | Abelard | OPEN | **Main:** Local clone `/data/consolidare-continuum/bpm` (`no_push`), deploy-key/org access, gated mirror script stub |
| **BPM-D3-02** | Grace | OPEN | **Main:** `agents/grace/CC-BPM-REPO-MANAGER.md` + consolidare-continuum README `bpm/` entry |
| **BPM-D3-03** | Ethan | OPEN | Corporate overlay checklist (LICENSE/NOTICE) for Ops Method under CC_ |
| **BPM-D3-04** | Grace + Gena | OPEN | **Main:** Biopole deliver pack path — full product into `/data/CLIENTS/biopole` and/or `biopoleMD/main_data` **on request** |
| **BPM-D3-05** | Ethan | OPEN | Sign **BPM-HANDOFF-READY** when D1–D3 mains GREEN (push still needs operator `CC_PUSH_PERMISSION`) |

*BPM-PH-05 → D3-01+D3-02 · BPM-PH-06 → D3-04.*

**Operator gate (not a team row):** `CC_PUSH_PERMISSION=1` for first GitHub seed to `Consolidare-Continuum/bpm`.

---

## Closed / superseded (cleanup)

| ID | Action |
|----|--------|
| BPM-PH-00 | DONE (bootstrap triage) |
| BPM-PH-01 | DONE |
| BPM-PH-02 | **DONE** — superseded by **BPM-D1-02** |
| BPM-PH-03 | **DONE** — superseded by **BPM-D2-01** |
| BPM-PH-04 | **DONE** — superseded by **BPM-D2-02** |
| BPM-PH-05 | **DONE** — superseded by **BPM-D3-01** + **BPM-D3-02** |
| BPM-PH-06 | **DONE** — superseded by **BPM-D3-04** |

---

## Assign to (digest)

- **Felix** — D1-03, D2-04  
- **Ava** — D1-02, D1-04, D2-03  
- **Abelard** — D2-01, D3-01  
- **Ethan** — D2-02, D3-03, D3-05  
- **Grace** — D3-02; co-own D3-04 with Gena  
- **Gena** — D3-04 (Biopole client tree / main_data placement)

SIGNED: Triage (Grace) | 3-day BPM-PH team wave | 2026-08-05 | ops-method · CC_ · Biopole
