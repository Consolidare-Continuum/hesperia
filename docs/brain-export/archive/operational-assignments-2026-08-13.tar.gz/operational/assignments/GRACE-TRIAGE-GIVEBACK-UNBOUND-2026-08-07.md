# Grace triage — unbound giveback wave (2026-08-07)

**From:** Cursor main giving-back / operator unbound  
**To:** Grace → owners  
**Reason:** Address remaining giveback items until green (LTS / compliance).

## Rows

| ID | Owner | Work |
|----|-------|------|
| **GB-DIRTY-01** | Cursor | Dirty-tree commit/park waves (wiki / ops-method / governance / giveback) |
| **GB-DEP-01** | Abelard | Dependabot triage `igareosh/cursor` IDE-only; Cloud Agent forbidden |
| **GB-CERT-01** | Abelard | Agent SSH cert renewed early (valid_until → 2026-08-08T16:10Z) + renew script REPO_ROOT fix |
| **GB-MDC-01** | Abelard/Felix | `ingest.py` collect `.mdc` + allow `.cursor`/`.codex`; staging README legacy |
| **GB-WIN-01** | Cursor main | Win register August books-home + EOM clean close |
| **GB-MKT-01** | Cursor main | Marketplace deep scan vs `mcp-config.json` |
| **GB-CHROMA-01** | Abelard | CHROMA-1 whole-repo reingest `--keep-layer fpf` |
| **GB-SUITE-01** | Grace/Cursor | SuiteCRM vs DONE — OGH/CSB Completed backfill |
| **GB-BIO-01** | Abelard | Biopole host — HDD wait; alert expected; no software close |

## Policy

- Cloud Agent stay allowlist: **not** `igareosh/cursor`.
- Mass CHROMA ingest = Abelard only.
- BiopoleUnreachable = expected until disk replaced.

SIGNED: Triage (Grace) | unbound giveback | 2026-08-07
