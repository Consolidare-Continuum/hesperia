# FPF Thinking Map 1.9.5 — live MCP adversarial verification

Target: `cursor-fpf-test-mcp` on `prichindel`, using the exact SSH/stdio
command configured in `.cursor/mcp.json`.

## Artifacts

- `run_live_mcp_adversarial.py` — rerunnable source for the 20 independent
  compatibility and failure-path checks. It also invokes the live MCP's
  bundled 35-check verifier. It exits non-zero on failure.
- `RESULT-2026-08-01.json` — captured result against release `1.9.5`, commit
  `308369fb233386c8e53156bb37019b00953f8417`.

Runner SHA-256:

```text
3fb91bd9a537d120df8cf7f55c7d29c3a2dfa541cc7c979494259395c3138ad1
```

## Re-run

From the brain repository root on `altitudine`:

```bash
python3 operational/assignments/fpf-1.9.5-prichindel-adversarial/run_live_mcp_adversarial.py
```

Prerequisites are the existing `prichindel` SSH alias/certificate and the
local Python `mcp` client package. The runner talks through MCP; it does not
directly import the remote checkout.

## Captured verdict

- MCP bundled verification: 35/35
- Independent adversarial scenarios: 20/20
- `dev_mcp.test_server` host harness: 38/38
- release `SHA256SUMS`: 87/87

ADV-03 and ADV-08 are expected observations from deliberately constructing a
fresh in-memory test state. They are recorded in the result and were not
treated as failures.
