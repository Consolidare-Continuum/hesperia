#!/usr/bin/env python3
"""Re-run the 1.9.5 compatibility adversarials through cursor-fpf-test-mcp.

This opens the same SSH/stdio MCP command configured for Cursor. It does not
import the checkout directly. Exit status is non-zero if the bundled verifier
or any independent scenario check fails.
"""

from __future__ import annotations

import ast
import asyncio
import json
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


REMOTE_COMMAND = (
    'REPO=/data/workspaces/fpf-thinking-map; cd "$REPO" && '
    'PYTHONPATH="$REPO" /data/chroma/venv/bin/python -m dev_mcp.server'
)

SCENARIO = r'''
checks = {}
details = {}

def base_map(transition):
    sm = SemanticMap()
    sm.register_context(ContextPrimitive("ctx", "Context"))
    sm.register_transition(transition)
    return sm

def bound(sm, role_ids=None, evidence=None):
    return ActiveState(
        semantic_map=sm,
        binding=RuntimeBinding(
            actor="actor",
            actor_role_ids=role_ids or [],
            active_context_id="ctx",
            current_evidence=evidence or [],
        ),
        current_state="initial",
    )

# F.6 is map-level opt-in: legacy maps may contain unattributed Work.
t_done = TransitionPrimitive("finish", "Finish", "ctx", "initial", "task_done")
legacy = base_map(t_done)
legacy.register_work(WorkPrimitive("w0", "Legacy work", "ctx", performed_under=None))
legacy_tr = ThinkingMapTraversal(legacy)
legacy_step = legacy_tr.step(bound(legacy), "finish")
legacy_attempt = legacy_tr.attempt_transition(bound(legacy), "finish")
checks["f6_legacy_no_roleassignment_step_allowed"] = legacy_step.kind == OutcomeKind.CONTINUE
checks["f6_legacy_no_roleassignment_attempt_allowed"] = legacy_attempt.kind == OutcomeKind.CONTINUE

auth = base_map(t_done)
auth.register_role(RolePrimitive("worker", "Worker", "ctx"))
auth.register_role_assignment(RoleAssignment("ra", "actor", "worker", "ctx"))
auth.register_work(WorkPrimitive("w1", "Unattributed work", "ctx", performed_under=None))
auth_tr = ThinkingMapTraversal(auth)
auth_out = auth_tr.step(bound(auth), "finish")
checks["f6_opted_in_invalid_attribution_denied"] = auth_out.kind == OutcomeKind.ABSTAIN
checks["f6_denial_is_general_guard_cause"] = auth_out.cause == OutcomeCause.GUARD_DENIAL

# E.16 is transition-level opt-in; AUTONOMOUS remains descriptive.
t_go = TransitionPrimitive("go", "Go", "ctx", "initial", "running")
auto = base_map(t_go)
auto.register_role(RolePrimitive("auto", "Autonomous", "ctx", agency_level=AgencyLevel.AUTONOMOUS))
auto_tr = ThinkingMapTraversal(auto)
auto_out = auto_tr.attempt_transition(bound(auto, ["auto"]), "go")
checks["e16_autonomous_without_budget_allowed"] = auto_out.kind == OutcomeKind.CONTINUE

t_budget = TransitionPrimitive(
    "budgeted", "Budgeted", "ctx", "initial", "running",
    requires_autonomy_budget_id="missing-budget",
)
missing_budget = base_map(t_budget)
missing_budget.register_role(RolePrimitive("auto", "Autonomous", "ctx", agency_level=AgencyLevel.AUTONOMOUS))
missing_budget_out = ThinkingMapTraversal(missing_budget).step(bound(missing_budget, ["auto"]), "budgeted")
checks["e16_explicit_missing_budget_escalates"] = missing_budget_out.kind == OutcomeKind.ESCALATE

# A.21 maximal lattice join and individual BLOCK production.
g_join = GatePrimitive("join", "Join", "ctx", checks=[
    GateCheck("partial", "Partial", ["a", "b"]),
    GateCheck("absent", "Absent", ["c"]),
])
checks["gate_join_degrade_over_abstain"] = g_join.evaluate({"a"}) == GateDecision.DEGRADE
checks["gate_join_pass_over_abstain"] = g_join.evaluate({"a", "b"}) == GateDecision.PASS

g_block = GatePrimitive("hard", "Hard", "ctx", checks=[
    GateCheck("critical", "Critical", ["permit"], failure_decision=GateDecision.BLOCK),
    GateCheck("ordinary", "Ordinary", [], failure_decision=None),
])
checks["gatecheck_can_produce_block"] = g_block.checks[0].evaluate(set()) == GateDecision.BLOCK
checks["gate_join_block_is_maximal"] = g_block.evaluate(set()) == GateDecision.BLOCK

# GateBlocked is exact BLOCK; GateAbstained preserves the former predicate.
gmap = SemanticMap()
gmap.register_context(ContextPrimitive("ctx", "Context"))
gmap.register_gate(g_block)
gmap.register_gate(GatePrimitive("soft", "Soft", "ctx", checks=[GateCheck("need", "Need", ["x"])]))
gstate = bound(gmap)
checks["gateblocked_true_only_for_block"] = (
    GateBlocked("hard").evaluate(gstate)
    and not GateBlocked("soft").evaluate(gstate)
    and not GateBlocked("missing").evaluate(gstate)
)
checks["gateabstained_compatibility"] = (
    GateAbstained("soft").evaluate(gstate)
    and GateAbstained("missing").evaluate(gstate)
    and not GateAbstained("hard").evaluate(gstate)
)

# BLOCK retains OutcomeKind compatibility while preserving a typed cause.
blocked_map = SemanticMap()
blocked_map.register_context(ContextPrimitive("ctx", "Context"))
blocked_map.register_gate(g_block)
blocked_map.register_transition(
    TransitionPrimitive("blocked", "Blocked", "ctx", "initial", "running", required_gate_id="hard")
)
blocked_tr = ThinkingMapTraversal(blocked_map)
blocked_step = blocked_tr.step(bound(blocked_map), "blocked")
blocked_attempt = blocked_tr.attempt_transition(bound(blocked_map), "blocked")
checks["block_step_denied_with_typed_cause"] = (
    blocked_step.kind == OutcomeKind.ABSTAIN and blocked_step.cause == OutcomeCause.GATE_BLOCK
)
checks["block_attempt_denied_with_typed_cause"] = (
    blocked_attempt.kind == OutcomeKind.ABSTAIN and blocked_attempt.cause == OutcomeCause.GATE_BLOCK
)

# Validation is fail-closed when called; legacy runtime stays compatible.
dangling_t = TransitionPrimitive(
    "dangling", "Dangling", "ctx", "initial", "running",
    required_gate_id="ghost-gate", guard_expression="ghost-rule",
)
dangling = base_map(dangling_t)
dangling_tr = ThinkingMapTraversal(dangling)
validation_errors = dangling_tr.validation_errors()
checks["validation_finds_both_dangling_refs"] = (
    len(validation_errors) == 2
    and "ghost-gate" in validation_errors[0]
    and "ghost-rule" in validation_errors[1]
)
try:
    dangling_tr.validate_map()
    validation_raised = False
except MapValidationError as exc:
    validation_raised = len(exc.errors) == 2
checks["validate_map_fails_closed"] = validation_raised
checks["dangling_runtime_remains_legacy_noop"] = (
    dangling_tr.step(bound(dangling), "dangling").kind == OutcomeKind.CONTINUE
)

# Bad transition IDs are explicit denials on both APIs.
plain = base_map(t_go)
plain_tr = ThinkingMapTraversal(plain)
unknown_step = plain_tr.step(bound(plain), "typo")
unknown_attempt = plain_tr.attempt_transition(bound(plain), "typo")
checks["unknown_id_step_denied"] = (
    unknown_step.kind == OutcomeKind.ABSTAIN
    and unknown_step.cause == OutcomeCause.UNKNOWN_TRANSITION
)
checks["unknown_id_attempt_denied"] = (
    unknown_attempt.kind == OutcomeKind.ABSTAIN
    and unknown_attempt.cause == OutcomeCause.UNKNOWN_TRANSITION
)

# Additive cause field did not break historical positional construction.
legacy_outcome = Outcome(OutcomeKind.ABSTAIN, "legacy", "next-state")
checks["outcome_positional_compatibility"] = (
    legacy_outcome.next_state == "next-state" and legacy_outcome.cause is None
)

details["legacy_step"] = legacy_step.to_dict()
details["f6_opted_in"] = auth_out.to_dict()
details["e16_missing_budget"] = missing_budget_out.to_dict()
details["block_step"] = blocked_step.to_dict()
details["unknown_step"] = unknown_step.to_dict()
details["validation_errors"] = validation_errors
result = {
    "all_pass": all(checks.values()),
    "passed": sum(1 for value in checks.values() if value),
    "total": len(checks),
    "failed": [name for name, value in checks.items() if not value],
    "checks": checks,
    "details": details,
}
'''


def text_content(reply) -> str:
    for item in reply.content:
        if getattr(item, "type", None) == "text":
            return item.text
    raise RuntimeError("MCP reply contained no text block")


async def run() -> int:
    params = StdioServerParameters(
        command="ssh",
        args=["prichindel", REMOTE_COMMAND],
    )
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            verify_reply = await session.call_tool("run_verify", {})
            verify_text = text_content(verify_reply)

            scenario_reply = await session.call_tool(
                "run_scenario",
                {"code": SCENARIO, "scope": "core", "compliance_mode": False},
            )
            envelope = json.loads(text_content(scenario_reply))
            if "error" in envelope:
                raise RuntimeError(envelope["error"])
            scenario_result = ast.literal_eval(envelope["result"])

            output = {
                "target": "cursor-fpf-test-mcp / prichindel",
                "verify": verify_text,
                "adversarial": scenario_result,
                "advisories_triggered": envelope.get("advisories_triggered", []),
            }
            print(json.dumps(output, indent=2, ensure_ascii=False))

            verify_ok = "STATUS: ALL PASS" in verify_text
            return 0 if verify_ok and scenario_result["all_pass"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(run()))
    except Exception as exc:  # noqa: BLE001 - CLI reports transport/test failures
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(2)
