# Grace wrap — DET-MCP-LOAD (2026-08-07)

**From:** Abelard  
**Task:** DET-MCP-LOAD (Detelina `active.md`) → **DONE**

## Diagnosis
Project `.cursor/mcp.json` `planfix` / `n8n-mcp` were **leased** but never `CreateClient`’d in Detelina sessions (only user MCP auto-spawned). Planfix also failed under Cursor’s minimal PATH (`python3` without `mcp.server.fastmcp`).

## Fix
- Merge overlay into `~/.cursor/mcp.json` (`user-planfix`, `user-n8n-mcp`)
- Office venv `/home/biopole/.venvs/planfix-mcp` pin `mcp==1.28.1`
- Absolute wrappers; n8n Bearer redacted on stderr
- Removed broken repo `uvx` Chroma entries earlier; global `query_knowledge` kept

## Commits
- `biopoleMD/main_data` `7107e5b`
- `biopoleMD/detelina_agent_brain` `bd2d9f9`

## Live catalog evidence
- Detelina `mcps/`: `user-planfix` (5 tools), `user-n8n-mcp` (18 tools incl. required four), `user-chroma-knowledge`
- Agent `GetMcpTools` / calls: `planfix_list_new_tasks`, `search_workflows` (Detelina*), `query_knowledge`
- `bash /home/biopole/scripts/runtime-status.sh` green

## Untouched (intentional)
- n8n DB flatten
- git history rewrite
- credential rotation
- unrelated Detelina dirty files (`backbone.env`, chroma/context/infra docs, `DETELINA-REPORT-AS-DONE.md`)

## Operator note
After `deploy-mcp-config-global.sh`, re-run:  
`bash /home/biopole/repos/main_data/scripts/merge-biopole-mcp-into-cursor-user.sh`

SIGNED: Abelard | DET-MCP-LOAD | 2026-08-07
