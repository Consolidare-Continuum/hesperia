# Versus Incident Helm Chart

This Helm chart deploys Versus Incident, a robust incident management tool that supports alerting across multiple channels with easy custom messaging and on-call integrations.

## Requirements

- Kubernetes 1.19+
- Helm 3.2.0+
- PV provisioner support in the underlying infrastructure (if persistence is required for Redis)

## Installing the Chart

You can install the Versus Incident Helm chart using OCI registry:

```bash
helm install versus-incident oci://ghcr.io/versuscontrol/charts/versus-incident
```

### Install with Custom Values

```bash
# Install with custom configuration from a values file
helm install \
  versus-incident \
  oci://ghcr.io/versuscontrol/charts/versus-incident \
  -f values.yaml
```

### Upgrading an Existing Installation

```bash
# Upgrade an existing installation with the latest version
helm upgrade \
  versus-incident \
  oci://ghcr.io/versuscontrol/charts/versus-incident

# Upgrade with custom values
helm upgrade \
  versus-incident \
  oci://ghcr.io/versuscontrol/charts/versus-incident \
  -f values.yaml
```

## Configuration

### High Availability / multi-instance (enterprise)

> HA runs the **enterprise** image with a `LICENSE_KEY`. The OSS single-instance
> path (`ha.enabled: false`, the default) is unchanged.

Setting `ha.enabled: true` switches the workload from a **Deployment** to a
**StatefulSet** so each replica gets a stable pod name. The binary reads its
instance index from the `POD_NAME` trailing ordinal (Downward API) and
`INSTANCE_COUNT` from `replicaCount`, then partitions signal sources and the SLO
scheduler job by hash-ownership — so multiple replicas never double-page. All
replicas share **one Postgres** (derived automatically — the binary refuses the
`file` backend with more than one replica) and converge their managed secrets
(session key, AI master key, admin-token hash) through it, so a session cookie or
the break-glass admin token minted on one replica validates on all.

The chart renders, alongside the StatefulSet: a **headless Service** (stable
per-pod DNS), a **PodDisruptionBudget**, a **NetworkPolicy**, **pod
anti-affinity** to spread replicas across nodes, a hardened **securityContext**
(non-root, read-only root filesystem, dropped capabilities), and **readiness +
liveness** probes against `/healthz` for graceful rollout.

```bash
helm upgrade --install versus \
  oci://ghcr.io/versuscontrol/charts/versus-incident \
  -f values-ha.yaml \
  --set enterprise.licenseKey="$LICENSE_KEY" \
  --set storage.postgres.dsn="postgres://versus:PASS@my-rds:5432/versus?sslmode=require" \
  --set gatewaySecret="$(openssl rand -hex 32)"
```

For production / GitOps, reference existing Secrets instead of inline values:

```bash
  --set enterprise.existingSecret=versus-license      # key: license_key
  --set storage.postgres.dsnExistingSecret=versus-pg  # key: postgres_dsn
```

See [`values-ha.yaml`](values-ha.yaml) for the full HA value set, and the raw
(non-Helm) manifests and a Docker Compose walkthrough under
`versus-enterprise/examples/high-availability/`.

| Key | Default | Description |
|---|---|---|
| `ha.enabled` | `false` | Render the StatefulSet HA path (enterprise). |
| `replicaCount` | `2` | Replicas; becomes `INSTANCE_COUNT`. |
| `ha.podManagementPolicy` | `Parallel` | StatefulSet pod start/stop ordering. |
| `ha.updateStrategy.type` | `RollingUpdate` | StatefulSet update strategy. |
| `ha.antiAffinity.enabled` / `.hard` | `true` / `false` | Spread replicas across nodes (soft by default). |
| `ha.podDisruptionBudget.enabled` | `true` | Keep the LB backed during node drains. |
| `ha.networkPolicy.enabled` | `true` | Default-deny ingress; egress allow-all (narrow in prod). |
| `enterprise.licenseKey` / `.existingSecret` | `""` | Enterprise license (required for HA). |
| `storage.postgres.dsn` / `.dsnExistingSecret` | `""` | Shared Postgres DSN (required for postgres). |

### Quick Start Example

```yaml
# values.yaml
replicaCount: 2

# Proxy configuration (for networks that block messaging services)
proxy:
  url: "http://proxy.example.com:8080"
  username: "proxy-user"     # optional
  password: "proxy-pass"     # optional

alert:
  slack:
    enable: true
    token: "xoxb-your-slack-token"
    channelId: "C12345"
    messageProperties:
      buttonText: "Acknowledge Alert"
      buttonStyle: "primary"
  
  telegram:
    enable: false
    botToken: "your-telegram-bot-token"
    chatId: "your-chat-id"
    useProxy: false 
  
  viber:
    enable: false
    botToken: "your-viber-token"
    channelId: "your-channel-id"
    useProxy: false
  
  lark:
    enable: false
    webhookUrl: "your-lark-webhook-url"
    useProxy: false
  
  email:
    enable: false
  
  msteams:
    enable: false
```

### Important Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas for the deployment | `2` |
| `config.publicHost` | Public URL for acknowledgment links | `""` |
| `gatewaySecret` | Shared secret for `/api/admin/*` and `/api/agent/*`. Empty value leaves admin routes unregistered. | `""` |
| `storage.type` | Storage backend (`file`, `redis`, `database`). Only `file` is implemented today. | `"file"` |
| `storage.persistence.enabled` | Mount a PVC at the fixed `/app/data` path so agent state survives restarts | `false` |
| `storage.persistence.size` | PVC request size | `"1Gi"` |
| `agent.enable` | Enable the AI SRE Agent (must run with `replicaCount: 1`) | `false` |
| `agent.mode` | `training`, `shadow`, or `detect` | `"training"` |
| `agent.ai.enable` | Enable LLM analysis in detect mode | `false` |
| `agent.ai.apiKey` | OpenAI API key (stored in chart Secret) | `""` |
| `agent.ai.model` | Model identifier | `"gpt-4o-mini"` |
| `agent.ai.temperature` | Randomness control. Set `-1` to omit the field for beta-limited / reasoning models that reject explicit temperature values. | `0.2` |
| `agent.ai.maxCallsPerHour` | Per-hour AI call rate limit (`0` = unlimited) | `60` |
| `agent.ai.analyze.model` | Override model for the on-demand analyze agent (empty inherits `agent.ai.model`) | `""` |
| `agent.tools.toolTimeout` | Per-tool dispatch timeout for analyze tools | `"20s"` |
| `agent.tools.parallelTools` | Run multiple tool calls in one model turn concurrently | `false` |
| `agent.tools.recentChanges.git.repos` | Remote git repos read by the `recent_changes` tool (empty = unregistered) | `[]` |
| `agent.tools.describeDependencies.services` | Service-dependency graph for the `describe_dependencies` tool (empty = unregistered) | `[]` |
| `agent.tools.findRunbook.embeddingModel` | Embedding model for the `find_runbook` runbook-RAG tool (empty = unregistered) | `""` |
| `agent.sources` | Inline list of signal sources (snake_case keys) | `[]` |
| `alert.slack.enable` | Enable Slack notifications | `false` |
| `alert.slack.token` | Slack bot token | `""` |
| `alert.slack.channelId` | Slack channel ID | `""` |
| `alert.telegram.enable` | Enable Telegram notifications | `false` |
| `alert.email.enable` | Enable email notifications | `false` |
| `alert.msteams.enable` | Enable Microsoft Teams notifications | `false` |
| `alert.lark.enable` | Enable Lark notifications | `false` |
| `alert.viber.enable` | Enable Viber notifications | `false` |
| `alert.viber.apiType` | Viber API type ("channel" or "bot") | `"channel"` |
| `oncall.enable` | Enable on-call functionality | `false` |
| `oncall.provider` | On-call provider ("aws_incident_manager" or "pagerduty") | `"aws_incident_manager"` |
| `redis.enabled` | Enable bundled Redis (required for on-call) | `false` |

## Notification Channel Configuration

### Slack

```yaml
alert:
  slack:
    enable: true
    token: "xoxb-your-slack-token"
    channelId: "C12345"
    messageProperties:
      buttonText: "Acknowledge Alert"
      buttonStyle: "primary" # "primary" (blue), "danger" (red), or empty (default gray)
      disableButton: false
```

### Telegram

```yaml
alert:
  telegram:
    enable: true
    botToken: "your-telegram-bot-token"
    chatId: "your-telegram-chat-id"
```

### Email

```yaml
alert:
  email:
    enable: true
    smtpHost: "smtp.example.com"
    smtpPort: 587
    username: "your-email@example.com"
    password: "your-password"
    to: "alerts@example.com"
    subject: "Incident Alert"
```

### Microsoft Teams

```yaml
alert:
  msteams:
    enable: true
    powerAutomateUrl: "your-power-automate-flow-url"
    otherPowerUrls:
      dev: "dev-team-power-automate-url"
      ops: "ops-team-power-automate-url"
```

### Lark

```yaml
alert:
  lark:
    enable: true
    webhookUrl: "your-lark-webhook-url"
    otherWebhookUrls:
      dev: "dev-team-webhook-url"
      prod: "prod-team-webhook-url"
```

### Viber

Viber supports two types of API integrations:

- **Channel API** (default): Send messages to Viber channels for team notifications  
- **Bot API**: Send messages to individual users for personal notifications

**Recommended Configuration (Channel API):**
```yaml
alert:
  viber:
    enable: true
    botToken: "your-viber-channel-token"  # Token for channel or bot
    apiType: "channel"  # Default: "channel" (or "bot" for individual messaging)
    channelId: "your-viber-channel-id"  # Required for Channel API
    templatePath: "/app/config/viber_message.tmpl"
```

**Alternative Configuration (Bot API):**
```yaml
alert:
  viber:
    enable: true
    botToken: "your-viber-bot-token"
    apiType: "bot"  # For individual user notifications
    userId: "your-viber-user-id"  # Required for Bot API
    templatePath: "/app/config/viber_message.tmpl"
```

**When to use each API type:**

- **Channel API** ✅ Better for incident management, team notifications, easier setup
- **Bot API** ⚠️ Limited to individual users, requires user interaction first

## On-Call Configurations

### AWS Incident Manager

```yaml
oncall:
  enable: true
  waitMinutes: 3
  provider: "aws_incident_manager"
  
  awsIncidentManager:
    responsePlanArn: "arn:aws:ssm-incidents::111122223333:response-plan/YourPlan"
    otherResponsePlanArns:
      prod: "arn:aws:ssm-incidents::111122223333:response-plan/ProdPlan"
      dev: "arn:aws:ssm-incidents::111122223333:response-plan/DevPlan"

redis:
  enabled: true
  auth:
    enabled: true
    password: "your-redis-password"
  architecture: standalone
  master:
    persistence:
      enabled: true
      size: 8Gi
```

### PagerDuty

```yaml
oncall:
  enable: true
  waitMinutes: 5
  provider: "pagerduty"
  
  pagerduty:
    routingKey: "your-pagerduty-routing-key"
    otherRoutingKeys:
      infra: "infrastructure-team-routing-key"
      app: "application-team-routing-key"
      db: "database-team-routing-key"

redis:
  enabled: true
  auth:
    enabled: true
    password: "your-redis-password"
  architecture: standalone
  master:
    persistence:
      enabled: true
      size: 8Gi
```

## Redis Configuration

Redis is **only required when on-call is enabled** (`oncall.enable=true` or `oncall.initializedOnly=true`). When on-call is disabled, the Redis settings are ignored.

The chart supports exactly two modes — pick one:

### Mode 1 — Bundled Redis (recommended for getting started)

The chart deploys a Bitnami Redis subchart and the application connects to it automatically at `<release-name>-redis-master:6379`.

```yaml
oncall:
  enable: true

redis:
  enabled: true
  auth:
    enabled: true
    password: "your-redis-password"
  architecture: standalone
  master:
    persistence:
      enabled: true
      size: 8Gi

# externalRedis.* is IGNORED in this mode — leave it untouched.
```

### Mode 2 — External Redis (production / shared Redis)

Disable the bundled Redis and point the chart at an existing Redis instance.

```yaml
oncall:
  enable: true

redis:
  enabled: false              # do NOT deploy bundled Redis

externalRedis:
  host: "redis.my-namespace.svc.cluster.local"  # required
  port: 6379
  password: "your-redis-password"
  db: 0
  insecureSkipVerify: false
  # Connection tuning. Defaults are deliberately generous so transient
  # DNS / network slowness in Kubernetes does not surface as
  # "context deadline exceeded". Tune downward if you want faster failure.
  connectionTimeout: 30
  readTimeout: 30
  writeTimeout: 30
  maxRetries: 3
  minRetryBackoff: 8
  maxRetryBackoff: 512
```

### Common pitfall — "Redis connection failed: context deadline exceeded"

Setting `externalRedis.host` while leaving `redis.enabled: true` (the default in some older examples) causes the application to talk to the bundled Redis and silently ignore your `externalRedis.*` values. Since chart `1.3.8` the chart fails fast with a clear error if both are set at the same time. If you hit this on an older chart version:

1. Decide which mode you want.
2. For Mode 2: set `redis.enabled: false` AND set `externalRedis.host`.
3. Verify connectivity from the pod: `kubectl exec -it <pod> -- nc -vz <externalRedis.host> 6379`.
4. If you see timeouts, raise `externalRedis.connectionTimeout` / `readTimeout` / `writeTimeout` (now defaulted to 30s).


## Custom Alert Templates

You can provide custom templates for each notification channel:

```yaml
templates:
  slack: |
    *Critical Error in {{.ServiceName}}*
    ----------
    Error Details:
    ```
    {{.Logs}}
    ```
    ----------
    Owner <@{{.UserID}}> please investigate

  telegram: |
    🚨 <b>Critical Error Detected!</b> 🚨
    📌 <b>Service:</b> {{.ServiceName}}
    ⚠️ <b>Error Details:</b>
    {{.Logs}}
```

## AWS Integrations

Versus Incident can receive alerts from aws sns systems:

### AWS SNS

```yaml
alert:
  sns:
    enable: true
    httpsEndpointSubscriptionPath: "/sns"
```

## Ingress Configuration

The Helm chart supports configuring an Ingress resource for external access:

```yaml
ingress:
  enabled: true
  className: "nginx"  # Specify your ingress controller class
  annotations:
    kubernetes.io/ingress.class: nginx
    kubernetes.io/tls-acme: "true"
    # Add any other annotations needed
  hosts:
    - host: versus-incident.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: versus-incident-tls
      hosts:
        - versus-incident.example.com
```

When enabling Ingress, make sure to also set the `config.publicHost` value to match your host for proper acknowledgement URL creation:

```yaml
config:
  publicHost: "https://versus-incident.example.com"
```

## Scaling and Replicas

This chart does NOT ship a HorizontalPodAutoscaler. The AI SRE Agent worker is
a single writer to the pattern catalog and detect log, so the agent must run
with `replicaCount: 1` — horizontal scaling would produce racing writes (the
chart fails fast if `agent.enable=true` with more than one replica). For
deployments that do not enable the agent you may raise `replicaCount`, but the
number of pods is fixed by that value and is not autoscaled.

```yaml
replicaCount: 1   # required when agent.enable=true
```

## Uninstalling the Chart

To uninstall/delete the `versus-incident` deployment:

```bash
helm uninstall versus-incident
```

## Additional Resources

- [Versus Incident Documentation](https://github.com/versuscontrol/versus-incident)
- [Template Syntax Guide](https://docs.versusincident.com/#/webhook/template-syntax)
- [Configuration Reference](https://docs.versusincident.com/#/configuration/configuration)