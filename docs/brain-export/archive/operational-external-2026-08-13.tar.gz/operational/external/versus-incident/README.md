# versus-incident — external mirror (Abelard / CHROMA-1)

**Upstream:** [VersusControl/versus-incident](https://github.com/VersusControl/versus-incident)  
**Pinned commit:** `UPSTREAM_SHA` in this folder  
**License:** MIT (`LICENSE`)  
**Stack:** Go — self-hosted AI SRE agent (baseline learning, anomaly escalation, chat/on-call routing)

**Sibling corpus (read first):** [devops-ai-guidelines](../devops-ai-guidelines/) — agentic DevOps theory/build path.  
**This pack sits underneath** — product-shaped incident/SRE thinking, not separate policy theater.

## What this is

Versus Incident learns what the system normally looks like and escalates **only what is new or unexpected** — to Slack/Telegram/PagerDuty-style channels. Operator-shared reference for Abelard when reasoning on **real problems we are solving** (signal, escalation, correlation), not on issue-delivery bureaucracy.

**Abelard awareness:** [agents/abelard/VERSUS-INCIDENT-AWARENESS.md](../../../agents/abelard/VERSUS-INCIDENT-AWARENESS.md)

## CHROMA-1 ingest

| Method | When |
|--------|------|
| **Delta (this pack)** | `bash cluster/chroma-server/ingest-versus-incident-delta.sh` on alunel after pull |
| **Whole-repo** | `ingest-whole-repo.sh` includes `operational/` |

## Refresh

```bash
bash scripts/vendor-versus-incident.sh
```

## Do not

- Deploy Versus Incident into prod verbatim — adapt patterns to Prometheus, malus, workflow, tersagor notify.
- Treat upstream Helm/AWS/chat integrations as cluster canon without Abelard review.
