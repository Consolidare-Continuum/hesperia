# devops-ai-guidelines — external mirror (Abelard / CHROMA-1)

**Upstream:** [VersusControl/devops-ai-guidelines](https://github.com/VersusControl/devops-ai-guidelines)  
**Pinned commit:** see `UPSTREAM_SHA` in this folder  
**License:** MIT (`LICENSE`)  
**Vendored slice:** `03-ai-agent-for-devops/` only (16-chapter series + `code/` + `images/`)

## What this is

Third-party **Practical DevOps AI** learning path (~24k lines, unrefined corpus): building an AI logging agent from scratch (LangChain, memory, multi-source logs, production deployment). **CHROMA-1:** ingested as-is for search; **Abelard:** adaptations only — no verbatim execution of upstream steps.

**Abelard awareness:** [agents/abelard/DEVOPS-AI-GUIDELINES-AWARENESS.md](../../../agents/abelard/DEVOPS-AI-GUIDELINES-AWARENESS.md)

## CHROMA-1 ingest

| Method | When |
|--------|------|
| **Whole-repo** | `bash cluster/chroma-server/ingest-whole-repo.sh` on alunel — `operational/` is in the path list; chunks land as `layer=operational`. |
| **Delta (this pack only)** | `bash cluster/chroma-server/ingest-devops-ai-guidelines-delta.sh` on alunel after pull. |

Verify after ingest: `query_knowledge` — e.g. "AI agent DevOps logging LangChain memory guardrails".

## Refresh from upstream

```bash
# From repo root; updates vendored tree + UPSTREAM_SHA
bash scripts/vendor-devops-ai-guidelines.sh
```

## Do not

- Treat upstream AWS/LangChain/Gemini examples as cluster runbooks without Abelard adaptation.
- Commit upstream `.git` — vendored files only.
