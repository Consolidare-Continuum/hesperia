# Ethan gate — Tersagor SDK v0.5.0-m5 deploy ratified

**Date:** 2026-06-21  
**Gate owner:** Ethan (architecture / release ratification)  
**VM:** tersagor.prichindel.local  
**Tag:** `tersagor-sdk-v0.5.0-m5`  
**Rev:** `1fe272ee00f5609d41ac59a9dc9665ae8c89546e`

---

## Gate decision

**RATIFIED — deploy accepted.** All M5 trust gates green on prod VM after `deploy/deploy-on-vm.sh`. v0.5.0-m5 is the current shipped checkpoint on tersagor.

---

## Gate evidence (2026-06-21T19:23:23+00:00)

| Gate | Script / check | Result |
|------|----------------|--------|
| M4 ship | `smoke_m4_ship_gate.py` | **10/10 GREEN** |
| IRC mesh glue | `smoke_irc_mesh_glue.py` | **2/2 GREEN** |
| SDK prod readiness | `smoke_sdk_prod_ready.py` | **4/4 READY** |
| Deploy exit | `deploy-on-vm.sh` | **0** |
| Rollback pointer | deploy log | `rev=1fe272ee00f5` |

**Services live after deploy:**

- `imirc-mesh-executor.service` (user) — mesh `:18094`, backend=openai, orchestrator=true
- `tersagor-approval-gateway.service` — `:18090` health OK
- Forwarder + MCP host processes restarted by deploy

**Known non-blocker:** SDK warns on handoff name `transfer_to_Status agent` → sanitized to `transfer_to_status_agent`. Cosmetic; smokes pass.

---

## Explicit out-of-scope (v0.6.0-m6 blocker)

| Item | Status |
|------|--------|
| Hosted brain MCP (`mcp.prichindel.local` from tersagor) | **OFF** — `TERSAGOR_HOSTED_MCP_ENABLED=0` |
| Full hosted-MCP GA claim | **Not ratified** until M6 Abelard wire + smoke |

Ref: [TERMS-ROUTING-AGENT-VS-GRACE-TRIAGE.md](../../governance/TERMS-ROUTING-AGENT-VS-GRACE-TRIAGE.md) — routing agent ≠ Grace triage.

---

## Next

- **v0.6.0-m6:** Abelard — hosted brain MCP reachability + enable flag + smoke
- Operator live probes: `!ping`, `!agent triage …` on IRC mesh (optional sanity)

---

SIGNED: Chief Architect (Ethan) | gate ratification | 2026-06-21 | tersagor-sdk v0.5.0-m5
