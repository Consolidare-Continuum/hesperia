# Felix — HWIKI-STRUCT-05 code-anchor verify (v0.7.0)

**Date:** 2026-07-26  
**Owner:** Felix (CSP from Cursor autonomous proceed)  
**Hubs:** `structure/SYSTEM-STRUCTURE-0.7.0.md` · `structure/HOW-IT-WORKS-0.7.0.md`  
**Trees:** dev `/data/workspaces/atomic-commit-hesperia` · prod `/data/hesperia/hesperia`

## Verdict

**PASS** — all cited paths/routes/VERSION fields present on both trees.

## Checklist

### Tree `/data/workspaces/atomic-commit-hesperia` (0.7.0 / 0fcbe899360354c74260ff605787ad2c91bfe355)
- OK path VERSION.yaml
- OK path runtime/shipping/api_main.py
- OK path runtime/services/analysis_service.py
- OK path hesperia/engine/sealed_multiscale_stack.py
- OK path runtime/services/product_interpret_service.py
- OK path sphere/router/ground_truth.py
- OK path sphere/router/tool_inquiry.py
- OK path runtime/pipeline/analyze.py
- OK path core/propagation/guard_pipeline.py
- OK path sphere/pipeline/pipeline_runner.py
- OK path core/layers/layer_3.py
- OK path hesperia/modules
- OK path hesperia/engine
- OK pkg dict_a present
- OK pkg dict_b present
- OK route runtime/shipping/api_main.py :: POST /analyze
- OK route runtime/shipping/api_main.py :: @app.post("/analyze")
- OK route runtime/shipping/api_main.py :: @app.post("/product/interpret")
- OK sym sphere/router/ground_truth.py :: logical
- OK sym sphere/router/ground_truth.py :: weight
- OK sym sphere/router/ground_truth.py :: source_activation
- OK sym sphere/router/ground_truth.py :: derive_ground_truth_blocks
- OK sym hesperia/engine/sealed_multiscale_stack.py :: product signals
- OK sym VERSION.yaml :: system_version: "0.7.0"
- OK sym VERSION.yaml :: release_stage: "modular_branches"
- OK sym VERSION.yaml :: core_engine: "0.7.0"
- OK sym VERSION.yaml :: router: "v7-router-0.1"
- OK sym VERSION.yaml :: fpf_bridge: "v7.2-v7.4"
- OK apply/allowlist refs present in VERSION or docs
- OK COBALT refs present
- OK REAL_DATA refs present

### Tree `/data/hesperia/hesperia` (v0.7.0 / 0fcbe899360354c74260ff605787ad2c91bfe355)
- OK path VERSION.yaml
- OK path runtime/shipping/api_main.py
- OK path runtime/services/analysis_service.py
- OK path hesperia/engine/sealed_multiscale_stack.py
- OK path runtime/services/product_interpret_service.py
- OK path sphere/router/ground_truth.py
- OK path sphere/router/tool_inquiry.py
- OK path runtime/pipeline/analyze.py
- OK path core/propagation/guard_pipeline.py
- OK path sphere/pipeline/pipeline_runner.py
- OK path core/layers/layer_3.py
- OK path hesperia/modules
- OK path hesperia/engine
- OK pkg dict_a present
- OK pkg dict_b present
- OK route runtime/shipping/api_main.py :: POST /analyze
- OK route runtime/shipping/api_main.py :: @app.post("/analyze")
- OK route runtime/shipping/api_main.py :: @app.post("/product/interpret")
- OK sym sphere/router/ground_truth.py :: logical
- OK sym sphere/router/ground_truth.py :: weight
- OK sym sphere/router/ground_truth.py :: source_activation
- OK sym sphere/router/ground_truth.py :: derive_ground_truth_blocks
- OK sym hesperia/engine/sealed_multiscale_stack.py :: product signals
- OK sym VERSION.yaml :: system_version: "0.7.0"
- OK sym VERSION.yaml :: release_stage: "modular_branches"
- OK sym VERSION.yaml :: core_engine: "0.7.0"
- OK sym VERSION.yaml :: router: "v7-router-0.1"
- OK sym VERSION.yaml :: fpf_bridge: "v7.2-v7.4"
- OK apply/allowlist refs present in VERSION or docs
- OK COBALT refs present
- OK REAL_DATA refs present


## Notes for Colombo (hub hygiene)

- `POST /analyze` / `POST /product/interpret` verified as FastAPI decorators on `runtime/shipping/api_main.py`.
- `ground_truth` three-block API `derive_ground_truth_blocks` present.
- Class A `dict_a`/`dict_b` packages present (directory search).
- Apply / COBALT / REAL_DATA: references exist; seal still gates (not flipped) — consistent with hub prose.

SIGNED: Developer (Felix) | HWIKI-STRUCT-05 code-anchor verify | 2026-07-26 | v0.7.0
