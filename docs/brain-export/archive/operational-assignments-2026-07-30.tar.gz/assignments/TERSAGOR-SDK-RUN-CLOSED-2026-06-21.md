# Tersagor SDK + hosted brain MCP — run closed

**Date:** 2026-06-21  
**Entity:** Cursor (wrap) · Abelard (M6 wire) · Ethan gate v0.5.0-m5 prior  
**Product repo:** `igareosh/tersagor` @ **`1fe272e`** (VM `.deploy-rev`; hosted-MCP code on disk, tag v0.6.0-m6 pending push)  
**Status:** **RUN CLOSED** — app-repo solution tasks for this wave **DONE**

---

## Delivered (this run)

| Layer | Result |
|-------|--------|
| **v0.5.0-m5** | Shipped — M4 10/10, IRC mesh 2/2, SDK prod 4/4 (hosted MCP off) · Ethan gate **RATIFIED** |
| **v0.6.0-m6 hosted brain MCP** | **LIVE** — `https://mcp.prichindel.com/mcp` via vaporas → prichindel `brain-mcp-http` |
| **OpenAI HostedMCPTool** | Green — raw bearer token in `authorization`; routing agent + mesh triage **OK** |
| **TSDK-001..080** | **DONE** on active.md (M1–M5 mesh confidence wave) |
| **TSDK-042** | HostedMCPTool → prichindel read-only MCP — **implemented and prod-enabled** |

---

## Infra (Abelard)

- prichindel: `brain-mcp-http.service` (:18120), nginx vhost, DNS LE cert
- vaporas: `mcp.prichindel.com` gate block + dedicated TLS cert (sync from prichindel)
- Cloudflare: A `mcp.prichindel.com` → `89.167.53.193`
- tersagor prod: `TERSAGOR_HOSTED_MCP_ENABLED=1`, bearer synced from prichindel

**Ops:** after cert renew → `bash scripts/sync-brain-mcp-cert-to-vaporas.sh`

---

## Smokes (final)

```
SDK prod: routing_agent_live status=ok · mesh_triage_path status=executed · ALL 4 GREEN
HostedMCPTool: list_runbooks via OpenAI — OK
```

---

## Honest gaps (not blocking close)

- Brain + tersagor git commits/push pending (disk-only deploy used for speed)
- vaporas `libnginx-mod-stream` apt failed (mirror); stream block commented — reload OK
- Tag **`tersagor-sdk-v0.6.0-m6`** not cut yet
- SuiteCRM sync for `SUITE: YES` rows — batch not re-run this session

---

## Next (operator / Grace only)

New work → **Grace triage** (no new active.md rows from this closure). Optional: tag v0.6.0-m6, push both repos, Ethan gate doc for M6 if product compliance wants a formal ratification.

---

SIGNED: Cursor | repo wrap / run closed | 2026-06-21 | tersagor-sdk + hosted MCP M6
