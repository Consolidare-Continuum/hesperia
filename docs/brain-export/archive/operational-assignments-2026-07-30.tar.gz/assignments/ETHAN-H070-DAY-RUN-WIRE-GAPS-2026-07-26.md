# Ethan — Hesperia day run: gather the ball · close wire gaps · structure

> **For agents:** Execute via Grace triage in **waves** (do not dump all OPEN on `active.md` at once). Prefer `workflow_automation_run` / Cursor proceed per wave. Stay on **`v0.7.0`**.

**Date:** 2026-07-26 (today plan)  
**Owner:** Ethan (plan) · Grace (triage batches) · Felix/Gena/Colombo/Abelard/Ava/Cursor (execute)  
**Goal:** Use existing ISO baseline + wiki structure hubs + grind inventory to **find and close wiring gaps**, making the sealed multipurpose engine **more structured** — not a new version, not new domain identity.

**Architecture:** Docs/wiki already describe the frame. This run **maps claim → code/CI/test path**, fixes **missing links / drift / soft wires**, and packages **ISO-grade evidence**. Class A plumbing may tighten; Class B stays gated; identity = multipurpose ([ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md](../../governance/ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md)).

**Tech stack:** prod `/data/hesperia/hesperia` @ `v0.7.0` · `0fcbe899` · dev `/data/workspaces/atomic-commit-hesperia` · brain pointers · CHROMA `hesperia_wiki` · sealed-runtime-gate CI

## Global constraints

- **No** `system_version` / tag bump; no “0.8” campaign.
- **No** clinical/medicine framing; TFP = one field module only.
- **No** Class B into sealed `/analyze`; COBALT/REAL_DATA stay gated unless Grace+operator gate.
- **Atomic commits** `hesperia(iso|grind|wire): …` with Why / What / Evidence.
- **Remotes:** only three Hesperia remotes (Ethan remotes policy).
- **Brain** = pointers + governance; product code in `igareosh/hesperia` → Atomic promote when ready.
- **ISO** = alignment evidence, **not** certification claims.

## Sources of truth for this run

| Source | Use |
|--------|-----|
| [HESPERIA-POST-070-PHASE-FRAME.md](../../governance/HESPERIA-POST-070-PHASE-FRAME.md) | Phase law |
| [ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md](../../governance/ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md) | Identity |
| [HESPERIA-ISO-PRODUCTIZATION-BASELINE.md](../../governance/HESPERIA-ISO-PRODUCTIZATION-BASELINE.md) | Evidence package |
| Wiki `structure/*` | How/where/why claims |
| [FELIX-H070-GRIND-01-…](FELIX-H070-GRIND-01-RUNTIME-INVENTORY-2026-07-26.md) | Runtime grind candidates |
| Modular architecture mandatory read | Class A/B rules |

## How to run today (ops)

| Step | Who | Action |
|------|-----|--------|
| 1 | Grace | Triage **Wave 0** (8 rows) → `active.md` |
| 2 | Cursor | `workflow_run` / proceed — drain Wave 0 |
| 3 | Grace | Open **Wave 1** when Wave 0 ≥80% DONE |
| 4 | … | Repeat Waves 2–8 (cap **8–12 OPEN** Hesperia rows) |
| 5 | Ethan/Cursor | End-of-day: gap ledger update + carry unfinished to tomorrow |

**Budget:** ~80 tasks · ~1 day of parallel agents (Felix+Gena primary code; Colombo docs/wiki; Abelard remotes/deploy; Ava tests; Cursor wire/ISO).

**ID prefix:** `H070-WIRE-NNN` (NNN = 001…080)

---

## Wave map (summary)

| Wave | Theme | Tasks | Primary owners |
|------|-------|-------|----------------|
| **0** | Kickoff · SOT · gap ledger | 001–008 | Ethan, Grace, Cursor, Abelard |
| **1** | Claim→path matrix (wiki/ISO → code) | 009–018 | Colombo, Felix, Cursor |
| **2** | Interpret + shipping wire | 019–030 | Felix, Gena |
| **3** | Allowlist · sealed gate · API snapshot | 031–040 | Felix, Ava |
| **4** | Module registry · Class A/B structure | 041–050 | Felix, Colombo, Ethan |
| **5** | Determinism · soak · e2e hygiene | 051–062 | Felix, Ava, Gena |
| **6** | ISO evidence packaging | 063–070 | Cursor, Ethan, Abelard |
| **7** | Cross-link · agent awareness structure | 071–076 | Colombo, Cursor |
| **8** | Day closeout · verify · carry | 077–080 | Ethan, Grace, Cursor |

**Count:** **80** tasks (within 50–100).

---

## Wave 0 — Kickoff · SOT · gap ledger (001–008)

- [ ] **H070-WIRE-001** Ethan: Ratify this day-run plan as active grind program (pointer from phase frame).  
  - Files: this doc · `HESPERIA-POST-070-PHASE-FRAME.md` § grind backlog  
  - DoD: status ACTIVE; Grace may triage waves  
- [ ] **H070-WIRE-002** Grace: Create gap ledger stub `operational/assignments/HESPERIA-WIRE-GAP-LEDGER-2026-07-26.md` (columns: claim, path, status OPEN/PARTIAL/CLOSED, owner).  
- [ ] **H070-WIRE-003** Abelard: Verify remotes on prod + dev (`scripts/hesperia/verify-hesperia-git-remotes.sh`); record evidence in ledger.  
- [ ] **H070-WIRE-004** Cursor: Print execution context; confirm `v0.7.0` @ `0fcbe899` on prod and matching tip on dev.  
- [ ] **H070-WIRE-005** Cursor: Snapshot sealed-runtime-gate job list into ledger (from `.github/workflows/sealed-runtime-gate.yml`).  
- [ ] **H070-WIRE-006** Colombo: Confirm identity stamp cited from CLIENTS + structure README (no clinical drift).  
- [ ] **H070-WIRE-007** Grace: Triage Wave 1 rows only after 001–006 DONE or PAUSED-with-reason.  
- [ ] **H070-WIRE-008** Ethan: Define “structured enough for today” exit bar (see § Exit).  

---

## Wave 1 — Claim→path matrix (009–018)

Map each structure-hub claim to a concrete path; mark gaps.

- [ ] **H070-WIRE-009** Colombo: Matrix row — SYSTEM-STRUCTURE layers ↔ `runtime/shipping/api_main.py` + `analysis_service`.  
- [ ] **H070-WIRE-010** Felix: Matrix row — HOW-IT-WORKS `/analyze` ↔ `sealed_multiscale_stack` entry.  
- [ ] **H070-WIRE-011** Felix: Matrix row — HOW-IT-WORKS `/product/interpret` ↔ `product_interpret_service.py`.  
- [ ] **H070-WIRE-012** Felix: Matrix row — ground_truth fields ↔ response schema / snapshot.  
- [ ] **H070-WIRE-013** Felix: Matrix row — HAND inquire/dig ↔ actual HAND/router entrypoints (or mark docs-only).  
- [ ] **H070-WIRE-014** Felix: Matrix row — APPLY allowlist ↔ apply code + `tests/h070/*`.  
- [ ] **H070-WIRE-015** Felix: Matrix row — COBALT/REAL_DATA gates ↔ `public_capability` / flags (document defaults).  
- [ ] **H070-WIRE-016** Colombo: Matrix row — ISO baseline §5 release package ↔ existing release-notice templates (gap list).  
- [ ] **H070-WIRE-017** Cursor: Fold Wave 1 matrix into gap ledger; prioritize TOP-15 wires.  
- [ ] **H070-WIRE-018** Ethan: Approve TOP-15 as Wave 2–5 binding scope (no safari).  

---

## Wave 2 — Interpret + shipping wire (019–030)

- [ ] **H070-WIRE-019** Felix: Document interpret capability default ON/OFF in shipping README or brain pointer.  
- [ ] **H070-WIRE-020** Felix: Ensure interpret errors surface consistent HTTP/shape (no silent empty).  
- [ ] **H070-WIRE-021** Felix: Wire gap — mode / overlay_hint / gap_report documented ↔ `interpretation_policy` tests.  
- [ ] **H070-WIRE-022** Gena: OpenAPI / schema comment alignment for `/product/interpret` (dev repo).  
- [ ] **H070-WIRE-023** Felix: Determinism guard — `HESPERIA_STRICT_DETERMINISM=1` path documented in grind note.  
- [ ] **H070-WIRE-024** Ava: Extend or confirm `test_run_product_interpret_deterministic` covers golden keys.  
- [ ] **H070-WIRE-025** Felix: Trace `engine_trace` consumption path into interpret (wiki claim vs code).  
- [ ] **H070-WIRE-026** Felix: Close or ticket any dead import under `runtime/services/` used by interpret.  
- [ ] **H070-WIRE-027** Gena: Shipping API route table (analyze/compare/batch/interpret/health) ↔ wiki SYSTEM-STRUCTURE.  
- [ ] **H070-WIRE-028** Felix: Flag matrix fixture file for interpret modes (test-only; no physics).  
- [ ] **H070-WIRE-029** Cursor: Update gap ledger for Wave 2 CLOSED/PARTIAL.  
- [ ] **H070-WIRE-030** Ethan: Hold-the-line check — no Class B folded during Wave 2.  

---

## Wave 3 — Allowlist · sealed gate · API snapshot (031–040)

- [ ] **H070-WIRE-031** Felix: Run `validate_shipping_surface.py` + `audit_shipping_allowlist.py` on prod tip; record.  
- [ ] **H070-WIRE-032** Felix: Drop or justify unused allowlist prefixes (creep cap).  
- [ ] **H070-WIRE-033** Ava: Confirm H070 apply gold tests green locally.  
- [ ] **H070-WIRE-034** Felix: Run `verify_public_api_snapshot.py` — treat drift as defect ticket.  
- [ ] **H070-WIRE-035** Felix: Run `validate_version_consistency.py` — must stay 0.7.0.  
- [ ] **H070-WIRE-036** Felix: Run `check_import_boundary.py` + `sealing_scan.py` — fix only if clear wire gap.  
- [ ] **H070-WIRE-037** Felix: Run `check_forbidden_zone_imports.py` — ledger any creep.  
- [ ] **H070-WIRE-038** Abelard: Confirm CI workflow still runs on main push (sealed-runtime-gate).  
- [ ] **H070-WIRE-039** Cursor: Map each gate step → ISO evidence row in ledger.  
- [ ] **H070-WIRE-040** Ethan: Approve any allowlist change as grind (not growth).  

---

## Wave 4 — Module registry · Class A/B structure (041–050)

- [ ] **H070-WIRE-041** Colombo: Write one-page “module map @ 0.7.0” (registry names ↔ Class A/B).  
- [ ] **H070-WIRE-042** Felix: Inventory `hesperia/modules/registry.py` + `tfp` / `nlp` — document enable paths.  
- [ ] **H070-WIRE-043** Felix: Mark what is **cored** vs **branch-persistent** in tree (evidence paths).  
- [ ] **H070-WIRE-044** Ethan: Ratify: no TFP behaviour into sealed analyze this run.  
- [ ] **H070-WIRE-045** Felix: Pipeline YAML / aliases — list optional modules and defaults.  
- [ ] **H070-WIRE-046** Colombo: Wiki hub addendum — “modules ≠ identity” pointer (short).  
- [ ] **H070-WIRE-047** Felix: Gap — module declared but unreachable from shipping (ticket or wire).  
- [ ] **H070-WIRE-048** Gena: Ensure module public contracts don’t leak into sealed schema unless intended.  
- [ ] **H070-WIRE-049** Cursor: Ledger update Wave 4.  
- [ ] **H070-WIRE-050** Ethan: Structure checkpoint — “can a new agent name Class A vs B correctly from docs alone?”  

---

## Wave 5 — Determinism · soak · e2e hygiene (051–062)

- [ ] **H070-WIRE-051** Felix: Define soak recipe (N requests, warm, p50/p95) for `/analyze` + `/product/interpret`.  
- [ ] **H070-WIRE-052** Ava: Run soak once on altitudine/prod-safe target; store numbers in assignment.  
- [ ] **H070-WIRE-053** Felix: Triage `tests/test_e2e_flows.py` — flaky vs deterministic.  
- [ ] **H070-WIRE-054** Felix: Triage `tests/test_e2e_full_stack.py`.  
- [ ] **H070-WIRE-055** Felix: Triage `tests/domain/test_e2e_pipeline.py`.  
- [ ] **H070-WIRE-056** Ava: Archive/gold e2e — keep, pin, or drop under 0.7.0.  
- [ ] **H070-WIRE-057** Felix: Optional pytest markers `slow`/`soak` **only if** needed (document).  
- [ ] **H070-WIRE-058** Gena: Benchmark harness — confirm `tools/product_benchmark_eval.py` still meaningful.  
- [ ] **H070-WIRE-059** Felix: Quarantine or fix one highest-pain flake (single concern commit).  
- [ ] **H070-WIRE-060** Ava: Re-run sealed-relevant pytest subset after fixes.  
- [ ] **H070-WIRE-061** Cursor: Ledger Wave 5.  
- [ ] **H070-WIRE-062** Ethan: Robustness bar — interpret deterministic test + gate tools green.  

---

## Wave 6 — ISO evidence packaging (063–070)

- [ ] **H070-WIRE-063** Cursor: Fill ISO control-matrix stub for today’s grind (baseline §3 × evidence links).  
- [ ] **H070-WIRE-064** Ethan: Standardize release-notice fields for ISO refs (template in brain or point to existing).  
- [ ] **H070-WIRE-065** Abelard: Remote integrity evidence attached to matrix.  
- [ ] **H070-WIRE-066** Cursor: Acceptance/DoD pointers for closed TOP wires.  
- [ ] **H070-WIRE-067** Daniel/Cursor: Security relevance check (shipping surface only) — N/A or note.  
- [ ] **H070-WIRE-068** Cursor: Corrective-action list (open gaps → tomorrow IDs).  
- [ ] **H070-WIRE-069** Abelard: No stealth prod promote without evidence package.  
- [ ] **H070-WIRE-070** Ethan: ISO day stamp — alignment package COMPLETE or PARTIAL with reason.  

---

## Wave 7 — Cross-link · agent awareness structure (071–076)

- [ ] **H070-WIRE-071** Colombo: Structure README — link gap ledger + day plan.  
- [ ] **H070-WIRE-072** Cursor: CLIENTS/hesperia — pointer to day plan + ledger.  
- [ ] **H070-WIRE-073** Colombo: Speech spine — one line “wire gaps program = structure, not new domain.”  
- [ ] **H070-WIRE-074** Cursor: Re-ingest `hesperia_wiki` after hub edits.  
- [ ] **H070-WIRE-075** Colombo: Purge remaining “clinical identity” phrasing in structure hubs if any.  
- [ ] **H070-WIRE-076** Cursor: Agent-facing one-pager `operational/assignments/HESPERIA-WIRE-TODAY-CHEATSHEET-2026-07-26.md` (owners + wave order).  

---

## Wave 8 — Day closeout (077–080)

- [ ] **H070-WIRE-077** Grace: Count DONE vs OPEN; no silent abandoned rows.  
- [ ] **H070-WIRE-078** Ethan: Publish day outcome (CLOSED wires / PARTIAL / CARRY).  
- [ ] **H070-WIRE-079** Cursor: Commit/push brain artifacts; product PRs only if code wires landed.  
- [ ] **H070-WIRE-080** Ethan: Tomorrow seed — next 12 wires from ledger TOP remaining.  

---

## Exit bar (today success)

**Done enough** if all of:

1. Gap ledger exists with ≥15 claim→path rows and TOP-15 ranked.  
2. Sealed gate tool suite run recorded (pass or ticketed fails).  
3. Interpret determinism path documented + test green (or explicit BLOCKED).  
4. Allowlist audit recorded; creep addressed or ticketed.  
5. Module Class A/B map one-pager exists.  
6. ISO control-matrix stub filled for the day (alignment, not cert).  
7. Identity: no clinical product framing reintroduced.  
8. Unfinished wires carried with IDs — not lost in chat.

**Not required today:** full e2e green suite; COBALT on; version bump; conference CFP; L* wiki expansion.

---

## Owner load (approximate)

| Owner | Task share | Focus |
|-------|------------|-------|
| Felix | ~28 | Runtime wire, gate tools, e2e triage |
| Colombo | ~12 | Matrix, module map, wiki/awareness |
| Cursor | ~16 | Ledger, ISO package, ingest, proceed |
| Ava | ~8 | Tests / soak / gold |
| Gena | ~6 | Schema / API table / contracts |
| Abelard | ~5 | Remotes / CI / promote discipline |
| Ethan | ~8 | Ratify, hold line, exit |
| Grace | ~5 | Wave triage / counts |
| Daniel | ~1 | Security note if needed |

---

## Grace triage protocol

1. Open **Wave 0** as 8 `active.md` rows (`H070-WIRE-001`…`008`), `SUITE: YES`.  
2. On Wave complete → open next wave (8–12 rows).  
3. Do **not** open all 80 at once.  
4. Link each row to this plan + gap ledger.  

**Grace packet:** [GRACE-TRIAGE-HESPERIA-WIRE-DAY-2026-07-26.md](GRACE-TRIAGE-HESPERIA-WIRE-DAY-2026-07-26.md)

SIGNED: Team lead (Ethan) | H070 wire-gap day plan | 2026-07-26 | 80 tasks · waves 0–8 · stay v0.7.0
