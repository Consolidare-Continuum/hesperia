# Grace — FPF done audit + map-wide wrap triage

**Date:** 2026-07-19  
**Operator:** check dones · triage wrap with Felix remainders · finalize FPF map-wide integration · budget ≤30  
**Wave id:** **FPF-MWI** (Map-Wide Integration)

---

## 1. Done audit (verified)

| ID | Owner | Status | Evidence |
|----|-------|--------|----------|
| FPF-HSR-01..07,09,10 | Ethan (+design) | **DONE** | Architecture packet |
| FPF-HSR-11 | Felix | **DONE** | hesperia `f877232` |
| FPF-HSR-12 | Felix | **DONE (server)** | brain `b8daba3e` + hesperia `fa24630` — **mcp-config still open** |
| FPF-HSR-13 | Felix | **DONE** | hesperia `58377cc` |
| FPF-BUII-00 | Grace | **DONE** | triage |
| FPF-BUII-01..05 | Gena | **DONE** | hesperia `3b2653b` + brain `hesperia-fpf-inspect` |
| FPF-BUII-07 | Ethan | **DONE** | BUII-G1..G3 seal language |

## 2. Carry-forward OPEN (do **not** re-create)

| ID | Owner | Why still open |
|----|-------|----------------|
| **FPF-HSR-08** | Sophia + Daniel | Security before external flags |
| **FPF-HSR-14** | Felix | hex_rotation Option B |
| **FPF-HSR-15** | Colombo | Mapping sign-off |
| **FPF-HSR-16** | Grace | HSR wave close G1–G9 |
| **FPF-BUII-06** | Marcus | Dig operator runbook |

**Felix priority this wrap:** **FPF-HSR-14** + **FPF-MWI-01** (mcp-config closes HSR-12) + map-wide Felix rows below.

---

## 3. New wave — FPF-MWI-00..24 (25 rows ≤30)

**Intent:** Finalize **fpf-thinking-map map-wide** in Hesperia — product inquire + dig inspect + bridge + pins + security + deploy — without merging dig into product inquire, without unpausing HSR-V7-X seal.

**Exit (Ethan ratifies in MWI-08):**  
- **MWI-G1** — both MCPs wired in mcp-config (router + inspect) on altitudine  
- **MWI-G2** — E2E gold: same text → GapReport + inquire ground_truth  
- **MWI-G3** — hard split documented: `hesperia_inspect` dig vs `hesperia_ops` product vs upper LLM  
- **MWI-G4** — FPF-HSR-08 + inspect security (MWI-13) signed before external clinical  
- **MWI-G5** — register + Grace close (MWI-24) after carry-forward 14/15/08/BUII-06 done or deferred

| ID | P | Owner | Task | TYPE |
|----|---|-------|------|------|
| **FPF-MWI-00** | P0 | Grace | Wave meta — MWI rows live; link this packet; cross-ref HSR-12 gap + BUII + HSR-14 | triage |
| **FPF-MWI-01** | P0 | Felix | Wire `hesperia-router` into `governance/mcp-config.json` + `.mcp.json` (local script pattern like inspect); close HSR-12 deploy gap | task |
| **FPF-MWI-02** | P0 | Felix | E2E gold — same synthetic text → `fpf_inspect` GapReport + `hesperia_router_inquire` ground_truth; assert three blocks present | task |
| **FPF-MWI-03** | P1 | Felix | Optional GapReport attach on `/product/interpret` behind flag default **off** (BUII P7; no upper-LLM schema change) | task |
| **FPF-MWI-04** | P0 | Felix | `thinking_map_bridge` completeness — cover `possible_transitions` / `response_contract` gaps Colombo flags; tests | task |
| **FPF-MWI-05** | P1 | Felix | CI/pytest smoke — `test_fpf_buii_inspect` + router MCP tests green on main | task |
| **FPF-MWI-06** | P1 | Felix | Skeleton domain map **`hesperia_ops`** (product agent moves) — separate from `hesperia_inspect`; no dig semantics | task |
| **FPF-MWI-07** | P0 | Felix | **Execute carry FPF-HSR-14** Option B + gold; mark GapReport provisional tag cleared when discriminating | task |
| **FPF-MWI-08** | P0 | Ethan | Ratify MWI-G1..G5 exit criteria; pin dual-version policy (brain library soak vs Hesperia runtime pin) | spec |
| **FPF-MWI-09** | P0 | Ethan | ADR — hard split `hesperia_inspect` / `hesperia_ops` / upper LLM (hold the line) | spec |
| **FPF-MWI-10** | P1 | Gena | `fpf_inspect` **Router** layer probe — envelope mandatory blocks visible in climb | task |
| **FPF-MWI-11** | P1 | Gena | Document Hesperia pin `fpf-thinking-map==1.2.1` vs brain soak `1.5.0` — no silent upgrade; point to MWI-08 | task |
| **FPF-MWI-12** | P2 | Gena | Operator CLI sugar — `python -m sphere.fpf_inspect climb --full` defaults documented in Hesperia README slice | task |
| **FPF-MWI-13** | P0 | Sophia | Security review **hesperia-fpf-inspect** MCP (synthetic dig OK; clinical text gate) | task |
| **FPF-MWI-14** | P0 | Daniel | Co-complete **FPF-HSR-08** with Sophia — HTTP context_packet + hesperia-router; one signed memo | task |
| **FPF-MWI-15** | P1 | Colombo | Map-wide glossary EN — inquire vs dig vs bridge vs GapReport | task |
| **FPF-MWI-16** | P1 | Colombo | **Execute carry FPF-HSR-15** mapping sign-off | task |
| **FPF-MWI-17** | P1 | Ava | Gold suite map-wide integration (fingerprint + ground_truth + GapReport schema) | task |
| **FPF-MWI-18** | P1 | Ava | Determinism — two digs identical GapReport JSON | task |
| **FPF-MWI-19** | P1 | Marcus | **Execute carry FPF-BUII-06** dig runbook (hit → climb) | task |
| **FPF-MWI-20** | P1 | Liam | Deploy runbook — both MCPs (router + inspect) on altitudine; Abelard handoff notes | task |
| **FPF-MWI-21** | P1 | Abelard | Ensure `HESPERIA_REPO_ROOT` + MCP scripts reachable on MCP execution hosts | task |
| **FPF-MWI-22** | P2 | Noah | Observability — structured log fields for dig/inquire (no PII) | task |
| **FPF-MWI-23** | P2 | Emma | Operator acceptance checklist — map-wide dig + inquire | task |
| **FPF-MWI-24** | P0 | Grace | MWI wave close when MWI-G1..G5 + carry 08/14/15/BUII-06 met or deferred; sync registers; then close FPF-HSR-16 | triage |

**Deps (Felix spine):** `01 → 02 → 05`; `07` (=HSR-14) parallel; `03` after `02`; `04` before Colombo `16`; `06` after Ethan `09`.  
**Security spine:** `13` + `14`/`08` before any external clinical flag.  
**Close:** `24` last (after Ethan `08`).

**SUITE:** YES on all new rows.  
**Do not:** unpause HSR-V7-X-*; merge dig into `hesperia_router_inquire`; invent library semantics (pin soak).

**New row count:** 25 (within ≤30).  
**Carry-forward already on board:** 5 (08,14,15,16,BUII-06) — MWI-07/14/16/19 are execution pointers that may close those rows without duplicating work.

---

## 4. Assign digest

**Assign to: Felix** — **MWI-01 → 02 → 05**; parallel **MWI-07/HSR-14**, **MWI-03**, **MWI-04**, **MWI-06**.  
**Assign to: Gena** — **MWI-10 → 11 → 12**.  
**Assign to: Ethan** — **MWI-08**, **MWI-09**.  
**Assign to: Sophia** — **MWI-13** + **HSR-08**.  
**Assign to: Daniel** — **MWI-14** + **HSR-08**.  
**Assign to: Colombo** — **MWI-15**, **MWI-16/HSR-15**.  
**Assign to: Ava** — **MWI-17**, **MWI-18**.  
**Assign to: Marcus** — **MWI-19/BUII-06**.  
**Assign to: Liam** — **MWI-20**.  
**Assign to: Abelard** — **MWI-21**.  
**Assign to: Noah** — **MWI-22**.  
**Assign to: Emma** — **MWI-23**.  
**Assign to: Grace** — **MWI-24** + **HSR-16**.

---

`SIGNED: Triage (Grace) | FPF-MWI wrap ≤30 | 2026-07-19 | map-wide finalize + Felix remainders`
