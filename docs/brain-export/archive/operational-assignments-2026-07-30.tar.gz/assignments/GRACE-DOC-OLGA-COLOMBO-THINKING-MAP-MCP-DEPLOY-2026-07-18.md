# Grace documentation — Olga Colombo thinking-map MCP deployment (permanent)

**Date:** 2026-07-18  
**Class:** **docs-only** · **MCP** · **integration** (Olga clinical Cursor)  
**Project:** `olga` (`igareosh/olga`)  
**Wave:** **OLGA-ATM-00..06** (all DONE)  
**Repo tip (deployed):** `3d5f255` on [igareosh/olga](https://github.com/igareosh/olga)  
**Host:** **altitudine** · Linux user **`olga`** · path **`/home/olga/olga-work`**  
**Client:** **olgahere** Cursor Remote-SSH → Host `altitudine` · User `olga` · folder `olga-work`

---

## One line

**Permanent MCP `olga-colombo-thinking-map` on Olga’s home:** fpf-thinking-map + in-MCP CHROMA-2 (`clinical_locate_step`); productized selfcheck; deploy auto-respawns; compliance signed.

---

## What was deployed

| Layer | What |
|-------|------|
| **MCP server** | `olga-colombo-thinking-map` (local process on altitudine as `olga` — **not** team `cursor-thinking-map`) |
| **Domain map** | `colombo_clinical` only (no `team_ops` / `cluster_ops` / `eod_ops`) |
| **Library** | In-process CHROMA-2 via brain `agent_mcp_colombo_library.retrieval` (`tfp_ru`); standalone `colombo-library` MCP remains for catalog/ingest/facets |
| **Primary tool** | `clinical_locate_step` — library search + map step → `sources_to_address` + evidence |
| **Also** | `library_search`, `thinking_map_step` (`auto_library=true`), `thinking_map_verify`, `list_thinking_maps` |
| **Pin** | `fpf-thinking-map==1.5.0` (Olga `.venv` + site-packages path) |

**Not deployed into Olga Cursor:** team ATM hard-gate / brain `thinking_map_mode` shutdown semantics.

---

## Where it lives

| Item | Path |
|------|------|
| GitHub | `github.com/igareosh/olga` |
| Checkout | `/home/olga/olga-work` |
| User MCP | `/home/olga/.cursor/mcp.json` |
| Project MCP | `/home/olga/olga-work/.cursor/mcp.json` |
| Launcher | `scripts/agent-mcp-olga-thinking-map.sh` |
| Env (single source) | `scripts/olga-thinking-map-python-env.sh` |
| Selfcheck | `scripts/olga-mcp-selfcheck.sh` |
| Deploy | `scripts/deploy-olga-mcp.sh` |
| Preflight | `scripts/olga-ide-preflight.sh` (step 6 = selfcheck **hard-fail**) |
| Rules | `.cursor/rules/colombo-olga-clinical.mdc` (tool-first mandate) |

Deploy source of truth: `governance/mcp-config.json` → `deploy-olga-mcp.sh` rewrites `__OLGA_REPO__` to absolute paths.

---

## Productization (why “permanent”)

| Script / rule | Duty |
|---------------|------|
| `olga-mcp-selfcheck.sh` | Six real checks: engine verify; gate logic both branches; evidence grants (mocked); no team_ops leakage; launcher cwd-independence; live CHROMA-2 smoke |
| `olga-thinking-map-python-env.sh` | One cwd-pin + PYTHONPATH for launcher **and** selfcheck (no drift) |
| `deploy-olga-mcp.sh` | Write mcp.json; clear `__pycache__`; kill live `agent_mcp_olga_thinking_map` / `agent_mcp_colombo_library` so Cursor respawns (~35s) |
| Preflight step 6 | Runs selfcheck; **fails** preflight if not PASS |
| Clinical rule | `clinical_locate_step` before drafting science; raw-model science answer = compliance failure |

---

## Commit trail (igareosh/olga)

| Commit | What |
|--------|------|
| `a78819f` | Initial MCP + `colombo_clinical` |
| `8cfc103` | CHROMA-2 library integrate (`clinical_locate_step`) |
| `7d3ef6d` | Corpus-miss answer gate fix |
| `dec3741` | Launcher cwd pin (brain `thinking_maps` collision) |
| `3d5f255` | Productize: selfcheck, env script, self-restarting deploy, preflight hard-fail, tool-first rule |

---

## Operator / Olga — how to open (olgahere)

1. On **olgahere**: Cursor → Remote-SSH → Host **`altitudine`** (User **`olga`**).
2. Open folder **`/home/olga/olga-work`** only (not brain `/data/altitudine/prichindel.com`).
3. Optional after pull: `bash scripts/olga-ide-preflight.sh` → expect **PREFLIGHT PASS**.
4. Confirm MCP list includes **`olga-colombo-thinking-map`** and **`colombo-library`**.
5. Science turns: Colombo must call **`clinical_locate_step`** (silent scaffold — no ATM jargon to Olga).

SSH/cert issues → desktop `verify-altitudine-ssh.ps1` · [ALTITUDINE-SSH-HANDOFF.md](../../cluster/olgahere/ALTITUDINE-SSH-HANDOFF.md) · repo `SPEC-OLGA-IT-ESCALATION.md`.

---

## Verification already done (2026-07-18)

| Path | Result |
|------|--------|
| Local as `olga` | `olga-mcp-selfcheck.sh` → **SELFCHECK PASS** |
| olgahere → altitudine as `olga` | USER_MCP + PROJECT_MCP OK; full preflight → **PREFLIGHT PASS** |
| Compliance | Signed [OLGA-ATM-COMPLIANCE-SIGN-2026-07-18.md](reports/OLGA-ATM-COMPLIANCE-SIGN-2026-07-18.md) · row in [CURSOR-REPO-COMPLIANCE-CHECK.md](../../governance/CURSOR-REPO-COMPLIANCE-CHECK.md) |

---

## Team awareness (brain)

| Doc | Role |
|-----|------|
| [ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md](ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md) | Ethan design (operator-approved) |
| [GRACE-TRIAGE-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md](GRACE-TRIAGE-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md) | Wave triage **OLGA-ATM-00..06** |
| [OLGA-ATM-PRODUCTIZE-2026-07-18.md](reports/OLGA-ATM-PRODUCTIZE-2026-07-18.md) | Productize closeout |
| [OLGA-ATM-COMPLIANCE-SIGN-2026-07-18.md](reports/OLGA-ATM-COMPLIANCE-SIGN-2026-07-18.md) | Compliance sign-off |
| [OLGA-COLOMBO-WORKSPACE.md](../../cluster/olgahere/OLGA-COLOMBO-WORKSPACE.md) | Cluster pointer (olgahere → altitudine) |
| This packet | **Grace deployment documentation** (canonical narrative) |

**Owners after ship:** Colombo (Olga iteration — use MCP) · Felix (code in `igareosh/olga`) · Abelard (venv/path/SSH if broken).

---

## Do not

- Wire team `cursor-thinking-map` / `team_ops` into Olga’s Cursor.
- Ingest map runtime JSON into Papra / CHROMA-2.
- Open brain repo as Olga’s daily workspace.
- Teach Olga ATM jargon — map is silent; she sees clinical answers.

SIGNED: Triage (Grace) | Olga Colombo thinking-map MCP deployment documented | 2026-07-18 | permanent /home/olga · olgahere Remote-SSH
