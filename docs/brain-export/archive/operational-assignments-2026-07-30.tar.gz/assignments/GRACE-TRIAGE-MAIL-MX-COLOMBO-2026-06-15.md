# Grace triage — Mailcow mx1 agent mail MCP (Colombo @prichindel.com)

**Date:** 2026-06-15  
**Source:** Operator — Colombo and all agents need **@prichindel.com** send/receive via **mx1 Mailcow** MCP; no credential hunting; Gena approves or implements.  
**Register:** [governance/MAIL-MX-2026-REGISTER.md](../../governance/MAIL-MX-2026-REGISTER.md)  
**Spec (draft for Gena):** [governance/SPEC-ETHAN-MAIL-MX-AGENT-MCP.md](../../governance/SPEC-ETHAN-MAIL-MX-AGENT-MCP.md)

---

## Triage outcome

**PROJECT-CREATED** — **MAIL-MX-00..10** on [active.md](../../active.md).  
**Project:** `cursor-repo` · **integration** + **MCP** + **security**  
**Primary consumer:** **Colombo** (`colombo@prichindel.com`)  
**Infra:** **mx1** Mailcow (`192.168.100.69` · `mx1.prichindel.local` / `mx1.prichindel.com`) — [cluster/alunel/MAILCOW-MX-CLUSTER.md](../../cluster/alunel/MAILCOW-MX-CLUSTER.md)

---

## Problem statement

| Today | Gap |
|-------|-----|
| **cursor-postfix-mail** → Proton `igareosh@igareosh.com` on prichindel | Not `@prichindel.com`; not mx1 |
| **cursor-inbox-reader** → `inbox.md` in brain repo | Not email |
| mx1 has `igareosh@prichindel.com` only | **No `colombo@prichindel.com`** yet |

**Operator ask:** One MCP — send text/file like `sendmail`, list/check mailbox securely (plain reasoning, no “click the link”), creds pre-wired on host (same pattern as `/data/smtp-outbound/proton-external.env`).

---

## Architecture decision (Grace → Gena gate)

**Preferred:** New repo module **`agent_mcp_mailcow`** (or rename wave: **`cursor-mailcow-mail`**) — do **not** overload Proton postfix MCP.

| Layer | Choice |
|-------|--------|
| Transport | SMTP submission **587 STARTTLS** + IMAP **993 TLS** to **mx1** |
| Creds | Single host file `/data/smtp-outbound/mailcow-agents.env` — per-mailbox app passwords; **never** in tool args or git |
| MCP host | **prichindel** SSH (match other MCPs); prichindel must reach `mx1.prichindel.local` on LAN |
| Default From | `MCP_MAILBOX` env in mcp-config (e.g. `colombo@prichindel.com` for Colombo sessions) |
| n8n | **BACKLOG** — only if Gena rejects direct IMAP/SMTP in Python MCP |

**Coexistence:** Keep **cursor-postfix-mail** for Proton/personal; new MCP for **@prichindel.com** domain mail.

---

## Wave map

| ID | Owner | Focus |
|----|-------|--------|
| MAIL-MX-00 | Grace | Triage + register (this packet) |
| MAIL-MX-01 | Abelard | mx1 mailboxes + app passwords + creds file on prichindel |
| MAIL-MX-02 | Gena | **Approve/reject** spec; build vs buy (upstream MCP); n8n decision |
| MAIL-MX-03 | Gena | Implement MCP tools (send text, send file, list, get, check) |
| MAIL-MX-04 | Daniel | SECURITY-BASELINE — creds path, IMAP read boundary, attachment limits |
| MAIL-MX-05 | Cursor | `mcp-config.json` + deploy + MCP-COMPLIANCE |
| MAIL-MX-06 | Liam | `SCRIPT-RUNBOOK-mailcow-agent-mail.md` |
| MAIL-MX-07 | Colombo | Smoke send/receive + unread summary with reasoning |
| MAIL-MX-08 | Emma | Integration contract Proton MCP vs Mailcow MCP |
| MAIL-MX-09 | Ethan | Ratify spec (P2) |
| MAIL-MX-10 | Grace | Wave closure when MAIL-MX-01..08 DONE |

---

## Start order

1. **MAIL-MX-01** (Abelard) — mailbox + creds file (blocks MCP smoke)
2. **MAIL-MX-02** (Gena) — architecture sign-off before heavy code
3. **MAIL-MX-03..05** parallel after 02
4. **MAIL-MX-07** after 03+05

---

SIGNED: Triage (Grace) | MAIL-MX PROJECT-CREATED | 2026-06-15 | mx1 agent mail MCP
