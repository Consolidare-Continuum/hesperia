# Hesperia wire-today cheatsheet (2026-07-26)

**Plan:** [ETHAN-H070-DAY-RUN-WIRE-GAPS-2026-07-26.md](ETHAN-H070-DAY-RUN-WIRE-GAPS-2026-07-26.md)  
**Ledger:** [HESPERIA-WIRE-GAP-LEDGER-2026-07-26.md](HESPERIA-WIRE-GAP-LEDGER-2026-07-26.md)

| Wave | Do next | Owner |
|------|---------|-------|
| 0 | DONE | — |
| 1 matrix | DONE (ledger M01–M18) | — |
| 2–5 | TOP-15 in ledger | Felix / Ava / Gena |
| 6 | ISO stub filled; expand on PRs | Cursor / Ethan |
| 7–8 | Outcome + carry | Ethan / Grace |

**Commands (prod tip):**

```bash
cd /data/hesperia/hesperia
export PYTHONPATH=. HESPERIA_STRICT_DETERMINISM=1
python3 tools/validate_version_consistency.py
python3 tools/audit_shipping_allowlist.py
python3 -m pytest tests/test_product_interpret_api.py::test_run_product_interpret_deterministic tests/h070/ -q
```

SIGNED: Cursor | cheatsheet | 2026-07-26 | H070-WIRE-076
