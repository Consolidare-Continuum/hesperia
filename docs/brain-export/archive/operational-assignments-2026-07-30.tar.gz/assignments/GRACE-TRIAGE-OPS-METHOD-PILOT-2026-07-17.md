# Grace triage — ops-method PILOT extract → matrix (2026-07-17)

**Project:** `ops-method`  
**Trigger:** Operator — proceed workflow; key installed; PRE-13 GO  
**Outcome:** PILOT rows for OpenAI extract → statements → matrix cells

| ID | Owner | Intent | Status |
|----|-------|--------|--------|
| OPS-METHOD-PILOT-00 | Grace | Triage this wave | DONE |
| OPS-METHOD-PILOT-01 | Felix | OpenAI extract runner + ingest statements/keywords/matrix | OPEN |
| OPS-METHOD-PILOT-02 | Felix | Adjust pre-ingest segmenter; re-segment pilot pages | OPEN |
| OPS-METHOD-PILOT-03 | Noah | Validate pilot batch gates G1–G8 | OPEN |
| OPS-METHOD-PILOT-04 | Ava | Smoke statement+matrix counts pages 1–20 | OPEN |
| OPS-METHOD-PILOT-05 | Ethan | Pilot READY → unlock full-book schedule (still freeze) | OPEN |

SIGNED: Triage (Grace) | PILOT wave | 2026-07-17
