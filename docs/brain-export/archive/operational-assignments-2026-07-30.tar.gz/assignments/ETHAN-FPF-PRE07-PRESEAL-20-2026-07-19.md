# Ethan — FPF-PRE07: last wire-up to pre-0.7 ready (20 tasks)

**Date:** 2026-07-19  
**Owner:** Ethan (Architecture) · board write via Grace form  
**Operator:** “add 20 tasks pre seal … wire it all up … pre0.7 ready”  
**Canon:** [SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md](../../governance/SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md)  
**Hold:** [HSR-V7-SEAL-OPERATOR-HOLD.md](../../governance/HSR-V7-SEAL-OPERATOR-HOLD.md) — **X-01..14 stay PAUSED** until operator explicit allow. PRE07 ≠ seal.

---

## What “pre-0.7 ready” means (precise)

| In scope | Out of scope |
|----------|--------------|
| HAND faces wired; agent rolls **without UI** | Prod seal tag / remotes push |
| Pin converge + collision polish | Unpause HSR-V7-X-* |
| Security OK for **synthetic/dev** agent rolling | External clinical REAL_DATA |
| X-14 **precondition list frozen** | Castle gate X-14 execution |
| Gold: ops loop + dig loop | Human UIs / sites / sales |

**Exit family PRE07-G1..G5** (Ethan owns definition; Grace stamps READY):

| Gate | Criterion |
|------|-----------|
| **PRE07-G1** | Both MCP faces live in mcp-config; pin Hesperia ≥ brain soak or documented waiver |
| **PRE07-G2** | Gold HAND loops: `hesperia_ops`→inquire and `hesperia_inspect`→GapReport |
| **PRE07-G3** | Security memo: synthetic agent-rolling allowed on altitudine |
| **PRE07-G4** | X-14 precondition checklist frozen (what must be green before operator unpause) |
| **PRE07-G5** | Grace declares **pre-0.7 READY** on register — seal still held |

---

## Exactly 20 rows — FPF-PRE07-00..19

| ID | P | Owner | Task | TYPE |
|----|---|-------|------|------|
| **FPF-PRE07-00** | P0 | Grace | Wave meta — PRE07 live; link this packet; cross-ref MWI + HAND + seal hold | triage |
| **FPF-PRE07-01** | P0 | Felix | Bump Hesperia `fpf-thinking-map` → **1.5.0**; fix collisions; CI green | task |
| **FPF-PRE07-02** | P0 | Felix | Gold HAND **ops loop** — `thinking_map_step(hesperia_ops)` → `hesperia_router_inquire` → re-step with ground_truth evidence | task |
| **FPF-PRE07-03** | P0 | Felix | Gold HAND **dig loop** — `hesperia_inspect` map → climb/GapReport → re-step | task |
| **FPF-PRE07-04** | P0 | Felix | Finish MWI wire spine if still open: mcp-config router (**MWI-01**) + E2E (**MWI-02**) — close or absorb | task |
| **FPF-PRE07-05** | P0 | Felix | Ship `hesperia_ops` map complete enough for PRE07-G2 (extends **MWI-06**) | task |
| **FPF-PRE07-06** | P1 | Felix | Agent-rolling harness — one Hesperia `tools/` or `scripts/` entry that runs ops+dig loops headless | task |
| **FPF-PRE07-07** | P1 | Felix | Option B hex_rotation if still OPEN (**HSR-14** / **MWI-07**) — or provisional tag remains named in GapReport | task |
| **FPF-PRE07-08** | P1 | Gena | VERSION / tag registry **pre-0.7 readiness note** (no seal tag bump) | task |
| **FPF-PRE07-09** | P1 | Gena | Publish agent-facing schema docs — ground_truth + GapReport + context_packet allowlist | task |
| **FPF-PRE07-10** | P0 | Ethan | Freeze **X-14 precondition checklist** (HSR G* + BUII-G* + MWI-G* + PRE07-G*) | spec |
| **FPF-PRE07-11** | P0 | Ethan | Ratify PRE07-G1..G5 exit; declare architecture “wire complete” criteria | spec |
| **FPF-PRE07-12** | P0 | Sophia + Daniel | Security memo — **synthetic/dev** agent HAND rolling OK; clinical still gated | task |
| **FPF-PRE07-13** | P1 | Colombo | Freeze agent-rolling glossary (HAND / face / dig / inquire / GapReport) | task |
| **FPF-PRE07-14** | P1 | Ava | Pre-0.7 integration matrix — both faces + pin + ground_truth + GapReport | task |
| **FPF-PRE07-15** | P1 | Abelard | Verify both MCP scripts + `HESPERIA_REPO_ROOT` on altitudine (dev only) | task |
| **FPF-PRE07-16** | P1 | Liam | Pre-0.7 **dev** deploy checklist (not prod X-05) | task |
| **FPF-PRE07-17** | P1 | Marcus | Operator recipe — “agent rolls Hesperia with no UI” (HAND loop) | task |
| **FPF-PRE07-18** | P2 | Emma | Operator acceptance — pre-0.7 READY without UI | task |
| **FPF-PRE07-19** | P0 | Grace | Stamp **pre-0.7 READY** when PRE07-G1..G5 met; sync registers; **do not** unpause X-* | triage |

**Deps:** `01` before `02/03`; `04/05` before `02`; `10/11` parallel; `12` before READY stamp; `19` last.

**SUITE:** YES on all.

**Do not:** unpause HSR-V7-X-*; flip prod clinical flags; invent UI work.

---

`SIGNED: Architecture (Ethan) | FPF-PRE07 20 tasks | 2026-07-19 | last wire to pre-0.7 ready; seal still held`
