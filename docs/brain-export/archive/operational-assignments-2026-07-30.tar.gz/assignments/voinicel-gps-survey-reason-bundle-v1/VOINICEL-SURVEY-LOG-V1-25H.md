# voinicel survey — log v1 · 25 h search & reason bundle

**Bundle:** `voinicel-gps-survey-reason-bundle-v1`  
**Version:** v1  
**Window:** 25 h from survey start (includes 24 h u-blox gate + 1 h post-gate)  
**Mount:** `voinicel-sma-rail-magnet-01`  
**Owner:** Colombo · **Source:** [voinicel-gps-survey-snapshot-20260620T1028Z](../voinicel-gps-survey-snapshot-20260620T1028Z/)  
**Updated:** 2026-06-20

---

## Search tags

`voinicel` `LEA-M8T` `survey-in` `TIM-SVIN` `ARP` `magnet-rail` `25h` `24h-gate` `svinAccLimit-1000mm` `quality_pct` `std3d` `Colombo` `reason-bundle` `v1` `Moldova-47N-28E` `incomplete` `accuracy-fail`

---

## Bundle manifest

| File | Role |
|------|------|
| [index.json](index.json) | Machine index — stats, gates, best-in-window |
| [convergence-25h.log](convergence-25h.log) | Full convergence log, 301 lines, 5 min cadence |
| [monitor-25h-hourly.csv](monitor-25h-hourly.csv) | Hourly SVIN samples (h0–h25) |
| [monitor-25h-milestones.json](monitor-25h-milestones.json) | h1, h6, h12, h24_gate, h25_end |
| [survey-spec.json](survey-spec.json) | Deployed UBX gates |
| `ubx-export-*.json` | Raw UBX poll snapshots in window |
| This file | Human search + reason entry point |

---

## COPY-PASTE — 25 h facts (search / reason)

```
VOINICEL-SURVEY-LOG-V1-25H

WINDOW
  start:        2026-06-19T01:33:16+03:00
  end:          2026-06-20T02:33:16+03:00  (25 h)
  mount_id:     voinicel-sma-rail-magnet-01
  hardware:     LEA-M8T-0 · WD22UGRC · SMA magnet on iron rail horizontal
  location:     ~47.03°N 28.82°E Moldova outdoor

SPEC (deployed)
  svinMinDur:     86400 s
  svinAccLimit:   1000 mm (1.0 m 3D — u-blox ns-timing reference tier)
  stop_rule:      BOTH dur>=86400 AND std3d<=1000 → valid=1 → Fixed mode

25H OUTCOME
  valid:          0 (never)
  duration@24h:   86345 s — GATE PASSED
  std3d@24h:      10078.9 mm — GATE FAILED (10.08 m)
  std3d@25h:      10114.5 mm — still FAILED
  quality@24h:    9.9%
  quality_range:  7.7% – 10.5% entire 25 h
  best_std3d:     9542.9 mm @ dur=551 s (first ~9 min only)
  pattern:        early brief improvement → plateau ~9.7–10.3 m for 23+ h

BEST ARP IN 25H (preliminary — valid=0, NOT certified)
  ts:             2026-06-19T01:40:07+03:00
  dur_s:          551
  ECEF_cm:        X=381598414 Y=209969027 Z=464396715
  LLA:            47.027862°N 28.821156°E
  std3d_mm:       9542.9
  quality_pct:    10.5%

AT 24H GATE (milestone h24_gate)
  ts:             2026-06-20T01:30:01+03:00
  dur_s:          86345
  obs:            86346
  ECEF_cm:        X=381599410 Y=209969740 Z=464397418
  std3d_mm:       10078.9
  quality_pct:    9.9%
  active:         1
  valid:          0

HOURLY STD3D PLATEAU (monitor-25h-hourly.csv)
  h0:  12904.8 mm   h6:  9674.6 mm   h12: 10024.4 mm
  h18: 10266.2 mm   h24: 10073.8 mm   h25: 10114.5 mm
```

---

## COPY-PASTE — 25 h conclusions (reason)

```
REASON — 25H WINDOW

1. Within 25 h the survey crossed the duration gate but NEVER the accuracy gate.
   At h24: std3d ≈ 10.08 m vs 1.0 m target → ~10% of u-blox ns reference tier.

2. Accuracy plateaued by ~h1–h2; extra hours to h25 did not materially improve std3d.
   Best observed std3d (9.54 m) occurred in the first 9 minutes — not at end of run.

3. valid=0 for entire 25 h → no Fixed-mode ARP; running-mean coordinates are indicative only.

4. DOP/SV coverage adequate (typical survey); failure is mount/multipath/environment ceiling,
   not lack of satellites or short duration.

5. For this magnet-on-rail mount, svinAccLimit=1000 mm is not achievable in 25 h (or 35 h full run).
   Realistic tier for this site: ~10 m 3D unless mount or environment changes.

6. Full run continued to 35.8 h then lost to voinicel reboot (outside this 25 h bundle).
   See [VOINICEL-SURVEY-WRAP-2026-06-20.md](../VOINICEL-SURVEY-WRAP-2026-06-20.md) for post-25h context.
```

---

## Hourly table (from monitor-25h-hourly.csv)

| Hour | Local ~time | dur_s | std3d_mm | quality_pct | valid |
|------|-------------|-------|----------|-------------|-------|
| 0 | 01:33 | 142 | 12904.8 | 7.7 | 0 |
| 1 | 02:35 | 3851 | 10458.4 | 9.6 | 0 |
| 2 | 03:35 | 7452 | 10517.7 | 9.5 | 0 |
| 3 | 04:35 | 11052 | 10403.0 | 9.6 | 0 |
| 4 | 05:35 | 14653 | 10305.2 | 9.7 | 0 |
| 5 | 06:35 | 18253 | 9781.9 | 10.2 | 0 |
| 6 | 07:35 | 21854 | 9674.6 | 10.3 | 0 |
| 7 | 08:35 | 25454 | 9793.9 | 10.2 | 0 |
| 8 | 09:35 | 29055 | 9872.5 | 10.1 | 0 |
| 9 | 10:35 | 32655 | 10089.2 | 9.9 | 0 |
| 10 | 11:35 | 36245 | 10018.8 | 10.0 | 0 |
| 11 | 12:35 | 39845 | 9951.1 | 10.0 | 0 |
| 12 | 13:35 | 43445 | 10013.9 | 10.0 | 0 |
| 13 | 14:35 | 47045 | 10248.2 | 9.8 | 0 |
| 14 | 15:35 | 50645 | 10118.9 | 9.9 | 0 |
| 15 | 16:35 | 54245 | 10041.0 | 10.0 | 0 |
| 16 | 17:35 | 57845 | 10211.7 | 9.8 | 0 |
| 17 | 18:35 | 61445 | 10352.8 | 9.7 | 0 |
| 18 | 19:35 | 65045 | 10266.2 | 9.7 | 0 |
| 19 | 20:35 | 68645 | 10275.2 | 9.7 | 0 |
| 20 | 21:35 | 72245 | 10306.0 | 9.7 | 0 |
| 21 | 22:35 | 75845 | 10235.6 | 9.8 | 0 |
| 22 | 23:35 | 79445 | 10164.6 | 9.8 | 0 |
| 23 | 00:35 | 83045 | 10062.8 | 9.9 | 0 |
| **24** | **01:35** | **86645** | **10073.8** | **9.9** | **0** |
| 25 | 02:30 | 89945 | 10114.5 | 9.9 | 0 |

---

## Milestone JSON (verbatim)

```json
[
  {"label":"h24_gate","ts_local":"2026-06-20T01:30:01+03:00","dur_s":86345,"std3d_mm":10078.9,"quality_pct":9.9,"valid":0},
  {"label":"h25_end","ts_local":"2026-06-20T02:30:01+03:00","dur_s":89945,"std3d_mm":10114.5,"quality_pct":9.9,"valid":0}
]
```

---

## index.json summary (machine)

```json
{
  "bundle_version": "v1",
  "window_hours": 25,
  "std3d_mm_at_24h": 10078.9,
  "std3d_mm_at_25h": 10114.5,
  "quality_pct_range": [7.7, 10.5],
  "valid_ever_in_window": false
}
```

---

## Cross-refs

- Deed: [agents/colombo/VOINICEL-ANTENNA-SURVEY.md](../../agents/colombo/VOINICEL-ANTENNA-SURVEY.md)
- Spec: [cluster/voinicel/ANTENNA-MOUNT-SURVEY.md](../../cluster/voinicel/ANTENNA-MOUNT-SURVEY.md)
- Full run wrap: [VOINICEL-SURVEY-WRAP-2026-06-20.md](../VOINICEL-SURVEY-WRAP-2026-06-20.md)

SIGNED: Research (Colombo) | voinicel survey log v1 25h reason bundle | 2026-06-20
