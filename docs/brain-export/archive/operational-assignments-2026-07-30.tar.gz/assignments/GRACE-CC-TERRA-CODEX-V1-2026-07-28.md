# Grace — CC_ Terra Codex web spec v1 (original frames)

**Date:** 2026-07-28  
**Invoker:** Operator → Grace (`by gpt terra`)  
**Wave:** CC_-BRAND  
**Task:** **CC_-BRAND-06**

## Drop

Five PNG boards from `.cache_to_sort_out/` (UUID filenames) — GPT Terra original:

| Order | Cache UUID | Master name |
|-------|------------|-------------|
| 01 | `230e03aa-…` | `01-terra-codex-web-design-spec.png` |
| 02 | `99bdc905-…` | `02-visual-system-material-logic.png` |
| 03 | `72a97e97-…` | `03-site-elements-ui-components.png` |
| 04 | `6cfa139e-…` | `04-motion-interaction-spatial-framing.png` |
| 05 | `b79ebd8e-…` | `05-page-templates-outcome-map.png` |

## Custody (Lane B SOT)

Repo: https://github.com/Consolidare-Continuum/CC_brading_and_site  
Path: `brand/masters/terra-codex-web-spec-v1/`  
Decision: `decisions/2026-07-28-terra-codex-web-spec-v1.md`  
Policy: [ETHAN-POLICY-CC-BRANDING-AND-SITE.md](../../governance/ETHAN-POLICY-CC-BRANDING-AND-SITE.md)

## Outcome

**DONE** — byte-identical masters filed, README + decision lock written, brain pointer via this note + active.md **CC_-BRAND-06**.

SIGNED: Triage / branding keeper (Grace) | Terra Codex v1 | 2026-07-28 | CC_-BRAND-06
