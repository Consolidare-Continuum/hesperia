# Grace triage — MCP-BRAIN wave (MCP improvements + brain repo awareness)

**Date:** 2026-06-20  
**Source:** Operator — Cursor orchestrates **10 team members × 3 tasks** from own context to improve repo and agentic flow.  
**Policy:** [MCP-COMPLIANCE-AND-OPERATIONAL.md](../../governance/MCP-COMPLIANCE-AND-OPERATIONAL.md) · [CHROMA-USAGE-POLICY.md](../../governance/CHROMA-USAGE-POLICY.md) · [CURSOR-CHROMA-TERSAGOR-COLOMBO-BOUNDARIES.md](../../governance/CURSOR-CHROMA-TERSAGOR-COLOMBO-BOUNDARIES.md)

---

## Triage outcome

**PROJECT-CREATED — MCP-BRAIN** — **2026-06-20** — [active.md](../../active.md) **MCP-BRAIN-001..030** · register [MCP-BRAIN-2026-REGISTER.md](../../governance/MCP-BRAIN-2026-REGISTER.md).

**One sentence:** Each team member owns **3 docs/runbook/policy rows** so agents reliably use **MCP + CHROMA-1** for brain context and **colombo-library (CHROMA-2)** for science — without grep-first drift or parallel task lists.

---

## Scope (in)

| Tag | Meaning |
|-----|---------|
| **MCP** | Awareness of existing MCP tools; compliance rows; no new servers |
| **workflow** | `get_heartbeat`, `get_current_step`, `report_done`, owner CSP |
| **docs-only** | Governance, contracts, test matrices, runbooks |
| **integration** | Routing: chroma-knowledge vs colombo-library vs inbox-reader |

## Scope (out)

- New MCP server implementations (→ Ethan shortlist + separate wave)
- LAN replication infra (→ **LRP** wave; complementary only)
- Client product code (Hesperia engine, SuiteCRM product build)

---

## CHROMA-2 / science path

Non-Colombo agents use **CHROMA-2** only for **science-informed retrieval** via **`colombo-library`** MCP — not team `query_knowledge` ingest. Ref: [agents/colombo/COLOMBO-CHROMA-2.md](../../agents/colombo/COLOMBO-CHROMA-2.md), [cluster/librarymaster/CHROMA-2.md](../../cluster/librarymaster/CHROMA-2.md).

**Team brain:** CHROMA-1 on alunel — `query_knowledge` mandatory first for process/roles/workflow.

---

## Member task blocks (3 each)

| Owner | IDs | Focus from own context |
|-------|-----|------------------------|
| **Ethan** | 001–003 | Architecture ratify, MCP shortlist, compliance |
| **Grace** | 004–006 | Triage meta, register, inbox/BF-007 hygiene |
| **Olivia** | 007–009 | Workflow API consumer docs, MCP smoke template |
| **Ava** | 010–012 | Agent behavior test matrices (MCP + CHROMA-2) |
| **Marcus** | 013–015 | Chroma storage boundary, layer hygiene, idempotency |
| **Sophia** | 016–018 | MCP exporter surveillance, drift cron, ownership matrix |
| **Liam** | 019–021 | Session opener runbook + mandatory trigger |
| **Daniel** | 022–024 | MCP SSH boundary, colombo write policy, cluster repair gate |
| **Noah** | 025–027 | CHROMA policy, layer routing, retrieval QA |
| **Emma** | 028–030 | Integration contracts, agent pickup flow |

---

## active.md rows (triaged)

| Pri | Project | ID | Owner | Status |
|-----|---------|-----|-------|--------|
| P1 | mcp-brain | MCP-BRAIN-001 | Ethan | OPEN |
| P1 | mcp-brain | MCP-BRAIN-002 | Ethan | OPEN |
| P1 | mcp-brain | MCP-BRAIN-003 | Ethan | OPEN |
| P1 | mcp-brain | MCP-BRAIN-004 | Grace | OPEN |
| P1 | mcp-brain | MCP-BRAIN-005 | Grace | OPEN |
| P1 | mcp-brain | MCP-BRAIN-006 | Grace | OPEN |
| P1 | mcp-brain | MCP-BRAIN-007 | Olivia | OPEN |
| P1 | mcp-brain | MCP-BRAIN-008 | Olivia | OPEN |
| P1 | mcp-brain | MCP-BRAIN-009 | Olivia | OPEN |
| P2 | mcp-brain | MCP-BRAIN-010 | Ava | OPEN |
| P2 | mcp-brain | MCP-BRAIN-011 | Ava | OPEN |
| P2 | mcp-brain | MCP-BRAIN-012 | Ava | OPEN |
| P2 | mcp-brain | MCP-BRAIN-013 | Marcus | OPEN |
| P2 | mcp-brain | MCP-BRAIN-014 | Marcus | OPEN |
| P2 | mcp-brain | MCP-BRAIN-015 | Marcus | OPEN |
| P2 | mcp-brain | MCP-BRAIN-016 | Sophia | OPEN |
| P2 | mcp-brain | MCP-BRAIN-017 | Sophia | OPEN |
| P2 | mcp-brain | MCP-BRAIN-018 | Sophia | OPEN |
| P1 | mcp-brain | MCP-BRAIN-019 | Liam | OPEN |
| P1 | mcp-brain | MCP-BRAIN-020 | Liam | OPEN |
| P1 | mcp-brain | MCP-BRAIN-021 | Liam | OPEN |
| P2 | mcp-brain | MCP-BRAIN-022 | Daniel | OPEN |
| P2 | mcp-brain | MCP-BRAIN-023 | Daniel | OPEN |
| P2 | mcp-brain | MCP-BRAIN-024 | Daniel | OPEN |
| P1 | mcp-brain | MCP-BRAIN-025 | Noah | OPEN |
| P1 | mcp-brain | MCP-BRAIN-026 | Noah | OPEN |
| P1 | mcp-brain | MCP-BRAIN-027 | Noah | OPEN |
| P1 | mcp-brain | MCP-BRAIN-028 | Emma | OPEN |
| P1 | mcp-brain | MCP-BRAIN-029 | Emma | OPEN |
| P1 | mcp-brain | MCP-BRAIN-030 | Emma | OPEN |

---

## Agent flow (target end state)

```mermaid
flowchart LR
  A[Session start] --> B[get_runbook session-opener]
  B --> C[query_knowledge CHROMA-1]
  C --> D[get_heartbeat / get_current_step]
  D --> E[Owner CSP execute]
  E --> F{Science needed?}
  F -->|yes| G[colombo-library CHROMA-2]
  F -->|no| H[report_done]
  G --> H
```

---

## SuiteCRM

All new rows: `SUITE: YES` · sync after triage per [GRACE-TRIAGE-SUITE-CRM-PER-ACTIVE-ADOPT-2026-06-18.md](GRACE-TRIAGE-SUITE-CRM-PER-ACTIVE-ADOPT-2026-06-18.md).

---

## Exit

Close at **30/30 DONE** per [MCP-BRAIN-EXIT-CRITERIA.md](../../governance/MCP-BRAIN-EXIT-CRITERIA.md) G1–G4. Grace closure packet → `operational/assignments/reports/`.

---

SIGNED: Triage (Grace) | MCP-BRAIN 3×10 wave | 2026-06-20
