# TPBRUN — Retro ThePirateBay Proxy Theme Spec

**Status:** captured from live site + public asset pack  
**Reference URL:** https://tpb.run/search.html?q=category:601  
**Captured:** 2026-06-15  
**Owner context:** Gena (main developer) — UI/theme mirror spec

---

## 1. Identity

| Field | Value |
|---|---|
| **Public name** | Retro ThePirateBay Proxy |
| **Page title** | `TPB.run - Retro ThePirateBay Proxy...` |
| **Marketing label** | Retro Green, Terminal Themed Proxy |
| **Internal asset pack** | `tpbrun` |
| **UX voice prefix** | `X:Proxy > …` |
| **Hosting** | Cloudflare (Turnstile gate before content) |
| **NOT the same as** | [Gioni06/terminal.css](https://github.com/Gioni06/terminal.css) — separate framework |

**Canonical asset source:**  
https://github.com/piraproxy/tpb-proxy-list-2026/tree/main/tpbrun

**CDN base (live):**  
`https://piraproxy.github.io/tpb-proxy-list-2026/tpbrun/`

**Target page semantics:** `category:601` = **Other → E-books** (TPB taxonomy; parent category `600` = Other).

---

## 2. Design tokens (production — `tpb.css`)

What tpb.run inlines in production. These values override the alternate `terminal.css` variable palette in the same repo.

| Token | Value | Usage |
|---|---|---|
| `--bg-base` | `#0a0a0a` | page, inputs, table rows, panels |
| `--bg-alt` | `#111111` | zebra rows, file list `.alt` |
| `--bg-hover` | `#1a1a1a` | torrent row `:hover` |
| `--text-primary` | `#33FE33` | all text, borders, links |
| `--text-muted` | `#33FE33` @ `opacity: 0.7` | meta lines, uploader, comments |
| **Font** | `1.25em/1.5em monospace` | system monospace stack |
| **Links** | dotted `1px` bottom border → solid on hover | no underline |
| **Borders** | `1px solid #33FE33` | forms, panels, tables |
| **Meta borders** | `1px dashed #33FE33` | `dt` / `dd` in detail view |

### Alternate palette (`terminal.css` in same repo)

CSS-variable variant — greener “Matrix” phosphor, not what tpb.run ships inline:

```css
:root {
  --bg-primary: #0c0c0c;
  --bg-secondary: #141414;
  --bg-tertiary: #1a1a1a;
  --text-primary: #00ff41;
  --text-secondary: #00cc33;
  --text-dim: #008f11;
  --border-color: #003300;
  --font-mono: 'Courier New', Courier, 'Lucida Console', Monaco, monospace;
}
```

**Mirror rule:** use **`tpb.css`** for pixel-accurate tpb.run clone; keep `terminal.css` only if extending with VPN bar, custom scrollbars, or variable theming.

---

## 3. Visual layers (signature CRT stack)

Fixed z-order on every page load:

| z-index | Element | Behaviour |
|---|---|---|
| `2147483647` | `#scanlines` | fullscreen, `pointer-events: none`, `opacity: 0.7` |
| `9998` | `#loading-container` | centered boot box |
| `9997` | `#pixel-overlay` | 70×70px grid reveal animation |
| default | `main` / `header` / `footer` | page content |

### Scanlines

```html
<div id="scanlines" style="position:fixed;top:0;left:0;width:100%;height:100%;
  pointer-events:none;z-index:2147483647;
  background-image:url('…/tpbrun/scanline.png');
  background-repeat:repeat;opacity:0.7;"></div>
```

Asset: `scanline.png` — PNG 960×720, 8-bit RGBA, ~9.4 KB.

### Boot box

```html
<div id="loading-container" style="position:fixed;top:50%;left:50%;
  transform:translate(-50%,-50%);z-index:9998;
  background:#0a0a0a;padding:20px 40px;border:1px solid #33FE33;">
  <div id="loading-text" style="color:#33FE33;font-family:monospace;font-size:18px;">
    X:Proxy &gt; Routing via tpb.run
  </div>
</div>
```

### Pixel-grid reveal (boot-overlay.js)

Parameters extracted from live site:

- `squareSize = 70` (px)
- Grid covers viewport: `cols = ceil(innerWidth/70)`, `rows = ceil(innerHeight/70)`
- Each cell: `position:absolute`, `background:#0a0a0a`
- Reveal order: sort by row then column (top-left → bottom-right)
- `batchSize = 3`, `delay = 15` ms between batches
- Each square: `opacity: 0`, `transition: opacity 0.05s ease`
- After all revealed: hide `#pixel-overlay` and `#loading-container` at +100 ms
- Start after `setTimeout(revealBatch, 100)`

### Turnstile gate (tpb.run-specific)

Pre-content screen copy:

`X:Proxy > Booting flesh-and-bone verifier...`

```html
<form id="verify-form" action="/verify" method="POST">
  <input type="hidden" name="redirect" id="redirect-input" value="/search.html?q=category:601">
  <div class="cf-turnstile"
       data-sitekey="0x4AAAAAADgsVvb7N8SCQTzI"
       data-callback="onVerified"
       data-theme="dark"></div>
</form>
```

Live sitekey is tpb.run’s — use your own Turnstile key in any real deploy.

---

## 4. Asset inventory

| File | ~Size | Role |
|---|---|---|
| `tpb.css` | 6.4 KB | **Production theme** — primary mirror target |
| `terminal.css` | 10.3 KB | Extended reference (variables, VPN bar, scrollbars) |
| `scanline.png` | 9.4 KB | CRT overlay |
| `tpb.png` | 18 KB | hero / logo |
| `tpblogo_sm_ny.png` | 8.6 KB | small header logo (≥1250px) |
| `tpblogo_sm_nyBAK.png` | 7.5 KB | logo backup variant |
| `icon-magnet.gif` | 57 B | magnet link icon |
| `trusted.png` | 115 B | uploader trusted badge |
| `moderator.png` | 991 B | mod badge |
| `vip.png` | 991 B | VIP badge |
| `supermod.png` | 991 B | supermod badge |
| `favicon.ico` | 824 B | repo root, not under `tpbrun/` |

**Download:**

```bash
BASE=https://raw.githubusercontent.com/piraproxy/tpb-proxy-list-2026/main
curl -LO "$BASE/tpbrun/tpb.css"
curl -LO "$BASE/tpbrun/terminal.css"
curl -LO "$BASE/tpbrun/scanline.png"
curl -LO "$BASE/tpbrun/tpb.png"
curl -LO "$BASE/tpbrun/tpblogo_sm_ny.png"
curl -LO "$BASE/tpbrun/icon-magnet.gif"
curl -LO "$BASE/tpbrun/trusted.png"
curl -LO "$BASE/tpbrun/moderator.png"
curl -LO "$BASE/tpbrun/vip.png"
curl -LO "$BASE/tpbrun/supermod.png"
curl -LO "$BASE/favicon.ico"
```

---

## 5. DOM contract

CSS selectors in `tpb.css` define required IDs and classes. Renaming breaks layout.

### 5.1 Page shell

```html
<body id="home" class="align-center">
<!-- browse context: -->
<div id="browse">
  <header class="row">…</header>
  <main class="browse row">
    <aside class="col-left">…</aside>
    <section class="col-center">…</section>
    <aside class="col-right">…</aside>
  </main>
  <footer>…</footer>
</div>
```

Utility classes: `.align-center`, `.flow-root`, `.flow-column`, `.row`, `.form-box`.

### 5.2 Header

| Element | Notes |
|---|---|
| `#logo` | hidden until `≥1250px`; link home; `a { border: 0 }` |
| `nav` | top links — see §7 Copy |
| `form` | search + category filter |
| `#search_input` | `width: 20em` at `≥800px`; green border inputs |
| `select` | same styling as inputs |

Ads hidden by theme: `#logo` co-hidden with `.ad120`, `.ad468`, `.ad728` until desktop breakpoint re-enables ad slots (still commonly stripped in mirror).

### 5.3 Torrent list (`#torrents`)

Uses CSS `display: table` on `<ul>`, not HTML `<table>`.

```html
<ul id="torrents" class="view-double">
  <li class="list-header">
    <span class="list-item list-header item-type">Type</span>
    <span class="list-item list-header item-name">Name</span>
    <span class="list-item list-header item-seed">SE</span>
    <span class="list-item list-header item-leech">LE</span>
  </li>
  <li class="list-entry alt">
    <span class="list-item item-type">Other(E-books)</span>
    <span class="list-item item-name">
      <span class="item-title"><a href="…">Title</a></span>
      <span class="item-details">Uploaded Today 14:00, Size 45.48 MiB, ULed by user</span>
      <span class="item-icons"><!-- magnet, trusted, mod badges --></span>
    </span>
    <span class="list-item item-seed">3</span>
    <span class="list-item item-leech">7</span>
  </li>
</ul>
```

| Class / ID | Rule |
|---|---|
| `.list-entry` / `.list-entry.alt` | zebra `#0a0a0a` / `#111111` |
| `.list-entry:hover` | `#1a1a1a` |
| `.item-details` | muted green @ 0.7 opacity |
| `.item-icons` | `inline-block`, `width: 70px` |
| `.item-seed`, `.item-leech` | `text-align: right` |
| `#viewswitch` | hidden mobile; `display: inline; float: right` at `≥800px` |
| `.view-double` / `.view-single` | column layout toggle |

Browse page heading:

```html
<h1>Browse Other &gt; E-books</h1>
```

Inside `#browse h1` — centered mobile, left-aligned desktop.

### 5.4 Detail page (`#description_container`)

| Region | Markup notes |
|---|---|
| Container | `border: 1px solid #33FE33`, `background: #0a0a0a` |
| `h2` | uppercase feel: `letter-spacing: 0.07em`, bottom border |
| `#metadata` | `display: flex` at `≥800px` |
| `.col-meta` | `width: 50%` each column |
| `dt` | bold, dashed bottom border; `.dt-sm` = 4em, `.dt-md` = 8em |
| `dd` | dashed bottom border |
| `.text-box` | bordered box, `white-space: pre-wrap` on `#description_text` |
| `#filelist` | `ol`, `.alt` rows, `.file-size` float right |
| `#comments_container` | `.comment-meta` muted; `.comment-text` bordered pre-wrap box |
| `.hyper-link:before` | content `➤` (`\27A4`) |
| `.links a` | uppercase, bold, dotted underline |

`.details h1` hidden mobile, shown `≥800px`.

### 5.5 Category sidebar (`.category_list`)

```html
<dl class="category_list">
  <div>
    <dt>Other</dt>
    <dd><a href="…category:601">E-books</a> …</dd>
  </div>
</dl>
```

`width: 50%`; sub-links as inline-flex in `dd`.

### 5.6 Forms and filter overrides (tpb.run injected)

Custom checkbox (16×16):

- unchecked: `background #0a0a0a`, `border 2px solid #33FE33`
- checked: `background #33FE33`, dark tick via `::after` rotated border

`#flist` filter input: `width 200px`, green placeholder @ 0.7 opacity.

Filter checkbox IDs on live site: `#f_720p`, `#f_1080p`, `#f_2160p`, `#f_x264`, `#f_h264`, `#f_x265`, `#f_h265`, `#f_webrip`, `#f_bluray`, `#f_hdr`, `#f_hevc`.

---

## 6. Responsive breakpoints

| Min width | Behaviour |
|---|---|
| default | stacked header; inputs `width: 99%`; centered `#browse h1`; ads hidden |
| `480px` | `.ad234` hidden; `.adblock .ad468` shown |
| `800px` | header `flex-direction: row`; 3-column `.browse`; `#search_input` 20em; `#viewswitch` visible; `.details h1` shown; side cols `140px` |
| `1250px` | `#logo` visible; `#browse` centered `width: 1240px` |

---

## 7. Copy strings

| Context | String |
|---|---|
| `<title>` | `TPB.run - Retro ThePirateBay Proxy...` |
| Boot routing | `X:Proxy > Routing via tpb.run` |
| Turnstile gate | `X:Proxy > Booting flesh-and-bone verifier...` |
| Browse H1 (601) | `Browse Other > E-books` |
| Type column (601) | `Other(E-books)` |
| Top nav | `Search Torrents \| Browse Torrents \| Recent Torrents \| TV shows \| Music \| Top 100` |
| Main categories (select) | `All \| Audio \| Video \| Applications \| Games \| Porn \| Other` |

---

## 8. Mirror implementation

### 8.1 Static theme bundle

```
theme/
  normalize.css          # v8.0.1 — inlined on live site
  tpb.css                # production tokens (#33FE33)
  terminal.css           # optional extended variant
  boot-overlay.js        # pixel grid reveal
  assets/
    scanline.png
    tpb.png
    tpblogo_sm_ny.png
    icon-magnet.gif
    trusted.png
    moderator.png
    vip.png
    supermod.png
  favicon.ico
templates/
  layout.html            # scanlines + boot overlay + header/footer shell
  home.html
  search.html
  browse-601.html        # E-books list
  details.html
```

### 8.2 CSS load order

1. `normalize.css` v8.0.1 (full reset — live site inlines entire file)
2. `tpb.css`
3. Optional injected overrides (checkbox, `#flist`, VPN link colour)

### 8.3 Data layer (separate from theme)

tpb.run is a **proxy** — theme is skin only.

| Backend | Notes |
|---|---|
| [UnblockedPiratebayClean](https://github.com/piratebayproxy/UnblockedPiratebayClean) | PHP + `api.php` + JS AJAX — swap in `tpb.css` |
| Cloudflare Worker / Pages | same DOM contract; `*.pages.dev` mirrors exist |
| [isohuntto/openbay](https://github.com/isohuntto/openbay) | different stack; replace CSS |

**Category 601 query:** `search.html?q=category:601` or `/browse/601` — rows use type label `Other(E-books)`.

### 8.4 Skip in design-only mirror

- VPN ad injection (`a.hyper-link[href*="nord-vpn"]`)
- Ad slot markup (already `display: none` in `tpb.css` for most slots)

### 8.5 Wrong reference sites

| Site | Why not |
|---|---|
| `pbproxy.pages.dev` | classic TPB skin, not tpbrun |
| `Gioni06/terminal.css` | unrelated framework |

---

## 9. Verification checklist

- [ ] Background `#0a0a0a`, text `#33FE33`, monospace `1.25em/1.5em`
- [ ] Scanline overlay visible, non-interactive
- [ ] Boot sequence: routing text → pixel reveal → content
- [ ] Links: dotted underline → solid on hover
- [ ] `#torrents` renders as CSS table with zebra rows
- [ ] E-books browse shows `Browse Other > E-books` and `Other(E-books)` type
- [ ] Forms: green border inputs on black background
- [ ] Desktop `≥1250px`: logo visible, content max `1240px` centered
- [ ] Detail page: `#description_container` bordered panel, `➤` prefix on hyper-links

---

## 10. Gaps and limits

- Post-Turnstile HTML not captured automatically from live tpb.run; DOM contract is fully defined by **`tpb.css`** plus classic TPB browse markup (see [thepiratebay.zone/browse/601](https://thepiratebay.zone/browse/601) for row shape).
- tpb.run worker/backend source is **not** public; only **`tpbrun`** asset pack is on GitHub.
- Live Turnstile sitekey belongs to tpb.run — do not reuse in production.

---

## 11. References

| Resource | URL |
|---|---|
| Live site | https://tpb.run/ |
| Target page | https://tpb.run/search.html?q=category:601 |
| Asset pack | https://github.com/piraproxy/tpb-proxy-list-2026/tree/main/tpbrun |
| CDN | https://piraproxy.github.io/tpb-proxy-list-2026/tpbrun/ |
| E-books browse shape | https://thepiratebay.zone/browse/601 |
| TPB category 601 | E-books under Other (600) |

---

SIGNED: Main Developer (Gena) | developer context | 2026-06-15 | TPBRUN retro theme design spec
