# Ethan → Grace — CC_ documents manager + secretar (2026-07-15)

**Status:** PROJECT-CREATED / policy RATIFIED  
**Policy:** [governance/ETHAN-POLICY-GRACE-CC-DOCUMENTS-MANAGER-AND-SECRETAR.md](../../governance/ETHAN-POLICY-GRACE-CC-DOCUMENTS-MANAGER-AND-SECRETAR.md)

## Intent

Ethan ratifies Grace enlargement for **CONSOLIDARE CONTINUUM SRL (`CC_`)**: documents manager + secretar (no new agent). Main Grace triage feature stays. Scripts + MinIO procedure in scope. Mail from `agents@prichindel.com` to Proton-family addresses by scope. n8n awareness = SuiteCRM sync existing; no mandatory new mail workflow.

## Deliverables

| # | Owner | Deliverable | Status |
|---|-------|-------------|--------|
| 1 | Ethan | Policy RATIFIED | DONE (this wave) |
| 2 | Grace | Card + runbook + scripts wired | DONE this session |
| 3 | Grace | Standing keeper duty remains `CC_-03` | OPEN |
| 4 | Grace | Use mail/MinIO scripts on demand | standing |

## Mail matrix (quick)

`agents@prichindel.com` → `consolidare_continuum@proton.me` | `igareosh@protonmail.com` | `igareosh@igareosh.com`

SIGNED: Architecture (Ethan) + Documents manager (Grace) | CC_ enlargement | 2026-07-15
