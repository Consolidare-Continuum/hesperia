# Grace triage — Hesperia wire-gap day run (2026-07-26)

**From:** Ethan plan  
**Plan:** [ETHAN-H070-DAY-RUN-WIRE-GAPS-2026-07-26.md](ETHAN-H070-DAY-RUN-WIRE-GAPS-2026-07-26.md)  
**Count:** 80 tasks · Waves 0–8 · **open 8–12 at a time**

## What to triage

| Priority | Action |
|----------|--------|
| P0 | Triage **Wave 0** (`H070-WIRE-001`…`008`) onto `active.md` now |
| P0 | Create gap ledger file (WIRE-002) as first concrete artifact |
| P1 | After Wave 0 drain ≥80%, open Wave 1 (`009`…`018`) |
| — | Do **not** dump Waves 2–8 until prior wave mostly DONE |

## Row template

`| P0 | hesperia | **H070-WIRE-NNN** Owner: <summary> | Owner | OPEN | [ETHAN-H070-DAY-RUN…](operational/assignments/ETHAN-H070-DAY-RUN-WIRE-GAPS-2026-07-26.md) · SUITE: YES · SUITE NR: — · TYPE: task |`

## Constraints (copy into awareness)

Stay `v0.7.0` · multipurpose identity · ISO alignment ≠ cert · no clinical framing · Class B gated.

SIGNED: Triage (Grace) | wire-gap day | 2026-07-26 | wave batching
