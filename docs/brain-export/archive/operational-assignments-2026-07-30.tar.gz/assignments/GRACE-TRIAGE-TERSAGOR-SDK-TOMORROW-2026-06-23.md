# Grace triage — Tersagor SDK tomorrow sprint (~40 tasks, Gena)

**Date:** 2026-06-23 (tomorrow)  
**Source:** Operator — budget ~40 tersagor tasks on active.md; **mind Gena answer** on sequencing.  
**Prior wave:** [GRACE-TRIAGE-TERSAGOR-SDK-UPGRADE-PHASE23-2026-06-22.md](GRACE-TRIAGE-TERSAGOR-SDK-UPGRADE-PHASE23-2026-06-22.md) · prod `9dc5b13`

---

## Triage outcome

**PROJECT-CONTINUED — TERSAGOR-SDK-TOMORROW** — **2026-06-23** — **TSDK-W40** meta + **40 OPEN** execution rows for **Gena** (incl. reprioritized 083–100 + new 101–124). Register: [TSDK-UPGRADE-2026-REGISTER.md](../../governance/TSDK-UPGRADE-2026-REGISTER.md).

**One sentence:** Tomorrow sprint = Gena sequencing first (parity + golden agentic tests + version_gate + operator doc), soak watch, MCP prereqs — **defer** ToolSearch (088) and routing dedup (100) until measured/spiked.

---

## Gena sequencing (mandatory run order)

| Order | IDs | Theme |
|-------|-----|--------|
| **1** | 083, 106–109 | Routing parity umbrella + four fixtures |
| **2** | 094, 095, 121, 122 | Golden agentic tests (no approval theater) |
| **3** | 090, 120 | `version_gate` hard-fail on deploy |
| **4** | 096, 123, 117 | Operator health doc + daily regression script |
| **5** | 101, 111–113 | Soak watch + trust-mode regression tests |
| **6** | 084, 110 | Dead regex removal + orchestrator line gate (after parity green) |
| **7** | 104–105, 116, 087 | MCP network + allowlist + E2E (Abelard 104 first) |
| **8** | 085, 086, 097–099, 092 | Phase 4–6 polish |
| **9** | 091, 114, 093 | Compat removal after soak + dry-run |
| **—** | **088, 100, 102, 103** | **PAUSED** — measure / spike only; no prod change |

---

## PAUSED (Gena defer)

| ID | Reason |
|----|--------|
| **TSDK-088** | ToolSearchTool — measure tool count/latency first (102) |
| **TSDK-100** | Routing dedup — spike doc only (103); high blast radius |
| **TSDK-102** | Measurement row — output gates 088 |
| **TSDK-103** | Spike doc — output gates 100 |

---

## Budget

| Bucket | Count |
|--------|-------|
| Grace meta | 1 (TSDK-W40) |
| Gena OPEN tomorrow | **40** (39 Gena + 1 Abelard 104) |
| Gena PAUSED (in wave) | 4 (088, 100, 102, 103) |
| Grace hygiene | 126 |
| Prior DONE | 081, 082 |

---

## Operator commands (must stay green)

`!agent status` · `!agent abelard cluster services status` · `!agent abelard list cluster online vms` · `!agent abelard status on alunel`

---

SIGNED: Grace (triage closure) | Gena chapter 1 closed; tomorrow sprint queued | 2026-06-22 | tersagor-sdk-tomorrow
