# Grace triage — ops-method MIND API flow cards

**Date:** 2026-07-28 · **Owner:** Grace  
**Trigger:** Operator — API align mind-over-semantics; material flattenable into tasking flowing cards  
**Upstream:** [MIND-OVER-SEMANTICS-READY.md](../../projects/ops-method/MIND-OVER-SEMANTICS-READY.md) · [RU-ATOMIC-BLIND-TODO-FRAME-2026-07-28.md](../../projects/ops-method/RU-ATOMIC-BLIND-TODO-FRAME-2026-07-28.md) §6

## Product

AGV lab (`:8765`) exposes **flowing task cards** flattened from RC `it_blind_todo` (+ CTA core as same contract). Mind gates — not cosine propose.

| Endpoint | Role |
|----------|------|
| `GET /tasks/flow` | Stream of flattened cards (`slot`/`moon`/`cursor`/`limit`) |
| `GET /tasks/next` | One card for agent session |
| `GET /tasks/{id}` | Inspect card + hop-1 logical edges |
| `POST /tasks/{id}/doing` | Claim |
| `POST /tasks/{id}/complete` | Evidence → done |
| `GET /tasks/stats` | Slot / status counts |

Card contract: `card_id · kind · slot · moon · do_ru · artifact · done_when · blind · status · origin_ref · mind{} · flow{}`

## Rows

| ID | Owner | Task |
|----|-------|------|
| **OPS-METHOD-MIND-API-00** | Grace | This triage |
| **OPS-METHOD-MIND-API-01** | Felix | Wire `/tasks/*` on AGV; flatten RC todos; restart lab AGV |
| **OPS-METHOD-MIND-API-02** | Ava | Smoke flow/next/complete + mind filters |
| **OPS-METHOD-MIND-API-03** | Ethan | Sign **MIND-API-FLOW-READY** |

**Triage outcome:** PROJECT-CREATED.

SIGNED: Triage (Grace) | MIND API flow cards | 2026-07-28 | ops-method
