# Grace triage — SuiteCRM per-active sync (mandatory from 2026-06-18)

**Date:** 2026-06-18  
**Source:** Operator — use SuiteCRM on **per-active** basis after Gena wired `activemd-crm-sync` (SUITE-CRM-35/36/84).  
**Prior:** [GRACE-TRIAGE-SUITE-CRM-TAKEOVER-2026-06-18.md](GRACE-TRIAGE-SUITE-CRM-TAKEOVER-2026-06-18.md) · [SUITECRM-WORKFLOWS.md](../../cluster/prichindel/n8n/SUITECRM-WORKFLOWS.md)

---

## Triage outcome

**POLICY-ACTIVE** — Grace triage **must** use `SUITE:` / `TYPE:` on **every new row** unless explicitly excluded. Sync is live on prichindel (cron 15 min + `suitecrm_sync_on_triage.sh`).

**Rows on active.md:** **SUITE-CRM-85..87** (adoption + pilot).

---

## What changed (Gena — SUITE-CRM-84 DONE)

| Piece | Location |
|-------|----------|
| Upsert script | `scripts/suitecrm_sync_active_md.py` |
| Triage one-liner | `scripts/suitecrm_sync_on_triage.sh --task-id <ID>` |
| Parser / flags | `scripts/suitecrm_active_md_common.py` |
| Grace runbook | [scripts/SCRIPT-RUNBOOK-grace-triage-active.md](../../scripts/SCRIPT-RUNBOOK-grace-triage-active.md) |
| Cursor rule | [.cursor/rules/cursor-suitecrm-mcp.mdc](../../.cursor/rules/cursor-suitecrm-mcp.mdc) |
| n8n export | [cluster/prichindel/n8n/activemd-crm-sync.workflow.json](../../cluster/prichindel/n8n/activemd-crm-sync.workflow.json) |
| Cron (prichindel) | `*/15 * * * *` → `scripts/cron-suitecrm-activemd-sync.sh` |

**Live proof:** **SUITE-CRM-84** → CRM `3530ce40-021b-41dd-9e2e-2757dc07f74a` (Todo / Not Started).

---

## Grace triage checklist (every new row)

1. **Write row** on [active.md](../../active.md) (BF-007 columns).
2. **Link cell** — append after markdown link (` · ` separator):

   ```text
   SUITE: YES · SUITE NR: — · TYPE: <triage|spec|task>
   ```

   | TYPE | When |
   |------|------|
   | `triage` | Grace triage packet / wave bootstrap / inbox → PROJECT-CREATED header row |
   | `spec` | Ethan spec, architecture ratification, CONTEXT-PACKET approval row |
   | `task` | Default executable unit (owner executes) |

3. **Default:** `SUITE: YES` for all **new** triages, specs, and tasks. Use `SUITE: NO` only for archive/hygiene rows that must not appear in CRM.
4. **Sync immediately** after triage (do not wait for cron):

   ```bash
   ssh prichindel 'sudo bash /data/workspaces/cursor/scripts/suitecrm_sync_on_triage.sh --task-id <ACTIVE_MD_ID>'
   ```

5. **Verify** Link column: `SUITE NR:` filled with CRM UUID after sync.
6. **Owner completes row** → `report_done(DONE)`; Cursor/MCP also `suitecrm_set_done` (automatic in workflow API when DONE).

---

## Pilot (SUITE-CRM-86..87)

**Next real inbox triage** (feature, investigation, or project wave):

- Grace applies checklist above on **all** rows created in that wave.
- First row in wave: `TYPE: triage` (Grace closure/bootstrap).
- Spec rows (if any): `TYPE: spec`.
- Execution rows: `TYPE: task`.
- Grace runs sync per row or once at end of wave (`suitecrm_sync_active_md.py active.md --write-back` on prichindel).

**Cursor** on pilot: when owner marks DONE, confirm CRM tree = Done ([SUITE-CRM-87](../../active.md)).

---

## Operator visibility

- **SuiteCRM UI:** `https://suite.prichindel.local` — Todo / Pending / Done trees.
- **Correlation:** `active_md_id_c` = row ID (e.g. `SUITE-CRM-84`).
- **CRM UI → active.md:** still **inbox only** ([SUITECRM-CRM-UI-TRIAGE-RULE.md](../../governance/SUITECRM-CRM-UI-TRIAGE-RULE.md)).

---

## Exceptions

| Case | SUITE |
|------|-------|
| Historical DONE rows (pre-2026-06-18) | NO (do not backfill unless operator asks) |
| docs-only / REPO-EOD hygiene | NO unless operator wants CRM mirror |
| New Grace triage / spec / task | **YES** |

---

## References

- [active.md](../../active.md) header — Link column format
- [OPERATIONAL-LAYER.md](../../governance/OPERATIONAL-LAYER.md) §II — single list
- [ETHAN-TARGETED-RUNBOOKS-MANDATORY.md](../../governance/ETHAN-TARGETED-RUNBOOKS-MANDATORY.md) — `SCRIPT-RUNBOOK-grace-triage-active` on triage
- [agents/grace/SUITE-CRM-TRIAGE-CHECKLIST.md](../../agents/grace/SUITE-CRM-TRIAGE-CHECKLIST.md) — one-page Grace copy

SIGNED: Triage (Grace) | per-active SuiteCRM adoption POLICY-ACTIVE | 2026-06-18 | SUITE-CRM-85
