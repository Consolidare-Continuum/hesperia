# Grace triage — EX exercise proposals / recommendations index

**Triage:** Grace · **Date:** 2026-07-22 · **Pack:** SRC-RYB-ED01  
**Plan:** [ETHAN-PLAN-EX-EXERCISES-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-EX-EXERCISES-2026-07-22.md)

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-EX-00** | Grace | P0 | Triage EX wave |
| **OPS-METHOD-EX-01** | Ethan | P0 | Ratify EX design (kinds, address, local embed) |
| **OPS-METHOD-EX-02** | Felix | P0 | Schema 011 `exercise_item` + ledger |
| **OPS-METHOD-EX-03** | Felix | P0 | Harvest Практическое задание N → proposals |
| **OPS-METHOD-EX-04** | Colombo | P0 | Exemplifies_ru gloss policy + recommendation harvest |
| **OPS-METHOD-EX-05** | Felix | P0 | Local embeddings + JSONL + search |
| **OPS-METHOD-EX-06** | Felix | P0 | API list/get/search exercises |
| **OPS-METHOD-EX-07** | Liam | P1 | Runbook EX session |
| **OPS-METHOD-EX-08** | Ava | P0 | Smoke coverage + search |
| **OPS-METHOD-EX-09** | Ethan | P0 | Sign **EX-READY** |

SIGNED: Triage (Grace) | EX exercises | 2026-07-22
