# Felix — H070-GRIND-01 runtime grind inventory (v0.7.0)

**Date:** 2026-07-26  
**Owner:** Felix  
**Task:** H070-GRIND-01  
**Status:** DONE — inventory only (no version bump, no code change this row)

**Seal:** prod `/data/hesperia/hesperia` · tag **`v0.7.0`** @ **`0fcbe899360354c74260ff605787ad2c91bfe355`**  
**Dev peer:** `/data/workspaces/atomic-commit-hesperia` → `igareosh/hesperia`  
**Phase:** [HESPERIA-POST-070-PHASE-FRAME.md](../../governance/HESPERIA-POST-070-PHASE-FRAME.md) (Ethan RATIFIED)

---

## CSP

```
From: Cursor Context | To: Felix Context
Reason: H070-GRIND-01 — inventory better/faster/robust candidates on sealed v0.7.0
What changes: Python/runtime authority; inventory + proposed grind slices; no seal identity change
```

---

## Constraint

- Stay on **`system_version: 0.7.0`** / tag `v0.7.0`.
- No new physics; no Class B into sealed `/analyze`.
- Grind = wiring · soak · determinism · allowlist · CI evidence inside the frame.

---

## Inventory (prod tree evidence)

### A — Better (correctness / determinism)

| Candidate | Path / evidence | Grind slice (proposed next rows) |
|-----------|-----------------|----------------------------------|
| Product interpret determinism | `tests/test_product_interpret_api.py` (`test_run_product_interpret_deterministic`) · `runtime/services/product_interpret_service.py` | Soak matrix: fixed seeds + `HESPERIA_STRICT_DETERMINISM=1`; golden response shape |
| Interpretation policy | `core/policy/interpretation_policy.py` · `tests/test_interpretation_policy.py` · `tests/interpretation/` | Flag matrix: mode / overlay_hint / gap_report — no silent drift |
| H070 apply gold | `tests/h070/test_h070_apply.py` · `tests/h070/test_h070_gold.py` | Keep allowlist-only apply green on every grind PR |
| Version authority | `VERSION.yaml` · `pyproject.toml` `version = "0.7.0"` · `tools/validate_version_consistency.py` | CI must stay green; never bump fields casually |
| Public API snapshot | `tools/verify_public_api_snapshot.py` (sealed-runtime-gate) | Treat snapshot drift as grind defect, not feature |

### B — Faster (latency / path cost)

| Candidate | Path / evidence | Grind slice |
|-----------|-----------------|-------------|
| Shipping API surfaces | `runtime/shipping/api_main.py` — `POST /analyze`, `POST /product/interpret` | Timed soak: N warm requests; record p50/p95 in assignment (no new dep) |
| Product benchmark harness | `tools/product_benchmark_eval.py` · `tests/test_product_benchmarks.py` · `benchmarks/` | Use existing harness; trim dead fixtures; no new physics |
| Corpus pipeline bench | `runtime/pipeline/run_corpus_benchmark.py` | Optional soak under Grace row; keep off sealed gate unless stable |
| Import surface | `runtime/shipping/shipping_import_allowlist.yaml` · `tools/validate_shipping_surface.py` · `tools/audit_shipping_allowlist.py` | Cap allowlist creep; drop unused prefixes |

### C — Robust (CI / e2e / gates)

| Candidate | Path / evidence | Grind slice |
|-----------|-----------------|-------------|
| Sealed runtime gate | `.github/workflows/sealed-runtime-gate.yml` | Keep all gate steps green on grind PRs (version, import boundary, sealing scan, API snapshot, shipping allowlist, forbidden zones) |
| Prod code-only | `.github/workflows/prod-code-only.yml` · `tools/ci/verify_prod_code_only.sh` | No docs creep into Atomic prod |
| E2E flows | `tests/test_e2e_flows.py` (407 lines) · `tests/test_e2e_full_stack.py` · `tests/domain/test_e2e_pipeline.py` | Quarantine flaky; prefer deterministic fixtures; marker hygiene (`pytest.ini` has `tfp` / `output_views` only — add `slow`/`soak` only if needed) |
| Archive / gold e2e | `tests/test_archive_063_e2e_gate.py` · `tests/test_fpf_mwi_gold_e2e.py` | Confirm still meaningful under 0.7.0; drop or pin if dead |
| Capability flags | `public_capability("interpret")` in shipping API | Document default ON/OFF; grind must not silently flip COBALT/REAL_DATA |

---

## Priority queue (suggested Grace/Felix follow-ups)

| Rank | Proposed ID | Slice | Why |
|------|-------------|-------|-----|
| 1 | H070-GRIND-02 | Interpret soak + determinism matrix | Product face of 0.7.0; awareness demos depend on it |
| 2 | H070-GRIND-03 | Shipping allowlist audit + creep cap | Sealed gate already encodes this — keep green |
| 3 | H070-GRIND-04 | E2E flake triage (`test_e2e_flows` / full stack) | Robustness without version story |
| 4 | H070-GRIND-05 | Benchmark/p95 baseline on `/analyze` + `/product/interpret` | Faster — evidence-backed |
| 5 | H070-GRIND-06 | Pin hygiene brain ↔ product (CI prove) | Better — no stealth version bump |

**Out of grind:** new CELL/molt campaigns, Class B into sealed analyze, COBALT/REAL_DATA “on by default”, wiki L* growth as primary program.

---

## Verify (this row)

```text
cd /data/hesperia/hesperia && git describe --tags --exact-match HEAD
# expect: v0.7.0
# HEAD: 0fcbe899360354c74260ff605787ad2c91bfe355
```

No product code edited under this assignment.

SIGNED: Developer (Felix) | Claude Code context | 2026-07-26 | H070-GRIND-01 inventory on v0.7.0
