# Felix/Cursor — H070-WIRE batch B1 (TOP-15 deepen)

**Date:** 2026-07-26  
**Batch:** after EXIT BAR — Grace CARRY opened  
**Seal:** `0fcbe899` · stay `0.7.0`  
**Status:** DONE (documentation + measurements; no version bump)

## Rows closed this batch

| ID | Summary | Result |
|----|---------|--------|
| **019** | Interpret capability defaults | `capabilities.yaml` `public.interpret: true`; `public_capability("interpret")` defaults **True** if key missing. Env: `HESPERIA_PRODUCT_SURFACE` (default strict), `HESPERIA_ROUTER_MODE` observe/warn/strict, `HESPERIA_INTERPRET_GAP_REPORT`, `HESPERIA_LLM_PROVIDER`. COBALT via `cobalt_enabled()` — not flipped by interpret alone. |
| **025** | `engine_trace` → interpret | Path: `run_product_interpret` → `compile_router_envelope` → `run_engine_analyze` → envelope.`engine_trace` → `enforce_ground_truth` + `_deterministic_interpretation` + `engine_trace_hash`. Dig face: `gap_detect` when gap_report on. |
| **028** | Interpret mode fixture matrix | Modes: `deterministic` \| `llm`. Flags: `overlay_hint`, `temp_relation_overlay`, `include_gap_report`, `context_packet` (allowlisted). Tests: `tests/test_product_interpret_api.py`. No new physics. |
| **045** | Pipeline optional modules | `configs/pipeline.yaml`: `nlp.basic`, `core.dict_a/b`, `topology.core`, **`tfp`**, `metrics.base`. TFP listed in pipeline = Class B module enabled in config, **not** folded into sealed `/analyze` identity. |
| **047** | Unreachable module pass | Aliases in `module_aliases.py` all map to importable targets present under prod tree (`nlp`, `tfp`, core.*). No orphan alias found this pass. |
| **051** | Soak recipe | In-process: warm 2× · N=20 · measure ms · report p50/p95. Prefer `compile_router_envelope` (analyze body) + `run_product_interpret(mode=deterministic)`. HTTP `/health` on :9005 optional when API up. |
| **052** | Soak once (altitudine) | **interpret** N=20: p50≈**794ms** p95≈**844ms** mean≈**797ms**. **envelope/analyze compile** N=20: p50≈**795ms** p95≈**838ms**. (Same machine; includes sealed analyze cost.) |
| **053** | `test_e2e_flows` triage | Collect-only: **13** tests. Full suite **>9m** without finish this session — **PARTIAL**; treat as soak/`slow` candidate; next: run with `-k` subsets or mark `slow` (WIRE-057/059). |
| **054** | `test_e2e_full_stack` | Collect **1** · **PASS** this session. |
| **055** | `domain/test_e2e_pipeline` | Collect **7** · **PASS** this session. |
| **022** | OpenAPI/schema | Shipping FastAPI: `docs_url=None`, `openapi_url=None` — **intentional** product surface. Contract = `InterpretBody` fields + public API snapshot tool (already OK). Align comments only; no OpenAPI publish without Ethan. |
| **038** | Sealed-runtime-gate on main | GitHub Actions `Atomic-Commits-Team/hesperia` main: **Sealed runtime gate** + **prod-code-only** **success** on seal push `30178169168` / `30178169134` (2026-07-25). |

## engine_trace wire diagram

```text
POST /product/interpret
  → product_interpret_service.run_product_interpret
    → compile_router_envelope
      → run_engine_analyze  →  engine_trace (+ trace_content_hash)
    → enforce_ground_truth(envelope)
    → interpretation (deterministic | llm)
    → optional gap_detect(dig) / cobalt if flags on
```

## CARRY still open (next batch)

`053` finish/subset · `059` (flake/slow fix for e2e_flows) · `064` release-notice ISO fields · remaining plan IDs.

SIGNED: Developer (Felix) · Cursor orchestrator | H070-WIRE batch B1 | 2026-07-26 | deepen · no version bump
