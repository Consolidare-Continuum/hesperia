# HWIKI-CAT-01 — parameter_catalog.md → wiki delta

**Date:** 2026-07-23  
**Owner:** Colombo  
**Source:** `/data/hesperia/hesperia/docs/foundations/parameter_catalog.md`  
**Wiki SOT:** `colombo_research/hesperia/wiki/tools/generate_wiki.py` ITEMS (post OPEN/KME/L6 regen)

## Method

Compared every named constant / threshold table row in `parameter_catalog.md` §§0–7 against wiki `ITEMS` names (fuzzy: substring match on symbol token). This is a **delta list**, not new pages (except where other HWIKI rows already added them the same session).

## Already wikified (catalog ↔ page present)

Geometry §0; activation/propagation §1–2; core math α/η/K_max/λ/decay/E_cap + penalty cluster via P_* pages; most diagnostic §4 thresholds; Louvain seed via Louvain page; conflict/opposition relation weights; KME §6 now has hub + 35 derived stubs (HWIKI-KME-01).

## Unwikified / weak coverage (next batch)

| Catalog symbol / group | Catalog § | Notes |
|---|---|---|
| `ultra_sparse_coverage_threshold` | 4 | diagnostic_rules.yaml — no page |
| `excessive_jump_threshold` | 4 | no page |
| `transition_concentration_threshold` | 4 | no page |
| `unique_areas_max` | 4 | monotony cap — no dedicated page |
| `ENTROPY_DROP_SIGNIFICANT` | 5 | FGR freshness — mentioned in prose only |
| `STABILITY_CURRENT_THRESHOLD` / `STABILITY_STALE_THRESHOLD` | 5 | freshness map partly covered by FGR freshness page; numeric pair not standalone |
| `DOMINANT_SHARE_HIGH` | 5 | covered as `FGR DOMINANT_SHARE_HIGH` — OK |
| Field-dynamics env knobs (`HESPERIA_FIELD_DYNAMICS_*`, `xi_proxy`, PhaseΘ) | corners / optional | out of four-pass scope; still unwikified |
| `active_sides` / `activeSides` | 1 (meaning) | derived census, not a constant page |
| `CoreShare` | 3 (via P_thin) | formula lives on P_thin page; no standalone |
| `k_amb` / `delta_gap` / `tau_core` / `k_thin` / `k_disp` / `k_guard` / `k_shadow` / `max_shadow_hops` | 3 | appear as **values on P_* pages**, not own pages — acceptable unless Ethan wants 1:1 |
| `energy_conservation_tolerance` | 3 | covered as `Energy conservation epsilon` — OK under alias |
| `stability_index` / `jump_rate` (signals) | 4 + weighting | consumed by Wiener feedback page; no standalone signal pages |

## Verdict

**HWIKI-CAT-01 deliverable = this delta list.** Highest-value missing pages for next Colombo pass: four diagnostic thresholds (`ultra_sparse`, `excessive_jump`, `transition_concentration`, `unique_areas_max`), then FGR freshness numeric pair, then field-dynamics corner.

SIGNED: Research (Colombo) | parameter_catalog delta | 2026-07-23 | HWIKI-CAT-01
