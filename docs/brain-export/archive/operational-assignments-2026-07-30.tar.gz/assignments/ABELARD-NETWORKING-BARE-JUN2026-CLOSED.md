# Abelard — networking + bare (alunel) — June 2026 CLOSED

**Status:** **DONE** · **Topics closed** (operator 2026-06-15)  
**Scope:** Cluster Tailscale/SSH toolkit + alunel holy cow hypervisor hygiene

---

## Networking — closed

| Deliverable | State |
|-------------|--------|
| Tailscale toolkit (`scripts/tailscale/`, MCP **cursor-tailscale**) | Wired · audit/sync workflow mandatory |
| librarymaster duplicate mesh IP vs altitudine | **Fixed** — separate tailnet IPs |
| LAN VM `accept-routes=false` | Verified |
| SSH managed block (`ts_ssh_sync --apply`) | On alunel + altitudine |
| Live inventory | [cluster/CLUSTER-NETWORK-INVENTORY-LIVE.md](../../cluster/CLUSTER-NETWORK-INVENTORY-LIVE.md) |
| Abelard spec | [agents/abelard/TAILSCALE-PROBLEM-ADDRESSED.md](../../agents/abelard/TAILSCALE-PROBLEM-ADDRESSED.md) — **month closed** |

**Ongoing rule (not open work):** execute Tailscale/SSH toolkit from **altitudine** or laptop; no hand-edited `100.x`.

---

## Bare / alunel holy cow — closed

| Deliverable | State |
|-------------|--------|
| Policy | [governance/ALUNEL-HOLY-COW-POLICY.md](../../governance/ALUNEL-HOLY-COW-POLICY.md) — operator-endorsed |
| Audit + purge scripts | `alunel-holy-cow-audit.sh`, `alunel-holy-cow-purge.sh` |
| Preflight gate | `agent-cluster-access-preflight.sh` blocks on audit errors |
| Hesperia `/data/hesperia` | **Migrated** → altitudine VM; hypervisor purged |
| Post-purge retained (on purpose) | CHROMA-1, `/data/workspaces/cursor`, `/data_prod/` + `README_DO_NOT_DEV_HERE.txt` |
| PVE 9.2 / kernel **7.0.6-2-pve** | Graceful reboot 2026-06-15; maintenance pass logged |
| Holy cow audit | **0 errors, 0 warnings** — state achieved |

**Ongoing rule (not open work):** dev/brain/Hesperia → **altitudine VM**; alunel = Proxmox + grandfathered services only.

---

## No further action this month

New networking or bare-metal scope → **Grace triage** as a new row; do not extend this closure packet.

SIGNED: DevOps (Abelard) | networking + bare Jun2026 closed | 2026-06-15 | operator topics closed
