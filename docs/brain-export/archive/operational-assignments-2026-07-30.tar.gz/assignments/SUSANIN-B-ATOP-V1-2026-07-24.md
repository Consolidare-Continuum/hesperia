# Susanin B-atop — HANDOFF_EXECUTE (v1)

**Map transition:** `handoff_execute` · **Abort twin:** `abort_orbit`  
**Clearance:** ATM2 `AuthorizationReceipt` / approval MCP — never invent `authorized=true`.

## Pattern

1. Susanin run reaches `next` with `next_emitted`.  
2. Operator (or approval) authorizes execution handoff → `handoff_approved`.  
3. Fire `HANDOFF_EXECUTE` with Clearance.  
4. **Grace triage** → active.md rows for Felix/Gena/Abelard (implementation).  
5. Colombo remains **process owner**; passport owner stays Colombo until those rows take over.

## Security (Daniel)

- Ignition Lock / Clearance still apply.  
- Abort to Orbit if authorization missing or expired.  
- Do not forge receipts.

## Workflow passport (Cursor)

Until handoff rows exist, `workflow_context_current.md` owner for modeling work = **Colombo**. After Grace triage of B rows, owners follow those rows.

SIGNED: Felix / Daniel / Ethan / Cursor | Susanin B-atop v1 | 2026-07-24
