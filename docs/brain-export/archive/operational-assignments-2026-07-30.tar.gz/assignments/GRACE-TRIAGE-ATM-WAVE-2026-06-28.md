# Grace triage — ATM wave (Agentic Thinking Map mandatory — brain + MCP + agents)

**Date:** 2026-06-28  
**Source:** Operator chat — propagate [prichindel.com-agentic-thinking-map](https://github.com/igareosh/prichindel.com-agentic-thinking-map) **v1.2.1** into every brain, every agent, every MCP on triggers; Ethan architecture plan in Cursor session 2026-06-28.  
**Package:** MIT · zero deps · `python -m fpf_thinking_map.verify` (19 checks)

---

## Triage outcome

**PROJECT-CREATED — ATM** — **2026-06-28** — [active.md](../../active.md) **ATM-00..79** · register [ATM-2026-REGISTER.md](../../governance/ATM-2026-REGISTER.md) · exit [ATM-EXIT-CRITERIA.md](../../governance/ATM-EXIT-CRITERIA.md).

**One sentence:** Pin the **thinking map engine** as canonical runtime layer #3 (after CHROMA-1 context + workflow task), add **`cursor-thinking-map` MCP**, build **team_ops + cluster_ops** domain maps, wire **governance + rules + runbooks** so all entities call `thinking_map_step` on mandatory triggers — complements Hesperia **FPF-V7** bridge (already OPEN).

---

## Three layers (binding)

| Layer | Tool | Question |
|-------|------|----------|
| Context | CHROMA-1 + `query_knowledge` | What exists? What's the rule? |
| Task | `active.md` + pipeline MCP | What row? Who owns? |
| Move | `fpf_thinking_map` + `cursor-thinking-map` MCP | Lawful next move + blockers + `response_contract` |

**Not mandatory every turn** — mandatory on triggers (destructive, proceed, approval, cluster Abelard rows, multi-step workflow execute). Ref: Ethan spec row **ATM-03..04**.

---

## Scope (in)

| Tag | Meaning |
|-----|---------|
| **MCP** | New `agent_mcp_thinking_map` + mcp-config deploy |
| **integration** | approval-gates, pipeline-status, workflow passport |
| **workflow** | proceed gates, report_done chain |
| **docs-only** | Rules, runbooks, OPERATIONAL-LAYER, entity `.mdc` |
| **security** | Map cannot bypass human approval record |

## Scope (out)

- Reimplementing FPF in Chroma (→ existing `layer=fpf` catalog)
- C.32 / NQD activation-bias patterns (rejected in package — do not add to domain maps)
- Tersagor SDK routing (separate wave; ATM-68 documents async path only)

---

## Dependency graph (critical path)

```mermaid
flowchart LR
  A[ATM-05 Abelard pin v1.2.1] --> B[ATM-09 Felix MCP skeleton]
  B --> C[ATM-13 Gena mcp-config]
  C --> D[ATM-16 Felix team_ops map]
  D --> E[ATM-38 Gena workflow passport]
  F[ATM-03 Ethan spec draft] --> G[ATM-04 Ethan ratify]
  G --> H[FPF-V7-10 parallel ratify]
  H --> I[ATM-57 Felix Hesperia pin align]
```

**Start now:** **ATM-05** (Abelard package pin) · **ATM-03** (Ethan spec draft) — parallel.

---

## Member blocks (summary)

| Owner | IDs | Focus |
|-------|-----|-------|
| **Grace** | 00–02, 76–78 | Meta, register, heartbeat, SuiteCRM sync batches |
| **Ethan** | 03–04, 25, 59–60, 79 | Spec ratify, mandatory runbooks, compliance, wave sign-off |
| **Abelard** | 05–08, 20, 40, 61, 71–73 | Package pin, cluster map evidence, CHROMA catalog ingest, venv |
| **Felix** | 09–12, 16–19, 37, 57–58 | MCP server, domain maps, approval hook, Hesperia align |
| **Gena** | 13–15, 33–36, 38–39, 74 | mcp-config, workflow driver, Copilot/Claude MCP, cluster snapshot stub |
| **Cursor** | 26–32, 75 | Rules + AGENTS.md propagation |
| **Liam** | 21–24, 62–63 | Runbooks + index |
| **Daniel** | 44–45, 64 | Security + Hesperia preflight cross-link |
| **Olivia** | 46–47, 65 | Workflow API + passport template |
| **Ava** | 48–50, 69–70 | Test matrices |
| **Marcus** | 43, 66 | Audit trace proposals |
| **Sophia** | 53–54, 71 | Surveillance + ownership |
| **Noah** | 41–42, 67 | CHROMA policy + FAQ |
| **Emma** | 51–52, 68 | Integration contracts |
| **Colombo** | 55–56 | Research boundary docs |

---

## Hesperia link

Existing **FPF-V7-01..09 DONE** · **FPF-V7-10..13 OPEN**. ATM **57–58** align brain package pin with `sphere/fpf_bridge` after **FPF-V7-10** ratification. Do not duplicate bridge code in brain — pin same GitHub release.

---

## SuiteCRM

All rows: `SUITE: YES` · sync per [SCRIPT-RUNBOOK-grace-triage-active.md](../../scripts/SCRIPT-RUNBOOK-grace-triage-active.md) · batches **ATM-76..78**.

---

## Exit

Close at **80/80 DONE** per [ATM-EXIT-CRITERIA.md](../../governance/ATM-EXIT-CRITERIA.md) G1–G6. Grace closure → `operational/assignments/reports/`.

SIGNED: Triage (Grace) | ATM wave bootstrap | 2026-06-28 | ATM-00..79
