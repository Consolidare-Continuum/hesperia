# Grace triage — OPS-METHOD SOURCE-TRACE (wire down to DB bounds)

**Date:** 2026-07-28 · **Owner:** Grace · **Trigger:** Operator — HATCHET atop book; proceed wiring claims down to source tracing (bounded in DB, not vague).

## Mandate

Moons/edges already sit **atop** the book. Next: every flowing card + attached edge must resolve to **concrete `source_*` / statement loci** in PostgreSQL (`sentence_id`, `page_no`, pack, optional `evidence_span`). No OpenAI invent reopen.

## Rows

| ID | Owner | Work |
|----|-------|------|
| OPS-METHOD-TRACE-00 | Grace | This triage |
| OPS-METHOD-TRACE-01 | Felix | Backfill `relation_edge.evidence_sentence_ids` for `hatchet_page_chain` (and any empty) via STM→`sentence_id` |
| OPS-METHOD-TRACE-02 | Felix | AGV `/tasks*` expose `source_trace` (exercise + edge endpoints → `source_sentence`) |
| OPS-METHOD-TRACE-03 | Ava | Smoke: card + relations have non-empty bounded loci |
| OPS-METHOD-TRACE-04 | Ethan | Sign **SOURCE-TRACE-READY** |

## Exit

- Hatchet edges with empty evidence → **0**
- Sample `/tasks/{id}` returns `source_trace` with `sentence_id`/`page_no` (and edge `evidence_sentence_ids`)
- Lab only; invent API stays closed

SIGNED: Orchestrator (Grace) | SOURCE-TRACE triage | 2026-07-28 | ops-method
