# Inbox → Ethan — HESPERIA COBALT module branch spec

**Date:** 2026-06-20  
**From:** Colombo (research) · operator request  
**To:** **Ethan** (architecture spec) → **Grace** (triage after spec)  
**Type:** Feature / Hesperia branch  
**Project:** Hesperia · branch **COBALT**

---

## Summary

Formalize **HESPERIA COBALT** as a **confirmed MVP module branch**: library RAG enhancer (CHROMA-2 primary), post-analyze hook, optional TFP consumer, **not** main engine. Colombo completed research formalization from chat; **Ethan** to ratify module-branch spec and produce register for Grace.

---

## What Colombo delivered

| Artifact | Path |
|----------|------|
| Research formalization v0.1 | [colombo_research/hesperia/COBALT/COBALT_research_FORMALIZATION-v0_1.md](../../colombo_research/hesperia/COBALT/COBALT_research_FORMALIZATION-v0_1.md) |
| Branch model (TFP · MRT · COBALT) | [colombo_research/hesperia/HESPERIA-BRANCH-MODEL-TFP-COBALT-MRT.md](../../colombo_research/hesperia/HESPERIA-BRANCH-MODEL-TFP-COBALT-MRT.md) |
| Spec draft (Ethan ratifies) | [governance/SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md](../../governance/SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md) |
| Ethan task checklist | [governance/TASK-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md](../../governance/TASK-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md) |

---

## Ethan actions (owner)

1. Read formalization + draft spec.
2. Ratify or amend [SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md](../../governance/SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md) — update §10 ratification.
3. Complete [TASK-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md](../../governance/TASK-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md) tasks 1–5.
4. Produce `governance/COBALT-2026-REGISTER.md` + `governance/COBALT-EXIT-CRITERIA.md`.
5. Hand Grace triage stub for execution wave (`COBALT-00..n`).

---

## Key decisions for Ethan

| Decision | Colombo proposal |
|----------|------------------|
| Grid policy | Document 96 (MRT) vs 288 (prod) before unified CHROMA-2 bounding |
| Corpus gate | Module prod flag **off** until dict attribution + eval pass |
| TFP coupling | Optional phase 3 — TFP branch does not wait on COBALT |
| Repo | Module on `igareosh/hesperia` — not `hesperia_mrt` |

---

## Grace (after Ethan spec)

- Triage `COBALT-00..n` to [active.md](../../active.md).
- Separate **corpus track** (attribution) from **module track** (adapter/MCP).
- Link PAPRA-29 / PAPRA-50 where corpus gates overlap.

---

## Research outcomes (chat distilled)

1. COBALT = enhancer module, self-standing branch, uses most of Hesperia core.
2. CHROMA-2 embeddings alone insufficient — need dict_a/dict_b attribution pipeline.
3. Path B default: 0→hero CHROMA-2; TFP join when `TFP_*` concepts on chunks.
4. MVP = post-analyze adapter + `cobalt_retrieval` schema + MCP; flag default off.

---

`SIGNED: Researcher (Colombo) | inbox Ethan COBALT | 2026-06-20 | operational/assignments`
