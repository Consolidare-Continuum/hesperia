# Grace triage — LRP tomorrow wave (58 tasks)

**Date:** 2026-06-21  
**Source:** Operator — task team for **tomorrow**; budget **50–60 tasks** (cap **58**).  
**Register:** [governance/LRP-2026-REGISTER.md](../../governance/LRP-2026-REGISTER.md)  
**Exit:** [governance/LRP-EXIT-CRITERIA.md](../../governance/LRP-EXIT-CRITERIA.md)

---

## Triage outcome

**PROJECT-CREATED — LRP** — **LRP-00..57** (58 tasks) on [active.md](../../active.md).  
**Project:** `lan-rep` + `mcp-int` (unified product).  
**Supersedes (ARCHIVED):** **LAN-REP-01..03**, **MCP-INT-01..02** → granular rows here.  
**Kept DONE:** LAN-REP-00, MCP-INT-00 (prior triage meta).

---

## Tomorrow priority

1. **Abelard W1+W2** (LRP-05..22) — inventory + hotfix **first** (stupid mistakes today).
2. **Ethan W0** (LRP-01..03) — ratify in parallel.
3. **Abelard W3–W4** (LRP-23..40) — permanent layer.
4. **Gena/Liam/Cursor W5** (LRP-41..47) — MCP + runbooks.
5. **Team W6–W7** — contracts, tests, Grace close (LRP-57).

**Not in scope:** Antenna survey analysis, Colombo deed, GNSS export semantics.

---

## Wave summary

| Wave | IDs | OPEN |
|------|-----|------|
| W0 Meta | 00–04 | 4 (00 DONE) |
| W1 Inventory | 05–14 | 10 |
| W2 Hotfix | 15–22 | 8 |
| W3 Runner | 23–32 | 10 |
| W4 Observe | 33–40 | 8 |
| W5 MCP | 41–47 | 7 |
| W6 Gov | 48–52 | 5 |
| W7 QA + close | 53–57 | 5 |

**Total OPEN after triage:** **57** (LRP-00 DONE).

---

## SuiteCRM

All rows `SUITE: YES` · sync on prichindel cron or `suitecrm_sync_on_triage.sh --task-id LRP-xx`.

---

SIGNED: Triage (Grace) | LRP-00..57 PROJECT-CREATED | 2026-06-21 | 58-task tomorrow budget
