# Grace triage — QA adversarial traversal (OpenAI reasoning model vs. D3/AGV, Felix-supervised)

**Triage:** Grace · **Date:** 2026-07-22 · **Pack:** SRC-RYB-ED01
**Plan:** operator direct ask, scoped via Felix plan `frolicking-discovering-truffle`
**Freeze:** HOLD · no second book — this wave is framed as **freeze-exit evidence gathering**, not a product build

## Why this is in-scope under FREEZE-UNTIL-BOOK-COMPLETE

[POST-05-SEMANTICS-AUDIT.md](../../projects/ops-method/POST-05-SEMANTICS-AUDIT.md) leaves two freeze-exit criteria open: multi-relational map **NOT MET**, semantics **PARTIAL**. This wave drives an OpenAI reasoning model through business-outcome traversals of the canonical step mesh (via a new local MCP bridge over the existing `agv_api.py`), and has Felix independently verify each hop — both mechanically (replay through a new FPF `SemanticMap` formalizing the existing `reason_option_catalog` vocabulary, via `cursor-fpf-test-mcp.run_scenario(scope="user-extension", compliance_mode=True)`, plus a structural DB cross-check) and semantically (RU rationale vs. `title_ru`/`imperative_ru`/`relation_gloss_ru`). Findings feed directly into closing the two open gaps; this wave does not itself sign them COMPLETE — that stays a Grace/Ethan/Colombo call.

## Guardrails (binding)

| Rule | Binding |
|------|---------|
| No writes to `canonical_step` / `relation_edge` / `dictionary_term` | HARD |
| No public/remote exposure of the D3 API or MCP bridge (127.0.0.1 only) | HARD |
| Distinct from **CSS-13** (still PAUSED — that's DB-wide OpenAI re-classification; this is read+propose_todo traversal QA only) | HARD |
| Envelope rows tagged `agent="openai_qa_*"` for attribution in `/ops/tail` | HARD |
| Wave 2 (adversarial variants) only after operator reviews wave 1 tallies | HARD |

## Rows

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-QA-00** | Grace | P0 | This triage + guardrails |
| **OPS-METHOD-QA-01** | Felix | P0 | MCP bridge (`agv_mcp_bridge.py`) over existing AGV API |
| **OPS-METHOD-QA-02** | Felix | P0 | FPF traversal `SemanticMap` (`ops_method_step_traversal_map.py`) formalizing `reason_option_catalog` |
| **OPS-METHOD-QA-03** | Felix | P0 | OpenAI harness (`traversal_adversarial_test.py`) — wave 1, chapter-seeded runs |
| **OPS-METHOD-QA-04** | Felix | P0 | Supervisor verify (`traversal_supervisor_verify.py`) — FPF replay + structural + semantic check |
| **OPS-METHOD-QA-05** | Felix | P0 | Report mapping findings to POST-05 gaps; share tallies before wave 2 |

SIGNED: Triage (Grace) / Felix | QA adversarial traversal | 2026-07-22
