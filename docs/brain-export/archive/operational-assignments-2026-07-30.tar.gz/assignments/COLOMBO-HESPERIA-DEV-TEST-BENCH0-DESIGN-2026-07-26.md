# Colombo — Bench-0 gold design for hesperia-dev-test

**Date:** 2026-07-26  
**Owner:** Colombo (formalization)  
**Audience:** Felix (implement) · Ethan (ratify if schema expands) · Grace (triage rows)  
**Status:** DESIGN — reason-only; no sealed-core change  
**Depends:** [ETHAN-HESPERIA-DEV-TEST-APPROVAL-2026-07-26.md](ETHAN-HESPERIA-DEV-TEST-APPROVAL-2026-07-26.md) (APPROVED INTO USE)  
**Repo:** `igareosh/hesperia` → `tools/hesperia_dev_test/` (Class B · `product_surface: none`)

---

## CSP

```
From: Ethan/Cursor Context | To: Colombo Context
Reason: Operator — reason what to add so FastAPI + MCP inspect core math via fast gold Bench-0
What changes: research/formalization authority; design packet only; Felix implements; no sealed edits
```

---

## 1. What Bench-0 is

**Bench-0** = the **gold reference core test** for Hesperia sealed measurement under **semantics-free Latin tokens**.

| Property | Binding |
|----------|---------|
| **Input** | Bare Latin `a`–`z` only (and optional casefold twins `A`/`a` …) — **no** Dict A words, **no** domain prose |
| **Verdict style** | **Structural / math compliance** — schemas, shapes, finiteness, identity pins, determinism |
| **Not** | Reasoning on *what* a letter “means”; not “correct area for `a`”; not clinical/TFP; not LLM judgment |
| **Effect on engine** | **Read-only** Class B harness — never mutates core/, sealed assets, or `module_aliases.py` |
| **Growth law** | Capabilities are **added as check modules** against the same gold; Bench-0 stays the constant baseline |

**Analogy (ADV-09):** the bench is a **witness** of structural equality, not an oracle of domain truth. It pins *that the machine still measures the same way*, not *that the measurement is semantically wise*.

---

## 2. Inventory — what already exists

| Module | Checks today | Gap vs Bench-0 gold |
|--------|----------------|---------------------|
| `corpus.py` | letters + digits + bools + diacritics + indices | Mixes **lanes**; Bench-0 should be **latin-only** subset |
| `api_battery.py` | HTTP 200, determinism (strip volatile) | No **schema/math pin**; no vector-length / finite checks |
| `alphabet_map.py` | area/family/activation per letter | Records flat fallback; does not **assert gold equality** |
| `timing_probe.py` | layer timings | Observational — optional SLA, not gold |
| `fpf_battery.py` | ops ground_truth keys; dig GapReport schema; gap_count | gap_count drifted 15→16 — need **gap-id set gold**, not mean count alone |
| pytest `-m dev_test` | 2 structural tests | Not yet a **pinned gold** artifact |
| MCP | `hesperia_router_inquire`, `hesperia_fpf_probe/gaps` | **Not wired** into the battery; no MCP↔FastAPI parity |

---

## 3. Non-goals (hold the line)

1. Do **not** assert that letter `a` “should” land on a particular product meaning.  
2. Do **not** treat flat activation (`0.000535` / A1 / family_000) as a bug inside Bench-0 — it is the **current sealed fallback signature** to pin.  
3. Do **not** fold diacritic *folding* into Bench-0 pass criteria (known truncate → separate **lane B** / Grace grind).  
4. Do **not** open sealed core to make the bench “more interesting.”  
5. Do **not** invent semantic thresholds (e.g. “governance must be low”) — only **type, presence, range, length, hash equality**.

---

## 4. What to add — Bench-0 surface (ordered)

### 4.1 Corpus lane split

```
bench0_latin     = a–z (+ optional casefold pairs)     ← GOLD
lane_digit       = 0–9, numerics                         ← later
lane_bool        = true/false/t/f                        ← later
lane_index       = idx*, a1b2…                           ← later
lane_diacritic   = ăâîșț + RO words                      ← KNOWN_BEHAVIOR / grind, not gold
```

Default `pytest -m dev_test` and MCP “fast” path run **`bench0_latin` only**. Full corpus = soak / `--full`.

### 4.2 Gold pin artifact (new)

Path (proposed): `tools/hesperia_dev_test/gold/bench0_v0_1.json` (or `.yaml`)

Pinned fields (per letter **or** one shared fingerprint if proven identical across a–z):

| Pin | Why |
|-----|-----|
| `system_version` | Identity — currently `0.7.0` |
| `schema_version` / `CANONICAL_PIPELINE` | Seal path still `sealed_multiscale_v1` |
| `engine_result.trace_content_hash` | Opaque equality of activation surface |
| `dominant_{area,family,concept}_id` | Opaque IDs only |
| `top_activation` + `trace_len` | Numeric surface shape |
| `ground_truth.schema` | `hesperia.agent_response_ground_truth.v0_1` |
| `ground_truth` three axes present | `logical` / `weight` / `source_activation` keys exist |
| `len(family_activation_vector)==288` | SIGMA / ontology grain |
| `len(area_activation_vector)==12` | Area ring |
| All weight/activation floats | **finite**, not NaN/Inf; activations ∈ [0, 1] where defined |
| L1 scalar allowlist | Presence + type for gold keys (e.g. `TOTAL_TOKENS`, `COVERAGE_RATIO`, `UNIQUE_FAMILIES_HIT`, `CALIBRATION_FALLBACK_USED`) — **values** pinned only where stable across letters |
| GapReport | `schema == hesperia.fpf_gap_report.v0_1` + **sorted gap id set** equals gold set |

**Re-gold procedure:** explicit Felix/Ethan step when seal intentionally changes (version bump or sealed measurement change) — never silent overwrite in CI.

### 4.3 Math-compliance module (new) — `math_compliance.py`

Fast, in-process, no semantic read:

- Finite / range checks on activations, governance, obstacle, tension, loopability  
- Vector length contracts (288 / 12; microcell shape metadata if present)  
- Mass / sum sanity where already exposed (e.g. `total_mass` finite ≥ 0)  
- Determinism: two `/analyze` stripped payloads equal (already started)  
- **Reject** if any float is NaN/Inf (hard fail)

This is the “core math compliant via fast testing” layer.

### 4.4 FastAPI contract matrix (extend `api_battery`)

For each Bench-0 token:

| Endpoint | Assert |
|----------|--------|
| `POST /analyze` | 200; required top-keys; L1–L9 objects present; `engine_result` present |
| `POST /product/interpret` | 200; ground_truth three-axis; router envelope schema |
| (optional later) health/ready | 200 — not math |

Keep TestClient in-process as **default**; `--live` remains timing-only soak.

### 4.5 Inspect / FPF-BUII (extend `fpf_battery`)

- `hesperia_fpf_probe` (or `sphere.fpf_inspect probe`) per layer L0–L9/GTP/Guards/Router: **InspectSlice schema** + `engine_authored=true`  
- Gaps: **set equality** to gold gap-ids (not mean_gap_count)  
- Ops loop: ground_truth keys non-empty (already)

Inspection stays **cheap** (sub-ms probes); heavy path stays `build_dig_input` / analyze — Bench-0 may **skip** full dig timing by default and keep dig as `--full` or sample-1 letter.

### 4.6 MCP parity harness (new) — `mcp_parity.py` or MCP tool wrapper

Same gold pins checked two ways:

1. FastAPI TestClient `/analyze` + `/product/interpret`  
2. MCP `hesperia_router_inquire(text=letter)` → compare `trace_content_hash` / weight scalars / dominant ids  

**Pass rule:** MCP packet and FastAPI `engine_result` **agree on gold opaque fields** for each letter.  
If MCP host unreachable → mark `SKIP` in IDE, **fail** in CI when MCP is required.

Optional: expose `bench0_run` as a small MCP tool later (Abelard/Felix deploy) — not required for v0; CLI + pytest first.

### 4.7 Capability registry (growth surface)

New file: `tools/hesperia_dev_test/CAPABILITIES.yaml` (or section in EXTENSION_STATUS note)

```yaml
bench0:
  version: v0_1
  corpus: latin_a_z
  checks:
    - http_status
    - determinism
    - schema_ground_truth
    - schema_gap_report
    - vector_lengths_288_12
    - float_finite
    - activation_range
    - identity_system_version
    - alphabet_fingerprint_gold
    - mcp_fastapi_parity   # when MCP available
  deferred_lanes:
    - digit
    - bool
    - index
    - diacritic_known_behavior
    - timing_sla
    - double_analyze_observation
```

**Law:** new capability = new check id + gold field(s) + pytest node; Bench-0 never gains “interpret this meaning” checks.

---

## 5. Fast path vs soak

| Mode | Corpus | Dig/timing | Target |
|------|--------|------------|--------|
| **Bench-0 fast** | 26 letters | skip or 1 sample | seconds–tens of seconds after warm import |
| **dev_test default** | Bench-0 fast | gold asserts | CI / agents |
| **Full soak** | full_corpus | all probes + timing | manual / nightly |

Warm-import cost dominates today; keep one process-wide client; avoid 65× cold starts.

---

## 6. Relation to sealed logic

Bench-0 **observes** sealed measurement. It must not:

- change tokenizer, double `/analyze`, or Dict A  
- assert diacritic fold until Grace/Felix sealed-touch row exists  
- treat flat alphabet as failure — pin it as gold until seal changes

Findings that are **behavior of the seal** (diacritic truncate, double pass) stay **outside** Bench-0 pass/fail → grind lanes.

---

## 7. Formal definition (one sentence)

**Bench-0** is the expandable, Class-B, semantics-free **gold witness** that FastAPI and MCP still return the same **opaque structural and math contracts** for Latin single-token inputs under sealed Hesperia 0.7.0 — without reasoning about results and without modifying engine logic.

---

## NEXT

1. **Felix** — implement `gold/bench0_v0_1.json` + `math_compliance.py` + corpus lane `bench0_latin`; tighten pytest to gold asserts; keep full corpus as `--full` / separate marker.  
2. **Felix** — MCP↔FastAPI parity check for `a`–`z` opaque fields (`trace_content_hash`, weight scalars, dominant ids).  
3. **Ethan** — ratify gold re-pin protocol when `system_version` / sealed measurement changes.  
4. **Grace** — keep diacritic + double-`/analyze` as grind rows; do not fold into Bench-0 fail.  
5. **Optional later** — MCP tool `hesperia_bench0_run` for one-shot agent invoke (Abelard deploy).

SIGNED: Researcher (Colombo) | Hesperia Bench-0 formalization | 2026-07-26 | Class B gold design only
