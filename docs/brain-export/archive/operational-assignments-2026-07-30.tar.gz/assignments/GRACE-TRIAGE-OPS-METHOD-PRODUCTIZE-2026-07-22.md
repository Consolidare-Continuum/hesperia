# Grace triage — ops-method PRODUCTIZE wave

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01 (target: general)
**Trigger:** Operator — "clearly productized and reliable for further dev new books... runnable throughout from start to finish with outcomes ideas inspections."
**Source:** [ETHAN-PLAN-PRODUCTIZE-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-PRODUCTIZE-2026-07-22.md)
**FREEZE:** LIFTED for CORE/RYB-ED01 finish work (see [GRACE-FREEZE-LIFT-CORE-UNBOUNDED-2026-07-22.md](GRACE-FREEZE-LIFT-CORE-UNBOUNDED-2026-07-22.md)). This wave is readiness work, not second-book content — no new carve-out needed.

## Rows to add → active.md

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-PROD-00** | Grace | P0 | Triage PRODUCTIZE wave (this file) + SuiteCRM sync |
| **OPS-METHOD-PROD-G01** | Ethan | P0 | Ratify canonical pipeline stage order |
| **OPS-METHOD-PROD-G02** | Felix | P0 | `ops_method_cli.py` — one entrypoint, resumable stages |
| **OPS-METHOD-PROD-G03** | Ava | P0 | Smoke: kill-mid-stage/rerun on fixture, no duplication |
| **OPS-METHOD-PROD-H01** | Ethan | P0 | Ratify outcomes-report contract |
| **OPS-METHOD-PROD-H02** | Felix | P0 | `ops_method_outcomes_report.py` |
| **OPS-METHOD-PROD-H03** | Ava | P0 | Verify report reflects live DB, not stale docs |
| **OPS-METHOD-PROD-I01** | Felix | P1 | DSN → env var everywhere; dev creds out of source |
| **OPS-METHOD-PROD-I02** | Sophia | P1 | `agv_api.py` as managed service (systemd/compose) |
| **OPS-METHOD-PROD-I03** | Liam | P1 | Service runbook (start/stop/health/logs) |
| **OPS-METHOD-PROD-I04** | Ava | P1 | Regression smoke post-schema-change |
| **OPS-METHOD-PROD-J01** | Liam + Ethan | P0 | New-pack onboarding runbook (generalize RYB-ED01 history) |
| **OPS-METHOD-PROD-J02** | Ethan | P0 | Ratify: is the SIPOC-lens pattern generalizable to other methods? |
| **OPS-METHOD-PROD-J03** | Colombo | P2 | Cross-pack vocab linking execution — **HOLD until real 2nd book product-intake authorized** |
| **OPS-METHOD-PROD-K01** | Grace | P1 | Bring `ARTIFACT-INDEX.md` current |
| **OPS-METHOD-PROD-K02** | Grace | P1 | Decide index-staleness enforcement mechanism |
| **OPS-METHOD-PROD-L01** | Olivia | P1 | Audit `agv_api.py` vs. real agent needs |
| **OPS-METHOD-PROD-L02** | Felix | P1 | Decide/build MCP packaging for mesh + API surface |
| **OPS-METHOD-PROD-L03** | Ava | P1 | Smoke any new MCP surface |
| **OPS-METHOD-PROD-99** | Ethan | P0 | Sign PRODUCTIZE-READY when G/H/I/J/K/L exit criteria met |

## Sequencing

G and H run first (P0, define the entrypoint and the report other work will be judged against). I and K proceed in parallel. J depends on G (onboarding runbook references the CLI). L depends on H (agent surface should expose the outcomes report too).

SIGNED: Triage (Grace) | PRODUCTIZE wave | 2026-07-22
