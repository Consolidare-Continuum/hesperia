# Grace triage — CC branding & site visual SOT

**Date:** 2026-07-28  
**Invoker:** Operator → Grace  
**Repo (Lane B):** https://github.com/Consolidare-Continuum/CC_brading_and_site  
**Policy:** [governance/ETHAN-POLICY-CC-BRANDING-AND-SITE.md](../../governance/ETHAN-POLICY-CC-BRANDING-AND-SITE.md)

## Operator directive (verbatim sense)

All **visual decisions** for CONSOLIDARE CONTINUUM are made in **`Consolidare-Continuum/CC_brading_and_site`** and left there. **Brand-related images** live in that repo.

## Triage outcome

**PROJECT-CREATED** — wave **CC_-BRAND-00..05**.

| ID | Owner | Intent |
|----|-------|--------|
| **CC_-BRAND-00** | Grace | Triage + lock visual SOT policy + brain pointers |
| **CC_-BRAND-01** | Grace | Bootstrap empty repo (README + `brand/` layout); local clone under `/data/consolidare-continuum/` |
| **CC_-BRAND-02** | Abelard | Deploy key / agent org access for this repo (one key ↔ one repo); clone sync if needed |
| **CC_-BRAND-03** | Grace | Standing keeper — visual decisions + brand images stay in `CC_brading_and_site`; sync pointers after major brand drops |
| **CC_-BRAND-04** | Abelard | Wire site deploy path: approved brand assets from branding repo → live `consolidare-continuum.com` docroot (no inventing brand art in brain deploy tree) |
| **CC_-BRAND-05** | Ethan | Optional ratify of branding policy into org policy § (if further amendment needed) |

## Boundaries

- **Lane B** only — no legal/bank dossier dump into this repo.
- Live site wiring remains Abelard (`cluster/consolidare-continuum.com/`); **source of visual truth** is the branding repo, not ad-hoc edits under brain `www-*` as permanent brand home.
- Repo name spelling **`CC_brading_and_site`** is as created on GitHub — do not rename without operator GO.

## SuiteCRM

All rows `SUITE: YES`.

SIGNED: Triage (Grace) | CC branding visual SOT | 2026-07-28 | CC_-BRAND
