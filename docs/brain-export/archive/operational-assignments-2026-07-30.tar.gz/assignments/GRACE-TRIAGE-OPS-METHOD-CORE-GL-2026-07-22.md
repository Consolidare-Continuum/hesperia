# Grace triage — ops-method CORE G–L wave

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method  
**Source:** [ETHAN-PLAN-CORE-GL-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-CORE-GL-2026-07-22.md)  
**Prior:** A–F DONE · freeze LIFTED.

## Rows → active.md

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-CORE-G00** | Grace | P0 | Triage G–L + SuiteCRM sync |
| **OPS-METHOD-CORE-G01** | Ethan | P0 | Ratify pipeline stage order + resume |
| **OPS-METHOD-CORE-G02** | Felix | P0 | `ops_method_cli.py` entry + stages |
| **OPS-METHOD-CORE-G03** | Ava | P0 | Smoke CLI status/dry-run |
| **OPS-METHOD-CORE-H01** | Ethan | P0 | Ratify outcomes report sections |
| **OPS-METHOD-CORE-H02** | Felix | P0 | Unified outcomes report command |
| **OPS-METHOD-CORE-H03** | Ava | P0 | Smoke report all sections |
| **OPS-METHOD-CORE-I01** | Felix | P0 | DSN via env / shared env module |
| **OPS-METHOD-CORE-I02** | Abelard | P0 | systemd user unit for agv_api |
| **OPS-METHOD-CORE-I03** | Ava | P0 | Smoke health + DSN override |
| **OPS-METHOD-CORE-J01** | Ethan | P1 | Ratify SIPOC-lens reuse vs SIPOC-specific |
| **OPS-METHOD-CORE-J02** | Liam | P1 | New-book onboarding runbook |
| **OPS-METHOD-CORE-J03** | Grace | P1 | README/index pointer for onboarding |
| **OPS-METHOD-CORE-K01** | Grace | P1 | Rebuild ARTIFACT-INDEX |
| **OPS-METHOD-CORE-K02** | Felix | P1 | `check_artifact_index.py` enforcement |
| **OPS-METHOD-CORE-K03** | Ava | P1 | Smoke index check green |
| **OPS-METHOD-CORE-L01** | Ethan | P1 | Ratify CLI-first vs MCP graduate |
| **OPS-METHOD-CORE-L02** | Felix | P1 | Implement per L01 |
| **OPS-METHOD-CORE-L03** | Ava | P1 | Smoke agent surface |

SIGNED: Triage (Grace) | CORE G–L wave | 2026-07-22
