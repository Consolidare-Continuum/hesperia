# Grace triage — P0 SRC-RYB-ORDER (Kak navesti poryadok) onto ED01 core

**Triage owner:** Grace · **Date:** 2026-07-24 · **Project:** ops-method  
**Trigger:** Operator — `proceed P0` (product intake). Unlocks DAY4-02 HOLD.  
**Advise:** [COLOMBO-ADVISE-SIX-BOOK-FIT-ONTO-CORE-2026-07-24.md](../../projects/ops-method/COLOMBO-ADVISE-SIX-BOOK-FIT-ONTO-CORE-2026-07-24.md)  
**Title named:** Рыбаков М. — *Порядок в бизнесе. Как навести порядок…* (series book **#3**)  
**Pack ID:** `SRC-RYB-ORDER` · **Author:** `AUTH-RYBAKOV` · **Onto-core:** `SRC-RYB-ED01`

## Product-intake note (operator)

First real second pack into PG = **#3 Как навести порядок** — not Strategy, not Payivina, not Smart Reading. Sequence thereafter remains ORDER → STRAT → DIGEST → PAY-LIVE per Colombo advise.

## Rows

| ID | Owner | Status | Deliverable |
|----|-------|--------|-------------|
| **OPS-METHOD-DAY4-02** | Grace | → DONE | SOURCE-PACK register ORDER |
| **OPS-METHOD-P0-01** | Felix | OPEN | Segment PDF → `source_*` for SRC-RYB-ORDER (all pages) |
| **OPS-METHOD-P0-02** | Felix | OPEN | OpenAI extract → statements/steps (ORDER); inline CORE-M/N |
| **OPS-METHOD-P0-03** | Felix | OPEN | Cross-pack grind ORDER ↔ ED01 (pgvector + typed proposals) |
| **OPS-METHOD-DAY4-07a** | Ava | → OPEN | Smoke small real sample via DAY4 API on ORDER |
| **OPS-METHOD-DAY4-06** | Colombo | → OPEN | RU review of ORDER↔ED01 cross-pack proposals |
| **OPS-METHOD-P0-04** | Ethan | OPEN | Sign P0 ORDER-onto-core READY (partial; not full series) |

SIGNED: Triage (Grace) | P0 SRC-RYB-ORDER intake | 2026-07-24 | ops-method
