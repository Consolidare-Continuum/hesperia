# Gena trace — agent Telegram (n8n) + Tersagor bot-IRC OpenAI ignore

**Date:** 2026-07-17  
**Session:** Cursor chat (Ethan → CSP Gena)  
**Hosts:** `execution_host=altitudine` · live deploy `tersagor` (jump alunel)

---

## What shipped

### A) Brain — permanent agent → phone Telegram

| Artifact | Role |
|----------|------|
| `scripts/agent-telegram.sh` | **Only** agent entry |
| `scripts/agent-telegram-send.py` | Telegram sender (chunk + retry) |
| `scripts/agent-irc-retrieve.py` / `agent-irc-sync.sh` | IRC JSONL → phone export |
| `scripts/deploy-n8n-agent-telegram.sh` | Deploy helper |
| `cluster/prichindel/n8n/AGENT-TELEGRAM.md` | Operator/agent doc |
| `cluster/prichindel/n8n/agent-telegram.workflow.json` | n8n export |
| `.cursor/rules/cursor-agent-telegram-n8n.mdc` | alwaysApply wiring |
| `scripts/runbooks/SCRIPT-RUNBOOK-agent-telegram.md` | Mandatory runbook |
| AGENTS / CLAUDE / Aegle / Aurel / Abelard quick ops / ETHAN-TARGETED | Awareness |

**Command:** `bash scripts/agent-telegram.sh "msg"` · `olga` · `both` · `--irc` · `--verify`

### B) Tersagor — bot IRC audit ≠ OpenAI SDK request

| Artifact | Role |
|----------|------|
| `operational/external/tersagor/src/imirc_gateway/forwarder.py` | `_should_skip_openai_ingress` (brain mirror) |
| `cluster/trustmaster/imirc-gateway/forwarder.py` | Stale-path mirror |
| Live `tersagor:~/imirc-gateway/forwarder.py` + `~/.config/imirc-gateway.env` | Deployed + restarted |
| GitHub **igareosh/tersagor** addon | `cdad34b` — same forwarder + test + docs |

**Ignore:** bot nicks (`abelard`, `web_operator`, …) · channels `#operator-notify`,`#agents-debug` · origins `web`,`prometheus`,`agent-telegram`,`agent-irc`.

Human `#agents-ingest` `!agent` still passes.

---

## Chat transcript pointer

Agent transcript: `86cbce1d-a6d5-488c-b1f7-8b7de1694f08` (Cursor agent-transcripts).

---

## Grace task (document throughout)

See: [GRACE-TRIAGE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md](GRACE-TRIAGE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md) · inbox entry 2026-07-17.

SIGNED: Developer (Gena) | agent-telegram + IRC OpenAI ignore | 2026-07-17 | trace
