# Grace triage — ops-method Day 4 book-ingestion wave

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01 + next Rybakov pack
**Trigger:** Operator — "Plan day 4 book ingestion branching and context of ball enhancement via api." Fulfills the Day 4+ item parked in [ETHAN-PLAN-DAY2-DAY3-2026-07-18.md](../../projects/ops-method/ETHAN-PLAN-DAY2-DAY3-2026-07-18.md) §5: "Unfreeze path for 5 further Rybakov packs."
**Source:** [ETHAN-PLAN-DAY4-BOOK-INGESTION-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-DAY4-BOOK-INGESTION-2026-07-22.md)
**FREEZE:** LIFTED for CORE/pipeline-capability work. **DAY4-02 (real second-book content registration) stays HOLD** until an explicit operator/Grace product-intake note names which of the 5 remaining Rybakov titles is next — same carve-out discipline as CORE-F02/F04, not a blanket reopen.

## Rows added → active.md (expanded to 15 on operator request — "light up the day")

| ID | Owner | P | Status | Deliverable |
|----|-------|---|--------|-------------|
| **OPS-METHOD-DAY4-00** | Grace | P0 | DONE | Triage Day 4 wave (this file) |
| **OPS-METHOD-DAY4-01** | Ethan | P0 | OPEN | Ratify pack-id/author convention; operator picks next title |
| **OPS-METHOD-DAY4-02** | Grace | P1 | PAUSED | Register `SOURCE-PACK-RYBAKOV-ED0?.md` — **HOLD, gated on product-intake note** |
| **OPS-METHOD-DAY4-03a** | Felix | P1 | OPEN | Generalize source_sentence/statement addressing for multi-pack |
| **OPS-METHOD-DAY4-03b** | Felix | P1 | OPEN | Ingestion API endpoint — accept fed text/page, assign addressing |
| **OPS-METHOD-DAY4-03c** | Felix | P1 | OPEN | Ingestion API — route into statement/canonical_step |
| **OPS-METHOD-DAY4-04a** | Felix | P1 | OPEN | Wire CORE-M contradiction check inline at insert time |
| **OPS-METHOD-DAY4-04b** | Felix | P1 | OPEN | Wire CORE-N rhetorical_kind detector inline at insert time |
| **OPS-METHOD-DAY4-05a** | Felix | P1 | OPEN | pgvector similarity candidates, new-pack vs. existing-pack |
| **OPS-METHOD-DAY4-05b** | Felix | P1 | OPEN | Typed cross-pack edge proposer (CORE-F01 vocab) |
| **OPS-METHOD-DAY4-06** | Colombo | P1 | OPEN | RU-semantics review of cross-pack proposals |
| **OPS-METHOD-DAY4-07a** | Ava | P1 | OPEN | Smoke: small real sample end-to-end via new API |
| **OPS-METHOD-DAY4-07b** | Ava | P1 | OPEN | Regression: SRC-RYB-ED01 dogfooding traversal still clean |
| **OPS-METHOD-DAY4-09** | Liam | P2 | OPEN | Runbook for the new ingestion API |
| **OPS-METHOD-DAY4-08** | Ethan | P1 | OPEN | Sign Day 4 ingestion pipeline READY |

## Sequencing

DAY4-01 first (needs operator's title pick). DAY4-03a/b/c and DAY4-04a/b (API + inline precision, generalized addressing) can build in parallel now, no dependency on which title. DAY4-02 gates DAY4-05a/05b/06/07a (need real or sample content to grind/review/smoke against). DAY4-07b has no dependency — runs against the existing pack immediately, as a standing regression check. DAY4-09 can start once 03b's endpoint shape is fixed. DAY4-08 last.

SIGNED: Triage (Grace) | Day 4 book ingestion | 2026-07-22
