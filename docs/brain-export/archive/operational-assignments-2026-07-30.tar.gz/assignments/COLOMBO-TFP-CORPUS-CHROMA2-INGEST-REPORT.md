# Colombo — Hesperia TFP corpus → CHROMA-2 (science-ready)

**Date:** 2026-06-20  
**Entity:** Colombo (Employ 4)  
**Session:** execution_host=altitudine, dev_office=true, connectivity=lan  
**Status:** **COMPLETE (operator 2026-06-23)** — tag-pass DONE 2026-06-21; TFP pack **137/137** in CHROMA-2 verified. Bulk ingest closed: [governance/TOMBSTONE-PAPRA-OCR-REQ-INGEST-DEAD-END.md](../../governance/TOMBSTONE-PAPRA-OCR-REQ-INGEST-DEAD-END.md) (`OCR_req` gap = dead end, not backlog).

**Fix applied:** Papra false-409 on python-docx `.docx` → ingest uses staged `.md`; `tag-pass` alias added; hash-dedup links original packs to normalized uploads.

---

## Result (2026-06-21 tag-pass)

| Step | Outcome |
|------|---------|
| MD re-upload | 134 new + 3 pilot + 137 hash-deduped (original packs) |
| Manifest doc_ids | 274/274 valid in Papra SQLite |
| tag-pass | 274 tagged, overlay updated, reindex queued |
| Unique content | 137 hashes (original ≡ normalized per file) |
| papra-ingest | Running — ~6/137 TFP unique indexed at 11:08 UTC; LibreOffice path for `text/markdown` |

**Log:** `/data/docker/papra/ingest/tfp_corpus_reingest_20260621_110044.log`

---

## Result (2026-06-20)

| Pack | Variant | Prepared | Papra upload | Catalog overlay |
|------|---------|----------|--------------|-----------------|
| ru_2_cleaned | normalized RU | 94 | ✅ | ✅ |
| en_2_cleaned | normalized EN | 43 | ✅ | ✅ |
| original_ru | original RU | 94 | ✅ | ✅ |
| original_en | original EN | 43 | ✅ | ✅ |
| **Total** | | **274** | **274** | **274** |

**Source files on prichindel: read-only** (scp fetch only; no renormalization or edits to Hesperia corpus).

**Tags per doc:** `TFP`, `psychology`, + 2 general (in `operator_tags` + `topics`).

**Papra names:** `{LANG} - {Creator} - {Title} [TFP normalized|original].docx`

**Script:** `prepare` → `ingest` → `tag` — [scripts/colombo-tfp-corpus-chroma2-batch.py](../../scripts/colombo-tfp-corpus-chroma2-batch.py)

**Manifest:** `/data/docker/papra/ingest/tfp_corpus_staging/manifest.json` on librarymaster

**Infra note:** Papra container DB bind mount out of sync with host SQLite — catalog via `papra_doc_meta.json` overlay + `queue_reingest`; Papra UI tag rows need Abelard mount fix.

| Corpus pack | Variant | Lang | Path on prichindel prod | Files (.md) |
|-------------|---------|------|-------------------------|-------------|
| **ru_2_cleaned** | normalized | RU | `hesperia/modules/tfp/data/corpus/ru_2_cleaned/` | 94 |
| **en_2_cleaned** | normalized | EN | `hesperia/modules/tfp/data/corpus/en_2_cleaned/` | 43 |
| **original_ru** | original | RU | `hesperia/modules/tfp/data/tfp_v1/corpus/original/ru/` | 94 |
| **original_en** | original | EN | `hesperia/modules/tfp/data/tfp_v1/corpus/original/en/` | 43 |
| **Total** | | | | **274** |

**CHROMA-1 (team brain):** layer `tfp_corpus_ru` — **ru_2_cleaned only**, ~15k chunks (Abelard ingest 2026-04-07). Spec: [governance/SPEC-ETHAN-TFP-CORPUS-RU-CHROMA-INGEST.md](../../governance/SPEC-ETHAN-TFP-CORPUS-RU-CHROMA-INGEST.md).

**CHROMA-2 (Papra library):** before this run, **no TFP-tagged Hesperia corpus** — COBALT blocker noted in [governance/SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md](../../governance/SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md).

---

## LOCATE — dual-store policy

| Store | Role for Colombo |
|-------|------------------|
| **CHROMA-1** `tfp_corpus_ru` | Team/agent `query_knowledge` — fast RU normalized retrieval |
| **CHROMA-2** `documents` | **Operator library + COBALT future** — full Papra names, tags, psychology theme, original **and** normalized |

Hesperia runtime via CHROMA-2 = **future** (COBALT module, `HESPERIA_COBALT_ENABLED`) — achievable when branch ships; corpus attribution must precede module value.

---

## Arrange — Papra naming convention

Pattern applied:

```text
{LANG} - {Creator} - {Title} [TFP {normalized|original}].docx
```

Examples (pilot, corrected Title–Author parse):

- `RU - Doering - Eroctic transference RUS [TFP normalized].docx`
- `RU - Doering ПЕРЕВОД - Implicit communication [TFP normalized].docx`

Source `.md` fetched from prichindel via SSH; staged under `/data/docker/papra/ingest/tfp_corpus_staging/{pack_id}/`.

---

## Tags and catalog (per document)

**Mandatory Papra tags (all docs):**

- `TFP`
- `psychology`

**Plus 2 general tags** (keyword-heuristic or stable pool): e.g. `clinical`, `psychoanalysis`, `transference`, `psychodynamics`, `object-relations`, `personality-disorder`.

**CHROMA-2 schema v1 facets** (`set_document_catalog`):

| Field | Value |
|-------|--------|
| theme | `psychology` |
| library_layer | `document` |
| facet_form | `monograph` |
| topics | pipe-separated tags |
| concepts | `hesperia_tfp\|{pack_id}\|corpus_{variant}` |

---

## Ingest execution

**Script:** [scripts/colombo-tfp-corpus-chroma2-batch.py](../../scripts/colombo-tfp-corpus-chroma2-batch.py)

| Step | Command (librarymaster) |
|------|---------------------------|
| Manifest | `… --manifest` |
| Pilot | `… --run --limit 3 --no-wait-chroma` → **3/3 ok** |
| Full batch | `nohup … --run --no-wait-chroma` → log: `/data/docker/papra/ingest/tfp_corpus_batch.log` |
| Post tag pass | `… --tag-pass` (after Papra DB visible) |

Machine report JSON: `operational/assignments/COLOMBO-TFP-CORPUS-CHROMA2-INGEST-REPORT.json` (on librarymaster brain clone + altitudine after sync).

**MCP verify (after papra-ingest indexes chunks):**

- `query_colombo_library` — `TFP transference Doering`
- `browse_colombo_library_facets` — theme `psychology`, tags `TFP`

---

## Science-ready use (Colombo)

1. **Research queries** → `query_colombo_library` with TFP/clinical terms; filter `theme=psychology` when MCP extended.
2. **Original vs normalized** → `concepts` contains `ru_2_cleaned` / `original_ru` / `en_2_cleaned` / `original_en`.
3. **Cross-check CHROMA-1** → `query_knowledge` `layer=tfp_corpus_ru` for team-brain parity on RU normalized.
4. **Citations** → `Papra/CHROMA-2 · doc_name=… · doc_id=… · query=… · date`

---

## NEXT (Colombo)

1. [x] Confirm full batch completion — 274 manifest doc_ids valid — **2026-06-21**
2. [x] Run `--tag-pass` / `tag-pass` — 274 tagged + reindex queued — **2026-06-21**
3. [x] Smoke `query_colombo_library` TFP hits — **2026-06-23** (137 unique psychology docs; guarded retrieval)
4. [ ] Grace triage row for COBALT corpus attribution closure (optional SUITE) — owner: **Grace**
5. [ ] Ethan ratify CHROMA-2 TFP pack as COBALT corpus source in branch spec — owner: **Ethan**

**Verified exists:** prichindel prod TFP paths; CHROMA-1 `tfp_corpus_ru`; Papra ingest pipeline; **137/137 TFP unique in CHROMA-2** (54,253 chunks, all `TFP` in topics).  
**Ingest tombstone:** `OCR_req` / `docs_indexed` gap — [TOMBSTONE-PAPRA-OCR-REQ-INGEST-DEAD-END.md](../../governance/TOMBSTONE-PAPRA-OCR-REQ-INGEST-DEAD-END.md). **Still open:** COBALT runtime hook only.

---

SIGNED: Research (Colombo) | TFP corpus CHROMA-2 ingest | 2026-06-20 | Hesperia library science pack
