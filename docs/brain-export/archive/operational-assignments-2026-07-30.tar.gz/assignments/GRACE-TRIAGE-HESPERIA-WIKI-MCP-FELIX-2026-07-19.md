# Grace triage — Felix MCP coding for Hesperia wiki science (agents)

**Date:** 2026-07-19  
**CSP:** From Cursor Context → To Grace Context | Reason: operator — task Felix 3–5 coding jobs for MCPs + wiki science integration for agents  
**Parent wave:** [GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md](GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md)

## Intent

Agents must not only *know the wiki exists* — they need **MCP-callable** wiki science (status, formula, module, relations) and light **code↔wiki** tooling so documentation grind and runtime agent context share one path.

## Rows (Felix — coding)

| ID | Task | Done when |
|----|------|-----------|
| **HWIKI-MCP-01** | Extend `agent_mcp_knowledge` (or thin sibling MCP) with `query_hesperia_wiki` + `get_hesperia_wiki_page` — structured fields: status, module, formula, produced_from/needed_by, source path, LAN URL | Tools live in MCP; smoke from Cursor/Claude config |
| **HWIKI-MCP-02** | Wire `layer=hesperia_wiki` into `cursor-context-rag` / `context_rag.py` optional retrieval when query looks like symbol/science (flag or auto) | Packet schema + MCP returns wiki chunks; schema doc updated |
| **HWIKI-MCP-03** | Deploy: `governance/mcp-config.json` + Claude/Copilot mirrors; `deploy-mcp-config-global` path; verify tools listed | Config committed; verify script or smoke note |
| **HWIKI-MCP-04** | Code↔wiki linker CLI under `colombo_research/hesperia/wiki/tools/` — input symbol → defs/usages in `/data/hesperia/hesperia` or atomic-commit tree → JSON/markdown fields for generator `add(...)` | Script runnable; feeds HWIKI-CODE-01 / Colombo pages |
| **HWIKI-MCP-05** | Agent science citation helper — format wiki MCP hits as a fixed **Science (wiki)** block (status · module · why · link) for agent/runbook response_contract | Doc + small Python helper; optional MCP tool `format_hesperia_wiki_science` |

**Out of scope here:** Colombo content authorship; Abelard systemd (already live); dumping 200 wiki pages.

**Handoff:** Colombo consumes linker output; Cursor keeps HWIKI-03 re-ingest after material regen.

SIGNED: Triage (Grace) | Felix HWIKI-MCP coding slice | 2026-07-19 | HWIKI-MCP
