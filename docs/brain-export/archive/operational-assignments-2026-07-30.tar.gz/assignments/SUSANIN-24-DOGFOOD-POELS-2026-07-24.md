# SUSANIN-24 dogfood — Poels process-map claim

**Theme:** `business` · **Map:** `susanin_ops`  
**CHROMA-1 evidence:** `query_knowledge(layer=books)` → Poels et al. 2019 citing Malinova & Mendling — *Why is BPMN not Appropriate for Process Maps?*

## PARSE
Candidate process: **org-wide process-map design** (not a single workflow diagram).

## FORMALIZE
| Claim | Evidence | Status |
|-------|----------|--------|
| BPMN is not ontologically expressive enough for process maps | Poels § citing Malinova/Mendling 2015a; CHROMA-1 books hit | Verified |
| Dedicated process-map meta-model / ADL needed | Poels meta-model design | Verified (paper claim) |
| BPMN remains for detailed process workflows | IDEF-DESIGN-CAPACITY core set | Guidance |

## SCHEME (A)
As-is: treat BPMN diagrams as detail views. To-be: process map as architecture artefact (Poels) + BPMN for leaf detail.

## NEXT
1. Borrowers use `susanin_ops` + theme=`business` for landscape modeling.  
2. Optional B: tooling → Felix (not this dogfood).

SIGNED: Research (Colombo) / Cursor | SUSANIN-24 dogfood | 2026-07-24
