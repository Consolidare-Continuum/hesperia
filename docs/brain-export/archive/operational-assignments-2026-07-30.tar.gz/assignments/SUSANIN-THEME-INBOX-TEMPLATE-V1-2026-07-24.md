# Grace — new Susanin theme inbox template

When operator requests a new Susanin theme:

1. Inbox entry: theme id + corpus paths.  
2. Triage → active.md row(s) owner **Colombo** (intake) + Abelard if CHROMA-1 mass.  
3. Run `SCRIPT-RUNBOOK-susanin-theme-intake`.  
4. Update [susanin-themes.md](../../agents/colombo/susanin-themes.md) Status=LIVE.  
5. Do **not** invent BPM automation rows.

SIGNED: Triage (Grace) | Susanin theme template v1 | 2026-07-24
