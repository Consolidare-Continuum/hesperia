# Grace triage — AGV wave (30): agentic traversal + action steps + D3/Cursor viz

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01  
**Trigger:** Operator — (1) 30 tasks make map DB agentics operational for traversal points + action steps; (2) Ethan D3 entire-map viz, real-time traversal, Cursor call button for live ops.  
**Plan:** [ETHAN-PLAN-AGV-D3-CURSOR-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-AGV-D3-CURSOR-2026-07-22.md)  
**Freeze:** HOLD — no second book · MAP-05/CORP-04/05/CSS-13 stay PAUSED  

## Rows → active.md (exactly 30)

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-AGV-00** | Grace | P0 | Triage this wave (30) + SuiteCRM sync |
| **OPS-METHOD-AGV-01** | Ethan | P0 | Ratify AGV+D3+Cursor-call plan |
| **OPS-METHOD-AGV-02** | Ethan | P0 | Contract: traversal_point / action_step / ops_event shapes |
| **OPS-METHOD-AGV-03** | Felix | P0 | Schema 008: traversal_point (+ view over STEPs) |
| **OPS-METHOD-AGV-04** | Felix | P0 | Schema 008: action_step (STEP↔statement_action/catalog) |
| **OPS-METHOD-AGV-05** | Felix | P0 | Materialize traversal_points for all active STEPs |
| **OPS-METHOD-AGV-06** | Felix | P1 | Materialize action_steps from statement_action (thin→grow later) |
| **OPS-METHOD-AGV-07** | Felix | P0 | API: `GET /steps` locate + filter (chapter/q) |
| **OPS-METHOD-AGV-08** | Felix | P0 | API: `GET /steps/{id}/next` typed next |
| **OPS-METHOD-AGV-09** | Felix | P0 | API: `GET /steps/{id}/actions` list action steps |
| **OPS-METHOD-AGV-10** | Felix | P0 | API: `POST /traverse` N-hop path + envelopes |
| **OPS-METHOD-AGV-11** | Felix | P0 | API: `POST /todos` propose_todo + evidence |
| **OPS-METHOD-AGV-12** | Felix | P0 | API: `GET /ops/tail` SSE stream of json_envelope verbs |
| **OPS-METHOD-AGV-13** | Noah | P1 | Thinking-map: bind traverse/list_actions/emit_todo gates |
| **OPS-METHOD-AGV-14** | Colombo | P1 | Action-step RU labels policy (catalog sense / EN ids) |
| **OPS-METHOD-AGV-15** | Felix | P1 | CLI parity: extend css_agent_cli with list_actions + traverse |
| **OPS-METHOD-AGV-16** | Liam | P1 | SCRIPT-RUNBOOK ops-method-agv-session (API+CLI) |
| **OPS-METHOD-AGV-17** | Ethan | P0 | D3 viz design lock — layout, LOD, colors, terminal mark |
| **OPS-METHOD-AGV-18** | Felix | P0 | Graph export JSON: nodes+links for D3 (chapter LOD) |
| **OPS-METHOD-AGV-19** | Gena | P0 | D3 page: force/cluster layout, zoom/pan, chapter filter |
| **OPS-METHOD-AGV-20** | Gena | P0 | D3: real-time traversal highlight via SSE ops/path |
| **OPS-METHOD-AGV-21** | Gena | P0 | UI: **Cursor call** button → POST /traverse session |
| **OPS-METHOD-AGV-22** | Gena | P0 | UI: ops side panel — live verbs/results Cursor invoked |
| **OPS-METHOD-AGV-23** | Felix | P1 | Wire Cursor call to real css verbs (no mock) |
| **OPS-METHOD-AGV-24** | Abelard | P1 | Serve AGV UI+API on altitudine localhost only (systemd/nginx local) |
| **OPS-METHOD-AGV-25** | Ava | P0 | Smoke API: locate→next→actions→traverse≥2 hops |
| **OPS-METHOD-AGV-26** | Ava | P0 | Smoke UI: map loads + Cursor call shows ≥3 ops |
| **OPS-METHOD-AGV-27** | Daniel | P1 | Security bar: bind 127.0.0.1; no public expose; no secrets in UI |
| **OPS-METHOD-AGV-28** | Olivia | P1 | Inspect requirements: search traversal points + action steps |
| **OPS-METHOD-AGV-29** | Ethan | P0 | Sign **AGV-READY** — agentic traverse + D3 Cursor-call GREEN |

## Sequencing

AGV-00→01→02 → (03∥04)→05→06 → 07..12 → 13..16 → 17→18→19..22 → 23→24 → 25∥26 → 27∥28 → 29.

## SuiteCRM

`SUITE: YES` on task/spec; AGV-00 `SUITE: NO`. Sync on triage.

SIGNED: Triage (Grace) | AGV 30-task wave | 2026-07-22 | traverse · actions · D3 · Cursor call
