# Grace triage — HATCHET IT TRAIN: moons edge ≥70%

**Date:** 2026-07-28 · **Owner:** Grace  
**Trigger:** Operator — «we continue full IT train on it» (70% edge bar)  
**Mode:** **HATCHET ON** · lab only · no OpenAI invent

## Rows

| ID | Owner | Task |
|----|-------|------|
| **OPS-METHOD-HATCHET-00** | Grace | This triage |
| **OPS-METHOD-HATCHET-01** | Felix | Pending logical mass sort (requires/precedes/supports) — mind gates |
| **OPS-METHOD-HATCHET-02** | Felix | Page±5 attach + hatchet page-chain template edges + re-attach → **≥70%** |
| **OPS-METHOD-HATCHET-03** | Ava | Smoke edge rate + `/tasks` relations sample |
| **OPS-METHOD-HATCHET-04** | Ethan | Sign **HATCHET-EDGE-70-READY** |

SIGNED: Triage (Grace) | HATCHET IT train edge 70 | 2026-07-28 | ops-method
