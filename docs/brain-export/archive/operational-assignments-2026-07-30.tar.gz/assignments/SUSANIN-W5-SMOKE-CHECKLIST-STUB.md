# SUSANIN W5 smoke checklist (stub)

**Wave:** SUSANIN-09 · Full QA = SUSANIN-53 (W5)

- [ ] `list_thinking_maps` includes `susanin_ops`
- [ ] Happy path CONTINUE with theme=business evidence
- [ ] Theme gate COLLECT_EVIDENCE without `theme_corpus_ready`
- [ ] HANDOFF_EXECUTE escalate without Clearance
- [ ] CHROMA-1 `query_knowledge` hits `theme=business` BPM books
- [ ] CHROMA-2 query by `doc_id` for §2l titles
- [ ] Runbook `SCRIPT-RUNBOOK-susanin-mode` readable via get_runbook

SIGNED: QA (Ava) / Cursor | smoke stub | 2026-07-24
