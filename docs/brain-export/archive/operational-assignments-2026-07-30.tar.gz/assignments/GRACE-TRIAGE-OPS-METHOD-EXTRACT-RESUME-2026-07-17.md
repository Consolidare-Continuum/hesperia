# Grace triage — ops-method extract resume → Cursor automation

**Date:** 2026-07-17  
**Trigger:** Operator leave-soon — Gena API grind must keep per-iteration state and be resume-safe under Cursor automation.  
**Freeze:** holds (no new packs)

## Rows

| ID | Owner | Task |
|----|-------|------|
| **OPS-METHOD-LTS-00** | Grace | Triage this packet (DONE when rows landed) |
| **OPS-METHOD-LTS-01** | Gena | Per-batch ledger + stable batch_id + checkpoint (code) |
| **OPS-METHOD-LTS-02** | Cursor | Run/resume full-book extract until eligible=0 via `scripts/ops-method-extract-resume-loop.sh` |

## Resume contract

1. State of truth = `ops_method.sentence_grind_ledger` (`extract` / `done|failed|running|skipped`)  
2. File mirror = `projects/ops-method/runtime/extract_checkpoint.json`  
3. Automation status = `projects/ops-method/runtime/extract_automation_status.json`  
4. Restart = same command; skips `done`; retries `failed` / stale `running`  

```bash
# from repo root on altitudine (ops-method-pg must be up)
bash scripts/ops-method-extract-resume-loop.sh
# optional: MAX_ROUNDS=5 MAX_BATCHES_PER_ROUND=20 bash scripts/ops-method-extract-resume-loop.sh
```

## Done when

- LTS-01: extract script has `--max-batches`, `--continue-on-fail`, stable batch ids, ledger running→done/failed  
- LTS-02: eligible unextracted sentences pp 21–393 = 0 (or PAUSED with checkpoint if max rounds — still resume-safe)

SIGNED: Triage (Grace) | extract resume automation | 2026-07-17 | ops-method
