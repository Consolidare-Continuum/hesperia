# Grace triage — CC_ legal-entity bootstrap (2026-07-15)

**Project shortcut:** `CC_`  
**Keeper:** Grace (triage + documentation / awareness — **not** bookkeeper, **not** librarian)  
**Hygiene tag:** security · integration (local-only legal docs)  
**Disclosure:** FORBIDDEN by default outside cluster + operator email. Full dossier **not** in this GitHub-tracked packet — lives in gitignored `CC_/` + MinIO.  
**CHROMA-1:** `CC_/` markdown → layer `project` / `project_name=CC_` via `scripts/ingest-cc-chroma1.sh` (binaries stay in MinIO; inventory in `CC_/AVAILABILITY.md`).

## Operator request (summary)

1. Treat **CC_** as a separate project (legal entity), not as current prichindel.com operations.
2. Glue today = the operator person; full operational transfer under the SRL = future.
3. Maintain awareness + arrange documents + SuiteCRM.
4. Store documents as **MinIO objects**, separate bucket, **no Papra**.
5. Awareness on brain disk; **not** for GitHub dump.
6. Romanian OK when `CC_` context is active.
7. Bank: request accepted / internal bank processing; credentials later — process what exists now.

## Where (cluster-local)

| What | Where |
|------|--------|
| Awareness + mirrors | repo path `CC_/` (**gitignored**) |
| Policy | `CC_/DISCLOSURE.md`, `CC_/RELATIONS.md` |
| Manifest | `CC_/DOCUMENTS-MANIFEST.md` |
| Objects | MinIO bucket `consolidare-continuum` prefix `legal/2026/` |
| Staging source | `.cache_to_sort_out/` (already gitignored) |

## Rows (active.md)

| ID | Owner | Intent | Status target |
|----|-------|--------|---------------|
| **CC_-00** | Grace | Triage bootstrap + SuiteCRM | DONE |
| **CC_-01** | Grace | Inventory + arrange docs + MinIO ingest (no Papra) | DONE |
| **CC_-02** | Grace | Bank credentials intake when operator receives them | PAUSED (wait bank) |
| **CC_-03** | Grace | Standing keeper: new CC_ docs → MinIO + manifest + CRM + Chroma re-ingest | OPEN standing |
| **CC_-04** | Grace | CHROMA-1 awareness ingest of `CC_/` markdown + AVAILABILITY | DONE |

## Do not

- Push `CC_/` or cache PDFs to GitHub.
- Put dossiers in Papra / CHROMA-2.
- Casual disclosure outside cluster/operator email.

## SuiteCRM

`SUITE: YES` on all CC_ rows. Sync after write.

SIGNED: Triage (Grace) | CC_ bootstrap | 2026-07-15 | secretary-legal-entity
