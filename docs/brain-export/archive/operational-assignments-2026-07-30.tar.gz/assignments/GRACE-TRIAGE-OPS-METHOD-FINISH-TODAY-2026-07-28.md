# Grace triage — ops-method FINISH today (post invent READY)

**Date:** 2026-07-28 · **Owner:** Grace  
**Trigger:** operator — *Grace triage to finish all above today*  
**Above (Ethan status):** densify · EX harvest expansion · N-hop QA · overlay invent  
**Upstream:** [BOOK1-DIGEST-INVENT-READY.md](../../projects/ops-method/BOOK1-DIGEST-INVENT-READY.md) · [PAY-TOM1-INVENT-READY.md](../../projects/ops-method/PAY-TOM1-INVENT-READY.md) · [GRIND-CORPUS-READY.md](../../projects/ops-method/GRIND-CORPUS-READY.md)

## Hold the line

- **#1–#6 invent extract stays CLOSED** — do not re-run OpenAI invent on DIGEST / STRAT / ORDER / ED01 / PAY-A / PAY.  
- **Overlay invent** (FTB / Poels / PLX) is a **new** invent scope — map/heuristic only until this wave; operator asked to finish today → invent API **reopened for overlays only**.

## Argue / Propose (locked into rows)

| Argue | Propose |
|-------|---------|
| ORDER emb **24.9%** / PAY **38.3%** / STRAT **43.8%** still thin for full-density mesh after invent | Densify floors then propose (FINISH-01) before overlay invent burn |
| Prior GRIND-03 overlay EX yielded 0 title EX | Expand EX on **invent-complete** PAY-A + densified triad; overlays after invent if text supports |
| Full invent on 3 overlays + densify same calendar day is heavy | Parallel tracks: **A** densify→review→EX→N-hop · **B** overlay invent→embed→review · Ethan one READY |

## Live floors (triage-time)

| Pack | stmts | emb % |
|------|------:|------:|
| ORDER | 5024 | 24.9 |
| STRAT | 2053 | 43.8 |
| PAY | 4430 | 38.3 |
| PAY-A | 3565 | 100 |
| ED01 | 5660 | 91.1 |
| FTB / Poels / PLX | full emb | invent = map only |

## Rows (same-day finish)

| ID | Owner | P | Task |
|----|-------|---|------|
| **OPS-METHOD-FINISH-00** | Grace | P0 | This triage |
| **OPS-METHOD-FINISH-01** | Felix | P0 | Densify ORDER/STRAT/PAY emb floors + full-density cross-pack propose (post-invent packs; sample caps OK) |
| **OPS-METHOD-FINISH-02** | Colombo | P0 | RU review pending families from FINISH-01 |
| **OPS-METHOD-FINISH-03** | Felix | P1 | EX harvest expansion — PAY-A + densified triad (+ overlays if invent B landed) |
| **OPS-METHOD-FINISH-04** | Ava | P0 | N-hop QA + ED01 regression smoke after densify/review |
| **OPS-METHOD-FINISH-05** | Felix | P0 | OpenAI invent overlays: FTB-GLOSS + Poels + PLX (replace map/heuristic; no STEP promote) |
| **OPS-METHOD-FINISH-06** | Felix | P0 | Embed + propose invent overlays → ED01/ORDER/STRAT |
| **OPS-METHOD-FINISH-07** | Colombo | P0 | RU review overlay invent edges |
| **OPS-METHOD-FINISH-08** | Ethan | P0 | Sign **FINISH-CORPUS-READY** (densify+EX+N-hop+overlay invent close) |

## Hygiene (same packet)

BOOK1/PAYTOM DONE rows currently sit **above** the `| Priority |` header (orphan) — `report_done` MCP cannot see them. FINISH-00 includes relocating those DONE orphan rows into the main table (no status change).

**Triage outcome:** PROJECT-CREATED — finish-today rows on active.md. Deadline: **2026-07-28**.

SIGNED: Triage (Grace) | FINISH densify·EX·N-hop·overlay invent today | 2026-07-28 | ops-method
