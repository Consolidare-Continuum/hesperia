# Grace triage — ops-method Day 7+ wave (remaining 4 books)

**Date:** 2026-07-27 · **Owner:** Grace  
**Trigger:** operator — "no firm planning on what's next"; adopt Grace, cover the remaining 4 books into the PG db  
**Upstream:** [P3-FOUR-PACK-READY.md](../../projects/ops-method/P3-FOUR-PACK-READY.md) (four-pack + digest live) · Colombo gate proposal (Days 7–10, R1 densify→glossary→Poels→formal→twin)

## Intake locked

Not-yet-live material in `colombo_research/business_process/`:

| # | File | Pack | Role |
|---|------|------|------|
| A | `FTB-BPM-CoE-Glossary-2009-10-26.pdf` (14pp) | `SRC-FTB-GLOSS` | lexicon overlay → ED01 |
| B | `Poels-etal-2019-Architecting-Business-Process-Maps.pdf` (25pp) | `SRC-POELS-MAPS` | map/chart theory overlay → ED01 (+ sparse ORDER/STRAT) |
| C | `Plexousakis-Koubarakis-BPM-formal-model-methodology.pdf` (21pp) | `SRC-PLX-FORMAL` | formal BPM model overlay → ED01 (+ formal "supports") |
| D | Payivina #5 (274pp twin) | `SRC-PAY-LIVE-A` | edition twin of `SRC-PAY-LIVE` (#6, 362pp, live) |

**Gate decision (operator, 2026-07-27):** all 4 are in scope — D is not dropped.

**Update 2026-07-27 (same day):** D's HOLD is resolved. The #5 twin PDF was never missing — it was sitting unstaged in `.cache_to_sort_out/` (never promoted per that cache's own "process then empty" policy, alongside 5 leftover duplicate copies of books 1/2/3/4/6 that had already been staged elsewhere — those duplicates were removed). Confirmed by SHA-256 + page count (274pp, distinct from #6's 362pp). Promoted to `colombo_research/business_process/5Payivina_O_Razvitie_Jivoy_Kompanii_274pp.a4.pdf`, registered as `SRC-PAY-LIVE-A` — see [SOURCE-PACK-PAYIVINA-LIVE-A.md](../../projects/ops-method/SOURCE-PACK-PAYIVINA-LIVE-A.md). `DAY10-00` DONE, `DAY10-01` unblocked (OPEN).

**Standing rule carried from R1/Colombo:** A–C are not peer STEP packs. No full OpenAI LTS invent-extract treatment (that's for Rybakov-grade method volumes). Retrieval map + sparse classify only, same pattern as the Day 6 digest. Colombo rejects any glossary/map/formal item proposed as a STEP duplicate.

## Wave shape

- **Day 7** — densify ORDER/PAY embeddings + second PAY→triad propose pass; register+map `SRC-FTB-GLOSS`.
- **Day 8** — `SRC-POELS-MAPS` overlay.
- **Day 9** — `SRC-PLX-FORMAL` overlay (+ EX fusion facet tie-in where formal "when" gates help).
- **Day 10** — twin gate: if #5 PDF has landed, sample twin edges (`equivalent`/`contradicts`) PAY-A↔PAY-LIVE; Ethan signs `SERIES-CORPUS-READY` either way (four method + digest + 3 theory overlays, twin included if staged in time).

## Rows

| ID | Owner | Status |
|----|-------|--------|
| DAY7-00 | Grace (this) | DONE |
| DAY7-01 | Felix — densify ORDER/PAY embeddings + 2nd PAY→triad propose | OPEN |
| DAY7-02 | Grace — register `SRC-FTB-GLOSS` (source intake doc) | OPEN |
| DAY7-03 | Felix — segment glossary; sparse map terms→ED01 (no invent extract) | OPEN |
| DAY7-04 | Colombo — RU review; reject glossary-as-STEP | OPEN |
| DAY7-05 | Ethan — sign `SRC-FTB-GLOSS` overlay READY | OPEN |
| DAY8-00 | Grace — register `SRC-POELS-MAPS` (source intake doc) | OPEN |
| DAY8-01 | Felix — segment + light extract/map Poels → ED01; sparse → ORDER/STRAT where when/what | OPEN |
| DAY8-02 | Colombo — RU review Poels edges | OPEN |
| DAY8-03 | Ava — smoke: map-concept → ED01 jump | OPEN |
| DAY8-04 | Ethan — sign `SRC-POELS-MAPS` overlay READY | OPEN |
| DAY9-00 | Grace — register `SRC-PLX-FORMAL` (source intake doc) | OPEN |
| DAY9-01 | Felix — segment + extract/map Plexousakis → ED01 (+ formal "supports" only) | OPEN |
| DAY9-02 | Felix — tie EX fusion facets where formal "when" gates help | OPEN |
| DAY9-03 | Colombo — RU review Plexousakis edges | OPEN |
| DAY9-04 | Ethan — sign `SRC-PLX-FORMAL` overlay READY | OPEN |
| DAY10-00 | Grace — gate check: is #5 (274pp) PDF staged in `colombo_research/business_process/`? | OPEN |
| DAY10-01 | Felix — if staged: segment + extract `SRC-PAY-LIVE-A`; sample twin edges vs `SRC-PAY-LIVE` | PAUSED (blocked on DAY10-00) |
| DAY10-02 | Colombo — RU review twin edges (`equivalent`/`contradicts` only, no duplicate STEPs) | PAUSED (blocked on DAY10-01) |
| DAY10-03 | Ethan — sign `SERIES-CORPUS-READY` (four method + digest + 3 overlays ± twin) | PAUSED (blocked on DAY9-04/DAY10-02) |

**Argue carried forward:** do not run full OpenAI LTS invent on FTB/Poels/Plexousakis as if peer method volumes — retrieval map + sparse classify only (Day 6 digest pattern).

SIGNED: Triage (Grace) | Day 7+ wave — remaining 4 books | 2026-07-27 | ops-method
