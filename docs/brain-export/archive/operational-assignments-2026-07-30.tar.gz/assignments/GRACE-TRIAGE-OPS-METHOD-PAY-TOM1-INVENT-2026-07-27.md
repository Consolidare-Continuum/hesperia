# Grace triage — Payivina ТОМ 1 full OpenAI invent

**Date:** 2026-07-27 · **Owner:** Grace  
**Trigger:** operator — Payivina pair is **ТОМ 1 / ТОМ 2** (parts), not “edition twins”; request full OpenAI invent on the volume still missing invent  
**Upstream:** SERIES-CORPUS-READY · SEE wave · operator clarification 2026-07-27

## Product correction (locked)

PDF cover pages (live check):

| PDF | Label on book | Pack | OpenAI invent today |
|-----|---------------|------|---------------------|
| `…(274pp).pdf` | **ТОМ 1** | `SRC-PAY-LIVE-A` | **Missing** (Day4 heuristic sample only, ~45 pages / 918 stmts) |
| `…(362pp).pdf` | **ТОМ 2** | `SRC-PAY-LIVE` | **DONE** (713 extract batches, validated) |

**Argue:** Do **not** re-run invent on ТОМ 2 — already complete.  
**Propose / intake:** Full OpenAI invent on **ТОМ 1** (`SRC-PAY-LIVE-A`, 274 pp) — the “other of the two” that never got `extract-pilot` batches. Retire the “edition twin / sample only” framing for invent scope; twin edges may remain as cross-volume links after invent.

## Wave shape

1. Relabel source intake + PG awareness (том 1 / том 2).  
2. Felix: replace heuristic sample product on `SRC-PAY-LIVE-A` with full OpenAI extract `--pack-id SRC-PAY-LIVE-A --page-start 1 --page-end 274` (same pattern as ТОМ 2 / STRAT).  
3. Embed + cross-pack propose ТОМ1 → triad (ED01/ORDER/STRAT); reconcile vs ТОМ2 edges.  
4. Colombo RU review · Ava smoke · Ethan READY.

## Rows

| ID | Owner | Task |
|----|-------|------|
| **OPS-METHOD-PAYTOM-00** | Grace | This triage |
| **OPS-METHOD-PAYTOM-01** | Grace | Relabel SOURCE-PACK docs + titles: 274=ТОМ1, 362=ТОМ2 |
| **OPS-METHOD-PAYTOM-02** | Felix | Full OpenAI invent `SRC-PAY-LIVE-A` pp 1–274 (clear heuristic sample product first) |
| **OPS-METHOD-PAYTOM-03** | Felix | Embed densify + propose PAY-A→ED01/ORDER/STRAT |
| **OPS-METHOD-PAYTOM-04** | Colombo | RU review new invent edges (reject STEP dup vs ТОМ2 where appropriate) |
| **OPS-METHOD-PAYTOM-05** | Ava | Smoke: ТОМ1 retrieval + one triad hop |
| **OPS-METHOD-PAYTOM-06** | Ethan | Sign **PAY-TOM1-INVENT-READY** |

**API runs remaining after this wave:** **0** (both Payivina volumes invent-complete).

SIGNED: Triage (Grace) | Payivina ТОМ1 full invent wave | 2026-07-27 | ops-method
