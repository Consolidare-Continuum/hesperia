# Grace triage — ops-method MIND drain (Ethan residual)

**Date:** 2026-07-28 · **Owner:** Grace  
**Trigger:** Operator AWP drain — Ethan's remaining counts (lab emb · edge-attach · classify)  
**Upstream:** Ethan count 2026-07-28 · MIND-OVER-SEMANTICS-READY · MIND-API-FLOW-READY

## Drain stack (no invent reopen)

| ID | Owner | Work | Est. API |
|----|-------|------|----------|
| **OPS-METHOD-MIND-DRAIN-00** | Grace | This triage | 0 |
| **OPS-METHOD-MIND-DRAIN-01** | Felix | Lab statement emb → 0 missing (~5259 @200) | ~27 embed |
| **OPS-METHOD-MIND-DRAIN-02** | Felix | SQL attach `edge_id` on `it_agentic_node` from approved logical edges | 0 OpenAI |
| **OPS-METHOD-MIND-DRAIN-03** | Felix | Prod classify remain page&lt;500 (PAY/overlays ~1872 @12) | ~156 classify |
| **OPS-METHOD-MIND-DRAIN-04** | Ava | Smoke lab emb 100% · edge attach rate · `/tasks/stats` · ED01 regression | 0 |
| **OPS-METHOD-MIND-DRAIN-05** | Ethan | Sign **MIND-DRAIN-READY** | 0 |

**Out of scope:** invent #1–#6 · cosine propose · design talk · EX-PAY-109 invent (optional follow-on).

SIGNED: Triage (Grace) | MIND drain Ethan residual | 2026-07-28 | ops-method
