# Grace triage — ops-method Day-3 "roll the ball" + Day-2 fixes

**Triage owner:** Grace · **Date:** 2026-07-21 · **Project:** ops-method · **Pack:** SRC-RYB-ED01
**Trigger:** Operator — "day 3 triage, include day2 fixes" after D2 build-the-ball complete.
**Source plan:** [ETHAN-PLAN-DAY2-DAY3-2026-07-18.md](../../projects/ops-method/ETHAN-PLAN-DAY2-DAY3-2026-07-18.md) §4 · debt [DAY2-MESH-DEBT.md](../../projects/ops-method/DAY2-MESH-DEBT.md)
**FREEZE:** intact — one book only; the 3 paused connector/new-org rows (MAP-05, CORP-04, CORP-05) stay PAUSED until MESH-READY + semantics sign.

## Entry state (D2 result, verified)

edges **3779** (22/27 types, all pending) · statements embedded **5158/5158** · dictionary activated (2149 keys, 11629 hits) · thinking-map slice self-test green · smoke traverse OK. Checkpoint `D2_ball_20260721T125717Z.dump`.

## Rows triaged → active.md

### Day-2 fixes (improve the ball before/while rolling)

| ID | Owner | Deliverable | P |
|----|-------|-------------|---|
| **OPS-METHOD-D2-FIX-01** | Felix | Backfill `evidence_sentence_ids` on API relation edges (rel_address/destination → statement.sentence_id); unblocks ADV-05 gate grouping. Debt #3. | P0 |
| **OPS-METHOD-D2-FIX-02** | Felix/Noah | Rebalance `requires`-heavy mesh (62%): review reject/relabel pass; promote thin tail (12 types ≤5). Debt #1–2. | P1 |
| **OPS-METHOD-D2-FIX-03** | Felix | Cross-chapter edges via embeddings near-dup (use 5158 vectors) — beyond local ≤3-page windows. Debt #4. | P1 |
| **OPS-METHOD-D2-FIX-04** | Colombo | Dictionary A4 — book-grounded `gloss_ru` (replace generic freq gloss); OpenAI. Debt #5. | P1 |
| **OPS-METHOD-D2-FIX-05** | Felix | Dedup duplicate semantic edges (same address+destination+type across windows). Debt #6. | P1 |

### Day-3 "roll the ball" wave

| ID | Owner | Deliverable | P |
|----|-------|-------------|---|
| **OPS-METHOD-D3-01** | Liam | SCRIPT-RUNBOOK `ops-method-mesh-session`: start → thinking_map_step → traverse → list_pending review → propose/refine → report. | P0 |
| **OPS-METHOD-D3-02** | Felix | Agent entry — MCP/CLI verbs `inspect_mesh` / `propose_relation` / `list_review` over JSON envelopes; wire D2-07 slice to live DB (folds debt #7). | P0 |
| **OPS-METHOD-D3-03** | Olivia | Human + agent inspect requirements — search by chapter / term / relation_type / compatibility over the mesh. | P1 |
| **OPS-METHOD-D3-04** | Cursor | Dry-run — Cursor + one other agent each complete one mesh refine cycle (accept ≥1, reject ≥1). | P0 |
| **OPS-METHOD-D3-05** | Ethan | Sign **MESH-READY** — informational system for this book operable; unlocks order-flow/visuals/product wave under new Grace triage. | P0 |

## Gates / sequencing

- D2-FIX-01 (evidence) should land before D3-04 dry-run so the review loop has real evidence hooks.
- D3-05 MESH-READY is the exit sign → only then does the "afterwards" wave (order flow, visuals, product, further Rybakov packs) become eligible, under a **new** Grace triage + freeze-exit.
- No new source packs, no new content domains (FREEZE).

## SuiteCRM

Rows carry `SUITE: YES` (tasks/specs). Sync on triage via `scripts/suitecrm_sync_on_triage.sh` / n8n `activemd-crm-sync` when reachable; SUITE NR backfilled after sync.

SIGNED: Triage (Grace) | ops-method Day-3 + Day-2 fixes | 2026-07-21 | ops-method SRC-RYB-ED01
