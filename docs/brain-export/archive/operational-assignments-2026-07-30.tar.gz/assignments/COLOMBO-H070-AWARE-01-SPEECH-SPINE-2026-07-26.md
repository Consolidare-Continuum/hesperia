# Hesperia 0.7.0 — awareness pack v1 (conference / speech spine)

**ID:** H070-AWARE-01  
**Owner:** Colombo  
**Date:** 2026-07-26  
**Audience:** Operator talks, conferences, partner briefings  
**Rule:** Every claim cites a wiki structure hub or sealed code path. No new physics on slides.  
**Wire gaps program** = structure/wiring (claim→path), **not** a new domain story.  
**Venue expand (v1.2):** [COLOMBO-H070-AWARE-01-SPEECH-PACK-VENUE-2026-07-26.md](COLOMBO-H070-AWARE-01-SPEECH-PACK-VENUE-2026-07-26.md) — *multipurpose methods / scientific conference* (clinical venue framing **withdrawn**).  
**Identity:** [ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md](../../governance/ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md)

**Phase:** [HESPERIA-POST-070-PHASE-FRAME.md](../../governance/HESPERIA-POST-070-PHASE-FRAME.md)

---

## 60-second story

Hesperia is a **multipurpose sealed runtime semantic engine**: text lands on a deterministic semantic grid (`/analyze`) when dictionaries, logic, areas/families (and corpus) are in play. Above that sits a **composition layer** (`/product/interpret`) that returns **engine-authored ground_truth**. The core is **not** an LLM and **has no domain story of its own** until a field of application is provided. Version **0.7.0** is the **fixed frame**. Modules (e.g. TFP) are applications — including field testing with genuine data — not product identity as medicine/clinical.

## How

1. **Measure** — sealed multiscale: concept → hex → family → area → product signals → HSPR.  
2. **Interpret** — router compose above measurement; HAND (fpf-thinking-map) chooses inquire vs dig.  
3. **Gate** — graph apply only on allowlist (`update_edge_weight`); COBALT and module **REAL_DATA** flags stay off until separate gates.

Cite: [HOW-IT-WORKS-0.7.0](../../colombo_research/hesperia/wiki/structure/HOW-IT-WORKS-0.7.0.md) · [HAND-FACES-0.7.0](../../colombo_research/hesperia/wiki/structure/HAND-FACES-0.7.0.md)

## Where

| Surface | Place |
|---------|--------|
| Prod runtime | prichindel `/data/hesperia/hesperia` @ tag `v0.7.0` |
| Dev | altitudine `/data/workspaces/atomic-commit-hesperia` → `igareosh/hesperia` |
| Product API | `POST /analyze` · `POST /product/interpret` |
| Agent roll | HAND faces — inquire / dig — never agent-authored ground_truth |
| Living map | wiki `structure/` hubs · LAN `http://wiki.hesperia.local/` |

Cite: [SYSTEM-STRUCTURE-0.7.0](../../colombo_research/hesperia/wiki/structure/SYSTEM-STRUCTURE-0.7.0.md)

## Why

- **Deterministic measurement** before narrative — shared body when field + dictionaries/corpus are supplied.  
- **Multipurpose** — not medicine, not clinical, not an LLM; modules apply the engine to a purpose.  
- **Modular Class A/B** — universal plumbing vs domain branches; no specialty pollution of sealed core.  
- **Observe ≠ mutate** — apply is allowlisted so product claims stay honest.  
- **0.7.0 freeze** — growth closed; productization = clarity + robustness, not feature inflation.  
- **TFP (if asked)** — one module for field application testing (genuine data vs science/results), not “Hesperia is clinical.”

Cite: castle seal report · ISO productization baseline · phase frame.

## 5-minute outline (speaker)

1. Problem: LLMs narrate; measurement evaporates.  
2. Body: sealed grid + ground_truth blocks.  
3. HAND: map law, not chat law.  
4. Gates: apply / COBALT / REAL_DATA.  
5. Phase: freeze 0.7.0 · grind · awareness.  
6. Demo pointer: interpret soak / wiki hubs (no live mutate).

## Do not say

- “We are building 0.8 next” (unless Ethan+operator seal a new identity).  
- “The graph rewrites itself in prod” (allowlist only).  
- “COBALT is on in prod” (default off).  
- “Hesperia is clinical / medical / medicine AI” (**false** — multipurpose engine; see Ethan identity stamp).  
- “Hesperia is an LLM” (**false**).  
- Structural analogy = full theory implementation.

SIGNED: Researcher (Colombo) | H070-AWARE-01 speech spine v1 | 2026-07-26 | conference-ready draft
