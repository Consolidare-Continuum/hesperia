# Grace triage - ops-method polish wave

**Date:** 2026-07-29 · **Owner:** Grace
**Trigger:** Operator - triage all continuation lanes; polish the existing card shop/task/session structure with small tweaks.
**Upstream:** [SCOPE-CARD-TASK-CANONICAL-v1.md](../../projects/ops-method/SCOPE-CARD-TASK-CANONICAL-v1.md) · [PROMOTE-2026-07-28-LAB-TO-PROD.md](../../projects/ops-method/PROMOTE-2026-07-28-LAB-TO-PROD.md) · [MIND-API-01-TASKS-FLOW.md](../../projects/ops-method/MIND-API-01-TASKS-FLOW.md)

## Product stance

Do not invent a parallel system. Continue the existing Felix/Claude structure:

- shop/catalog = corpus-wide card browse (`/catalog/*`)
- cart/company fit = bind + promote + accept flow (`/company/*`)
- flowing task cards = `/tasks/*`
- save-project session continuity = `it_agentic_session` + `scripts/it_agentic_session.py`

This wave is **small tweaks only** - polish, missing actions, UX mismatches, and session continuity helpers around what already exists.

## Rows

| ID | Owner | Task |
|----|-------|------|
| **OPS-METHOD-POLISH-00** | Grace | This triage |
| **OPS-METHOD-POLISH-01** | Felix | Shop/cart backend polish - fill small missing actions around the existing catalog/cart flow (`remove-from-cart`, bulk pick, export/checkpoint hook readiness only if low-risk and aligned to current model) |
| **OPS-METHOD-POLISH-02** | Felix | UI/UX polish in `agv_ui/company.html` - fix small browse/cart/checkout mismatches without changing the canonical slot-first shop model |
| **OPS-METHOD-POLISH-03** | Felix | Save-project session polish - extend `scripts/it_agentic_session.py` and/or API surface for continuity beyond `open/show/traverse`, staying aligned to `it_agentic_session` |
| **OPS-METHOD-POLISH-04** | Grace | Intake remembered rough edges from operator during the polish wave; fold concrete small tweaks into 01-03 instead of spawning a parallel design track |

**Triage outcome:** PROJECT-CREATED.

## POLISH-04 intake (2026-07-29)

Operator remembered no separate “yesterday defect” beyond the four lanes. Wave fold-back:

| Edge | Folded into | Result |
|------|-------------|--------|
| Missing cart remove + bulk pick | **01** | `POST /catalog/remove-from-cart`, `POST /catalog/add-many-to-cart` |
| Cart UI remove action | **02** | `company.html` remove-from-cart wiring |
| Session only open/show/traverse | **03** | `list` / `await` / `resume` / `close` (orbit) on `it_agentic_session.py` |
| UI still loops single add for bulk | noted | Backend ready; no new row — optional later UI hook only |
| invent for books #1–#6 | — | stays CLOSED; out of polish scope |

No parallel design track opened. Wave complete when **04** DONE.

SIGNED: Triage (Grace) | ops-method polish wave | 2026-07-29 | ops-method
SIGNED: Intake (Grace) | OPS-METHOD-POLISH-04 | 2026-07-29 | rough-edge fold into 01–03
