# Grace triage — Colombo Susanin mode (on-demand autoworkflow)

**Date:** 2026-07-24  
**Authority:** Operator (igareosh) — design approved; Approach **2**; A-by-design + B-atop; tasking **on demand** (budget 40–100).  
**Spec:** [SPEC-ETHAN-COLOMBO-SUSANIN-MODE.md](../../governance/SPEC-ETHAN-COLOMBO-SUSANIN-MODE.md)  
**Register:** [SUSANIN-2026-REGISTER.md](../../governance/SUSANIN-2026-REGISTER.md) · **Exit:** [SUSANIN-EXIT-CRITERIA.md](../../governance/SUSANIN-EXIT-CRITERIA.md)

---

## Triage outcome

**PROJECT-CREATED — SUSANIN** — **2026-07-24** → **CLOSED v1 same day** — [active.md](../../active.md) **SUSANIN-00..59** all **DONE** (60). Exit: [SUSANIN-V1-QA-EXIT-2026-07-24.md](SUSANIN-V1-QA-EXIT-2026-07-24.md). Capacity: [agents/colombo/SUSANIN-MODE.md](../../agents/colombo/SUSANIN-MODE.md).

**One sentence:** Colombo first-class **Susanin mode v1** for process/business-process formalize + model/remodel; domain map `susanin_ops`; base theme `business`; ready for work.

---

## On-demand release (mandatory)

| Trigger phrase | Action |
|----------------|--------|
| `proceed Susanin W1` | Grace adds SUSANIN-10..24 to active.md · SuiteCRM sync |
| `proceed Susanin W2` | Grace adds SUSANIN-25..36 |
| `proceed Susanin W3` | Grace adds SUSANIN-37..44 |
| `proceed Susanin W4` | Grace adds SUSANIN-45..52 |
| `proceed Susanin W5` | Grace adds SUSANIN-53..59 |
| `proceed Susanin all` | Grace adds remaining OPEN catalog (use sparingly) |
| `cancel Susanin W<n>` | Mark those IDs CANCELLED in register; do not add |

Cursor may ask Grace to release a wave when needed for Cursor’s own alignment work.

---

## Wave 0 rows (live)

| ID | Owner | TYPE |
|----|-------|------|
| SUSANIN-00 | Grace | triage |
| SUSANIN-01 | Ethan | spec |
| SUSANIN-02 | Cursor | task |
| SUSANIN-03 | Colombo | task |
| SUSANIN-04 | Liam | task |
| SUSANIN-05 | Noah | task |
| SUSANIN-06 | Cursor | task |
| SUSANIN-07 | Colombo | task |
| SUSANIN-08 | Grace | task |
| SUSANIN-09 | Ava | task |

All: `SUITE: YES` · Link → this packet · sync per `SCRIPT-RUNBOOK-grace-triage-active`.

---

## Parallel

Does not pause ATM2 / ops-method / other OPEN waves.

SIGNED: Triage (Grace) / Cursor | Susanin on-demand | 2026-07-24 | Wave 0 live
