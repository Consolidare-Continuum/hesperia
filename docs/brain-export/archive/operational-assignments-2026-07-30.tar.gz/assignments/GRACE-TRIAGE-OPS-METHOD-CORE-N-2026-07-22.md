# Grace triage — ops-method CORE-N rhetorical-context wave

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01
**Trigger:** Operator — "spec me a fix for romantic abstractions context awareness copes." Generalizes CORE-M (statement-type precision) into a real category + reasoning-layer awareness, not just a relabel.
**Source:** [ETHAN-PLAN-CORE-N-RHETORICAL-CONTEXT-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-CORE-N-RHETORICAL-CONTEXT-2026-07-22.md)
**FREEZE:** LIFTED, not relevant — quality/reasoning-surface axis, not map density or gloss completeness.
**Depends on:** CORE-M (M02a/M02b's audit rows seed N03's detector) — sequence N after M, or run in parallel with N03 blocked on M's outputs.

## Rows to add → active.md

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-CORE-N00** | Grace | P1 | Triage CORE-N wave (this file) |
| **OPS-METHOD-CORE-N01** | Ethan + Colombo | P1 | Ratify `rhetorical_kind` closed vocab |
| **OPS-METHOD-CORE-N02** | Felix | P1 | Schema: `statement.rhetorical_kind` + vocab table |
| **OPS-METHOD-CORE-N03** | Felix | P1 | Detector, seeded from CORE-M audit rows — **blocked on CORE-M02a/M02b** |
| **OPS-METHOD-CORE-N04** | Felix | P1 | Propose `illustrates` edges from tagged statements to what they illustrate |
| **OPS-METHOD-CORE-N05** | Felix | P1 | Wire `rhetorical_context` into `reason_at_step()`; exclude from actionability default; additive supervisor flag |
| **OPS-METHOD-CORE-N06** | Ava | P1 | Smoke: known examples tagged+linked; no regression on dogfooding baseline |
| **OPS-METHOD-CORE-N07** | Ethan | P1 | Sign complete; folds into `PROD-J01` onboarding runbook with CORE-M |

## Sequencing

N01/N02 can start now (design + schema, no dependency). N03 blocked on CORE-M's M02a/M02b outputs. N04→N05→N06→N07 follow in order.

SIGNED: Triage (Grace) | CORE-N rhetorical context | 2026-07-22
