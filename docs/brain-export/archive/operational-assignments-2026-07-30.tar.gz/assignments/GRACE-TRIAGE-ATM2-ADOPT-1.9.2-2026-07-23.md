# Grace triage — ATM2 adopt wave (`fpf-thinking-map==1.9.2`)

**Date:** 2026-07-23  
**Authority:** Operator (igareosh) — Approach A approved in Cursor chat; soak hold lifted.  
**Package:** [fpf-thinking-map on PyPI](https://pypi.org/project/fpf-thinking-map/) **==1.9.2** (runtime = 1.9.1; 1.9.2 = PyPI presentation)  
**Prior wave:** ATM-00..79 DONE (1.2→1.6 era) · [GRACE-TRIAGE-ATM-WAVE-2026-06-28.md](GRACE-TRIAGE-ATM-WAVE-2026-06-28.md)  
**Soak lift:** [FPF-THINKING-MAP-1.9.1-PROVENANCE.md](../../governance/FPF-THINKING-MAP-1.9.1-PROVENANCE.md) held pin at 1.6.0; this wave **adopts**.

---

## Triage outcome

**PROJECT-CREATED — ATM2** — **2026-07-23** — [active.md](../../active.md) **ATM2-00..49** (50 rows) · register [ATM2-2026-REGISTER.md](../../governance/ATM2-2026-REGISTER.md) · exit [ATM2-EXIT-CRITERIA.md](../../governance/ATM2-EXIT-CRITERIA.md).

**One sentence:** Pin brain + MCP paths to **1.9.2**, wire **Clearance** (`AuthorizationReceipt`), **Holding Pattern** (`PendingInput` / `AWAIT`), **Tail Number** (`MoveIntent` / `inspect_move`) into `cursor-thinking-map` + domain maps + rules/runbooks — Cursor uses the library **as product and as MCP muscle while running**.

---

## Why now

Operator authored/curated the package. Wide use already ratified for 1.6.0 ([FPF-THINKING-MAP-WIDE-USE.md](../../governance/FPF-THINKING-MAP-WIDE-USE.md)). 1.9.x features soaked at package level; ops adopt is the deferred decision — **now explicit**.

---

## New mechanisms (binding names)

| Name | Mechanism | Since |
|------|-----------|-------|
| Clearance | `AuthorizationReceipt` — auth scoped to one transition + inspected state | 1.7.0 (+ 1.9.1 clock fix) |
| Holding Pattern | `PendingInput` / `OutcomeKind.AWAIT` — wait ≠ IDLE | 1.8.0 |
| Tail Number | `MoveIntent` / `inspect_move()` — concrete move identity | 1.9.0 |

Ignition Lock (1.6.0) remains; Clearance tightens it. Do not invent `authorized=true` or forge receipts.

---

## Scope

**In:** brain pin, MCP faces (`cursor-thinking-map`, `cursor-fpf-test-mcp`), `team_ops` / `cluster_ops` / `eod_ops`, rules, runbooks, evidence tokens, Hesperia/ops-method pin align, CHROMA `thinking_map_catalog` re-ingest, SuiteCRM sync.

**Out:** Rebuilding ATM-00..79; parallel engine vend; Traversal Checkpoint (upstream design-only, not in 1.9.2).

**Parallel:** HWIKI and other OPEN waves continue — ATM2 does not pause them.

---

## Dependency graph (critical path)

```mermaid
flowchart LR
  A[ATM2-00 Grace triage] --> B[ATM2-03 Ethan ratify]
  B --> C[ATM2-05 Abelard pin 1.9.2]
  C --> D[ATM2-11..14 Felix MCP surface]
  D --> E[ATM2-15..18 domain maps]
  E --> F[ATM2-23 Gena deploy]
  F --> G[ATM2-28..33 Cursor self-use rules]
  G --> H[ATM2-49 Grace close]
```

**Start now:** **ATM2-00** (done at triage) · **ATM2-05** (pin) · **ATM2-03** (Ethan) · **ATM2-28** (Cursor wide-use) — parallel.

---

## Member blocks

| Owner | IDs | Focus |
|-------|-----|-------|
| **Grace** | 00–02, 49 | Meta, register, heartbeat, close |
| **Ethan** | 03–04 | Adopt ratify + SPEC bump |
| **Abelard** | 05–10 | Pin, venvs, hard-gate, CHROMA ingest, CI |
| **Felix** | 11–22, 43–44 | MCP + maps + tests + Hesperia/ops-method |
| **Gena** | 23–27 | mcp-config deploy, mirrors, passport |
| **Cursor** | 28–33 | Wide-use, rules, AGENTS, self MCP habit |
| **Liam** | 34–36 | Runbooks + evidence tokens |
| **Noah** | 37–38 | CHROMA policy + FAQ |
| **Daniel** | 39–40 | Security (receipt / AWAIT) |
| **Colombo** | 41–42 | fpf-test mandatory + boundary |
| **Olivia** | 45 | Workflow API docs |
| **Ava** | 46 | QA matrix |
| **Marcus** | 47 | Audit trail proposal |
| **Sophia** | 48 | Surveillance health note |

---

## SuiteCRM

All rows: `SUITE: YES` · sync per `SCRIPT-RUNBOOK-grace-triage-active` · batch at **ATM2-49**.

---

## Exit

Close at **50/50 DONE** per [ATM2-EXIT-CRITERIA.md](../../governance/ATM2-EXIT-CRITERIA.md).

SIGNED: Triage (Grace) / Cursor | ATM2 adopt 1.9.2 | 2026-07-23 | Approach A
