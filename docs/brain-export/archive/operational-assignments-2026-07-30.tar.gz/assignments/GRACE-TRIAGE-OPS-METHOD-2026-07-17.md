# Grace triage — ops-method project open (2026-07-17)

**Project shortcut:** `ops-method`  
**Hygiene tag:** docs-only → then integration (pipeline wave later)  
**Outcome:** PROJECT-CREATED  
**Ethan open packet:** [ETHAN-OPS-METHOD-PROJECT-OPEN-2026-07-17.md](ETHAN-OPS-METHOD-PROJECT-OPEN-2026-07-17.md)  
**Spec:** [SPEC-ETHAN-OPS-METHOD-PRODUCT.md](../../governance/SPEC-ETHAN-OPS-METHOD-PRODUCT.md)  
**Register:** [OPS-METHOD-2026-REGISTER.md](../../governance/OPS-METHOD-2026-REGISTER.md)

## Operator request (summary)

1. New team project: operational business processes product.  
2. Full book decomposition (0..N claims per sentence), relations, gates, checks, guards, audit.  
3. Agentic semantic dictionary; DB inspectability (agent + human); batches, statements, matrices, coordinates.  
4. Hesperia-like — **not** Hesperia yet.  
5. First source: Rybakov; engine reusable for other books/frameworks.  
6. First artifact: Decomposition & Traceability Spec v0.1 before full book.

## Rows (active.md)

| ID | Owner | Intent | Status target |
|----|-------|--------|---------------|
| **OPS-METHOD-00** | Grace | Triage PROJECT-CREATED; bootstrap verify; SuiteCRM sync | DONE (this packet) |
| **OPS-METHOD-01** | Ethan | Ratify product SPEC | DONE |
| **OPS-METHOD-02** | Ethan | Decomposition & Traceability Spec v0.1 | OPEN |
| **OPS-METHOD-03** | Grace | Seal CONTEXT-PACKET | OPEN |
| **OPS-METHOD-04** | Ethan | ARCH-DECISION WBS APPROVED | OPEN |
| **OPS-METHOD-05** | Grace | Intake Rybakov book file + edition (operator supply) | OPEN / blocked on file |
| **OPS-METHOD-06** | Sophia | Infra Duration Estimate | OPEN |
| **OPS-METHOD-07** | Daniel | SECURITY-BASELINE source isolation | OPEN |

## Do not

- Start full-book extraction before Spec v0.1 + pilot plan.  
- Merge into Hesperia without Ethan decision.  
- Invent relation types outside Spec vocabulary.  
- Commit verbatim book text to public GitHub.

## SuiteCRM

`SUITE: YES` on all OPS-METHOD rows. Sync after write.

SIGNED: Triage (Grace) | ops-method PROJECT-CREATED | 2026-07-17 | Wave 0
