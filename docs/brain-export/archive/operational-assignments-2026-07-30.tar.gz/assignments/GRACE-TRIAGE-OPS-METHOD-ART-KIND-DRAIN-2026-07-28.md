# Grace triage — ART-KIND drain into API run

**Date:** 2026-07-28 · **Owner:** Grace  
**Trigger:** Operator — triage, drain into API run (artifact_kind explicit).

## Promote

| ID | Was | Now | Owner | Work |
|----|-----|-----|-------|------|
| OPS-METHOD-ART-KIND-01 | OPEN later | **P0 drain** | Felix | Vocab + persist `artifact_kind` / `artifact_object_ru` on lab todos |
| OPS-METHOD-ART-KIND-02 | OPEN later | **P0 drain** | Felix | OpenAI API grind: object-shaped kind from `do_ru`+`artifact` |
| OPS-METHOD-ART-KIND-03 | OPEN later | **P1 drain** | Ava | Smoke AGV kind + complete awareness |

**Stance:** letter→`letter`. Heuristic templates first; API for generic “файл или таблица…” PRODUCE/ASK/DECIDE. Invent still closed. Lab `ops_method_lab`.

SIGNED: Orchestrator (Grace) | ART-KIND API drain triage | 2026-07-28 | ops-method
