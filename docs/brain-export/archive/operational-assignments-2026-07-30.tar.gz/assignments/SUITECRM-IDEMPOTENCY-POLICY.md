# Idempotency — active.md → SuiteCRM sync

**SUITE-CRM-41** · Marcus

**Key:** `active_md_id` — custom field `active_md_id_c` after Quick Repair; until then **`[active_md_id]` name prefix**.

**Upsert:** n8n and MCP search by key before POST; PATCH/POST to `/Api/V8/module` only.

**Duplicates:** forbidden — digest alerts Grace if two CRM rows share prefix.

SIGNED: Data (Marcus) | idempotency policy | 2026-06-18
