# Grace triage — Document agent Telegram (n8n) + Tersagor bot-IRC OpenAI ignore

**Date:** 2026-07-17  
**Source:** Operator → Ethan → CSP Gena (this chat).  
**Status:** Triaged — **Grace documented separately** (tersagor pack + brain pack).  
**Trace:** [GENA-TRACE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md](GENA-TRACE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md)  
**Transcript:** Cursor chat `86cbce1d-a6d5-488c-b1f7-8b7de1694f08`  
**Tersagor docs:** [GRACE-DOC-TERSAGOR-BOT-IRC-OPENAI-IGNORE-2026-07-17.md](GRACE-DOC-TERSAGOR-BOT-IRC-OPENAI-IGNORE-2026-07-17.md)  
**Brain docs:** [GRACE-DOC-BRAIN-AGENT-TELEGRAM-N8N-2026-07-17.md](GRACE-DOC-BRAIN-AGENT-TELEGRAM-N8N-2026-07-17.md)

---

## What to triage

Operator asks Grace to **document this chat throughout** — fold the permanent phone Telegram path and the Tersagor OpenAI-ignore boundary into team docs / active awareness so every agent surface stays consistent.

### Already executed (Gena) — do not re-implement

1. **Brain agent Telegram (n8n)** — `bash scripts/agent-telegram.sh` for igareosh + Olga; IRC→phone export; rule + runbook + AGENTS wiring.
2. **Tersagor forwarder ignore** — bot/system IRC stays in JSONL; does **not** hit OpenAI Agents SDK. Live on tersagor; pushed as addon to **igareosh/tersagor**.

### Grace deliverables (document throughout)

| ID (suggested) | Owner after triage | Work |
|----------------|--------------------|------|
| DOC-TG-00 | Grace | Triage this packet → active.md row(s) · `SUITE: YES` · `TYPE: triage` |
| DOC-TG-01 | Grace | Ensure CONTEXT-ARCHIVE / agent READMEs / INDEX pointers mention agent-telegram as **canonical phone path** |
| DOC-TG-02 | Grace | Cross-link Tersagor ignore addon (`docs/ADDON-BOT-IRC-OPENAI-IGNORE-2026-07-17.md` on tersagor) in cluster/tersagor brain docs |
| DOC-TG-03 | Grace | SuiteCRM sync for documentation task rows |
| DOC-TG-04 | Ethan (optional) | Confirm ETHAN-TARGETED + OPERATIONAL-LAYER §IIa still match after doc pass |

---

## Problem statement (for docs)

| Need | Solution |
|------|----------|
| Any agent texts operator phone | `scripts/agent-telegram.sh` → n8n on prichindel (no Tersagor hunt) |
| Bot IRC alerts clutter OpenAI SDK | Forwarder `_should_skip_openai_ingress` — IRC audit OK, SDK skip |
| Operator wants durable chat record | This packet + Gena trace + inbox |

---

## References

- [cluster/prichindel/n8n/AGENT-TELEGRAM.md](../../cluster/prichindel/n8n/AGENT-TELEGRAM.md)
- [scripts/runbooks/SCRIPT-RUNBOOK-agent-telegram.md](../../scripts/runbooks/SCRIPT-RUNBOOK-agent-telegram.md)
- [.cursor/rules/cursor-agent-telegram-n8n.mdc](../../.cursor/rules/cursor-agent-telegram-n8n.mdc)
- Brain mirror: `operational/external/tersagor/src/imirc_gateway/forwarder.py`
- GitHub: `igareosh/tersagor` addon `cdad34b`
- Brain: `igareosh/cursor` `dc943f50`

---

## Triage outcome

**PROJECT-CREATED** — 2026-07-17 — two separate documentation improvements:

| Wave | Pack | active.md |
|------|------|-----------|
| Tersagor | [GRACE-DOC-TERSAGOR-BOT-IRC-OPENAI-IGNORE-2026-07-17.md](GRACE-DOC-TERSAGOR-BOT-IRC-OPENAI-IGNORE-2026-07-17.md) | **DOC-TG-TERSAGOR-00..01** |
| Brain | [GRACE-DOC-BRAIN-AGENT-TELEGRAM-N8N-2026-07-17.md](GRACE-DOC-BRAIN-AGENT-TELEGRAM-N8N-2026-07-17.md) | **DOC-TG-BRAIN-00..01** |
| Bootstrap | this packet | **DOC-TG-00** |

SIGNED: Triage (Grace) | document chat throughout (tersagor + brain separate) | 2026-07-17
