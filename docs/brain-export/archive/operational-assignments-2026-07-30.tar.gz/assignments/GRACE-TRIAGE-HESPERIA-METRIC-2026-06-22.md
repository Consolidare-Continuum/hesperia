# Grace triage — Hesperia METRIC and Distance (40 tasks)

**Date:** 2026-06-22  
**Source:** Operator — Grace triage + task team for Ethan **SPEC-ETHAN-HESPERIA-METRIC-AND-DISTANCE** + **24_SPEC** + academia pack  
**Register:** [governance/METRIC-2026-REGISTER.md](../../governance/METRIC-2026-REGISTER.md)  
**Exit criteria:** [governance/METRIC-EXIT-CRITERIA.md](../../governance/METRIC-EXIT-CRITERIA.md)  
**Budget:** **40 tasks** (METRIC-00..39) — standard wave, **≤50** cap

---

## Triage outcome

**PROJECT-CREATED** — **METRIC-00..39** on [active.md](../../active.md).  
**Project:** `hesperia` · **HesperiaMetric** registry · phases A–D.  
**Authority:** [governance/SPEC-ETHAN-HESPERIA-METRIC-AND-DISTANCE.md](../../governance/SPEC-ETHAN-HESPERIA-METRIC-AND-DISTANCE.md) (Ethan **RATIFIED**).  
**Operator gate:** **METRIC-17** — freeze `anchor_map_v1` before GCS hex-tier emit (METRIC-22, METRIC-26).

---

## Wave map

| Wave | IDs | Focus | Owner mix |
|------|-----|--------|-----------|
| W0 | 00–04 | Meta, exit criteria, CHANGE-LOG | Grace, Ethan |
| W1 | 05–09 | Phase A doc hygiene, glossary, THEORY-INDEX | Colombo, Cursor, Liam, Marcus, Noah |
| W2 | 10–16 | Phase B dev promotion + schemas + API contract | Gena, Felix, Olivia |
| W3 | 17–19 | **anchor_map_v1** freeze + reconcile IPoV | Grace, Felix, Gena |
| W4 | 20–28 | Phase C runtime emit + path action + tests | Felix, Gena, Ava |
| W5 | 29–33 | Phase D academia + CHROMA + security | Colombo, Abelard, Sophia, Daniel |
| W6 | 34–39 | BELL/KME hygiene + wave closure | Felix, Gena, Ethan, Grace |

---

## Gap register → tasks

| Gap | Tasks |
|-----|-------|
| G-M1 unified registry | 10–16, 20 (spec + emit) |
| G-M2 GCS + IPoW in product | 22, 23 |
| G-M3 anchor_map | 17, 18, 19 |
| G-M4 path action | 24, 25 |
| G-M5 symbol collision | 05, 36 |
| G-M6 J_sem→gcs | 26 |
| G-M7 Poisson | optional — not triaged |

---

## Team tasking summary

| Owner | Count | First OPEN |
|-------|-------|------------|
| Grace | 6 | METRIC-00 |
| Ethan | 3 | METRIC-01 |
| Felix | 12 | METRIC-14 |
| Gena | 7 | METRIC-10 |
| Colombo | 3 | METRIC-05 |
| Abelard | 1 | METRIC-31 |
| Cursor | 1 | METRIC-06 |
| Liam | 1 | METRIC-07 |
| Marcus | 1 | METRIC-08 |
| Noah | 1 | METRIC-09 |
| Olivia | 1 | METRIC-16 |
| Ava | 1 | METRIC-28 |
| Sophia | 1 | METRIC-32 |
| Daniel | 1 | METRIC-33 |

**Total:** 40 tasks.

---

## SuiteCRM

All rows: `SUITE: YES` · `TYPE: task` (METRIC-00, METRIC-04 = `triage` where noted).  
Post-triage: `bash scripts/suitecrm_sync_on_triage.sh --task-id METRIC-00` (and wave sync).

---

## Dependencies (critical path)

```text
METRIC-10 (24_SPEC on dev)
  → METRIC-14 (schema)
    → METRIC-20 (emit)
METRIC-17 (operator freeze)
  → METRIC-18 (anchor_map JSON)
    → METRIC-22 (GCS emit)
    → METRIC-26 (J_sem→gcs)
METRIC-24 + METRIC-25 (path action) — parallel after METRIC-20
METRIC-37 (Ethan sign-off) — after G1–G8 evidence
METRIC-39 (wave closure) — last
```

---

**SIGNED: Triage (Grace) | Hesperia METRIC wave | 2026-06-22 | METRIC-00..39**
