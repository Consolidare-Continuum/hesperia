# Grace triage — SuiteCRM product takeover (prichindel.com pipeline)

**Date:** 2026-06-18  
**Source:** Operator — after Ethan architecture; **Grace task team** to takeover SuiteCRM as **new product** in pipeline; budget **&lt;100 tasks**.  
**Register:** [governance/SUITE-CRM-PRODUCT-2026-REGISTER.md](../../governance/SUITE-CRM-PRODUCT-2026-REGISTER.md)  
**Spec:** [governance/SPEC-ETHAN-SUITECRM-PRODUCT-PIPELINE.md](../../governance/SPEC-ETHAN-SUITECRM-PRODUCT-PIPELINE.md)  
**Project:** [projects/suitecrm/](../../projects/suitecrm/)  
**Prior:** SUITE-CRM-00..08 DONE — infra + OAuth n8n live.

---

## Triage outcome

**PROJECT-CREATED** — **SUITE-CRM-09..83** (75 tasks) on [active.md](../../active.md).  
**Project key:** `suitecrm` (product) · was `cluster` for deploy wave  
**URL:** `https://suite.prichindel.local`  
**Product:** Company CRM — three task trees (Todo / Pending / Done), n8n ↔ active.md, MCP-first agents.

---

## Problem statement

| Today | Gap |
|-------|-----|
| CRM **installed** (8.10.1) | No productized operator home; stock SuiteCRM clutter |
| n8n OAuth wired | No active.md sync, no report_done bridge |
| active.md canonical | No CRM projection for company / operator visibility |
| Agents | No `cursor-suitecrm` MCP; must not hit MariaDB |
| Moldova registration pending | No Accounts/Projects shell for legal entity |

**Operator ask:** Team **takeover** — UI + automation + governance so SuiteCRM is a **prichindel.com pipeline product**; Cursor adds/set-done for Hesperia-class projects; Grace/team use n8n + MCP.

---

## Architecture (Ethan — adopted)

- **active.md** stays single source of truth ([OPERATIONAL-LAYER.md](../../OPERATIONAL-LAYER.md)).
- SuiteCRM = **projection + human UI**; sync **active.md → CRM**; CRM UI → **inbox only**.
- **MCP** `cursor-suitecrm` — V8 API OAuth; **no DB** unless break-glass.
- **n8n:** `activemd-crm-sync`, `crm-on-report-done`, `crm-digest-grace`.
- **Moldova:** COMPANY-MD placeholder rows (66–68); full wave when registration completes.

---

## Wave map (75 tasks)

| Wave | IDs | Focus |
|------|-----|--------|
| W0 Bootstrap | 09–15 | Triage, project folder, Ethan WBS, Sophia infra duration |
| W1 UI | 16–23 | Three trees, fields, theme, Ava UI tests |
| W2 MCP | 24–33 | agent_mcp_suitecrm, Daniel security, Cursor wire, Felix smoke |
| W3 n8n | 34–41 | Sync workflows, Emma/Olivia contracts |
| W4 Security | 42–45 | Daniel policies |
| W5 Runbooks | 46–49 | Liam |
| W6 Contracts | 50–52 | Emma, Olivia, Sophia backup |
| W7 Tests | 53–56 | Ava sync matrix |
| W8 Chroma | 57–59 | Noah, Gena mirror, Marcus Projects |
| W9 Cursor/Hesperia | 60–62 | Felix, Cursor rules, Gena passport |
| W10 Infra | 63–65 | Abelard SSO/DNS, Sophia monitoring |
| W11 Moldova | 66–68 | Ethan, Grace, Marcus |
| W12 Portfolio | 69–72 | Olivia, Marcus, Ethan, Colombo i18n |
| W13 Close | 73–83 | Grace closure, polish, backup verify |

---

## Start order

1. **SUITE-CRM-11..12** (Ethan) — ratify spec + WBS APPROVED  
2. **SUITE-CRM-15** (Sophia) — infra duration within 48h  
3. **SUITE-CRM-16..23** (Gena/Abelard/Ava) — operator UI  
4. **SUITE-CRM-24..33** (Gena/Cursor/Felix) — MCP in parallel after 12  
5. **SUITE-CRM-34..41** (Gena) — n8n sync after OAuth clients  
6. Remaining waves parallel per register  
7. **SUITE-CRM-74** (Grace) — wave closure

---

## Team budget

| Cap | Actual |
|-----|--------|
| Operator max | &lt;100 |
| This wave | **75** (09–83) |
| OPEN at triage | **74** (09 DONE) |

---

SIGNED: Triage (Grace) | SUITE-CRM product takeover PROJECT-CREATED | 2026-06-18 | 75 tasks on active.md
