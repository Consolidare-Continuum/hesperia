# Grace triage — SEM RU semantics → reasoning API

**Triage:** Grace · **Date:** 2026-07-22 · **Pack:** SRC-RYB-ED01  
**Plan:** [ETHAN-PLAN-SEM-REASON-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-SEM-REASON-2026-07-22.md)  
**Freeze:** HOLD · no second book

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-SEM-00** | Grace | P0 | Triage this wave |
| **OPS-METHOD-SEM-01** | Ethan | P0 | Ratify SEM design + FPF non-conflict |
| **OPS-METHOD-SEM-02** | Colombo | P0 | RU gloss for option kinds + relation_type |
| **OPS-METHOD-SEM-03** | Felix | P0 | Schema 010 reason gloss / option catalog |
| **OPS-METHOD-SEM-04** | Felix | P0 | API `POST /reason/at-step` + GET convenience |
| **OPS-METHOD-SEM-05** | Noah | P1 | FPF alignment block + advisory notes in payload |
| **OPS-METHOD-SEM-06** | Gena | P1 | UI: Reason at STEP button |
| **OPS-METHOD-SEM-07** | Liam | P1 | Runbook update |
| **OPS-METHOD-SEM-08** | Ava | P0 | Smoke ≥3 STEPs across chapters |
| **OPS-METHOD-SEM-09** | Ethan | P0 | Sign **SEM-READY** |

SIGNED: Triage (Grace) | SEM reason | 2026-07-22
