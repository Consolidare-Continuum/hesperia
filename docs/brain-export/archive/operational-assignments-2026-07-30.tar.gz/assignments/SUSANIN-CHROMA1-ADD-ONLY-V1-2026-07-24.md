# Susanin — CHROMA-1 books add-only path (v1)

**Owner:** Abelard awareness · **Users:** Colombo / Cursor

```bash
# Stage EN-named PDFs; meta in cluster/chroma-server/books_full_meta.py (theme=business|…)
# On prichindel:
export CHROMA_SERVER_URL=http://chroma-1.prichindel.local:8002
export OWNCLOUD_BOOKS_PATH=/tmp/susanin-books-staging
export BOOKS_EMBED_CLIENT=1 INGEST_ONLY_MISSING=1 BOOKS_WRITE_MANIFEST=0
export PYTHONPATH=/data/workspaces/cursor
/data/chroma/venv/bin/python cluster/chroma-server/ingest_books.py "$OWNCLOUD_BOOKS_PATH"
```

CHROMA-2: `ingest_colombo_library_drop` / `papra-drop.sh`. Theme gate: [SCRIPT-RUNBOOK-susanin-theme-intake.md](../../scripts/SCRIPT-RUNBOOK-susanin-theme-intake.md).

SIGNED: DevOps (Abelard) / Cursor | Susanin CHROMA-1 path v1 | 2026-07-24
