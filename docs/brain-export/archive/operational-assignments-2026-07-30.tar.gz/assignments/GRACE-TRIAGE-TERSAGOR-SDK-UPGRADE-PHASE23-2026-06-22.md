# Grace triage — Tersagor SDK upgrade Phases 0–3 + operator trust mode (chat capture)

**Date:** 2026-06-22  
**Source:** Operator chat with **Gena** — IRC/TG Abelard fixes, OpenAI Agents SDK long-run upgrade, minimal HITL / agentic Telegram guidance.  
**Canonical repo:** `igareosh/tersagor` · VM `tersagor.prichindel.local` · clone `/data/tersagor`  
**Plan:** `docs/SDK-UPGRADE-RUN-PLAN.md` on tersagor repo

---

## Triage outcome

**PROJECT-CONTINUED — TERSAGOR-SDK-UPGRADE** — **2026-06-22** — Phases **0–3 DONE** on prod (`9dc5b13`); **Phase 4+** triaged as **TSDK-081..100** on [active.md](../../active.md). Register: [TSDK-UPGRADE-2026-REGISTER.md](../../governance/TSDK-UPGRADE-2026-REGISTER.md).

**One sentence:** Gena upgraded prod from `openai-agents` **0.3.3 → 0.17.6**, shipped **operator trust mode** (minimal permission theater; Abelard auto-executes; Colombo/triage agentic inquires only), deployed tersagor — all M4 + SDK prod smokes green; next wave = routing consolidation, MCP Streamable HTTP, retire compat shim.

---

## What Gena did (brief — do not lose context)

### Problem (operator pain)

| Symptom | Root cause |
|---------|------------|
| Per-message SDK crashes (`tool_input_guardrails`) | Prod venv **0.3.3**; code targeted **0.17.x** |
| IRC trace spam / bot feedback loops | Prior mesh/orchestrator fixes + old SDK |
| TG “want me to copy-paste?” / approval theater | HITL + risk judge + runner approval on by default |
| Misleading SSH / missing replies | Mixed direct-lane vs SDK-lane + version skew |

### Operator policy (2026-06-22)

- **Abelard:** full sudo on cluster — **minimal HITL**; no stupid permission prompts for routine ops.
- **Colombo / tersagor TG:** **agentic** — meaningful context questions only; not Pentagon security layer; skip “shall I paste?” theater.
- **Gena:** proceed alone in SDK woods; commit/push/deploy authorized.

### Delivered (commits + prod)

| Phase | Commit / rev | What |
|-------|--------------|------|
| **0–1** | `a597065` | Pin `openai-agents>=0.17.6,<0.18`; deploy scripts; `version_gate.py`; `sdk_max_turns()`; lazy guardrails; prod venv **0.17.6** both paths |
| **2–3** | `9dc5b13` | **Operator trust mode** — see env table below |
| **Deploy** | `9dc5b13` on VM | `deploy-on-vm.sh` + `sync-imirc-agent-env.sh`; smokes **10/10 M4**, **2/2 mesh glue**, **4/4 SDK prod**, **28 pytest** altitudine |

### Operator trust mode (default on prod)

| Env | Default | Effect |
|-----|---------|--------|
| `TERSAGOR_OPERATOR_TRUST_MODE` | `1` | Low-friction ops |
| `TERSAGOR_ABELARD_SDK_HITL` | `0` | No SDK `needs_approval` pauses |
| `TERSAGOR_ABELARD_RUNNER_APPROVAL` | `0` | No TG shell approval polling |
| `TERSAGOR_RISK_JUDGE_ENABLED` | `0` | No LLM risk judge before shell |

**Code:** `agentic_contract.py`, `abelard/approval_mode.py`, slimmed `risk_classifier.py` (forbidden-only hard blocks), prompts (Abelard/Colombo/triage/raw adapter), `docs/OPERATOR-TRUST-MODE.md`.

**Legacy path retained:** set trust `0` + HITL/runner `1` for critical-only approvals (e.g. `docker system prune -a --volumes`).

### Architecture (two lanes — unchanged)

| Lane | Examples |
|------|----------|
| **Direct (no LLM)** | `!agent status`, `!agent abelard cluster services status`, VM list, `status on <host>` |
| **SDK** | Open-ended Abelard/Colombo/triage via `Runner.run` + `SQLiteSession` |

### Prod verify (2026-06-22)

```
smoke_m4_ship_gate.py     → 10/10 GREEN
smoke_irc_mesh_glue.py    → 2/2 GREEN
smoke_sdk_prod_ready.py  → 4/4 GREEN (routing agent live)
sdk_dev_venv.sh pytest    → 28 passed (altitudine)
```

### Operator expectation (post-ship)

- **Telegram/IRC:** Abelard **runs**; Colombo **asks meaningful questions** when context missing — not permission theater.
- **Daily commands** must stay green (see `SDK-UPGRADE-RUN-PLAN.md` § daily operator commands).

---

## Phase 4+ (triaged — Gena recommendations)

Canonical checklist: `docs/SDK-UPGRADE-RUN-PLAN.md` Phases **4–6** on tersagor repo.

| Phase | Focus | Gate |
|-------|--------|------|
| **4** | Routing/triage consolidation — handoffs default; keyword fallback behind flag; delete duplicate regex when parity proven; `nest_handoff_history` for token limits | orchestrator <800 lines; parity tests |
| **5** | MCP Streamable HTTP to prichindel read-only; ToolSearch when tool count high; keep hand-rolled shell for jump SSH | read-only MCP smoke |
| **6** | Retire `function_tool_compat.py`; `version_gate` hard-fail; `STATUS=ga`; migration doc prod table | M4 smokes + 2-week soak |

**Prod flag (after Phase 4 parity):** `TERSAGOR_TRIAGE_AGENT_ENABLED=1`, `TERSAGOR_TRIAGE_KEYWORD_FALLBACK=0` — operator sign-off before flip (was `0` at M5 mesh conf).

---

## Active.md wave

| ID range | Owner | Status |
|----------|-------|--------|
| **TSDK-081** | Grace | DONE — this packet |
| **TSDK-082** | Gena | DONE — phase 0–3 + trust mode ship |
| **TSDK-W41** | Grace | DONE — [closure packet](GRACE-CLOSURE-GENA-TERSAGOR-SDK-PHASE23-2026-06-22.md) |
| **TSDK-W40** | Grace | DONE — tomorrow sprint triage |
| **TSDK-083..126** | Gena (+ Abelard 104) | OPEN / PAUSED — Phase 4+ queue |

**Closure:** Gena chapter 1 signed off 2026-06-22. Operator acknowledgement: great job so far.

---

## References

| Doc | Path |
|-----|------|
| **Grace closure** | [GRACE-CLOSURE-GENA-TERSAGOR-SDK-PHASE23-2026-06-22.md](GRACE-CLOSURE-GENA-TERSAGOR-SDK-PHASE23-2026-06-22.md) |
| Upgrade run plan | `igareosh/tersagor` → `docs/SDK-UPGRADE-RUN-PLAN.md` |
| Trust mode | `docs/OPERATOR-TRUST-MODE.md` |
| Migration | `docs/AGENTS-SDK-MIGRATION.md` |
| 50-task registry (prior wave) | [TSDK-2026-REGISTER.md](../../governance/TSDK-2026-REGISTER.md) |
| Mesh M5 | [TSDK-MESH-CONF-2026-REGISTER.md](../../governance/TSDK-MESH-CONF-2026-REGISTER.md) |
| Brain cluster stub | [cluster/tersagor/README.md](../../cluster/tersagor/README.md) |

---

SIGNED: Grace (triage) | Tersagor SDK upgrade phase 0–3 chat capture + phase 4+ wave | 2026-06-22 | tersagor-sdk-upgrade
