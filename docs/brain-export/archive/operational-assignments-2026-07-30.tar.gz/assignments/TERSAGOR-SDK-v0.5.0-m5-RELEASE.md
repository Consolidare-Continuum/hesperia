# Tersagor OpenAI Agents SDK — v0.5.0-m5 (shipped, not GA)

**Date:** 2026-06-21  
**Product repo:** `igareosh/tersagor` @ **`1fe272e`** (tag `tersagor-sdk-v0.5.0-m5`)  
**Brain register:** [TSDK-MESH-CONF-2026-REGISTER.md](../governance/TSDK-MESH-CONF-2026-REGISTER.md)

---

## Version line

| Field | Value |
|-------|--------|
| **Release** | **v0.5.0-m5** |
| **Codename** | mesh-glue-routing |
| **Status** | Shipped on tersagor VM — **not GA** |
| **Operator sign-off** | YES (routing agent on) — [TERSAGOR-M5-OPERATOR-SIGNOFF.md](TERSAGOR-M5-OPERATOR-SIGNOFF.md) |
| **Boss proof** | [ETHAN-BOSS-PROOF-TERSAGOR-SDK-2026-06-21.md](ETHAN-BOSS-PROOF-TERSAGOR-SDK-2026-06-21.md) |
| **Ethan gate** | [ETHAN-GATE-TERSAGOR-v0.5.0-m5-2026-06-21.md](ETHAN-GATE-TERSAGOR-v0.5.0-m5-2026-06-21.md) — **RATIFIED** 2026-06-21 |

Canonical release notes: [RELEASE-TERSAGOR-SDK-v0.5.0-m5.md](https://github.com/igareosh/tersagor/blob/main/docs/RELEASE-TERSAGOR-SDK-v0.5.0-m5.md)

---

## In scope (this version)

Mesh + routing agent + IRC glue smokes + deploy-on-VM. Local MCP `:18093`. M4/M5/SDK prod smokes all green after debug fixes.

## Out of scope until v0.6.0-m6

~~**Hosted brain MCP**~~ — **shipped v0.6.0-m6** 2026-06-21. See [TERSAGOR-SDK-v0.6.0-m6-RELEASE.md](TERSAGOR-SDK-v0.6.0-m6-RELEASE.md).

## Debug policy (operator-endorsed)

No magic: **assume broken until smokes + live probe after deploy.** Version name marks a **debugged checkpoint**, not “done forever.”

---

SIGNED: Grace/Ethan version record | v0.5.0-m5 | 2026-06-21 | tersagor-sdk
