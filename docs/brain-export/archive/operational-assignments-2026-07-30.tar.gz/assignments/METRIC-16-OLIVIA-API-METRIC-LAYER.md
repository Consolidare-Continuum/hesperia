# METRIC-16 — API consumer note: qualify distance by `metric_layer`

**Owner:** Olivia · **Date:** 2026-06-23 · **Status:** DONE

## Rule

Public and integration consumers **MUST** treat any numeric “distance”, “cost”, or “path_mass” field together with its **`metric_layer`** (or nested under `meta.hesperia_metric`). Bare “distance” in client UI or downstream analytics is **forbidden**.

## Layers (24_SPEC)

| `metric_layer` | Meaning for consumers |
|----------------|----------------------|
| `area_sphere` | Geodesic arc on 12-area unit sphere |
| `family_graph` | Zone + bridge shortest path on family lattice |
| `hex_graph` | Hop / corridor mass on hex adjacency |
| `gcs_surface` | Geodesic sphere anchor chords (after `anchor_map_v1`) |
| `ipow_volume` | Chord in IPoW unit ball |
| `concept_graph` | BELL/KSI path_mass over concept relations |
| `state_gram` | Inner product / Gram coupling G_hex_ij |

## API surfaces

| Endpoint / block | Fields |
|------------------|--------|
| `POST /analyze` → `meta.hesperia_metric` | `layers_active`, `anchor_map_id`, optional `geodesic_sphere` |
| Traversal / matrix_run extension | `path_metric_cost`, `path_metric_layers`, `path_action_version` |
| Compare / batch | Document any delta fields that imply distance — qualify in schema |

**Ref:** [24_SPEC](../user_documents/HESPERIA_ACADEMIA/24_SPEC__Hesperia_Metric_and_Distance_v0_1.md) · dev [ENGINE-ANALYZE-CONTRACT](https://github.com/igareosh/hesperia/blob/main/docs/ENGINE-ANALYZE-CONTRACT.md)

**SIGNED: Integration (Olivia) | METRIC-16 API consumer | 2026-06-23**
