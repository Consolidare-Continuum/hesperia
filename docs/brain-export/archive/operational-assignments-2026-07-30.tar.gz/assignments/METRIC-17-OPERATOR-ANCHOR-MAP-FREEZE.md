# METRIC-17 — Operator packet: freeze `anchor_map_v1`

**Date:** 2026-06-22  
**Owner:** Grace → **igareosh** sign-off  
**Blocks:** METRIC-18, METRIC-22, METRIC-26 (per-hex GCS distances)

## Decision required

Choose **one** anchor rule for mapping semantic hex indices → geodesic sphere slots (251 anchors per family area).

### Option A — mod-6 default (recommended candidate)

- Rule: `family_index_in_area % 6 == 0` → anchor slot **250**; all other indices → slot **251** with `geodesic_extra_index = 250`.
- Candidate JSON: [colombo_research/hesperia/METRIC_research/schemas/anchor_map_v1.candidate.json](../../colombo_research/hesperia/METRIC_research/schemas/anchor_map_v1.candidate.json)
- Rationale: Simple, deterministic, aligns with 6-side hex geometry; minimal operator surface.

### Option B — pent-wedge per PentagonPole (ADR)

- Rule: wedge assignment per pole geometry (see 22_SPEC GCS draft).
- Higher fidelity; more implementation and test surface.

## Sign-off line (reply in chat)

```
ANCHOR_MAP_V1: FROZEN option=A|B — YYYY-MM-DD — igareosh
```

After sign-off: Felix **METRIC-18** generates committed `anchor_map_v1.json` on `igareosh/hesperia`.

**Sign-off (recorded):**

```
ANCHOR_MAP_V1: FROZEN option=A — 2026-06-23 — igareosh
```

**SIGNED: Triage (Grace) | METRIC-17 operator packet | 2026-06-22**
