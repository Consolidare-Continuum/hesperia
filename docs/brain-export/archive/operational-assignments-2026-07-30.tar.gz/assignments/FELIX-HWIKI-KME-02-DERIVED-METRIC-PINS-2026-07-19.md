# HWIKI-KME-02 — KME derived metric pins (Felix)

**Date:** 2026-07-19  
**Owner:** Felix  
**Task:** Pin each of 35 KME derived metrics to `calculator.py` / call sites for Colombo wiki pages  
**Product tree:** `/data/hesperia/hesperia` → `hesperia/engine/kme/derived/calculator.py`

## Call sites (consumers of `compute_derived_metrics`)

| Path | Role |
|------|------|
| `hesperia/engine/kme/derived/calculator.py` | **Definition** — `compute_derived_metrics`, `to_derived_vector`, `full_fingerprint` |
| `hesperia/engine/kme/pipeline.py` | Pipeline invokes `compute_derived_metrics(primitives)` (×2 paths) |
| `hesperia/engine/kme/clinical_bridge.py` | Clinical bridge → derived |
| `hesperia/engine/kme/fingerprint/builder.py` | Fingerprint map/vector from `DerivedMetrics` (canonical name order) |
| `hesperia/engine/kme/__init__.py` | Public exports |
| `hesperia/engine/kme/models.py` | `DerivedMetrics` dataclass fields |

**Primitives in** (`p`): `LD`, `COH`, `NC`, `PR`, `PV`, `CI` — all `clamp01` before algebra.  
**Regime:** pure algebra; `clamp01` + `safe_div`; null primitives → all zeros.

## 35 derived metrics (canonical order = `to_derived_vector`)

| # | Symbol | Formula (from calculator.py) | Line (approx) | Generator stub hint |
|---|--------|------------------------------|---------------|---------------------|
| 1 | KDI | `clamp01(LD * COH)` | 72 | Knowledge Density Index |
| 2 | CSI | `clamp01(NC * PR)` | 73 | Coverage–Presence Index |
| 3 | SPI | `clamp01(CI)` | 74 | Structure Index pass-through |
| 4 | TDS | `clamp01(PR * LD)` | 75 | |
| 5 | SSS | `clamp01(safe_div(COH, PV))` | 76 | |
| 6 | KCI | `clamp01(safe_div(LD, PR))` | 77 | |
| 7 | CCI | `clamp01(COH * NC)` | 78 | |
| 8 | SPS | `clamp01(PR * COH)` | 79 | |
| 9 | DCI | `clamp01(LD * NC)` | 80 | |
| 10 | CSI2 | `clamp01(CI * LD)` | 81 | |
| 11 | KEF | `clamp01(safe_div(PV, NC))` | 82 | |
| 12 | ASS | `clamp01(safe_div(COH * LD, PV))` | 83 | |
| 13 | CDR | `clamp01(safe_div(PR, NC))` | 84 | |
| 14 | KCR | `clamp01(safe_div(LD, NC))` | 85 | |
| 15 | TCI | `clamp01(COH * LD * CI)` | 86 | |
| 16 | PEI | `clamp01(safe_div(PR, PV))` | 87 | |
| 17 | KE | `clamp01(safe_div(PR, LD))` | 88 | |
| 18 | SCS | `clamp01(safe_div(LD * COH, NC))` | 89 | |
| 19 | CRI | `clamp01(CI * COH)` | 90 | |
| 20 | KNS | `clamp01(NC * COH * LD)` | 91 | |
| 21 | CII | `clamp01(safe_div(NC, PR))` | 92 | |
| 22 | TEP | `clamp01(PV * LD)` | 93 | |
| 23 | KSI | `clamp01(safe_div(COH * LD, PR))` | 94 | |
| 24 | CDD | `clamp01(safe_div(NC, PV))` | 95 | |
| 25 | SSR | `clamp01(safe_div(PR, PV))` | 96 | |
| 26 | TER | `clamp01(safe_div(CI, LD))` | 97 | |
| 27 | CPC | `clamp01(safe_div(PR * NC, PV))` | 98 | |
| 28 | KBS | `clamp01(safe_div(COH * NC, PV))` | 99 | |
| 29 | TRI | `clamp01(safe_div(CI * LD, PR))` | 100 | |
| 30 | IDE | `clamp01(safe_div(PR * COH, NC))` | 101 | |
| 31 | KPS | `clamp01(safe_div(COH, PR))` | 102 | |
| 32 | TBI | `clamp01(NC * PV)` | 103 | |
| 33 | KDI2 | `clamp01(LD * PR * COH)` | 104 | |
| 34 | CDI | `clamp01(CI * NC)` | 105 | |
| 35 | KVI | `clamp01(safe_div(LD * COH * PR, PV))` | 106 | |

**Fingerprint name order** (same symbols): `fingerprint/builder.py` `DERIVED_NAMES` / `to_derived_map`.

## Module pin for wiki generator

```text
module: hesperia/engine/kme/derived/calculator.py:<line>
needed_by: hesperia/engine/kme/pipeline.py ; clinical_bridge.py ; fingerprint/builder.py
produced_from: PrimitiveMetrics (LD, COH, NC, PR, PV, CI) via primitives/calculator.py
status: LIVE_FULL (BEYOND Java prototype — no 1:1 Java names)
```

## Handoff to Colombo (`HWIKI-KME-01`)

Use this table as `add(...)` stubs: one page per symbol (or one hub + 35 children). Expand names/theory in `HWIKI-DOC-*` / KME-01 — this pin is **code truth only**.

SIGNED: Developer (Felix) | Claude Code / Cursor Felix context | 2026-07-19 | HWIKI-KME-02
