# Grace triage — Hesperia all-encompassing wiki documentation grind

**Date:** 2026-07-19  
**CSP:** From Cursor Context → To Grace Context | Reason: operator approved push + VECTOR-STORAGE + wave open | What changes: Grace may write active.md rows for this wave  
**Operator mandate (verbatim intent):** long grind through Hesperia and its science throughout — wiki must not miss theory, decisions, or science; all-encompassing per step or line of code — what and where happens, for what reasons, relations interlinked.

**Hub:** [wiki/CLAUDE.md](../../colombo_research/hesperia/wiki/CLAUDE.md) · live `http://192.168.100.65:8901/` · policy [HESPERIA-PARAMETER-WIKI-SOURCE.md](../../governance/HESPERIA-PARAMETER-WIKI-SOURCE.md) · gaps [Coverage-Ledger.md](../../colombo_research/hesperia/wiki/Coverage-Ledger.md)

---

## Wave identity

| Field | Value |
|-------|--------|
| **Project** | `hesperia` |
| **ID prefix** | `HWIKI-` |
| **Scale** | ~100–200 executable runs (batched; do not dump all at once) |
| **SUITE** | YES on all wave rows |
| **Exit** | Coverage-Ledger gaps closed or deferred with owner; every LIVE symbol page links module path + reason + relations; `layer=hesperia_wiki` queryable |

## Scope (non-negotiable)

Wiki pages (and linked theory/decision notes) must eventually cover:

1. **Science** — formulas, provenance, LIVE/DEAD/PARTIAL/REJECTED with evidence  
2. **Theory** — why the quantity exists; TFP / Class A/B / branch framing  
3. **Decisions** — explicit REJECTED / DEAD_ALGO_SURVIVED / BEYOND with rationale  
4. **Code** — responsible module path, call sites, tests when present  
5. **Relations** — `produced_from` / `needed_by` / cross-links; no orphan symbols  

Durable edits only via `wiki/tools/generate_wiki.py` → regen → HTML → Chroma re-ingest.

## Batch plan (Grace opens batches; owners grind)

| Batch | IDs | Owner | Theme |
|-------|-----|-------|--------|
| **B0** | HWIKI-00..03 | Grace / Ethan / Abelard / Cursor | Wave open, charter, Chroma ingest, re-ingest habit |
| **B1** | HWIKI-L6-* | Colombo (+ Felix code pins) | L6 neighbors around LYAPUNOV (cheap first layer slice) |
| **B2** | HWIKI-KME-* | Colombo / Felix | KME 35 derived metrics → individual pages |
| **B3** | HWIKI-TRIZ-* | Felix / Colombo | TRIZ extension internals beyond Louvain |
| **B4** | HWIKI-CAT-* | Colombo | Full `parameter_catalog.md` / rationale sweep |
| **B5** | HWIKI-L*-* | Colombo | L1–L11 remaining layers (~225 symbols, one layer per sub-batch) |
| **B6** | HWIKI-CODE-* | Felix / Gena | Per-module code↔wiki linking (what/where/why) |
| **B7** | HWIKI-DEC-* | Ethan / Colombo | Decision/theory narrative pages per Class A/B branch |
| **B8** | HWIKI-OPEN-* | Colombo | Resolve Coverage-Ledger open questions (tension antipodes, Wiener, Mixing) |
| **B-MCP** | HWIKI-MCP-* | Felix | MCP tools + context-rag + code↔wiki linker + agent science citation — [GRACE-TRIAGE-HESPERIA-WIKI-MCP-FELIX-2026-07-19.md](GRACE-TRIAGE-HESPERIA-WIKI-MCP-FELIX-2026-07-19.md) **DONE 2026-07-19** |
| **B-DOC** | HWIKI-DOC-* | Colombo / Ethan (+ Felix verify) | Theory-depth 30 — explainable terms, authors, applications — [GRACE-TRIAGE-HESPERIA-WIKI-DOC-THEORY-DEPTH-30-2026-07-19.md](GRACE-TRIAGE-HESPERIA-WIKI-DOC-THEORY-DEPTH-30-2026-07-19.md) |

Open **B0 + first seeds of B1/B2/B8** now. **B-MCP** done 2026-07-19. **B-DOC** opened 2026-07-19 (operator). Further batches: Grace adds rows when prior batch ≥70% DONE or operator says expand.

## Rows opened this triage

See `active.md` `HWIKI-*` OPEN rows linked to this packet.

SIGNED: Triage (Grace) | Hesperia all-encompassing wiki wave | 2026-07-19 | HWIKI

## HWIKI-KEEP-01 pass (2026-07-29)

B0+B1 ≥70% DONE long since; subsequent seed batches already on board and DONE. Keeper closed this AWP drain without spawning a new OPEN batch (operator drain-to-zero).

**Operator expand 2026-07-29:** Grace led finish — opened [GRACE-TRIAGE-HWIKI-FINISH-FROM-KEEP-2026-07-29.md](GRACE-TRIAGE-HWIKI-FINISH-FROM-KEEP-2026-07-29.md) (`HWIKI-FINISH-*` / L6-02 / L7-01 / L8-01 / CAT-02 / TRIZ-02..03 / KME-03 / KEEP-02).

SIGNED: Keeper (Grace) | HWIKI-KEEP-01 | 2026-07-29 | drain pass + finish expand
