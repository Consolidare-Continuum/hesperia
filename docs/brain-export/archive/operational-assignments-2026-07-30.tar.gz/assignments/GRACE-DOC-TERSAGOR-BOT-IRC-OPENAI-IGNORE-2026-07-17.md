# Grace documentation — Tersagor improvement: bot IRC ≠ OpenAI SDK

**Date:** 2026-07-17  
**Class:** **docs-only** · **integration** (IM-IRC ↔ OpenAI Agents SDK boundary)  
**Project:** `tersagor` (GitHub `igareosh/tersagor` · VM `.68`)  
**Owner after ship:** Felix (tersagor manager) · infra assist Abelard  
**Transcript:** Cursor chat [`86cbce1d-a6d5-488c-b1f7-8b7de1694f08`](../../.cursor/CONTEXT-ARCHIVE.md)  
**Gena trace:** [GENA-TRACE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md](GENA-TRACE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md)  
**Shipped code:** `cdad34b` on [igareosh/tersagor](https://github.com/igareosh/tersagor/commit/cdad34b9eb74e0dc09dca5b8673c2991d684e16b)

---

## Improvement (one line)

**Bot/system lines may and should land in IRC/JSONL for audit; they must not become requests on the OpenAI Agents SDK / mesh interface.**

---

## Chat narrative (tersagor scope only)

| Time (approx) | Actor | Ask / action (tersagor-relevant) |
|---------------|-------|----------------------------------|
| 20:51 | Operator → Ethan → **CSP Gena** | Cross-check wiring; **ignore** own bot messages on tersagor: IRC OK, OpenAI SDK **not** |
| 20:51–20:57 | Gena | Found gap: `IMIRC_DEFAULT_TEXT_TO_AGENT=1` + incomplete `IMIRC_GATEWAY_IGNORE_NICKS` let `abelard` / `web_operator` `!task` lines hit OpenAI |
| 20:51–20:57 | Gena | Added `_should_skip_openai_ingress` (nick + channel + meta origin); live deploy on `tersagor:~/imirc-gateway/` + env; restart forwarder |
| 20:57 | Operator → Gena | Push as **addon** to tersagor repo; leave traces; task Grace |
| 20:57+ | Gena | Pushed addon `cdad34b`; Grace packet opened |
| 21:00 | Operator → **Grace** | Document whole chat **for tersagor** (this packet) **separately** from brain |

**Out of scope here:** n8n agent-telegram phone path (see brain pack).

---

## Technical contract (canonical)

| Layer | Rule |
|-------|------|
| Eggdrop classify JSONL | Continues to record **all** channel traffic (including bots) |
| `imirc-gateway` forwarder | Before envelope → OpenAI/mesh: call `_should_skip_openai_ingress(row)` |
| Skip if | nick ∈ ignore list **or** chan ∈ `#operator-notify`,`#agents-debug` **or** `meta:origin` ∈ `web`,`prometheus`,`agent-telegram`,`agent-irc` |
| Still allowed | Human ops on `#agents-ingest` (e.g. `!agent ask …`) |

**Env keys:** `IMIRC_GATEWAY_IGNORE_NICKS`, `IMIRC_GATEWAY_IGNORE_CHANNELS`, `IMIRC_GATEWAY_IGNORE_ORIGINS`  
**Example:** `config/env/imirc-gateway.env.example`  
**Addon doc (repo):** `docs/ADDON-BOT-IRC-OPENAI-IGNORE-2026-07-17.md`  
**Test:** `tests/test_forwarder_ignore_bots.py`  
**Brain mirror (not SOT for live):** `operational/external/tersagor/src/imirc_gateway/forwarder.py`

**Default ignore nicks (non-exhaustive):** `imirc_reply`, `tersagor`, `egdropp`, executors, `tersagor_bridge`, `web_operator`, `trustmaster_agent`, `cursor_agent`, `cursor`, `prometheus`, `abelard`, `agent-irc-export`, `agent-telegram`, `agent-telegram-verify`.

---

## Live deploy checklist (Abelard / Felix)

1. Code: `~/imirc-gateway/forwarder.py` matches addon (or pull from `igareosh/tersagor` and sync).
2. Env: `~/.config/imirc-gateway.env` has the three IGNORE keys (chmod 600).
3. `systemctl --user restart imirc-gateway-forwarder.service`
4. Verify: bot nick row → skip; human `#agents-ingest` `!agent` → not skipped.

---

## Why this is an improvement

- Stops **feedback loops** (alerts/`!task` from bots re-entering Agents SDK).
- Keeps **IRC as audit plane** without paying OpenAI for machine chatter.
- Clarifies product boundary: **Tersagor = IM-IRC + SDK edge**; phone Telegram for agents is **brain n8n**, not this path.

---

## Grace triage outcome (tersagor)

**PROJECT-CREATED** as documentation improvement — rows **DOC-TG-TERSAGOR-00..01** on [active.md](../../active.md).  
This packet = durable chat record for tersagor half.

SIGNED: Triage (Grace) | tersagor bot-IRC OpenAI ignore docs | 2026-07-17
