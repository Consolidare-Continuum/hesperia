# Grace triage — HWIKI-DOC 30-task theory-depth grind (surfable wiki)

**Date:** 2026-07-19  
**CSP:** From Cursor Context → To Grace Context | Reason: operator — 30-task grind documenting Hesperia into wiki with explainable terms, theory/authors, parameter application  
**Parent:** [GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md](GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md)  
**Hub:** `colombo_research/hesperia/wiki/` · live `http://192.168.100.65:8901/` · MCP `query_hesperia_wiki` / `layer=hesperia_wiki`

---

## Intent

Make the wiki **surfable and understandable** for humans and agents: not stub registers alone, but pages (and concept hubs) that carry:

1. **Explainable terms** — plain-language “what this means” before formula  
2. **Theory + authors** — named lineage with year; extent (full | structural analogy | rejected-with-reason)  
3. **Legitimate reasoning** — why Hesperia adopted / adapted / rejected the science (checkable, not vibe)  
4. **Application** — which parameters, modules, or other wiki pages consume it  

Durable edits via `wiki/tools/generate_wiki.py` → regen → HTML → Cursor `HWIKI-03` re-ingest.

## Quality bar (every DONE)

| Gate | Required |
|------|----------|
| Plain language | ≥1 short paragraph a non-specialist can follow |
| Theory | Author(s) + year + extent label |
| Reasoning | Why this science fits (or was rejected) in Hesperia — cite module/spec |
| Application | ≥2 linked parameters/pages or call sites |
| Links | `produced_from` / `needed_by` / related theory pages updated |
| Regen | `generate_wiki.py` + `render_wiki_html.py` for touched items |

Sources to mine (do not invent authors): `docs/publication/SCIENCE.md`, `docs/foundations/parameter_rationale_and_theory.md`, Colombo audits 2026-07-19, Java `20_GEOMETRY` / `21_MATH` / `22_SPEC`.

## Owners

| Role | Duty |
|------|------|
| **Colombo** | Primary — theory prose, authors, reasoning, generator notes |
| **Ethan** | Charter/template + Class A/B decision narratives (DOC-01, DOC-28) |
| **Felix** | Code verification pins where task says “verify in tree” (DOC-04, DOC-11, DOC-19) |
| **Cursor** | Re-ingest after material batches (`HWIKI-03`) |

## Batch map (30)

| ID | Owner | Theme (surf target) |
|----|-------|---------------------|
| **HWIKI-DOC-00** | Grace | Triage this packet (DONE) |
| **HWIKI-DOC-01** | Ethan + Colombo | **Theory Explainer block** schema for generator (`notes`/`origin` fields): plain-lang + author + extent + application |
| **HWIKI-DOC-02** | Colombo | **Shannon entropy** — Shannon 1948; explain H/−Σp log p; applications: P_disp, monotony, Mixing |
| **HWIKI-DOC-03** | Colombo | **KL divergence REJECTED** — why structurally dead (η + clamp → zeros); contrast Shannon |
| **HWIKI-DOC-04** | Colombo + Felix | **Markov-like λ** — Markov 1906; “Markov-like not HMM”; λ/decay/E_cap applications; Felix verify wording in code comments |
| **HWIKI-DOC-05** | Colombo | **Transition matrix W** — finite-state Markov formalism; how counts→probabilities apply |
| **HWIKI-DOC-06** | Colombo | **Chapman–Kolmogorov** — Chapman 1928 / Kolmogorov 1931; multi-step diffusion applications |
| **HWIKI-DOC-07** | Colombo | **Mixing diagnostics** — mixing theory applied; link entropy sequence; resolve vs UNVERIFIED |
| **HWIKI-DOC-08** | Colombo | **PageRank-shaped walk** — Brin & Page 1998 as structural analogy only; where cited in SCIENCE.md |
| **HWIKI-DOC-09** | Colombo | **PHI / golden ratio** — φ history + icosahedron embeddings; AREAS/geometry applications |
| **HWIKI-DOC-10** | Colombo | **Icosahedral surface graph** — Platonic topology; 5-regular vs ring; links to tension/DFT |
| **HWIKI-DOC-11** | Colombo + Felix | **DFT Ring Smoothness REJECTED** — topology incompatibility reasoning; Felix verify adjacency degree |
| **HWIKI-DOC-12** | Colombo | **Lyapunov estimate** — Lyapunov 1892; honesty: proxy not true exponent; GLOBAL_STABILITY_SCORE |
| **HWIKI-DOC-13** | Colombo | **Wiener feedback** — Norbert Wiener cybernetics lineage; relocate or DEAD with evidence |
| **HWIKI-DOC-14** | Colombo | **Gini concentration** — Corrado Gini; inequality → activation concentration applications |
| **HWIKI-DOC-15** | Colombo | **BM25** — Robertson / Spärck Jones; retrieval BEYOND path applications |
| **HWIKI-DOC-16** | Colombo | **Jaccard** — Jaccard index; overlap applications in product |
| **HWIKI-DOC-17** | Colombo | **Cosine similarity** — vector-space model lineage; LIVE_SUCCESSOR applications |
| **HWIKI-DOC-18** | Colombo | **Louvain** — Blondel et al.; communities seed 42; TRIZ/graph applications |
| **HWIKI-DOC-19** | Colombo + Felix | **Clustering coefficient** — Watts–Strogatz / graph clustering; PARTIAL extent + code pin |
| **HWIKI-DOC-20** | Colombo | **Circuit rank / LOOP_*** — cycle space / cyclomatic idea; loop density applications |
| **HWIKI-DOC-21** | Colombo | **Bipolar tension / antipodes** — geometric opposition theory; compute_tension + OPPOSITE_OFFSET |
| **HWIKI-DOC-22** | Colombo | **Contradiction → tension_energy** — TRIZ / Altshuller lineage vs LIVE mapping |
| **HWIKI-DOC-23** | Colombo | **Penalty suite** — P_amb/thin/disp/guard/shadow as one explainable system; governance applications |
| **HWIKI-DOC-24** | Colombo | **Propagation weights** — center/inner/middle/outer/bridge; diffusion intuition + YAML applications |
| **HWIKI-DOC-25** | Colombo | **Fusion α + E_cap + η** — evidence fusion theory; why centroid threshold kills KL |
| **HWIKI-DOC-26** | Colombo | **FGR** — Formality/Ground/Reliability explainable terms; DOMINANT_SHARE / freshness map applications |
| **HWIKI-DOC-27** | Colombo | **Concept Dictionary** — expand 3+ entries: Markov-like, LIVE_SUCCESSOR, DEAD_ALGO_SURVIVED, structural analogy |
| **HWIKI-DOC-28** | Ethan + Colombo | **Class A/B science narrative** — which theories bind core vs TFP/MRT/COBALT (surf hub page) |
| **HWIKI-DOC-29** | Colombo | **Category hub preambles** — Geometry + Core Math + Propagation hubs: “how to read” + theory map |
| **HWIKI-DOC-30** | Colombo | **Coverage-Ledger refresh** — after DOC-02..29, list remaining theory gaps; queue next 30 |

## Exit (wave slice)

- ≥25/30 DONE with quality bar met  
- Category hubs Geometry / Core Math / Propagation readable by a cold agent without prior chat  
- `query_hesperia_wiki` returns enriched Origin/Notes for touched symbols  

SIGNED: Triage (Grace) | HWIKI-DOC 30-task theory-depth grind | 2026-07-19 | HWIKI-DOC
