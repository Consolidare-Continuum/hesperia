# Grace plan — CC_ brand account reservation (2026-07-27)

**CSP:** From Cursor → To Grace (documents manager + secretar + Lane B registry)  
**Reason:** Operator asked Grace to plan account reservation for **consolidare-continuum.com** on npm, PyPI, Docker Hub, Hugging Face, Telegram, X.  
**Project:** `CC_` · **Hygiene:** security · integration  
**Lane:** **B** (public brand / product identity) — not Lane A legal dump. Credentials → **trustmaster custody** (Abelard), never Telegram/chat.

**Already held (do not re-create):**

| Surface | Value |
|---------|--------|
| Domain | `consolidare-continuum.com` (live) |
| Company email | `consolidare_continuum@proton.me` (Proton) |
| GitHub org | `Consolidare-Continuum` (Team paid) |
| MinIO | bucket `consolidare-continuum` |

**Public registry (handles only):** [cluster/consolidare-continuum.com/ACCOUNTS.md](../../cluster/consolidare-continuum.com/ACCOUNTS.md)

---

## Goal

Reserve **one coherent brand identity** across package registries + social before squatters take names. Signup is **operator-gated** after naming lock; Grace owns the matrix, awareness, and SuiteCRM wave.

## Naming lock (proposed — needs operator GO)

Align to existing hyphen / underscore split:

| Rule | Form | Examples already live |
|------|------|------------------------|
| URL / org display | hyphen | `consolidare-continuum.com`, GitHub `Consolidare-Continuum` |
| Email local-part | underscore | `consolidare_continuum@proton.me` |
| Where hyphens forbidden | compact or underscore | Docker Hub often needs compact |

| # | Platform | Preferred handle | Fallback | Probe 2026-07-27 | Account type |
|---|----------|------------------|----------|------------------|--------------|
| 1 | **npm** | org **`@consolidare-continuum`** | user `consolidare-continuum` | registry org/user **404** → likely free | **Org** (scoped pkgs `@consolidare-continuum/*`) |
| 2 | **PyPI** | org **`consolidare-continuum`** | user `consolidare_continuum` | org page **404**; user probe hit CF challenge — re-check at signup | **Org** preferred |
| 3 | **Docker Hub** | **`consolidarecontinuum`** | `consolidare-continuum` | org/user look **free** | **Org** (namespace for images) |
| 4 | **Hugging Face** | org **`consolidare-continuum`** | user same | org/user API **404** → free | **Org** |
| 5 | **Telegram** | **`@consolidare_continuum`** | `@ConsolidareContinuum` | `t.me` contact stubs (claim **in-app**; HTTP alone inconclusive) | User + optional channel later |
| 6 | **X** | **`@consolidare_continuum`** | `@ConsolidareCont` | profile URLs **404** → likely free | Company account |

**Signup email for all:** `consolidare_continuum@proton.me`  
**Website field:** `https://consolidare-continuum.com`  
**Display name:** `CONSOLIDARE CONTINUUM` / `Consolidare Continuum`

### Do not

- Use `prichindel.com` / `agents@prichindel.com` as public identity on these platforms.
- Put passwords, tokens, or recovery codes in brain GitHub, Telegram, or chat.
- Fuse these into prichindel.com personal accounts (keep SRL brand separate).

---

## Phases

### Phase 0 — Plan + triage (this packet)

- [x] Naming matrix + ownership  
- [x] active.md wave  
- [ ] Operator **GO** on preferred handles (or mark fallbacks)

### Phase 1 — Registry reserves (after GO)

Order (product-critical first):

1. **npm** org `@consolidare-continuum`  
2. **PyPI** org `consolidare-continuum`  
3. **Docker Hub** `consolidarecontinuum`  
4. **Hugging Face** org `consolidare-continuum`

Each: create → 2FA on → record recovery to trustmaster → update `ACCOUNTS.md` status.

### Phase 2 — Social reserves (same GO)

5. **Telegram** `@consolidare_continuum` (phone may be required — operator)  
6. **X** `@consolidare_continuum` (phone / verification may be required — operator)

Public bio: company site + Proton contact. No secrets.

### Phase 3 — Custody + awareness

| Who | Duty |
|-----|------|
| **Grace** | Matrix, SuiteCRM, `ACCOUNTS.md`, `CC_/` awareness pointer, CHROMA-1 re-ingest of markdown |
| **Abelard** | Store credentials / recovery / API tokens under **trustmaster** custody; host inventory pointer only |
| **Operator** | Signup sessions, phone OTP, payment if any org billing, final handle GO |
| **Ethan** | Optional ratify if naming becomes policy (after GO) |

---

## Rows (active.md)

| ID | Owner | Intent | Status target |
|----|-------|--------|---------------|
| **CC_-ACCOUNTS-00** | Grace | Triage + this plan | DONE |
| **CC_-ACCOUNTS-01** | Grace | Operator GO on naming matrix → lock `ACCOUNTS.md` | OPEN |
| **CC_-ACCOUNTS-02** | Grace+Op | Reserve **npm** org `@consolidare-continuum` | PAUSED (waits 01) |
| **CC_-ACCOUNTS-03** | Grace+Op | Reserve **PyPI** org `consolidare-continuum` | PAUSED (waits 01) |
| **CC_-ACCOUNTS-04** | Grace+Op | Reserve **Docker Hub** `consolidarecontinuum` | PAUSED (waits 01) |
| **CC_-ACCOUNTS-05** | Grace+Op | Reserve **Hugging Face** org `consolidare-continuum` | PAUSED (waits 01) |
| **CC_-ACCOUNTS-06** | Grace+Op | Reserve **Telegram** `@consolidare_continuum` | PAUSED (waits 01) |
| **CC_-ACCOUNTS-07** | Grace+Op | Reserve **X** `@consolidare_continuum` | PAUSED (waits 01) |
| **CC_-ACCOUNTS-08** | Abelard | trustmaster custody for all created secrets + inventory pointer | PAUSED (waits first create) |
| **CC_-ACCOUNTS-09** | Grace | Keep `ACCOUNTS.md` + `CC_/` awareness current; CHROMA-1 ingest | OPEN (standing) |

## SuiteCRM

`SUITE: YES` on all rows. Sync after write.

## Asked (operator)

Confirm or amend the **Preferred** column, then say **GO accounts** (or per-platform GO). Grace unlocks 02–07.

SIGNED: Triage / plan (Grace) | CC_ accounts reservation | 2026-07-27 | consolidare-continuum.com brand
