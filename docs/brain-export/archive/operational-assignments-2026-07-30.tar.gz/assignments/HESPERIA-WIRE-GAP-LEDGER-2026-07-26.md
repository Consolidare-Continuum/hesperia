# Hesperia wire-gap ledger (2026-07-26)

**Program:** [ETHAN-H070-DAY-RUN-WIRE-GAPS-2026-07-26.md](ETHAN-H070-DAY-RUN-WIRE-GAPS-2026-07-26.md)  
**Seal:** prod+dev `v0.7.0` / `0.7.0` @ `0fcbe899360354c74260ff605787ad2c91bfe355`  
**Status:** EXIT-BAR FILL — Wave 0 DONE · Wave 1 matrix filled · deeper wires CARRY

## Remotes (WIRE-003)

| Tree | Verifier | Result |
|------|----------|--------|
| `/data/hesperia/hesperia` | `scripts/hesperia/verify-hesperia-git-remotes.sh` | **OK** |
| `/data/workspaces/atomic-commit-hesperia` | same | **OK** |
| brain `prichindel.com` | no hesperia product remotes | **OK** |

## Seal tips (WIRE-004)

| Tree | Tag/describe | HEAD |
|------|--------------|------|
| prod | `v0.7.0` | `0fcbe899360354c74260ff605787ad2c91bfe355` |
| dev | `0.7.0` | `0fcbe899360354c74260ff605787ad2c91bfe355` |

## Gate tool snapshot (WIRE-005 / Wave 3)

| Tool | Path | Last run | Result |
|------|------|----------|--------|
| validate_version_consistency | `tools/validate_version_consistency.py` | 2026-07-26 | **OK** `system_version=0.7.0` |
| check_import_boundary | `tools/check_import_boundary.py` | 2026-07-26 | **OK** |
| sealing_scan | `tools/sealing_scan.py` | 2026-07-26 | **OK** |
| verify_public_api_snapshot | `tools/verify_public_api_snapshot.py` | 2026-07-26 | **OK** sha256 `75b932b2…` |
| check_forbidden_zone_imports | `tools/check_forbidden_zone_imports.py` | 2026-07-26 | **OK** |
| validate_shipping_surface | `tools/validate_shipping_surface.py` | 2026-07-26 | **OK** |
| audit_shipping_allowlist | `tools/audit_shipping_allowlist.py` | 2026-07-26 | **OK** imports=28 repo_prefixes=4 third_party=3 |

## Claim→path matrix (Wave 1 · ≥15 rows)

| ID | Claim (wiki/ISO) | Code / CI path | Status | Owner | Notes |
|----|------------------|----------------|--------|-------|-------|
| M01 | SYSTEM layers · `/analyze` | `runtime/shipping/api_main.py` POST `/analyze` · `runtime/services/analysis_service.py` | CLOSED | Felix | Routes gated by `public_capability("analyze")` |
| M02 | SYSTEM · `/product/interpret` | `api_main.py` POST `/product/interpret` · `product_interpret_service.py` | CLOSED | Felix | `public_capability("interpret")` |
| M03 | HOW-IT-WORKS · sealed stack | `analysis_service` → sealed multiscale path | CLOSED | Felix | Stay 0.7.0; no physics change |
| M04 | ground_truth compose | `sphere/router/ground_truth.py` · interpret service | CLOSED | Felix | Claim↔code present |
| M05 | HAND inquire | `sphere/router/tool_inquiry.py` · `tool_inquiry_service.py` | PARTIAL | Felix | Inquire wired; dig narrative = docs+HAND hub — deepen WIRE-025 |
| M06 | APPLY allowlist | `tests/h070/*` · apply allowlist paths | CLOSED | Ava | pytest `tests/h070/` **green** 2026-07-26 |
| M07 | COBALT/REAL_DATA gates | `hesperia/system/capabilities.py` · wiki COBALT hub | CLOSED | Felix | Flags gated; identity ≠ clinical |
| M08 | Shipping import allowlist | `runtime/shipping/shipping_import_allowlist.yaml` | CLOSED | Felix | audit OK |
| M09 | Version authority | `VERSION.yaml` · `pyproject.toml` · validate_version_consistency | CLOSED | Felix | 0.7.0 |
| M10 | Public API snapshot | `tools/verify_public_api_snapshot.py` | CLOSED | Felix | OK |
| M11 | Module registry aliases | `hesperia/engine/module_aliases.py` · `hesperia/modules/{nlp,tfp}` | CLOSED | Felix | See module map |
| M12 | ISO remotes / promote | verify-hesperia-git-remotes · ETHAN remotes policy | CLOSED | Abelard | OK |
| M13 | ISO quality evidence | sealed-runtime-gate tool suite + pytest interpret | CLOSED | Cursor | Recorded this ledger |
| M14 | Identity multipurpose | CLIENTS + structure hubs + Ethan stamp | CLOSED | Colombo | No clinical product framing |
| M15 | Determinism path | `HESPERIA_STRICT_DETERMINISM` · `test_run_product_interpret_deterministic` | CLOSED | Ava | **PASS** |
| M16 | Compare/batch capabilities | `public_capability("compare"|"batch")` in api_main | CLOSED | Gena | Present; soak CARRY |
| M17 | Health endpoint | GET `/health` shipping | CLOSED | Gena | Present |
| M18 | Prod code-only CI | `.github/workflows/prod-code-only.yml` | PARTIAL | Abelard | Exists; live Actions run CARRY WIRE-038 |

## TOP-15 (Ethan bind · WIRE-018) — next grind order

| # | ID | Status |
|---|-----|--------|
| 1 | WIRE-025 | **DONE** — engine_trace path documented |
| 2 | WIRE-019 | **DONE** — capability defaults |
| 3 | WIRE-051/052 | **DONE** — soak recipe + p50/p95 |
| 4 | WIRE-053–055 | **054/055 DONE** · **053b** narrow 3/3 PASS (~313s) · full file slow |
| 5 | WIRE-028 | **DONE** |
| 6 | WIRE-045 | **DONE** |
| 7 | WIRE-047 | **DONE** |
| 8 | WIRE-022 | **DONE** (OpenAPI intentionally off) |
| 9 | WIRE-038 | **DONE** — Actions green |
| 10 | WIRE-058 | **DONE** — harness OK; fixtures accuracy 0 (refresh CARRY-B3) |
| 11 | WIRE-059 | **DONE** — slow list + subset mitigation |
| 12 | WIRE-064 | **DONE** — ISO release fields template |
| 13–15 | … | **CARRY-B3** |

**B1:** [FELIX-H070-WIRE-BATCH-B1-2026-07-26.md](FELIX-H070-WIRE-BATCH-B1-2026-07-26.md) · **B2:** [FELIX-H070-WIRE-BATCH-B2-2026-07-26.md](FELIX-H070-WIRE-BATCH-B2-2026-07-26.md)

### Soak numbers (WIRE-052)

| Surface | N | p50 ms | p95 ms |
|---------|---|--------|--------|
| `run_product_interpret` deterministic | 20 | ~794 | ~844 |
| `compile_router_envelope` (analyze body) | 20 | ~795 | ~838 |

## Tests (Wave 5 sample)

| Test | Result |
|------|--------|
| `tests/test_product_interpret_api.py::test_run_product_interpret_deterministic` | **PASS** |
| `tests/h070/` | **PASS** (8) |

## Identity (WIRE-006)

CLIENTS + structure hubs cite multipurpose stamp; clinical only as **label/gate language**, not product identity. **PASS**.

SIGNED: Cursor (+Abelard/Felix/Colombo/Ava faces) | wire-gap ledger | 2026-07-26 | exit-bar fill
