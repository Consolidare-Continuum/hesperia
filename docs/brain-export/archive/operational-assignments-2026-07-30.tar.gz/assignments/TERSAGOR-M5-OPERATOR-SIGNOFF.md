# Tersagor M5 operator sign-off (before prod triage)

**Date:** 2026-06-21  
**Project:** tersagor-sdk M5 (TSDK-051..080)  
**Policy:** `TERSAGOR_TRIAGE_AGENT_ENABLED=0` until this checklist is signed.  
**Operator decision 2026-06-21:** **YES** — enable Tersagor **routing agent** (SDK handoffs). Not Grace triage. Ref: [TERMS-ROUTING-AGENT-VS-GRACE-TRIAGE.md](../../governance/TERMS-ROUTING-AGENT-VS-GRACE-TRIAGE.md).

---

## Preconditions (team must complete)

- [x] `deploy/deploy-on-vm.sh` ends with M4 **10/10** + IRC mesh **2/2** green
- [x] `pytest tests/test_forwarder_mesh.py tests/test_irc_mesh_glue.py` green on dev + CI
- [x] VM snapshot doc: [cluster/tersagor/M5-DEPLOY-SNAPSHOT.md](../cluster/tersagor/M5-DEPLOY-SNAPSHOT.md)
- [x] Runbook: [M5-IRC-MESH-CONFIDENCE.md](https://github.com/igareosh/tersagor/blob/main/docs/M5-IRC-MESH-CONFIDENCE.md)

---

## Operator verification (igareosh)

- [x] Reviewed M5 closure packet / Abelard TSDK-080 report
- [x] Ran or witnessed `smoke_irc_mesh_glue.py` on tersagor VM (or trust deploy log)
- [x] Comfortable with forwarder→mesh path; no live eggdrop change required yet
- [x] **Decision:** enable prod **routing agent**? **YES**

If **NO:** leave `TERSAGOR_TRIAGE_AGENT_ENABLED=0`; file follow-up via Grace triage (workflow).

If **YES:** Abelard applies `deploy/sdk-openai-prod.flags` + redeploy; monitor `#agents-ingest`.

---

## Sign-off

| Field | Value |
|-------|--------|
| Operator | igareosh |
| Date | 2026-06-21 |
| Decision | YES — full OpenAI Agents SDK stack on (`sdk-openai-prod.flags`) |

SIGNED: Grace | M5 operator sign-off DONE | 2026-06-21 | tersagor-sdk
