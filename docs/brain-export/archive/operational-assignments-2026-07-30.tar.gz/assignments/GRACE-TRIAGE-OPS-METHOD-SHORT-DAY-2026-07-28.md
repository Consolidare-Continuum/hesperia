# Grace triage — SHORT DAY: SQL exercise↔statement links + moons edge densify

**Date:** 2026-07-28 · **Owner:** Grace  
**Trigger:** Operator — densify 1259/5149 via SQL links; call **shortened day**  
**No OpenAI invent/classify/embed.**

## Rows

| ID | Owner | Task |
|----|-------|------|
| **OPS-METHOD-SHORT-00** | Grace | This triage |
| **OPS-METHOD-SHORT-01** | Felix | SQL fill `linked_statement_ids` (evidence + page window) |
| **OPS-METHOD-SHORT-02** | Felix | Re-attach `edge_id` — linked STMs + page±1 approved logical edges |
| **OPS-METHOD-SHORT-03** | Ava | Smoke edge rate + `/tasks/{id}` relations |
| **OPS-METHOD-SHORT-04** | Ethan | Sign **SHORT-DAY-READY** |

SIGNED: Triage (Grace) | SHORT DAY link densify | 2026-07-28 | ops-method
