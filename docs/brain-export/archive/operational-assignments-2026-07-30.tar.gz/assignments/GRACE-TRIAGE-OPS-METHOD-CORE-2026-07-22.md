# Grace triage — ops-method CORE harden wave

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01
**Trigger:** Operator — gap audit ([OPS-METHOD-V1-READY.md](../../projects/ops-method/OPS-METHOD-V1-READY.md)) then "adopt ethan plan me a spec to address each with tasking team."
**Source:** [ETHAN-PLAN-CORE-HARDEN-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-CORE-HARDEN-2026-07-22.md)
**FREEZE:** intact — Workstreams A + C are the freeze-exit criteria themselves. Workstream F is second-book *prep*, which `FREEZE-UNTIL-BOOK-COMPLETE.md`'s Means table names as explicitly forbidden while HOLD — see plan §7. **CORE-F-02/F-04 do not go OPEN until Grace logs the operator carve-out as a line in `FREEZE-UNTIL-BOOK-COMPLETE.md`, same pattern as the 2026-07-22 MAP-05/CORP-04/05/CSS-13 archival edit.** CORE-F-01/F-03 (design only, no schema/content) may proceed.

## Rows to add → active.md

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-CORE-00** | Grace | P0 | Triage CORE wave (this file) + SuiteCRM sync |
| **OPS-METHOD-CORE-A01** | Ethan | P0 | Ratify review-queue auto-accept policy (threshold + excluded types) |
| **OPS-METHOD-CORE-A02** | Felix | P0 | `review_clear_batch.py` — dry-run-first, envelope-logged |
| **OPS-METHOD-CORE-A03** | Ava | P0 | Precision audit ≥100 sample, ≥98% bar |
| **OPS-METHOD-CORE-A04** | Grace | P0 | Weekly queue-count tracking; escalate on audit fail |
| **OPS-METHOD-CORE-B01** | Ethan | P1 | Ratify action/state-required step categories |
| **OPS-METHOD-CORE-B02** | Felix | P1 | Coverage report (action_step/statement_state gaps by category) |
| **OPS-METHOD-CORE-B03** | Felix + Colombo | P1 | Gap-fill in-scope category (supersedes archived CSS-13 — Ethan to confirm) |
| **OPS-METHOD-CORE-B04** | Ava | P1 | Smoke coverage report vs. target ratio |
| **OPS-METHOD-CORE-C01** | Colombo | P0 | Run dictionary activation A4 (book-grounded gloss_ru) |
| **OPS-METHOD-CORE-C02** | Felix | P0 | Batch/API support for A4 |
| **OPS-METHOD-CORE-C03** | Colombo + Ethan | P0 | Sign semantics COMPLETE (freeze-exit criterion 2) |
| **OPS-METHOD-CORE-D01** | Felix | P1 | Rebalance `requires`-overweight edges |
| **OPS-METHOD-CORE-D02** | Felix + Abelard | P1 | Install pgvector, persist real embedding vectors |
| **OPS-METHOD-CORE-D03** | Felix | P1 | Cross-chapter edge pass (post-D02) |
| **OPS-METHOD-CORE-D04** | Ava | P1 | Verify relation-type distribution + thin-tail review |
| **OPS-METHOD-CORE-E01** | Felix + Colombo | P2 | Harvest additional SIPOC frames per SIPOC-READY.md plan |
| **OPS-METHOD-CORE-E02** | Ava | P2 | Verify zero false-positive contradictions at scale |
| **OPS-METHOD-CORE-F01** | Ethan | P1 | Ratify author/cross-pack data model (design only) |
| **OPS-METHOD-CORE-F02** | Felix + Marcus | HOLD | Cross-pack schema migration — **gated on Grace carve-out log** |
| **OPS-METHOD-CORE-F03** | Colombo | P1 | Author-level shared-vocabulary policy (design only) |
| **OPS-METHOD-CORE-F04** | Ava | HOLD | Synthetic dummy-pack smoke test — **gated on Grace carve-out log** |
| **OPS-METHOD-CORE-99** | Ethan | P0 | Sign freeze-exit when A+C both COMPLETE — triggers Grace unfreeze triage per `FREEZE-UNTIL-BOOK-COMPLETE.md` |

## Sequencing

A + C run parallel now (P0, both freeze-exit-blocking). D depends on A (rebalance after auto-accept policy cuts noise). B and E proceed independently. F01/F03 (design) proceed now; F02/F04 HOLD until Grace logs the carve-out.

SIGNED: Triage (Grace) | CORE harden wave | 2026-07-22
