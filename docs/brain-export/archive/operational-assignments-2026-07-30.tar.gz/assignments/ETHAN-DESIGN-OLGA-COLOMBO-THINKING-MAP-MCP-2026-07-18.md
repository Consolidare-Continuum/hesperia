# Ethan design — Olga Colombo thinking-map MCP

**Date:** 2026-07-18  
**Authority:** Ethan (architecture) · Operator-approved design (sections 1–3)  
**Status:** DESIGN APPROVED — await Grace triage → active.md rows before implement  
**Package:** [fpf-thinking-map](https://pypi.org/project/fpf-thinking-map/) pin `==1.5.0` (same as brain)

---

## Intent

Olga’s Cursor (`igareosh/olga`, user `olga` on **altitudine**) needs a **separate** MCP with **fpf-thinking-map** capabilities, adapted for Colombo clinical scopes — **omnipresent** on every meaningful turn (search, inspect, analyze, answer).

Not a copy of team ATM workflow gates. Library is fine; **MCP + domain map + rules** must be Olga-adapted.

---

## Product shape (approved)

| Item | Value |
|------|--------|
| **MCP name** | `olga-colombo-thinking-map` |
| **Host** | **altitudine**, Linux user `olga`, **local** process (no SSH hop for this MCP) |
| **Repo** | `github.com/igareosh/olga` → `/home/olga/olga-work` |
| **Engine** | PyPI `fpf-thinking-map==1.5.0` |
| **Primary map** | `colombo_clinical` |
| **When** | Every Colombo turn that searches, answers, inspects, or analyses |
| **Not in this MCP** | `team_ops`, `cluster_ops`, `eod_ops`, Grace/active.md, cluster SSH gates, brain hard-shutdown |
| **Speak to Olga** | No ATM jargon — silent scaffold; she sees answers |

---

## Domain map — `colombo_clinical`

**Context id:** `olga_tfp`  
**Role:** `colombo` only

### States

`orient` → `search` → `inspect` → `analyze` → `answer` → (loop on follow-up)

### Evidence tokens

| Token | Meaning |
|-------|---------|
| `chroma2_ru_query_done` | CHROMA-2 / `colombo-library` query in Russian |
| `chroma1_crosscheck_done` | Optional CHROMA-1 when theory contested |
| `repo_cases_checked` | `cases/` / `references/` when clinical |
| `sources_cited` | Answer cites retrieved sources |
| `uncertainty_labeled` | LLM-only gaps labeled |

### Gates (clinical quality — not team approval)

| Gate | Before | Requires |
|------|--------|----------|
| `corpus_gate` | Science/theory answer | `chroma2_ru_query_done` |
| `answer_gate` | Final answer | `sources_cited` (+ `uncertainty_labeled` if corpus miss) |

### Logic (examples)

- Science claim without corpus → `COLLECT_EVIDENCE` (`chroma2_ru_query_done`)
- Multi-source conflict → stay in `inspect` / `analyze`
- Greeting / meta → short path, no block

Aligns with existing answer hierarchy in `SPEC-COLOMBO-OLGA-CHROMA2.md`: CHROMA-2 RU → CHROMA-1 → cache → repo → LLM last.

---

## MCP tools

**Olga maps only** + **in-MCP CHROMA-2** (same `query_library_guarded` as `colombo-library`, profile `tfp_ru`):

| Tool | Purpose |
|------|---------|
| `clinical_locate_step` | **Primary** — CHROMA-2 search + map step; returns `sources_to_address` / `library_hit` + merged evidence |
| `library_search` | CHROMA-2 only (guarded) |
| `list_thinking_maps` | `colombo_clinical` (+ later maps) |
| `thinking_map_verify` | Package health |
| `thinking_map_step` | Map; `auto_library=true` pulls CHROMA-2 |
| `get_thinking_map_slice` | Debug |

Standalone `colombo-library` MCP remains for catalog / ingest / facets. Map MCP = locate+move, not ingest.

Shipped: `igareosh/olga` @ `8cfc103` (library integrate) → **productized permanent** @ `3d5f255` (selfcheck + self-restarting deploy + tool-first rule). Closeout: [reports/OLGA-ATM-PRODUCTIZE-2026-07-18.md](reports/OLGA-ATM-PRODUCTIZE-2026-07-18.md).

---

## Deploy path (altitudine / `olga`)

1. venv under `/home/olga/` (or reuse existing Olga Python env) + `pip install fpf-thinking-map==1.5.0`
2. Code in `igareosh/olga`:
   - `agent_mcp_olga_thinking_map/` (FastMCP wrapper)
   - `thinking_maps/colombo_clinical/` (domain map)
3. Wire into `governance/mcp-config.json` → `scripts/deploy-olga-mcp.sh` + `olga-ide-preflight.sh`
4. Rules: `.cursor/rules/colombo-only.mdc` + clinical rule — call `thinking_map_step` every meaningful turn; obey library JSON
5. Update `AGENTS.md` / `OLGA-CONTEXT.md` / `SPEC-COLOMBO-OLGA-CHROMA2.md` MCP section
6. Verify: `thinking_map_verify` PASS; sample clinical turn returns `COLLECT_EVIDENCE` without corpus token

**Do not** add this server to team brain `governance/mcp-config.json` as a substitute for `cursor-thinking-map`.

---

## Ownership (proposed Grace wave)

| Owner | Work |
|-------|------|
| **Ethan** | This design; ratify exit criteria |
| **Felix** | MCP module + `colombo_clinical` map + tests |
| **Abelard** | altitudine venv/path/permissions if Felix blocked |
| **Colombo** | Rules + SPEC wording in `igareosh/olga` (Olga iteration) |
| **Grace** | Triage → active.md rows + SuiteCRM |

---

## Exit criteria

- [ ] MCP listed in Olga `mcp.json` (user + project) after preflight
- [ ] `list_thinking_maps` returns only Olga maps
- [ ] `thinking_map_verify` PASS on altitudine as `olga`
- [ ] Rules mandate omnipresent step; no team_ops leakage
- [ ] Smoke: theory question without library call → `COLLECT_EVIDENCE` / `chroma2_ru_query_done`
- [ ] Olga chat stays jargon-free (agent-internal map only)

---

## Explicit non-goals

- Brain `thinking_map_mode` hard-gate / exit 42 for Olga repo
- Cloning `team_ops` into clinician Cursor
- Ingesting map runtime JSON into Papra / CHROMA-2
- Replacing `colombo-library` or formalization path — map **augments** LOCATE/FORMALIZE

Ref: brain [agents/colombo/THINKING-MAP-VS-FORMALIZATION.md](../../agents/colombo/THINKING-MAP-VS-FORMALIZATION.md) · workspace [cluster/olgahere/OLGA-COLOMBO-WORKSPACE.md](../../cluster/olgahere/OLGA-COLOMBO-WORKSPACE.md)

SIGNED: Team lead (Ethan) | Olga Colombo thinking-map MCP design | 2026-07-18 | sections 1–3 operator-approved
