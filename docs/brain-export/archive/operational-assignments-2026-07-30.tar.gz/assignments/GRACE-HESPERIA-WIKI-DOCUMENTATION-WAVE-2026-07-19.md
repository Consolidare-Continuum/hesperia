# Grace triage packet — Hesperia wiki documentation wave

**Date:** 2026-07-19  
**From:** Cursor (operator intent)  
**To:** Grace — triage into `active.md` / assignments as sized rows  
**Do not** invent rows until Grace triages.

## Intent

Hesperia first serious release is wrapping. Team needs durable, surfable documentation of **what we do in/with the product, why, and how** — not only awareness. The parameter/variable wiki is the hub; ~**100–200** task runs will document and **link product** into that hub (and related specs).

## Hub (already live)

- Onboarding: `colombo_research/hesperia/wiki/CLAUDE.md`
- Index: `colombo_research/hesperia/wiki/index.md`
- Serve: `http://192.168.100.65:8901/index.html`
- Policy: `governance/HESPERIA-PARAMETER-WIKI-SOURCE.md`
- Coverage gaps: `colombo_research/hesperia/wiki/Coverage-Ledger.md`

## Suggested batching (Grace sizes)

| Batch | Owner default | Theme |
|-------|---------------|--------|
| W1 | Colombo | Fill Coverage-Ledger gaps (L1–L11 vars, KME metrics, TRIZ) into generator |
| W2 | Felix | Link wiki pages ↔ live Python modules / tests in `igareosh/hesperia` |
| W3 | Gena | Java-ancestor ↔ LIVE successor crosswalk pages (audit leftovers) |
| W4 | Colombo + Ethan | Why/how product narratives per Class A/B branch (TFP/MRT/COBALT/core) |
| W5 | Cursor | MCP/Chroma re-ingest after each material wiki regen; agent-rule drift checks |

Prefer many small OPEN rows (one symbol family or one module) over megatasks. Link: `SUITE: YES` when operator board visibility helps.

## Done when

- Coverage-Ledger open items either wikified or explicitly deferred with owner
- Agents resolve param status via `layer=hesperia_wiki` or wiki URL without chat archaeology
- Product docs/specs point at wiki for math symbols (no duplicate registers)

SIGNED: Cursor | Grace wiki documentation wave packet | 2026-07-19 | triage input
