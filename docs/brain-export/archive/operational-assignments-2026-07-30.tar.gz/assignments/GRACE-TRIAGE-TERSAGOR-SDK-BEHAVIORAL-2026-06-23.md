# Grace triage — Tersagor SDK behavioral polish (post-IRC debug)

**Date:** 2026-06-23  
**Source:** Operator — tomorrow sprint runtime green; `#agents-debug` alive; shift to **behavioral** quality.  
**Prior:** [GRACE-TRIAGE-TERSAGOR-SDK-TOMORROW-2026-06-23.md](GRACE-TRIAGE-TERSAGOR-SDK-TOMORROW-2026-06-23.md) · prod `2df3a31` deployed

---

## Triage outcome

**PROJECT-CONTINUED — TERSAGOR-SDK-BEHAVIORAL** — **2026-06-23** — **TSDK-W42** meta + **4 Gena OPEN** rows (**127–130**). Register: [TSDK-UPGRADE-2026-REGISTER.md](../../governance/TSDK-UPGRADE-2026-REGISTER.md).

**One sentence:** Runtime/deploy smokes green; next = fix prod `deploy_hints` error, tighten status/cluster routing to Abelard direct paths, dry-run venv hygiene, regression asserts on operator commands.

---

## Evidence (IRC debug / forwarder trace)

| Signal | Observation |
|--------|-------------|
| Runtime | `imirc-tersagor-presence`, forwarder, mesh, MCP E2E — **green** post-deploy |
| `#agents-debug` | Trace + mirror traffic live (mesh_executor, telegram, colombo) |
| **Errors** | `deploy_hints` UnboundLocalError on deploy-flavored Abelard objectives (~7/100 forwarder traces) |
| **Behavior** | Same status family sometimes `abelard_executed` / `local_status`, sometimes generic LLM wrap-up (`executed` + waffle text) |
| **Hygiene** | `deploy_dry_run_altitudine.py` uses system `python3` (no pytest) on VM |

---

## Gena run order (mandatory)

| Order | ID | Theme |
|-------|-----|--------|
| **1** | **127** | Fix `deploy_hints` prod error + pytest repro |
| **2** | **128** | Status/cluster routing — prefer Abelard `_try_direct_*` before Status-agent LLM |
| **3** | **129** | `deploy_dry_run_altitudine.py` — mesh venv / `sdk_dev_venv.sh` for pytest |
| **4** | **130** | Extend `daily_operator_regression` or parity — assert no generic status waffle on operator cmds |

---

## Still blocked / deferred

| ID | Reason |
|----|--------|
| **TSDK-091** | **PAUSED** — permanently out of scope (operator 2026-06-29); soak deferred |
| **TSDK-093** | **PAUSED** — permanently out of scope (operator 2026-06-29); GA sign-off deferred |
| **088, 100, 102, 103** | **PAUSED** — measure/spike defer |

---

## Operator commands (must stay green)

`!agent status` · `!agent abelard cluster services status` · `!agent abelard list cluster online vms` · `!agent abelard status on alunel`

After **127–130**: forwarder trace should show **zero** `deploy_hints` errors; operator cmds should prefer `abelard_executed` / `local_status` over generic `executed` waffle.

---

SIGNED: Grace (triage) | behavioral wave post-IRC-debug | 2026-06-23 | tersagor-sdk-behavioral
