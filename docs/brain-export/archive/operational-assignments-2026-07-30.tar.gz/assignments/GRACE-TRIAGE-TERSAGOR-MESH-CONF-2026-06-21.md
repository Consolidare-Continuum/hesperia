# Grace triage — Tersagor M5: IRC mesh glue confidence (30 tasks)

**Date:** 2026-06-21  
**Source:** Operator — M4 build looks good but **not trusted** until deploy + IRC mesh glue is exercised end-to-end.  
**Canonical task list:** `tasks/AGENTS-SDK-MESH-30-TASKS.md` on **igareosh/tersagor** (`/data/tersagor`).

---

## Triage outcome

**PROJECT-EXTENDED — TERSAGOR-SDK M5** — **2026-06-21** — **TSDK-W51 + TSDK-051..080** (31 rows) on [active.md](../../active.md); register [TSDK-MESH-CONF-2026-REGISTER.md](../../governance/TSDK-MESH-CONF-2026-REGISTER.md).

**One sentence:** 30 atomic confidence tasks (deploy, forwarder→mesh→orchestrator, IRC smokes, M5 operator gate) before igareosh touches prod triage.

**Trust gate:** **M5** = TSDK-077 + TSDK-080 green on tersagor VM; `TERSAGOR_TRIAGE_AGENT_ENABLED=0` until operator sign-off (TSDK-079).

---

## Why (operator)

M4 closed with scripted VM smokes (orchestrator in-process). That does **not** prove:

- eggdrop/forwarder → mesh `POST /run` → orchestrator
- IRC envelope v1 (`source=irc`, `#agents-ingest`, `irc_recent_messages`)
- deploy-on-vm timing (mesh restart race)
- correlation_id / trace_events on the glue path

M5 exercises **IRC mesh glue** explicitly.

---

## Milestones

| Milestone | Task range | Owner lead | Gate |
|-----------|------------|------------|------|
| **M5a** | 051–056 | Abelard + Felix | deploy + CI smoke extensions |
| **M5b** | 057–067 | Gena + Felix | forwarder/mesh unit + integration pytest |
| **M5c** | 068–077 | Abelard + Felix + Gena | VM irc-mesh-smoke + runbook |
| **M5d** | 078–080 | Grace + Abelard | prod safety + operator sign-off |

---

## Operator command (executed)

```
Grace, task team 30 more including deployment and testing via irc mesh glue
to gain confidence before I touch it.
```

---

SIGNED: Grace (triage) | M5 mesh confidence wave | 2026-06-21 | tersagor-sdk
