# Grace triage — Canonical traversal amplification + chapter resolve

**Triage owner:** Grace · **Date:** 2026-07-22 · **Pack:** SRC-RYB-ED01  
**Trigger:** Operator — amplify/surface canonical traversal relations first; optional kept; canonical call traverse+resolve chapters for clearer API structures.  
**Plan:** [ETHAN-PLAN-CANONICAL-TRAVERSE-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-CANONICAL-TRAVERSE-2026-07-22.md)  
**Freeze:** HOLD · no second book · MAP-05/CORP/CSS-13 PAUSED  

## Rows

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-TRAV-00** | Grace | P0 | Triage this wave |
| **OPS-METHOD-TRAV-01** | Ethan | P0 | Ratify canonical vs optional tier lock |
| **OPS-METHOD-TRAV-02** | Felix | P0 | Views `step_next_canonical` / `step_next_optional` + ranked list_next |
| **OPS-METHOD-TRAV-03** | Felix | P0 | Amplify: within-chapter `precedes` gap-fill (resume ledger) |
| **OPS-METHOD-TRAV-04** | Felix | P0 | Amplify: chapter-bridge `precedes` N→N+1 |
| **OPS-METHOD-TRAV-05** | Felix | P0 | API `POST /canonical/resolve-chapters` + envelope verb |
| **OPS-METHOD-TRAV-06** | Felix | P1 | API `list_next?tier=canonical\|optional\|all` |
| **OPS-METHOD-TRAV-07** | Gena | P1 | UI: Resolve chapters + show spine per chapter |
| **OPS-METHOD-TRAV-08** | Liam | P1 | Runbook update — canonical traverse call |
| **OPS-METHOD-TRAV-09** | Ava | P0 | Smoke: resolve-chapters ≥5 chapters with spine |
| **OPS-METHOD-TRAV-10** | Ethan | P0 | Sign **TRAV-CANON-READY** |

## Sequencing

00→01→02→(03∥04)→05→06→07→08→09→10.

SIGNED: Triage (Grace) | TRAV canonical amp | 2026-07-22 | chapters resolve
