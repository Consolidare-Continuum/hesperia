# Grace triage — atm-wp-publisher productize (Atomic-Commits-Team)

**Date:** 2026-07-14  
**Source:** Operator chat — Ethan leads team push of `igareosh/wfh` solution into **Atomic-Commits-Team** as product `fpf-atm-wordpress-publisher`; Felix + Colombo own programming/docs in `igareosh/wfh`; Claude Code must **not** be prompted with Atomic-Commits-Team remotes.  
**Prior row:** **ATM-WP-PUB-01** (Felix) — DONE — v0.1 in `igareosh/wfh`, plugin active on wellfedhippo.com.

---

## Triage outcome

**PROJECT-CREATED — ATM-WP-PROD** — 2026-07-14 — productization of the agentic WordPress publisher into Atomic Commits Team.

**One sentence:** Treat `igareosh/wfh` as the **dev / Claude Code surface** and `Atomic-Commits-Team/fpf-atm-wordpress-publisher` as the **prod product line**; Ethan owns governance + prod push coordination; Felix/Colombo continue code and ISO docs only in `wfh`.

---

## Readiness (confirmed 2026-07-14)

| Check | Result |
|-------|--------|
| Source repo | `https://github.com/igareosh/wfh` — private; codespace `.devcontainer` present |
| Product layout | `plugin/` + `mcp/` + `docs/` (REQUIREMENTS/ARCHITECTURE/API/DEPLOYMENT) + `tests/e2e/` |
| ATM gate | `publish_map.py` via fpf-thinking-map — publish/trash evidence-gated |
| Safety NFR-1 | `_atm_managed=1` choke — live site has 35 unmanaged posts protected |
| wellfedhippo deploy | Plugin **atm-wp-publisher 0.1.0 active**; user `atm-publisher-bot` role `atm_publisher` |
| Prod GitHub | `Atomic-Commits-Team/fpf-atm-wordpress-publisher` — **exists, empty** — ready for first seed |

---

## Context split (mandatory — operator)

| Surface | Repo | Who | Prompting rule |
|---------|------|-----|----------------|
| **Claude Code / Felix+Colombo coding** | `igareosh/wfh` only | Felix (impl), Colombo (ISO docs) | **Do not** mention Atomic-Commits-Team, prod remotes, or brain push policies in Claude prompts |
| **Team / Cursor / Ethan prod** | `Atomic-Commits-Team/fpf-atm-wordpress-publisher` | Ethan lead; Abelard executes git seed/push | Brain governance + ACT remotes live here only |

Mirrors Hesperia pattern (`igareosh/hesperia` vs `Atomic-Commits-Team/hesperia`) without putting that pattern into Claude session context.

Policy file: [governance/ETHAN-POLICY-ATM-WP-PUBLISHER-REMOTES.md](../../governance/ETHAN-POLICY-ATM-WP-PUBLISHER-REMOTES.md).  
ACT partners: [governance/ETHAN-POLICY-ATOMIC-COMMITS-TEAM-PARTNERS.md](../../governance/ETHAN-POLICY-ATOMIC-COMMITS-TEAM-PARTNERS.md) — **[TDYK](https://github.com/TDYK)** org admin / equal share; word = igareosh until scandal.

---

## Scope (in)

- Seed + maintain prod product repo under Atomic-Commits-Team
- Ethan remotes / release / Claude-isolation policy
- Colombo ISO freeze for v0.1 product packet
- Abelard: ACT seed push + wellfedhippo deploy awareness (no Claude)
- Productization reuse docs already in `wfh` (generic plugin install path)

## Scope (out)

- Pages/media/comments/multisite (already out of v1 REQUIREMENTS)
- Teaching Claude about ACT org
- Mixing brain-repo Cursor automation prompts into `wfh` Claude sessions

---

## Wave rows (active.md)

| ID | Owner | Unit |
|----|-------|------|
| **ATM-WP-PROD-00** | Grace | This triage packet · SuiteCRM — DONE |
| **ATM-WP-PROD-01** | Ethan | Ratify remotes + Claude-isolation policy — DONE |
| **ATM-WP-PROD-02** | Abelard | Seed empty ACT repo from `igareosh/wfh` @ v0.1 tag/commit |
| **ATM-WP-PROD-03** | Colombo | ISO docs freeze (REQUIREMENTS/ARCHITECTURE/API/DEPLOYMENT) for product release |
| **ATM-WP-PROD-04** | Felix | wfh-only closure: e2e green + release notes in `igareosh/wfh` (no ACT remotes in session) |
| **ATM-WP-PROD-05** | Ethan | Release criteria seal + CLIENTS/GITHUB-REPOS awareness pointers |

---

## Advice (productization — WordPress)

1. **Keep the custom plugin** — correct vs core `wp/v2/posts` (NFR-1 managed-post guard + narrow surface). Do not regress to full core REST for the agent account.
2. **Application Passwords + HTTPS** — stay the only external auth path; document canonical URL (no 301) in DEPLOYMENT.
3. **First customer install** — zip of `plugin/atm-wp-publisher/` via wp-admin Upload is the product story; wellfedhippo wp-cli path is operator convenience only.
4. **Optional later (not v0.1):** Gutenberg block / settings page is out — stay zero-UI; audit stays `error_log` prefix.
5. **Content path:** agent publishes from git `.md` via MCP; plugin never sees git — keep that boundary.

---

SIGNED: Triage (Grace) | ATM-WP productize | 2026-07-14 | atm-wp-publisher → Atomic-Commits-Team
