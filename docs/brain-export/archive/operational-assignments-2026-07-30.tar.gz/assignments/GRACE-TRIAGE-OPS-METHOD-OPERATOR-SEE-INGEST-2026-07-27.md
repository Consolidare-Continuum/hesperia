# Grace triage — ops-method operator SEE ingest (proof, not re-ingest)

**Date:** 2026-07-27 · **Owner:** Grace  
**Trigger:** operator — "grace triage, i wont leave you until i see those books ingested"  
**Upstream:** [SERIES-CORPUS-READY.md](../../projects/ops-method/SERIES-CORPUS-READY.md) · [GRIND-CORPUS-READY.md](../../projects/ops-method/GRIND-CORPUS-READY.md) · Day7+ / grind waves DONE

## Hold the line

Day 7–10 remaining-four + twin **are already ingested** into PostgreSQL (`ops_method`). Ethan signed `SERIES-CORPUS-READY`. Grind wave signed `GRIND-CORPUS-READY`. **Do not reopen** invent-extract / Day7–10 rows.

What was missing for the operator: a **single visible proof** (PDF → pack → pages → statements → embeddings → READY), not another silent DONE stamp.

## Product intake (locked)

| Need | Decision |
|------|----------|
| Re-run OpenAI LTS invent on FTB/Poels/PLX | **NO** — overlay/sparse pattern; already done |
| Full invent on PAY-A twin (274pp) | **NO** unless new operator ask — Day10 was **sample** twin edges by design |
| Operator-visible corpus proof | **YES** — this wave |
| Retrieval smoke per Day7–10 pack | **YES** — Ava |

## Live PG snapshot (triage verify 2026-07-27)

| Pack | PDF pages | pages_seg | stmts | emb | Role |
|------|----------:|----------:|------:|----:|------|
| `SRC-FTB-GLOSS` | 14 | 14 | 172 | 172 | Day7 lexicon overlay |
| `SRC-POELS-MAPS` | 25 | 25 | 550 | 550 | Day8 map overlay |
| `SRC-PLX-FORMAL` | 21 | 21 | 494 | 494 | Day9 formal overlay |
| `SRC-PAY-LIVE-A` | 274 | 274 | 918 | 918 | Day10 twin sample |
| `SRC-PAY-LIVE` | 362 | 362 | 4430 | 1698 | #6 living-org (prior) |
| `SRC-RYB-ED01` | 393 | 393 | 5660 | 5158 | CORE how |
| `SRC-RYB-ORDER` | 404 | 405 | 5024 | 1250 | when |
| `SRC-RYB-STRAT` | 224 | 225 | 2053 | 900 | what |
| `SRC-SR-BP-DIGEST` | 41 | 41 | 1094 | 300 | digest |

All 9 PDFs under `colombo_research/business_process/` are registered and segmented.

## Rows

| ID | Owner | Task | Status at triage |
|----|-------|------|------------------|
| **OPS-METHOD-SEE-00** | Grace | This triage | DONE (this packet) |
| **OPS-METHOD-SEE-01** | Felix | Emit [CORPUS-INGESTION-PROOF.md](../../projects/ops-method/CORPUS-INGESTION-PROOF.md) — live counts + sample stmt + PDF path per pack | OPEN → execute immediately |
| **OPS-METHOD-SEE-02** | Ava | Retrieval smoke: ≥1 hit each for FTB / Poels / PLX / PAY-A | OPEN |
| **OPS-METHOD-SEE-03** | Ethan | Sign **OPERATOR-CORPUS-VISIBLE** after SEE-01+02 | OPEN |

**Triage outcome:** PROJECT-CREATED — proof/visibility wave only. Ingestion stays closed.

SIGNED: Triage (Grace) | operator SEE ingest proof wave | 2026-07-27 | ops-method
