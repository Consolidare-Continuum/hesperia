# Felix/Cursor — H070-WIRE batch B2

**Date:** 2026-07-26  
**After:** B1 · `H070-WIRE-CARRY-B2`  
**Seal:** stay `0.7.0` @ `0fcbe899`

## Closed this batch

| ID | Result |
|----|--------|
| **053-subset** | Narrow smoke **3/3 PASS** in **313s** (`analyze_sentence`, `sealed_multiscale`, `capability_matrix`). Full file / `run_e2e_all*` remain **slow** — exclude from default grind. |
| **059** | Pain: `run_e2e_all*` (+ heavy TFP/DLCR). Even “narrow” e2e ~5min (engine cost). **Mitigation:** subset command below; recommend `@pytest.mark.slow` on `run_e2e_all*` in next product PR. |
| **058** | Benchmark harness **runs**. `tests/test_product_benchmarks.py` **PASS** (report schema). Eval accuracy on fixtures currently **0.0** matched — harness still useful; fixtures/profile expectations **stale** → ticket for Felix/Gena fixture refresh (no version bump). |
| **064** | ISO release-notice field template — [CURSOR-H070-WIRE-064-ISO-RELEASE-FIELDS-2026-07-26.md](CURSOR-H070-WIRE-064-ISO-RELEASE-FIELDS-2026-07-26.md) |

## Recommended grind e2e command (053)

```bash
cd /data/hesperia/hesperia
export PYTHONPATH=. HESPERIA_STRICT_DETERMINISM=1
# Verified 2026-07-26: 3 passed in ~313s — use this as default grind e2e
python3 -m pytest \
  tests/test_e2e_flows.py::test_e2e_analyze_sentence_output_exists \
  tests/test_e2e_flows.py::test_e2e_sealed_multiscale_artifact \
  tests/test_e2e_flows.py::test_e2e_capability_matrix_wires_blocks \
  -q --tb=line
# Do not run unfiltered test_e2e_flows.py or run_e2e_all* in default grind loops
```

## Slow list (exclude from default grind)

- `test_e2e_run_e2e_all_produces_all_artifacts`
- `test_e2e_run_e2e_all_optional_dlcr_artifact`
- `test_e2e_tfp_smoke_with_dlcr_bundles` (heavy)
- Full file unfiltered (hung >9m in B1)

## Benchmark (058) snapshot

| Set | total | matched | accuracy |
|-----|-------|---------|----------|
| llm_audit | 3 | 0 | 0.0 |
| tfp_analysis | 3 | 0 | 0.0 |
| document_fingerprint | 2 | 0 | 0.0 |

**Verdict:** tool path OK · fixture expectations need refresh (CARRY-B3 optional).

## CARRY-B3 (optional) — parked at run close

- Product PR: `pytest.mark.slow` + `addopts` keep default `-m "not slow"`  
- Refresh product_benchmark fixtures  
- Remaining day-plan IDs beyond TOP-15  

**Disposition:** deferred — [CURSOR-H070-WIRE-RUN-CLOSE-2026-07-26.md](CURSOR-H070-WIRE-RUN-CLOSE-2026-07-26.md).

SIGNED: Developer (Felix) · Cursor | H070-WIRE batch B2 | 2026-07-26 | subset · ISO fields · bench note · B3 parked
