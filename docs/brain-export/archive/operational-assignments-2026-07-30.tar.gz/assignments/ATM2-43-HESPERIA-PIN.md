# ATM2-43 — Hesperia fpf-thinking-map pin

**Result (2026-07-23):** applied on altitudine data-root (uncommitted).  
**Shelved (2026-07-25, Ethan A-12):** committed on proper dev clone + remotes @ **`f762973`**.

| Path | Pin |
|------|-----|
| `/data/workspaces/atomic-commit-hesperia/requirements/router.txt` | `fpf-thinking-map==1.9.2` |
| `/data/workspaces/atomic-commit-hesperia/requirements/calibration.txt` | `fpf-thinking-map==1.9.2` |
| `docs/specs/HSR-V7-ROUTER-ENVELOPE-v0_1.md` | doc pin → 1.9.2 |
| Remotes | `igareosh/hesperia` + backup + Atomic `main` @ `f762973` |
| `colombo_research/hesperia/` | no separate pin file (N/A) |

Ref: [ETHAN-A12-PRESEAL-CLEAN-2026-07-25.md](reports/ETHAN-A12-PRESEAL-CLEAN-2026-07-25.md)

SIGNED: Developer (Felix) | ATM2-43 | 2026-07-23 | Hesperia pin align  
SIGNED: Architecture (Ethan) | ATM2-43 shelf | 2026-07-25 | committed f762973
