# Susanin borrowers — CSP and anti-patterns (v1)

**Spec:** [SPEC-ETHAN-COLOMBO-SUSANIN-MODE.md](../../governance/SPEC-ETHAN-COLOMBO-SUSANIN-MODE.md)

## Guidance by agent

| Agent | When Susanin helps | Prefer | Do / don’t |
|-------|-------------------|--------|------------|
| **Colombo** | First-class | Full `susanin_ops` spine | Owns formalize/scheme |
| **Ethan** | Architecture framing | Process map + IDEF0/FFBD | Frame; Colombo formalizes |
| **Grace** | Triage only | Team `active.md` | Do **not** invent BPM rows as triage substitutes |
| **Felix** | After B handoff | Implement models/tools | CSP into Susanin for modeling; out for code |
| **Gena** | After B handoff | Schemas/APIs | CSP; no freestyle BPMN invent |
| **Abelard** | Rare (ingest/infra) | Materials path | CSP; no process ownership |
| **Cursor** | Orchestrate | Release waves / wire | Adopt owner CSP when executing rows |

## CSP (required for non-Colombo)

```
From: <Agent> Context | To: Susanin / Colombo Context
Reason: process modeling / scheme / theme gate
What changes: authority = model/schema (A); code/deploy still Felix/Gena/Abelard; Move = susanin_ops JSON
```

## Anti-patterns (Ava)

- Claiming theme without corpus gate  
- Using BPMN as org process map (Poels)  
- Inventing `authorized=true` for HANDOFF_EXECUTE  
- Replacing Grace triage with a process diagram  
- Mixing team automation “workflow” with BPM Workflow  

SIGNED: Ethan / Ava / Cursor | Susanin borrowers v1 | 2026-07-24
