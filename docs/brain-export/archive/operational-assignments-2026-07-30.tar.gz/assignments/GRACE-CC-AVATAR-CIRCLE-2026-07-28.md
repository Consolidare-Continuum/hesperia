# Grace — avatar circle-fit lockup v1

**Date:** 2026-07-28  
**Invoker:** Operator → Grace  
**Task:** **CC_-BRAND-12**

## Drop

`.cache_to_sort_out/logo_anywhere_image_fit_circles_like_facebook_github.jpg`  
JPEG 1254×1254 · md5 `8c81ab1608d9b363e5654dd3ef9a2836`

## Custody

| Path | Role |
|------|------|
| `brand/masters/consolidare-continuum-avatar-circle-v1.jpg` | Master |
| `brand/exports/consolidare-continuum-avatar-circle-v1.jpg` | Approved export |
| `brand/web/avatar-circle-{1254,512,256,128}.jpg` | Web sizes |
| `decisions/2026-07-28-avatar-circle-fit-lockup.md` | Lock |

## Outcome

**DONE.** Ready for Facebook / GitHub / circular profile use.

SIGNED: Branding keeper (Grace) | avatar circle-fit | 2026-07-28 | CC_-BRAND-12
