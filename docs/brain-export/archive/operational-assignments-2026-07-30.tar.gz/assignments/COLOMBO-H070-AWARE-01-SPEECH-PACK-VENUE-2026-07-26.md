# Hesperia 0.7.0 — speech pack v1.2 (venue-named · identity-corrected)

**ID:** H070-AWARE-01 expand  
**Owner:** Colombo (corrected under Ethan identity stamp)  
**Date:** 2026-07-26  
**Base spine:** [COLOMBO-H070-AWARE-01-SPEECH-SPINE-2026-07-26.md](COLOMBO-H070-AWARE-01-SPEECH-SPINE-2026-07-26.md)  
**Identity law:** [ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md](../../governance/ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md)

**Correction:** v1.1 wrongly framed a “clinical informatics” venue. **Withdrawn.** Hesperia is **not** clinical/medicine.

---

## Named venue / audience (this expand)

| Field | Value |
|-------|--------|
| **Venue profile** | General technical / scientific methods conference — **multipurpose semantic engines** track (interim until operator names a specific conference) |
| **Audience** | Engineers · researchers · technical PMs · operators — how/where/why without inventing a domain |
| **Secondary venue** | Operator internal briefing (LAN wiki + soak demo pointer) |
| **Replace when** | Operator names a real conference/city/CFP — re-title; keep identity law |

---

## 12-minute talk (multipurpose engine track)

| Min | Beat | Say | Cite |
|-----|------|-----|------|
| 0–1 | Hook | Most “AI” narrates without a shared measurement body. | — |
| 1–3 | What | **Multipurpose** runtime semantic engine — dictionaries, logic, areas/families, wide params. Frame **0.7.0** fixed. **Not** an LLM; core has **no** domain knowledge until you supply field + corpus. | SYSTEM-STRUCTURE · Ethan identity |
| 3–6 | How | `/analyze` measures on the grid; `/product/interpret` returns engine-authored **ground_truth**. | HOW-IT-WORKS · HAND-FACES |
| 6–8 | Where | Prod @ tag `v0.7.0`; modules attach for purpose slices; agents roll HAND inquire/dig. | SYSTEM-STRUCTURE · HAND |
| 8–10 | Modules | e.g. **TFP** = one application for **field testing** when genuine data is provided (science/results check) — **not** “this product is medicine.” Gates: allowlist apply; REAL_DATA / COBALT stay gated. | APPLY · COBALT hubs · identity |
| 10–11 | Why now | Growth closed; grind robustness; speak how/where/why honestly. | PHASE · ISO (alignment ≠ cert) |
| 11–12 | Close | Demo: interpret soak + wiki `structure/` — observe, don’t mutate. | — |

## Slide claim checklist

- [ ] Multipurpose / not domain-locked  
- [ ] Not LLM · not clinical/medicine  
- [ ] Core empty of domain until field + dictionaries/logic + corpus  
- [ ] TFP (if mentioned) = one module / field test, not identity  
- [ ] Version `0.7.0` · no certification claim  

## Q&A bank

| Likely question | Answer spine |
|-----------------|--------------|
| Is this medical AI / clinical software? | **No.** Multipurpose engine. Domain appears only when you provide field, dictionaries, corpus. |
| Is this an LLM? | **No.** Deterministic grid measurement + composition; no built-in encyclopedic knowledge. |
| What is TFP then? | One **module** application — field data (e.g. Olga) vs science/results for product testing. |
| Can modules change the core? | Class A universal plumbing may drain into core; Class B domain stays branch — never redefine sealed `/analyze` as a specialty. |

SIGNED: Researcher (Colombo) | H070-AWARE-01 expand v1.2 | 2026-07-26 | venue: multipurpose methods · clinical framing withdrawn  
SIGNED: Team lead (Ethan) | identity correction | 2026-07-26 | not clinical
