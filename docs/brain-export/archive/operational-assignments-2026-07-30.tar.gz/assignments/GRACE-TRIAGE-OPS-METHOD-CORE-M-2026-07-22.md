# Grace triage — ops-method CORE-M statement-precision wave

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01
**Trigger:** Operator dogfooding (10 random `reason_at_step` calls) found a Lao Tzu epigraph classified as a business requirement; operator asked for a spec before a second book leans on the same pipeline.
**Source:** [ETHAN-PLAN-CORE-M-STATEMENT-PRECISION-2026-07-22.md](../../projects/ops-method/ETHAN-PLAN-CORE-M-STATEMENT-PRECISION-2026-07-22.md)
**FREEZE:** LIFTED, not relevant here — this is a quality axis the freeze doc never covered (map density §A / semantics-gloss §C only). No carve-out needed.

## Rows to add → active.md

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-CORE-M00** | Grace | P1 | Triage CORE-M wave (this file) |
| **OPS-METHOD-CORE-M01** | Ethan + Colombo | P1 | Ratify precision criteria + sample size N |
| **OPS-METHOD-CORE-M02a** | Felix | P1 | List the 221 deterministic `narration_flag=true AND statement_type='requirement'` rows |
| **OPS-METHOD-CORE-M02b** | Felix | P1 | Stratified sample of N additional `requirement` rows |
| **OPS-METHOD-CORE-M03** | Colombo | P1 | RU-semantics review — genuine requirement vs. epigraph/narration/aphorism |
| **OPS-METHOD-CORE-M04** | Felix | P1 | Remediation + cascade flag for downstream rows |
| **OPS-METHOD-CORE-M05** | Ava | P1 | Re-run outcomes report post-remediation, report delta |
| **OPS-METHOD-CORE-M06** | Ethan | P1 | Sign precision pass complete; feeds `PROD-J01` onboarding runbook as a new stage |

## Sequencing

M01 first (ratify). M02a has no dependency (deterministic, can run immediately). M02b depends on M01's N. M03 depends on M02a+M02b. M04 depends on M03. M05 depends on M04. M06 last.

SIGNED: Triage (Grace) | CORE-M statement precision | 2026-07-22
