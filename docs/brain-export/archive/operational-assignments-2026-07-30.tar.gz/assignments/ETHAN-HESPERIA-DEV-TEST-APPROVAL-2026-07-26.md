# Ethan — hesperia-dev-test APPROVED into team use

**Date:** 2026-07-26  
**Owner:** Ethan  
**ID:** ETHAN-HDT-01  
**Status:** DONE — **APPROVED INTO USE** (team/dev diagnostic; not product ship)

**Dev repo:** `/data/workspaces/atomic-commit-hesperia` → push target **`igareosh/hesperia`**  
**Registry:** `EXTENSION_STATUS.yaml` → `hesperia_dev_test`  
**Evidence:** `pytest -m dev_test` 2/2; live HTTP 65/65 OK (`outputs/reports/hesperia_dev_test/live_run.json`); sealed core untouched

---

## CSP

```
From: Cursor Context | To: Ethan Context
Reason: Operator — Ethan approve hesperia-dev-test into use and align
What changes: team-lead authority; Class B diagnostic tool law; Grace gets findings triage
```

---

## Verdict

**APPROVED INTO USE** as the **canonical team/dev semantics-free diagnostic battery** for sealed `/analyze` + `/product/interpret` + FPF-BUII inspection.

| Hold | Binding |
|------|---------|
| **Class** | Class **B** non-cored · `tools/hesperia_dev_test/` · **not** sealed merge |
| **product_surface** | stays **`none`** — not a public plugin / product capability |
| **status** | stays **`experimental`** in registry sense (not shipped product) + **`team_use: approved`** |
| **Sealed core** | **do not** “fix” tokenizer / double `/analyze` pass inside this tool’s scope — findings → Grace → owned grind rows |
| **Corpus** | synthetic tokens only (letters/digits/booleans/diacritics/indices) — **no** real Dict A words |
| **Phase** | Track **B — Runtime grind** under [HESPERIA-POST-070-PHASE-FRAME.md](../../governance/HESPERIA-POST-070-PHASE-FRAME.md) |

## Run (agents)

```bash
cd /data/workspaces/atomic-commit-hesperia
pytest -m dev_test
python -m tools.hesperia_dev_test run
python -m tools.hesperia_dev_test run --live http://127.0.0.1:<port>
```

## Findings accepted (not fixed here)

1. **Diacritics silent truncate** — `core/lexical/normalization.py` `TOKEN_RE = [a-z0-9]+`; NFKC does not fold RO ă/â/î/ș/ț into ASCII. `'mână'` → `['m','n']`; bare `'ă'` → empty. API still 200. **Data-loss risk** if diacritic text is a live input path. → **Grace** triage (architect/Felix assessment; sealed-touch gate).
2. **Latency** — mean ~1265 ms `/analyze`+`/product/interpret`; `build_dig_input` ~793 ms; all FPF-BUII probe layers ~3 ms total. `/analyze` runs **two** full pipeline passes (observation only).
3. **Alphabet map flat** — all 26 bare letters → same A1 / family_000 / top_activation fallback — no Dict A hit at single-letter grain.
4. **FPF gap count flat at 15.0** — structural/fixed-field gaps; not an input-health differentiator yet.

## Align targets

- Dev: `EXTENSION_STATUS.yaml` (`team_use: approved`, Ethan stamp)
- Brain: [CLIENTS/hesperia/README.md](../../CLIENTS/hesperia/README.md) pointer
- Grace: inbox entry for diacritic + optional `/analyze` double-pass grind

SIGNED: Team lead (Ethan) | ETHAN-HDT-01 | 2026-07-26 | hesperia-dev-test APPROVED into team use
