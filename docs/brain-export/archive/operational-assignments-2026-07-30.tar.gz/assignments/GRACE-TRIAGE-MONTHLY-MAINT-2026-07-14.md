# Grace triage — Monthly maintenance wave (2026-07)

**Date:** 2026-07-14  
**Source:** Operator — team monthly maintenance; Cursor may task and/or run automation; expect all done in one run.  
**Policy:** [cluster/MAINTENANCE_POLICY.md](../../cluster/MAINTENANCE_POLICY.md) · [SCRIPT-RUNBOOK-grace-triage-active.md](../../scripts/SCRIPT-RUNBOOK-grace-triage-active.md) · [SUITECRM-OPERATOR-AWARENESS.md](../../governance/SUITECRM-OPERATOR-AWARENESS.md)

---

## Triage outcome

**PROJECT-CREATED — MONTHLY-MAINT** — **2026-07-14** — [active.md](../../active.md) **MONTHLY-MAINT-00..04**.

**One sentence:** Abelard runs alunel + all VM maintenance; Ethan trashes repo noise; Grace documents the run and pushes SuiteCRM; Colombo refreshes brain/team repo context — one run to DONE.

---

## Rows (triaged)

| Pri | ID | Owner | Task |
|-----|-----|-------|------|
| P1 | **MONTHLY-MAINT-00** | Grace | Triage wave + SuiteCRM sync on row create |
| P1 | **MONTHLY-MAINT-01** | Abelard | alunel + all VM cluster maintenance (`run-cluster-maintenance.sh` + hypervisor notes) |
| P1 | **MONTHLY-MAINT-02** | Ethan | Repo trash-out (root hygiene, stale noise, compliance row) |
| P1 | **MONTHLY-MAINT-03** | Grace | Documenting maintenance + SuiteCRM push/verify |
| P1 | **MONTHLY-MAINT-04** | Colombo | Brain team repo context maintenance |

## Scope (in)

- Cluster unit maintenance (reachable units + offline probes)
- Brain repo trash-out / compact (no team operational file moves)
- Operational documentation of this monthly run
- SuiteCRM sync for `SUITE: YES` rows
- Colombo source-map / context archive freshness for team brain

## Scope (out)

- Hesperia product code / OPEN FBV* rows (remain separate)
- Cold backup phase2 to fulgusor unless Abelard finds staging already ready
- Cursor main full monthly audit letter (optional companion; not blocking this wave)

## Closure

Wave DONE when **MONTHLY-MAINT-00..04** are DONE, SuiteCRM write-back present or verified fail documented, cluster run dir under `/data/system_maintenance/latest` on alunel.

SIGNED: Triage (Grace) | monthly maintenance | 2026-07-14 | MONTHLY-MAINT
