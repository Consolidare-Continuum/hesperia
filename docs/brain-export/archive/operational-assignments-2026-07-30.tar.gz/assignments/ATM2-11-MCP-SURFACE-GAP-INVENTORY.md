# ATM2-11 — MCP surface gap inventory vs fpf-thinking-map 1.9.x

**Date:** 2026-07-23  
**Owner:** Felix  
**Pin:** `fpf-thinking-map==1.9.2` (26/26)

## Library APIs vs `agent_mcp_thinking_map/`

| Mechanism | Library surface | Gap (pre) | Status (post ATM2-12..14) |
|-----------|-----------------|-----------|---------------------------|
| Ignition Lock | `attempt_transition(..., authorized=)` | wired | **OK** — `authorized=` |
| Clearance / `AuthorizationReceipt` | `authorization=` + `issue_authorization_receipt` | parsers existed, **not on tool signature** | **OK** — `authorization_json`, `issue_receipt` |
| Holding / `PendingInput` / `AWAIT` | `RuntimeBinding.pending_inputs` → `OutcomeKind.AWAIT` | outcome kind only; no input path | **OK** — `pending_inputs_json` + outcome `pending_inputs` / `pending_input_ids` / `wake_conditions` / `awaiting_input` |
| Tail / `MoveIntent` / `inspect_move` | `intent=` + `inspect_move(state, intent)` | helpers unparsed | **OK** — `move_intent_json`, `inspect_move=true` |

## Domain maps (ATM2-15..18)

| Map | Adopt |
|-----|-------|
| `team_ops` | Glossary + invariants for Clearance/MoveIntent; comments on `execute_destructive` / `report_done` |
| `cluster_ops` | `trustmaster_ops` + `high_risk_ssh_fire` → `requires_human_authorization=True` |
| `eod_ops` | Holding glossary/invariant; evidence `eod_external_pending`; AWAIT via MCP `pending_inputs_json` |

## Residual

- Live MCP process on prichindel must reload to pick up tool schema (deploy/restart separate from this inventory).
- CHROMA `thinking_map_catalog` re-ingest deferred (`scripts/ingest-thinking-map-catalog.sh`) until map surface lands — ATM2-09.

SIGNED: Developer (Felix) | Claude Code context | 2026-07-23 | ATM2-11 inventory
