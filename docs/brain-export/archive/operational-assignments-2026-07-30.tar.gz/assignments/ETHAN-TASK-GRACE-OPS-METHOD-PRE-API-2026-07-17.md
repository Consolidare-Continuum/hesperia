# Ethan → Grace — task team: pre-API structure prep (ops-method)

**From:** Ethan (Chief Architect)  
**To:** Grace (triage)  
**Date:** 2026-07-17  
**Project:** `ops-method` · FREEZE: RYB-ED01 only

## Mandate

Task the team for **all pre-API feeding tasks**: prepare structure **before** decomposing the book by running against OpenAI API and ingesting results as product information.

**Do not** start live API decomposition until Grace marks **PRE exit GREEN** and Ethan **PRE-13 GO**.

## Goal of PRE wave

Stand up the informational-system **skeleton** so that when API runs:

1. Batches land in PG with coords, envelopes, manifests.  
2. Statements/relations/keywords validate against SCHEMA-CORE.  
3. Source sentences already exist (segmented from PDF without API).  
4. Agentic traverse surface exists (003).  
5. Security/custody for source PDF + future API key path is set.

## In PRE (must finish before API)

| Area | Owner(s) | Existing / new |
|------|----------|----------------|
| DB provision | Abelard + Sophia | **NEW PRE** + OPS-METHOD-06 |
| DDL 001→003 + seed | Marcus | MAP-03 |
| Source isolation / key custody path | Daniel | OPS-METHOD-07 (CRM CORP-05 **out**) |
| PDF → sentences/pages (no OpenAI) | Felix | **NEW PRE** |
| Envelope + ingest dry-run (fixtures) | Felix | MAP-07 / CORP-03 narrowed |
| Offline validation / vocab gates | Noah | MAP-08 / CORP-02 narrowed |
| Matrix coord seed + dictionary skeleton | Colombo | MAP-04 / CORP-06 |
| Search/inspect requirements | Olivia | MAP-06 |
| Runbooks (pre-API + batch) | Liam | MAP-09 |
| PRE exit checklist | Grace | **NEW PRE** |
| Authorize first API pilot | Ethan | **NEW PRE-13** |

## Out of PRE (pause until after structure + first ingest)

- Live OpenAI full/pilot **until PRE GREEN + Ethan GO**  
- Emma CORP-04 CRM/email contract (post product)  
- Daniel CORP-05 CRM/email connector bar (post)  
- Grace MAP-05 client org/IS intake (mapping to company — after book product exists)  
- Product MCP  

## Grace: do

1. Triage wave **OPS-METHOD-PRE-***.  
2. Align/reword existing OPEN rows to PRE scope; **PAUSE** out-of-PRE rows.  
3. SuiteCRM sync.  
4. Keep FREEZE: no new books/info domains.

SIGNED: Chief Architect (Ethan) | task Grace PRE wave | 2026-07-17 | pre-API structure
