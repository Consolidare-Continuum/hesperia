# Grace documentation — Brain improvement: agent Telegram (n8n) permanent phone path

**Date:** 2026-07-17  
**Class:** **docs-only** · **workflow** · **MCP/n8n** (agent → phone)  
**Project:** `cursor-repo` / prichindel n8n  
**Owner after ship:** Abelard (n8n/deploy) · all agents **use** the path  
**Transcript:** Cursor chat [`86cbce1d-a6d5-488c-b1f7-8b7de1694f08`](../../.cursor/CONTEXT-ARCHIVE.md)  
**Gena trace:** [GENA-TRACE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md](GENA-TRACE-AGENT-TELEGRAM-IRC-OPENAI-IGNORE-2026-07-17.md)  
**Shipped code:** brain `dc943f50` (+ pin `df614072`) on [igareosh/cursor](https://github.com/igareosh/cursor/commit/dc943f5009ef96d980cddcd235e90d693a2c4602)

---

## Improvement (one line)

**Any agent (Cursor, Copilot/Aegle, Claude/Felix, OpenAI/Aurel) texts igareosh or Olga via one brain command — n8n on prichindel — no Tersagor hunt.**

---

## Chat narrative (brain scope only)

| Time (approx) | Actor | Ask / action (brain-relevant) |
|---------------|-------|--------------------------------|
| 20:26 | Operator → **Ethan** | Idiotic-simple n8n path: any agent → Telegram **igareosh** or **Olga** (+373 69 527 262); full operational; brain-wide; stop searching Tersagor |
| 20:26–20:45 | Ethan / deploy | Built `scripts/agent-telegram.sh` + sender; n8n webhook `agent-telegram`; secrets on prichindel; dual-path; alwaysApply rule; AGENTS/CLAUDE/Aegle/Aurel/Abelard wiring |
| 20:45 | Operator → Ethan | Reliability + **IRC retrieve → phone** + wrap as **permanent** export |
| 20:45–20:51 | Ethan | Retries, chunking, `agent-irc-retrieve` / `agent-irc-sync`, `--irc` / `--verify`; alunel cron for JSONL sync |
| 20:51 | Operator → Ethan → Gena | Cross-check (brain wiring OK; Telegram does not post back to IRC) |
| 20:57 | Operator → Gena | Save for brain so agents can text operator; traces; task Grace |
| 21:00 | Operator → **Grace** | Document whole chat **for brain** (this packet) **separately** from tersagor |

**Out of scope here:** Tersagor OpenAI SDK ignore (see tersagor pack).

---

## Canonical agent interface

```bash
bash scripts/agent-telegram.sh "message to igareosh"
bash scripts/agent-telegram.sh olga "message to Olga"
bash scripts/agent-telegram.sh both "message to both"
bash scripts/agent-telegram.sh --irc
bash scripts/agent-telegram.sh olga --irc --channel '#agents-ops' --irc-lines 30
bash scripts/agent-telegram.sh --verify
```

| Recipient | Who |
|-----------|-----|
| `igareosh` (default) | +37368725554 |
| `olga` | +37369527262 |
| `both` | both |

**Do not:** invent Bot API curls, dig Tersagor for phone notify, ask how to send Telegram.

---

## Artifact map (brain)

| Path | Role |
|------|------|
| `scripts/agent-telegram.sh` | **Only** agent entry |
| `scripts/agent-telegram-send.py` | Sender (chunk + retry) |
| `scripts/agent-irc-retrieve.py` | IRC JSONL window |
| `scripts/agent-irc-sync.sh` | Sync JSONL → prichindel `/data/n8n/local-files/irc/` |
| `scripts/deploy-n8n-agent-telegram.sh` | Deploy helper |
| `cluster/prichindel/n8n/AGENT-TELEGRAM.md` | Ops doc |
| `cluster/prichindel/n8n/agent-telegram.workflow.json` | n8n export |
| `.cursor/rules/cursor-agent-telegram-n8n.mdc` | alwaysApply |
| `scripts/runbooks/SCRIPT-RUNBOOK-agent-telegram.md` | Mandatory runbook |
| `governance/ETHAN-TARGETED-RUNBOOKS-MANDATORY.md` | Table A+B entry |

**Legacy:** `SCRIPT-RUNBOOK-tersagor-operator-notify` — prefer agent-telegram.

**Reliability:** n8n webhook (3 retries) → direct sender fallback; Telegram chunk ~3900; retry 429/5xx.

**IRC source:** `tersagor:~/ergo/logs/eggdrop-classify.jsonl` (sync via **alunel→tersagor**; prichindel lacks that SSH). Default export channel `#operator-notify`.

---

## Boundary with Tersagor

| Concern | Path |
|---------|------|
| Agent → operator **phone** | **Brain** `agent-telegram.sh` / n8n |
| IRC / OpenAI Agents SDK mesh | **Tersagor** `imirc-gateway` |
| Bot lines in IRC | Stay in JSONL; **must not** re-enter SDK — [GRACE-DOC-TERSAGOR-BOT-IRC-OPENAI-IGNORE-2026-07-17.md](GRACE-DOC-TERSAGOR-BOT-IRC-OPENAI-IGNORE-2026-07-17.md) |

agent-telegram is **Telegram-only send** (+ IRC *retrieve*). It does not inject bot traffic into OpenAI.

---

## Grace triage outcome (brain)

**PROJECT-CREATED** as documentation improvement — rows **DOC-TG-BRAIN-00..01** on [active.md](../../active.md).  
This packet = durable chat record for brain half.

SIGNED: Triage (Grace) | brain agent-telegram n8n docs | 2026-07-17
