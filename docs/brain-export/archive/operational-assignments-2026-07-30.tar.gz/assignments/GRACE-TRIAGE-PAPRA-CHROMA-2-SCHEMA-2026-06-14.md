# Grace triage — Papra CHROMA-2 deploy prep (50 tasks)

**Date:** 2026-06-14 (expanded same day)  
**Source:** Operator — **50-task budget before CHROMA-2 deploy** on librarymaster  
**Register:** [governance/PAPRA-CHROMA2-2026-REGISTER.md](../../governance/PAPRA-CHROMA2-2026-REGISTER.md)  
**Exit criteria:** [governance/PAPRA-CHROMA2-EXIT-CRITERIA.md](../../governance/PAPRA-CHROMA2-EXIT-CRITERIA.md)

---

## Triage outcome

**PROJECT-CREATED** — **PAPRA-00..49** (50 tasks) on [active.md](../../active.md).  
**Project:** `cursor-repo` · **CHROMA-2 / Papra** · librarymaster only.  
**Deploy definition:** G1–G8 in exit criteria doc; wave closes at **PAPRA-48**.  
**Reindex (W4):** **PAUSED** until PAPRA-13, PAPRA-15, PAPRA-16, PAPRA-18.

---

## Wave map (50 tasks)

| Wave | IDs | Focus | Owner mix |
|------|-----|--------|-----------|
| W0 | 00–04 | Meta, exit criteria, architecture | Grace, Ethan |
| W1 | 05–12 | Ingest schema v1 code + dry-run | Abelard, Felix, Gena, Cursor |
| W2 | 13–18 | Vector approval, backup, security, **operator gate** | Marcus, Noah, Abelard, Daniel, Grace |
| W3 | 19–26 | Stack hardening, runbooks, capacity | Abelard, Liam, Sophia, Marcus |
| W4 | 27–34 | **Full reindex** (blocked) | Abelard, Olivia, Grace |
| W5 | 35–42 | MCP + Colombo surf | Cursor, Colombo, Ethan |
| W6 | 43–47 | RAGAS, QA, integration | Noah, Daniel, Emma |
| W7 | 48–49 | Sign-off + hybrid spike (P2) | Grace, Abelard |

---

## Team tasking summary

| Owner | Task count | First OPEN |
|-------|------------|------------|
| Abelard | 18 | PAPRA-05 |
| Grace | 5 | PAPRA-04 |
| Ethan | 4 | PAPRA-02 |
| Cursor | 5 | PAPRA-12 |
| Felix | 2 | PAPRA-09 |
| Liam | 2 | PAPRA-23 |
| Marcus | 3 | PAPRA-13 |
| Noah | 4 | PAPRA-14 |
| Colombo | 3 | PAPRA-39 |
| Daniel | 2 | PAPRA-17 |
| Gena | 1 | PAPRA-11 |
| Olivia | 1 | PAPRA-33 |
| Sophia | 1 | PAPRA-25 |
| Emma | 1 | PAPRA-47 |

**Done at triage:** PAPRA-00, PAPRA-01.

**Start now (no operator block):** W0 PAPRA-02..04, W1 PAPRA-05..12, W2 PAPRA-13..17, W3 PAPRA-19..26, W5 PAPRA-35..38 (MCP can parallel after PAPRA-10 dry-run).

**Blocked on operator:** PAPRA-18 → entire W4.

---

## Operator decision (PAPRA-18)

**APPROVED 2026-06-14** — igareosh: full Papra reindex despite pain; dev + deploy CHROMA-2; rebuild ingester; **24 cores for evening run** (librarymaster VM 103 bumped on alunel Proxmox).

Execution: `bash scripts/librarymaster-papra-evening-reindex.sh`

**Process note (operator-correct):** Approval was for **data**, but team **must not** start mass index before **schema DEV + DEPLOY** gates (G0). Evening run **violated** 1→2→3 by bundling deploy + full wipe + corpus in one script while PAPRA-02/10 and MCP were still OPEN. Hard order now in schema spec §0 and exit criteria **G0**.

---

SIGNED: Triage (Grace) | PAPRA-00..49 PROJECT-CREATED | 2026-06-14 | 50-task deploy budget
