# Grace triage — ops-method MAP wave (2026-07-17)

**Project:** `ops-method`  
**Wave:** MAP — book → operational informational system reality  
**Hygiene tag:** docs-only + integration (schema/search later)  
**Outcome:** PROJECT wave rows added (same project; not new project)  
**Parent open:** [GRACE-TRIAGE-OPS-METHOD-2026-07-17.md](GRACE-TRIAGE-OPS-METHOD-2026-07-17.md)  
**Spec:** [SPEC-ETHAN-OPS-METHOD-PRODUCT.md](../../governance/SPEC-ETHAN-OPS-METHOD-PRODUCT.md)  
**Register:** [OPS-METHOD-2026-REGISTER.md](../../governance/OPS-METHOD-2026-REGISTER.md)

## Operator request

Grace triage for **mapping this business book into operational informational system reality**.

Meaning (from product SPEC § mapping vs assessment):

1. Preserve book-derived claims (after Spec v0.1 + lawful source).  
2. **Map** each usable claim into company operational/IS reality:  
   principle → policy → business process → step → role → control → metric → **system / data / interface** → task automation.  
3. Make the map **inspectable and searchable** (agentic + human).  
4. Keep gates, checks, guards, audit manifests on every mapping batch.  
5. Assessment (gap status) is a **separate** later wave — not this triage.

## Dependencies

| Dep | Status | Effect on MAP |
|-----|--------|----------------|
| OPS-METHOD-02 Spec v0.1 | OPEN | Ontology/contracts can start; claim-level mapping waits |
| OPS-METHOD-05 book file + edition | OPEN / blocked | Book-grounded mapping PAUSED until intake |
| OPS-METHOD-03 CONTEXT-PACKET | OPEN → seal this session | Unblocks Ethan WBS |

## Rows (active.md)

| ID | Owner | Intent | Status |
|----|-------|--------|--------|
| **OPS-METHOD-MAP-00** | Grace | Triage MAP wave; SuiteCRM sync | DONE (this packet) |
| **OPS-METHOD-MAP-01** | Ethan | Mapping target ontology v0.1 — operational IS entity types (policy, process, step, role, control, metric, system, datastore, interface, automation) | OPEN |
| **OPS-METHOD-MAP-02** | Ethan | Mapping operation contract — claim→…→IS reality chain; evidence + gate rules | OPEN |
| **OPS-METHOD-MAP-03** | Marcus | PostgreSQL schema draft — mapping edges + client ontology (inspectable/searchable) | OPEN |
| **OPS-METHOD-MAP-04** | Colombo | Semantic dictionary starter — agentic variables for management terms (pack-neutral + Rybakov-ready) | OPEN |
| **OPS-METHOD-MAP-05** | Grace | Org/IS reality intake checklist — docs, interviews, systems, observed ops | OPEN |
| **OPS-METHOD-MAP-06** | Olivia | Human + agent search/inspect requirements over mapping graph (API/query surface) | OPEN |
| **OPS-METHOD-MAP-07** | Felix | Mapping batch writer stub — statements, relations, run-manifest hooks (after Spec v0.1) | OPEN |
| **OPS-METHOD-MAP-08** | Noah | AI mapping-candidate gates — no invented relation types; review_status required | OPEN |
| **OPS-METHOD-MAP-09** | Liam | SCRIPT-RUNBOOK — mapping batch execute + audit | OPEN |
| **OPS-METHOD-MAP-10** | Grace | Standing: when book file arrives (OPS-METHOD-05), unlock pilot mapping batch scope | OPEN standing |

## Do not

- Run assessment statuses in this wave (separate wave later).  
- Map without evidence IDs.  
- Invent relation types outside Spec vocabulary.  
- Commit verbatim book text to GitHub.  
- Full-book map before Spec v0.1 + 20-page pilot plan.

## SuiteCRM

`SUITE: YES` on all MAP rows. Sync after write.

SIGNED: Triage (Grace) | ops-method MAP wave | 2026-07-17 | book→IS reality
