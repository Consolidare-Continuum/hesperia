# HRES-07 — Poisson ↔ hex propagation cross-ref (G-M7 optional)

**Owner:** Colombo · **Date:** 2026-06-23 · **Status:** DONE

## Analog (pedagogy only)

| Poisson / Laplace | Hesperia hex field |
|-------------------|-------------------|
| Source ρ(x) | Activation injection on hex nodes |
| Field φ(x) | `A_hex` activation vector |
| ∇²φ = −ρ | Discrete diffusion / propagation on `L_H` adjacency |
| Green's function | Corridor aggregation from seed hex |

## Non-claims

- Hesperia does **not** solve continuous Poisson PDE on the sphere.
- `propagation_corridors` is **graph flow**, not a variational field equation.
- Use **`metric_layer=hex_graph`** for hop/corridor costs.

**Ref:** [POISSON-EQUATION-WHAT-IT-IS.txt](../../colombo_research/physics_cosmology/POISSON-EQUATION-WHAT-IT-IS.txt) · [METRIC_research_GAPS G-M7](../../colombo_research/hesperia/METRIC_research/METRIC_research_GAPS-AND-REMEDIATION-v01.md)

**SIGNED: Researcher (Colombo) | HRES-07 Poisson cross-ref | 2026-06-23**
