# voinicel survey — refreshed data wrap (Colombo)

**Collected:** 2026-06-20T10:28Z (via alunel → voinicel `.16`)  
**Local snapshot:** `operational/assignments/voinicel-gps-survey-snapshot-20260620T1028Z/`  
**Mount:** `voinicel-sma-rail-magnet-01` · LEA-M8T · magnet / iron rail / horizontal  
**Deed:** [agents/colombo/VOINICEL-ANTENNA-SURVEY.md](../../agents/colombo/VOINICEL-ANTENNA-SURVEY.md)

---

## COPY-PASTE BLOCK — facts for reasoning

```
VOINICEL SURVEY — POST-24H STATUS (verified 2026-06-20)

RUN
  started_local:     2026-06-19T01:33:16+03:00
  spec_gates:        svinMinDur=86400s (24h) AND svinAccLimit=1000mm (1.0m 3D)
  last_active_poll:  2026-06-20T13:20:08+03:00
  last_active_dur:   128952 s = 35.82 h (past 24h gate by +11.82 h)
  survey_stopped:    ~2026-06-20T13:22+03 (voinicel reboot; uptime 7 min at 13:29)
  live_now:          timeMode=0 (Disabled), svin active=0 dur=0 valid=0
  survey-active_file: STILL PRESENT on disk (stale marker post-reboot)

GATES AT END OF ACTIVE RUN
  duration_gate:     PASSED (128952 >= 86400)
  accuracy_gate:     FAILED — std3d_mm=9961.4 vs target 1000 (9.96 m vs 1.0 m)
  valid:             0 (never achieved)
  quality_pct:       10.0% of u-blox 1m ns-timing reference tier (flat ~9.9–10.5% whole run)

CONVERGENCE TRAJECTORY (431 monitor samples)
  first:   2026-06-19T01:33:18+03 std3d=12904.8mm quality=7.7%
  best:    2026-06-19T01:40:07+03 std3d=9542.9mm  quality=10.5%  (early only)
  at_24h:  2026-06-20T01:30:01+03 std3d=10078.9mm quality=9.9%
  last:    2026-06-20T13:20:08+03 std3d=9961.4mm  quality=10.0%
  pattern: brief early dip, then plateau ~9.7–10.3m for 30+ hours — mount ceiling not duration-limited

LAST ACTIVE ARP (preliminary — NOT validated, valid=0)
  ECEF_cm:  X=381599418  Y=209969789  Z=464397471
  LLA_deg:  47.027826°N, 28.821180°E
  obs:      128953 fixes averaged
  meanV:    99228616 mm² → std3d = 9961.4 mm

COVERAGE (last active window)
  numSV:    10–11 typical
  pDOP:     ~1.5–2.6 (acceptable)
  tDOP:     ~0.84–1.88
  PVT hAcc: ~1.5m pre-reboot; post-reboot hAcc ~3.9m (3D fix degraded briefly)

STOP CAUSE
  voinicel reboot ~13:22+03 cleared module survey-in RAM state
  preset skipped cold-reset (survey-active file) but module came up timeMode=0
  NOT a successful survey completion or abort script — infrastructure event

ARCHIVE CHAIN
  voinicel logs:     FULL pull OK (alunel rsync 2026-06-20T10:28Z)
  chronomaster:      STALE — collect BLOCKED from chronomaster SSH preflight (intermittent)
  alunel mirror:     not refreshed this run
```

---

## COPY-PASTE BLOCK — conclusions

```
CONCLUSIONS (Colombo)

1. SURVEY FAILED the u-blox dual gate — duration exceeded 24h but accuracy never approached 1m.
   The mount/environment ceiling is ~10m 3D std, ~10% of ns-timing reference tier. More time did not help.

2. NO VALID ARP — valid=0 entire run; preliminary ECEF/LLA from running mean only; do not use for Fixed mode.

3. STRATUM 1 (PVT+PPS chrony) unaffected in principle; survey-in was for ARP formalization / fixed-mode timing upgrade.

4. RUN ENDED BY REBOOT not by module auto-complete — 35.8h of data lost from module; logs on disk preserve history.

5. MAGNET-ON-IRON-RAIL mount at ~47.03°N/28.82°E Moldova outdoor: stable enough for ~10m survey mean,
   NOT stable enough for svinAccLimit=1000mm without environmental change (mount, ground plane, multipath).

6. OPTIONS (operator):
   A) Accept ~10m ARP — relax svinAccLimit to ~10000mm, re-survey, enter Fixed with realistic accuracy
   B) Change mount/antenna environment — new survey after physical change
   C) Stay PVT mode — stratum 1 already works; abandon fixed-mode ns-tier pursuit for this mount
   D) Investigate reboot cause — prevent unplanned loss of long survey runs
```

---

## Key evidence lines (verbatim)

**Last active monitor (2026-06-20T13:20:08+03):**
```
std3d_mm=9961.4 target_mm=1000 quality_pct=10.0
svin dur=128952 obs=128953 active=1 valid=0 meanV_mm2=99228616
```

**First post-reboot monitor (2026-06-20T13:25:01+03):**
```
svin dur=0 active=0 valid=0
```

**Live UBX export (2026-06-20T10:28:35Z, post-reboot):**
```json
"svin": {"active": 0, "dur": 0, "valid": 0}
"tmode2": {"timeMode": 0, "svinAccLimit_mm": 0, "svinMinDur_s": 0}
```

**survey-spec.json (unchanged):**
```json
{"svinMinDur":86400,"svinAccLimitMm":1000,"started":"2026-06-19T01:33:16+03:00"}
```

---

## NEXT

1. Operator picks A/B/C/D above.
2. Abelard: fix chronomaster→voinicel collect SSH path; rsync this snapshot to chronomaster archive; find reboot cause.
3. Colombo: on operator decision — draft mount-limit memo + update deed phase from WAITING → **INCOMPLETE (accuracy fail + reboot)**.

SIGNED: Research (Colombo) | voinicel survey wrap | 2026-06-20 | refreshed collect post-24h
