# Grace triage — Tersagor Agents SDK: 50-task integration (trust gate)

**Date:** 2026-06-21 (rev 2)  
**Source:** Operator — spike not trusted until **50 tasks** run, snitching patterns from [openai/openai-agents-python](https://github.com/openai/openai-agents-python).  
**Canonical task list:** `tasks/AGENTS-SDK-50-TASKS.md` on **igareosh/tersagor** (clone `/data/tersagor`).

---

## Triage outcome

**PROJECT-CREATED — TERSAGOR-SDK** — **2026-06-21** — **TSDK-00..050** (51 rows) on [active.md](../../active.md); register [TSDK-2026-REGISTER.md](../../governance/TSDK-2026-REGISTER.md); project [projects/tersagor-sdk/](../projects/tersagor-sdk/).

**One sentence:** 50 atomic SDK integration tasks + Grace meta live; **45 OPEN**, **2 IN_PROGRESS** (partial spike), **3 PAUSED** (SKIP); prod blocked until **TSDK-050**.

**Triage outcome**: PROJECT-CREATED — 2026-06-21 — active.md TSDK-00..050 · heartbeat OPEN += 45

---

## Prior draft (superseded by triage execution above)

**PROJECT:** `tersagor-sdk` · **50 rows** `TSDK-001` … `TSDK-050`  
**Trust gate:** prod stays on legacy paths until **M4** (tasks 046–050 VM smoke all green).  
**Spike status:** `5950a63` = **001 partial, 013–016 partial only** — not production.

---

## Milestones (batch triage to active.md)

| Milestone | Task range | Owner lead | Gate |
|-----------|------------|------------|------|
| **M1** Foundation + runner | 001–012 | Gena | pytest + CI |
| **M2** Handoffs + guardrails | 013–028 | Gena | orchestrator <800 lines |
| **M3** HITL + sessions | 029–039 | Gena + Felix | TG session + approval resume |
| **M4** MCP + trace + ship | 040–050 | Gena + Abelard | 10-smoke script exit 0 on VM |

Grace may triage **5 milestone rows** (M1–M4 + umbrella) or **50 atomic rows** — operator preference: **atomic** for visibility.

---

## Sample active.md rows (001–010; full list in tersagor tasks file)

| Pri | Project | ID | Owner | Summary |
|-----|---------|-----|-------|---------|
| P1 | tersagor-sdk | TSDK-001 | Gena | Pin openai-agents 0.17 + CI venv smoke (hello_world) |
| P1 | tersagor-sdk | TSDK-002 | Gena | Migration doc aligned to SDK quickstart |
| P1 | tersagor-sdk | TSDK-003 | Felix | test_sdk_smoke_hello.py in CI |
| P1 | tersagor-sdk | TSDK-004 | Gena | Log RunResult usage in audit JSONL |
| P1 | tersagor-sdk | TSDK-005 | Felix | Retry wrapper in openai_agents_adapter |
| P1 | tersagor-sdk | TSDK-006 | Gena | sdk/run_config.py RunConfig factory |
| P1 | tersagor-sdk | TSDK-007 | Gena | sdk/hooks.py JSONL lifecycle hooks |
| P1 | tersagor-sdk | TSDK-008 | Gena | OperationContext in RunContextWrapper |
| P1 | tersagor-sdk | TSDK-009 | Gena | Runner.run_sync vs async_bridge decision |
| P1 | tersagor-sdk | TSDK-010 | Gena | output_type strict/loose for plan/op |

**TSDK-011 … TSDK-050:** see [tasks/AGENTS-SDK-50-TASKS.md](https://github.com/igareosh/tersagor/blob/main/tasks/AGENTS-SDK-50-TASKS.md) after push.

---

## What we snitch (categories)

| SDK area | Upstream examples | Replaces in tersagor |
|----------|-------------------|----------------------|
| Handoffs | `agent_patterns/routing`, `handoffs/*`, `customer_service` | orchestrator regex, natural routers |
| Guardrails | `input/output/tool_guardrails` | duplicate checks in policy_gate only for exec |
| HITL | `human_in_the_loop*`, `shell_human_in_the_loop` | GuardedShellRunner approval polling |
| Sessions | `memory/sqlite_session*` | conversation_state, IRC prefix hack |
| MCP | `mcp/*`, `hosted_mcp/*`, `tools/tool_search` | mcp/client urllib, flat registry |
| Tools | `tools/shell`, `sandbox/unix_local*` | Abelard hand-rolled function_tools |
| Tracing | `docs/tracing.md` | ad-hoc trace_events only |

**Explicit SKIP (document only):** realtime/voice (024), OpenAI server sessions (035), parallelization (048).

---

## Operator command

```
Grace, triage tersagor-sdk TSDK-001 through TSDK-050 from tasks/AGENTS-SDK-50-TASKS.md — atomic rows, SUITE YES.
```

---

SIGNED: Cursor | operator trust gate — 50 tasks | 2026-06-21 | tersagor-sdk
