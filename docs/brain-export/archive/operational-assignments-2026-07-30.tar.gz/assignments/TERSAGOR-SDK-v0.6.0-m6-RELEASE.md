# Tersagor OpenAI Agents SDK — v0.6.0-m6 (hosted brain MCP live)

**Date:** 2026-06-21  
**Product repo:** `igareosh/tersagor` — hosted-MCP glue in `src/tersagor_agent/sdk/hosted_mcp.py`  
**Brain infra:** [cluster/prichindel/brain-mcp-http/](../../cluster/prichindel/brain-mcp-http/) · [vaporas gate](../../cluster/vaporas/vaporas-gate.conf)  
**Prior:** [v0.5.0-m5](TERSAGOR-SDK-v0.5.0-m5-RELEASE.md) · [run closed](TERSAGOR-SDK-RUN-CLOSED-2026-06-21.md)

---

## Version line

| Field | Value |
|-------|--------|
| **Release** | **v0.6.0-m6** |
| **Codename** | hosted-brain-mcp |
| **Status** | **Live on tersagor VM** — not GA |
| **Public MCP** | `https://mcp.prichindel.com/mcp` |
| **Tools** | `query_knowledge`, `list_runbooks`, `get_runbook` |

---

## In scope

- Abelard: brain MCP streamable HTTP on prichindel + vaporas public gate + TLS
- tersagor: `HostedMCPTool` with raw bearer token; prod flags `HOSTED_MCP_ENABLED=1`
- SDK prod smokes green with OpenAI reaching MCP (`openai-mcp/1.0.0`)

## Out of scope

- GA / marketing release
- Authentik wall on MCP (bearer-only by design)
- Full 50-task SDK backlog beyond triaged rows

---

SIGNED: Abelard/Cursor | v0.6.0-m6 hosted MCP | 2026-06-21 | tersagor-sdk
