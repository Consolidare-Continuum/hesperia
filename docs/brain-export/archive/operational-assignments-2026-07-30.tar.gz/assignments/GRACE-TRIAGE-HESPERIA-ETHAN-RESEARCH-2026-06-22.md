# Grace triage — Hesperia Ethan-specced research (HRES supplement)

**Date:** 2026-06-22  
**Source:** Operator — Grace triage all **Ethan-ratified research** into hesperia todos  
**Register:** [governance/HRES-2026-REGISTER.md](../../governance/HRES-2026-REGISTER.md)  
**Companion wave:** [METRIC-2026-REGISTER.md](../../governance/METRIC-2026-REGISTER.md) (**METRIC-00..39** already live)

---

## Triage outcome

**PROJECT-CREATED** — **HRES-00..11** on [active.md](../../active.md).  
**Project:** `hesperia` · Ethan research supplement (Minkowski–IPoW + pedagogy + G9–G10).  
**Authority:**

| SPEC | Status |
|------|--------|
| [SPEC-ETHAN-HESPERIA-METRIC-AND-DISTANCE.md](../../governance/SPEC-ETHAN-HESPERIA-METRIC-AND-DISTANCE.md) | RATIFIED — METRIC wave |
| [SPEC-ETHAN-HESPERIA-MINKOWSKI-IPOW-ITERATIONS.md](../../governance/SPEC-ETHAN-HESPERIA-MINKOWSKI-IPOW-ITERATIONS.md) | RATIFIED — **this supplement** |

**Not triaged (awaiting Ethan):** [SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md](../../governance/SPEC-ETHAN-HESPERIA-COBALT-MODULE-BRANCH.md) — still DRAFT.

---

## Research corpus covered

| Path | Role |
|------|------|
| [colombo_research/hesperia/METRIC_research/](../../colombo_research/hesperia/METRIC_research/) | Metric tensor ↔ Hesperia; Minkowski–IPoW pass |
| [colombo_research/physics_cosmology/](../../colombo_research/physics_cosmology/) | 6 human explainers (pedagogy) |
| [24_SPEC §14](../../user_documents/HESPERIA_ACADEMIA/24_SPEC__Hesperia_Metric_and_Distance_v0_1.md) | Iteration interval **I²_n** |
| [HESPERIA-METRIC-ACADEMIA-NARRATION-v0_1.md](../../user_documents/HESPERIA_ACADEMIA/HESPERIA-METRIC-ACADEMIA-NARRATION-v0_1.md) | §3.5a iteration geometry |

---

## Team summary

| Owner | Count |
|-------|-------|
| Grace | 3 |
| Ethan | 2 |
| Colombo | 3 |
| Felix | 1 |
| Gena | 1 |
| Noah | 1 |
| Abelard | 1 |

**Total:** 12 tasks.

---

## SuiteCRM

All rows: `SUITE: YES`. Post-triage: `bash scripts/suitecrm_sync_on_triage.sh --task-id HRES-00` (wave sync).

---

**SIGNED: Triage (Grace) | Ethan research HRES wave | 2026-06-22**
