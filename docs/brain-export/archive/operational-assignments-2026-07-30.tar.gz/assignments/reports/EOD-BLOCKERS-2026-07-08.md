# Thinking-map technical blockers — EOD queue (2026-07-08T12:14:25Z)

Pending (open + fixed_runtime): **12**
Registry: governance/thinking_map_blockers.jsonl

| blocker_id | status | class | task_id | outcome | registered |
|---|---|---|---|---|---|
| 1259c1ba83a8 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:37:15Z |
| e48061c6b2d4 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:37:15Z |
| 42000e1a4f8b | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:33:43Z |
| 06b4fe0fdf84 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:33:43Z |
| 431addf5d637 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:32:57Z |
| c49bea556b1d | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:32:57Z |
| 462727a75bed | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:05Z |
| 8c01c7ad6bd7 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:05Z |
| 09f0a2a82234 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:02Z |
| 7b2a604a6602 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:02Z |
| e334dfe63442 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:14:33Z |
| 7cb08dec8a36 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:14:33Z |

### 1259c1ba83a8 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### e48061c6b2d4 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 42000e1a4f8b (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 06b4fe0fdf84 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 431addf5d637 (collect_evidence) — open
- task: web_ui
- reason: 
- missing_evidence: web_snapshot_done

### c49bea556b1d (collect_evidence) — open
- task: edge_ops
- reason: 
- missing_evidence: cf_observability_done

### 462727a75bed (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 8c01c7ad6bd7 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 09f0a2a82234 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 7b2a604a6602 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### e334dfe63442 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 7cb08dec8a36 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read
