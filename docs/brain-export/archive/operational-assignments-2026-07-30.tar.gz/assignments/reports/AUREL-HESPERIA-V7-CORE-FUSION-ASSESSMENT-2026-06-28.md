# Aurel — Hesperia V7 core fusion assessment

**Date:** 2026-06-28  
**Owner:** Aurel (Codex stabilization and architecture audit)  
**Scope:** map real Hesperia code paths for V7 core fusion, identify what moves into core, what stays branch-specific, and what must be sealed afterward

**Canonical path anchor:** [HESPERIA-V7-CASTLE-PATH-2026-06-28.md](/data/altitudine/prichindel.com/governance/HESPERIA-V7-CASTLE-PATH-2026-06-28.md)

## Executive verdict

**V7 productization is feasible, but core fusion is not a blind merge.**  
The inspected Hesperia code already separates into four real classes:

1. **sealed core that should stay sealed,**
2. **generic runtime math and governance code that should be fused into canonical core homes,**
3. **duplicated or inverted ownership paths that must be normalized before seal,**
4. **domain or branch code that must stay non-cored.**

The most important conclusion from the code itself is:

> **V7 should fuse generic semantic math, observability, audit, and bridge substrate into canonical core-adjacent homes, while keeping TFP clinical semantics, TRIZ contradiction packages, and clinical KME bridges outside sealed core.**

---

## Trees inspected

### Runtime implementation tree

- `/data/hesperia/hesperia`

### Dev clone comparison tree

- `/data/workspaces/atomic-commit-hesperia`

### Brain-side productization docs

- [HESPERIA-V7-CASTLE-PATH-2026-06-28.md](/data/altitudine/prichindel.com/governance/HESPERIA-V7-CASTLE-PATH-2026-06-28.md)
- [SPEC-ETHAN-HESPERIA-V7-SEMANTICS-ROUTER-COMPLIANCE.md](/data/altitudine/prichindel.com/governance/SPEC-ETHAN-HESPERIA-V7-SEMANTICS-ROUTER-COMPLIANCE.md)
- [AUREL-HESPERIA-V7-LAST-BATTLE-PLAN-2026-06-28.md](/data/altitudine/prichindel.com/operational/assignments/reports/AUREL-HESPERIA-V7-LAST-BATTLE-PLAN-2026-06-28.md)

---

## What the code says today

### 1. There is already a real sealed spine

The codebase already enforces a sealed product spine around:

- `hesperia/engine/sealed_multiscale_stack.py`
- `hesperia/engine/multiscale_product_bridge.py`
- `hesperia/system/system_seal.py`
- `tests/test_runtime_spine_integrity.py`
- `tests/system_seal/test_system_seal_gate.py`

That spine is the correct place to preserve and seal after fusion.  
It should not be reopened by module drift or branch-specific logic.

### 2. There is already a generic core math layer

The repo already has real canonical math and deterministic utility surfaces under:

- `core/math/`
- `core/metrics/`
- `core/dynamics/`
- `core/propagation/`
- `core/layers/`
- `core/lexical/`
- `core/result/`
- `core/output/`
- `core/guards/`
- `core/projection/`

This is the right fusion gravity well.

### 3. Generic code is still split between core and runtime

Several generic, reusable pieces still live under `hesperia/engine/`, `hesperia/extensions/`, `hesperia/product/`, or `sphere/` even though they are not domain-specific.

Those are the main fusion candidates.

### 4. There are real ownership inversions and drifts

The code exposes several structural drifts:

- `core/domain/*` presents itself as core-facing, but many files are only re-export shims whose canonical implementation still lives under `hesperia/engine/kme/*`.
- `hesperia/modules/tfp/math_v1.py` and `hesperia/engine/tfp_math.py` overlap heavily.
- `hesperia/product/service.py` still uses the modular `run_pipeline()` path instead of the sealed multiscale spine.
- `hesperia/engine/pipeline_runner.py` advertises `ENGINE_VERSION = "0.7.0"` while `hesperia/VERSION.yaml` still reports `0.6.0`.

These must be normalized before a trustworthy V7 seal.

---

## Fusion rule

Use this decision rule for every path:

### Fuse into core or core-adjacent canon when

- it is deterministic,
- it is domain-agnostic,
- it is needed by more than one branch or product surface,
- it expresses measurement, geometry, observability, audit, or governance substrate.

### Keep outside sealed core when

- it encodes clinical or TFP semantics,
- it depends on branch-specific corpora or intervention taxonomies,
- it is TRIZ or contradiction package logic,
- it is a clinical KME bridge,
- it is product UI or service wiring rather than universal semantic substrate.

---

## Path map — keep sealed as canonical core

These are already where they belong or close enough that fusion should preserve them rather than relocate them.

| Path group | Status | Fusion action |
|-----------|--------|---------------|
| `core/math/*` | canonical Class A math | preserve as core |
| `core/metrics/*` | deterministic metric layer | preserve as core |
| `core/dynamics/*` | deterministic numeric support | preserve as core |
| `core/propagation/*` | canonical propagation and guard mechanics | preserve as core |
| `core/layers/*` | canonical layer contract logic | preserve as core |
| `core/lexical/*` | generic lexical preparation | preserve as core |
| `core/result/*` | canonical result contract | preserve as core |
| `core/output/*` | generic fingerprint/result output helpers | preserve as core |
| `core/guards/*` | invariant/determinism guards | preserve as core |
| `core/projection/*` | public projection substrate | preserve as core |
| `core/runtime/engine.py` | frozen public analysis entry | preserve as core |
| `hesperia/engine/sealed_multiscale_stack.py` | sealed runtime spine | preserve and seal, do not move casually |
| `hesperia/engine/multiscale_product_bridge.py` | sealed spine bridge | preserve as core-adjacent product spine |
| `hesperia/system/system_seal.py` | canonical seal gate | preserve and extend |

---

## Path map — promote into core fusion

These paths are generic enough to be fused into canonical core homes.  
Target locations below are **proposed canonical homes**, inferred from current responsibilities.

| Current path | Proposed canonical home | Why it should fuse |
|-------------|--------------------------|--------------------|
| `hesperia/engine/observables.py` | `core/math/observables.py` | Canonical field observables are generic math, not product wiring |
| `hesperia/extensions/dynamics/equations.py` | `core/math/semantic_field_equations.py` | Explicit semantic field equations are universal engine math |
| `hesperia/extensions/dynamics/semantic_field_v1.py` | `core/services/semantic_field_bundle.py` | Versioned calibration/bundle wrapper over generic equations belongs in a core-adjacent service layer |
| `hesperia/engine/output_trace.py` | `core/output/trace.py` or `core/audit/output_trace.py` | Reverse-trace explainability is generic audit substrate for V7 |
| `sphere/fpf_bridge/*` | `core/router/fpf_bridge/*` or `core/governance/fpf_bridge/*` | Layer 11 bridge is deterministic logic/governance substrate, not sphere-local business logic |
| `specs/canon/fpf_bridge_v7.md` | spec stays, but canon should point to fused bridge home | bridge spec already defines bounded structural substrate for V7 |
| `hesperia/product/contracts/*.schema.json` | `core/contracts/product/*.schema.json` | product-facing contracts should be versioned canonical contracts, not hidden in one service layer |
| `hesperia/product/contracts/validator.py` | `core/contracts/product/validator.py` | contract validation is generic product boundary logic |

### Notes on `sphere/fpf_bridge/*`

`sphere/fpf_bridge/*` is a particularly strong fusion candidate because it is:

- deterministic,
- pure-consumer by design,
- already specified as bounded structural substrate,
- directly aligned with the V7 semantics-router architecture.

It should move **near** core, but not inside raw sealed physics math.  
The right home is a core-adjacent router or governance package, with `sphere.fpf_bridge` left as a compatibility shim if needed.

---

## Path map — normalize by de-duplication or ownership flip

These are not simple “move to core” cases. They need ownership cleanup first.

| Current path(s) | Problem | Required action |
|-----------------|---------|-----------------|
| `hesperia/modules/tfp/math_v1.py` and `hesperia/engine/tfp_math.py` | overlapping TFP clinical math helpers in two places | choose one Class B canonical home under TFP module; leave one shim only |
| `hesperia/engine/calculus.py` | generic engine helper file depends on TFP-specific math | split generic helpers from TFP-specific bundle logic |
| `core/domain/*` and `hesperia/engine/kme/*` | core namespace points to engine.kme canon via re-export shims | pick one canon: preferably move universal KME/domain primitives into `core/domain/*`, leave engine shims |
| `hesperia/product/service.py` and sealed spine | product service runs `run_pipeline()` instead of sealed multiscale product path | rebind V7 product surface to sealed spine before seal |
| `hesperia/engine/pipeline_runner.py` vs `hesperia/VERSION.yaml` | version story is inconsistent (`0.7.0` vs `0.6.0`) | unify single source of truth before V7 sealing |

### TFP math duplication

From inspection:

- `hesperia/engine/calculus.py` imports `hesperia.engine.tfp_math`
- `hesperia/tfp/__init__.py` imports `hesperia.modules.tfp.math_v1`

That means the clinical TFP branch is leaking in two directions at once.  
For V7 fusion, this is wrong:

- generic engine code should not own clinical stage semantics,
- the TFP module should own TFP-specific stage, intervention, and affect heuristics.

### KME/domain ownership inversion

`core/domain/*` currently looks like the right canonical home from a V7 architecture perspective, but many files say:

- “Legacy re-export. Canonical: `hesperia.engine.kme...`”

At the same time, many tests already import `core.domain.*`.

That is the classic sign that the architecture wants the canon in `core/domain`, but implementation ownership has not been flipped yet.  
This is a prime V7 fusion task.

---

## Path map — keep branch-specific or non-cored

These should **not** be pulled into sealed core.

| Path group | Why it stays non-cored |
|-----------|-------------------------|
| `hesperia/modules/tfp/*` | clinical / TFP module surface, branch-specific |
| `hesperia/modules/tfp/data/tfp_v1/*` | branch corpus and provenance data |
| `hesperia/nlp/*` | much of this is session/clinical and not baseline core NLP plumbing |
| `hesperia/engine/kme/clinical_bridge.py` | explicit clinical activation → graph bridge |
| `hesperia/extensions/triz/*` | contradiction and TRIZ layer is branch/domain logic, not sealed universal core |
| `hesperia/product/service.py`, `hesperia/product/*` UI/output builders | product surface logic should compose canon, not become canon |
| `hesperia/ontology/dictA/*`, `hesperia/ontology/dictB/*` content packs | governed assets and domain data, not generic code fusion |
| `sphere/logic/*`, `sphere/interpretation/*`, `sphere/prolog_logic/*`, `sphere/pipeline/*` | legacy/parallel sphere family should not be merged blindly into sealed product core |

### Important nuance on `hesperia/modules/*`

The Class A module wrappers themselves should stay as wrappers:

- `hesperia/modules/core/dict_a.py`
- `hesperia/modules/core/dict_b.py`
- `hesperia/modules/topology/core.py`
- `hesperia/modules/nlp/basic.py`
- `hesperia/modules/metrics/base.py`
- `hesperia/engine/module_aliases.py`

These are not the fusion target.  
They are the modular interface layer over fused core logic.

---

## Concrete findings that matter for V7

## Finding 1 — `FPF-V7` runtime truth is real in `/data/hesperia/hesperia`

`/data/hesperia/hesperia` contains:

- `sphere/fpf_bridge/*`
- `specs/canon/fpf_bridge_v7.md`
- `tests/test_fpf_bridge.py`

So the bridge is not hypothetical. It exists in the implementation tree inspected here.

## Finding 2 — product service is on the wrong spine for V7

[hesperia/product/service.py](/data/hesperia/hesperia/hesperia/product/service.py) still uses:

- `hesperia.engine.pipeline_runner.run_pipeline`

But the sealed runtime integrity and system seal are built around:

- `hesperia.engine.sealed_multiscale_stack`
- `hesperia.engine.multiscale_product_bridge`

So V7 productization should **not** ship by extending the current product service path unchanged.

## Finding 3 — version drift exists in code, not just docs

[hesperia/engine/pipeline_runner.py](/data/hesperia/hesperia/hesperia/engine/pipeline_runner.py) declares:

- `ENGINE_VERSION = "0.7.0"`

while [hesperia/VERSION.yaml](/data/hesperia/hesperia/hesperia/VERSION.yaml) still says:

- `system_version: "0.6.0"`
- `core_engine: "0.6.0"`

That must be resolved before any truthful post-fusion seal.

## Finding 4 — TFP-specific semantics still contaminate generic engine placement

[hesperia/engine/calculus.py](/data/hesperia/hesperia/hesperia/engine/calculus.py) imports TFP math primitives:

- `detect_tfp_stage`
- `estimate_affect_intensity`
- `compute_confidence_scores`
- `detect_interaction_loops`

Those are not generic whole-world core semantics.  
They should be owned by the TFP module line.

## Finding 5 — KME/domain wants a canonical home flip

Tests already use `core.domain.*`, but implementation canon still points to `hesperia.engine.kme.*`.  
For V7, that should be normalized so universal domain-graph math has one real home.

---

## Recommended fusion sequence

## Phase 1 — choose canonical homes

Make explicit ownership decisions before moving code:

1. `core/domain` becomes canonical for universal KME/domain math.
2. `core/math/observables.py` becomes canonical for field observables.
3. `core/math/semantic_field_equations.py` becomes canonical for generic semantic field equations.
4. `core/output/trace.py` or `core/audit/output_trace.py` becomes canonical for reverse-trace audit.
5. `core/router/fpf_bridge/*` becomes canonical for Layer 11 bridge substrate.
6. `hesperia.modules.tfp.*` becomes canonical for TFP-specific clinical heuristics.

## Phase 2 — move or wrap without breaking imports

Do the moves with temporary compatibility shims:

1. move generic code into new canonical homes,
2. keep old import paths as thin re-export shims,
3. update tests to target canonical homes first,
4. add import-ownership tests.

## Phase 3 — rebind V7 product surface to sealed spine

Before V7 API/product claims:

1. route V7 product entry through `multiscale_product_bridge`,
2. attach router envelope/audit on top,
3. stop treating `run_pipeline()` product service as the future V7 surface.

## Phase 4 — freeze seal

After fusion:

1. seal the canonical homes,
2. lock versioning,
3. lock import direction,
4. lock product path to sealed spine,
5. lock bridge as deterministic sublayer.

---

## Post-fusion seal gates

These are the gates I would require before calling the fused line sealed for V7.

### Gate S1 — import direction seal

- no generic engine file imports TFP clinical math,
- no universal domain math is canonical only under `hesperia.engine.kme`,
- `sphere.fpf_bridge` is shim-only if a core router canon exists.

### Gate S2 — product spine seal

- V7 product/service entry uses sealed multiscale path,
- no legacy or alternate path bypasses router/audit,
- `system_seal` verifies that route.

### Gate S3 — version seal

- one source of truth for engine version,
- no `0.7.0` labels while runtime manifest still reports `0.6.0`,
- bridge/router versioning is explicit and provenance-bound.

### Gate S4 — contract seal

- product contracts live in versioned canonical contract homes,
- router envelope and audit contracts are versioned,
- validators match those canonical schemas.

### Gate S5 — branch-boundary seal

- TFP-specific logic stays under TFP ownership,
- TRIZ and clinical bridge logic stay non-cored,
- module wrappers remain wrappers, not secret physics owners.

---

## Proposed test additions after fusion

| Test | Purpose |
|------|---------|
| `tests/architecture/test_core_domain_canonical_home.py` | forbid canon drift between `core/domain` and `engine/kme` |
| `tests/architecture/test_no_tfp_math_in_generic_engine.py` | prevent clinical heuristics from re-entering generic engine files |
| `tests/architecture/test_fpf_bridge_canonical_home.py` | enforce bridge canon + shim-only old path if moved |
| `tests/product/test_product_service_uses_sealed_spine.py` | ensure V7 product entry stays on sealed path |
| `tests/system_seal/test_version_single_source.py` | catch `ENGINE_VERSION` vs `VERSION.yaml` drift |

---

## Bottom line

The codebase is already close enough to support a serious V7 fusion line, but the fusion must be disciplined:

1. **preserve the sealed multiscale spine,**
2. **fuse generic math, observability, audit, and bridge substrate inward,**
3. **reverse the ownership drifts,**
4. **keep TFP, TRIZ, and clinical bridges non-cored,**
5. **seal only after import, version, contract, and product-path truth are aligned.**

The shortest trustworthy commandment from the inspected code is:

> **Fuse generic runtime math and governance inward; leave domain semantics outward; then seal the V7 product surface on the sealed multiscale spine.**

SIGNED: OpenAI/Codex (Aurel) | Hesperia V7 core fusion assessment | 2026-06-28 | path map, fusion map, seal map
