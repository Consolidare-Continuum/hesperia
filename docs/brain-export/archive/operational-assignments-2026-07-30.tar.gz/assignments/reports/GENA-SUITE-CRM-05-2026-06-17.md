# Gena — SUITE-CRM-05 approval / delivery

**Date:** 2026-06-17  
**Task:** SUITE-CRM-05 — V8 API OAuth client + n8n credential

## Delivered

| Item | Path |
|------|------|
| OAuth bootstrap script | `scripts/cluster/setup-suitecrm-oauth-n8n.sh` |
| n8n credential guide | `cluster/prichindel/suitecrm/N8N-CREDENTIAL.md` |
| Live creds (prichindel) | `/root/.secrets/suitecrm/oauth-n8n.env` |

## Verify (prichindel)

- `client_credentials` token from `/legacy/Api/access_token` — **OK**
- `GET /legacy/Api/V8/meta/modules` with Bearer — **OK**
- OAuth client `n8n-agent-cursor` with `assigned_user_id` = admin

## n8n decision

**Direct OAuth2 API credential** on n8n (not custom MCP, not n8n-only HTTP without OAuth). Matches Planfix pattern: orchestration in n8n, secrets on host.

SIGNED: Gena | SUITE-CRM-05 DONE | 2026-06-17
