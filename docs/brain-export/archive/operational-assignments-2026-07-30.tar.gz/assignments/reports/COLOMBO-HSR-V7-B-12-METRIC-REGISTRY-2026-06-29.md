# Colombo — Metric registry Class A vs domain-specific (HSR-V7-B-12)

**Date:** 2026-06-29  
**Registry:** `assets/config/output_metric_registry_v1.json` (dev clone)  
**Note:** Task text says `metric_layer`; canonical artifact is **`output_metric_registry_v1.json`** artifact keys (planes), not a separate `metric_layer` module.

---

## Classification by registry artifact

| Registry artifact key | Example metrics | Class | Rationale |
|----------------------|-----------------|-------|-----------|
| `structural_batch.L1` | `ATTRIBUTED_TOKENS`, `COVERAGE_RATIO`, `CALIBRATION_FALLBACK_USED` | **A** | Universal structural batch semantics — comparable across runs |
| `structural_batch.diagnostics.calibration_status` | `marker_concept_mass`, `uniform_concept_prior_fallback_used`, `l1_calibration_fallback` | **A** contract / **B** pack binding | Semantics **A**; which calibration pack applies is **B** (`archive_063_minimal`, TFP packs) |
| `sealed.hex_activation_map` | `total_mass` | **A** | Sealed stack observable on hex plane |
| `product_analyze.result` | `governance` | **A** | Product `/analyze` governance index — universal |
| `kme.report.primitives` | `*` (per-primitive scalars) | **A** | KME fingerprint primitives — domain-agnostic machinery |
| `session_tfp_stages.areas_top` | `*` normalized activations | **B** | TFP session NLP plane — not comparable to lexicon structural without alignment spec (registry note) |

---

## Cross-plane rules

| Rule | Class |
|------|-------|
| `comparable_across_runs: true` on structural/L1 metrics | **A** — core contract metrics |
| `comparable_across_runs: false` on session/TFP planes | **B** — domain session slice |
| Anomaly codes referencing registry (`output_anomaly_codes_v1.json`) | **A** machinery — codes universal, thresholds may be B-tuned |

---

## Relation to Ethan/Felix lists

| Item | Alignment |
|------|-----------|
| Felix B-06 `product_signals`, observables on spine | **A** — covered by `product_analyze` + sealed planes |
| Ethan B-11 TFP `OBSERVABILITY_LEVELS` | **B** — separate from registry `session_tfp_stages` and from `context_rag.observability` |
| Partial registry coverage (draft v1) | **OK** — `OUTPUT_METRIC_REGISTRY_PARTIAL_COVERAGE_v1.md`; missing keys ≠ Class B by default |

---

## Verdict

Registry rows split cleanly: **structural/sealed/product/kme planes → Class A**; **`session_tfp_stages.*` → Class B**. Calibration **pack selection** stays Class B even when metric semantics are Class A.

---

SIGNED: Research (Colombo) | metric registry Class A/B | 2026-06-29 | B-12
