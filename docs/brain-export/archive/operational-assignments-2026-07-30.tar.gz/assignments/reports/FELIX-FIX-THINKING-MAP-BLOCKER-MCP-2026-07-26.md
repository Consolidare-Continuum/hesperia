# Felix — fix `close_thinking_map_blocker_eod` MCP (2026-07-26)

## Defect

EOD reported MCP close broken: `No module named 'thinking_maps.blocker_registry'`.

## Cause

`cursor-thinking-map` runs on **prichindel** via SSH against `/data/workspaces/cursor`. That clone was **172–219 commits behind** (`7c7f92da`) and lacked `thinking_maps/blocker_registry.py` (added in `a842cf3d`). Altitudine brain had the module; MCP host did not.

## Fix

1. `git reset --hard origin/main` on prichindel `/data/workspaces/cursor` → **`30c1ddda`**
2. Smoke: register blocker `245f124b525e` → MCP `close_thinking_map_blocker_eod` → **`eod_closed`**; digest pending **0**
3. Durable:
   - `scripts/sync-prichindel-mcp-brain.sh` (stash + hard reset + import check)
   - wired into `scripts/mcp/deploy-mcp-config-global.sh`
   - clearer RuntimeError hint in `agent_mcp_thinking_map/__main__.py`
   - `verify-thinking-map-mcp.sh` imports `blocker_registry`; optional `VERIFY_PRICHINDEL_MCP_BRAIN=1`
   - EOD workflow note when MCP import fails

## Verify

```
close_thinking_map_blocker_eod(245f124b525e) → status eod_closed
get_thinking_map_blocker_eod_digest → pending_count 0
```

SIGNED: Developer (Felix) | Claude Code / Cursor | 2026-07-26 | MCP blocker_registry
