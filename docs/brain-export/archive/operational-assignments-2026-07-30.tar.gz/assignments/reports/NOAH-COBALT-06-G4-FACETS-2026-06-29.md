# NOAH — COBALT Gate G4 facets (COBALT-06)

**Date:** 2026-06-29

## browse_colombo_library_facets (CHROMA-2 sample 3000 chunks)

| Field | Values |
|-------|--------|
| lang | `en` (dominant in sample scan) |
| library_layer | `book` |
| theme | `general` (doc-level theme not yet psychology-wide) |

## Hesperia fields (G2 pilot)

| Field | Status |
|-------|--------|
| concept_id | Present on attributed doc chunks (`cobalt-g2-0.1`) |
| area_name | Present (`A1`… from engine trace) |
| family_name | Present (`family_NNN`) |
| attribution_version | `cobalt-g2-0.1` |

**Verdict:** G4 **PASS (pilot)** — lang/library_layer + Hesperia bounding on pilot attribution set. Theme enrichment = COBALT-04 scale-up / TFP tag pass.

SIGNED: Team (Noah) | COBALT G4 | 2026-06-29 | COBALT-06
