# Ethan — Gate B resolve "decide later" (HSR-V7-B-21)

**Date:** 2026-06-29  
**Inputs:** B-04..20 reports · Ethan's class lists · Felix/Gena inventories

All B-04..20 items resolved — **no "decide later"** on critical path:

| Item | Resolution |
|------|------------|
| Modular branch vs Class A list | **A** — PASS (B-04) |
| TFP/MRT/COBALT separation | **B** — PASS (B-05) |
| HSPR_discovery research | **B/future** (B-11); `hspr_index` primitive **A** |
| Metric registry planes | **A** structural/sealed; `session_tfp_stages` **B** (B-12) |
| irc_teacher envelope core | **A**; OpenAI Teacher **B** (B-08 Gena) |
| thinking_map_bridge | **A** (B-13 Gena) |
| Router envelope fields | **A** core set locked (B-14 Gena) |
| Corpus snapshot machinery | **A** (B-16 Noah) |
| Approval primitives | **A** (B-17 Daniel) |
| Teacher sanitization | **A**; OpenAI path **B** (B-18 Sophia) |
| Test harness gold vs TFP fixtures | **A** / **B** (B-20 Ava) |

**Carry-forward (non-blocking):** `context_rag.observability` wire in Gate C; MySQL B columns populate or narrow in Gate C.

---

SIGNED: Architecture (Ethan) | B-21 resolve | 2026-06-29
