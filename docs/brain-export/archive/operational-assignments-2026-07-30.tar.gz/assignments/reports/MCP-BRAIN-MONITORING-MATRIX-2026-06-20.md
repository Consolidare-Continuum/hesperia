# Monitoring ownership — MCP-BRAIN wave

**MCP-BRAIN-018** · Sophia

| Signal | Owner |
|--------|-------|
| cursor-mcp-exporter :9097 | Abelard |
| mcp_config_drift cron | Abelard / Liam |
| verify-mcp-appendix | Gena / Abelard |
| SURVEILLANCE §18 | Sophia |
| MCP compliance rows | Ethan / Grace |

SIGNED: Monitoring (Sophia) | MCP-BRAIN-018 | 2026-06-20
