# HSR-V7-12 — Final wording sweep (router/governor language)

**Date:** 2026-06-29  
**Owner:** Colombo  
**Scope:** New Hesperia v7 router/calibration docs (post HSR-V7-01 ratification)

---

## Files reviewed

| Path | Finding |
|------|---------|
| `docs/specs/HSR-V7-ROUTER-ENVELOPE-v0_1.md` | OK — router/fingerprint language |
| `docs/specs/HSR-V7-CORPUS-SNAPSHOT-POLICY.md` | OK — provenance, no reasoning overclaim |
| `sphere/router/prompt_envelope.py` | OK — explicitly forbids black-box reasoning as evidence |
| `sphere/calibration/llm_calibration.py` | OK — governed envelope, map step |
| Brain `governance/SPEC-ETHAN-HESPERIA-V7-SEMANTICS-ROUTER-COMPLIANCE.md` §6.2 | OK — canonical |
| Brain `operational/assignments/reports/OLIVIA-HSR-V7-10-*.md` | OK — "No vendor reasoning exposure" |

## Replacements

None required in v7 router/calibration surface — no "Hesperia reasons" or "inspectable vendor reasoning" claims found.

## Residual (out of scope this sweep)

Legacy docs (e.g. `docs/specs/0.6.3-IRC-TEACHER-RUN.md`) retain pre-v7 "reasoning prose" operator rules — not router/governor surface.

---

SIGNED: Research (Colombo) | HSR-V7-12 wording sweep | 2026-06-29 | v7 router docs
