# FELIX/GENA — COBALT-04 G2 batch attribution

**Date:** 2026-06-29

## Deliverable

`tools/cobalt_chroma2_attrib_batch.py` — doc-level engine trace → `concept_id`, `area_name`, `family_name` on CHROMA-2 chunks.

## Pilot run

- Attribution version: `cobalt-g2-0.1`
- Pilot docs processed (background job): ~25+ documents
- Sample verify: **50/50** chunks in first page carry `concept_id` + `area_name`
- `verify-hesperia-cobalt-gates.sh` G2 **PASS**

## Scale-up

Full 1.28M chunk corpus = scheduled batch (`--max-docs` / doc manifest), not blocking COBALT adapter or G3 pilot eval.

SIGNED: Developer (Felix) | COBALT G2 | 2026-06-29 | COBALT-04
