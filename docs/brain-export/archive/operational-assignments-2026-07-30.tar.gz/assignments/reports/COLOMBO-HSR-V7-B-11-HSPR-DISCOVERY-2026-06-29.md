# Colombo — HSPR_discovery classification (HSR-V7-B-11)

**Date:** 2026-06-29  
**Dev clone:** `/data/workspaces/atomic-commit-hesperia`  
**Inputs:** Ethan B-01/B-03 · modular architecture §5 research threads · `hesperia/engine/hspr_index.py`

---

## Disambiguation (three HSPR concepts)

| Concept | Location | Class | Role |
|---------|----------|-------|------|
| **`hspr_index` (sealed KPI)** | `hesperia/engine/hspr_index.py` · `run_sealed_multiscale_stack` output | **A** | Evidence-only scalar on field state — universal engine observable |
| **HSPR calibration index (field Σ̂)** | `runtime/semantic_field/`, `HSPR_CALIBRATION_INDEX_v1` | **A machinery** + **B packs** | Math **A**; calibration dict/threshold packs **B** |
| **HSPR_discovery (research thread)** | `colombo_research/` §5 — path/corpus-path discovery thesis | **B / future** | Relation-specific search — **not proven**, not prod |

---

## HSPR_discovery classification

| Slice | Class | Rationale |
|-------|-------|-----------|
| Emit `hspr_index` in `engine_trace` / public projection | **A** | Deterministic measurement primitive; test-locked (`tests/support/public_output_contract.py`) |
| Use `hspr_index` as router audit evidence | **A** | Values-only structural evidence — no relation mutation |
| Corpus-path / relation-path **discovery** proposals | **B** | Domain corpus + relation overlay — compose after sealed analyze |
| Auto-apply discovered paths to graph | **future-only** | Ethan B-03 — blocked until H070 sandbox apply |
| Thesis thread promotion to module | **future-only** | Requires Ethan + operator branch spec per §5 rule |

---

## Evidence-only vs relation-specific

| Question | Answer |
|----------|--------|
| Does `compute_hspr_index` mutate graph? | **No** — read-only aggregate on `field_state` |
| Does HSPR_discovery thread claim prod executor? | **No** — research in `colombo_research/` only |
| May discovery output enter `relation_context`? | **Yes as Class B optional block** — replay/reflection evidence (Gena B-14), not core physics |

---

## Verdict

- **Class A primitive:** `hspr_index` computation + contract enforcement on sealed stack.  
- **Class B / future:** HSPR_discovery research (path finding, relation-specific corpus navigation).  
- **No drain conflict** with modular §2c — index stays on spine; discovery stays branch/research.

---

SIGNED: Research (Colombo) | HSPR_discovery Class A/B split | 2026-06-29 | B-11
