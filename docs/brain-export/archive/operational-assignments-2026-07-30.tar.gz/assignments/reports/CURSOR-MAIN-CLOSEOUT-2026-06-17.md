# Cursor main close-out — 2026-06-17

**Scope:** Close remaining items from [CURSOR-MAIN-MONTHLY-AUDIT-2026-06-16.md](CURSOR-MAIN-MONTHLY-AUDIT-2026-06-16.md) (non-Papra).

## Done this pass

| Item | Result |
|------|--------|
| **M5 Windows agent SSH CA** | **CLOSED** — olgahere OpenSSH CA; lamaita Bitvise fixed `id_agent.pub` (`igare@`); fluturas **out_of_scope_cold_backup** (operator) |
| **M1 June compliance** | Row added [governance/CURSOR-REPO-COMPLIANCE-CHECK.md](../../../governance/CURSOR-REPO-COMPLIANCE-CHECK.md) |
| **M2 CHROMA retrieval QA** | [CHROMA-RETRIEVAL-QA-2026-06-17.md](CHROMA-RETRIEVAL-QA-2026-06-17.md) |
| **M4 MAIL-MX wave** | Register all DONE; **cursor-mailcow-mail** handshake OK on prichindel |
| **M8 colombo-library MCP** | Linux config 12 servers; LAMAITA `mcp-config-windows-lamaita.json` → 12 servers deployed to `BvSsh_lamaita`; handshake 12/12 on alunel |
| **MCP verify script** | Fixed colombo-library path (`chroma-2` venv), +mailcow +tailscale, locale-safe result grep |
| **Git** | Cursor-owned commits pushed (agent SSH + MCP close-out) |

## Explicitly open (operator / infra)

| Item | Status |
|------|--------|
| **PAPRA-29** ingest ~300 files | IN_PROGRESS — excluded from clean-tree |
| **W8 dirty Papra/Colombo/mail WIP** | Expected until ingest lands or split PR |
| **W9 PAPRA-16 fulgusor arc** | **DEFERRED** — local backup done; physical fulgusor **cold zip+README** ([COLD-BACKUP-POLICY.md](../../../cluster/fulgusor/COLD-BACKUP-POLICY.md)); **cloudmaster** owns `.40` |
| **M3 PAPRA-50** | Blocked on PAPRA-29 |
| **M9 cost baseline** | Optional — template still empty |

## Operator actions

- **LAMAITA:** fully quit and restart Cursor (12-server `mcp.json` deployed).
- **fluturas / fulgusor:** no action — cold on-demand backup until you re-open or power on for a drop.

SIGNED: Cursor main | monthly audit close-out | 2026-06-17 | non-Papra items
