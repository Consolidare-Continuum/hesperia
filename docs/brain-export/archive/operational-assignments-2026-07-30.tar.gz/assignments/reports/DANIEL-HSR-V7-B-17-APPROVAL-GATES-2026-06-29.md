# Daniel — Approval gate primitives as Class A (HSR-V7-B-17)

**Date:** 2026-06-29  
**Inputs:** `agent_mcp_approval_gates/` · `governance/approval_gates.json` · thinking-map `approval_id` evidence token

---

## Verdict

**Class A** — `approval_id`, `request_approval`, `get_approval_status`, and `record_approval` are universal audit/governance primitives. **Scope strings** and domain-specific gates (e.g. H070 graph apply) are Class B **applications** of the same primitive.

---

## Primitive inventory (Class A)

| Primitive | Location | Class | Role |
|-----------|----------|-------|------|
| `approval_id` | `thinking_maps/team_ops/map.py` required evidence | **A** | Machine evidence token for destructive workflow moves |
| `request_approval(scope, reason)` | `agent_mcp_approval_gates/__main__.py` | **A** | Creates pending gate; id `approval-{uuid}` |
| `get_approval_status(approval_id)` | same | **A** | Read gate state |
| `list_pending_approvals()` | same | **A** | Preflight listing |
| `record_approval(approval_id, status)` | same | **A** | Authoritative write path (human/authorized token only) |
| `governance/approval_gates.json` | brain repo | **A** | Persistence contract (`pending` / `approved` / `rejected`) |
| Integration contract | `governance/INTEGRATION-CONTRACT-thinking-map-approval-gates.md` | **A** | Map surfaces blockers; cannot substitute `record_approval` |

---

## Class B applications (use primitives, not redefine)

| Application | Class | Uses Class A primitives |
|-------------|-------|-------------------------|
| H070 `record_approval` before `applied=1` | **B** apply track | **yes** — scope e.g. `hesperia.graph.apply` |
| Router `BLOCK` + operator ACK | **A** router audit | **optional** — separate from brain approval file |
| Destructive cluster ops (Abelard) | **B** scope | **yes** — `approval_id` in thinking_map_step |

---

## Security properties (Class A contract)

| Property | Enforced |
|----------|----------|
| Map cannot call `record_approval` for operator | **yes** — Daniel policy |
| `record_approval` id must exist in pending | **yes** |
| Privilege escalation via arbitrary overwrite | **no** — id + status match only |

---

## Verdict for drain (Gate C)

Approval primitives stay in **brain MCP + governance** — do not fork into Hesperia sealed core. Hesperia router references policy via `policy_block` / `RouterDecision`, not duplicate approval store.

---

SIGNED: Security (Daniel) | approval gate Class A primitives | 2026-06-29 | B-17
