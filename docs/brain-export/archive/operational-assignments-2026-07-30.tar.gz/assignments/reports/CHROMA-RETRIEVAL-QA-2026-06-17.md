# CHROMA retrieval QA — June 2026

**Date:** 2026-06-17  
**Runner:** Cursor main (close-out pass)  
**Checklist:** [governance/CHROMA-RETRIEVAL-QA.md](../../../governance/CHROMA-RETRIEVAL-QA.md)

| # | Check | Result | Pass |
|---|-------|--------|------|
| 1 | Empty layer (hesperia generic) | No chunks — expected for wrong/generic layer query | Y |
| 2 | Wrong layer | governance query for retired chroma-new → **Purged 2026-05-23** (CHROMA-INSTANCES), no "purge pending" | Y |
| 3 | Duplicate check | Same governance query 2× — identical top sources | Y |
| 4 | Stale document | chroma-new wrap re-ingested 2026-06-16; retrieval shows purged state | Y |
| 5 | Cross-layer bleed | books layer query → book PDF chunks only, no governance workflow rows | Y |
| 6 | Books layer | `layer=books` + architecture → valid book filenames | Y |
| 7 | Latency | MCP `query_knowledge` from altitudine IDE path < 5s per query | Y |

**MCP handshake (alunel):** 12/12 OK incl. **colombo-library**, **cursor-mailcow-mail**, **cursor-tailscale** — `scripts/mcp/verify-mcp-handshake.sh`.

SIGNED: Cursor main | CHROMA retrieval QA | 2026-06-17 | monthly close-out
