# Colombo — MONTHLY-MAINT-04 brain team repo context (2026-07-14)

**Owner:** Colombo · **Wave:** MONTHLY-MAINT

## INVENTORY (what exists)

| Asset | State |
|-------|-------|
| Team brain repo | `/data/altitudine/prichindel.com` on **altitudine** (dev office) |
| CHROMA-1 | heartbeat **200** (`chroma-1.prichindel.local:8002`) |
| CHROMA-2 / colombo-library | Territory unchanged — librarymaster Papra; not reindexed this pass |
| Source map | [agents/colombo/COLOMBO-SOURCE-MAP.md](../../../agents/colombo/COLOMBO-SOURCE-MAP.md) |
| Context archive | [.cursor/CONTEXT-ARCHIVE.md](../../../.cursor/CONTEXT-ARCHIVE.md) |
| OPEN product rows | FBV72/73/74 Hesperia (separate from this hygiene wave) |
| Monthly wave | MONTHLY-MAINT-00..04 |

## LOCATE

- Process/roles/workflow → CHROMA-1 `query_knowledge` (MCP not in this IDE session descriptor folder — config present in `~/.cursor/mcp.json`, drift **0**; restart Cursor to reload tools in IDE).
- Library books/papers → **colombo-library** / CHROMA-2 only.
- Maintenance policy → `cluster/MAINTENANCE_POLICY.md`.

## FORMALIZE

**Brain team repo context** for July 2026 monthly: team execution path remains Grace triage → active.md → owner → report_done → SuiteCRM; Abelard owns cluster VM pass; Ethan owns allowlist/trash; Colombo owns map + archive freshness, not infra.

## DRAFT / updates this pass

1. Prepended **2026-07-14 monthly maintenance** block to CONTEXT-ARCHIVE.
2. Bumped COLOMBO-SOURCE-MAP **Updated** date; added monthly-maint pointer under brain paths.
3. This report.

## fpf-thinking-map verify

Local `fpf_thinking_map.verify.main()`: **22/22 ALL PASS** (Colombo mandatory MCP substitute this session — IDE MCP tools absent except browser).

## NEXT

1. **Abelard** — confirm CHROMA-1 whole-repo ingest after this wave commits land on alunel clone.
2. **Colombo** — FBV74-03 TFP tag pass remains OPEN (product wave; not this hygiene).
3. **Operator** — IDE full restart if MCP tools besides browser missing from session.

SIGNED: Researcher (Colombo) | MONTHLY-MAINT-04 | 2026-07-14 | brain team context
