# Sophia — Teacher boundary Class A vs Class B (HSR-V7-B-18)

**Date:** 2026-06-29  
**Dev clone:** `/data/workspaces/atomic-commit-hesperia`  
**Inputs:** Gena B-08 · `sphere/router/prompt_envelope.py` · `runtime/irc_teacher/`

---

## Verdict

**PASS** — sanitization and values-only envelope contracts are **Class A** universal boundaries. OpenAI/RU Teacher client and IRC orchestration are **Class B** provider/application paths.

---

## Class A — universal boundary machinery

| Component | Path | Role |
|-----------|------|------|
| `build_prompt_envelope` | `sphere/router/prompt_envelope.py` | Strips raw operator text from prompt substrate; bounded tasks |
| `enforce_prompt_policy` / `enforce_prompt_policy_or_raise` | same | Forbidden keys (`input_text`, `chain_of_thought`, …) + regex patterns |
| `_DEFAULT_FORBIDDEN_ACTIONS` | same | No graph mutation / clinical truth without corpus |
| `build_engine_run_envelope` | `runtime/irc_teacher/engine_run_envelope.py` | Git SHAs, roads, activations — audit envelope |
| `serialize_teacher_packet` | `runtime/irc_teacher/teacher_packet.py` | Values-only KSI packet (schema-agnostic structural) |
| `analyze_adapter` | `runtime/irc_teacher/analyze_adapter.py` | HTTP `/analyze` bridge — no provider |
| V7 `product_interpret` path | `runtime/services/product_interpret_service.py` | Router sanitization without `run_irc_teacher_path` |

---

## Class B — provider / Teacher application

| Component | Path | Why B |
|-----------|------|-------|
| `call_openai_teacher_v063` | `runtime/irc_teacher/teacher_v063.py` | OpenAI API + RU system prompt |
| `teacher_response.v063` schema | same | Provider response contract |
| `run_irc_teacher_path` | `runtime/irc_teacher/run.py` | 0.6.3 Teacher app orchestrator |
| `irc_teacher_emitter` | `runtime/irc_teacher/irc_teacher_emitter.py` | tersagor/IRC surface |
| `mysql_ledger` RU columns | `runtime/irc_teacher/mysql_ledger.py` | `input_text_ru`, `input_kind=tfp_scientific_statement` |
| Hybrid retrieve (when enabled) | `analyze_adapter.retrieve` | Corpus/session retrieval — domain path |

---

## Boundary matrix

| Concern | Class A handling | Class B handling |
|---------|------------------|------------------|
| Raw operator text in LLM prompt | **Blocked** — `input_text` not in `RouterPromptEnvelope` | Teacher v063 may include RU clinical context in B path only |
| Hidden reasoning as evidence | **Forbidden** in prompt policy + audit | N/A — vendor CoT never auditable evidence |
| Engine trace to LLM | **Allowed** via bounded `engine_trace` subset | Teacher packet adds KSI incidents (values-only) |
| Graph/auto-apply authority | **Blocked** at prompt + audit | Proposals in Teacher response require separate H070 gate |

---

## Security note (D-23 follow-up)

Router v7 `/product/interpret` uses Class A sanitization. IRC Teacher stack remains Class B — enable flags (`HESPERIA_IRC_TEACHER`) must not bypass router audit when converged in Gate C.

---

SIGNED: Security (Sophia) | Teacher boundary Class A/B | 2026-06-29 | B-18
