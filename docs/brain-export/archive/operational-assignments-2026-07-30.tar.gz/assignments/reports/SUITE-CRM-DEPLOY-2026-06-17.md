# SUITE-CRM deploy — operational check-out

**Date:** 2026-06-17  
**Host:** prichindel (`192.168.100.21`)  
**URL:** `https://suite.prichindel.local`  
**Version:** SuiteCRM **8.10.1**

## Verify (prichindel)

| Check | Result |
|-------|--------|
| `curl -sk https://suite.prichindel.local/` | **200** |
| `curl http://127.0.0.1:8082/` | **200** |
| `docker exec suitecrm php bin/console suitecrm:version` | **8.10.1** |
| Messenger worker | **running** (`messenger:consume internal-async`) |
| Containers | `suitecrm` + `suitecrm_db` up |

## Credentials

- **User:** `admin`
- **Password:** on prichindel only — `sudo grep SUITECRM_ADMIN_PASSWORD /root/.secrets/suitecrm/env.backup`

## DNS

- **prichindel** `/etc/hosts` — alias on `.21` line (deploy script)
- **LAN nodes:** run `sudo bash scripts/cluster/cluster-merge-lan-hosts.sh` (brain repo)
- **AD (recommended):** `suite.prichindel.local` A → `192.168.100.21` on actarus/dnsmaster

## TLS

Self-signed at `/etc/ssl/suitecrm/` — browser will warn; accept for LAN use.

## Phase 2

Completed 2026-06-17 — see [GENA-SUITE-CRM-05-2026-06-17.md](GENA-SUITE-CRM-05-2026-06-17.md), [SUITE-CRM-08-WAVE-CLOSURE-2026-06-17.md](SUITE-CRM-08-WAVE-CLOSURE-2026-06-17.md).

SIGNED: Abelard deploy verify | SUITE-CRM-01..04 DONE | 2026-06-17
