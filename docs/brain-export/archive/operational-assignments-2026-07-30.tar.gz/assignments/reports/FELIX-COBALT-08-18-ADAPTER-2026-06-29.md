# FELIX — COBALT adapter chain (COBALT-08..13, 17, 18)

**Date:** 2026-06-29 · **Branch:** `hsr-v7-router-implementation`

| ID | Deliverable |
|----|-------------|
| COBALT-08 | `runtime/cobalt/` package |
| COBALT-09 | `compose_and_retrieve()` |
| COBALT-10 | `chroma2_client.py` — HttpClient + embeddings (matches Papra model) |
| COBALT-11 | `HESPERIA_COBALT_ENABLED=0` default in `flags.py` |
| COBALT-12 | `analyze_adapter.retrieve()` optional COBALT |
| COBALT-13 | `cobalt_retrieval` packet + product interpret field |
| COBALT-17 | `retrieval_context` populated when flag on |
| COBALT-18 | `tests/cobalt/test_cobalt_retrieve.py` |
| COBALT-22 | `scripts/verify-hesperia-cobalt-gates.sh` |

**G2 blocker:** prod flag remains 0 until attribution (COBALT-04).

SIGNED: Developer (Felix) | COBALT | 2026-06-29
