# Thinking-map technical blockers — EOD queue (2026-07-20T22:36:03Z)

Pending (open + fixed_runtime): **23**
Registry: governance/thinking_map_blockers.jsonl

| blocker_id | status | class | task_id | outcome | registered |
|---|---|---|---|---|---|
| 79a524ec867b | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-07-20T22:24:26Z |
| 839a2c67e8d1 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-07-20T22:24:26Z |
| 0cf45d835c7f | open | collect_evidence | EOD-structure | OutcomeKind.COLLECT_EVIDENCE | 2026-07-19T14:34:05Z |
| b7ce370a62ea | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-07-15T22:03:31Z |
| c030c02ca690 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-07-15T22:03:31Z |
| e3da3e1484be | open | collect_evidence | CC_-04 | OutcomeKind.COLLECT_EVIDENCE | 2026-07-15T14:27:08Z |
| fcbef591ce53 | open | access_denied | WFH-DIMA-S-ACCESS-01 | OutcomeKind.COLLECT_EVIDENCE | 2026-07-14T10:57:46Z |
| c27ff3036884 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-07-14T10:51:16Z |
| 36093158fb48 | open | collect_evidence | ATM-WP-PROD-02 | OutcomeKind.COLLECT_EVIDENCE | 2026-07-14T10:51:09Z |
| de5eda085476 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-07-14T10:26:53Z |
| a532cd5d5035 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-07-14T10:26:53Z |
| 1259c1ba83a8 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:37:15Z |
| e48061c6b2d4 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:37:15Z |
| 42000e1a4f8b | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:33:43Z |
| 06b4fe0fdf84 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:33:43Z |
| 431addf5d637 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:32:57Z |
| c49bea556b1d | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:32:57Z |
| 462727a75bed | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:05Z |
| 8c01c7ad6bd7 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:05Z |
| 09f0a2a82234 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:02Z |
| 7b2a604a6602 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:18:02Z |
| e334dfe63442 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:14:33Z |
| 7cb08dec8a36 | open | collect_evidence |  | COLLECT_EVIDENCE | 2026-06-28T13:14:33Z |

### 79a524ec867b (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 839a2c67e8d1 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 0cf45d835c7f (collect_evidence) — open
- task: EOD structure
- reason: Evidence gaps: ['eod_blockers_reviewed']
- missing_evidence: eod_blockers_reviewed

### b7ce370a62ea (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### c030c02ca690 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### e3da3e1484be (collect_evidence) — open
- task: CC_ legal-entity: Grace keeper CHROMA-1 ingest + availability inventory + workflow proceed
- reason: Evidence gaps: ['task_id']
- missing_evidence: task_id

### fcbef591ce53 (access_denied) — open
- task: Grant dima.s SSH+files+DB access to wellfedhippo on prichindel; store pubkey in Authentik
- reason: Evidence gaps: ['agent_cert_valid', 'snapshot_fresh']
- missing_evidence: agent_cert_valid, snapshot_fresh

### c27ff3036884 (collect_evidence) — open
- task: ATM-WP-PROD-02 seed ACT repo
- reason: 

### 36093158fb48 (collect_evidence) — open
- task: ATM-WP-PROD seed Atomic-Commits-Team/fpf-atm-wordpress-publisher
- reason: Evidence gaps: ['task_id']
- missing_evidence: task_id

### de5eda085476 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### a532cd5d5035 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 1259c1ba83a8 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### e48061c6b2d4 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 42000e1a4f8b (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 06b4fe0fdf84 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 431addf5d637 (collect_evidence) — open
- task: web_ui
- reason: 
- missing_evidence: web_snapshot_done

### c49bea556b1d (collect_evidence) — open
- task: edge_ops
- reason: 
- missing_evidence: cf_observability_done

### 462727a75bed (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 8c01c7ad6bd7 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 09f0a2a82234 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 7b2a604a6602 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### e334dfe63442 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read

### 7cb08dec8a36 (collect_evidence) — open
- task: workflow_execute
- reason: 
- missing_evidence: get_current_step_done, query_knowledge_done, runbook_read
