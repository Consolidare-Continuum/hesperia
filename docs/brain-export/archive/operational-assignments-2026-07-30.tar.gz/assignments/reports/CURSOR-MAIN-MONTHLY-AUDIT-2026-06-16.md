# Cursor main — monthly operator audit

**Date**: 2026-06-16 (UTC)  
**Session**: `execution_host=altitudine`, `role=dev_vm_ulim`, `dev_office=true`, `connectivity=lan`  
**Operator**: igareosh  
**Standing brief**: [governance/CURSOR-MAIN-MONTHLY-OPERATOR-BRIEF.md](../../../governance/CURSOR-MAIN-MONTHLY-OPERATOR-BRIEF.md)

---

## Executive summary

The brain repo is **operationally mature** — workflow, MCP design, CHROMA-1 cutover, BODY-FLOW / WF-APP / REPO-AUTO waves, host separation policy, and Colombo/CHROMA-2 territory are real assets. **June 2026 friction** is mostly **drift and unfinished long runs**: agent SSH cert expired today, CHROMA-1 whole-repo ingest stale (~16 days), PAPRA CHROMA-2 reindex ~10% with a chain of PAUSED tasks, a large uncommitted working tree, and **contradictory “where is dev office?”** text across top-level docs. Several **monthly compliance scripts are broken by path** (`mcp_config_drift_check.sh` REPO_ROOT and missing `scripts/` wrapper). **June start-of-month compliance row is missing** (last formal start-of-month: 2026-05-14).

---

## Done right (keep; do not churn)

| Area | Why it works |
|------|----------------|
| **Single workflow path** | `active.md` → driver → executor / Cursor-in-IDE; heartbeat authoritative; captain_on_deck respected |
| **CHROMA-1 canonical** | Live heartbeat **200** at `chroma-1.prichindel.local:8002`; prichindel chroma-new purged with archive |
| **MCP architecture** | One `governance/mcp-config.json`, deploy script, 9+ servers documented; **drift_detected=0** when check runs with correct `REPO_ROOT` |
| **Host separation (intent)** | `HOST-ALTITUDINE-VS-LIBRARYMASTER`, `ALUNEL-HOLY-COW-POLICY`, session detector + `brain_path_warning` — correct mental model once unified |
| **Territory policy (2026-06-16)** | CHROMA-1 agent-silent / CHROMA-2 operator+Colombo / Tersagor infra-not-entity — reduces operator noise |
| **Colombo entity + Papra wave** | PAPRA-00..28 largely DONE; G0 verification, vector approval, schema v1 ingest worker wired |
| **Compliance habit** | `CURSOR-REPO-COMPLIANCE-CHECK.md` dense audit trail; EOD/EOW workflows exist |
| **Cluster access flow** | Agent SSH CA, trustmaster-hub, MCP `fix_agent_cluster_access` — defect-aware, not retry loops |
| **Hesperia program** | Multiple sealed waves (0.6.x), debloat to dev repo, execution-gap registers — serious engineering |
| **Tone / quality floor** | did/asked/result, MCP-first, Grace triage path — matches how you actually work |
| **June bare closure** | Abelard networking/bare topic closed 2026-06-15 — holy cow audit 0/0 |

---

## Wrong (factual defects)

| # | Issue | Evidence |
|---|--------|----------|
| W1 | **Agent SSH cert expired** | `governance/agent_ssh_cert_status.txt` `valid_until: 2026-06-16T03:11:17+03:00`; session `agent_cert=expired` |
| W2 | **`mcp_config_drift_check.sh` REPO_ROOT bug** | Script at `scripts/mcp/` uses `dirname/..` → `scripts/` not repo root → `ERROR missing scripts/governance/mcp-config.json` |
| W3 | **Documented script path missing** | Docs/cron cite `scripts/mcp_config_drift_check.sh`; file only at `scripts/mcp/mcp_config_drift_check.sh` (no wrapper) |
| W4 | **CURSOR-MCP-SETUP stale Chroma ops** | §5 still says restart `chroma-new-docker` on prichindel — instance **purged 2026-05-23** |
| W5 | **CHROMA-1 index stale vs repo** | Last whole-repo ingest **2026-05-31** (920 files / 6200 chunks); major commits since (Colombo, Papra, mail MCP, territory policy) |
| W6 | **CHROMA-1 may serve contradictory chunks** | `query_knowledge` returned chroma-new “purge pending” text alongside “purged” — ingest refresh required |
| W7 | **Dev office contradictions** | `AGENTS.md` §1: primary dev office = **alunel**; `ALUNEL-HOLY-COW-POLICY`: dev → **altitudine VM**; `HOST-ALTITUDINE` table: altitudine `dev_office=false` but detector sets `dev_office=true` on altitudine |
| W8 | **Large dirty git tree uncommitted** | 30+ modified + untracked (Papra ingest, mailcow MCP, colombo-library, workflow state) — brain not one-tree clean on GitHub |
| W9 | **PAPRA-16 backup incomplete** | Row notes “fulgusor SSH pending” for CHROMA-2 backup drill |
| W10 | **Grace “evaporated” vs omnipresent Grace** | INDEX: Grace evaporated; every workflow still requires Grace triage — confusing for humans and weak models |

---

## Missing

| # | Gap | Notes |
|---|-----|-------|
| M1 | **June 2026 start-of-month compliance pass** | No June row like 2026-05-14 / 2026-04-14 pattern |
| M2 | **CHROMA retrieval QA execution** | Checklist exists ([CHROMA-RETRIEVAL-QA.md](../../../governance/CHROMA-RETRIEVAL-QA.md)); no June run recorded |
| M3 | **PAPRA-50 completion gate** | Reindex checkout script bundle when 999/999 — defined but blocked at 103/999 |
| M4 | **MAIL-MX wave execution** | Inbox 2026-06-15 triaged; verify MAIL-MX rows closed vs MCP `cursor-mailcow-mail` deploy on all Cursor hosts |
| M5 | **Windows agent SSH CA (Phase 2)** | **DONE** — olgahere + lamaita; fluturas cold backup out of scope |
| M6 | **Unified dev-office canonical paragraph** | One paragraph all top files must cite — pick: **altitudine VM** for daily dev + **alunel** CHROMA-1 service only |
| M7 | **Symlink or wrapper for monthly scripts** | `mcp_config_drift_check.sh` at documented path for cron on alunel |
| M8 | **CHROMA-2 colombo-library MCP on every IDE host** | New MCP + ingest glue — deploy-mcp + restart after push |
| M9 | **Cost/subscription snapshot** | `foundational/templates/cost-baseline.md` empty — optional but useful for “product retains money” lens |

---

## Requires fixing (actionable)

| Priority | Item | Owner | Action |
|----------|------|-------|--------|
| P0 | Agent SSH cert | Abelard | `bash scripts/trustmaster-hub fix-access` or `scripts/agent-ssh-cert-renew.sh` on alunel |
| P0 | MCP drift script path | Cursor/Liam | Fix `REPO_ROOT` to `../..`; add `scripts/mcp_config_drift_check.sh` wrapper calling `scripts/mcp/` |
| P0 | CURSOR-MCP-SETUP §5 | Cursor | Replace chroma-new restart with CHROMA-1 on alunel restart/runbook |
| P1 | CHROMA-1 whole-repo ingest | Abelard | After push: alunel `ingest-whole-repo.sh`; record file/chunk counts in compliance row |
| P1 | Commit/push Papra+Colombo+mail wave | Cursor + operator | Scope commit; leave unrelated dirt; one-tree `main` |
| P1 | PAPRA-29 reindex monitor | Abelard | 103/999 — confirm still running or restart; unblock PAPRA-30..50 chain |
| P1 | Dev office doc unification | Cursor (EOW row) | Single source: amend `AGENTS.md`, `HOST-ALTITUDINE`, `cursor-main-awareness` to match holy-cow + altitudine VM |
| P2 | HOST-ALTITUDINE altitudine row | Cursor | `dev_office=true` for altitudine VM in table (match detector) |
| P2 | fulgusor CHROMA-2 backup drill | Abelard | Complete PAPRA-16 fulgusor leg when host up |
| P2 | Grace evaporated wording | Cursor | INDEX/inbox: “Grace = triage orchestrator (team persona); entity evaporated” one line |

---

## Requires improving (hygiene, not emergencies)

| Area | Improvement |
|------|-------------|
| **active.md size** | 399 DONE rows — archive DONE waves to `archive/` registers only; keep active lean |
| **Policy surface** | `.cursor/rules/` + governance strong — schedule **EOW** integration pass to dedupe host/chroma paragraphs |
| **Inbox** | Recent entries triaged; scan >30d New per BF-009 monthly |
| **Entity count** | Standardize **15 entities** (incl. Colombo, Copilot main) in all rules — remove stale “13/14” |
| **Chroma cookbook** | `CHROMA-COOKBOOK-ABELARD.md` still mentions prichindel chroma-new paths — point to CHROMA-1 alunel |
| **Subscription/product** | Cursor subscription is justified by **this** brain — monthly audit + EOW is the “give back” loop; consider pinning default model on heavy research sessions |
| **Hesperia vs brain boundary** | Debloat wave done — enforce “links in brain, content in hesperia repo” in agent rules (already policy; audit quarterly) |
| **Operator notify** | tersagor monthly summary when audit finds P0 items |

---

## Blocked on operator (decisions only)

| Decision | Context |
|----------|---------|
| PAPRA reindex patience | ~3d ETA at 10%; pause vs let run |
| Push large dirty tree | Which untracked Papra/mail files are prod-ready vs WIP |
| CHROMA-MIG historical chunks | Re-ingest vs accept until next EOD ingest |
| fulgusor reachability | Backup drill when host on LAN |

---

## Live checks this session

| Check | Result |
|-------|--------|
| CHROMA-1 heartbeat | **200** |
| MCP drift (REPO_ROOT set) | **drift_detected=0** |
| MCP drift (default script path) | **FAIL** (W2) |
| Workflow OPEN | **0** (heartbeat); IN_PROGRESS: PAPRA-29; PAUSED: 8 |
| query_knowledge | OK (stale chroma-new chunks in results — W6) |

---

## Next monthly trigger

Invoke: **"Cursor main, monthly"** or run [.cursor/END-OF-MONTH-WORKFLOW.md](../../../.cursor/END-OF-MONTH-WORKFLOW.md).

Pair with: compliance row + `REPO_ROOT=$(pwd) bash scripts/mcp/mcp_config_drift_check.sh` + CHROMA retrieval QA.

SIGNED: Cursor main | monthly operator audit | 2026-06-16 | igareosh standing request

---

## Verification (Cursor main — post-Felix/Abelard, 2026-06-16 eve)

**Papra scope (operator 2026-06-16):** PAPRA / CHROMA-2 library ingest **not closed** — ~300 files remaining. Monthly audit treats Papra rows as **in progress**, not DONE.

**Commits reviewed:** `4f405974` · `9deef3b1` · `9fa1bf2f`

| Audit item | Status | Notes |
|------------|--------|-------|
| W1 Agent SSH cert | **DONE** | Renewed; valid until 2026-06-17T23:03 (`9deef3b1`) |
| W2 MCP drift REPO_ROOT | **DONE** | `../..` fix + wrapper committed Cursor main 2026-06-16 |
| W3 Script path wrapper | **DONE** | `scripts/mcp_config_drift_check.sh` |
| W4 CURSOR-MCP-SETUP §5 | **DONE** | `4f405974` |
| W5 CHROMA-1 ingest stale | **DONE** | `9deef3b1` — 667 files / 4450 chunks from alunel |
| W6 Stale Chroma chunks | **DONE** | delete-by-source + re-ingest on alunel (Cursor main 2026-06-16); `query_knowledge` returns **Purged 2026-05-23** |
| W7 Dev office contradictions | **DONE** | AGENTS + HOST-ALTITUDINE unified (`4f405974`); Cursor main fixed deploy split + entity count same session |
| W8 Dirty git tree | **OPEN** | Papra/Colombo/mail WIP — **excluded** while Papra ingest ~300 files remaining |
| W9 PAPRA-16 fulgusor backup | **OPEN** | unchanged |
| W10 Grace wording | **DONE** | INDEX one-liner (`4f405974`) |
| M6 Dev office canonical | **DONE** | altitudine VM `.65` |
| Entity count 15 | **MOSTLY DONE** | `.copilot/*` (`9fa1bf2f`); AGENTS 14→15 fixed Cursor main eve |
| SURVEILLANCE §8 | **DONE** | `9fa1bf2f` + quick-ref row fixed Cursor main eve |
| Monthly EOM workflow | **PARTIAL** | Files exist; not committed to `main` |
| PAPRA-29 reindex | **OPEN (operator)** | Ingestion in progress ~300 files remaining — **not closed** |

**Live checks:** CHROMA-1 heartbeat **200** · MCP drift **0** (with local wrapper)

---

## Verification (Cursor main — 2026-06-17 close-out)

| Audit item | Status | Notes |
|------------|--------|-------|
| M5 Windows agent SSH CA | **DONE** | olgahere CA; lamaita Bitvise `igare@` fixed key; fluturas `out_of_scope_cold_backup` |
| M1 June compliance | **DONE** | CURSOR-REPO-COMPLIANCE-CHECK row 2026-06-17 |
| M2 CHROMA retrieval QA | **DONE** | [CHROMA-RETRIEVAL-QA-2026-06-17.md](CHROMA-RETRIEVAL-QA-2026-06-17.md) |
| M4 MAIL-MX wave | **DONE** | Register closed; mailcow MCP handshake OK |
| M8 colombo-library MCP | **DONE** | 12-server configs; LAMAITA deploy; verify 12/12 |
| W9 PAPRA-16 fulgusor | **DEFERRED** | Local backup done; physical fulgusor cold zip+README policy — cloudmaster owns .40 |
| PAPRA-29 / W8 WIP tree | **OPEN (operator)** | Ingest ~300 files — excluded |

Report: [CURSOR-MAIN-CLOSEOUT-2026-06-17.md](CURSOR-MAIN-CLOSEOUT-2026-06-17.md)

SIGNED: Cursor main | monthly audit close-out | 2026-06-17
