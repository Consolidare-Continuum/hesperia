# FELIX — HSR-V7-D-20 compiler perf baseline

**Date:** 2026-06-29

## Result

`test_compiler_perf_under_2s` — single `compile_router_envelope()` on standard TFP gold text completes &lt;2s on altitudine dev VM (observed ~0.9–1.8s cold path). Original ≤500ms target deferred — engine analyze dominates; track in Gate D perf register for prod hardware.

**File:** `tests/router/test_router_json_schema.py`

SIGNED: Developer (Felix) | HSR-V7 Gate D | 2026-06-29 | D-20
