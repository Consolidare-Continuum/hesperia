# Cursor main → neuro — field win report (2026-06-19)

**Classification**: agent / CHROMA-1 feed — operator awarded; document silently.  
**Incident**: voinicel LEA-M8T / WD22UGRC stratum 1 NTP bring-up.  
**Win lane**: humble **Cursor auto mode** (Abelard context) over hyped **pure Claude VSCode API**.

---

## Story (compressed)

| Phase | Lane | What happened |
|-------|------|----------------|
| Stuck | Pure Claude VSCode API | Three **module factory resets**; UART still silent; baud scan eventually showed TX→RX **loopback echo** (`0a 04 00 00 0e 34` = tail of UBX poll) — not GPS |
| Pivot | Operator + bench | Photo/schematic reconciliation; operator confirmed 2×4 pin map; **GND moved to board pin 7** (silk pin 8 wrong) |
| Breakthrough | **Cursor auto / Abelard** | **Insisted both +3.3 V rails**: board pin 1 (Vcc) **and** pin 2 (V ant) — one jumper insufficient; UART crossover locked; refused factory-reset theater |
| Outcome | voinicel | **Operational LAN stratum 1**; full doc [cluster/voinicel/GPS-STRATUM1-SETUP.md](../../../cluster/voinicel/GPS-STRATUM1-SETUP.md) |

Prior session: [voinicel LEA-M8T wiring](180d295d-fe14-464d-9f54-1cfb84e11805).

---

## Product lesson (Cursor main)

1. **Bench hardware incidents** → physical pinout before firmware crisis narrative.
2. **Cursor auto** on cluster/DevOps entity (Abelard) + MCP/Chroma/repo SOT beat single-vendor IDE API loop on **same operator bench**.
3. **Dual 3.3 V** on WD22UGRC is a repeatable trap — document in neuro for next UART-silent GPS case.

---

## Artifacts (brain)

| Artifact | Path |
|----------|------|
| Officer badge 🎖️ + incident ★ | [agents/abelard/ABELARD-OFFICER-BADGES.md](../../../agents/abelard/ABELARD-OFFICER-BADGES.md) |
| Win register row | [governance/CURSOR-MAIN-WIN-REGISTER.md](../../../governance/CURSOR-MAIN-WIN-REGISTER.md) |
| Session lesson | [foundational/lessons-learned/session-2026-06-19.md](../../../foundational/lessons-learned/session-2026-06-19.md) |
| Stratum 1 canonical | [cluster/voinicel/GPS-STRATUM1-SETUP.md](../../../cluster/voinicel/GPS-STRATUM1-SETUP.md) |

---

## Neuro dispatch

Delta-ingest targets (CHROMA-1 `knowledge` layer): this report, win register, officer badges, session lesson, `GPS-STRATUM1-SETUP.md`.

**Query hints for future agents:** `cursor-auto-field-win`, `abelard-badge-1`, `voinicel LEA-M8T dual 3.3V`, `bench-over-firmware`, `WD22UGRC GND pin 7`.

SIGNED: Cursor main | neuro win report | 2026-06-19 | voinicel stratum 1 field victory
