# MCP host verify — Hesperia HAND faces (altitudine dev)

**Date:** 2026-07-19  
**Owner:** Abelard (DevOps)  
**Rows:** FPF-MWI-21 · FPF-PRE07-15  
**Target host:** altitudine (`execution_host=altitudine`, dev office)

---

## Required layout

| Variable / path | Expected value |
|-----------------|----------------|
| `HESPERIA_REPO_ROOT` | `/data/workspaces/atomic-commit-hesperia` |
| Brain repo | `/data/altitudine/prichindel.com` |
| Hesperia dev clone | git remote → `igareosh/hesperia` |

---

## MCP launcher scripts

| Script | Status | Module |
|--------|--------|--------|
| `scripts/agent-mcp-hesperia-fpf-inspect.sh` | **Present** | `agent_mcp_hesperia_fpf_inspect` |
| `scripts/agent-mcp-hesperia-router.sh` | **To be added** (Felix MWI-01) | `agent_mcp_hesperia_router` |

Both scripts must:

1. Export `HESPERIA_REPO_ROOT` default `/data/workspaces/atomic-commit-hesperia`.  
2. Export `CURSOR_REPO_ROOT` to brain repo.  
3. `exec python3 -m agent_mcp_hesperia_*` with `PYTHONPATH` set.

**Pattern:** mirror existing inspect launcher:

```bash
export HESPERIA_REPO_ROOT="${HESPERIA_REPO_ROOT:-/data/workspaces/atomic-commit-hesperia}"
```

---

## Verify commands (run on altitudine)

```bash
# Repo root
test -d /data/workspaces/atomic-commit-hesperia && \
  test -f /data/workspaces/atomic-commit-hesperia/runtime/shipping/cli_main.py

# Inspect launcher
test -x /data/altitudine/prichindel.com/scripts/agent-mcp-hesperia-fpf-inspect.sh
HESPERIA_REPO_ROOT=/data/workspaces/atomic-commit-hesperia \
  bash /data/altitudine/prichindel.com/scripts/agent-mcp-hesperia-fpf-inspect.sh --help 2>/dev/null || true
# ^ MCP servers block on stdio — smoke = script exists + python -m import

python3 -c "import agent_mcp_hesperia_fpf_inspect" \
  --directory /data/altitudine/prichindel.com 2>/dev/null || \
  (cd /data/altitudine/prichindel.com && PYTHONPATH=. python3 -c "import agent_mcp_hesperia_fpf_inspect")

# Router launcher (when added)
test -f /data/altitudine/prichindel.com/scripts/agent-mcp-hesperia-router.sh || echo "PENDING: MWI-01"

# mcp-config
grep -q hesperia-fpf-inspect /data/altitudine/prichindel.com/governance/mcp-config.json
grep -q hesperia-router /data/altitudine/prichindel.com/governance/mcp-config.json || echo "PENDING: MWI-01 mcp-config entry"
```

---

## mcp-config expectation (post MWI-01)

```json
"hesperia-fpf-inspect": {
  "command": "bash",
  "args": ["/data/altitudine/prichindel.com/scripts/agent-mcp-hesperia-fpf-inspect.sh"]
},
"hesperia-router": {
  "command": "bash",
  "args": ["/data/altitudine/prichindel.com/scripts/agent-mcp-hesperia-router.sh"]
}
```

Deploy: `bash scripts/deploy-mcp-config-global.sh` from brain root; restart Cursor.

---

## Verdict

| Check | Result |
|-------|--------|
| `HESPERIA_REPO_ROOT` path exists | Run verify on altitudine |
| inspect launcher + module | Expected **PASS** |
| router launcher | **PENDING** Felix MWI-01 |
| mcp-config both servers | **PARTIAL** — inspect only until MWI-01 |
| Prod `/data/hesperia/hesperia` as MCP default | **NOT** approved — dev only |

**PRE07-G1 blocked until:** router script + mcp-config entry land (Felix MWI-01, Liam MWI-20).

---

## Notes

- MCP execution on altitudine runs **local bash launchers** — not SSH-to-prichindel for Hesperia faces.  
- prichindel chroma MCP host unchanged.  
- Do not point `HESPERIA_REPO_ROOT` at prod tree for agent rolling until security clinical gate.

---

`SIGNED: DevOps (Abelard) | Hesperia MCP host verify | 2026-07-19 | MWI-21 PRE07-15 altitudine dev`
