# voinicel stratum 1 — production operational report

**Date:** 2026-06-21  
**Owner:** Abelard  
**Node:** voinicel · WiFi `192.168.100.16` · mount `voinicel-sma-rail-magnet-01`

## Verdict

**OPERATIONAL** — production stratum 1 for cluster LAN. Survey-in **retired**. Position tier **10 m fixed** (site class).

## Production stack

| Component | Status | Detail |
|-----------|--------|--------|
| Fixed ARP | OK | `/var/lib/voinicel-gps/fixed-pos.json` · `fixedPosAcc_mm=10000` · CFG-TMODE2 applied |
| gpsd | OK | active, enabled |
| chrony | OK | active, enabled · **Stratum 1** · ref **PPS** |
| Survey cron | RETIRED | `/etc/cron.d/voinicel-gps-survey.retired` |
| Prod intake | OK | `/etc/cron.d/voinicel-gps-prod` · 15 min |
| Log retention | OK | `/etc/logrotate.d/voinicel-gps-prod` · 48 h local |
| chronomaster collect | OK | `/etc/cron.d/voinicel-gps-prod-collect` · 10 min |
| Archive | OK | `/srv/gnss/voinicel-sma-rail-magnet-01/` · latest symlink |

## Live tests (2026-06-21 ~12:50 UTC)

| Test | Result |
|------|--------|
| SSH voinicel | PASS |
| NMEA @ 9600 (`$GPGGA`, 10 sats, fix) | PASS |
| PPS 1 Hz `/dev/pps0` | PASS |
| chrony Stratum 1, `#* PPS` | PASS |
| `voinicel-gps-prod-export.sh` | PASS |
| chronomaster collect run | PASS `mode=stratum1-prod` |
| chronomaster sync from voinicel | PASS · ref `192.168.100.16` · **Stratum 2** |

## Cluster role

- **voinicel** = LAN stratum **1** reference (GPS+PPS)
- **chronomaster** (`192.168.100.63`) = stratum **2**, synced to voinicel WiFi IP
- Other LAN clients: `server voinicel.prichindel.local iburst` or `192.168.100.16`

## Notes

- NMEA shows `#?` in chrony while PPS is `#*` — expected; PPS disciplines, NMEA provides TOD only.
- Position tier **10 m** is environmental (multipath); not u-blox 1 m reference. See Colombo conclusion paper.
- Historical survey logs frozen under `/var/log/voinicel-gps-survey/` (not rotated by prod logrotate).

## Install paths (repo)

- voinicel: `cluster/voinicel/scripts/install-voinicel-gps-prod.sh`
- chronomaster: `cluster/chronomaster/scripts/install-voinicel-gps-prod-collect.sh`
- Doc: `cluster/voinicel/GPS-STRATUM1-SETUP.md` §7.6

SIGNED: DevOps (Abelard) | voinicel stratum1 prod | 2026-06-21 | operational verification
