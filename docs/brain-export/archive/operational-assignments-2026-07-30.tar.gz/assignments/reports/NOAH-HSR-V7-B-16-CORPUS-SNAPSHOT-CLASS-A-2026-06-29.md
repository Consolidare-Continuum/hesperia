# Noah — Corpus snapshot machinery as Class A (HSR-V7-B-16)

**Date:** 2026-06-29  
**Complements:** [NOAH-HSR-V7-08-CORPUS-SNAPSHOT-POLICY-2026-06-29.md](NOAH-HSR-V7-08-CORPUS-SNAPSHOT-POLICY-2026-06-29.md) · [NOAH-HSR-V7-A-16-CORPUS-SNAPSHOT-ID-2026-06-29.md](NOAH-HSR-V7-A-16-CORPUS-SNAPSHOT-ID-2026-06-29.md)

---

## Verdict

**Class A** — corpus snapshot machinery is universal provenance/audit plumbing. TFP/dict **content** and freeze dates are Class B corpus assets; the **id field, propagation, and audit hooks** are Class A.

---

## Machinery inventory (Class A)

| Component | Path | Class | Function |
|-----------|------|-------|----------|
| `corpus_snapshot_id` field | `sphere/router/envelope_v0_1.py` | **A** | Contract identity on `RouterInputEnvelope` |
| Compiler default + env | `sphere/router/pre_llm_compiler.py` | **A** | `HESPERIA_CORPUS_SNAPSHOT_ID` / `corpus-unset` default |
| Fingerprint input | `sphere/router/fingerprint.py` | **A** | Deterministic audit includes policy + retrieval hashes |
| Prompt evidence refs | `sphere/router/prompt_envelope.py` | **A** | `corpus:{id}` in `evidence_references` |
| Audit corpus check | `sphere/router/audit.py` | **A** | `CORPUS_MISSING` reason when `corpus-unset` + unsupported claims |
| Product response | `runtime/services/product_interpret_service.py` | **A** | `evidence_ids` includes snapshot id |
| Policy doc | `docs/specs/HSR-V7-CORPUS-SNAPSHOT-POLICY.md` | **A** | Format + audit rules (not TFP corpus content) |

---

## Class B boundary (corpus content, not machinery)

| Item | Class | Notes |
|------|-------|-------|
| Dict B JSONL pack `archive_063_minimal` | **B** | Asset lane — named by id, not merged into sealed physics |
| TFP data tree freeze point | **B** | Operator ratified freeze date in id string |
| `hesperia-corpus-0.6.3-dict-b-<date>` literal value | **B** | Snapshot **names** B corpus; machinery that carries the name is **A** |

---

## Provenance flow (Class A)

```text
context_packet / env → pre_llm_compiler.corpus_snapshot_id
  → RouterInputEnvelope → fingerprint → prompt evidence_refs
  → audit (CORPUS_MISSING / mismatch) → /product/interpret evidence_ids
```

---

## Gate C note

Mismatch rule (packet id vs envelope id → `CORPUS_SNAPSHOT_MISMATCH`) is Class A audit — implement when `observability` block wired (Felix B-15).

---

SIGNED: Policy (Noah) | corpus snapshot Class A machinery | 2026-06-29 | B-16
