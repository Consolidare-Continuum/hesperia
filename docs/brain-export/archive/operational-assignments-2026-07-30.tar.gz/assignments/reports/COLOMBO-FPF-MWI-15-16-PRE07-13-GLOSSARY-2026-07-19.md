# Agent-rolling glossary (HAND / faces / dig / inquire)

**Date:** 2026-07-19  
**Owner:** Colombo (Research / formalization)  
**Rows:** FPF-HSR-15 · FPF-MWI-15 · FPF-MWI-16 · FPF-PRE07-13  
**Canon:** [SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md](../../../governance/SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md) · FPF-HSR-09 mapping (`igareosh/hesperia` → `sphere/router/thinking_map_bridge.py`)

---

## Frozen terms (EN)

| Term | Definition |
|------|------------|
| **HAND** | fpf-thinking-map **move layer** — `thinking_map_step` outcome JSON is **law** for the agent's next action (`kind`, `missing_evidence`, `gate_status`, `logic`, `response_contract`). Not chat re-derivation. |
| **Body** | Hesperia sealed engine + router + GTP + `fpf_inspect` — produces **ground_truth**. |
| **Face** | Concrete invoke surface under one HAND — MCP tool or HTTP/CLI. Two faces; one HAND. |
| **dig** | Bottom-up inspect climb via **`hesperia_inspect`** map + **`hesperia-fpf-inspect`** MCP (`sphere.fpf_inspect`). Output: layer probes, **GapReport**, provisional ADR hints. Inspect ≠ act. |
| **inquire** | Product rolling via **`hesperia_ops`** map + **`hesperia-router`** MCP (`router-inquire`). Output: engine-authored **ground_truth** (three blocks). |
| **GapReport** | Structured gap inventory from dig climb — missing evidence, provisional flags, layer blockers. Evidence for map re-step; not narrative truth. |
| **ground_truth** | Engine-only measurement envelope: **`logical`**, **`weight`**, **`source_activation`** blocks. Agent forbidden to author or edit. |
| **hesperia_ops** | Domain map id — product **roll** face (`hesperia_router_inquire`, `/product/interpret` path). |
| **hesperia_inspect** | Domain map id — **dig** face (`hesperia_fpf_probe`, `_gaps`, `_map_step`). |

---

## Face / map / MCP matrix

| Map | Face purpose | MCP server | Primary tool |
|-----|--------------|------------|--------------|
| `hesperia_ops` | Roll runtime; gather ground_truth | `hesperia-router` | `hesperia_router_inquire` |
| `hesperia_inspect` | Dig structure; GapReport | `hesperia-fpf-inspect` | `hesperia_fpf_probe`, `_gaps`, `_map_step` |

Upper LLM = narrative advise on GapReport/envelope only — **not** a third face that authors truth.

---

## FPF-HSR-09 mapping sign-off (FPF-HSR-15 / MWI-16)

**Reviewed:** Ethan mapping draft in `thinking_map_bridge.py` — field alignment `thinking_map_outcome` → `RouterInputEnvelope` + `gtp` block.

| Mapping area | Status |
|--------------|--------|
| `gtp_current_hex`, coherence hints | Mapped |
| `thinking_map_outcome.kind` → bridge policy | Mapped |
| `missing_evidence` token attach | Mapped |
| **`possible_transitions`** | **GAP — Felix MWI-04** |
| **`response_contract`** | **GAP — Felix MWI-04** |

**Colombo verdict:** HSR-09 table **accepted** for clinical/TFP naming where present. **`possible_transitions` and `response_contract` are not complete in bridge** — assign to **FPF-MWI-04** (Felix): implement + tests in `thinking_map_bridge.py`; do not block PRE07 glossary on MWI-04 ship.

**Not in bridge yet:** domain-specific transition labels for TFP clinical states — defer to MWI-04 + Colombo review pass after Felix ships.

---

## Usage rules (normative)

1. Agent loop: **map step → face invoke → read ground_truth/GapReport → map step**.
2. Never merge dig + inquire into one tool call that blurs inspect vs act.
3. Synthetic/dev only until Sophia/Daniel clinical gate (FPF-HSR-08 full).
4. Domain terms stay English inside Romanian prose.

---

`SIGNED: Researcher (Colombo) | agent-rolling glossary | 2026-07-19 | FPF-HSR-15 MWI-15/16 PRE07-13; MWI-04 owns bridge gaps`
