# HSR-V7-08 — Corpus snapshot policy (`corpus_snapshot_id` + retrieval provenance)

**Status:** ratified policy (implementation refs in dev clone)  
**Owner:** Noah  
**Depends:** HSR-V7-D-10 (`corpus_snapshot_id` in `RouterInputEnvelope`) · HSR-V7-01 router compliance spec §7.3  
**Register:** [HSR-V7-2026-REGISTER.md](../../../governance/HSR-V7-2026-REGISTER.md) (D-19 / active **HSR-V7-08**)

---

## 1. Purpose

`corpus_snapshot_id` names **which frozen lexical/TFP corpus** routed answers may cite. The router must not imply corpus-backed authority without a snapshot id or an explicit **unsupported** classification.

---

## 2. Field contract

| Field | Where | Type | Required |
|-------|-------|------|----------|
| `corpus_snapshot_id` | `RouterInputEnvelope` | string | yes (pre-LLM) |
| `corpus_snapshot_id` | `RouterPromptEnvelope` | via evidence_refs | propagated |
| `corpus_snapshot_id` | `/product/interpret` `evidence_ids` | string | yes (response) |

**Default when unset:** `corpus-unset` — audit treats corpus claims as **missing_evidence** / **REVIEW_REQUIRED**, not ALLOW.

**Env override (ops):** `HESPERIA_CORPUS_SNAPSHOT_ID=<id>` → compiler default when packet omits id.

---

## 3. Snapshot id format (v0.1)

```text
hesperia-corpus-<sealed_base>-<dict_lane>-<freeze_date>
```

| Segment | Example | Source |
|---------|---------|--------|
| `sealed_base` | `0.6.3` | `VERSION.yaml` `system_version` |
| `dict_lane` | `dict-b` | sealed dict JSONL lane in prod assets |
| `freeze_date` | `20260319` | operator ratified freeze (CHANGELOG / Ethan row) |

**Example (illustrative):** `hesperia-corpus-0.6.3-dict-b-20260319`

**Placeholder ids (allowed, flagged):**

| Id | Meaning | Audit |
|----|---------|-------|
| `corpus-unset` | Compiler default; no freeze wired | REVIEW_REQUIRED on corpus-backed language |
| `corpus-dev-local` | Dev clone only; not prod authority | WARN in strict mode |

---

## 4. Retrieval provenance rules

1. **context_rag packet** may include `corpus_snapshot_id`; if present it **must match** envelope `corpus_snapshot_id` or audit emits `CORPUS_SNAPSHOT_MISMATCH`.
2. **retrieval_context.evidence_ids** are references only — not substitutes for `corpus_snapshot_id`.
3. **COBALT slot** (when live) appends attribution objects; snapshot id remains envelope-level (one id per routed call).
4. **LLM narrative** must not invent corpus version strings; only echo ids present in envelope or mark unsupported in audit path.

---

## 5. Population path (implemented)

| Step | Owner | Behavior |
|------|-------|----------|
| Compile | Felix (`pre_llm_compiler.py`) | `corpus_snapshot_id` param → context_packet → env → `corpus-unset` |
| Product interpret | Felix (`product_interpret_service.py`) | Surfaces in `evidence_ids` |
| Audit | Felix (`audit.py` `_corpus_check`) | `corpus-unset` → `missing_evidence`; mismatch → review/block per rules |

---

## 6. Operator checklist (when ratifying a new freeze)

1. Ethan row + CHANGE-LOG freeze date for dict lane.
2. Set prod env `HESPERIA_CORPUS_SNAPSHOT_ID` to new id on deploy.
3. Verify `/product/interpret` response `evidence_ids.corpus_snapshot_id` matches.
4. Gold tests (Ava **HSR-V7-11**) must include at least one fixture per snapshot id class (`set`, `unset`, `dev-local`).

---

## 7. Open / deferred

| ID | Item |
|----|------|
| **HSR-V7-A-16** | Live inventory of current prod dict JSONL hash → canonical id string (Abelard/Ethan deploy pass) |
| **COBALT** | CHROMA-2 attribution objects referenced from `retrieval_context` |

---

SIGNED: Policy (Noah) | HSR-V7 corpus snapshot | 2026-06-29 | HSR-V7-08
