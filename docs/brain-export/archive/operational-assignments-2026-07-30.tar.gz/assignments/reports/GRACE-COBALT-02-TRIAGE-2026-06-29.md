# GRACE — COBALT triage (COBALT-02)

**Date:** 2026-06-29

COBALT execution rows already live from V7 wave 4 triage (`HSR-V7-W4-00`). No new rows required.

**Driver order:** COBALT-03 (G1) → COBALT-08..13 (adapter) → G2–G4 gates → COBALT-24 exit.

SIGNED: Team (Grace) | COBALT | 2026-06-29 | COBALT-02
