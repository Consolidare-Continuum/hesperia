# HSR-V7-E-07 — Academia narration (V7 positioning)

**Audience:** ULIM papers, lucrări, grant abstracts (EN primary; RO body with English terms).

## Positioning sentence (EN)

Hesperia v7 introduces a **semantics router and compliance governor** atop the sealed multiscale engine: every product-facing LLM call is preceded by a deterministic `RouterInputEnvelope` and followed by a `RouterOutputAudit` that yields an explicit `RouterDecision` — preserving epistemic separation between structural trace evidence and optional generated narration.

## Positioning sentence (RO)

Hesperia v7 adaugă un **semantics router** și un **compliance governor** peste engine-ul multiscale sigilat: fiecare apel LLM product-facing este precedat de un `RouterInputEnvelope` determinist și urmat de un `RouterOutputAudit` care produce un `RouterDecision` explicit — separând dovada structurală (`engine_trace`) de narațiunea generată opțional.

## Keywords (E-08)

`RouterInputEnvelope`, `RouterPromptEnvelope`, `RouterOutputAudit`, `RouterDecision`, `router_fingerprint`, `corpus_snapshot_id`, semantics router, compliance governor, deterministic semantic middleware.

SIGNED: Research (Colombo) | Gate E | 2026-06-29 | E-07 E-08
