# HSR-V7 Class A/B ledger (canonical drain reference)

**Date:** 2026-06-29  
**Owner:** Colombo · **Ratified inputs:** Ethan B-01..03, Felix B-06..10/15/19, Gena B-08/13/14, team B-04..20

## Class A (drain toward core — sealed physics untouched)

Sealed spine · `sphere/router/*` · thinking_map_bridge · topology math/guards · shipping boundary · context_rag calculable/coherence · KSI wiring · ledger core · product_interpret governed API · approval primitives · corpus snapshot machinery · router gold tests · `hspr_index` primitive

## Class B (non-cored modules)

TFP/MRT/COBALT modules · legacy pipeline · TFP YAML · calibration packs · KSI thresholds · books retrieval · MySQL RU columns · OpenAI Teacher · IRC orchestration · TFP test fixtures · HSPR_discovery research

## Future-only

Graph mutation prod · apply without sandbox · unified runtime tree · CHROMA cross-ingest · vendor reasoning as evidence

**Cross-ref:** [ETHAN-HSR-V7-GATE-B-CLASS-LISTS-2026-06-29.md](ETHAN-HSR-V7-GATE-B-CLASS-LISTS-2026-06-29.md) · per-component reports under `operational/assignments/reports/`

---

SIGNED: Research (Colombo) | Class A/B ledger B-22 | 2026-06-29
