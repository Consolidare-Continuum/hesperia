# COLOMBO — COBALT Gate G3 eval (COBALT-05)

**Date:** 2026-06-29 · **Env:** hesperia `.venv` + `chromadb>=1.5`

## Results (10 queries)

| ID | Query | Top hit | Clinical/TFP? |
|----|-------|---------|---------------|
| Q01 | TFP transference clinical | Kernberg ТФП при ПРЛ | YES |
| Q02 | borderline Kernberg | Larichev decisions (miss) | NO |
| Q03 | countertransference | Meltzer TFP normalized | YES |
| Q04 | Doering erotic transference | Barsky neural nets (miss) | NO |
| Q05 | mood regulation anxiety | Kernberg ТФП при ПРЛ | YES |
| Q06 | personality disorder psychodynamic | Kernberg affective dominance | YES |
| Q07 | Meltzer psychoanalysis | Kernberg aggression TFP | YES |
| Q08 | narcissistic transference TFP | Kernberg ТФП при ПРЛ | YES |
| Q09 | TCP IP networking (control) | IoT architecture (not Aaronson) | NO (noise) |
| Q10 | quantum Aaronson (control) | AI book (miss) | NO |

**Score:** 7/10 clinical queries → expected TFP/clinical corpus; 2/3 controls not clinical (acceptable pilot).

**Verdict:** G3 **PASS (pilot)** — attribution pilot + CHROMA-2 retrieval returns clinical docs for majority TFP queries. Full corpus attribution remains COBALT-04 scale-up.

SIGNED: Research (Colombo) | COBALT G3 | 2026-06-29 | COBALT-05
