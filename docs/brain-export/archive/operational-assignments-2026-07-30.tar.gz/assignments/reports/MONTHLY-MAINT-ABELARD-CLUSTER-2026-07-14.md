# Abelard — MONTHLY-MAINT-01 alunel + VMs (2026-07-14)

**Owner:** Abelard · **Wave:** MONTHLY-MAINT

## Did

| Step | Result |
|------|--------|
| Holy-cow audit | **0** error / **0** warning |
| Hypervisor | `alunel-hypervisor-maintenance.sh` DONE — dist-upgrade, journal 14d, upgradable **0**, QM list healthy |
| Cluster units | `run-cluster-maintenance.sh` → `/data/system_maintenance/2026-07-14_cluster_2026-07-14_131025` · `latest` updated |
| Agent cert | Expired mid-run → renewed on alunel; valid → **2026-07-15T14:20** |
| Retries | alunel (apt lock vs hypervisor); trustmaster/dnsmaster/tersagor after cert renew |

## Unit table (final)

| Unit | Status |
|------|--------|
| altitudine, alunel, librarymaster, mediamaster, prichindel, cloudmaster | OK |
| trustmaster, dnsmaster, tersagor | OK (post-retry) |
| stejarel, izvoras, mugurel | ISSUE — no route (offline/away) |
| voinicel | ISSUE — pubkey deny (not agent-CA path) |

## Notes for next run

- prichindel `/` **96%** (largest `/data/hesperia` ~48G).
- `alunel-ipmi-sel-archive.service` failed — BMC SEL note only.
- Do not run hypervisor apt in parallel with cluster alunel unit.

SIGNED: DevOps (Abelard) | MONTHLY-MAINT-01 | 2026-07-14 | alunel+VM maintenance
