# CHROMA retrieval QA — 2026-07-14 (EOM spot-check)

**Owner note:** Noah checklist [CHROMA-RETRIEVAL-QA.md](../../../governance/CHROMA-RETRIEVAL-QA.md). Executed under Cursor main EOM.

| # | Check | Result |
|---|-------|--------|
| Heartbeat | CHROMA-1 | **200** |
| Count | collection `knowledge` | **23715** |
| Gov hit | query agent SSH CA | `AGENT-SSH-CA-MANDATORY.md` — PASS |
| Stale | chroma-new purge | wrap doc **Purged** — PASS |
| Fresh | MONTHLY-MAINT | miss until ingest — expected FAIL |
| Latency | alunel HttpClient | &lt;5s — PASS |

SIGNED: Cursor main | EOM retrieval QA | 2026-07-14 | Noah checklist spot
