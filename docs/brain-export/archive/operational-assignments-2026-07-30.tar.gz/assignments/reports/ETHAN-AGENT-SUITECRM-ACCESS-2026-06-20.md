# Agent SuiteCRM access reliability — report

**Date:** 2026-06-20  
**Owner:** Cursor (Ethan lane — agent access product)  
**Session:** execution_host=altitudine, role=dev_vm_ulim, dev_office=true, connectivity=lan

---

## Problem

Agents syncing LRP / active.md rows to SuiteCRM hit three failure modes:

| Symptom | Root cause |
|---------|------------|
| `Host key verification failed` / `Permission denied (publickey)` | Stale agent CA cert or wrong SSH target (direct IP without agent config) |
| `Permission denied: '/root/.secrets/suitecrm/oauth-cursor.env'` | **Primary bug** — `cursor-suitecrm` MCP ran as `igareosh@prichindel` without `sudo`; OAuth creds are `root:root 600` |
| Local `ls /root/.secrets/suitecrm/` on altitudine | Expected fail — creds live on **prichindel** only; agents must use MCP SSH, not local paths |

Manual sync scripts (`suitecrm_sync_active_md.py`, cron) already used `sudo -n`; MCP config did not.

---

## Fix applied

1. **`scripts/agent-mcp-suitecrm-remote.sh`** — canonical prichindel launcher:
   - Resolves brain repo (`/data/altitudine/prichindel.com` → fallback `/data/workspaces/cursor` by module presence)
   - Runs `sudo -n env … python -m agent_mcp_suitecrm` so OAuth file is readable

2. **`governance/mcp-config.json`** + **`.cursor/mcp.json`** — `cursor-suitecrm` SSH arg now invokes the remote launcher (not bare python).

3. **`governance/mcp-config-windows.json`** — added missing **`cursor-suitecrm`** entry (LAMAITA parity).

4. **Deployed to prichindel** — `scripts/sync-suitecrm-mcp-prichindel.sh` (called from `deploy-mcp-config-global.sh`).

5. **`scripts/mcp/deploy-mcp-config-global.sh`** — fixed REPO_ROOT when invoked via `scripts/` symlink (was `/data/altitudine`); now walks up to `governance/mcp-config.json`, syncs SuiteCRM to prichindel, runs verify + drift check.

6. **Docs** — `MCP-COMPLIANCE-AND-OPERATIONAL.md` + `SCRIPT-RUNBOOK-suitecrm-task-sync.md` failure table updated.

7. **`scripts/verify-agent-suitecrm-mcp.sh`** — one-command smoke from dev office.

---

## Verification (2026-06-20)

```text
ssh prichindel → sudo SuiteCRMClient.list_tasks → OK count=2
Simulated new MCP path → {"mcp_path_ok": true, "repo": "/data/workspaces/cursor", "count": 2}
Remote launcher starts (stdio MCP) → exit 0
get_agent_access_status (MCP) → agent_cert_expired: false
```

**Before fix:** `suitecrm_list_tasks` MCP → `[Errno 13] Permission denied: '/root/.secrets/suitecrm/oauth-cursor.env'`

---

## Operator / agent actions

| Who | Action |
|-----|--------|
| **Cursor IDE (this session)** | Full restart after pull so merged MCP loads new `cursor-suitecrm` SSH command |
| **Any dev host** | `bash scripts/deploy-mcp-config-global.sh` (syncs prichindel + verify + drift) then restart Cursor |
| **Smoke** | `bash scripts/verify-agent-suitecrm-mcp.sh` |
| **Abelard** | Keep `/root/.secrets/suitecrm/oauth-*.env` on prichindel; ensure `igareosh` retains passwordless sudo for MCP launcher |

---

## Remaining notes (non-blocking)

- **`governance/agent_ssh_cert_status.txt`** in repo clone can lag live cert; trust **`get_agent_access_status`** MCP or alunel renew cron.
- **prichindel prod brain** = `/data/workspaces/cursor` (not altitudine path); launcher handles fallback.
- **Windows** — run `deploy-mcp-config-global.ps1` on LAMAITA when next on that machine.

---

## NEXT

- After Cursor restart: re-run LRP wave SuiteCRM upserts via `suitecrm_upsert_task` / `suitecrm_sync_on_triage.sh`.
- Task Grace if LRP rows still missing SUITE NR after MCP green.

SIGNED: Cursor | Ethan agent-access lane | 2026-06-20 | cursor-suitecrm MCP reliability
