# Operator dig runbook — hit something → climb (no UI)

**Date:** 2026-07-19  
**Owner:** Marcus (Product)  
**Rows:** FPF-BUII-06 · FPF-MWI-19 · FPF-PRE07-17  
**Canon:** [SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll.md](../../../scripts/SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll.md) · [SPEC-ETHAN-HESPERIA-FPF-BOTTOM-UP-INSPECT.md](../../../governance/SPEC-ETHAN-HESPERIA-FPF-BOTTOM-UP-INSPECT.md) · [SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md](../../../governance/SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md)

---

## Scope

Operator dig recipe when something smells wrong during HAND roll. **No product UI.** Dig = `hesperia_inspect` face; inquire = `hesperia_ops` face. Do not collapse.

**Host:** altitudine · `HESPERIA_REPO_ROOT=/data/workspaces/atomic-commit-hesperia`  
**Input:** synthetic gold only — security memo PRE07-12.

---

## Trigger

Hit something during ops loop:

- unexpected layer / empty `ground_truth` block
- map `kind=COLLECT_EVIDENCE` naming structure gaps
- GapReport provisional ADR, gate block, or fingerprint drift
- operator says “dig” / “climb”

→ leave `hesperia_ops`; enter dig recipe below.

---

## Dig recipe (HAND loop — no UI)

```text
1. thinking_map_step(map_id=hesperia_inspect, trigger=hesperia_bridge, …)
2. Obey outcome JSON — kind · missing_evidence · gate_status · response_contract
3. Face invoke (MCP preferred):
     hesperia_fpf_probe  |  hesperia_fpf_gaps  |  hesperia_fpf_map_step
   CLI equivalent (same body):
     cd $HESPERIA_REPO_ROOT
     python -m sphere.fpf_inspect climb --full --analyze-file <gold.json>
4. Read GapReport + InspectSlice fingerprints — engine_authored only
5. Attach gap_report_done / inspect_slice_done evidence → thinking_map_step again
6. ADVANCE/CONTINUE → return to hesperia_ops; IDLE → stop; escalate if map says so
```

**Rule:** dig clarifies structure; inquire rolls product. Do not open UI. Do not invent Move semantics in chat.

---

## CLI climb (MWI-12 sugar)

Full climb (do not stop on first gap):

```bash
export HESPERIA_REPO_ROOT=/data/workspaces/atomic-commit-hesperia
cd "$HESPERIA_REPO_ROOT"
# analyze JSON = synthetic gold fixture (or envelope dump from inquire)
python -m sphere.fpf_inspect climb --full --analyze-file /path/to/gold_analyze.json
```

Stop on first gap (default):

```bash
python -m sphere.fpf_inspect climb --analyze-file /path/to/gold_analyze.json
```

GapReport only:

```bash
python -m sphere.fpf_inspect gaps --analyze-file /path/to/gold_analyze.json
```

Single layer:

```bash
python -m sphere.fpf_inspect probe --layer GTP --analyze-file /path/to/gold_analyze.json
```

Map step (inspect HAND):

```bash
python -m sphere.fpf_inspect map-step --state layer_climb --evidence gap_report_done
```

---

## Climb order (expect)

`L0 → L1 → … → L9 → GTP → Guards → Router`  
GapReport **must** name `lowest_failed_layer`. Stub L6 fields never appear as evidence.

---

## Failure routing

| Symptom | Action |
|---------|--------|
| MCP inspect missing | Abelard PRE07-15 / Liam PRE07-16 deploy |
| CLI `no Hesperia repo` | Set `HESPERIA_REPO_ROOT` |
| Agent authors GapReport fields | Defect — engine only |
| Clinical / REAL_DATA text | **STOP** — PRE07-12 |
| Prod path `/data/hesperia/hesperia` | **STOP** — not this runbook |

---

## Exit (BUII-06 / MWI-19 / PRE07-17)

- [ ] Hit-something → dig recipe executed without UI  
- [ ] `climb --full` (or MCP probe/gaps) returns GapReport on synthetic gold  
- [ ] Map re-step uses GapReport as evidence; return to ops when CLEAR  
- [ ] Cross-check Ava MWI-18 determinism if fingerprint drifts  

Full HAND roll (ops + dig): **get_runbook** `SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll`.

---

`SIGNED: Product (Marcus) | dig runbook hit→climb | 2026-07-19 | BUII-06 MWI-19 PRE07-17`
