# MCP smoke — cursor-suitecrm (Felix)

**Date:** 2026-06-18 · **SUITE-CRM-33**

**Host:** prichindel (via client.py on server)

| Step | Result |
|------|--------|
| OAuth token `oauth-cursor.env` | PASS (URL `/Api/access_token`) |
| upsert `SYNC-TEST2` | PASS |
| set_done `SYNC-TEST2` | PASS |
| Custom fields `active_md_id_c` | PENDING Quick Repair — **name prefix fallback active** |

SIGNED: Developer (Felix) | MCP smoke | 2026-06-18
