# Abelard — FPF outside brain + CHROMA-1 catalog refreeze

**Date**: 2026-07-17  
**Session**: `execution_host=altitudine`, `dev_office=true`, `connectivity=lan`  
**Trigger**: Operator — no `FPF-Spec.md` in brain; clone outside; reingest frozen `layer=fpf`; agents refuse monolith super-manism.

## Did

| Item | Result |
|------|--------|
| Scratchpad `/tmp/claude-*/…/FPF-Spec.md` | Deleted |
| Brain `FPrincipleF/` | Absent (none to remove); gitignore kept as safety |
| Clone | `/data/workspaces/fpf` ← `github.com/ailev/FPF` @ `44dd881` |
| Catalog extract | **288** rows → `/data/workspaces/fpf/fpf-catalog.jsonl` |
| CHROMA-1 ingest | **288** `document_type=fpf_catalog` chunks; verified `query_knowledge` A.1 hit `source=/data/workspaces/fpf/FPF-Spec.md` |
| Ingest fix | `ingest.py` uses `get_collection()` (HttpClient avoids `KeyError('_type')` on create) |
| Compliance | [ETHAN-FPF-OUTSIDE-BRAIN-AND-AGENT-REFUSAL.md](../../../governance/ETHAN-FPF-OUTSIDE-BRAIN-AND-AGENT-REFUSAL.md) + rule `cursor-fpf-monolith-refusal.mdc` |
| Grace | Inbox row 2026-07-17 (New) for awareness triage |

## Agent path (canonical)

- Human Spec: `/data/workspaces/fpf/FPF-Spec.md`
- Refresh Chroma: `bash cluster/chroma-server/ingest-fpf.sh`
- Agent use: `query_knowledge` `layer=fpf` / `fpf_catalog_only=true` — **refuse** full Spec in chat

## Refreeze (operator 2026-07-17)

Stamp: [governance/fpf_layer_freeze.txt](../../../governance/fpf_layer_freeze.txt) — **FROZEN**, **288** catalog chunks, search/inspect allowed. `ingest-fpf.sh` exits 4 unless `FPF_UNFREEZE=1`.

## Case status

**CLOSED** 2026-07-17 — operator accepted compliance case.

SIGNED: DevOps (Abelard) | FPF outside brain refreeze | 2026-07-17 | CHROMA-1 catalog 288 FROZEN · case CLOSED
