# Cursor — ops-method DB visual mapper MVP (2026-07-28)

**Badge:** Serious badge · MVP visual mapper of a DB (#1)  
**Register:** [governance/CURSOR-MVP-BADGES.md](../../../governance/CURSOR-MVP-BADGES.md) · [governance/CURSOR-MAIN-WIN-REGISTER.md](../../../governance/CURSOR-MAIN-WIN-REGISTER.md)  
**Who:** Cursor (default) · operator recognition in chat (session ephemeral → this file)

## Product photo

![Full DB · statements + relations](assets/CURSOR-OPS-METHOD-DB-VISUAL-MAPPER-MVP-2026-07-28.jpg)

Operator product shot (2026-07-28): **21 420** nodes · **6 770** edges · ~3 s load · HA/pending/model_accepted on · pack-clustered spirals. Canonical copy also: `projects/ops-method/agv_ui/shots/full-db-mapper-product-2026-07-28.jpg`.

## What shipped

| Surface | URL (altitudine) | Role |
|---------|------------------|------|
| Full DB map | `http://127.0.0.1:8765/full` | All SRC statements + relations; filters; click object |
| Pack night | `http://127.0.0.1:8765/night` | Pack constellation (summary sky) |
| ED01 AGV | `http://127.0.0.1:8765/` | Chapter STEP map (earlier product) |
| API full | `GET /graph/db-full?scope=all\|connected&status=…` | Nodes + links JSON |
| API packs | `GET /graph/db-sim` | Pack-level summary |

**Service:** user systemd `ops-method-agv` · `projects/ops-method/scripts/agv_api.py`

## Verified scale (2026-07-28)

- Statements (SRC, excl. synth dummy): **21 420**
- SRC↔SRC edges in full payload: **7 472** (status mix: HA / pending / model_accepted / rejected as filtered)
- Human-approved connected subgraph: **871** nodes · **1 066** edges
- Full JSON ~**6.8 MB** · fetch ~**3 s** on altitudine

## Why it is an MVP (not a sketch)

Operator asked for a simulation of DB objects (after rejecting “melt the GPU” joke path), then for something **showable** (not five circles), then for **full** objects + relations with 32 GB RAM budget. Cursor delivered pack sky → constellation → **full mapper** with live Postgres behind it.

## Paths

- UI: `projects/ops-method/agv_ui/full.html`, `night.html`, `index.html`
- API: `projects/ops-method/scripts/agv_api.py` (`/graph/db-full`, `/graph/db-sim`, `/full`, `/night`)

**SIGNED:** Cursor | ops-method visual MVP | 2026-07-28 | badge + win register
