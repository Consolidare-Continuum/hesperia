# Ava — Test harness Class A vs Class B (HSR-V7-B-20)

**Date:** 2026-06-29  
**Dev clone:** `/data/workspaces/atomic-commit-hesperia`

---

## Verdict

**Gold / contract tests → Class A.** **TFP statement / clinical YAML fixture suites → Class B.** Router gold matrix is Class A (decision taxonomy); TFP bundle and contradiction tests are Class B (domain plane).

---

## Class A — universal contract harness

| Test module | What it locks | Tag |
|-------------|---------------|-----|
| `tests/router/test_router_gold_matrix.py` | ALLOW/WARN/REVIEW/BLOCK branches (10 cases) | **A** |
| `tests/router/test_router_fingerprint_v0_1.py` | Deterministic `router_fingerprint` | **A** |
| `tests/router/test_post_llm_audit.py` | Audit decision paths | **A** |
| `tests/router/test_prompt_envelope.py` | Prompt policy enforcement | **A** |
| `tests/router/test_pre_llm_compiler.py` | Envelope compile contract | **A** |
| `tests/support/public_output_contract.py` | `hspr_index` bounds, public shape | **A** |
| `tests/test_engine_analyze_contract.py` | HSPR-01/02 envelope | **A** |
| `tests/test_runtime_spine_integrity.py` | Sealed spine exclusive path | **A** |
| `tests/engine/test_sealed_multiscale.py` | `compute_hspr_index` on stack | **A** |

**Gold fixture pattern (Class A):** synthetic English clinical-adjacent **narrative** in `test_router_gold_matrix.py` — tests **router decisions**, not TFP lexicon physics. Uses `corpus_snapshot_id` as provenance token, not TFP YAML.

---

## Class B — domain / TFP fixture harness

| Test module | Fixture source | Tag |
|-------------|----------------|-----|
| `tests/triz/test_*` | TFP contradiction calibration, `inspect_tfp_bundle_output` | **B** |
| `tests/topology/test_family_structure.py` | `families_structure_tfp.yaml` | **B** |
| `tests/topology/test_activation_propagation.py` | `family_embedding_tfp.yaml` | **B** |
| `tests/domain/test_derived_metrics.py` | KME `KSI` metric name collision (not Kolmogorov) | **B** domain |
| `tools/tfp_pipeline_standard_run.py` (invoked by tests) | TFP file pipeline | **B** |

**TFP statement fixtures:** RU corpus bundles, `tfp_signal_calibration`, contradiction JSON under `assets/data/engine_dynamics_v060/tfp/` — exercise **clinical domain plane**, not universal router contract.

---

## Classification rule (for B-21)

| Question | Class A test | Class B test |
|----------|--------------|--------------|
| Would it pass if TFP module disabled but sealed `/analyze` runs? | **A** | — |
| Requires TFP YAML, RU markers, or session stages? | — | **B** |
| Locks router decision enum / fingerprint / prompt policy? | **A** | — |

---

## Gap (non-blocking)

`HSR-V7-D-16` compiler gold vs TFP input — use **Class B input** with **Class A expected envelope fields**; split fixtures accordingly in Gate C-19.

---

SIGNED: QA (Ava) | test harness Class A/B | 2026-06-29 | B-20
