# Security memo — synthetic/dev HAND agent rolling (altitudine)

**Date:** 2026-07-19  
**Owners:** Sophia (Security) + Daniel (Security co-sign)  
**Rows:** FPF-HSR-08 · FPF-MWI-13 · FPF-MWI-14 · FPF-PRE07-12  
**Canon:** [SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md](../../../governance/SPEC-ETHAN-HESPERIA-FPF-HAND-AGENT-ROLLING.md) · [SPEC-ETHAN-HESPERIA-AGENT-AUTONOMOUS-INVOCATION.md](../../../governance/SPEC-ETHAN-HESPERIA-AGENT-AUTONOMOUS-INVOCATION.md)

---

## Verdict

**APPROVED** — synthetic/dev agent HAND rolling on **altitudine** for **`hesperia-router`** + **`hesperia-fpf-inspect`**.

**Clinical/prod REAL_DATA remains GATED.**

---

## Approved surface (dev only)

| Face | MCP | Host | Input class |
|------|-----|------|-------------|
| **inquire** | `hesperia-router` | altitudine | Synthetic / fixture / operator-authored non-clinical text |
| **dig** | `hesperia-fpf-inspect` | altitudine | Same; climb/GapReport on synthetic analyze JSON |

**Execution host:** `altitudine` (`dev_office=true`). **Not** prichindel prod tree for agent rolling until separate Abelard gate.

---

## Gates still closed

| Flag / path | Rule |
|-------------|------|
| `HESPERIA_MCP_BRIDGE_REAL_DATA=1` | **BLOCKED** — no flip |
| Prod `/data/hesperia/hesperia` MCP default | **BLOCKED** for external/agent callers |
| Real clinical / TFP corpus text via MCP or HTTP `context_packet` | **BLOCKED** until FBV73-03 + FPF-HSR-08 clinical pass (future wave) |
| HSR-V7-X-* seal unpause | **BLOCKED** — operator hold unchanged |

---

## Security controls (required, dev)

1. **Three-axis doctrine** — agents never author `logical` / `weight` / `source_activation`; engine only.
2. **JSON-only MCP** — no shell passthrough; subprocess = Hesperia CLI only.
3. **Self-contained requests** — no server-side session; each invoke carries full `context_packet`.
4. **Input allowlist** — synthetic fixtures, gold strings, operator test prose; no patient identifiers.
5. **No PII in logs** — see Noah MWI-22 field schema; no raw clinical text in trace/jsonl.
6. **MCP config** — brain `governance/mcp-config.json` dev paths only; prod deploy = Liam MWI-20 + Abelard PRE07-15.

---

## Explicit non-approval

- External callers (Olga launcher, tunnel, prod HTTP) with real clinical input.
- Autonomous unattended rolling against CHROMA-2 / TFP corpus without redaction.
- Treating this memo as FBV73-03 substitute.

---

## Dependencies

| Row | Satisfied by this memo |
|-----|------------------------|
| FPF-HSR-08 | Partial — **dev synthetic only** |
| FPF-MWI-13 | Yes — `hesperia-fpf-inspect` synthetic dig |
| FPF-MWI-14 | Co-sign complete |
| FPF-PRE07-12 | Yes — PRE07-G3 input |

Felix may proceed MWI-01/02/05 on altitudine under this memo. Grace stamps PRE07-G3 when Abelard PRE07-15 + Liam PRE07-16 green.

---

`SIGNED: Security (Sophia) | synthetic/dev HAND rolling | 2026-07-19 | FPF-HSR-08 MWI-13/14 PRE07-12 APPROVED dev only`

`SIGNED: Security (Daniel) | co-sign | 2026-07-19 | clinical/prod REAL_DATA still gated`
