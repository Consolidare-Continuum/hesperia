# Cursor main — monthly operator audit

**Date**: 2026-07-14 (UTC+3)  
**Session**: `execution_host=altitudine`, `role=dev_vm_ulim`, `dev_office=true`, `connectivity=lan`  
**Operator**: igareosh  
**Standing brief**: [governance/CURSOR-MAIN-MONTHLY-OPERATOR-BRIEF.md](../../../governance/CURSOR-MAIN-MONTHLY-OPERATOR-BRIEF.md)  
**Companion same-day**: team [MONTHLY-MAINT wave closure](MONTHLY-MAINT-WAVE-CLOSURE-2026-07-14.md) (Abelard/Ethan/Grace/Colombo) — complementary, not a substitute for this Cursor main letter.

---

## Executive summary

July’s stack is **stronger than June’s audit predicted**: MCP drift **0**, CHROMA-1 **200** with **23 715** `knowledge` chunks and retrieval that now lands the **purged** wrap (not stale “purge pending”), thinking-map hard-gate + verify **22/22** / pytest **23**, agent cert renewed today, and team **MONTHLY-MAINT-00..04** closed with SuiteCRM Completed. The remaining pain is **not architecture** — it is **IDE MCP session blindness** (only browser tools loaded while `~/.cursor/mcp.json` is full), **uncommitted brain dirt** from today’s maintenance + unrelated WIP, **prichindel root disk 96%** with `/data` on the same filesystem (not a separate disk), and **Hesperia FBV 7.2–7.4** ratification / OCR / TFP gates still OPEN. M9 cost talk stays **closed**.

---

## Done right (keep; do not churn)

| Area | Why it works |
|------|----------------|
| **Workflow SOT** | `active.md` + heartbeat; MONTHLY-MAINT and FBV rows visible; captain_on_deck false |
| **CHROMA-1** | Heartbeat 200; collection `knowledge` live; agent-SSH and chroma-new queries return canonical governance sources |
| **MCP config truth** | `governance/mcp-config.json` ↔ user/project: **drift_detected=0**; wrapper `scripts/mcp_config_drift_check.sh` exists |
| **Host model** | Detector + holy-cow: altitudine = primary dev office; alunel = hypervisor + CHROMA-1 |
| **Thinking map** | `thinking_map_mode=1`; hard-gate pass; library self-verify ALL PASS |
| **Territory** | CHROMA-1 agent-silent / CHROMA-2 Colombo / SuiteCRM operator board — policies held |
| **Team monthly hygiene** | Abelard cluster+hypervisor; Ethan trash-out; Grace docs+CRM; Colombo context — one run DONE |
| **malus / SuiteCRM / tersagor** | Prod Docker UI, permanent CRM, hosted brain MCP — persist as product surfaces |
| **Tone / quality floor** | did/asked/result; Grace triage for new work; no private todo as SOT |
| **June P0s largely closed** | Drift script path, CURSOR-MCP-SETUP chroma-new text, Windows SSH Phase 2, PAPRA-29/30 operator-aborted cleanly |

---

## Wrong (factual defects)

| # | Issue | Evidence |
|---|--------|----------|
| W1 | **This Cursor IDE session only exposes `cursor-ide-browser` MCP** | `mcps/` folder = one server; `~/.cursor/mcp.json` otherwise full → agents fall back to scripts/SSH; violates “Session = MCP” in practice until full IDE restart |
| W2 | **Brain tree dirty after MONTHLY-MAINT + unrelated WIP** | ~37 porcelain lines: monthlies untracked/modified; fpf-atm / www-prichindel / CLAUDE.md dirt mixed — not one-tree clean on GitHub |
| W3 | **prichindel `/` at 96%** | `df`: `/dev/sda1` **116G/126G**; `findmnt -T /data` → **TARGET=/** — `/data` is **not** a separate mount on this guest |
| W4 | **Agent cert was expired mid-cluster-run** | Renewed 2026-07-14; valid → **2026-07-15T14:20** — will expire again ~25h; renew cadence still fragile |
| W5 | **CHROMA-1 missing today’s monthly artifacts** | Query `MONTHLY-MAINT Grace triage` returns June SuiteCRM Grace packets — expected until commit + ingest |
| W6 | **trustmaster-hub jump broken from altitudine** | `fix-access` → alunel missing `/data/workspaces/cursor/scripts/trustmaster-hub` — ops clone lag |
| W7 | **PAUSED debt stock** | Heartbeat **40 PAUSED** vs **8 OPEN** — attention skewed; PAUSED not groomed monthly |
| W8 | **FBV OPEN chain blocks product “complete” narrative** | FBV72/73/74 ratification, Olga MCP, Sophia security, Abelard OCR, Colombo TFP still OPEN |

---

## Missing

| # | Gap | Notes |
|---|-----|-------|
| M1 | **July CHROMA retrieval QA report artifact** | Spot-check done in this EOM (below); formal Noah checklist row file not written as standalone until now (embedded here) |
| M2 | **Scoped commit + CHROMA-1 ingest of MONTHLY-MAINT + EOM** | Operator approval to commit; Abelard ingest after push |
| M3 | **IDE full MCP reload** | Restart Cursor on altitudine so chroma-knowledge / pipeline / thinking-map / suitecrm appear in session |
| M4 | **alunel ops clone = trustmaster-hub scripts** | Sync `/data/workspaces/cursor` on alunel or hub path fix so `scripts/trustmaster-hub` jumps work |
| M5 | **prichindel disk plan** | Separate `/data` disk vs prune (hesperia ~48G under `/data`) — Abelard |
| M6 | **Daily cert renew automation awareness** | Cron/timer on alunel CA host — verify exists and fires before 25h wall |
| M7 | **PAUSED board pass** | Grace triage wave or EOW: archive vs reopen vs drop 40 PAUSED |

---

## Requires fixing (actionable)

| Priority | Item | Owner | Action |
|----------|------|-------|--------|
| P0 | Reload MCP in IDE | Operator / Cursor | Full restart Cursor on altitudine; confirm tools beyond browser |
| P0 | prichindel disk 96% / `/data` on `/` | Abelard | Confirm intentional layout; free space or attach data disk; report to Grace if structural |
| P1 | Commit MONTHLY-MAINT + EOM audit scoped | Cursor | On operator “commit”: exclude www/fpf-atm unrelated; push; then Abelard ingest |
| P1 | CHROMA-1 whole-repo (or delta) ingest | Abelard | After push — so MONTHLY-MAINT + this audit become retrieval hits |
| P1 | alunel brain clone / trustmaster-hub path | Abelard | `git pull` ops clone or fix hub jump |
| P1 | Cert renew before expiry | Abelard | Renew before 2026-07-15T14:20; verify timer |
| P2 | PAUSED grooming | Grace | Triage pass — 40 → actionable set |
| P2 | FBV72–74 product gates | Ethan → owners | Ratify specs; Sophia P0 security; Abelard OCR; Colombo TFP |

---

## Requires improving

| Item | Note |
|------|------|
| **Agentic hygiene of dirty trees** | Separate “session WIP” from “brain monthly” in commits so EOM does not bury FPF site edits |
| **Retrieval QA cadence** | Monthly spot-check should leave a dated `CHROMA-RETRIEVAL-QA-YYYY-MM-DD.md` even when PASS |
| **MCP session detector** | Optional: session mode field `mcp_tools_loaded=N` vs expected — catch W1 earlier |
| **Product use assurance** | Stack is used (workflow, SuiteCRM, Chroma, thinking-map). Still not mutually assured until IDE MCP session matches config (W1) |

**Not listed:** cost/subscription/ROI (M9 closed).

---

## Blocked on operator

| Decision | Why |
|----------|-----|
| **Commit/push** today’s MONTHLY-MAINT + EOM artifacts? | User rule: no commit unless asked |
| **Disk strategy** for prichindel 96% | Prune vs new disk vs accept short free space |
| **Cursor full restart now** | Required to clear IDE MCP blindness |
| **FBV priority order** for next workflow drain | Which ratification first among 72/73/74 |

---

## CHROMA retrieval QA (July spot-check)

| # | Check | Result |
|---|-------|--------|
| Live | Heartbeat | **200** |
| Count | `knowledge` | **23715** |
| Books/gov hit | `agent SSH CA mandatory` | Top: `governance/AGENT-SSH-CA-MANDATORY.md` — **PASS** |
| Stale chroma-new | `chroma-new purge pending` | Top: `CHROMA-NEW-PRICHINDEL-RETIRED-WRAP.md` **Status: Purged** — **PASS** (June W6 fixed) |
| Fresh monthly | `MONTHLY-MAINT Grace triage` | Old SuiteCRM Grace — **FAIL until ingest** (expected) |
| Latency | Local alunel HttpClient | &lt;5s — **PASS** |

---

## Technical compliance (this run)

| Check | Result |
|-------|--------|
| Session detect | altitudine / dev_vm_ulim / true / lan |
| Agent cert | valid → 2026-07-15T14:20+03 |
| MCP drift | **0** |
| CHROMA-1 | **200** |
| Heartbeat | OPEN **8**, PAUSED **40**, DONE **979** |
| thinking-map | hard-gate OK; verify 22/22; pytest 23 |
| MONTHLY-MAINT | **5/5 DONE** + SuiteCRM Completed |

---

## Route work

- Disk / alunel clone / cert timer → **Abelard** (already in requires fixing; Grace triage if new active.md rows needed).
- IDE MCP restart → **operator**.
- Commit batch → **ask operator** (below).
- FBV OPEN → remain on **active.md** (already triaged).

---

## Closure

- Artifact: this file  
- Compliance row: [CURSOR-REPO-COMPLIANCE-CHECK.md](../../../governance/CURSOR-REPO-COMPLIANCE-CHECK.md) **2026-07-14 (EOM Cursor main)**  
- CHROMA-1 ingest: **deferred** until push  

**Asked:** Commit scoped EOM + MONTHLY-MAINT brain files (exclude www/fpf-atm unrelated)? Restart Cursor for full MCP?

---

## Cursor main sign-off (2026-07-14, verification pass)

**Verdict: JULY 2026 — COMPLIANT. Repo operational for this month.**

Re-checked live: MCP drift 0 · CHROMA-1 200 · thinking-map hard-gate OK · agent cert valid · MONTHLY-MAINT 5/5 DONE · EOM audit + QA artifacts on disk · compliance rows dated. Workflow continues (8 OPEN product = FBV chain, not hygiene failure).

Non-blocking follow-ups: commit/push monthly+EOM batch · Cursor restart for full MCP · Abelard disk · FBV owners.

SIGNED: Cursor main | July compliance sign-off | 2026-07-14 | repo operational

SIGNED: Cursor main | EOM monthly audit | 2026-07-14 | igareosh standing request
