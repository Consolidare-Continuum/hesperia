# MCP-BRAIN test matrices (Ava — 010..012)

## MCP-BRAIN-010 — query_knowledge before grep

| Step | Expected | Result |
|------|----------|--------|
| Agent asked "what's the rule for workflow" | `query_knowledge` first | PASS (session policy) |
| grep/repo only without MCP attempt | process violation | rules enforce MCP-first |

## MCP-BRAIN-011 — CSP + get_current_step

| Step | Expected | Result |
|------|----------|--------|
| User says "proceed" | `workflow_run.sh` + read current step | PASS |
| Owner ≠ generic Cursor | CSP block emitted | PASS |
| Complete row | `report_done` | PASS (LRP wave) |

## MCP-BRAIN-012 — colombo-library vs query_knowledge

| Query type | Tool | Result |
|------------|------|--------|
| Team process/roles | `query_knowledge` CHROMA-1 | PASS |
| Papra library book | `colombo-library` CHROMA-2 | PASS (territory policy) |
| Library via query_knowledge | wrong path | blocked by rules |

SIGNED: QA (Ava) | MCP-BRAIN-010..012 | 2026-06-20 | manual matrices
