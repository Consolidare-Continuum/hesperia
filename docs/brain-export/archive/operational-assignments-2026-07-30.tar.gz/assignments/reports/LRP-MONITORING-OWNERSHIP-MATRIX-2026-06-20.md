# Monitoring ownership matrix — LRP wave

**LRP-56** · Owner: Sophia

| Signal | Owner | Escalation |
|--------|-------|------------|
| `LanReplicationFailed` / `LanReplicationStale` | Abelard | Grace if >1 interval |
| textfile metrics on job host | Abelard | reinstall runner |
| `get_lan_replication_status` MCP | Abelard / Cursor | MCP config on prichindel |
| SURVEILLANCE.md §8.3 | Sophia | doc drift → Grace |
| maintenance `08-lan-replication.txt` | Abelard | daily maintenance run |
| registry.yaml changes | Grace triage | no orphan cron |

SIGNED: Monitoring (Sophia) | LRP-56 | 2026-06-20 | LRP wave ownership
