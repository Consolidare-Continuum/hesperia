# Ethan — HSR-V7 Gate B Class A / B / Future lists (B-01..03)

**Date:** 2026-06-29  
**Owner:** Ethan (Chief Architect)  
**Inputs:** [FELIX-HSR-V7-GATE-B-INVENTORIES-2026-06-29.md](FELIX-HSR-V7-GATE-B-INVENTORIES-2026-06-29.md) · HSR-V7-01 compliance spec  
**Register:** B-01, B-02, B-03

---

## B-01 — Class A (universal math / semantics / packet / audit machinery)

**Rule:** May drain toward core — must not reopen sealed 0.6.3 physics or import legacy `sphere.pipeline` on shipping.

| ID | Component | Path / contract |
|----|-----------|-----------------|
| A-01 | Sealed spine plumbing | `analysis_service`, `engine_analyze_contract`, `public_projection`, `system_seal` |
| A-02 | V7 router packet | `sphere/router/*` (envelope, fingerprint, pre_llm_compiler, audit, prompt_envelope, llm_interpret) |
| A-03 | fpf-thinking-map bridge | `sphere/router/thinking_map_bridge.py`, `sphere/calibration/` |
| A-04 | Icosahedral topology math | `sphere/topology/topology_loader`, `embedding`, `embedding_alignment`, `metrics` |
| A-05 | Guards Σ/Γ/Θ | `sphere/guards/*`, `sphere/runtime/guards.py` |
| A-06 | Shipping boundary | `runtime/shipping/api_main`, `cli_main`, `schema_guard`, `env_guard` |
| A-07 | context_rag A-blocks | `calculable`, `coherence_hints` (brain `context_rag.py`; wire `observability` in Gate C) |
| A-08 | KSI envelope wiring | `runtime/irc_teacher/analyze_adapter`, `engine_run_envelope` schemas |
| A-09 | MySQL ledger core | `hesperia_teacher_run`, `hesperia_edge_snapshot` activation core columns |
| A-10 | Product interpret governed API | `runtime/services/product_interpret_service.py` |

---

## B-02 — Class B (domain / provider-specific — stay non-cored)

| ID | Component | Why B |
|----|-----------|-------|
| B-01 | Sealed multiscale stack + assets | Frozen 0.6.3 physics — **sealed**, not drain |
| B-02 | `hesperia/modules/tfp/`, DLCR sidecar | Clinical domain |
| B-03 | `sphere/pipeline` (legacy), `runtime/pipeline/analyze.py` | Retire path |
| B-04 | TFP YAML bindings | `area_structure`, `family_structure`, `family_embedding_tfp.yaml` |
| B-05 | Calibration dict packs / OpenAI calibrate | `assets/calibration/`, governed calibrate CLIs |
| B-06 | KSI thresholds / `ksi_config_v01.json` | TFP-tuned config |
| B-07 | context_rag retrieval layer | CHROMA-1 books — not product core |
| B-08 | **COBALT** module | `runtime/cobalt/` when built — library RAG enhancer |
| B-09 | **MRT** branch | `hesperia_mrt` sibling repo |
| B-10 | MySQL ledger B columns | `label_ru`, grid ids — DDL wider than persist |
| B-11 | TFP observability levels | `families_structure_tfp.yaml` — not `context_rag.observability` |

---

## B-03 — Future-only (not v7 drain)

| Item | Rationale |
|------|-----------|
| Graph mutation / auto-apply from LLM | Blocked by router audit + charter |
| Apply-candidate promotion without sandbox | Post-0.6.5 / H070 |
| Speculative research threads → core | Ethan spec per module only |
| CHROMA cross-ingest | Forbidden per COBALT §7 |
| Unified runtime tree narrative | Rejected — modular branches (TFP / MRT / COBALT) |
| Vendor hidden reasoning as evidence | Forbidden — router/governor only |

---

SIGNED: Architecture (Ethan) | HSR-V7 Gate B class lists | 2026-06-29 | B-01..03
