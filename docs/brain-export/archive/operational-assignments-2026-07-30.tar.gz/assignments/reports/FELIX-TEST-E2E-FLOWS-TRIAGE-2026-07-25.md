# Felix — test_e2e_flows.py triage (pre-seal)

**Date:** 2026-07-25
**Authority:** Felix (flagged by Gena, [GENA-HESPERIA-CORE-WIRING-E2E-PRESEAL-2026-07-25.md](GENA-HESPERIA-CORE-WIRING-E2E-PRESEAL-2026-07-25.md): `tests/test_e2e_flows.py` — SKIPPED / hung >8min, not a core-wiring gate, flag for Felix)
**Repo:** `/data/hesperia/hesperia` (altitudine data-root mirror, `main`)
**Class:** Bug fix (import path) — no seal bytes, no prod pull

---

## Verdict

**Not a hang. Real bug, now fixed. Full file green.**

| Step | Result |
|------|--------|
| Isolate hanging tests individually (60s probes) | 4 tests exceeded 60s: `run_e2e_all_produces_all_artifacts`, `optional_dlcr_artifact`, `session_kme_and_triz_artifacts_shape`, `capability_matrix_wires_blocks` |
| Sub-function probing (`run_e2e_session_kme`, `run_e2e_triz_complete`) | CPU-bound, ~57s each, not deadlocked — ruled out network/lock hang |
| Full-file run, generous timeout | 5 tests pass fast, 6th (`test_e2e_run_e2e_all_produces_all_artifacts`) prints **F** after ~11.5min, then next test stalls until 20min kill |
| Isolated `test_e2e_run_e2e_all_produces_all_artifacts` alone, `-v --tb=long` | **FAILED** — `ImportError: cannot import name 'field_dynamics_enabled' from 'hesperia.extensions.dynamics.e2e_bridge'`, `runtime/pipeline/run_e2e_all.py:1361`, after 690.46s |

## Root cause

`runtime/pipeline/run_e2e_all.py` imported `field_dynamics_enabled` from `hesperia.extensions.dynamics.e2e_bridge` at two call sites (`run_all()` line 1361, `main()` line 1408). That name is not a module-level attribute of `e2e_bridge` — it only exists there as a local import inside `run_field_dynamics_e2e_artifact()`. The real definition lives in `hesperia.extensions.dynamics.phase1`.

Because this import sits after 11 prior pipeline stages in `run_all()`, it only raises ~11.5min into the test — long enough that prior harness runs (Gena's, mine at first) mistook it for a hang and killed/skipped it before it could fail cleanly.

## Fix

`runtime/pipeline/run_e2e_all.py` — both import sites now pull `field_dynamics_enabled` from `hesperia.extensions.dynamics.phase1` (unrelated `run_field_dynamics_e2e_artifact` import from `e2e_bridge` unchanged, that one's correct).

**Commit:** `fc7a7613` — pushed to `dev` (igareosh/hesperia), `backup` (hesperia-dev-backup), `origin` (Atomic-Commits-Team/hesperia).

## Verification

- `test_e2e_run_e2e_all_produces_all_artifacts` alone: **PASS** in 1374.40s (0:22:54).
- Full `tests/test_e2e_flows.py`: **13 passed, 1 deselected** (tfp-marked, correctly excluded by `pytest.ini` default) in 2633.95s (0:43:53).

## Note — this file is legitimately slow, not just this one bug

Slowest durations post-fix:
- `test_e2e_run_e2e_all_produces_all_artifacts` — 1349.41s
- `test_e2e_run_e2e_all_optional_dlcr_artifact` — 670.99s
- `test_e2e_capability_matrix_wires_blocks` — 299.35s
- `test_e2e_session_kme_and_triz_artifacts_shape` — 160.51s
- `test_e2e_tfp_smoke_with_dlcr_bundles` — 137.27s

No `lru_cache`/module-level caching found on the ontology loads (`concept_nodes.yaml` ~1.1MB, `concept_relations.yaml` ~280KB) reparsed per call across these heavy pipeline stages. Not fixed here — out of scope for a bug-fix triage — but flagging as a perf follow-up: any CI/harness running this file needs an explicit 45min+ budget, or it will read as a hang again on the next heavy stage.

---

## Scope note

This does not change Gena's core-wiring gate verdict (PASS, unaffected by this file). This closes out the one item Gena's report handed to me. Seal (`HSR-V7-X-01..14`) remains held per [HSR-V7-SEAL-OPERATOR-HOLD.md](../../../governance/HSR-V7-SEAL-OPERATOR-HOLD.md) — operator explicit allow required in chat before any X-* row executes; this report does not constitute that allow.

`SIGNED: Developer (Felix) | Claude Code context | 2026-07-25 | test_e2e_flows.py triage — bug fixed, 13/13 green`
