# Observability — dig / inquire structured log fields (no PII)

**Date:** 2026-07-19  
**Owner:** Noah (Observability)  
**Row:** FPF-MWI-22  
**Companion:** [ATM-TRACE-SCHEMA.md](../../../governance/ATM-TRACE-SCHEMA.md) · [SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll.md](../../../scripts/SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll.md)

---

## Purpose

Standard field names for Hesperia HAND rolling traces — **dig** (`hesperia-fpf-inspect`) and **inquire** (`hesperia-router`) — so operators and agents correlate loops without logging clinical content.

---

## Required fields (every invoke)

| Field | Type | Description |
|-------|------|-------------|
| `ts` | ISO8601 UTC | Event time |
| `trace_id` | string (UUID) | Correlates ops↔dig re-steps in one roll session |
| `face` | enum | `inquire` \| `dig` |
| `map_id` | string | `hesperia_ops` \| `hesperia_inspect` |
| `mcp_server` | string | `hesperia-router` \| `hesperia-fpf-inspect` |
| `tool` | string | e.g. `hesperia_router_inquire`, `hesperia_fpf_gaps` |
| `outcome_kind` | string | Map or engine outcome (`CONTINUE`, `COLLECT_EVIDENCE`, `IDLE`, `ERROR`, …) |
| `execution_host` | string | `hostname -s` (expect `altitudine` for dev) |
| `hesperia_repo_root` | string | Path only — e.g. `/data/workspaces/atomic-commit-hesperia` |
| `duration_ms` | int | Wall time |
| `exit_ok` | bool | Success vs ERROR path |

---

## Face-specific optional fields

### inquire (`hesperia-router`)

| Field | Type | Description |
|-------|------|-------------|
| `ground_truth_present` | bool | All three blocks returned |
| `logical_block_count` | int | Count only — no payload |
| `weight_block_count` | int | Count only |
| `source_activation_count` | int | Count only |
| `context_packet_keys` | string[] | Allowlist key names only |
| `input_chars` | int | Length only — **not** text |

### dig (`hesperia-fpf-inspect`)

| Field | Type | Description |
|-------|------|-------------|
| `probe_layer` | string | e.g. `L3`, `GTP`, `Guards` |
| `gap_report_id` | string | Stable id if engine emits one |
| `gap_count` | int | Number of gaps |
| `provisional_adr_count` | int | Provisional flags only |
| `climb_depth` | int | Steps in climb |
| `analyze_fingerprint` | string | Hash/id of analyze JSON — **not** analyze body |

---

## HAND / map correlation

| Field | Type | Description |
|-------|------|-------------|
| `thinking_map_kind` | string | From last `thinking_map_step` |
| `missing_evidence_count` | int | From map outcome |
| `gate_status_summary` | string | Comma-separated gate ids in `insufficient` state |
| `trigger` | string | `hesperia_bridge`, `workflow_proceed`, … |

---

## Forbidden in logs (hard)

- Raw input `text` or clinical/TFP corpus content  
- Patient identifiers, names, dates of birth  
- Full `ground_truth` / `GapReport` JSON bodies  
- Full `response_contract` with PII  
- Credentials, tokens, env secrets  

**Allowed:** counts, key names, hashes, layer ids, blocker ids, enum outcomes.

---

## Sink (dev)

| Sink | Path / mechanism |
|------|------------------|
| JSONL (preferred) | `governance/hesperia_hand_trace.jsonl` append-only |
| MCP stderr | ERROR lines only — no payload dump |
| Prometheus | Future — counter `hesperia_hand_invoke_total{face,tool,outcome}` |

---

## Example line (inquire, synthetic)

```json
{"ts":"2026-07-19T14:00:00Z","trace_id":"a1b2c3d4-…","face":"inquire","map_id":"hesperia_ops","mcp_server":"hesperia-router","tool":"hesperia_router_inquire","outcome_kind":"CONTINUE","execution_host":"altitudine","hesperia_repo_root":"/data/workspaces/atomic-commit-hesperia","duration_ms":842,"exit_ok":true,"ground_truth_present":true,"input_chars":48,"context_packet_keys":["thinking_map_outcome"]}
```

---

`SIGNED: Observability (Noah) | dig/inquire log schema | 2026-07-19 | MWI-22 no PII`
