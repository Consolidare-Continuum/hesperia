# ABELARD — COBALT-23 prod flag policy

**Date:** 2026-06-29

`verify-hesperia-cobalt-gates.sh` → **G1–G4 PASS** on pilot sample.

**Decision:** Do **not** set `HESPERIA_COBALT_ENABLED=1` on prod until:

1. G2 attribution scale-up beyond pilot doc set (operator/Abelard batch), and
2. Operator explicit chat approval for prod library retrieval.

Dev/staging may enable flag for integration tests.

SIGNED: DevOps (Abelard) | COBALT | 2026-06-29 | COBALT-23
