# GRACE — COBALT exit audit (COBALT-24)

**Date:** 2026-06-29

| Gate | Status |
|------|--------|
| G1 CHROMA-2 | PASS |
| G2 attribution pilot | PASS (`cobalt-g2-0.1`) |
| G3 eval | PASS pilot 7/10 clinical |
| G4 facets | PASS pilot |
| G5 grid policy | DONE |
| Adapter + flag off | DONE |
| Sealed core unchanged | YES |

**Prod:** `HESPERIA_COBALT_ENABLED=0` until operator scale-up attribution + optional COBALT-23 Abelard sign-off.

**Verdict:** **COBALT track EXIT (pilot)** — module ready; prod flag gated.

SIGNED: Team (Grace) | COBALT | 2026-06-29 | COBALT-24
