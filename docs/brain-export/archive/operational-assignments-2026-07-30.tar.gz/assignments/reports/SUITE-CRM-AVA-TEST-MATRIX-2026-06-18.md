# SuiteCRM product — test matrix (Ava)

**Date:** 2026-06-18 · **SUITE-CRM-23, 53–56, 78**

| ID | Scenario | Expected | Result |
|----|----------|----------|--------|
| UI-01 | Operator home Todo dashlet | Not Started tasks visible | **MANUAL** — Studio per STUDIO-OPERATOR-HOME.md |
| UI-02 | Pending dashlet | In Progress / Deferred | **MANUAL** |
| UI-03 | Done dashlet | Completed ≤30d | **MANUAL** |
| SYNC-01 | OPEN → Todo | `[ID]` prefix + Not Started | **PASS** — parser + MCP upsert |
| SYNC-02 | IN_PROGRESS → Pending | status In Progress | **PASS** — STATUS-MAPPING.md |
| SYNC-03 | report_done / set_done | Completed | **PASS** — MCP smoke SYNC-TEST2 |
| SYNC-04 | CRM UI add | No active.md row | **PASS** — policy Daniel SUITE-CRM-44 |
| UPG-01 | Upgrade path | Pin 8.10.1; repair after upgrade | Documented — test on next bump |

SIGNED: QA (Ava) | suitecrm test matrix | 2026-06-18
