# Felix — HSR-V7 Gate B inventories (B-06, B-07, B-09, B-10, B-15, B-19)

**Date:** 2026-06-29  
**Owner:** Felix  
**Dev clone:** `/data/workspaces/atomic-commit-hesperia` (`e36d6a5`, sealed base `0.6.3`)  
**Framing:** Ethan's Class A/B lists (B-01..03) pending; inventories inform B-21 resolution  
**Register:** [HSR-V7-2026-REGISTER.md](../../../governance/HSR-V7-2026-REGISTER.md)

---

## Tag legend (preliminary — not ratified)

| Tag | Meaning |
|-----|---------|
| **sealed** | Frozen 0.6.3 `/analyze` physics — must not move |
| **A** | Universal engine plumbing — drain candidate |
| **B** | Domain/provider-specific — stay non-cored |
| **A+sealed** | Both |

---

## B-06 — `/analyze` sealed core (must-not-move inventory)

### Canonical spine

```text
POST /analyze (api_main)
  ├─ run_structural_analysis → build_structural_internal_from_multiscale → run_sealed_multiscale_stack → project_to_public
  └─ run_engine_analyze → build_engine_analyze_from_raw (same sealed raw)
```

### Must-not-move (sealed)

| Component | Path |
|-----------|------|
| Physics runner | `hesperia/engine/sealed_multiscale_stack.py` — `run_sealed_multiscale_stack` |
| Bridge binding | `hesperia/engine/multiscale_product_bridge.py` — frozen signature, alias to stack |
| Sealed assets | `assets/data/engine_dynamics_v060/`, `assets/matrices/production/`, `assets/matrices/pch/`, `assets/topology/hex_topology_v1.json` |
| Spine tests | `tests/test_runtime_spine_integrity.py` — exclusive path, zero `sphere.pipeline` on product |

### Class A (universal plumbing on spine — may consolidate, not reopen physics)

`analysis_service`, `engine_analyze_contract`, `public_projection`, `system_seal`, `core/lexical/analysis_input`, `core/attribution/structural`, hex/PCH/matrix loaders, `product_signals`, `hspr_index`.

### Class B (must stay off sealed stack)

`sphere/pipeline` (legacy), `runtime/pipeline/analyze.py`, DLCR sidecar, `hesperia/modules/tfp/`, domain metrics via bridge, TRIZ optional, IRC `analyze_adapter` (consumer only).

**Decision test:** universal engine plumbing → **A**; domain/theme/attribution → **B**, compose after sealed `/analyze`.

---

## B-07 — `runtime/shipping/` (universal vs 0.6.3-coupled)

| File | Role | Tag |
|------|------|-----|
| `api_main.py` | FastAPI `/analyze`, `/compare`, `/batch`; `run_engine_analyze` sidecar | **A+sealed** |
| `cli_main.py` | Sealed CLI façade | **A+sealed** |
| `schema_guard.py` | Public output redaction | **A** |
| `schema_integrity.py` | Schema SHA256 gate | **A** |
| `env_guard.py` | `HESPERIA_*` allowlist | **A** |
| `license_check.py` | Optional license gate | **A** |
| `version_info.py` | Build metadata (drift: shows `0.6.0` vs `VERSION.yaml` `0.6.3`) | **A** |
| `shipping_import_allowlist.yaml` | Import surface policy | **A** |

**Split:** shipping is **universal product boundary** (Class A plumbing). **0.6.3 coupling** is behavioral — system seal at boot, calibration profile pin, HSPR engine envelope, trust/L7 compare fields — not filename-level.

---

## B-09 — `sphere/` (topology, embedding, guards)

### Strong Class A drain candidates

| Cluster | Paths | Notes |
|---------|-------|-------|
| Icosahedral topology | `sphere/topology/topology_loader`, `embedding`, `embedding_alignment`, `metrics` | Pure graph math |
| Guards Σ/Γ/Θ | `sphere/guards/*`, `sphere/runtime/guards.py` | Universal invariant orchestration |
| V7 router | `sphere/router/envelope_v0_1`, `fingerprint`, `thinking_map_bridge` | Pre-LLM packet (not sealed physics) |

### Class B within sphere

| Path | Why B |
|------|-------|
| `sphere/topology/area_structure.py`, `family_structure.py` | Load `*_tfp.yaml` clinical labels |
| `sphere/topology/family_embedding.py` | Machinery **A**, bound `family_embedding_tfp.yaml` **B** |

### Rest of sphere

L1–L10 pipeline (`propagation`, `shadow`, `dynamism`, `logic`, `interpretation`, `usf`, `pipeline`) — **A+sealed** on 0.6.3 path. **`sphere/fpf_bridge/` not in this clone** (package-pin path uses `sphere/router/thinking_map_bridge.py` per Gate A-03).

---

## B-10 — KSI pipeline

| Layer | Location | Class | Notes |
|-------|----------|-------|-------|
| Formal spec | `docs/brain-export/governance/SPEC-HESPERIA-KOLMOGOROV-SEMANTIC-INSPECTION-v0_1.md` | **A** contract | Incident types, bridge scoring |
| Compute engine | **tersagor** (`phi_e`, `pipeline`, `expected_j`) | **A** algo | **Not in Hesperia tree** |
| Envelope wiring | `runtime/irc_teacher/analyze_adapter`, `engine_run_envelope`, `teacher_packet` | **A** | Pulls `ksi` from `/analyze` |
| Schemas | `schemas/engine_run_envelope_v063.json` | **A** | Contract |
| Thresholds | `HESPERIA_KSI_TAU*`, `assets/data/ksi/ksi_config_v01.json` | **B** | TFP-tuned; config path referenced, assets missing in clone |
| Name collision | `tests/domain/test_derived_metrics.py` `KSI` metric | **N/A** | KME fingerprint — not Kolmogorov inspection |

---

## B-15 — `context_rag` packet

### Brain (packet source — Class A blocks)

| Block | Source | Class |
|-------|--------|-------|
| `calculable` | `cluster/chroma-server/context_rag.py` → `matrix_run` | **A** |
| `coherence_hints` | same — ring/adjacency | **A** |
| `observability` | same — read-only telemetry | **A** |
| `retrieval` | CHROMA-1 / books | **B** |

Schema: [governance/CONTEXT-RAG-PACKET-SCHEMA.md](../../../governance/CONTEXT-RAG-PACKET-SCHEMA.md)

### Hesperia adoption (v7 router)

| Field | In `RouterInputEnvelope`? | Class |
|-------|---------------------------|-------|
| `calculable` | Yes | **A** |
| `coherence_hints` | Yes | **A** |
| `observability` | **No** (gap for Gate C) | **A** (pending wire) |

**Disambiguation:** TFP `observability` in `families_structure_tfp.yaml` / `OBSERVABILITY_LEVELS` is **Class B** — different concept from `context_rag.observability`.

---

## B-19 — MySQL ledger

**ORM:** none — `pymysql` + raw SQL in `runtime/irc_teacher/mysql_ledger.py`.

| Table / column group | Class | Notes |
|---------------------|-------|-------|
| `hesperia_teacher_run` core (`run_id`, envelopes, git SHAs, status) | **A** | Audit/replay |
| `hesperia_teacher_run` (`input_text_ru`, `input_kind=tfp_scientific_statement`) | **B** | RU/TFP operator path |
| `hesperia_edge_snapshot` (`source/target`, `W_e`, `R_e`, `phi_sat`) | **A** | Written from `phi_trace` |
| `hesperia_edge_snapshot` (`Q_e`, `C_e`, `D_e`, `K_e`, grid ids) | **B** | DDL columns; **not populated** by current persist code |
| `hesperia_activation_snapshot` (`concept_id`, `observed`, `expected`, `residual`) | **A** | |
| `hesperia_activation_snapshot` (`label_ru`, `incident_type`, grid ids) | **B** | Often NULL in persist today |
| `hesperia_proposal`, `hesperia_reweight_event` | **A** | Proposal/apply audit |

DDL canonical: `docs/specs/0.6.3-IRC-TEACHER-RUN.md` §5. Referenced `cluster/hesperia/mysql/001_h063_schema.sql` **missing** from brain repo — Abelard/Gena hygiene item.

---

## Cross-cutting findings (for Ethan B-21)

1. **Sealed spine is narrow and test-locked** — drain work must not rebind `run_sealed_multiscale_stack` or import `sphere.pipeline` on shipping.
2. **Strongest A drain targets:** icosahedral topology math, guards, `sphere/router/`, brain `context_rag` A-blocks.
3. **KSI compute is off-repo** (tersagor) — Hesperia inventory is wiring + spec only.
4. **`observability` naming collision** — three domains; classify by contract.
5. **MySQL B columns exist in DDL but under-populated** — Gate C should either populate or narrow schema.

---

## Tasks closed

| ID | Status |
|----|--------|
| HSR-V7-B-06 | DONE — this doc §B-06 |
| HSR-V7-B-07 | DONE — this doc §B-07 |
| HSR-V7-B-09 | DONE — this doc §B-09 |
| HSR-V7-B-10 | DONE — this doc §B-10 |
| HSR-V7-B-15 | DONE — this doc §B-15 |
| HSR-V7-B-19 | DONE — this doc §B-19 |

---

SIGNED: Developer (Felix) | HSR-V7 Gate B inventories | 2026-06-29 | B-06 B-07 B-09 B-10 B-15 B-19
