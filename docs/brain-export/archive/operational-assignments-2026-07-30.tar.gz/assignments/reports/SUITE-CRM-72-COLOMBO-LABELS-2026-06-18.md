# Colombo — Tasks UI labels (EN / RO)

**SUITE-CRM-72**

| EN (product) | RO suggestion | Notes |
|--------------|---------------|-------|
| Todo | De făcut | Home dashlet |
| Pending | În așteptare | |
| Done | Finalizat | |
| Task | Sarcină | Module |
| brain_project | Proiect brain | Custom field label post-repair |

Operator may set RO in SuiteCRM language packs (installed).

SIGNED: Research (Colombo) | UI labels | 2026-06-18
