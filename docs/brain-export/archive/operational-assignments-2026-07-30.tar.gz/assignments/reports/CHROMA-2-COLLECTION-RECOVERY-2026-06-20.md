# CHROMA-2 collection recovery — operational report

**Date:** 2026-06-20  
**Owner:** Cursor (Abelard-equivalent ops on librarymaster)  
**Trigger:** Workflow grind — Papra/CHROMA-2 operational check before full-auto

---

## Symptom

- `reindex_progress.txt` reported **796 indexed, 0 chunks** while `/data/chroma-2/data` was **12G**.
- HTTP API exposed empty collection `documents` UUID `00e218fe-…` (count **0**).
- SQLite on disk held collection `3c91fd88-…` with **1,229,691** embeddings.

**Root cause:** `chroma-2-docker` restart (~07:51 UTC) + `papra-ingest` startup **POST** created a duplicate empty `documents` collection in the API layer; ingest progress polled the orphan UUID until chunk count read **0**.

---

## Recovery (librarymaster)

1. `systemctl stop papra-ingest`
2. `systemctl restart chroma-2-docker` — API re-bound to sqlite collection `3c91fd88-…`
3. Verified: **1,229,691** chunks via HTTP + sqlite
4. `systemctl start papra-ingest` — progress file updated:

```
docs_indexed: 796 / 1010 (78.8%)
chunks: 1229691
ingest_run_id: eaf9d3b03a7b
```

---

## Operational status (post-recovery)

| Service | Status |
|---------|--------|
| `chroma-2-docker` | active |
| `papra-ingest` | active |
| CHROMA-2 `documents` | **1,229,691** chunks |

**Reindex (historical):** PAPRA-29 reached corpus pass 100%; `docs_indexed` gap = `OCR_req` bucket. **Operator tombstone 2026-06-23:** ingest **COMPLETE** — dead end until `OCR_req` tag removed. Ref: [governance/TOMBSTONE-PAPRA-OCR-REQ-INGEST-DEAD-END.md](../../governance/TOMBSTONE-PAPRA-OCR-REQ-INGEST-DEAD-END.md).

---

## Follow-up (Abelard)

- Ingest worker: **do not POST create collection** if `documents` exists in sqlite (idempotent get-or-create).
- Add preflight: HTTP chunk count must match sqlite embeddings count before declaring ingest healthy.
- Runbook note in [SCRIPT-RUNBOOK-chroma-2-librarymaster.md](../../scripts/SCRIPT-RUNBOOK-chroma-2-librarymaster.md) § incident.

---

SIGNED: Cursor | CHROMA-2 collection recovery | 2026-06-20
