# Integration matrix — HAND faces · pin · ground_truth · GapReport · determinism

**Date:** 2026-07-19  
**Owner:** Ava (QA / integration)  
**Rows:** FPF-MWI-17 · FPF-MWI-18 · FPF-PRE07-14  
**Canon:** HAND SPEC · BUII SPEC · Colombo glossary PRE07-13 · Marcus dig runbook PRE07-17

---

## Matrix (must all align for PRE07-G1/G2)

| Axis | Expected | Verify |
|------|----------|--------|
| **Face: inquire** | MCP `hesperia-router` → `hesperia_router_inquire` · map `hesperia_ops` | Session tool list + gold ops loop |
| **Face: dig** | MCP `hesperia-fpf-inspect` → `hesperia_fpf_probe` / `_gaps` / `_map_step` · map `hesperia_inspect` | Session tool list + gold dig loop |
| **Pin** | `fpf-thinking-map==1.5.0` brain + Hesperia | `requirements-thinking-map.txt` · `requirements/router.txt` · GapReport `fpf_pin` |
| **ground_truth** | Three blocks: `logical` · `weight` · `source_activation` · schema `hesperia.agent_response_ground_truth.v0_1` | Inquire / interpret response only — agent never authors |
| **GapReport** | schema `hesperia.fpf_gap_report.v0_1` · `lowest_failed_layer` · `gaps[]` · `engine_fingerprint` · `fpf_pin` | climb / gaps CLI or MCP |
| **context_packet** | Self-contained invoke payload — no server session | Router inquire args; allowlist in Hesperia schema doc PRE07-09 |
| **Determinism (MWI-18)** | Same synthetic gold → same GapReport fingerprint + same ground_truth keys | Gold fixture twice; compare hashes |

---

## Face split (normative)

| Map | Face | Output as map evidence | Forbidden |
|-----|------|------------------------|-----------|
| `hesperia_ops` | inquire | `ground_truth` three blocks | Authoring blocks; opening UI |
| `hesperia_inspect` | dig | GapReport + InspectSlice | Merging inquire into probe; stub L6 as evidence |

Upper LLM = advise on GapReport/envelope only — **not** a third face.

---

## ground_truth three blocks (MWI-17 check)

| Block | Engine source (illustrative) | Empty = |
|-------|------------------------------|---------|
| `logical` | engine_trace present · logic_mapping · GTP imprint | `GroundTruthMissingError` |
| `weight` | governance/loopability/tension/obstacle · risk_level · gtp_coherence | same hard fail |
| `source_activation` | corpus/policy snapshot ids · retrieval_context · GTP hex | same hard fail |

Seams: `sphere/router/tool_inquiry.py` · `runtime/services/product_interpret_service.py`.

---

## GapReport + determinism (MWI-18)

```
[ ] climb --full on gold A → GapReport G1
[ ] repeat identical input → GapReport G2
[ ] G1.engine_fingerprint == G2.engine_fingerprint
[ ] gap ids + lowest_failed_layer stable
[ ] fpf_pin == fpf-thinking-map==1.5.0
[ ] stub L6 fields absent from evidence_ids
```

CLI:

```bash
cd /data/workspaces/atomic-commit-hesperia
python -m sphere.fpf_inspect climb --full --analyze-file <gold.json> | tee /tmp/g1.json
python -m sphere.fpf_inspect climb --full --analyze-file <gold.json> | tee /tmp/g2.json
# compare engine_fingerprint + gaps
```

---

## Integration pass/fail

| ID | Criterion | Result |
|----|-----------|--------|
| MWI-17 | Both faces + ground_truth three blocks on synthetic gold | `[ ] PASS` / `[ ] FAIL` |
| MWI-18 | Deterministic GapReport on same gold | `[ ] PASS` / `[ ] FAIL` |
| PRE07-14 | This matrix frozen + linked from Emma acceptance | `[ ] PASS` / `[ ] FAIL` |

**FAIL routing:** empty ground_truth → Felix MWI-02/13 · face missing → Liam PRE07-16 · pin drift → Gena PRE07-08 / Felix PRE07-01 · nondeterminism → Gena BUII P5.

---

## Explicit out of scope

- Prod X-05 deploy  
- Seal tag / HSR-V7-X unpause  
- Clinical REAL_DATA  

---

`SIGNED: QA (Ava) | HAND integration matrix | 2026-07-19 | MWI-17 MWI-18 PRE07-14`
