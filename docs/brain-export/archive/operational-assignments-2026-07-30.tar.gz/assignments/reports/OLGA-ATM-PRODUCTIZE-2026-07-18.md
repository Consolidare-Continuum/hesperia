# OLGA-ATM — productized permanent deploy (closeout)

**Date:** 2026-07-18  
**Host:** altitudine · user `olga` · path `/home/olga/olga-work`  
**Repo:** `igareosh/olga` @ `3d5f255` (on `dec3741` + gate fixes)

## Verdict

**PRODUCTIZED — permanent for `/home/olga`.** Claude (Felix) addressed, checked, tested. Selfcheck PASS. Git clean of MCP work; only Olga’s own in-progress case/exam files remain unstaged (untouched).

## What “productized” means

| Piece | Role |
|-------|------|
| `scripts/olga-mcp-selfcheck.sh` | Six real checks (engine, gate logic both branches, evidence grants mocked, no team_ops leakage, launcher cwd-independence, live CHROMA-2 smoke). Replaces weak “import only” preflight. |
| `scripts/olga-thinking-map-python-env.sh` | Single cwd-pin + PYTHONPATH — sourced by launcher **and** selfcheck (no drift). |
| `scripts/deploy-olga-mcp.sh` | Clears stale bytecode; kills live MCP subprocess so next Cursor tool call respawns fresh (~35s verified in Olga session). |
| `scripts/olga-ide-preflight.sh` | Step 6 = real selfcheck; **hard-fail** if not PASS. |
| `.cursor/rules/colombo-olga-clinical.mdc` | Tool-first: `clinical_locate_step` before drafting science; raw-model science answers = compliance failure. |

## Verified this host (2026-07-18)

```text
bash scripts/olga-mcp-selfcheck.sh  →  === SELFCHECK PASS ===
mcp-config includes olga-colombo-thinking-map (after colombo-library)
```

## Operator

Olga Cursor: Remote-SSH → `altitudine` → `/home/olga/olga-work`. After code deploys, MCP auto-respawns; full IDE restart only if MCP list missing the server.

## Related

- Design: [ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md](../ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md)
- Workspace: [cluster/olgahere/OLGA-COLOMBO-WORKSPACE.md](../../../cluster/olgahere/OLGA-COLOMBO-WORKSPACE.md)
- Wave rows: **OLGA-ATM-00..06** DONE

SIGNED: Cursor | Olga ATM productize closeout | 2026-07-18 | permanent /home/olga  
SIGNED: Compliance (Cursor) | see [OLGA-ATM-COMPLIANCE-SIGN-2026-07-18.md](OLGA-ATM-COMPLIANCE-SIGN-2026-07-18.md) | 2026-07-18 | olgahere Remote-SSH PREFLIGHT PASS
