# Felix — Hesperia + SuiteCRM MCP duty

**SUITE-CRM-60** · When executing Hesperia rows on active.md:

1. `report_done(task_id, DONE)` via pipeline MCP (canonical).
2. `suitecrm_set_done(task_id)` via **cursor-suitecrm** when MCP in session.
3. Row must exist on active.md before CRM write (Grace triage).

Ref: [SPEC-ETHAN-SUITECRM-PRODUCT-PIPELINE.md](../../governance/SPEC-ETHAN-SUITECRM-PRODUCT-PIPELINE.md) §6.

SIGNED: Developer (Felix) | Hesperia CRM duty | 2026-06-18
