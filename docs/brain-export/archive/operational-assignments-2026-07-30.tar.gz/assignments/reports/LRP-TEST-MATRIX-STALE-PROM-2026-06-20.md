# Test matrix — forced stale → Prometheus alert

**LRP-53** · Owner: Ava

| Step | Action | Expected | Result 2026-06-20 |
|------|--------|----------|-------------------|
| 1 | Deny replication key (`chmod 000`) | job exit 1 | PASS |
| 2 | prom `lan_replication_last_run_exit_code` | 1 | PASS |
| 3 | prom `lan_replication_freshness_violation` | 1 | PASS |
| 4 | Restore key + successful run | exit 0, violation 0 | PASS |
| 5 | Alert rule `LanReplicationFailed` | fires when exit≠0 | rule in `cluster/prichindel/prometheus/rules.yml` — scrape-dependent |

SIGNED: QA (Ava) | LRP-53 | 2026-06-20 | forced stale prom
