# Backend test — MCP 12/12 handshake smoke

**MCP-BRAIN-009** · Olivia · `bash scripts/verify-mcp-appendix.sh` (from alunel hop)

| # | MCP | Smoke | Pass 2026-06-20 |
|---|-----|-------|-----------------|
| 1 | chroma-knowledge | verify-mcp.sh | altitudine venv OK |
| 2 | cursor-pipeline-status | import | OK |
| 3 | cursor-runbook | import | OK |
| 4 | cursor-approval-gates | import | OK |
| 5 | cursor-postfix-mail | import | OK |
| 6 | cursor-cluster-snapshot | get_lan_replication_status | OK |
| 7 | cursor-github-ci | import | OK |
| 8 | cursor-context-rag | import | OK |
| 9 | cursor-inbox-reader | import | OK |
| 10+ | colombo-library, suitecrm, tailscale | per deploy | IDE session |

**Status:** READY (baseline + appendix path documented)

SIGNED: Backend (Olivia) | MCP-BRAIN-009 | 2026-06-20 | MCP handshake template
