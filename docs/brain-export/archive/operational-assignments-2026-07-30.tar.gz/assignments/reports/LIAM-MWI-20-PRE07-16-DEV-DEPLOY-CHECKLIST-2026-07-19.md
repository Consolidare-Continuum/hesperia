# Dev deploy checklist — both Hesperia HAND MCP faces (altitudine)

**Date:** 2026-07-19  
**Owner:** Liam (Deploy / release hygiene)  
**Rows:** FPF-MWI-20 · FPF-PRE07-16  
**Host:** altitudine only (`execution_host=altitudine`, `dev_office=true`)  
**Not:** prod X-05 · not `/data/hesperia/hesperia` as MCP default · not seal tag bump

**Depends:** Abelard host verify [ABELARD-MWI-21-PRE07-15-MCP-HOST-VERIFY-2026-07-19.md](ABELARD-MWI-21-PRE07-15-MCP-HOST-VERIFY-2026-07-19.md) · runbook [SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll.md](../../../scripts/SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll.md)

---

## Target layout

| Item | Value |
|------|--------|
| Brain | `/data/altitudine/prichindel.com` |
| `HESPERIA_REPO_ROOT` | `/data/workspaces/atomic-commit-hesperia` |
| Pin | `fpf-thinking-map==1.5.0` (brain + Hesperia `requirements/{router,calibration}.txt`) |
| MCP faces | `hesperia-fpf-inspect` · `hesperia-router` |

---

## Checklist (execute in order)

### A. Dev clone

```
[ ] cd /data/workspaces/atomic-commit-hesperia && git status clean enough for MCP smoke
[ ] remote = igareosh/hesperia (dev) — not Atomic prod promote path
[ ] sphere/fpf_inspect/__main__.py present
[ ] python -c "import sphere.fpf_inspect" from repo root (venv activated if used)
[ ] pip show fpf-thinking-map | grep 1.5.0
```

### B. Launchers (brain)

```
[ ] test -x scripts/agent-mcp-hesperia-fpf-inspect.sh
[ ] test -x scripts/agent-mcp-hesperia-router.sh   # Felix MWI-01 — BLOCK if missing
[ ] both export HESPERIA_REPO_ROOT default → /data/workspaces/atomic-commit-hesperia
[ ] both export CURSOR_REPO_ROOT → brain path
```

### C. mcp-config

```
[ ] grep hesperia-fpf-inspect governance/mcp-config.json
[ ] grep hesperia-router governance/mcp-config.json
[ ] bash scripts/deploy-mcp-config-global.sh   # from brain root
[ ] fully restart Cursor (MCP stdio reload)
```

Expected entries:

```json
"hesperia-fpf-inspect": {
  "command": "bash",
  "args": ["/data/altitudine/prichindel.com/scripts/agent-mcp-hesperia-fpf-inspect.sh"]
},
"hesperia-router": {
  "command": "bash",
  "args": ["/data/altitudine/prichindel.com/scripts/agent-mcp-hesperia-router.sh"]
}
```

### D. Session smoke (no UI)

```
[ ] Cursor session on altitudine brain workspace
[ ] tools visible: hesperia_fpf_probe / _gaps / _map_step + hesperia_router_inquire
[ ] HESPERIA_REPO_ROOT resolves in launcher env
[ ] synthetic gold inquire returns ground_truth three blocks OR documented blocker
[ ] synthetic gold climb/gaps returns GapReport OR documented blocker
```

### E. Explicit exclusions (must stay true)

```
[ ] HSR-V7-X-05 / prod deploy NOT run
[ ] HESPERIA_REPO_ROOT NOT pointed at /data/hesperia/hesperia for agent MCP
[ ] HESPERIA_MCP_BRIDGE_REAL_DATA unset / not 1
[ ] no seal / VERSION tag bump (Gena PRE07-08)
```

---

## Redeploy recipe (after code pull)

```bash
# 1. Hesperia
cd /data/workspaces/atomic-commit-hesperia
git pull --ff-only
# activate project venv if present; reinstall pin if bumped
pip install -r requirements/router.txt   # includes fpf-thinking-map==1.5.0

# 2. Brain MCP
cd /data/altitudine/prichindel.com
bash scripts/deploy-mcp-config-global.sh
# 3. Restart Cursor IDE — required
```

---

## Verdict

| Gate | Status |
|------|--------|
| Both MCP faces on altitudine | `[ ] PASS` / `[ ] BLOCKED` |
| Block reason | |
| PRE07-G1 contribution | Both faces + pin path documented |

Hand off BLOCKED → Felix (missing launcher/module) or Abelard (host path). Acceptance stamp → Emma PRE07-18.

---

`SIGNED: Release (Liam) | altitudine MCP dual-face deploy | 2026-07-19 | MWI-20 PRE07-16 not prod X-05`
