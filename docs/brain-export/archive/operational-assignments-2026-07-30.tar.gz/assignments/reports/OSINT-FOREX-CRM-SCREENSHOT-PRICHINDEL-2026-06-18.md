# prichindel.com — OSINT semantic investigation report

| Field | Value |
|-------|--------|
| **Document ID** | `PRICHINDEL-OSINT-2026-06-18-001` |
| **Title** | Screenshot semantic analysis — multi-brand forex/crypto CRM lead table |
| **Author** | Colombo (Employ 4 — research / formalization) |
| **Company** | prichindel.com |
| **Date** | 2026-06-18 |
| **Classification** | Internal research — open-source intelligence only |
| **Logo (public)** | https://prichindel.com/assets/logo-prichindel.png |
| **Evidence** | Two photographs of a monitor; chat-derived inference chain (Cursor session 2026-06-18) |

---

## Abstract

This report formalizes an open-source intelligence (OSINT) and semantic analysis of a cropped photograph showing a tabular database-style view containing partially redacted personal data, financial figures, broker brand names, and Slavic personal names. The investigation proceeds in three layers: (1) visual and lexical evidence inventory, (2) inferred relational schema and storage encoding, (3) public-domain entity linkage for visible brand strings. Confidence is expressed as qualitative ranges (Possible / Unlikely / Not possible) suitable for downstream search and triage. **No attempt was made to deanonymize redacted fields or access live systems.**

---

## Page 1 — Scope, methodology, and evidence inventory

### 1.1 Scope

**In scope**

- Semantic interpretation of visible columns and cell values
- Likely database field types, encoding, and sort behaviour
- Product class (CRM / back-office vs other domains)
- Public regulator and watchdog signals for named brands
- Search-friendly conclusions for investigators, compliance staff, and researchers

**Out of scope**

- Unmasking `****` redactions (email, phone, IP, codes)
- Identifying natural persons behind visible names
- Penetration, login, or unauthorized access to any CRM
- Legal determination of fraud (report cites public warnings only)

### 1.2 Methodology

| Step | Action |
|------|--------|
| E1 | Capture review — two images: (a) name-only list on pale blue background; (b) full row table with PII and numbers |
| E2 | Column alignment — left-to-right reading; note wrap in phone column |
| E3 | Sort reconstruction — test hypotheses (surname sort, given-name sort, full-string DESC) |
| E4 | Schema inference — map columns to canonical CRM entities (lead, brand, ledger) |
| E5 | Engine priors — compare patterns to MySQL/MariaDB/Oracle default behaviour |
| E6 | OSINT linkage — web search for brand strings and forex CRM product class |
| E7 | Confidence tagging — High / Medium / Low / Not possible |

### 1.3 Evidence artifacts

**Image A (names only)** — four lines, pale blue panel:

1. Vladimir Serebrov  
2. Sinitsin Dmitriy  
3. Aleksei Dolmatov  
4. Aleksandr Achertonn  

**Image B (full table)** — four visible rows, ≥10 columns (headers cropped). Left-to-right cell content:

| Row | Col 1 (email) | Col 2 (phone) | Col 3 | Col 4 (IP) | Col 5 | Col 6 | Col 7 | Col 8 (brand) | Col 9 (name) | Col 10 |
|-----|---------------|---------------|-------|------------|-------|-------|-------|---------------|--------------|--------|
| 1 | ele****@gma**** | +37 / 3**** | Aa**** | 86.**** | 117,510 | 142,680 | 151 | … Solutions | Vladimir Serebrov | E |
| 2 | den****@gma**** | +37 / 3**** | 06**** | 188.**** | 97,650 | 213 | 129,752 | Platinum Shares Solutions | Sinitsin Dmitriy | N |
| 3 | ali****@gma**** | +37 / 3**** | 12**** | 0.**** | 75,124 | -8,075 | 92,856 | Titan | Aleksei Dolmatov | R |
| 4 | dic****@mai**** | +37 / 3**** | Sc**** | 46.**** | 63,763 | 761 | 129,885 | *(blank)* | Aleksandr Achertonn | A |

**Observations fixed as facts**

- Redaction uses fixed-width asterisk masking (`****`) — consistent application-layer privacy mask
- Phone prefix `+37` with second line `3****` strongly suggests **+373 (Moldova)** among +37x ITU codes
- Column 6 includes a **negative** value (`-8,075`) ⇒ signed numeric semantics
- Column 8 includes **Platinum Shares Solutions** and **Titan** as literal brand strings
- Name column repeats Image A strings; order preserved top-to-bottom
- Numeric columns use **comma thousands separators** without decimal cents in view

---

## Page 2 — Inferred schema (semantic column map)

### 2.1 Column-level inference

| Col | Visible pattern | Likely DB field | Confidence |
|-----|-----------------|-----------------|------------|
| 1 | `ele****@gma****` … | `email` `VARCHAR(255)` UTF-8 | **High** |
| 2 | `+37` / `3****` (wrapped) | `phone` `VARCHAR(20)` E.164-ish string | **High** (+373 Moldova **likely**) |
| 3 | `Aa****`, `06****`, `Sc****` | `login`, `affiliate_ref`, `desk_code`, or doc prefix — **not** full password | **Medium** |
| 4 | `86.****`, `188.****`, `0.****` | `registration_ip` or `last_ip` `VARCHAR(45)` / INET | **High** |
| 5 | `117,510` … `63,763` | monetary: `total_deposit`, `ftd`, or fake “balance” `DECIMAL`/`INT` | **Medium–High** |
| 6 | `142,680` / `213` / `-8,075` / `761` | signed metric: `pnl`, `net_balance`, or withdrawal | **Medium** (negative ⇒ signed column) |
| 7 | `151` … `129,885` | second ledger: withdrawals, bonus, volume, or retention score | **Low–Medium** |
| 8 | Platinum Shares Solutions / Titan / blank | `brand_id` → `brands.name` (multi-desk CRM) | **High** |
| 9 | Names (mixed order) | `full_name` or broken `first_name`/`last_name` | **High** |
| 10 | `E` / `N` / `R` / `A` | `status` `ENUM`/`CHAR` — sales pipeline code | **Medium** |

### 2.2 Conceptual relational model

```text
brands(id, name)                    -- Platinum Shares Solutions, Titan, …
leads / clients(
  id, email, phone, full_name,
  brand_id, status, reg_ip,
  metric_a, metric_b, metric_c,    -- denormalized totals possible
  …
)
deposits_ledger(client_id, amount, type)   -- optional normalized ledger
```

**Formal note.** Multi-brand column plus deposit-like numerics matches documented **forex back-office CRM** layouts (e.g. FXBO-class systems, Kenmore CRM MySQL replication schemas). See public product descriptions: [FX Back Office](https://fxbackoffice.com/), [Kenmore CRM data push](https://www.kenmoredesign.com/forex-api-for-developers/crm-data-push/).

### 2.3 Name-field anomaly (row 2)

| Row | Rendered | Token order |
|-----|----------|-------------|
| 1, 3, 4 | Given + Family | Vladimir Serebrov; Aleksei Dolmatov; Aleksandr Achertonn |
| 2 | Family + Given | Sinitsin Dmitriy |

**Inference:** `display_name` is a **single concatenated string** without normalization. Row 2 fits `CONCAT(last_name, ' ', first_name)` or manual entry in family-first convention (common in RU/CIS forms). **Possible (≈85%).** This is **not** default behaviour of MySQL, MariaDB, or Oracle.

### 2.4 Sort order (semantic)

Observed name order: **V → Si → Aleksei → Aleksandr** (full string descending).

| Hypothesis | Fits? |
|------------|-------|
| `ORDER BY display_name DESC` | **Yes — High** |
| `ORDER BY last_name DESC` | No |
| `ORDER BY first_name DESC` | No (row 2 keys on Sinitsin) |
| Default DB order without `ORDER BY` | No (undefined order) |

Financial columns are **not** monotonic with name order ⇒ sort key is **name column only**.

---

## Page 3 — Encoding, storage, and database engine priors

### 3.1 Character encoding

| Aspect | Verdict | Range |
|--------|---------|-------|
| Character encoding | UTF-8 / `utf8mb4` | **Possible (≈85%)** — Latin transliteration, no mojibake |
| Exotic Cyrillic-in-DB / Latin-in-UI split | Not required by evidence | **Unlikely** |

### 3.2 Database engine (storage tier)

| Engine | Range | Rationale |
|--------|-------|-----------|
| **MySQL / MariaDB** | **Possible (≈70%)** | Dominant in forex CRM tier; Kenmore and similar vendors document MySQL replication |
| **PostgreSQL** | **Possible (≈20%)** | Some modern CRM stacks |
| **Oracle** | **Unlikely (≈5%)** | Typical for large regulated enterprises; mismatches desk-level UI cues |

### 3.3 Column typing priors

| Data | Likely storage | Confidence |
|------|----------------|------------|
| Amounts | `INT` or `DECIMAL(12,2)`; UI may drop cents | **Possible (≈75%)** |
| Phone | String with `+` prefix — not numeric type | **High** |
| IP | String column — not binary `INET6` | **Possible (≈60%)** |
| Status | Single char or short enum | **Medium** |

### 3.4 Display vs database defaults

| Behaviour | DB default? | Verdict |
|-----------|-------------|---------|
| `ORDER BY` direction | Engines default to **ASC** | **DESC sort is explicit** (SQL, view, or UI) — **High** |
| `****` redaction | No native MySQL/Oracle mask in grid | **Application / role-based view — High** |
| Comma thousands (`117,510`) | Not raw SQL*Plus/psql default | **Frontend locale or `FORMAT()` — High** |
| Family-first name on one row | No | **Import / concat bug — Possible (≈85%)** |

**Compact storage model:** plain **UTF-8 text + numeric money columns** under a **web CRM admin** — no exotic collation required to explain the screenshot.

---

## Page 4 — Domain semantics, UI class, and public OSINT linkage

### 4.1 System class

| Conclusion | Range |
|------------|-------|
| Forex/crypto affiliate or retention CRM | **Possible (≈90%)** |
| Multi-brand “boiler room” / unlicensed desk operation | **Possible (≈85%)** |
| Medical / TFP / therapist registry | **Not possible (~0%)** |
| University / Oracle APEX academic DB | **Not possible (~0%)** |
| Generic SaaS CRM (Salesforce, HubSpot) | **Unlikely (≈10%)** |
| Raw phpMyAdmin / SQL Developer grid | **Unlikely (≈15%)** |
| Licensed MT4/MT5 regulated broker back-office | **Unlikely (≈20%)** |

**Geography:** +373-style phones + Slavic names ⇒ **CIS / Moldova lead pool — Possible (≈80%).**

### 4.2 Money columns (header absent)

| Hypothesis | Fits `-8,075`? | Range |
|------------|----------------|-------|
| Deposit total / platform “balance” / withdrawal net | Yes | **Possible (≈65%)** |
| FTD / lifetime deposit / bonus | Partially | **Possible (≈50%)** |
| Lead score / call count | No | **Unlikely** |
| Unix timestamp / pure ID | No | **Not possible** |

### 4.3 UI / product stack

| Stack | Range |
|-------|-------|
| White-label forex CRM (FXBO, Syntellicore, UpTrader, Kenmore, custom) | **Possible (≈60%)** |
| Custom admin (PHP / Laravel / Node + MySQL) | **Possible (≈55%)** |
| Spreadsheet export | **Unlikely (≈10%)** |
| ERP (1C, SAP) | **Not possible (~0%)** |

Visual cues: pale web table, wrapped phone cell, clipped right column ⇒ **browser admin panel**, not terminal SQL client.

### 4.4 Public OSINT — brand column entities

Investigation used **public regulator and watchdog sources only**.

#### Platinum Shares Solutions

| Authority | Signal | URL |
|-----------|--------|-----|
| Bank of Russia | Illegal securities-market activity warning | https://cbr.ru/eng/inside/warning-list/detail/?id=38294 |
| BC Securities Commission | Investment Caution List (not registered) | https://www.bcsc.bc.ca/enforcement/early-intervention/investment-caution-list/2025/platinum-shares-solutions |
| AMF (Québec) | Not registered; unauthorized solicitation | https://lautorite.qc.ca/en/general-public/media-centre/investor-warnings/investor-warnings-sheet/platinum-shares-solutions |

Reported domains in warnings include `platinum-shares-solutions.com` and related names — **verify live on authority sites before citation in legal filings.**

#### Titan (column value)

**Titan** is a **generic broker marketing label** reused across many unrelated entities (multiple “Titan *” platforms carry scam warnings). The cell value **does not prove** use of [Titan-T CRM software](https://liquidityfeed.com/Company/titan-t/) — only that this lead row is tagged to a desk brand named “Titan”.

**Multi-brand inference:** one CRM, many `brand_id` values — **Possible (≈75%).**

### 4.5 Status codes (column 10)

Visible: `E`, `N`, `R`, `A`. Plausible CRM pipeline maps (unverified without header):

- Engaged / New / Retention / Active  
- Eligible / No answer / Registered / Assigned  

**Confidence: Medium (≈55%)** — requires UI header or vendor documentation.

### 4.6 Blank brand (row 4)

**Possible (≈70%):** NULL `brand_id`, unassigned lead, or churned desk.

---

## Page 5 — Limitations, searcher conclusions, and next steps

### 5.1 What cannot be concluded

| Item | Status |
|------|--------|
| Deanonymize redacted email / phone / IP | **Out of scope** — intentional mask |
| Prove identity of named individuals | **Not possible** from redacted crop |
| Exact CRM vendor or version | **Not possible** — class-level only |
| Legal owner / hosting jurisdiction of DB | **Not possible** from screenshot |
| Whether displayed money reflects real funds | **Not possible** — may be internal desk metrics |

### 5.2 Final conclusions — searcher checklist

Plain statements for search engines, analysts, and compliance triage. Copy as discrete queries or filter rules.

1. **The screenshot shows a web-based CRM lead table, not a medical, academic, or raw DBA tool.**
2. **Columns match forex/crypto sales CRM patterns:** contact fields + IP + money metrics + multi-brand + pipeline status.
3. **Platinum Shares Solutions appears as a desk brand; public regulators have issued investor warnings against that name.**
4. **Titan in the brand column is a label inside the CRM, not proof of a specific CRM product named Titan-T.**
5. **Phone prefixes indicate Moldova (+373) or adjacent +37x ITU codes — CIS lead geography is likely.**
6. **Partial redaction (`****`) is applied in the application layer for agent-role screens.**
7. **Storage is likely MySQL/MariaDB with UTF-8 text; Oracle is unlikely at this tier.**
8. **Name sort is descending on a single display string (`ORDER BY name DESC` or equivalent UI click).**
9. **Row “Sinitsin Dmitriy” indicates inconsistent name concatenation (family-first on one record).**
10. **Column 6 includes negative values — treat as signed financial or P&L-like metric, not a counter.**
11. **Three numeric columns are monetary or desk-performance metrics — exact headers unknown without UI chrome.**
12. **One row has blank brand — treat as unassigned or NULL `brand_id`.**
13. **Status letters E/N/R/A are single-char pipeline codes — exact meanings need column header.**
14. **Do not attempt to unmask redacted PII from the image — insufficient entropy for reliable recovery.**
15. **Cross-check any brand string against national warning lists (CBR, BCSC, AMF, local FSA) before engagement.**

### 5.3 Recommended search queries (OSINT)

| Purpose | Example query |
|---------|----------------|
| Brand warnings | `"Platinum Shares Solutions" warning OR scam OR AMF OR BCSC` |
| Domain history | `platinum-shares-solutions.com` on registrar/WHOIS archives |
| CRM class | `forex CRM multi brand deposit ledger schema` |
| Moldova leads | `+373 forex leads CRM` (contextual — high noise) |
| Parallel scams | `"Platinum Shares" Titan forex` |

### 5.4 Evidence strengthening (if operator obtains more)

| Additional artifact | Would improve |
|--------------------|---------------|
| Column headers (any language) | Cols 5–7, status E/N/R/A |
| URL bar / login page title | CRM vendor class |
| UI language chrome | Locale and vendor fingerprint |
| Uncropped rows | Cardinality, pagination, filters |

---

## References (public)

1. Bank of Russia warning list — Platinum-shares-solutions — https://cbr.ru/eng/inside/warning-list/detail/?id=38294  
2. BCSC Investment Caution List — Platinum shares solutions — https://www.bcsc.bc.ca/enforcement/early-intervention/investment-caution-list/2025/platinum-shares-solutions  
3. AMF Québec investor warning — Platinum Shares Solutions — https://lautorite.qc.ca/en/general-public/media-centre/investor-warnings/investor-warnings-sheet/platinum-shares-solutions  
4. FX Back Office (forex CRM product class) — https://fxbackoffice.com/  
5. Kenmore Design — CRM MySQL replication schema — https://www.kenmoredesign.com/forex-api-for-developers/crm-data-push/  
6. prichindel.com brand registry — `brand/README.md` in brain repo  

---

## NEXT (Colombo)

| # | Action | Owner |
|---|--------|-------|
| 1 | If operator has **header row** or **URL**, append as `PRICHINDEL-OSINT-2026-06-18-001-A` addendum | igareosh → Colombo |
| 2 | If regulatory filing needed, cite **primary regulator URLs** above — not this report alone | Legal / operator |
| 3 | Do **not** route through Grace as prod task unless triage requires formal case file | Grace if escalated |

---

**SIGNED:** Research (Colombo) | OSINT semantic formalization | 2026-06-18 | forex CRM screenshot investigation · prichindel.com branded report
