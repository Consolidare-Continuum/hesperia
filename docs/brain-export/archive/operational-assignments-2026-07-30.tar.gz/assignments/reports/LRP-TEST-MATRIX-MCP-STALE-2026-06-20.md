# Test matrix — MCP stale=true → runbook path

**LRP-54** · Owner: Ava

| Step | Action | Expected | Result 2026-06-20 |
|------|--------|----------|-------------------|
| 1 | Induce failure (SSH key deny) | `get_lan_replication_status` failed/stale | stale after failed run |
| 2 | Output contains runbook id | `SCRIPT-RUNBOOK-lan-replication-stale` | PASS |
| 3 | BLOCKED_HINT when stale/failed | line present | PASS |
| 4 | ETHAN-TARGETED-RUNBOOKS row | mandatory trigger | PASS (LRP-44) |
| 5 | cluster-proceed-preflight step 2 | get_lan_replication_status | PASS (LRP-47) |

SIGNED: QA (Ava) | LRP-54 | 2026-06-20 | MCP stale runbook path
