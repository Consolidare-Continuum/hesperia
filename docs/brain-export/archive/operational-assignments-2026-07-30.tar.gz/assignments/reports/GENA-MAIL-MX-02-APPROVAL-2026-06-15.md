# Gena — MAIL-MX-02 architecture approval

**Date:** 2026-06-15  
**Decision:** **APPROVED** — build in-repo `agent_mcp_mailcow`; **n8n: NO** for v1.

| Check | Outcome |
|-------|---------|
| Module `cursor-mailcow-mail` / `agent_mcp_mailcow` | Approved |
| Creds `/data/smtp-outbound/mailcow-agents.env` | Approved |
| LAN IP + `MAILCOW_TLS_INSECURE_LAN` for mx1 connect | Approved (Daniel baseline) |
| Upstream/npm MCP | Rejected — mirror `agent_mcp_postfix_mail` pattern |
| n8n | Deferred — direct Python IMAP/SMTP sufficient |

**Implemented:** MAIL-MX-03 — tools `mail_send_text`, `mail_send_file`, `mail_list`, `mail_get`, `mail_check`.

---

SIGNED: Developer (Gena) | MAIL-MX-02/03 | 2026-06-15 | mx1 agent mail MCP
