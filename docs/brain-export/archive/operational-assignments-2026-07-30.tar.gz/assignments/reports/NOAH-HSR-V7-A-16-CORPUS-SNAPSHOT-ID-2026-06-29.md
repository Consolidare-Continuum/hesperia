# Noah — Current corpus snapshot id inventory (HSR-V7-A-16)

**Date:** 2026-06-29  
**Complements:** [NOAH-HSR-V7-08-CORPUS-SNAPSHOT-POLICY-2026-06-29.md](NOAH-HSR-V7-08-CORPUS-SNAPSHOT-POLICY-2026-06-29.md)

---

## Prod assets (sealed 0.6.3)

| Asset | Path (typical prod) | Snapshot contribution |
|-------|---------------------|------------------------|
| Dict B JSONL | `assets/calibration/dicts/` active pack `archive_063_minimal` | `dict_lane=dict-b` |
| TFP data tree | `tfp_v1` per `VERSION.yaml` | freeze point in Ethan row |
| Engine dynamics | `assets/data/engine_dynamics_v060/` | sealed base `0.6.3` |

## Canonical id (pending prod hash)

```text
hesperia-corpus-0.6.3-dict-b-<freeze_date>
```

**Operator action:** Abelard/Ethan to publish `freeze_date` + dict pack SHA256 in CHANGE-LOG when prod promote occurs. Until then router uses `corpus-unset` or `HESPERIA_CORPUS_SNAPSHOT_ID` env.

## Dev clone

Branch `hsr-v7-router-implementation` @ `c0f76a6` — same `VERSION.yaml` 0.6.3; calibration governed via `sphere/calibration/`.

---

SIGNED: Policy (Noah) | corpus snapshot id inventory | 2026-06-29 | A-16
