# Gena — COBALT-14 MCP stub contract

**Task:** `get_cobalt_packet` for IDE/tersagor

## MVP stub (until `hesperia-cobalt` MCP server)

**In-process (Hesperia dev):**

```python
from runtime.cobalt.retrieve import compose_and_retrieve
packet = compose_and_retrieve(text, engine_result=engine_trace, strategy="S1")
```

**Future MCP tool schema:**

| Arg | Type | Description |
|-----|------|-------------|
| text | string | Operator query |
| engine_trace | object? | Optional post-/analyze trace for S1 |
| strategy | S0\|S1 | Query composition |

**Returns:** `cobalt_retrieval` v0.1-mvp packet (see COBALT formalization §2.4).

**Flag:** `HESPERIA_COBALT_ENABLED=1` required on runtime host.

SIGNED: Developer (Gena) | COBALT MCP stub | 2026-06-29 | COBALT-14
