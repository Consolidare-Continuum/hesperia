# Colombo — Class B list verification vs TFP/COBALT/MRT branch model (HSR-V7-B-05)

**Date:** 2026-06-29  
**Inputs:** [ETHAN-HSR-V7-GATE-B-CLASS-LISTS-2026-06-29.md](ETHAN-HSR-V7-GATE-B-CLASS-LISTS-2026-06-29.md) §B-02 · [HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md](../../../colombo_research/hesperia/HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md) §2c · [HESPERIA-BRANCH-MODEL-TFP-COBALT-MRT.md](../../../colombo_research/hesperia/HESPERIA-BRANCH-MODEL-TFP-COBALT-MRT.md)

---

## Verdict

**PASS — correct separation.** Ethan's Class B list maps 1:1 to confirmed non-cored branches (TFP psy · MRT IT · COBALT attribution) plus sealed/frozen assets and retire paths that must not drain into core.

---

## Branch model ↔ Ethan B-rows

| Branch (§4) | Ethan B ID | Component | Separation correct? |
|-------------|------------|-----------|---------------------|
| **TFP** (clinical psy) | B-02 | `hesperia/modules/tfp/`, DLCR sidecar | **YES** — domain module, compose after `/analyze` |
| **TFP** | B-04 | TFP YAML (`area_structure`, `family_embedding_tfp.yaml`) | **YES** — clinical labels, not universal topology math |
| **TFP** | B-06 | `ksi_config_v01.json`, `HESPERIA_KSI_TAU*` | **YES** — TFP-tuned thresholds |
| **TFP** | B-10 | MySQL `label_ru`, grid ids | **YES** — RU operator path |
| **TFP** | B-11 | `families_structure_tfp.yaml` observability levels | **YES** — ≠ `context_rag.observability` (Felix B-15) |
| **MRT** (IT / FPF) | B-09 | `hesperia_mrt` sibling repo | **YES** — 96-fam grid stays non-cored |
| **COBALT** (attribution) | B-08 | `runtime/cobalt/` when built | **YES** — CHROMA-2 library enhancer, optional provider |
| **COBALT** | B-07 | context_rag `retrieval` layer | **YES** — books/CHROMA-1, not product core |

---

## Frozen / retire (not branches, still Class B)

| Ethan ID | Item | Why stays B / sealed |
|----------|------|----------------------|
| B-01 | Sealed multiscale stack + v060 assets | **Frozen physics** — sealed, not drain |
| B-03 | `sphere/pipeline`, `runtime/pipeline/analyze.py` | Retire path — must not re-enter shipping |
| B-05 | Calibration dict packs / OpenAI calibrate CLIs | Domain-bound assets, governed calibrate |

---

## Agent rule cross-check (§7)

| Rule | Ethan list compliance |
|------|----------------------|
| Branches do not block each other | TFP/COBALT/MRT all B — no core merge required |
| Class B registers at runtime only | B-08/B-09 explicit sibling/scaffold paths |
| No branch corpus inside sealed physics | B-01 sealed separate from B-02/B-07/B-08 |

---

## Finding

No Ethan B-row should be reclassified as Class A. **COBALT-01 ratified** spec aligns with B-08 placement (non-cored, envelope slot only).

---

SIGNED: Research (Colombo) | HSR-V7 Gate B Class B verification | 2026-06-29 | B-05
