# SOPHIA — COBALT-20 security review

**Date:** 2026-06-29

| Check | Status |
|-------|--------|
| Query uses composed text + trace ids only | PASS |
| No operator session replay in packet | PASS |
| Excerpts truncated 1200 chars | PASS |
| Flag off by default | PASS |
| CHROMA-2 read-only client | PASS |

**Residual:** G2 attribution may surface wrong hits — quality not security; gated by G3.

**Verdict:** APPROVED for dev adapter (flag off).

SIGNED: Team (Sophia) | COBALT | 2026-06-29 | COBALT-20
