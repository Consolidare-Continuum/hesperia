# HSR-V7-10 — `/product/interpret` routed API contract (observe | warn | strict)

**Status:** ratified contract (implementation = Felix HSR-V7-D-42..44)  
**Depends on:** HSR-V7-09 `RouterDecision` v0.1, FPF-V7-12 `/product/interpret` baseline  
**Spec anchor:** [governance/SPEC-ETHAN-HESPERIA-V7-SEMANTICS-ROUTER-COMPLIANCE.md](../../../governance/SPEC-ETHAN-HESPERIA-V7-SEMANTICS-ROUTER-COMPLIANCE.md) §Phase E

---

## 1. Endpoint

| Field | Value |
|-------|-------|
| Method | `POST` |
| Path | `/product/interpret` |
| Content-Type | `application/json` |
| Capability gate | `interpret` (existing `public_capability`) |
| Schema id (response) | `hesperia.product_interpret.v0_1` |

Successor to ad-hoc interpret — **governed router surface** with post-LLM audit when `mode=llm`.

---

## 2. Request body

```json
{
  "text": "string (required, 1..10000 chars)",
  "mode": "deterministic | llm",
  "operating_mode": "observe | warn | strict",
  "overlay_hint": { "optional": "object" },
  "temp_relation_overlay": [ "optional advisory overlay objects" ],
  "context_packet": { "optional": "context_rag packet object" }
}
```

| Field | Required | Default | Notes |
|-------|----------|---------|-------|
| `text` | yes | — | Normalized user input; same limits as `/analyze` |
| `mode` | no | `deterministic` | `llm` runs mock/provider narrative + **mandatory** `router_decision` when audit wired |
| `operating_mode` | no | env `HESPERIA_ROUTER_MODE` or `observe` | Governs HTTP surfacing of `RouterDecision` (§4) |
| `overlay_hint` | no | null | HSPR overlay hints (unchanged) |
| `temp_relation_overlay` | no | null | Advisory only; no auto-apply |
| `context_packet` | no | null | Optional `context_rag` augmentation for envelope compiler |

**Validation errors:** `422` with JSON `detail` (FastAPI standard).

---

## 3. Response body (success path)

Always JSON. Core blocks:

| Key | When | Schema |
|-----|------|--------|
| `schema` | always | `hesperia.product_interpret.v0_1` |
| `mode` | always | echoes request `mode` |
| `router_envelope` | always | `hesperia.router_input_envelope.v0_1` |
| `interpretation` | always | deterministic structural summary |
| `llm` | `mode=llm` | provider narrative object |
| `router_output_audit` | `mode=llm` | `hesperia.router_output_audit.v0_1` |
| `router_decision` | `mode=llm` | `hesperia.router_decision.v0_1` |
| `governance` | always (v0.1.1+) | operating-mode surfacing metadata (§4.4) |

`router_decision.decision` ∈ `ALLOW` | `WARN` | `REVIEW_REQUIRED` | `BLOCK`.

---

## 4. Operating modes (`observe` | `warn` | `strict`)

Modes control **surfacing**, not audit computation. Audit always runs for `mode=llm`.

### 4.1 `observe` (default)

| HTTP | Body |
|------|------|
| `200` always (unless rate limit / capability / validation) | Full payload including `router_decision`; no suppression |

**Use:** logging, shadow deploy, operator inspection. Unsafe decisions visible but not enforced.

`governance` block:

```json
{
  "operating_mode": "observe",
  "enforced": false,
  "surfaced_decision": "<RouterDecision.decision>",
  "action": "log_only"
}
```

### 4.2 `warn`

| `router_decision.decision` | HTTP | Body |
|---------------------------|------|------|
| `ALLOW` | `200` | Full payload |
| `WARN` | `200` | Full payload + `governance.warnings` |
| `REVIEW_REQUIRED` | `200` | Full payload + `governance.warnings` (review flag) |
| `BLOCK` | `200` | Full payload + `governance.warnings`; **LLM narrative redacted** (`llm.narrative` → null, `llm.redacted_reason` set) |

**Use:** production with operator visibility; never hard-fail client on BLOCK (narrative stripped).

`governance` example (BLOCK under warn):

```json
{
  "operating_mode": "warn",
  "enforced": true,
  "surfaced_decision": "BLOCK",
  "action": "redact_narrative",
  "warnings": ["ROUTER_DECISION_BLOCK", "MUTATION_ATTEMPT"]
}
```

### 4.3 `strict`

| `router_decision.decision` | HTTP | Body |
|---------------------------|------|------|
| `ALLOW` | `200` | Full payload |
| `WARN` | `200` | Full payload + `governance.warnings` |
| `REVIEW_REQUIRED` | `409` | `{ "schema": "hesperia.router_governance_error.v0_1", "router_decision": {...}, "detail": "review_required" }` — no narrative |
| `BLOCK` | `403` | `{ "schema": "hesperia.router_governance_error.v0_1", "router_decision": {...}, "detail": "blocked" }` — no narrative |

**Use:** compliance-critical deploy; unsafe output never returned as success.

Deterministic mode (`mode=deterministic`): **unaffected** by strict — no LLM audit path; always `200`.

### 4.4 Response headers (all modes)

| Header | Value |
|--------|-------|
| `X-Hesperia-Router-Decision` | `ALLOW` \| `WARN` \| `REVIEW_REQUIRED` \| `BLOCK` \| `N/A` (deterministic) |
| `X-Hesperia-Router-Fingerprint` | envelope fingerprint when present |
| `X-Hesperia-Operating-Mode` | `observe` \| `warn` \| `strict` |

---

## 5. Error catalog

| Status | Condition |
|--------|-----------|
| `403` | Capability disabled; or **strict** + `BLOCK` |
| `409` | **strict** + `REVIEW_REQUIRED` |
| `422` | Validation failure |
| `429` | Rate limit |
| `500` | Internal error (no stack in body) |

---

## 6. Environment defaults

| Variable | Default | Purpose |
|----------|---------|---------|
| `HESPERIA_ROUTER_MODE` | `observe` | Default `operating_mode` when omitted in request |
| `HESPERIA_LLM_PROVIDER` | `mock` | LLM provider for `mode=llm` |
| `HESPERIA_CORPUS_SNAPSHOT_ID` | `corpus-unset` | Envelope corpus id |

---

## 7. Non-goals (v0.1 contract)

- No WebSocket streaming.
- No auto-apply / graph mutation from API.
- No vendor reasoning exposure.
- Gold test matrix (Ava HSR-V7-11) validates decision mapping separately.

---

## 8. Implementation handoff

| Register | Owner | Task |
|----------|-------|------|
| HSR-V7-D-42 | Felix | FastAPI endpoint wiring + `governance` block |
| HSR-V7-D-43 | Felix | `observe` / `warn` / `strict` behavior per §4 |
| HSR-V7-D-44 | Felix | `HESPERIA_ROUTER_MODE` env default |

---

SIGNED: API Contract (Olivia) | hesperia v7 router surface | 2026-06-29 | HSR-V7-10 `/product/interpret` observe|warn|strict
