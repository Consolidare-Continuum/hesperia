# Backend test report — LRP MCP smoke

**LRP-50** · Owner: Olivia · Scope: `get_lan_replication_status`

| # | Test | Method | Expected | Actual | Pass |
|---|------|--------|----------|--------|------|
| 1 | Tool import | `python -m agent_mcp_cluster_snapshot` + call | no import error | OK chroma-venv | ✓ |
| 2 | Registry load | job count | ≥1 | 1 (`chroma-2-backup-librarymaster`) | ✓ |
| 3 | SSH collect | librarymaster last_run | exit 0 JSON | exit 0, bytes>0 | ✓ |
| 4 | stale=false | fresh run | stale: false | stale: false | ✓ |
| 5 | Runbook hint | output line | SCRIPT-RUNBOOK-lan-replication-stale | present | ✓ |

**Status:** READY  
SIGNED: Backend (Olivia) | LRP MCP smoke | 2026-06-20 | get_lan_replication_status
