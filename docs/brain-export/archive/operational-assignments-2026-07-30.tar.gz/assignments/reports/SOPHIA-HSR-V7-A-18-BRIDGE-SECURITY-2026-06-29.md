# Sophia — Bridge attack surface review (HSR-V7-A-18)

**Date:** 2026-06-29  
**Scope:** `sphere/router/thinking_map_bridge.py`, `sphere/calibration/thinking_map.py`, fpf-thinking-map PyPI pin

---

## Surface

| Vector | Risk | Mitigation |
|--------|------|------------|
| PyPI `fpf-thinking-map` supply chain | MED | Pin in `requirements/calibration.txt`; verify hash on promote |
| Map step before LLM | LOW | Read-only evidence collection; no network in map lib |
| Bridge imports | LOW | No `eval`/`exec`; typed `SemanticMap` from library |
| Calibration scripts | MED | OpenAI keys via env only; timeout/retry in `llm_calibration.py` |
| Router bypass | HIGH if broken | `product_interpret_service` enforces envelope path — tested |

## Recommendations

1. Lock fpf-thinking-map version in prod requirements at 0.6.5 promote.
2. No map output written to MySQL without audit row (Gate C).
3. CI: `test_router_governance.py` + calibration tests on every router PR.

**Verdict:** Accept for v7 dev; prod promote requires pin + Abelard secrets hygiene.

---

SIGNED: Security (Sophia) | bridge attack surface | 2026-06-29 | A-18
