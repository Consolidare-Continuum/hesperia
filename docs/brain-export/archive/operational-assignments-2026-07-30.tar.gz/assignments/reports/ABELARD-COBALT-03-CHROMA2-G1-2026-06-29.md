# ABELARD — COBALT Gate G1 (COBALT-03)

**Date:** 2026-06-29  
**Host:** librarymaster · CHROMA-2 `http://chroma-2.prichindel.local:8002`

## G1 verdict: PASS with documented gaps

| Check | Result |
|-------|--------|
| CHROMA-2 heartbeat | OK |
| Collection `documents` count | **1,286,742** chunks |
| Schema | **v1** (`schema_version=1` on sampled chunks) |
| Papra ingest state | **1,148** docs in `processed.json` |
| Reindex run | `ingest_run_id=c3a3f599c001`, `skip_ocr=True`, `turbo=True` |

## OCR / ingest gap list (explicit)

1. **OCR skipped** — `skip_ocr: True` in active ingest profile; scanned PDFs may lack text layers until OCR pass.
2. **Hesperia bounding absent (G2)** — sample 20/20 chunks: `theme=general`, no `concept_id` / `area_name` / `family_name`.
3. **Attribution pipeline** — COBALT-04 required before G3 eval is meaningful; flag stays **off** until G2–G4 pass.

## Operator action (non-blocking for dev adapter)

- Dev `HESPERIA_COBALT_ENABLED=0` default — adapter + mock tests OK.
- Prod `=1` only after `verify-hesperia-cobalt-gates.sh` G1–G4 PASS (COBALT-22..23).

SIGNED: DevOps (Abelard) | COBALT G1 | 2026-06-29 | COBALT-03
