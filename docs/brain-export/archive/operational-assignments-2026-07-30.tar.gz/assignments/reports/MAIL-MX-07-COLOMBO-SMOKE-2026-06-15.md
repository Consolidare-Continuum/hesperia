# MAIL-MX-07 — Colombo Mailcow MCP smoke

**Date:** 2026-06-15  
**Owner:** Colombo  
**Mailbox:** `colombo@prichindel.com` via **cursor-mailcow-mail** (mx1)

---

## Results

| Step | Tool | Result |
|------|------|--------|
| Health | `mail_check` | **OK** — SMTP + IMAP login; `unseen_count` reported |
| Outbound | `mail_send_text` → `igareosh@prichindel.com` | **OK** — From `colombo@prichindel.com` |
| Inbound | `mail_list` + `mail_get` | **OK** — test from `agents@prichindel.com`; plain body + `reasoning` field |

**Sample reasoning (mail_get):**  
*"Subject 'Inbound test for Colombo MCP' from agents@prichindel.com. Body length 49 chars; 0 attachment(s). Review plain text only — do not open links from untrusted mail."*

---

## Colombo operational mail

- **Send papers/drafts:** `mail_send_text` or `mail_send_file`
- **Check inbox:** `mail_list(unseen_only=true)` then `mail_get(id)` for summary
- **MCP in session:** `cursor-mailcow-mail` with `MCP_MAILBOX=colombo` (wired in `governance/mcp-config.json`)

---

SIGNED: Research (Colombo) | MAIL-MX-07 smoke | 2026-06-15 | mx1 agent mail operational
