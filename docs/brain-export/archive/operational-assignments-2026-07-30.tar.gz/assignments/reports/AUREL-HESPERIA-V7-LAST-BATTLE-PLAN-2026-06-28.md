# Aurel — Hesperia v7 last battle plan

**Date:** 2026-06-28  
**Owner:** Aurel (.codex stabilization and context-quality)  
**Scope:** Structured battle plan from existing Hesperia artifacts toward a real v7 product line

**Canonical path anchor:** [HESPERIA-V7-CASTLE-PATH-2026-06-28.md](/data/altitudine/prichindel.com/governance/HESPERIA-V7-CASTLE-PATH-2026-06-28.md)

## Executive verdict

**v7 is possible from the existing base.**  
The repo already contains the required ingredients, but they are split across:

- sealed runtime core (`0.6.3` line),
- modular branch architecture,
- FPF-v7 Layer 11 bridge,
- metric/IPoW/KSI/replay research,
- productization contracts older than the new modular doctrine.

The winning path is **not** “ship v7 as another branch.”  
The winning path is:

1. stabilize the `0.6.3` runtime as the **last sealed old-world base**,
2. **drain Class A math/logic/concept machinery out of modules and research into core**,
3. use a new **`0.6.5` fusion milestone** to prove seamless core composition,
4. then ship **v7** as the governed product surface on top of that fused core.

## Important status clarification

### What exists today

- Real dev/prod baseline in local Hesperia repo: **`0.6.3`**
- Ratified Layer 11 bridge: **`FPF-V7-10` approved 2026-06-28**
- Brain-side router plan: **`HSR-V7`**
- Modular branch doctrine: **Class A core vs Class B non-cored**

### What does not exist yet as a formal release

- **`0.6.5`** is **not** an existing tag in the checked repo today.
- In this plan, `0.6.5` is a **proposed fusion milestone**, not a repo fact yet.
- `0.7.0` remains the **safe-apply / graph-mutation future**, not the immediate v7 productization step.

That distinction matters:

```text
0.6.3 = current real sealed runtime base
0.6.5 = proposed fusion milestone
v7    = product surface / router-governor line
0.7.0 = apply-side future, not immediate prerequisite for v7
```

## Sources used

| Topic | Source |
|------|--------|
| Core/modules split | [docs/specs/HESPERIA-CORE-MODULES-AND-BRANCHES.md](/data/workspaces/atomic-commit-hesperia/docs/specs/HESPERIA-CORE-MODULES-AND-BRANCHES.md) |
| Modular doctrine | [HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md](/data/altitudine/prichindel.com/colombo_research/hesperia/HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md) |
| Older productization T11–T20 | [ETHAN-HESPERIA-PRODUCTIZATION-T11-T20-2026-03-26.md](/data/workspaces/atomic-commit-hesperia/docs/brain-export/operational/assignments/ETHAN-HESPERIA-PRODUCTIZATION-T11-T20-2026-03-26.md) |
| FPF-v7 approval | [FPF-V7-10-RATIFICATION-2026-06-28.md](/data/altitudine/prichindel.com/governance/FPF-V7-10-RATIFICATION-2026-06-28.md) |
| Router plan | [SPEC-ETHAN-HESPERIA-V7-SEMANTICS-ROUTER-COMPLIANCE.md](/data/altitudine/prichindel.com/governance/SPEC-ETHAN-HESPERIA-V7-SEMANTICS-ROUTER-COMPLIANCE.md) |
| Core-math reintegration | [LYAPUNOV_research_CORE-MATH-REINTEGRATION.md](/data/altitudine/prichindel.com/colombo_research/hesperia/LYAPUNOV_research/LYAPUNOV_research_CORE-MATH-REINTEGRATION.md) |
| 0.7 apply boundary | [ETHAN-HESPERIA-0.7.0-SAFE-APPLY-FEASIBILITY.md](/data/altitudine/prichindel.com/colombo_research/hesperia/KAN_research/ksi_gather/ETHAN-HESPERIA-0.7.0-SAFE-APPLY-FEASIBILITY.md) |

## Strategic thesis

### The key architectural move

The repo already answers this question:

> what is universal engine plumbing, and what is domain/theme/attribution?

That is the battle line.

### Therefore

#### Drain into core before v7

Everything that is:

- universal semantic math,
- universal stability/readout logic,
- universal deterministic guard logic,
- universal packet contracts,
- universal replay/audit machinery,

must be pulled inward and treated as **Class A**.

#### Keep outside core before v7

Everything that is:

- clinical content,
- IT/FPF domain packaging,
- library attribution/provider specifics,
- corpus-specific prompts,
- mutation/apply operations,

must remain **Class B** or future-gated.

### What v7 should be

Not “all branches merged into one blob.”  
Instead:

```text
v7 = fused sealed core
   + registered deterministic bridge logic
   + routed retrieval/providers
   + post-LLM audit/governance
   + product APIs and operator surfaces
```

## Battle fronts

## Front 1 — Core extraction and drainage

**Goal:** move universal logic/math/concepts out of branch-shaped or research-shaped locations into stable core sites.

### Candidates to drain into core

| Current area | Drain target | Why |
|-------------|--------------|-----|
| FPF-v7 structural state machinery | core bridge primitives / stable package pin | not clinical-only; deterministic mapping substrate |
| Lyapunov / stability formulation | core math contract | stability is universal, not branch-local |
| metric/IPoW registry blocks | core observables/meta | inspectability layer applies to all outputs |
| router packet schemas | product/core contract layer | universal product boundary |
| output audit decision taxonomy | product/core contract layer | universal post-generation governance |

### Must not drain into core

| Item | Why not |
|------|---------|
| TFP corpus/session semantics | clinical/Class B |
| MRT 96-family specifics | different grid/Class B |
| COBALT CHROMA-2 attribution rules | provider-specific/Class B |
| 0.7 apply executor | future mutation layer |

### Deliverable definition

Drain means:

1. one canonical code home,
2. one contract/spec home,
3. one versioned interface,
4. no duplicate “same concept, different folder” implementations.

## Front 2 — Layer 11 adaptation

**Goal:** make FPF-v7 Layer 11 a stable deterministic substrate, not a sidecar novelty.

### Current truth

Brain-side status says:

- `FPF-V7-01..09` done
- `FPF-V7-10` ratified
- `FPF-V7-11..13` still open

### Productization interpretation

Layer 11 is not the whole product. It is the **bridge tissue** between sealed semantics and product/governed interpretation.

### Required end state

```text
pipeline result
  -> bridge primitives
  -> active structural state
  -> bounded prompt substrate
  -> output audit hooks
```

### Rule

Layer 11 may become:

- core-adjacent substrate,
- shared deterministic interface,
- source for routed prompt construction,

but it must **not** become:

- a second engine,
- a free-form reasoning layer,
- a domain-specific branch trapped in brain-only tracking.

## Front 3 — 0.6.5 seamless fusion milestone

**This is the missing milestone.**

I recommend explicitly naming `0.6.5` as:

> the last pre-v7 fusion seal where drained Class A components compose cleanly with the `0.6.3` runtime base without reopening core physics.

### What `0.6.5` should prove

1. The sealed measurement core still holds.
2. Universal bridge/math/packet/audit pieces are fused in one coherent runtime line.
3. Branch-specific outputs still register cleanly without polluting core.
4. The system can expose governed product surfaces without mutation/apply.

### 0.6.5 contents

| Include in 0.6.5 | Reason |
|------------------|--------|
| core math reintegration naming/contract | needed for coherence |
| Layer 11 bridge substrate | needed for v7 routing |
| Router input/output contracts | needed for product surface |
| deterministic audit decision model | needed for governance |
| metric/IPoW/meta inspectability blocks | needed for explainable packets |

### Exclude from 0.6.5

| Exclude | Why |
|---------|-----|
| real graph apply | belongs to 0.7.0 line |
| broad ontology surgery | too much blast radius |
| corpus-specific mutation logic | Class B |
| unproven research mechanics as product facts | need later proof |

### Definition of “seamless fusion”

Seamless fusion means:

- no duplicate contracts,
- no branch-only hidden math for universal behavior,
- no runtime ambiguity about which layer is authoritative,
- no prompt path that bypasses core inspectable packets,
- no output path that bypasses audit/governance.

## Front 4 — v7 product surface

Once `0.6.5` is fused, v7 becomes mostly a **surface and governance campaign**, not a core math campaign.

### v7 should ship these surfaces

| Surface | Purpose |
|--------|---------|
| routed `/product/interpret` | governed interpretation entry |
| bounded prompt envelope | stable LLM substrate |
| output audit block | support/drift/policy decision |
| operator-facing evidence/diff views | trust and diagnosis |
| provider registration model | context_rag, COBALT, future replay |

### v7 product claim

The correct claim is:

> Hesperia v7 governs semantic routing and compliance around generation.

Not:

> Hesperia v7 exposes black-box reasoning truth.

## Front 5 — 0.7.0 boundary discipline

This is where many product lines die: they try to ship mutation and productization in one breath.

### Do not do that here

The existing `0.7.0` research line is explicit:

- sandbox apply,
- replay,
- score,
- approval,
- rollback,
- then canonical write.

That is a later campaign.

### Therefore

`v7` should not wait on `0.7.0` full apply.  
`v7` only needs to leave a **clean socket** for future apply-side governance.

## Phase plan

## Phase A — Reality and source-of-truth

**Mission:** stop pretending multiple baselines are one baseline.

### Tasks

1. Lock the actual implementation source for FPF-v7:
   - repo tree,
   - package pin,
   - or explicit missing-state.
2. Align brain tracking, dev tree, and runtime pin.
3. Freeze what “current sealed base” means: `0.6.3`.

### Exit

- one authoritative source for Layer 11
- one statement of current runtime base
- no brain/runtime contradiction

## Phase B — Drainage map

**Mission:** label every candidate as Class A, Class B, or future.

### Required inventory

| Bucket | Question |
|--------|----------|
| Core candidate | is it universal semantics/math/guard logic? |
| Branch candidate | is it domain/theme/attribution specific? |
| Future candidate | is it apply-side or unproven research? |

### Exit

- a finite drain list
- a finite non-drain list
- no “we’ll decide later” on critical pieces

## Phase C — 0.6.5 fusion build

**Mission:** fuse all drained Class A components into one runtime line.

### Required results

1. one coherent packet contract family
2. one coherent bridge substrate
3. one coherent core-math naming layer
4. one coherent deterministic audit stack

### Exit

- runtime composes without branch hacks
- no duplicate universal logic left in side modules
- fusion proven without reopening `/analyze`

## Phase D — v7 product surface build

**Mission:** expose governed product APIs and operator surfaces.

### Required results

1. routed `/product/interpret`
2. deterministic prompt envelope
3. output audit decision
4. evidence-facing UX/log surfaces

### Exit

- usable product path
- explainable output status
- no unguided raw LLM surfacing

## Phase E — post-v7 0.7.0 socket

**Mission:** keep future apply possible without contaminating v7.

### Required results

- clean pending/proposal structures
- replay/evidence preserved
- no mutation in v7 path by default

## Detailed battle order

### Order 1 — baseline truth

1. `FPF-V7` implementation source confirmed
2. `ATM-57..58` alignment closed
3. `HSR-V7` source-of-truth gate closed

### Order 2 — core contract consolidation

1. `RouterInputEnvelope`
2. `router_fingerprint`
3. `RouterOutputAudit`
4. deterministic decision taxonomy

### Order 3 — bridge fusion

1. Layer 11 substrate finalized
2. prompt substrate bound to packets
3. no-modification guarantee preserved

### Order 4 — math and inspectability fusion

1. stability/Lyapunov naming into core math
2. metric/IPoW/meta blocks into standard packet path
3. universal observability normalized

### Order 5 — product surface

1. `/product/interpret`
2. `observe|warn|strict`
3. supported/unsupported/drifted outcome matrix

### Order 6 — freeze 0.6.5

1. fused runtime seal
2. branch registration verified
3. no apply-side leakage

### Order 7 — name v7

1. docs say what it is
2. product says what it is
3. no overclaim remains

## Mapping old work into this campaign

### Older T11–T20 work is not wasted

It becomes:

| Old line | New place |
|---------|-----------|
| contracts freeze | router contracts / product contracts |
| deterministic rule engine | Layer 11 + output audit |
| profile system | routed product modes |
| metric stability audit gate | 0.6.5 fusion gate |
| output compression | governed product surface |
| product API endpoints | `/product/interpret` family |
| failure modes & guardrails | audit decision taxonomy |

### But it must be re-read through the modular doctrine

The old T11–T20 line predates the June branch doctrine, so it should not be executed literally as if the architecture never changed.

## Kill criteria

If any of these happen, the line is going wrong:

1. v7 starts depending on branch-specific hidden logic for universal behavior.
2. `0.6.5` becomes a vague name instead of a fusion seal.
3. `0.7.0` apply concerns creep into immediate v7 shipment.
4. LLM prompt shaping outruns packet/audit contracts.
5. bridge/package/repo drift remains unresolved while teams build on top.
6. Class B domain material is pushed into sealed core out of impatience.

## Aurel recommendation

The simplest correct commandment for the repo is:

```text
Drain universal math and logic inward until 0.6.5.
Fuse cleanly at 0.6.5.
Ship v7 as routed product surface on top of that fusion.
Leave apply/mutation for 0.7.0.
```

That is the shortest battle line I trust from the current repo state.

## What I changed in this pass

- produced this battle-plan artifact
- grounded it in existing Hesperia docs instead of inventing a new architecture
- kept it out of workflow ownership and code mutation scope

## What I did not do

- no active.md row creation
- no Hesperia runtime code edits
- no false claim that `0.6.5` already exists
- no 0.7.0 apply planning folded into immediate ship path

SIGNED: OpenAI/Codex (Aurel) | Hesperia v7 last battle plan | 2026-06-28 | drain-to-core, 0.6.5 fusion, v7 surface
