# Compliance sign-off — Olga Colombo thinking-map MCP (permanent /home/olga)

**Date:** 2026-07-18  
**Scope:** `igareosh/olga` @ `3d5f255` · altitudine `/home/olga/olga-work` · Cursor from **olgahere** via Remote-SSH  
**Authority:** Cursor (repo) compliance + Abelard path verify

---

## Verdict

**COMPLIANT — signed.** Productized MCP is permanent for user `olga`. Restart of Cursor on that folder (from olgahere) loads MCP correctly.

---

## Evidence (live 2026-07-18)

### A. Host deploy (altitudine / `olga`)

| Check | Result |
|-------|--------|
| Tip | `3d5f255` Productize olga-colombo-thinking-map |
| `~/.cursor/mcp.json` | 14 servers; `olga-colombo-thinking-map` + `colombo-library` |
| Project `.cursor/mcp.json` | Absolute launcher `/home/olga/olga-work/scripts/agent-mcp-olga-thinking-map.sh` |
| `bash scripts/olga-mcp-selfcheck.sh` | **SELFCHECK PASS** (6/6) |
| `bash scripts/deploy-olga-mcp.sh` | Deploys user+project mcp; clears bytecode; respawns MCP |

### B. olgahere → altitudine session path (Cursor restart path)

From **olgahere** (`OLGA_HERE` / user Olga) → `ssh altitudine` → user **`olga`**:

| Check | Result |
|-------|--------|
| Agent cert files | `id_agent` + `id_agent-cert.pub` present |
| Land | `olga` @ `altitudine.prichindel.local` |
| USER_MCP / PROJECT_MCP | OK |
| Map + colombo in mcp.json | True |
| `bash scripts/olga-ide-preflight.sh` | **PREFLIGHT PASS** (step 6 = real selfcheck hard-fail) |

### C. Productization compliance

| Artifact | Status |
|----------|--------|
| `olga-mcp-selfcheck.sh` | Real gates (not import-only) |
| `olga-thinking-map-python-env.sh` | Single env source for launcher + selfcheck |
| Deploy self-restart | Verified in productize; kill+respawn on code change |
| Rules tool-first | `clinical_locate_step` before science draft |
| No team_ops leakage | Selfcheck asserts Olga-only map surface |
| CHROMA-2 in-MCP | `clinical_locate_step` / `library_search` |

---

## Cursor restart procedure (olgahere)

1. On **olgahere**: Cursor → Remote-SSH → Host **`altitudine`** (User **`olga`**).
2. Open folder **`/home/olga/olga-work`** only (not brain `/data/altitudine/prichindel.com`).
3. Optional once after pull: `bash scripts/olga-ide-preflight.sh` → expect **PREFLIGHT PASS**.
4. Fully quit/reopen Cursor Remote window if MCP list missing `olga-colombo-thinking-map`.
5. Smoke: ask a ТФП science question — Colombo must call **`clinical_locate_step`** (not raw model).

If SSH/cert fails: desktop `verify-altitudine-ssh.ps1` → [ALTITUDINE-SSH-HANDOFF.md](../../../cluster/olgahere/ALTITUDINE-SSH-HANDOFF.md).

---

## Signatures

```
SIGNED: Compliance (Cursor) | Olga ATM MCP permanent deploy | 2026-07-18 | olgahere Remote-SSH path PREFLIGHT PASS
SIGNED: DevOps path verify (Abelard context) | olgahere→altitudine olga mcp | 2026-07-18 | USER_MCP+selfcheck
```

Refs: [OLGA-ATM-PRODUCTIZE-2026-07-18.md](OLGA-ATM-PRODUCTIZE-2026-07-18.md) · [ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md](../ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md) · [OLGA-COLOMBO-WORKSPACE.md](../../../cluster/olgahere/OLGA-COLOMBO-WORKSPACE.md)
