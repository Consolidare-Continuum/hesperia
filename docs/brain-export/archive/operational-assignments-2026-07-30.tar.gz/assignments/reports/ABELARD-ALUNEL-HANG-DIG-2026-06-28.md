# Abelard — alunel hang dig report (operational)

**Date:** 2026-06-28 09:15 EEST  
**Session:** execution_host=altitudine, role=dev_vm_ulim, dev_office=true, connectivity=lan  
**Investigator:** Abelard (DevOps)  
**Trigger:** Operator report — alunel hang

---

## Executive summary

**alunel hard-froze overnight** with the **known w83795 I2C death-spiral signature** (same class as 2026-06-20). Last journal line on the previous boot: **2026-06-28 04:17:22 EEST**. Operator **power-cycled** the host; clean boot at **09:09–09:10 EEST**. **All 10 production VMs are running** post-recovery; cluster SSH/API paths from altitudine are **OPEN**.

**Critical gap:** `alunel-distress-watch` **detected** the failure at 04:17:27 but **Tersagor last-words alert FAILED** (`Host key verification failed` on notify path). Operator received **no automated warning** before freeze.

---

## Timeline

| Time (EEST) | Event |
|-------------|-------|
| 2026-06-23 14:57 | Previous boot start (uptime base until today) |
| 2026-06-24 09:01 | First w83795 I2C err -6 burst (32 lines) — host survived |
| 2026-06-24 11:47–11:50 | Larger w83795 bursts (32–68 lines/min) — host survived |
| 2026-06-28 04:17:20–22 | **Fatal w83795 I2C death spiral** — kernel log ends here |
| 2026-06-28 04:17:26 | `alunel-distress-watch.service` starts (timer-fired) |
| 2026-06-28 04:17:27 | Distress notify **FAILED**: `Host key verification failed` / `Tersagor FAILED: I2C hardware monitor bus dying (w83795)` |
| 2026-06-28 04:17 → 09:09 | **~5 h silent gap** — host unresponsive (no clean shutdown in journal) |
| 2026-06-28 09:09–09:10 | Operator power cycle; kernel boot 09:10:04 |
| 2026-06-28 09:15 | Dig pass — SSH OK, VMs up, services active |

**Prior crash markers** (`last reboot`): Jun 22 (×3), Jun 23 — all tagged **crash** (not clean shutdown).

---

## Root cause (assessment)

| Layer | Finding |
|-------|---------|
| **Primary** | **Hardware power/I2C bus instability** on Supermicro **X8DT3-F** — w83795ADG monitor chip loses I2C (`err -6`) in bursts → precedes **hard host freeze** (no panic/oops logged) |
| **Signature** | 914 w83795 failure lines across prev boot; recurring episodes Jun 24, fatal episode Jun 28 04:17 |
| **Not** | Kernel panic, OOM, disk full, failed systemd units, or Proxmox software fault |
| **Recovery** | Manual power cycle only (inline stabilizer does not log these events) |

Ref pattern: `cluster/alunel/scripts/alunel-distress-watch.sh` (2026-06-20 signature), `cluster/alunel/FANS-W83795.md` (fan chip — separate closed issue; do not touch pwm).

---

## Post-recovery state (2026-06-28 09:15 EEST)

### Host

| Check | Result |
|-------|--------|
| Uptime | ~5 min at first probe; boot 09:10:04 |
| Load | 8.75 (post-boot VM storm — expected, decaying) |
| RAM | 46G / 173G used |
| Disk `/` | 19% · `/data` 65% · `/data_prod` 14% |
| Failed units | **0** |
| w83795 (current boot) | Clean probe; guard OK 09:13:08 |
| Sensors | CPU 55–59°C; jc42 75–80°C; w83795 in spec |
| IPMI SEL (local + LAN .115) | Empty on query (no fresh voltage-low asserts captured) |

### VMs (`qm list`)

| VMID | Name | Status |
|------|------|--------|
| 100 | chronomaster | running |
| 101 | mediamaster | running |
| 102 | altitudine | running |
| 103 | librarymaster | running |
| 104 | trustmaster | running |
| 105 | tersagor | running |
| 106 | dnsmaster | running |
| 107 | prichindel | running |
| 108 | mx1 | running |
| 109 | mx2 | stopped (expected) |
| 110 | cloudmaster | running |

### Services

| Service | Status |
|---------|--------|
| nginx | active |
| tailscaled | active |
| pveproxy | active |
| chroma-1-query-api | active |
| Proxmox UI :8006 | HTTP 200 |
| alunel.prichindel.com | HTTP 200 |
| CHROMA-1 `:8002` heartbeat | HTTP 200 (v0.6.3) |

### Cluster reachability (from altitudine)

prichindel · dnsmaster · librarymaster · trustmaster · chroma-1 — **SSH 22 OPEN**

---

## Defects found (operational)

### 1. Distress notify broken on alunel (P1)

At 04:17:27, watch correctly fired on w83795 burst but notify failed:

```
alunel-distress-watch.sh: Host key verification failed.
Tersagor FAILED: I2C hardware monitor bus dying (w83795)
```

**Cause:** `scripts/cluster/tersagor-operator-notify.sh` defaults `TERSAGOR_NOTIFY_SSH=alunel`. When the watch runs **on alunel**, `get_token()` does `ssh alunel → ssh prichindel` (self-hop + key check) instead of direct LAN curl to tersagor `:18090` or `ssh prichindel` locally.

**Fix (Abelard):** On alunel, set `TERSAGOR_NOTIFY_SSH=127.0.0.1` or skip SSH hop in distress path; bake token at `/root/.secrets/` for last-words; add `known_hosts` for tersagor/prichindel on alunel if SSH remains required. Test: `ALUNEL_DISTRESS_DRY_RUN=1` burst simulation.

### 2. Missing incident doc (P2)

`cluster/alunel/scripts/alunel-distress-notify.sh` references **`cluster/alunel/ALUNEL-POWER-HANG-2026-06-20.md`** — **file not in repo**. Commit canonical incident write-up (2026-06-20 + this 2026-06-28 recurrence).

---

## Recommendations

| Priority | Action | Owner |
|----------|--------|-------|
| **P0** | Fix distress notify path for **local-on-alunel** execution; smoke test from alunel | Abelard | **DONE** 2026-06-28 — `deploy-alunel-power-evidence.sh`; token baked; direct curl verified |
| **P1** | Commit `ALUNEL-POWER-HANG-2026-06-20.md` + append 2026-06-28 recurrence | Abelard | **DONE** 2026-06-28 — grid-cascade section |
| **P1** | BMC SEL archive timer (5 min) + optional UPS note | Abelard | **DONE** 2026-06-28 — `alunel-ipmi-sel-archive` |
| **P2** | Hardware track: recurring w83795/I2C freezes on X8DT3-F — PSU caps, board reseat, BMC firmware, inline stabilizer effectiveness | Operator + Abelard |
| **P2** | **Grace triage:** row for distress-notify fix + incident doc | Abelard → Grace |

**Do not:** touch W83795 pwm/fan registers (`cluster/alunel/FANS-W83795.md` — CLOSED SOLVED).

---

## Evidence commands (replay)

```bash
ssh alunel 'uptime; last reboot | head -5'
ssh alunel 'sudo qm list'
ssh alunel 'sudo journalctl -b -1 --no-pager | grep w83795 | tail -20'
ssh alunel 'sudo journalctl -b -1 -u alunel-distress-watch.service --no-pager | tail -10'
```

---

SIGNED: DevOps (Abelard) | cluster context | 2026-06-28 | alunel hang dig — operational
