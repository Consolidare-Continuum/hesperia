# Operator acceptance — pre-0.7 READY without UI

**Date:** 2026-07-19  
**Owner:** Emma (Acceptance)  
**Rows:** FPF-MWI-23 · FPF-PRE07-18  
**Exit family:** PRE07-G1..G5 · [ETHAN-FPF-PRE07-PRESEAL-20-2026-07-19.md](../ETHAN-FPF-PRE07-PRESEAL-20-2026-07-19.md)

---

## Scope

Accept **pre-0.7 wire complete** — agents roll Hesperia via HAND **without any product UI**. Seal (HSR-V7-X-*) stays held.

---

## Checklist (operator / Emma sign)

### A. MCP faces (PRE07-G1)

```
[ ] hesperia-fpf-inspect MCP live on altitudine Cursor session
[ ] hesperia-router MCP live on altitudine (MWI-01)
[ ] brain governance/mcp-config.json + .mcp.json match deploy script output
[ ] HESPERIA_REPO_ROOT=/data/workspaces/atomic-commit-hesperia verified (Abelard PRE07-15)
```

### B. Gold HAND loops (PRE07-G2)

```
[ ] hesperia_ops: thinking_map_step → hesperia_router_inquire → ground_truth (three blocks)
[ ] hesperia_inspect: map step → climb/GapReport → re-step
[ ] Same synthetic gold string for both loops (Felix PRE07-02/03 or MWI-02)
[ ] Agent does not author logical/weight/source_activation
```

### C. Security (PRE07-G3)

```
[ ] Sophia+Daniel memo APPROVED — synthetic/dev only
[ ] No HESPERIA_MCP_BRIDGE_REAL_DATA=1
[ ] No clinical/TFP corpus text in MCP invokes during acceptance run
```

### D. Docs + runbook

```
[ ] Colombo glossary frozen (PRE07-13)
[ ] Marcus HAND runbook present (SCRIPT-RUNBOOK-hesperia-fpf-hand-agent-roll)
[ ] Liam dev deploy checklist complete (PRE07-16) — not prod
```

### E. Observability

```
[ ] Noah MWI-22 log fields used — no PII in dig/inquire traces
[ ] Failures surface outcome_kind + blockers, not raw input
```

### F. Explicit exclusions (must remain true)

```
[ ] HSR-V7-X-* still PAUSED
[ ] No prod seal tag bump
[ ] No external clinical caller enabled
[ ] No human product UI required for this READY stamp
```

---

## Verdict block

| Field | Value |
|-------|-------|
| **pre-0.7 READY (no UI)** | `[ ] ACCEPT` / `[ ] REJECT` |
| **Reject reason** | _(required if REJECT)_ |
| **Date** | |
| **Operator witness** | igareosh optional |

**Grace PRE07-19:** Stamp register only when all A–F checked and PRE07-G4 checklist frozen (Ethan PRE07-10).

---

## Minimal smoke (no UI)

1. Open Cursor on altitudine brain repo.  
2. Run ops loop per runbook §3 on synthetic gold.  
3. Trigger dig loop per runbook §4 on same gold.  
4. Confirm IDLE or documented escalate — not UI navigation.

---

`SIGNED: Acceptance (Emma) | pre-0.7 READY without UI | 2026-07-19 | MWI-23 PRE07-18 checklist`
