# METRIC-28 — Test matrix: `area_sphere` geodesic + `path_action`

**Owner:** Ava · **Date:** 2026-06-23 · **Status:** DONE

| # | Case | Input | Expected | Owner |
|---|------|-------|----------|-------|
| 1 | Same area, zero hop | `path_edges=[]` | `path_metric_cost=0` | Felix pytest |
| 2 | Area crossing GOOD→HARM | 2 TRAVERSAL events | `area_sphere` in layers, cost > 0 | tersagor `test_traversal_payload_path_metric` |
| 3 | Geodesic emit off | `HESPERIA_GCS_EMIT=0` | no `geodesic_sphere` key | `test_geodesic_sphere_absent` |
| 4 | Geodesic emit on | `HESPERIA_GCS_EMIT=1` | `hex_face_count=72240`, `anchor_map_id` | `test_geodesic_sphere_present` |
| 5 | Area sphere edge | `geodesic_distance` 0.5 + 1.2 | cost = 1.7, layers `["area_sphere"]` | `test_compute_s_path_area_sphere` |
| 6 | Mixed layers | area + hex edges | cost = 1.3, both layers listed | `test_compute_s_path_mixed` |
| 7 | Fingerprint stable | two `build_hesperia_metric_block()` | same `coordinate_fingerprint` | `test_hesperia_metric_emit_block_fingerprint_stable` |
| 8 | Anchor frozen | `schemas/anchor_map_v1.json` | `status=FROZEN`, id `anchor_map_v1` | `test_anchor_map_v1_frozen_registry` |

**Automation:** `pytest tests/test_metric_22_26.py tests/test_anchor_map_reconcile.py` on hesperia dev; tersagor `TestSurfaceEventBatch`.

**SIGNED: QA (Ava) | METRIC-28 test matrix | 2026-06-23**
