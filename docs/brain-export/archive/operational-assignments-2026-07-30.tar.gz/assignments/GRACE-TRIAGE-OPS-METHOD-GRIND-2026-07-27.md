# Grace triage — ops-method post-ingestion grind (after SERIES-CORPUS-READY)

**Date:** 2026-07-27 · **Owner:** Grace  
**Trigger:** AWP drain closed Day7–10; Ethan [SERIES-CORPUS-READY.md](../../projects/ops-method/SERIES-CORPUS-READY.md) signed  
**Upstream pattern:** P3-CLOSE-01..03 · Day7+ triage “after ingestion — grinding”

## Product intake (locked)

1. Full-density cross-pack propose across live packs (triad + PAY + overlays).  
2. EX harvest expansion on FTB / Poels / PLX overlays (sparse; no STEP promote).  
3. Ava full N-hop QA / regression smoke.  
4. Ethan corpus closeout succeeding P3-FOUR-PACK-READY (grind READY, not re-ingestion).

## Rows

| ID | Owner | Task |
|----|-------|------|
| **OPS-METHOD-GRIND-00** | Grace | This triage |
| **OPS-METHOD-GRIND-01** | Felix | Densify remaining ORDER/STRAT/PAY + overlay emb; full-density cross-pack propose pass (sample caps OK) |
| **OPS-METHOD-GRIND-02** | Colombo | RU review new pending families from GRIND-01 |
| **OPS-METHOD-GRIND-03** | Felix | EX harvest expansion on FTB/Poels/PLX (facet-tagged; no STEP promote) |
| **OPS-METHOD-GRIND-04** | Ava | N-hop QA + ED01 regression smoke after grind |
| **OPS-METHOD-GRIND-05** | Ethan | Sign **GRIND-CORPUS-READY** (closeout after P3-FOUR-PACK-READY) |

**Triage outcome:** PROJECT-CREATED — grinding rows on active.md.

SIGNED: Triage (Grace) | post-ingestion grind wave | 2026-07-27 | ops-method
