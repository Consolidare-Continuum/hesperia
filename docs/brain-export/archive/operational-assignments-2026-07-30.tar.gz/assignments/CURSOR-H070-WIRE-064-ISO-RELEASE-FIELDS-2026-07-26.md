# Hesperia ISO release-notice field template (WIRE-064)

**Date:** 2026-07-26  
**Owner:** Ethan / Cursor  
**Baseline:** [HESPERIA-ISO-PRODUCTIZATION-BASELINE.md](../../governance/HESPERIA-ISO-PRODUCTIZATION-BASELINE.md)  
**Generic template:** [foundational/templates/RELEASE-NOTICE.md](../../foundational/templates/RELEASE-NOTICE.md)

Use this block on every Hesperia promote / seal note (alignment ≠ certification).

```markdown
## Hesperia release — ISO evidence package

- **system_version / tag**: e.g. `0.7.0` / `v0.7.0`
- **Seal commit**: full SHA
- **Phase frame**: freeze · grind · awareness (cite HESPERIA-POST-070-PHASE-FRAME)
- **Identity**: multipurpose engine — not clinical/LLM (cite ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY)

### Evidence links (required)

| Field | Fill with |
|-------|-----------|
| Acceptance / DoD | active.md task IDs or seal castle report |
| Test evidence | pytest paths + sealed-runtime-gate Actions URL |
| Security | shipping allowlist audit + import boundary (or N/A) |
| Remote integrity | `scripts/hesperia/verify-hesperia-git-remotes.sh` OK |
| Soak / quality (optional grind) | p50/p95 interpret note from wire ledger |
| Rollback | previous tag + Atomic commit |

### Do not claim

- ISO certification
- New version identity without Ethan+operator seal protocol
```

SIGNED: Cursor · Ethan | H070-WIRE-064 | 2026-07-26 | ISO release fields
