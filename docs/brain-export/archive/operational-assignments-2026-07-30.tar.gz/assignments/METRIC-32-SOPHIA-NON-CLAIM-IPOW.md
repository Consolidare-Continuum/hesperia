# METRIC-32 — Non-claim policy: IPoW / GCS distances

**Owner:** Sophia · **Date:** 2026-06-23 · **Status:** DONE

## Policy

1. **`metric_layer=ipow_volume`** and **`gcs_surface`** distances are **geometric bookkeeping** on the Hesperia semantic engine — **not** clinical scores, diagnostic labels, or therapist competence metrics.
2. **PointZero** (`powv_point_zero=true`) is a **reference stance** for iteration geometry — not a patient baseline or pathology indicator.
3. **`I²_n`** (iteration interval) is an **audit scalar** for sealed `SurfaceEventBatch` steps — not physical proper time or Minkowski interval.
4. Marketing, ULIM capitol, and operator-facing copy **SHALL** include: *“Semantic geometry only — not medical measurement.”*

## Applies to

- `meta.interior_point_of_world_view`
- `meta.hesperia_metric.geodesic_sphere`
- Academia narration §3.5a
- Colombo `physics_cosmology` explainers (pedagogy ≠ product physics)

**Ref:** [SPEC-ETHAN-HESPERIA-MINKOWSKI-IPOW-ITERATIONS.md](../../governance/SPEC-ETHAN-HESPERIA-MINKOWSKI-IPOW-ITERATIONS.md) §0 non-claim · [24_SPEC §14](../../user_documents/HESPERIA_ACADEMIA/24_SPEC__Hesperia_Metric_and_Distance_v0_1.md)

**SIGNED: Risk (Sophia) | METRIC-32 non-claim | 2026-06-23**
