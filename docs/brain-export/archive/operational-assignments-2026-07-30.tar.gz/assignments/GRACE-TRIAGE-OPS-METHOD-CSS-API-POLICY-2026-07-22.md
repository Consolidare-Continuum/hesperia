# Grace triage — ops-method CSS API policy (no DB-wide before CSS)

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01  
**Trigger:** Operator accepted Ethan steer — do **not** run OpenAI DB-wide actionable surfacing before Canonical Step Surface.  
**Parent wave:** [GRACE-TRIAGE-OPS-METHOD-CSS-2026-07-22.md](GRACE-TRIAGE-OPS-METHOD-CSS-2026-07-22.md)  
**Ethan decision (chat 2026-07-22):** promote STEPs from live PG fields first; OpenAI only as **gap-fill after CSS-09 smoke** (or documented attachment gap).

## Policy (binding for CSS-01..12)

| Rule | Binding |
|------|---------|
| **No** DB-wide OpenAI re-classify / re-surface actionables before CSS promotion + smoke | HARD |
| CSS-02/03/05/06 use existing `process_candidate`, form, action_orientation, modality, edges | HARD |
| OpenAI allowed only when CSS-09 (or CSS-05) documents a **concrete gap** (missed STEPs, empty attachments, thin action/state/runbook) | HARD |
| Optional local 50-row precision sample — no API | ALLOWED anytime |
| MAP-05 / CORP-04 / CORP-05 | stay **PAUSED** |

## Rows

| ID | Owner | P | Status | Deliverable |
|----|-------|---|--------|-------------|
| **OPS-METHOD-CSS-00b** | Grace | P0 | DONE | This triage + lock policy onto board / design lock |
| **OPS-METHOD-CSS-01** | Ethan | P0 | OPEN | Ratify lock **including § API policy** (amendment) |
| **OPS-METHOD-CSS-03** | Felix | P0 | OPEN | Promote from **existing** fields only — no OpenAI in this row |
| **OPS-METHOD-CSS-05** | Felix | P1 | OPEN | Wire attachments from DB; OpenAI only if gap blocks + note in report |
| **OPS-METHOD-CSS-13** | Felix | P2 | **PAUSED** | API gap-fill grind (missed actionables / thin action·state·runbook) — **unpause only after CSS-09 GREEN** + Ethan scope note |

## Sequencing note

Unchanged CSS-00→12 order. **CSS-13** sits after CSS-09; does not block CSS-READY if smoke proves navigation without API.

## SuiteCRM

Sync CSS-01 (updated), CSS-13 on create; CSS-00b `SUITE: NO`.

SIGNED: Triage (Grace) | CSS API policy | 2026-07-22 | no API-before-CSS
