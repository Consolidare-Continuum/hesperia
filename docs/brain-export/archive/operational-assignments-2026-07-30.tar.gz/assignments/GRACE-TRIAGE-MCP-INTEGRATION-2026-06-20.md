# Grace triage — MCP integration (LAN replication + agent visibility)

**Date:** 2026-06-20  
**Source:** Operator — LAN copy/cron silent failures must be fixed **and** visible to agents via MCP (not log archaeology).  
**Policy:** [MCP-COMPLIANCE-AND-OPERATIONAL.md](../../governance/MCP-COMPLIANCE-AND-OPERATIONAL.md) · [ETHAN-MCP-PLUGIN-SHORTLIST.md](../../governance/ETHAN-MCP-PLUGIN-SHORTLIST.md) — extend **cursor-cluster-snapshot**, no new MCP server.

---

## Triage outcome

**PROJECT-CREATED — MCP-INT** — **2026-06-20** — [active.md](../../active.md) **MCP-INT-00..02** · register [MCP-INT-2026-REGISTER.md](../../governance/MCP-INT-2026-REGISTER.md).

**Infra track (same incident):** **LAN-REP-00..03** — [GRACE-TRIAGE-LAN-REPLICATION-RELIABILITY-2026-06-20.md](GRACE-TRIAGE-LAN-REPLICATION-RELIABILITY-2026-06-20.md). Abelard ships bytes + alerts; **MCP-INT** ships agent-readable status.

**One sentence:** Agents check LAN copy health with **get_lan_replication_status** (cluster-snapshot MCP) before trusting cron/rsync; stale = BLOCKED + Grace.

---

## Two tracks (do not merge owners)

| Track | IDs | Owner | Delivers |
|-------|-----|-------|----------|
| **Infra** | LAN-REP-01..03 | Ethan + Abelard | registry, runner, systemd, Prometheus, runbook on disk |
| **MCP** | MCP-INT-01..02 | Gena + Liam | snapshot tool, mandatory runbook trigger |

**Order:** Abelard **LAN-REP-02** hotfix can run now. **MCP-INT-01** after registry schema exists (LAN-REP-03 partial OK — tool reads `INVENTORY-*.md` until `registry.yaml`).

---

## MCP integration scope (this wave)

### 1. Tool — extend cursor-cluster-snapshot (Gena, MCP-INT-01)

| Tool | Input | Output |
|------|-------|--------|
| `get_lan_replication_status` | optional `job_id` | All jobs or one: id, host, last_success_utc, stale (bool), last_exit, bytes |

**Data sources (read-only, SSH where needed):**

- `cluster/lan-replication/registry.yaml` (when present)
- `cluster/lan-replication/INVENTORY-*.md` (P0 interim)
- Per-host `/var/lib/lan-replication/<id>/last_run.json` (when deployed)
- Prometheus `LanReplicationStale` firing via existing `list_firing_alerts` correlation (optional enrich)

**No new MCP server.** Update [governance/MCP-COMPLIANCE-AND-OPERATIONAL.md](../../governance/MCP-COMPLIANCE-AND-OPERATIONAL.md) §1 tool row for cursor-cluster-snapshot.

### 2. Runbook + mandatory trigger (Liam, MCP-INT-02)

| Deliverable | Path |
|-------------|------|
| Runbook | `scripts/SCRIPT-RUNBOOK-lan-replication-stale.md` |
| Mandatory trigger | [ETHAN-TARGETED-RUNBOOKS-MANDATORY.md](../../governance/ETHAN-TARGETED-RUNBOOKS-MANDATORY.md) — "LAN periodic copy stale / cron silent / rsync no new bytes" |

**Agent flow:** `get_lan_replication_status` → if any `stale=true` → **get_runbook** → assign Abelard LAN-REP-02/03; **task Grace** if data-loss risk.

### 3. Agent rules (Cursor, bundled in MCP-INT-02 or LAN-REP-03)

Before declaring LAN copy DONE or trusting archive paths: call **get_lan_replication_status** (or read inventory during P0). Ref: [.cursor/rules/cursor-mcp-chroma-first.mdc](../../.cursor/rules/cursor-mcp-chroma-first.mdc) — cluster proceed preflight already uses cluster-snapshot.

---

## active.md rows (triaged)

| Pri | Project | ID | Owner | Status |
|-----|---------|-----|-------|--------|
| P1 | mcp-int | MCP-INT-00 | Grace | DONE |
| P1 | mcp-int | MCP-INT-01 | Gena | OPEN |
| P1 | mcp-int | MCP-INT-02 | Liam | OPEN |

**Linked infra rows:** LAN-REP-01..03 (lan-rep project) — unchanged.

---

## Stupid mistakes → MCP answer

| Mistake | MCP answer |
|---------|------------|
| "Cron installed" | `get_lan_replication_status` → `stale=true` |
| Nobody reads cron.log | Tool + Prometheus alert |
| Agent assumes copy OK | Mandatory runbook before DONE on copy rows |
| grep repo for copy state | cluster-snapshot MCP first |

---

## SuiteCRM

All new rows: `SUITE: YES` · sync after triage per [GRACE-TRIAGE-SUITE-CRM-PER-ACTIVE-ADOPT-2026-06-18.md](GRACE-TRIAGE-SUITE-CRM-PER-ACTIVE-ADOPT-2026-06-18.md).

---

SIGNED: Triage (Grace) | MCP integration + LAN-REP linked | 2026-06-20
