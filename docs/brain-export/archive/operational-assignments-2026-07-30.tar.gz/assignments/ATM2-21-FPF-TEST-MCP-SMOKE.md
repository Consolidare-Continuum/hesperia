# ATM2-21 — cursor-fpf-test-mcp Clearance/Holding/Tail smoke

**Date:** 2026-07-23  
**Result:** Package `python -m fpf_thinking_map.verify` on pin **1.9.2** includes dedicated checks:

- `authorization receipt (scoped, non-replayable, TOCTOU-safe)`
- `pending input / AWAIT (distinct from IDLE)`
- `move intent / inspect_move (concrete move identity)`

Brain domain coverage: `thinking_maps/tests/test_atm2_clearance_holding_tail.py` (receipt round-trip + expiry, AWAIT vs IDLE, MoveIntent mismatch, cluster Clearance escalate).

Live MCP `run_verify` / `run_scenario(scope=core)` confirms API symbols present when server connected; local verify **26/26** is authoritative for this row.

SIGNED: Developer (Felix) | Claude Code context | 2026-07-23 | ATM2-21 smoke
