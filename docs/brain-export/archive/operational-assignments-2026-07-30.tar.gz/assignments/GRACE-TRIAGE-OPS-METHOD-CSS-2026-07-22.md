# Grace triage — ops-method Canonical Step Surface (CSS) wave

**Triage owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method · **Pack:** SRC-RYB-ED01  
**Trigger:** Operator — no org yet; surface book-true method as navigable steps + agentic next; Ethan plan ready.  
**Source:** [ETHAN-NEXT-CSS-2026-07-22.md](../../projects/ops-method/ETHAN-NEXT-CSS-2026-07-22.md) · [CSS-DESIGN-LOCK-v0.1.md](../../projects/ops-method/CSS-DESIGN-LOCK-v0.1.md)  
**MESH:** [MESH-READY-SRC-RYB-ED01.md](../../projects/ops-method/MESH-READY-SRC-RYB-ED01.md)  
**FREEZE:** intact for **new books** until CSS-READY + freeze-exit.  
**Do not reopen:** MAP-05 org intake, CORP-04/05 CRM/email (stay PAUSED).

## Rows to add → active.md

| ID | Owner | P | Deliverable |
|----|-------|---|-------------|
| **OPS-METHOD-CSS-00** | Grace | P0 | Triage CSS wave (this file) + SuiteCRM sync |
| **OPS-METHOD-CSS-01** | Ethan | P0 | Ratify CSS-DESIGN-LOCK-v0.1 (step / next / attachment / todo) |
| **OPS-METHOD-CSS-02** | Felix | P0 | Schema 007 canonical step surface DDL |
| **OPS-METHOD-CSS-03** | Felix | P0 | Promote STEP candidates from statements (resume-safe) |
| **OPS-METHOD-CSS-04** | Colombo | P0 | Attachment class policy (RU sense / EN ids) |
| **OPS-METHOD-CSS-05** | Felix | P1 | Wire attachments from existing DB tables |
| **OPS-METHOD-CSS-06** | Felix | P0 | Agent verbs locate_step / list_next / inspect_attachments / propose_todo |
| **OPS-METHOD-CSS-07** | Noah | P1 | Thinking-map CSS states + gates |
| **OPS-METHOD-CSS-08** | Liam | P1 | SCRIPT-RUNBOOK ops-method-css-session |
| **OPS-METHOD-CSS-09** | Ava | P1 | Smoke: 5 STEPs → next or certified terminal |
| **OPS-METHOD-CSS-10** | Felix | P1 | canonical_todo table + emit path |
| **OPS-METHOD-CSS-11** | Cursor | P0 | Dry-run traverse 3 hops + emit todo (Cursor + Felix) |
| **OPS-METHOD-CSS-12** | Ethan | P0 | Sign **CSS-READY** — unlocks org-overlay design + freeze-exit triage (new Grace pass) |

## Sequencing

CSS-00 → CSS-01 → (CSS-02 ∥ CSS-04) → CSS-03 → CSS-05 → CSS-06 → CSS-07/08 → CSS-09 → CSS-10 → CSS-11 → CSS-12.  
**CSS-13** (API gap-fill) PAUSED until CSS-09 — see [GRACE-TRIAGE-OPS-METHOD-CSS-API-POLICY-2026-07-22.md](GRACE-TRIAGE-OPS-METHOD-CSS-API-POLICY-2026-07-22.md).

## SuiteCRM

`SUITE: YES` on task/spec rows; sync on triage.

SIGNED: Triage (Grace) | ops-method CSS wave | 2026-07-22 | post-MESH canonical navigation  
SIGNED: Triage (Grace) | API policy addendum pointer | 2026-07-22 | CSS-00b
