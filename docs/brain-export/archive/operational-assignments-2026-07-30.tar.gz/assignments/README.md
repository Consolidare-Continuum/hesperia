# operational/assignments — live triage only

Historical waves → [`docs/brain-export/archive/`](https://github.com/igareosh/hesperia/tree/main/docs/brain-export/archive) on **igareosh/hesperia**.

Hesperia closure triage → [`docs/brain-export/final-sweep-2026-06-14/operational/`](https://github.com/igareosh/hesperia/tree/main/docs/brain-export/final-sweep-2026-06-14/operational).

**PAPRA** live packet: add new `GRACE-TRIAGE-*.md` here when Grace triages.
