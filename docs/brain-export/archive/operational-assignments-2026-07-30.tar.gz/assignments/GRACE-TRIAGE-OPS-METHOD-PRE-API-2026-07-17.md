# Grace triage — ops-method PRE-API structure wave (2026-07-17)

**Project:** `ops-method`  
**Wave:** PRE — structure before OpenAI book decomposition  
**Ethan task:** [ETHAN-TASK-GRACE-OPS-METHOD-PRE-API-2026-07-17.md](ETHAN-TASK-GRACE-OPS-METHOD-PRE-API-2026-07-17.md)  
**Outcome:** TEAM TASKED · API blocked until PRE exit GREEN + Ethan GO  
**Freeze:** unchanged — RYB-ED01 only

## Rule

**No live OpenAI decomposition / ingest of book batches** until:

1. All **PRE** exit criteria checked, and  
2. **OPS-METHOD-PRE-13** Ethan GO recorded.

## Rows (active.md) — PRE wave

| ID | Owner | Intent | Status |
|----|-------|--------|--------|
| **OPS-METHOD-PRE-00** | Grace | Triage PRE wave; pause post-API rows; SuiteCRM sync | DONE |
| **OPS-METHOD-PRE-01** | Abelard | Provision PostgreSQL for `ops_method` schema (dev host per Sophia) | OPEN |
| **OPS-METHOD-PRE-02** | Sophia | SCHEDULE-BASELINE + DB/infra duration (complete OPS-METHOD-06) | OPEN |
| **OPS-METHOD-PRE-03** | Marcus | Apply DDL 001+002+003 + verify seed/vocab (MAP-03) | OPEN |
| **OPS-METHOD-PRE-04** | Felix | PDF→page/paragraph/sentence segmenter → `source_*` tables (**no OpenAI**) | OPEN |
| **OPS-METHOD-PRE-05** | Felix | json_envelope + statement ingest dry-run on fixtures (no API) | OPEN |
| **OPS-METHOD-PRE-06** | Noah | Offline validation gates + closed relation vocab checks | OPEN |
| **OPS-METHOD-PRE-07** | Colombo | Seed logical/semantic coords + RU dictionary skeleton (MAP-04/CORP-06) | OPEN |
| **OPS-METHOD-PRE-08** | Olivia | Search/inspect requirements over coords/relations (MAP-06) | OPEN |
| **OPS-METHOD-PRE-09** | Liam | SCRIPT-RUNBOOK — pre-API prep + batch execute/audit (MAP-09) | OPEN |
| **OPS-METHOD-PRE-10** | Daniel | SECURITY-BASELINE source PDF isolation + OpenAI key custody path (no call) | OPEN |
| **OPS-METHOD-PRE-11** | Grace | PRE exit checklist — structure ready for API feeding | OPEN |
| **OPS-METHOD-PRE-12** | Ava | Smoke checklist — DB reachability, segment counts, dry-run envelope validate | OPEN |
| **OPS-METHOD-PRE-13** | Ethan | **GO** — authorize first OpenAI pilot batch (pp 1–20) only if PRE GREEN | OPEN |

## Existing rows — status alignment

| ID | Action |
|----|--------|
| OPS-METHOD-06, 07 | Stay OPEN — owned under PRE-02 / PRE-10 |
| MAP-03, 04, 06, 07, 08, 09 | Stay OPEN — execution targets for PRE-03..09 |
| CORP-02, 03 | Stay OPEN — ATM/envelope **stubs only** under PRE (no live book API) |
| CORP-01 | DONE (already) |
| **MAP-05** | **PAUSED** — client org intake after book product |
| **CORP-04** | **PAUSED** — CRM/email contract after core fed |
| **CORP-05** | **PAUSED** — CRM/email connectors after core fed |
| **CORP-07** | OPEN — absorb into PRE-11 checklist (RU orientation) |

## PRE exit (GREEN)

- [ ] DB up; `001`–`003` applied; SRC-RYB-ED01 seeded  
- [ ] Source sentences loaded for at least pilot pages (or full book segment) without API  
- [ ] Fixture dry-run writes envelopes/statements/manifests  
- [ ] Validation gates + vocab offline pass  
- [ ] Dictionary/coord skeleton + search requirements + runbooks present  
- [ ] Security: PDF access + API key custody path documented  
- [ ] Ava smoke pass  
- [ ] Ethan PRE-13 GO  

## Do not

- Call OpenAI for RYB-ED01 until PRE-13.  
- Add new source packs.  
- Build product MCP / CRM adapters in this wave.

## SuiteCRM

`SUITE: YES` on PRE rows. Sync after write. Pause CRM status on MAP-05 / CORP-04 / CORP-05 via `report_done` PAUSED or status update.

SIGNED: Triage (Grace) | PRE-API structure wave | 2026-07-17 | Ethan-tasked
