# Grace triage — FPF-BUII (bottom-up fpf inspect before 0.7)

**Date:** 2026-07-19  
**Source:** Operator → Ethan architecture SPEC  
**SPEC:** [governance/SPEC-ETHAN-HESPERIA-FPF-BOTTOM-UP-INSPECT.md](../../governance/SPEC-ETHAN-HESPERIA-FPF-BOTTOM-UP-INSPECT.md)

## Intent

Debug / dig endoscope for operator + Cursor team — **not** a second upper LLM path. Do not duplicate FPF-HSR-11..13.

## Rows (owners 2026-07-19 — Gena implement)

| ID | P | Owner | Task | TYPE |
|----|---|-------|------|------|
| **FPF-BUII-00** | P0 | Grace | Wave meta — BUII rows live; link SPEC; X-14 / FPF-HSR-10 cross-ref BUII-G1..G3 | triage |
| **FPF-BUII-01** | P0 | **Gena** | `sphere/fpf_inspect/` — probe L0 + L5/L7 climb MVP + GapReport v0.1 | task |
| **FPF-BUII-02** | P0 | **Gena** | Gold tests — deterministic GapReport; L6 stubs never evidence | task |
| **FPF-BUII-03** | P1 | **Gena** | Extend climb L1–L4, L6-live, GTP provisional tags (02/03/04), guards | task |
| **FPF-BUII-04** | P0 | **Gena** | MCP `hesperia_fpf_probe` + `hesperia_fpf_gaps` (dev); mcp-config | task |
| **FPF-BUII-05** | P1 | **Gena + Ethan** | Domain map `hesperia_inspect` + `hesperia_fpf_map_step` | task |
| **FPF-BUII-06** | P2 | Marcus / Grace | Operator dig runbook (“hit something → climb”) | task |
| **FPF-BUII-07** | P1 | Ethan | Amend FPF-HSR-10 / X-14 packet with BUII-G1..G3 seal language | spec |

**Deps:** 01→02; 01→03; 01+02→04; 04→05; 07 parallel (DONE).

**Operator reassign 2026-07-19:** implementation **Felix → Gena**. See [GRACE-TRIAGE-FPF-BUII-GENA-2026-07-19.md](GRACE-TRIAGE-FPF-BUII-GENA-2026-07-19.md).

**SUITE:** YES on all.

---

`SIGNED: Triage (Grace) | FPF-BUII | 2026-07-19 | Gena tasked implement`
