# Grace triage — FPF-BUII tasked to Gena

**Date:** 2026-07-19  
**Operator:** Grace triage and task Gena with bottom-up fpf inspect  
**SPEC:** [governance/SPEC-ETHAN-HESPERIA-FPF-BOTTOM-UP-INSPECT.md](../../governance/SPEC-ETHAN-HESPERIA-FPF-BOTTOM-UP-INSPECT.md)  
**Prior triage:** [GRACE-TRIAGE-FPF-BUII-2026-07-19.md](GRACE-TRIAGE-FPF-BUII-2026-07-19.md) (Felix owners superseded)

## Decision

**Gena** owns implementation of the bottom-up FPF-HSR inspect interface (BUII).  
Felix remains on product FPF-HSR-11..14 (router inquire / context_packet) — **do not conflate**.

| ID | Owner | Status |
|----|-------|--------|
| FPF-BUII-00 | Grace | DONE (meta) |
| **FPF-BUII-01** | **Gena** | OPEN — `sphere/fpf_inspect/` L0+L5/L7 + GapReport |
| **FPF-BUII-02** | **Gena** | OPEN — gold tests |
| **FPF-BUII-03** | **Gena** | OPEN — full climb + provisional tags |
| **FPF-BUII-04** | **Gena** | OPEN — MCP probe/gaps |
| **FPF-BUII-05** | **Gena + Ethan** | OPEN — `hesperia_inspect` map |
| FPF-BUII-06 | Marcus | OPEN — dig runbook |
| FPF-BUII-07 | Ethan | DONE |

**Order for Gena:** **01 → 02 → 03 → 04 → 05**.

**Handoff:** Infra/MCP deploy to prod hosts → Abelard. Architecture questions → Ethan SPEC. Upper LLM layer — do not touch.

---

`SIGNED: Triage (Grace) | FPF-BUII → Gena | 2026-07-19 | implement dig endoscope`
