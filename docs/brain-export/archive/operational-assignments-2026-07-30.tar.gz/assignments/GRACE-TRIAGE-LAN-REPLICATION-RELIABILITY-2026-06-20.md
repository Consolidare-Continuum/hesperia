# Grace triage — LAN replication reliability (cron/rsync/scp silent failure class)

**Date:** 2026-06-20  
**Source:** Operator — cluster LAN copy jobs fail silently; cron present but bytes stop landing; unacceptable data-loss risk if primary path behaved the same.  
**Ethan spec:** [governance/SPEC-ETHAN-LAN-REPLICATION-AND-JOB-RELIABILITY.md](../../governance/SPEC-ETHAN-LAN-REPLICATION-AND-JOB-RELIABILITY.md)

---

## Triage outcome

**PROJECT-CREATED — LAN-REP** — **2026-06-20** — [active.md](../../active.md) **LAN-REP-00..03** · register [LAN-REP-2026-REGISTER.md](../../governance/LAN-REP-2026-REGISTER.md).

**Linked MCP track:** [GRACE-TRIAGE-MCP-INTEGRATION-2026-06-20.md](GRACE-TRIAGE-MCP-INTEGRATION-2026-06-20.md) · **MCP-INT-00..02** on [active.md](../../active.md).

**One sentence:** LAN cron/rsync must land bytes or alert — no silent third state.

**Severity:** P1 — data integrity.

**Scope:** Transport + job reliability only. Not antenna/survey content.

**Grace simplification:** Four rows total. Stupid mistakes get stupid-clear tasks — inventory + hotfix first, permanent observer second.

---

## active.md rows (triaged)

| Pri | Project | ID | Owner | Status |
|-----|---------|-----|-------|--------|
| P1 | lan-rep | LAN-REP-00 | Grace | DONE |
| P1 | lan-rep | LAN-REP-01 | Ethan | OPEN |
| P1 | lan-rep | LAN-REP-02 | Abelard | OPEN |
| P1 | lan-rep | LAN-REP-03 | Abelard | OPEN |

---

## Root cause class (for Abelard P0, any job)

Check in order — **document which step failed** in inventory:

1. **Timer never ran** — `cron` inactive; wrong user; `/etc/cron.d` syntax; VM suspended.
2. **Job ran, exited non-zero** — read `journalctl` / `*-cron.log` / `collect.log`; first line of failure.
3. **SSH** — wrong IP (DNS vs WiFi); missing replication key; agent cert not trusted on Pi; `BatchMode=yes` + no key.
4. **Remote command failed** — sudo NOPASSWD; export script error; disk full on source.
5. **Rsync lied** — partial transfer; stderr swallowed; overlapping runs without flock.
6. **Wrong transport** — rsync to NTFS; need tar-stream.
7. **False green** — symlink `latest` updated but dirs empty; verify step missing.
8. **No observer** — no metric; operator only notices in chat days later.

---

## Dependencies

- Abelard cluster SSH (fix replication keys — **not** agent CA for data plane).
- prichindel Prometheus textfile path (existing node_exporter pattern).
- Ethan spec ratification before P1 code merge (LAN-REP-01).

---

## Next

**Abelard:** LAN-REP-02 now (inventory + hotfix). **Ethan:** LAN-REP-01 ratify. **Abelard:** LAN-REP-03 after spec ratified.

SIGNED: Triage (Grace) | PROJECT-CREATED LAN-REP-00..03 | 2026-06-20
