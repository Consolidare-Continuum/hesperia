# Colombo — HWIKI-STRUCT-01 inventory (param wiki vs sealed 0.7.0)

**Date:** 2026-07-26  
**Owner:** Colombo  
**Seal:** `system_version 0.7.0` · tag `v0.7.0` @ `0fcbe899360354c74260ff605787ad2c91bfe355`  
**Verified trees:** prod `/data/hesperia/hesperia` · dev `/data/workspaces/atomic-commit-hesperia`

---

## 1. What the wiki already is

| Layer | State @ inventory |
|-------|-------------------|
| Parameter/variable pages | **137** ITEMS via `tools/generate_wiki.py` |
| Theory-depth | **HWIKI-DOC-01..30** DONE (explainers on symbol pages) |
| Class A/B hub | [CLASS-AB-SCIENCE-NARRATIVE-HUB.md](../../colombo_research/hesperia/wiki/CLASS-AB-SCIENCE-NARRATIVE-HUB.md) — template only |
| Structure / how-it-works | **Missing as first-class wiki surface** — only scattered in `colombo_research/*_research/*HOW-IT-WORKS*` and modular-architecture brain docs |

**Verdict:** Wiki is excellent for *symbol live/dead*. It does **not** yet answer “what is Hesperia 0.7.0 as a system?” or “which path runs when I call X?”.

---

## 2. Sealed 0.7.0 surfaces that need structure narrative

From Ethan castle + live `VERSION.yaml` (both trees):

| Surface | Role | Wiki need |
|---------|------|-----------|
| `system_version: 0.7.0` · `release_stage: modular_branches` | Identity | State on structure hub |
| **Core sealed `/analyze`** → `runtime/services/analysis_service.py` → `sealed_multiscale_stack` | Plane A measurement | How-it-works scheme |
| **`POST /product/interpret`** → `runtime/shipping/api_main.py` · `product_interpret_service.py` · `sphere/router/` | V7 composition (not new physics) | How-it-works scheme + ground_truth |
| `sphere/router/ground_truth.py` | Three blocks: logical / weight / source_activation | Structure + how-it-works |
| Class A modules (`dict_a`/`dict_b`, topology, nlp, metrics) | Cored plumbing | Link CLASS-AB hub |
| Class B (TFP / MRT / COBALT) | Non-cored branches | Explicit “not sealed analyze” |
| H070 apply allowlist | Graph mutation still gated | Boundary scheme (observe ≠ apply) |
| `fpf_bridge: v7.2-v7.4` | Sealed with 0.7.0; flag-gated | Note pin diverge brain 1.9.3 vs product 1.9.2 |
| COBALT prod flag = 0 · clinical REAL_DATA gated | Not flipped by seal | Deferred STRUCT later |

---

## 3. Prior research (reuse, re-verify)

| Doc | Use for STRUCT | Caution |
|-----|----------------|---------|
| [HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md](../../colombo_research/hesperia/HESPERIA-MODULAR-BRANCH-ARCHITECTURE.md) | Structure hub backbone | Update prod hash refs to `v0.7.0` |
| [NASH_research_HESPERIA-HOW-IT-WORKS.md](../../colombo_research/hesperia/NASH_research/NASH_research_HESPERIA-HOW-IT-WORKS.md) | Plane A/B/C split | Dated 2026-06-15 — re-verify Plane A vs current sealed stack |
| [BELL_research_HESPERIA-HOW-IT-WORKS.md](../../colombo_research/hesperia/BELL_research/BELL_research_HESPERIA-HOW-IT-WORKS.md) | Apply / sandbox mermaid | Apply still allowlist — do not claim open mutate |
| Coverage-Ledger | Gap list | Add structure gap until STRUCT-04 |

---

## 4. Explicit non-goals (this batch)

- Do not re-wikify L1–L11 / TRIZ / CAT leftovers (other HWIKI batches).
- Do not invent new generator status codes for “system hubs”.
- Do not fold Class B into sealed `/analyze` narrative.

---

## 5. Deliverables unlocked by this inventory

| ID | Output |
|----|--------|
| STRUCT-02 | `wiki/structure/SYSTEM-STRUCTURE-0.7.0.md` |
| STRUCT-03 | `wiki/structure/HOW-IT-WORKS-0.7.0.md` (+ mermaid) |
| STRUCT-04 | Generator index + Coverage-Ledger links |

SIGNED: Researcher (Colombo) | HWIKI-STRUCT-01 inventory | 2026-07-26 | post-0.7.0 wiki align
