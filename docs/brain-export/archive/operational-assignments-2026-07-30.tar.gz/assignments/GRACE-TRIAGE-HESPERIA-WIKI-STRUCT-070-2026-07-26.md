# Grace triage — Hesperia wiki structure / how-it-works align (post 0.7.0)

**Date:** 2026-07-26  
**CSP:** From Colombo Context → To Grace Context | Reason: operator proceed after Hesperia **0.7.0** seal; wiki must describe structure and how it works, not only params | What changes: Grace opens `HWIKI-STRUCT-*` rows; Colombo owns content  
**Operator mandate:** Align wiki to sealed **0.7.0** — add descriptions for structure and what/how works; schemes if required; research if required.

**Seal ref:** [ETHAN-HESPERIA-070-SEAL-CASTLE-2026-07-26.md](reports/ETHAN-HESPERIA-070-SEAL-CASTLE-2026-07-26.md) · tag `v0.7.0` @ `0fcbe899360354c74260ff605787ad2c91bfe355`  
**Hub:** [wiki/CLAUDE.md](../../colombo_research/hesperia/wiki/CLAUDE.md) · live `http://192.168.100.65:8901/` · prior wave [GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md](GRACE-TRIAGE-HESPERIA-WIKI-ALL-ENCOMPASSING-2026-07-19.md)  
**Keeper trigger:** [HWIKI-KEEP-01](../../active.md) — B0–B1 / DOC wave ≥70% DONE → open next batch (this packet).

---

## Wave identity

| Field | Value |
|-------|--------|
| **Project** | `hesperia` |
| **ID prefix** | `HWIKI-STRUCT-` |
| **Batch** | **B-STRUCT** (post-0.7.0 structure + how-it-works) |
| **SUITE** | YES on all wave rows |
| **Exit** | Wiki home links durable structure hubs; Coverage-Ledger names 0.7.0 structure gap closed or deferred; schemes cite verified module paths |

## Scope (non-negotiable)

1. **Structure** — what Hesperia *is* at 0.7.0: core sealed `/analyze`, Class A/B modules, V7 router `/product/interpret`, apply allowlist boundary, components in `VERSION.yaml`.
2. **How it works** — step schemes for Plane A (sealed multiscale) and product interpret (ground_truth three-block doctrine); do not merge planes.
3. **Research** — inventory gap vs param wiki; cite NASH/BELL how-it-works only when re-verified against `v0.7.0` tree.
4. **Schemes** — mermaid or ASCII in durable hubs; not generator `ITEMS` unless a named symbol.

Durable hubs live under `colombo_research/hesperia/wiki/structure/` (hand-authored; **not** overwritten by `generate_wiki.py`). Index + Coverage-Ledger link them via generator patch (STRUCT-04).

## Rows opened this triage

| ID | Owner | Theme |
|----|-------|--------|
| **HWIKI-STRUCT-00** | Grace | Wave triage (this packet) |
| **HWIKI-STRUCT-01** | Colombo | Inventory: param wiki vs 0.7.0 sealed surfaces |
| **HWIKI-STRUCT-02** | Colombo | System structure hub @ 0.7.0 |
| **HWIKI-STRUCT-03** | Colombo | How-it-works schemes (Plane A + `/product/interpret`) |
| **HWIKI-STRUCT-04** | Colombo | Wire hubs into `generate_wiki.py` index + Coverage-Ledger |
| **HWIKI-STRUCT-05** | Felix | Code-anchor verify structure hubs vs `v0.7.0` tree |
| **HWIKI-STRUCT-06** | Cursor | HTML regen + `ingest-hesperia-wiki.sh` smoke after material batch |
| **HWIKI-STRUCT-07** | Colombo | HAND faces hub (inquire vs dig) |
| **HWIKI-STRUCT-08** | Colombo | Apply allowlist hub (H070) |
| **HWIKI-STRUCT-09** | Colombo | COBALT-off + REAL_DATA gates |

Further STRUCT rows: Grace adds when this seed ≥70% DONE or operator expands.

SIGNED: Triage (Grace) | Hesperia wiki B-STRUCT post-0.7.0 | 2026-07-26 | HWIKI-STRUCT
