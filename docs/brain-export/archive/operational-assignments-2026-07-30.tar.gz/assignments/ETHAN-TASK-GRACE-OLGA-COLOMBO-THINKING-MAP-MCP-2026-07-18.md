# Grace triage — Olga Colombo thinking-map MCP

**Date:** 2026-07-18  
**From:** Ethan (operator-directed)  
**Inbox:** New Feature — separate MCP on altitudine for Olga Colombo + fpf-thinking-map  
**Design (approved):** [ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md](ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md)

---

## What to triage

Operator: Olga needs a **separate** MCP on **altitudine**, fpf-thinking-map integrated into her Colombo contexts — **omnipresent** (search / inspect / analyze / answer). Library OK; MCP adapted for clinical scopes. **Not** team ATM workflow gates.

## Proposed active.md rows

| ID | Owner | Summary | TYPE | SUITE |
|----|-------|---------|------|-------|
| **OLGA-ATM-00** | Grace | Triage bootstrap — this packet | triage | YES |
| **OLGA-ATM-01** | Ethan | Spec seal + exit criteria on design | spec | YES |
| **OLGA-ATM-02** | Felix | Implement `olga-colombo-thinking-map` + `colombo_clinical` map in `igareosh/olga` | task | YES |
| **OLGA-ATM-03** | Felix | Wire mcp-config + deploy-olga-mcp + preflight | task | YES |
| **OLGA-ATM-04** | Colombo | Rules/AGENTS/SPEC in `igareosh/olga` — omnipresent step, jargon-free Olga chat | task | YES |
| **OLGA-ATM-05** | Abelard | altitudine venv/path for user `olga` if Felix blocked | task | YES |
| **OLGA-ATM-06** | Felix | Smoke verify (verify + COLLECT_EVIDENCE without corpus) | task | YES |

Link pattern: `[ETHAN-DESIGN…](operational/assignments/ETHAN-DESIGN-OLGA-COLOMBO-THINKING-MAP-MCP-2026-07-18.md) · SUITE: YES · SUITE NR: — · TYPE: …`

## Boundaries

- Code home: **`igareosh/olga`** / `/home/olga/olga-work`
- Engine pin: `fpf-thinking-map==1.5.0`
- Do **not** replace team `cursor-thinking-map`
- Do **not** put map runtime into Papra/CHROMA-2

## After rows

```bash
bash scripts/suitecrm_sync_on_triage.sh --task-id OLGA-ATM-00
# … per new id
```

SIGNED: Ethan → Grace | Olga ATM MCP triage ask | 2026-07-18 | operator-approved design
