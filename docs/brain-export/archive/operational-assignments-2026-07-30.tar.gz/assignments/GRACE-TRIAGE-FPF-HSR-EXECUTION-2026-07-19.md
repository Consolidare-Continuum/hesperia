# Grace triage — FPF-HSR execution after Ethan architecture packet

**Date:** 2026-07-19  
**Triage:** Grace  
**Source:** Operator — Ethan address Felix OPEN tasks → Grace triage after  
**Ethan packet:** [governance/ETHAN-FPF-HSR-02-10-ARCHITECTURE-PACKET-2026-07-19.md](../../governance/ETHAN-FPF-HSR-02-10-ARCHITECTURE-PACKET-2026-07-19.md)  
**Register:** [governance/FPF-HSR-2026-REGISTER.md](../../governance/FPF-HSR-2026-REGISTER.md)

## Ethan rows closed by packet (no new triage for these)

| ID | Status |
|----|--------|
| FPF-HSR-01 | DONE (prior day run) |
| FPF-HSR-02 | DONE — ADR accept `r=0` interim; Option B follow-up |
| FPF-HSR-03 | DONE — ratify `40_POLICY_v0_placeholder` |
| FPF-HSR-04 | DONE — ratify provisional anchors |
| FPF-HSR-05 | DONE — architecture approve |
| FPF-HSR-06 | DONE — architecture approve |
| FPF-HSR-07 | DONE — architecture approve |
| FPF-HSR-09 | DONE — mapping draft (Colombo review follow-up) |
| FPF-HSR-10 | DONE — exit criteria defined |

## Already OPEN (do not duplicate)

| ID | Owner | Action |
|----|-------|--------|
| **FPF-HSR-08** | Sophia + Daniel | Security review — leave OPEN; unblocks G6 |

## New execution rows (create on active.md)

| ID | P | Owner | Task | TYPE | SUITE |
|----|---|-------|------|------|-------|
| **FPF-HSR-11** | P0 | Felix | Implement `InterpretBody.context_packet` per Ethan packet §FPF-HSR-05; wire to `compile_router_envelope`; tests; flags default safe | task | YES |
| **FPF-HSR-12** | P0 | Felix | Ship MCP `hesperia-router` (`hesperia_router_inquire`) per §FPF-HSR-06; wire brain mcp-config; JSON-only | task | YES |
| **FPF-HSR-13** | P1 | Felix | Enforce mandatory logical/weight/source_activation blocks (`hesperia.agent_response_ground_truth.v0_1`) per §FPF-HSR-07 on 11/12 surfaces | task | YES |
| **FPF-HSR-14** | P2 | Felix | Implement discriminating `hex_rotation` Option B (primary-side-only) + gold tests; update 23_SPEC §0.1 note | task | YES |
| **FPF-HSR-15** | P1 | Colombo | Review/sign FPF-HSR-09 mapping table (clinical/TFP naming); amend gaps `possible_transitions` / `response_contract` | task | YES |
| **FPF-HSR-16** | P1 | Grace | Wave close when Ethan exit G1–G9 met; inbox footer; register DONE counts | triage | YES |

**Deps:** 11/12 before 13; 08 before any external/prod real-data on 11/12; 15 parallel; 16 last.

## SuiteCRM

After rows live: `bash scripts/suitecrm_sync_on_triage.sh --task-id FPF-HSR-11` (repeat per id or rely on 15‑min cron).

---

`SIGNED: Triage (Grace) | FPF-HSR execution | 2026-07-19 | rows FPF-HSR-11..16`
