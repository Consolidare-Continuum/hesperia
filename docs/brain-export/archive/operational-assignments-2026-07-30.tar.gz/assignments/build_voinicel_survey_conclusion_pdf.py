#!/usr/bin/env python3
"""Build branded prichindel.com PDF for voinicel antenna survey conclusion paper."""
from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm, mm
from reportlab.platypus import (
    HRFlowable,
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

REPO = Path(__file__).resolve().parents[2]
LOGO = REPO / "brand" / "logo-prichindel.png"
OUT = Path(__file__).resolve().parent / "VOINICEL-ANTENNA-SURVEY-CONCLUSION-PAPER.pdf"

# prichindel brand palette (logo: purple→blue on dark)
BRAND_DARK = colors.HexColor("#0B0F1A")
BRAND_PURPLE = colors.HexColor("#8B5CF6")
BRAND_BLUE = colors.HexColor("#3B82F6")
BRAND_TEXT = colors.HexColor("#1E293B")
BRAND_MUTED = colors.HexColor("#64748B")
BRAND_RULE = colors.HexColor("#CBD5E1")
BRAND_TABLE_HEAD = colors.HexColor("#EEF2FF")


def footer_canvas(canvas, doc):
    canvas.saveState()
    w, h = A4
    canvas.setFillColor(BRAND_DARK)
    canvas.rect(0, 0, w, 14 * mm, fill=1, stroke=0)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica", 8)
    canvas.drawString(20 * mm, 5 * mm, "prichindel.com — development company")
    canvas.drawRightString(w - 20 * mm, 5 * mm, f"Page {doc.page}")
    canvas.setStrokeColor(BRAND_PURPLE)
    canvas.setLineWidth(2)
    canvas.line(20 * mm, 14 * mm, w - 20 * mm, 14 * mm)
    canvas.restoreState()


def header_block(logo_path: Path) -> list:
    story = []
    if logo_path.exists():
        img = Image(str(logo_path), width=5.2 * cm, height=1.1 * cm, kind="proportional")
        story.append(img)
    story.append(Spacer(1, 4 * mm))
    story.append(
        Paragraph(
            "<font color='#8B5CF6'><b>Research &amp; Formalization</b></font> "
            "<font color='#64748B'>| Colombo · prichindel.com</font>",
            ParagraphStyle("brandline", fontSize=9, leading=11),
        )
    )
    story.append(Spacer(1, 6 * mm))
    story.append(HRFlowable(width="100%", thickness=1, color=BRAND_PURPLE, spaceAfter=8))
    return story


def p(text: str, style: str, styles) -> Paragraph:
    return Paragraph(text, styles[style])


def table(data, col_widths=None) -> Table:
    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), BRAND_TABLE_HEAD),
                ("TEXTCOLOR", (0, 0), (-1, 0), BRAND_TEXT),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("LEADING", (0, 0), (-1, -1), 10),
                ("GRID", (0, 0), (-1, -1), 0.25, BRAND_RULE),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return t


def build_pdf() -> Path:
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            "TitleDoc",
            parent=styles["Title"],
            fontSize=16,
            leading=20,
            textColor=BRAND_TEXT,
            spaceAfter=10,
        )
    )
    styles.add(
        ParagraphStyle(
            "Subtitle",
            parent=styles["Normal"],
            fontSize=9,
            leading=12,
            textColor=BRAND_MUTED,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            "H2",
            parent=styles["Heading2"],
            fontSize=12,
            leading=14,
            textColor=BRAND_PURPLE,
            spaceBefore=10,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            "H3",
            parent=styles["Heading3"],
            fontSize=10,
            leading=12,
            textColor=BRAND_BLUE,
            spaceBefore=6,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            "Body",
            parent=styles["Normal"],
            fontSize=9.5,
            leading=13,
            textColor=BRAND_TEXT,
            alignment=TA_JUSTIFY,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            "BodyBullet",
            parent=styles["Body"],
            leftIndent=12,
            bulletIndent=0,
            spaceAfter=4,
        )
    )

    doc = SimpleDocTemplate(
        str(OUT),
        pagesize=A4,
        leftMargin=20 * mm,
        rightMargin=20 * mm,
        topMargin=18 * mm,
        bottomMargin=22 * mm,
        title="Voinicel Antenna Survey Conclusion",
        author="Colombo · prichindel.com",
        subject="GNSS survey-in environmental characterization",
    )

    story: list = []
    story.extend(header_block(LOGO))

    story.append(
        p(
            "Antenna Mount Survey-In on a Fixed Multipath-Rich Site:<br/>"
            "<b>Outcomes, Environmental Limits, and Operational Positioning Tier</b>",
            "TitleDoc",
            styles,
        )
    )
    story.append(
        p(
            "<b>Mount:</b> voinicel-sma-rail-magnet-01 &nbsp;|&nbsp; "
            "<b>Node:</b> voinicel · LEA-M8T-0 · WD22UGRC VER.C<br/>"
            "<b>Date:</b> 2026-06-20 &nbsp;|&nbsp; <b>Owner:</b> Colombo (Research)<br/>"
            "<b>Data:</b> Survey log bundle v1 (25 h) + edge archive through 35.8 h active survey-in",
            "Subtitle",
            styles,
        )
    )

    story.append(p("<b>Abstract</b>", "H2", styles))
    story.append(
        p(
            "A maximum-duration u-blox TIM-SVIN survey-in "
            "(<i>svinMinDur</i> = 86,400 s, <i>svinAccLimit</i> = 1,000 mm) was executed on a "
            "mechanically fixed outdoor installation in Moldova (≈ 47.03°N, 28.82°E) to characterize "
            "the antenna reference point (ARP) of a MikroTik magnetic-mount antenna on a horizontal "
            "ferrous rail, in proximity to a wet metal sewer stack and a utility supply mast (≈ 5–6 m). "
            "The survey-in <b>did not complete</b> (<i>valid</i> = 0). Duration exceeded the 24 h gate; "
            "three-dimensional accuracy remained at ≈ 10 m (≈ 10% of the u-blox one-metre timing-reference "
            "tier). Epoch-wise position scatter reached ≈ 46 m horizontally and ≈ 67 m vertically. "
            "The installation nonetheless sustains <b>stratum-1 time transfer</b> via PVT plus "
            "pulse-per-second (PPS), with a <b>practical positioning lock tier of ≈ 10 m</b> at the ARP. "
            "<b>Software or firmware alterations cannot alter the feasibility conclusions drawn from the "
            "environment</b>; they may only change logging, masking heuristics, or acceptance thresholds. "
            "The limiting factor is <b>static near-field multipath</b>, not mechanical instability or "
            "antenna-mount defect.",
            "Body",
            styles,
        )
    )

    story.append(p("1. Introduction", "H2", styles))
    story.append(p("1.1 Objective", "H3", styles))
    story.append(
        p(
            "The survey sought to determine whether a fixed outdoor ARP on voinicel could satisfy "
            "u-blox CFG-TMODE2 survey-in gates sufficient for transition to <b>Fixed time mode</b> at "
            "the <b>one-metre three-dimensional accuracy</b> level associated with nanosecond-class "
            "TIMEPULSE performance (UBX timing documentation, reference tier ≤ 1 m position knowledge).",
            "Body",
            styles,
        )
    )
    story.append(p("1.2 Scope", "H3", styles))
    story.append(
        p(
            "This paper reports <b>environmental and instrumental outcomes</b> only. It does not propose "
            "code changes, receiver reprogramming, or algorithmic post-processing as remedies for the "
            "observed accuracy ceiling, because those interventions do not remove the underlying "
            "multipath geometry established by the site.",
            "Body",
            styles,
        )
    )
    story.append(p("1.3 Operational context", "H3", styles))
    story.append(
        p(
            "The LEA-M8T installation already provides <b>network time protocol (NTP) stratum 1</b> to "
            "the cluster via <b>gpsd</b>, <b>NMEA shared memory</b>, and <b>PPS</b> to chrony. "
            "Survey-in addressed <b>ARP formalization</b> and <b>fixed-mode timing upgrade</b>, not "
            "basic time service viability.",
            "Body",
            styles,
        )
    )

    story.append(p("2. Methods", "H2", styles))
    story.append(p("2.1 Survey specification", "H3", styles))
    story.append(
        table(
            [
                ["Parameter", "Value"],
                ["timeMode", "1 (Survey-In)"],
                ["svinMinDur", "86,400 s (24 h)"],
                ["svinAccLimit", "1,000 mm (1.0 m 3D)"],
                ["Start (local)", "2026-06-19 01:33:16 +03:00"],
                ["Completion rule", "Both duration and accuracy gates required for valid = 1"],
            ],
            [5.5 * cm, 11 * cm],
        )
    )
    story.append(Spacer(1, 6))

    story.append(p("2.2 Mount and site description", "H3", styles))
    story.append(
        table(
            [
                ["Element", "Description"],
                [
                    "Mechanical mount",
                    "MikroTik magnetic-mount antenna on horizontal iron rail; no intentional motion",
                ],
                [
                    "RF path",
                    "Mag-mount with designed isolation between ferrous cup and radiator",
                ],
                [
                    "Proximate reflectors",
                    "Ferrous rail; metal sewer (≈ 6 m up, 3 m down); utility mast (≈ 5–6 m, grounded)",
                ],
                [
                    "Electrical grounding",
                    "Utility bonding per grid practice; irrelevant to L1 (≈ 1.575 GHz) reflection suppression",
                ],
            ],
            [3.8 * cm, 12.7 * cm],
        )
    )
    story.append(Spacer(1, 6))

    story.append(p("2.3 Data acquisition", "H3", styles))
    for line in [
        "Edge monitor: 5 min cadence (convergence.log, monitor.csv, UBX TIM-SVIN poll).",
        "Bundle v1: 25 h window, 301 convergence samples, hourly SVIN milestones.",
        "Full run: 128,952 s (≈ 35.8 h) last active sample before host reboot.",
        "Archive: voinicel-gps-survey-reason-bundle-v1.",
    ]:
        story.append(p(f"• {line}", "BodyBullet", styles))

    story.append(PageBreak())
    story.extend(header_block(LOGO))
    story.append(p("3. Results", "H2", styles))
    story.append(p("3.1 Survey-in gates", "H3", styles))
    story.append(
        table(
            [
                ["Gate", "Criterion", "24 h", "25 h", "End of run"],
                ["Duration", "dur ≥ 86,400 s", "Passed", "Passed", "Passed"],
                ["", "", "86,345 s", "89,945 s", "128,952 s"],
                ["Accuracy", "σ₃D ≤ 1,000 mm", "Failed", "Failed", "Failed"],
                ["", "", "10,078.9 mm", "10,114.5 mm", "9,961.4 mm"],
                ["valid", "1", "0", "0", "0"],
            ],
            [2.2 * cm, 3.8 * cm, 2.5 * cm, 2.5 * cm, 2.5 * cm],
        )
    )
    story.append(Spacer(1, 4))
    story.append(
        p(
            "<b>Terminology outcome:</b> The receiver <b>correctly withheld Fixed-mode transition</b>. "
            "Survey-in <b>failed on accuracy</b>, not on insufficient integration time.",
            "Body",
            styles,
        )
    )

    story.append(p("3.2 Convergence trajectory", "H3", styles))
    story.append(
        table(
            [
                ["Phase", "Time span", "σ₃D", "quality_pct", "Outcome"],
                ["Initial transient", "First ≈ 10 min", "12.9 m → 9.5 m", "7.7% → 10.5%", "Not sustained"],
                ["Plateau", "h2 through h25+", "9.7–10.3 m", "≈ 9.9–10.3%", "Environmental ceiling"],
                ["Post-24 h", "+11.8 h beyond gate", "≈ 10.0 m", "≈ 10.0%", "No improvement"],
            ],
            [2.8 * cm, 3.2 * cm, 2.5 * cm, 2.5 * cm, 5.5 * cm],
        )
    )
    story.append(Spacer(1, 6))

    story.append(p("3.3 Epoch-wise positioning scatter (233 monitored 3D fixes)", "H3", styles))
    story.append(
        table(
            [
                ["Component", "Observed spread", "Terminology outcome"],
                ["Horizontal", "≈ 46 m", "Strong horizontal multipath on fixed mount"],
                ["Altitude (MSL)", "≈ 67 m", "Vertical domination of error budget"],
                ["Mean eph", "≈ 18.9 m", "Reported uncertainty understates scatter"],
                ["Mean epv", "≈ 35.1 m", "Vertical ≈ 1.9× horizontal"],
            ],
            [3.5 * cm, 3.5 * cm, 8.5 * cm],
        )
    )
    story.append(Spacer(1, 4))
    story.append(
        p(
            "<b>Terminology outcome:</b> The antenna did not move; pseudorange solutions wandered within "
            "a ≈ 50–100 m instantaneous envelope. Long-term averaging compressed this to ≈ 10 m on the "
            "TIM-SVIN mean — <b>not</b> to the 1 m tier.",
            "Body",
            styles,
        )
    )

    story.append(p("3.4 Preliminary ARP (running mean, valid = 0)", "H3", styles))
    story.append(
        table(
            [
                ["Quantity", "Value", "Status"],
                ["Latitude", "47.027826° N", "Indicative only"],
                ["Longitude", "28.821180° E", "Indicative only"],
                ["ECEF (cm)", "X=381599418, Y=209969789, Z=464397471", "Not certified ARP"],
                ["Observations", "128,953", "Sufficient for mean stability"],
                ["σ₃D at end", "9,961.4 mm", "Fails reference tier"],
            ],
            [3.5 * cm, 5.5 * cm, 5.5 * cm],
        )
    )
    story.append(Spacer(1, 6))

    story.append(p("3.6 Operational time service", "H3", styles))
    story.append(
        table(
            [
                ["Service", "Mechanism", "Outcome"],
                ["Stratum 1 NTP", "chrony ← PPS + NMEA (gpsd)", "Operational"],
                ["3D fix class", "fixType = 3 sustained", "Continuous lock"],
                ["Practical position tier", "PVT + survey mean", "≈ 10 m at ARP"],
            ],
            [3.5 * cm, 5.5 * cm, 5.5 * cm],
        )
    )
    story.append(Spacer(1, 4))
    story.append(
        p(
            "<b>Terminology outcome:</b> <b>Stratum 1 at ≈ 10 m GPS position lock</b> is what the "
            "installation <b>in fact achieves</b>. Nanosecond-tier surveyed ARP lock at 1 m is "
            "<b>not</b> achieved.",
            "Body",
            styles,
        )
    )

    story.append(PageBreak())
    story.extend(header_block(LOGO))
    story.append(p("4. Discussion", "H2", styles))

    blocks = [
        (
            "4.1 Mechanical stability versus ranging stability",
            "Reasoning: A fixed magnetic-mount antenna on a rigid rail exhibits mechanical stationarity.",
            "Result: Running-mean ECEF drift ≈ 2–3 m over 25 h without step discontinuities. "
            "Mechanical stability is confirmed.",
        ),
        (
            "4.2 Antenna design versus site reflectors",
            "Reasoning: MikroTik mag-mount antennas incorporate RF isolation between base and radiator. "
            "Close metallic structures within ≈ 6 m produce static L1 reflections.",
            "Result: Mount is fit for purpose. Epoch scatter ≈ 46–67 m matches near-field multipath. "
            "Electrical grounding does not decouple GPS energy.",
        ),
        (
            "4.3 Temporal averaging under static multipath",
            "Reasoning: Independent white noise averages with √N; static multipath does not.",
            "Result: Plateau for 23+ hours. Extended survey-in is not an effective mitigation at this ARP.",
        ),
        (
            "4.4 Code, firmware, and masking interventions",
            "Reasoning: Software alters measurement selection or logging, not physical reflectors.",
            "Result: <b>Altering code does not benefit the feasibility of environmental conclusions.</b> "
            "It cannot reclassify this site as a one-metre timing-reference installation.",
        ),
    ]
    for title, reasoning, result in blocks:
        story.append(p(title, "H3", styles))
        story.append(p(f"<b>Reasoning:</b> {reasoning}", "Body", styles))
        story.append(p(f"<b>Result:</b> {result}", "Body", styles))

    story.append(p("4.5 Achieved versus targeted tier", "H3", styles))
    story.append(
        table(
            [
                ["Tier", "Target", "Achieved", "Terminology"],
                ["u-blox timing reference", "σ₃D ≤ 1 m, valid = 1", "Not achieved", "Survey-in incomplete"],
                ["Long-mean site ARP", "Stable ECEF mean", "≈ 10 m", "Site-class ARP"],
                ["Stratum 1 time", "PPS-disciplined NTP", "Achieved", "Primary operational outcome"],
                ["Instantaneous PVT", "Continuous 3D fix", "Achieved (large scatter)", "Coarse conning only"],
            ],
            [3.8 * cm, 4.2 * cm, 3.5 * cm, 3.8 * cm],
        )
    )

    story.append(p("5. Conclusions", "H2", styles))
    conclusions = [
        "Survey-in at svinAccLimit = 1,000 mm is <b>not feasible</b> at ARP voinicel-sma-rail-magnet-01 "
        "given the documented static environment, independent of integration beyond 24 h.",
        "The limiting phenomenon is <b>near-field multipath</b> from ferrous rail, sewer, and utility mast "
        "(≈ 5–6 m), producing ≈ 50–100 m instantaneous excursion and a stabilized ≈ 10 m three-dimensional mean.",
        "Mechanical stationarity and mag-mount antenna integrity are <b>not in question</b>.",
        "<b>What is in fact achieved:</b> stratum-1 time service with ≈ 10 m GPS position lock at the ARP — "
        "suitable for cluster timing, unsuitable for one-metre Fixed-mode certification without environmental change.",
        "<b>Software modification is not a path to overturning these environmental conclusions.</b>",
    ]
    for i, c in enumerate(conclusions, 1):
        story.append(p(f"{i}. {c}", "BodyBullet", styles))

    story.append(p("6. Recommendations (non-code)", "H2", styles))
    story.append(
        table(
            [
                ["Intent", "Recommendation"],
                ["Maintain stratum 1", "Continue PVT + PPS; do not depend on survey-in valid"],
                ["Fixed-mode ARP", "Re-survey with svinAccLimit ≈ 10 m or relocate antenna"],
                ["Higher tier", "Physical RF mitigation — not repository script changes"],
                ["Documentation", "Treat v1 bundle as site characterization record"],
            ],
            [4 * cm, 12.5 * cm],
        )
    )

    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=0.5, color=BRAND_RULE))
    story.append(Spacer(1, 4))
    story.append(
        p(
            "<font color='#64748B'>SIGNED: Research (Colombo) | prichindel.com | 2026-06-20 | "
            "voinicel-sma-rail-magnet-01 · stratum 1 at ≈ 10 m lock</font>",
            "Subtitle",
            styles,
        )
    )
    story.append(
        p(
            "<font color='#64748B'>References: u-blox UBX-13003221 §25.3 · "
            "cluster/voinicel/GPS-STRATUM1-SETUP.md · "
            "voinicel-gps-survey-reason-bundle-v1</font>",
            "Subtitle",
            styles,
        )
    )

    doc.build(story, onFirstPage=footer_canvas, onLaterPages=footer_canvas)
    return OUT


if __name__ == "__main__":
    path = build_pdf()
    print(path)
