# Grace triage — ops-method Day 5 (+ Day 6 hold)

**Triage owner:** Grace · **Date:** 2026-07-27 (landed) · **Drafted:** 2026-07-24 · **Project:** ops-method  
**Trigger:** Inbox New + Colombo plans; operator AWP 2026-07-27.  
**Plans:** [COLOMBO-PLAN-DAY5-STRAT.md](../../projects/ops-method/COLOMBO-PLAN-DAY5-STRAT.md) · [COLOMBO-PLAN-DAY6-DIGEST-PAY-EX.md](../../projects/ops-method/COLOMBO-PLAN-DAY6-DIGEST-PAY-EX.md)  
**Day 4 closed:** [DAY4-08-PIPELINE-READY.md](../../projects/ops-method/DAY4-08-PIPELINE-READY.md) · [DAY4-WRAP-2026-07-24.md](../../projects/ops-method/DAY4-WRAP-2026-07-24.md)

## Product intake (locked)

1. Day 5 = book **#2 Strategy** → `SRC-RYB-STRAT` (AUTH-RYBAKOV)  
2. Day 6 = Smart Reading digest overlay + Payivina **#6** + exercise plane — **HOLD** until Ethan **P1-TRIAD-READY** (or operator parallel carve)  
3. Digest ≠ peer STEPs; Payivina #5 ≠ equal pack

## Rows landed (Day 5 only)

| ID | Owner | Status | Deliverable |
|----|-------|--------|-------------|
| **OPS-METHOD-DAY5-00** | Grace | DONE | This triage |
| **OPS-METHOD-DAY5-01** | Grace | OPEN | Register `SOURCE-PACK-RYBAKOV-STRAT.md` + schema seed `SRC-RYB-STRAT` |
| **OPS-METHOD-DAY5-02** | Felix | OPEN | Segment Strategy PDF → `source_*` (224 pp) |
| **OPS-METHOD-DAY5-03** | Felix | OPEN | OpenAI extract `--pack-id SRC-RYB-STRAT` (resume OK; 017 coord) |
| **OPS-METHOD-DAY5-04a** | Felix | OPEN | API `POST /cross-pack/propose` STRAT→ED01 (`persist=true`) |
| **OPS-METHOD-DAY5-04b** | Felix | OPEN | API propose STRAT→ORDER |
| **OPS-METHOD-DAY5-05** | Colombo | OPEN | RU sort/review both edge families |
| **OPS-METHOD-DAY5-06** | Ava | OPEN | STRAT ingest smoke + ED01 10×3-hop regression |
| **OPS-METHOD-DAY5-07** | Ethan | OPEN | Sign **P1-TRIAD-READY** (partial OK if extract incomplete) |
| **OPS-METHOD-DAY5-08** | Liam | OPEN | Amend ingestion runbook: dual-target cross-pack |

**Day 6:** not landed — serial after Day 5 Ethan sign.

**Triage outcome:** PROJECT-CREATED — 2026-07-27 — Day 5 rows on [active.md](../../active.md).

SIGNED: Triage (Grace) | Day 5 STRAT wave | 2026-07-27 | ops-method
