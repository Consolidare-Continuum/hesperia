# Cursor → Grace — CC_ Hesperia copyright session

**Date:** 2026-07-26  
**Status:** COPYRIGHT PACK DONE (Lane B) · NDA originals remain Lane A

## Did

- Proprietary posture **A** — all rights reserved; no shared rights; disclosure only under NDA or court order.
- Company identity from Grace CC_ / Extraș RSUD: **CONSOLIDARE CONTINUUM S.R.L.** IDNO **1026023120076**, Platonov Igor 100%.
- Overlay on `Consolidare-Continuum/hesperia` @ `6b8419c` (on top of Atomic `0fcbe899`).
- Files: `LICENSE`, `NOTICE`, `LEGAL_NOTICE.md`, `SECURITY.md`, `README.md`, `docs/corporate/*`.
- Mirror script re-applies overlay after Atomic sync.
- Design: `docs/superpowers/specs/2026-07-26-cc-hesperia-copyright-design.md`

## Still Lane A (not GitHub)

NDA PDF, ASP/registry packs, bank rechizite — MinIO / `CC_/documents`.

## Mentor path

1. Sign NDA (Lane A)  
2. Invite to private GitHub org repo  
3. Work under agreement — see `docs/corporate/ACCESS-UNDER-NDA.md` on the product repo

`SIGNED: Cursor + Grace CC_ | copyright session | 2026-07-26 | proprietary A shipped`
