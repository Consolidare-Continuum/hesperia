# Hesperia module map @ 0.7.0 (Class A / B)

**Date:** 2026-07-26  
**Owners:** Colombo (formalize) · Felix (tree evidence) · Ethan (ratify structure)  
**Seal:** `0fcbe899` · `system_version 0.7.0`  
**Identity:** [ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md](../../governance/ETHAN-HESPERIA-MULTIPURPOSE-ENGINE-IDENTITY.md)

## Rule

**Modules ≠ product identity.** Core = dictionaries · logic · areas/families. Domain modules stay Class B unless universal plumbing drains to Class A.

## Alias SSOT

`hesperia/engine/module_aliases.py` (re-exported via `hesperia/modules/registry.py`):

| Alias | Target | Class | Notes |
|-------|--------|-------|-------|
| `nlp` / `nlp.basic` | `hesperia.modules.nlp.basic` | **A** | Shared tokenization |
| `dict_a` / `core.dict_a` | `core.runtime.dict_a_module` | **A** | Lexical → grid |
| `dict_b` / `core.dict_b` | `core.runtime.dict_b_module` | **A** | Lexical → grid |
| `topology` / `topology.core` | `core.runtime.topology_module` | **A** | Geometry/phase |
| `metrics` / `metrics.base` | `core.runtime.metrics_module` | **A** | Measurement hooks |
| `tfp` / `tfp.v1` | `hesperia.modules.tfp.v1` | **B** | One field application module — **not** medicine identity |

## Tree presence (prod)

- `hesperia/modules/nlp/` — present  
- `hesperia/modules/tfp/` — present  
- `hesperia/modules/registry.py` — thin re-export of aliases  

## Shipping vs modules

Public shipping commands (`analyze` · `compare` · `batch` · `interpret`) are **capabilities**, not module aliases — `hesperia/system/capabilities.py` · `runtime/shipping/api_main.py`.

## Ethan hold (WIRE-044)

No TFP behaviour into sealed `/analyze` in this wire run. TFP remains Class B field module.

SIGNED: Researcher (Colombo) · Developer (Felix) · Team lead (Ethan) | module map 0.7.0 | 2026-07-26 | H070-WIRE-041/043/044
