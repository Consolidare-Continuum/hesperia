# Grace triage — ops-method corporate locale / ATM / CRM+email (2026-07-17)

**Project:** `ops-method`  
**Wave:** CORP — language split, agentic ATM, CRM+email corporate grade  
**Hygiene tag:** docs-only · integration  
**Outcome:** POLICY-ACTIVE + active.md rows  
**Canonical policy:** [projects/ops-method/LANGUAGE-AND-OPERATING-LOCALE.md](../../projects/ops-method/LANGUAGE-AND-OPERATING-LOCALE.md)

## Operator directives (locked)

1. **Source is Russian and stays Russian** — no forced translation of source sentences or claim sense-text.  
2. **Human orientation = Russian** — operator/client-facing operational UI and human orientation in RU.  
3. **Documentation = ISO-grade English** — charters, specs, runbooks, contracts, engineering docs.  
4. **Variables / process semicode / code descriptions = ISO-grade English** — identifiers, schemas, relation type tokens, API fields, code comments that describe structure.  
5. **Semantics stay Russian** — meanings, dictionary glosses for humans, claim semantic content in RU.  
6. **LLM participation** = mostly **agentic**, based on **fpf-thinking-map** library — **may adopt from start**.  
7. **MCP:** team/dev MCP OK for side development now; **project MCP for ops-method is created separately after product finish** — do not scope product MCP in Wave 0/MAP.  
8. **Post-mapping runtime** heavily works with **a CRM, any CRM**, and **email** — CRM-agnostic connectors.  
9. **Corporate grade** — audit, access control, isolation, reliability bar.

## Rows (active.md)

| ID | Owner | Intent | Status |
|----|-------|--------|--------|
| **OPS-METHOD-CORP-00** | Grace | Triage CORP policy; SuiteCRM sync | DONE |
| **OPS-METHOD-CORP-01** | Ethan | Ratify language split + corporate grade into SPEC / ARCH-DECISION / Spec v0.1 | OPEN |
| **OPS-METHOD-CORP-02** | Noah | Adopt fpf-thinking-map into agentic pipeline from start (gates on mapping/extraction moves) | OPEN |
| **OPS-METHOD-CORP-03** | Felix | Wire ATM pin + thinking_map_step hooks in pipeline stubs (dev-side; not product MCP) | OPEN |
| **OPS-METHOD-CORP-04** | Emma | Integration contract DRAFT — CRM-agnostic adapter + email; product MCP deferred post-finish | OPEN |
| **OPS-METHOD-CORP-05** | Daniel | Corporate-grade bar for CRM/email connectors (secrets, audit, access class) | OPEN |
| **OPS-METHOD-CORP-06** | Colombo | RU semantics dictionary policy — RU sense / EN identifiers; align MAP-04 | OPEN |
| **OPS-METHOD-CORP-07** | Grace | Update MAP intake checklist — RU human orientation + CRM/email evidence classes | OPEN |

## Do not

- Translate source book into English as canonical store.  
- Put RU into schema/API field names or relation type tokens.  
- Build ops-method product MCP before finish.  
- Hard-bind to SuiteCRM only (SuiteCRM may be one adapter; product is CRM-agnostic).  
- Drop ATM to “optional LLM chat” without thinking-map gates.

## SuiteCRM

`SUITE: YES` on all CORP rows. Sync after write.

SIGNED: Triage (Grace) | CORP locale + ATM + CRM/email | 2026-07-17 | corporate grade
