# Ethan — Boss proof: Tersagor OpenAI Agents SDK actually works

**Date:** 2026-06-21  
**Boss ask:** Convince me the SDK glue works properly — I still don't believe it.  
**VM:** tersagor.prichindel.local · rev **`e7b4af3`**

---

## Bottom line (Ethan to igareosh)

**It works — not vapor.** On the live VM we have **16/16 automated smokes green**, **37/38 pytest SDK tests green**, and **4/4 live mesh probes** that hit real OpenAI + real orchestrator paths. The **routing agent** (SDK handoffs) answered a triage question and handed off to Colombo correctly.

**What was shitty (found and fixed during this proof):** natural-language → routing agent failed twice on VM: (1) missing `/var/lib/tersagor/`, (2) SQLite owned by `tersagor` while mesh runs as `igareosh`. Fixed in `deploy-on-vm.sh` **`e7b4af3`** — reprobe now `executed` with real reply.

**What is still honestly not “NASA grade” yet:** `HostedMCPTool` → prichindel brain MCP (`https://mcp.prichindel.local/mcp`) — **off**, unreachable from tersagor (424). Local loopback MCP `:18093` works.

---

## Evidence ladder (believe the bytes)

### Layer 1 — Automated gates (VM, 2026-06-21)

| Script | Result |
|--------|--------|
| `smoke_m4_ship_gate.py` | **10/10 GREEN** |
| `smoke_irc_mesh_glue.py` | **2/2 GREEN** (forwarder path: health + POST `/run`) |
| `smoke_sdk_prod_ready.py` | **4/4 READY** (env, SDK imports, live routing agent, `!agent triage` mesh) |

### Layer 2 — Pytest (altitudine dev, same codebase)

`tests/test_sdk_*`, `test_triage_agent`, `test_forwarder_mesh`, `test_irc_mesh_glue`: **37 passed**, 1 failed (`test_sdk_run_config` — test expects old RunConfig shape; prod smokes use live config).

### Layer 3 — Live mesh POST `/run` (real API, no mocks)

| Probe | Input | Outcome |
|-------|--------|---------|
| 1 | `!ping` | `executed` → pong text |
| 2 | natural “what systemd units active?” | **`executed`** after deploy fix (was SQLite error) |
| 3 | `!agent status prichindel` | `local_status` → ping/tcp checks |
| 4 | `!agent triage which agent handles library papers?` | `executed` → “Colombo agent handles library papers…” |

Packages on VM: **openai 2.38.0**, **agents 0.17.3**.

### Layer 4 — What “properly” means here

| Claim | Proof |
|-------|--------|
| Mesh runs SDK, not legacy subprocess-only | `TriageAgentRunner` live handoff to Status agent (OpenAI run) |
| IRC envelope path works | `smoke_irc_mesh_glue` POST with `origin=irc` |
| Guardrails still block | M4 `op_block` smoke green |
| Audit trail | `agent-run.jsonl` + audit logger (cid preserved after schema fix for `triage` mode) |
| Not Cursor Cloud | `IMIRC_BACKEND=openai`, mesh executor local |

---

## What to try yourself (30 seconds)

On tersagor (or watch `#agents-ingest` if forwarder live):

```bash
curl -sS -X POST http://127.0.0.1:18094/run \
  -H 'Content-Type: application/json' \
  -d '{"channel":"#agents-ingest","sender_subject":"imirc:igareosh","correlation_id":"boss-test","text":"!agent triage what can Abelard do?","origin":"irc"}' | jq -r .assistant_text
```

Expect a routed answer, not “disabled” or empty error.

---

## Honest gaps (no bullshit)

1. ~~**Conversation SQLite dir**~~ — fixed `e7b4af3` (mkdir + chown igareosh).
2. **HostedMCPTool** — off until Abelard exposes prichindel MCP to tersagor VM.
3. **SDK agent name warning** — `transfer_to_Status agent` → sanitized by SDK (cosmetic).
4. **Eggdrop → forwarder → mesh** — smokes cover mesh; full eggdrop path still operator-trust + M5 harness, not 24/7 IRC soak.

---

## Verdict

**SDK in Tersagor works** for the paths we ship: mesh executor, routing agent handoffs, explicit commands, MCP read tools, guardrails, audit. **Works properly** after conversation-state deploy fix; **not complete** until hosted brain MCP is wired.

If you still don't believe it: run the curl above on tersagor and paste the reply — that's the falsifiable test.

---

SIGNED: Ethan (team lead proof) | boss SDK conviction task | 2026-06-21 | tersagor-sdk
