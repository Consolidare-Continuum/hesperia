# Grace triage — SuiteCRM 8.10 company CRM on prichindel

**Date:** 2026-06-17  
**Source:** Operator — company CRM for Cursor agents + igareosh UI; **SuiteCRM 8.10.1** on **prichindel** at **`https://suite.prichindel.local`** (LAN / Tailscale).  
**Register:** [governance/SUITE-CRM-2026-REGISTER.md](../../governance/SUITE-CRM-2026-REGISTER.md)  
**Prior spec:** Ethan cluster placement (2026-06-17) — prichindel Docker, not k3d; Planfix stays client CRM.

---

## Triage outcome

**PROJECT-CREATED** — **SUITE-CRM-00..08** on [active.md](../../active.md).  
**Project:** `cluster` · **integration** + **infra**  
**Host:** **prichindel** VM 107 on alunel (`192.168.100.21`)  
**URL:** `https://suite.prichindel.local` (not public; no vaporas)  
**Version:** **8.10.1** (maintenance fix for Studio core-field regression)

---

## Problem statement

| Today | Gap |
|-------|-----|
| **Planfix** (`biopole-md`) | Client CRM only — Biopole business |
| No self-hosted company CRM | Agents lack structured Accounts/Contacts/Tasks/Cases on-cluster |
| php81_fpm on prichindel | PHP 8.1 — **cannot** run SuiteCRM 8.10 (needs 8.2–8.4) |

**Operator ask:** Install and operate SuiteCRM on prichindel at **`suite.prichindel.local`** for company use (Cursor API path + human UI).

---

## Architecture decision (Grace → Abelard execute)

| Layer | Choice |
|-------|--------|
| Runtime | Docker Compose under `/data/docker/suitecrm/` |
| Image | `guerchele/suitecrm:8.10.1` (Apache + PHP 8.3 + messenger worker + cron) |
| Database | Dedicated **MariaDB 10.11** container (isolated from shared `mysql_db`) |
| Upstream | `127.0.0.1:8082` — nginx on prichindel only |
| Ingress | **LAN/Tailscale HTTPS** — `nginx-suite.prichindel.local.conf`; self-signed TLS |
| DNS | **AD A record** `suite.prichindel.local` → `192.168.100.21`; cluster `/etc/hosts` alias on deploy |
| Public | **None** — no vaporas, no Cloudflare for `.local` |
| Auth (phase 1) | SuiteCRM admin login; Authentik SSO **BACKLOG** |
| Agent API (phase 2) | V8 JSON API + n8n — **Gena** after operational |

**Coexistence:** Planfix unchanged. Biopole n8n flows unchanged.

---

## Wave map

| ID | Owner | Focus |
|----|-------|--------|
| SUITE-CRM-00 | Grace | Triage + register (this packet) |
| SUITE-CRM-01 | Abelard | Docker stack — compose, secrets, volumes, `docker compose up` |
| SUITE-CRM-02 | Abelard | nginx vhost + self-signed TLS for `suite.prichindel.local` |
| SUITE-CRM-03 | Abelard | DNS — AD A record + cluster hosts alias |
| SUITE-CRM-04 | Abelard | Verify install — HTTP 200, messenger worker, `suitecrm:version` |
| SUITE-CRM-05 | Gena | V8 API OAuth client + n8n credential (phase 2) |
| SUITE-CRM-06 | Daniel | SECURITY-BASELINE — LAN-only boundary, creds path |
| SUITE-CRM-07 | Liam | SCRIPT-RUNBOOK-suitecrm-prichindel.md |
| SUITE-CRM-08 | Grace | Wave closure when SUITE-CRM-01..04 DONE |

---

## Start order

1. **SUITE-CRM-01..04** (Abelard) — install + operational on LAN  
2. **SUITE-CRM-05** (Gena) — after admin can log in  
3. **SUITE-CRM-06..07** parallel after 04  
4. **SUITE-CRM-08** (Grace) — closure

---

SIGNED: Triage (Grace) | SUITE-CRM PROJECT-CREATED | 2026-06-17 | SuiteCRM on prichindel
