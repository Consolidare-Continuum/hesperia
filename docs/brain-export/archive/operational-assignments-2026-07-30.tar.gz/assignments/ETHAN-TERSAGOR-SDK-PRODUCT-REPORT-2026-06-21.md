# Ethan — Tersagor SDK integration & product report

**Date:** 2026-06-21  
**Session:** altitudine dev office · LAN  
**Operator:** igareosh  
**Author:** Cursor (Ethan track)  
**Upstream:** [openai/openai-agents-python](https://github.com/openai/openai-agents-python) (target **0.17.x**, latest release **v0.17.6**)

---

## Executive summary

**Tersagor is a prichindel.com product** — edge runtime on `tersagor.prichindel.local` (Telegram + IM-IRC mesh + OpenAI Agents SDK). It is **not** a dev playground and **not** a Cursor IDE substitute. Cursor remains the brain/dev office; tersagor is the **holy-spirit edge** that operators and clients touch through controlled channels.

**2026-06-21 outcome:** The **50-task SDK wave** (`TSDK-001..050`) and **M5 IRC mesh confidence wave** (`TSDK-051..080`) are triaged on [active.md](../../active.md). Code lives on **igareosh/tersagor** (`/data/tersagor`, HEAD through M5 glue commits). Prod triage agent stays **`TERSAGOR_TRIAGE_AGENT_ENABLED=0`** until operator M5 sign-off ([TERSAGOR-M5-OPERATOR-SIGNOFF.md](TERSAGOR-M5-OPERATOR-SIGNOFF.md)).

**First commercial target:** **Biopole** — NASA-grade replacement for Serghei's small-crops Q&A when OpenAI tombstones Assistants (Detelina-class service). That is a **future subagent** on tersagor, not Telegram feature dev.

---

## What we snitched from openai-agents-python (in scope)

| SDK concept | Tersagor module / behavior | Tasks |
|-------------|---------------------------|-------|
| Agent + Runner + RunConfig | `sdk/run_config.py`, `openai_agents_adapter.py` | 001–010 |
| RunHooks → audit JSONL | `sdk/hooks.py`, `audit_log.py` | 004, 007 |
| Handoffs + agents-as-tools | `triage_agent.py`, `TriageAgentRunner` | 013–020 |
| Guardrails (input/output/tool + LLM judge) | `sdk/guardrails/*` | 021–028 |
| Human-in-the-loop | `abelard/guarded_runner.py` ↔ approval `:18090` | 029–033 |
| Sessions (SQLiteSession, compaction) | `sdk/session_factory.py`, `conversation_state.py` | 034–039 |
| IRC session (drop `irc_recent` hack) | `irc_session.py`, forwarder glue | 037, M5 072 |
| MCP + ToolSearchTool | `hosted_mcp.py`, `mcp/client.py`, `mcp_registry.py` | 040–043 |
| Tracing → JSONL / IRC trace | `audit_log.py`, `irc_trace.py` | 046, M5 067 |
| Read-only sandbox inspect | `abelard/sandbox_runner.py` (partial) | 047 |
| VM ship gate | `scripts/smoke_m4_ship_gate.py` 10/10 | 050 |
| IRC mesh glue | forwarder → mesh `:18094` → orchestrator | M5 051–077 |

**Custom authority preserved (non-negotiable):** `policy_gate` + `OperationExecutor`, `config/operations.yaml`, operator allowlists, approval gateway for mutating shell/SSH.

Registers: [TSDK-2026-REGISTER.md](../../governance/TSDK-2026-REGISTER.md) · [TSDK-MESH-CONF-2026-REGISTER.md](../../governance/TSDK-MESH-CONF-2026-REGISTER.md)

---

## Explicitly out of scope (operator-confirmed 2026-06-21)

Tersagor is **not dev** and will **not become dev**. Coding in Telegram is nonsense. These gaps are **accepted**, not backlog bugs:

| Gap | Why it does not matter for tersagor + IRC |
|-----|-------------------------------------------|
| **Prod triage disabled** | SDK handoffs exist; live IRC agent routing stays off until **M5 operator sign-off** (TSDK-079/080) |
| **Full SandboxAgent** (GitRepo manifest, `RunConfig.sandbox`) | TSDK-047 = read-only local inspect only; not upstream 0.17 full sandbox agent pattern |
| **Streaming / Realtime voice** | TG/IRC are message-at-a-time; no stream-to-chat product requirement |
| **Redis sessions** | Upstream optional; edge uses SQLite only |
| **LiteLLM / 100+ providers** | Not ported — OpenAI-only on tersagor edge |
| **Skills** (`.agents/skills` in upstream repo) | Not in 50-task registry; Cursor brain holds skills/rules instead |
| **Live eggdrop touch** | Harness + smokes only; signoff doc: no eggdrop change required yet |
| **Migration doc stale** | `docs/AGENTS-SDK-MIGRATION.md` checklist lagged code landing — refresh on next tersagor doc pass |
| **1 pytest red** | `test_sdk_risk_judge` — minor before calling M4 “clean” |

**SKIP rows (document only):** TSDK-024 streaming guardrails · TSDK-035 OpenAI server sessions · TSDK-048 parallelization.

---

## Product positioning — prichindel.com

| Layer | Role |
|-------|------|
| **Cursor IDE + brain repo** | Dev company office — workflow, Grace, entities, Hesperia, clients when assigned. **Not traded away.** |
| **Tersagor** | **Product** — sellable edge agent runtime for prichindel.com and clients |
| **First sale** | **Biopole** — when OpenAI revokes Assistants worldwide (Detelina tombstone), offer Serghei a **true NASA-grade** crops/agronomy assistant |

Detelina today = n8n + awareness pipeline on prichindel ([cluster/DETELINA-PROD-PIPELINE.md](../../cluster/DETELINA-PROD-PIPELINE.md)). Replacement path = **tersagor subagent** with Biopole corpus (Chroma books/marketing, Planfix-aware ops via prichindel stack), not another OpenAI Assistant ID.

Client pointer: [CLIENTS/biopole.md](../../CLIENTS/biopole.md) · Serghei = domain/agronomy · igareosh = biopole IT deploy.

---

## NASA-grade specialists on tersagor (product requirement)

Two **production-grade** SDK agents must exist on tersagor — built on **openai-agents-python patterns** (handoffs, guardrails, HITL, sessions, MCP, tracing), not repo-only glue:

### 1. Abelard (administer / cluster ops)

**Purpose:** Operator-facing admin — status, guarded shell, deploy hints, cluster report, policy-gated mutating ops.

**Current code:** `src/tersagor_agent/abelard/` — `AbelardAgent`, `GuardedShellRunner`, guardrails, HITL loop.

**NASA-grade bar:**

- SDK `Agent` + `Runner` with `RunConfig` from env
- Input/output/tool guardrails + risk judge before shell
- HITL interruptions → approval gateway `:18090` with resume
- Audit JSONL + trace spans for every run
- `policy_gate` remains final mutating authority
- Handoff from triage via SDK handoffs (not regex routing)

**Doc on canonical repo:** `docs/ABELARD-AGENT.md`

### 2. Colombo (university / research / formalization)

**Purpose:** Operator university work — CHROMA-2 library, TFP/Hesperia theory pointers, EN↔RO scientific writing, Papra ingest paths.

**Current code:** `src/tersagor_agent/colombo/` — `ColomboAgent`, CHROMA-1/2 clients, library corpus tools.

**NASA-grade bar:**

- Same SDK stack as Abelard (sessions, guardrails, hooks)
- CHROMA-2 via Colombo library patterns; CHROMA-1 theory layers read-only
- Shared `SQLiteSession` with triage per chat (TSDK-038)
- Optional `WebSearchTool` off by default (`TERSAGOR_COLOMBO_WEB=0`)
- No invented implementation facts — claims tied to corpus

**Brain entity boundary:** Full entity Colombo lives in Cursor brain; tersagor Colombo = **product runtime mirror**, not duplicate entity passport. Ref: [governance/CURSOR-CHROMA-TERSAGOR-COLOMBO-BOUNDARIES.md](../../governance/CURSOR-CHROMA-TERSAGOR-COLOMBO-BOUNDARIES.md)

---

## Future: Biopole agronomy subagent (Serghei)

**Trigger:** OpenAI Assistants tombstone → Detelina service revoked for Biopole.

**Product:** Third tersagor specialist (name TBD — e.g. `biopole_agronomist` / `detelina_successor`) — **not** a fourth brain entity.

**Must use cutting-edge SDK surface (not repo-only):**

- Triage handoff → dedicated agent with Biopole system prompt + corpus tools
- `ToolSearchTool` / MCP read-only for Biopole knowledge layer
- Sessions per Serghei/chat; guardrails on output (no secret leak)
- Structured answers for small-crops questions (reference dataset / golden standard from Biopole discovery docs)
- Deploy on tersagor VM; Biopole does not get cluster SSH — read-only agronomy Q&A first

**Not in scope now:** Grace triage row creation from this report — operator or Grace opens wave when Detelina tombstone is imminent.

**Prep assets:** Biopole canon is routed through [CLIENTS/biopole.md](../../CLIENTS/biopole.md) · Chroma `layer=books`, `theme=marketing` ingest path in [cluster/chroma-server/README.md](../../cluster/chroma-server/README.md).

---

## Milestone status (2026-06-21)

| Milestone | Range | Gate | Status |
|-----------|-------|------|--------|
| **M1** | 001–012 | pytest + CI | DONE on active.md · code on tersagor |
| **M2** | 013–028 | orchestrator shrink + guardrails | DONE on active.md |
| **M3** | 029–039 | HITL + SQLiteSession | DONE on active.md |
| **M4** | 040–050 | VM 10-smoke exit 0 | DONE on active.md · Abelard TSDK-050 |
| **M5** | 051–080 | IRC mesh confidence + operator gate | **078 DONE** · **079–080 OPEN** (operator sign-off) |

**Prod flag:** `TERSAGOR_TRIAGE_AGENT_ENABLED=0` until TSDK-079 signed + TSDK-080 Abelard closure packet.

**Local verify (altitudine, 2026-06-21):** `pytest tests/test_sdk_*` — 21 passed, 1 failed (`test_sdk_risk_judge`), 6 skipped.

---

## IRC mesh architecture (reference)

```
IRC / Telegram ingest
        │
        ▼
  forwarder (envelope v1, allowlist, correlation_id)
        │
        ▼
  mesh executor :18094/run
        │
        ▼
  orchestrator → TriageAgentRunner → SDK handoffs
        │              ├── Abelard (ops, guarded)
        │              ├── Colombo (research)
        │              └── [future] Biopole agronomist
        ▼
  audit JSONL + optional irc_trace
```

Runbook (canonical repo): `docs/M5-IRC-MESH-CONFIDENCE.md` · harness: `docs/IRC-MESH-TEST-HARNESS.md`

---

## What Cursor does vs what tersagor product does

| Concern | Cursor | Tersagor product |
|---------|--------|------------------|
| Dev / Hesperia / brain edits | Yes | No |
| Workflow / Grace / active.md | Yes | No (notify only) |
| Client code (Biopole GAS, etc.) | Gena when assigned | No |
| Operator admin via IRC/TG | No (IDE) | Abelard |
| University / papers / library | Colombo entity in IDE | Colombo runtime on edge |
| Sellable client assistant | No | Biopole first |

---

## Next actions (ordered)

1. **Operator:** Complete [TERSAGOR-M5-OPERATOR-SIGNOFF.md](TERSAGOR-M5-OPERATOR-SIGNOFF.md) (TSDK-079) — decide triage enable YES/NO.
2. **Abelard:** M5 closure packet for igareosh (TSDK-080) after 077 green on VM.
3. **Felix/Gena:** Fix `test_sdk_risk_judge` on tersagor; refresh `docs/AGENTS-SDK-MIGRATION.md` checklist to match landed code.
4. **Ethan/product:** When Detelina tombstone confirmed → Grace triage **Biopole agronomy subagent wave** on tersagor (SDK-native, corpus-backed, Serghei-facing).
5. **Maintain NASA-grade bar:** Abelard + Colombo runs must stay on openai-agents-python primitives (Runner, guardrails, HITL, sessions, MCP, tracing) — not regress to orchestrator regex-only paths.

---

## Canonical links

| Resource | URL / path |
|----------|------------|
| Tersagor repo | https://github.com/igareosh/tersagor |
| 50 tasks | `tasks/AGENTS-SDK-50-TASKS.md` |
| M5 tasks | `tasks/AGENTS-SDK-MESH-30-TASKS.md` |
| SDK migration | `docs/AGENTS-SDK-MIGRATION.md` |
| OpenAI Agents SDK | https://github.com/openai/openai-agents-python |
| SDK docs | https://openai.github.io/openai-agents-python/ |
| Brain cluster stub | [cluster/tersagor/README.md](../../cluster/tersagor/README.md) |
| Project folder | [projects/tersagor-sdk/](../../projects/tersagor-sdk/) |

---

SIGNED: Cursor | Ethan tersagor SDK + product report | 2026-06-21 | prichindel.com product · Biopole first sale path
