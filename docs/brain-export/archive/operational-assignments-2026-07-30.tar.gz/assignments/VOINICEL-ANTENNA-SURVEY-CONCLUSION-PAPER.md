# Antenna Mount Survey-In on a Fixed Multipath-Rich Site: Outcomes, Environmental Limits, and Operational Positioning Tier

**Document type:** Survey conclusion paper  
**Mount identifier:** `voinicel-sma-rail-magnet-01`  
**Node:** voinicel · u-blox LEA-M8T-0 · WD22UGRC VER.C  
**Antenna:** MikroTik magnetic-mount active GNSS antenna (SMA, 3.3 V bias)  
**Research owner:** Colombo  
**Data basis:** Survey log bundle v1 (25 h window) and full edge archive through 35.8 h active survey-in  
**Date:** 2026-06-20  
**PDF (branded):** [VOINICEL-ANTENNA-SURVEY-CONCLUSION-PAPER.pdf](VOINICEL-ANTENNA-SURVEY-CONCLUSION-PAPER.pdf) — regenerate: `python3 operational/assignments/build_voinicel_survey_conclusion_pdf.py`  
**Cross-references:** [VOINICEL-SURVEY-LOG-V1-25H.md](voinicel-gps-survey-reason-bundle-v1/VOINICEL-SURVEY-LOG-V1-25H.md) · [VOINICEL-SURVEY-WRAP-2026-06-20.md](VOINICEL-SURVEY-WRAP-2026-06-20.md) · [cluster/voinicel/ANTENNA-MOUNT-SURVEY.md](../cluster/voinicel/ANTENNA-MOUNT-SURVEY.md)

---

## Abstract

A maximum-duration u-blox TIM-SVIN survey-in (`svinMinDur = 86\,400\,\mathrm{s}`, `svinAccLimit = 1\,000\,\mathrm{mm}`) was executed on a mechanically fixed outdoor installation in Moldova ($\approx 47.03°\mathrm{N}$, $28.82°\mathrm{E}$) to characterize the antenna reference point (ARP) of a MikroTik magnetic-mount antenna on a horizontal ferrous rail, in proximity to a wet metal sewer stack and a utility supply mast ($\approx 5\text{–}6\,\mathrm{m}$). The survey-in **did not complete** (`\mathrm{valid} = 0`). Duration exceeded the 24 h gate; three-dimensional accuracy remained at $\approx 10\,\mathrm{m}$ ($\approx 10\%$ of the u-blox one-metre timing-reference tier). Epoch-wise position scatter reached $\approx 46\,\mathrm{m}$ horizontally and $\approx 67\,\mathrm{m}$ vertically. The installation nonetheless sustains **stratum-1 time transfer** via PVT plus pulse-per-second (PPS), with a **practical positioning lock tier of $\approx 10\,\mathrm{m}$** at the ARP. **Software or firmware alterations cannot alter the feasibility conclusions drawn from the environment**; they may only change logging, masking heuristics, or acceptance thresholds. The limiting factor is **static near-field multipath**, not mechanical instability or antenna-mount defect.

---

## 1. Introduction

### 1.1 Objective

The survey sought to determine whether a fixed outdoor ARP on voinicel could satisfy u-blox CFG-TMODE2 survey-in gates sufficient for transition to **Fixed time mode** at the **one-metre three-dimensional accuracy** level associated with nanosecond-class TIMEPULSE performance (UBX timing documentation, reference tier $\leq 1\,\mathrm{m}$ position knowledge).

### 1.2 Scope

This paper reports **environmental and instrumental outcomes** only. It does not propose code changes, receiver reprogramming, or algorithmic post-processing as remedies for the observed accuracy ceiling, because those interventions do not remove the underlying multipath geometry established by the site.

### 1.3 Operational context

The LEA-M8T installation already provides **network time protocol (NTP) stratum 1** to the cluster via **gpsd**, **NMEA shared memory**, and **PPS** to chrony. Survey-in addressed **ARP formalization** and **fixed-mode timing upgrade**, not basic time service viability.

---

## 2. Methods

### 2.1 Survey specification

| Parameter | Value |
|-----------|--------|
| `timeMode` | 1 (Survey-In) |
| `svinMinDur` | $86\,400\,\mathrm{s}$ (24 h) |
| `svinAccLimit` | $1\,000\,\mathrm{mm}$ (1.0 m 3D) |
| Start (local) | 2026-06-19 01:33:16 +03:00 |
| Completion rule | Both duration **and** accuracy gates required for `valid = 1` |

### 2.2 Mount and site description

| Element | Description |
|---------|-------------|
| Mechanical mount | MikroTik factory magnetic-mount antenna on horizontal iron rail; operator confirmed no intentional motion |
| RF path | Magnetic mount with designed isolation between ferrous cup and radiator (commercial mag-mount practice) |
| Proximate reflectors | Ferrous rail (under); metal rainwater sewer ($\approx 6\,\mathrm{m}$ above, $3\,\mathrm{m}$ below antenna horizon); utility electrical mast ($\approx 5\text{–}6\,\mathrm{m}$, fully metal, utility-grounded) |
| Electrical grounding | Utility mast bonded per grid practice; **irrelevant to L1 ($\approx 1.575\,\mathrm{GHz}$) reflection suppression** |

### 2.3 Data acquisition

- Edge monitor: 5 min cadence (`convergence.log`, `monitor.csv`, UBX TIM-SVIN poll).
- Bundle v1: 25 h window (2026-06-19 01:33:16 → 2026-06-20 02:33:16 +03:00), 301 convergence samples, hourly SVIN milestones.
- Full run: 128\,952 s ($\approx 35.8\,\mathrm{h}$) last active sample before host reboot cleared in-RAM survey state.
- Archive: [voinicel-gps-survey-reason-bundle-v1](voinicel-gps-survey-reason-bundle-v1/).

### 2.4 Metrics

| Metric | Definition | Interpretation |
|--------|------------|----------------|
| `dur` | TIM-SVIN elapsed survey time | Duration gate progress |
| `meanV` | TIM-SVIN 3D variance (mm²) | $\sigma_{3\mathrm{D}} = \sqrt{\mathrm{meanV}}$ |
| `quality_pct` | $\min(100,\; 100 \times 1000 / \sigma_{3\mathrm{D},\mathrm{mm}})$ | Percentage of 1 m reference tier |
| `valid` | TIM-SVIN completion flag | 1 = survey-in accepted |
| Epoch scatter | Range of `TPV` fixes during survey | Instantaneous multipath envelope |
| `hAcc` / `eph` | Receiver-reported horizontal accuracy | Often optimistic under multipath |

---

## 3. Results

### 3.1 Survey-in gates

| Gate | Criterion | Outcome at 24 h | Outcome at 25 h | Outcome at end of active run |
|------|-----------|-----------------|-----------------|------------------------------|
| Duration | `dur \geq 86\,400\,\mathrm{s}` | **Passed** ($86\,345\,\mathrm{s}$) | **Passed** ($89\,945\,\mathrm{s}$) | **Passed** ($128\,952\,\mathrm{s}$) |
| Accuracy | $\sigma_{3\mathrm{D}} \leq 1\,000\,\mathrm{mm}$ | **Failed** ($10\,078.9\,\mathrm{mm}$) | **Failed** ($10\,114.5\,\mathrm{mm}$) | **Failed** ($9\,961.4\,\mathrm{mm}$) |
| `valid` | 1 | **0** | **0** | **0** |

**Terminology outcome:** The receiver **correctly withheld Fixed-mode transition**. Survey-in **failed on accuracy**, not on insufficient integration time.

### 3.2 Convergence trajectory

| Phase | Time span | $\sigma_{3\mathrm{D}}$ | `quality_pct` | Terminology outcome |
|-------|-----------|------------------------|---------------|---------------------|
| Initial transient | First $\approx 10\,\mathrm{min}$ | $12.9\,\mathrm{m} \rightarrow 9.5\,\mathrm{m}$ | 7.7% → 10.5% | Rapid initial averaging; **not sustained** |
| Plateau | $\approx \mathrm{h}2$ through h25+ | $9.7\text{–}10.3\,\mathrm{m}$ | $\approx 9.9\text{–}10.3\%$ | **Environmental ceiling reached**; further integration **non-informative** |
| Post–24 h extension | +11.8 h beyond gate | $\approx 10.0\,\mathrm{m}$ | $\approx 10.0\%$ | **Temporal extension did not improve accuracy** |

### 3.3 Epoch-wise positioning scatter (233 monitored 3D fixes)

| Component | Observed spread | Terminology outcome |
|-----------|-----------------|---------------------|
| Horizontal | $\approx 46\,\mathrm{m}$ | **Strong horizontal multipath** on fixed mount |
| Altitude (MSL) | $\approx 67\,\mathrm{m}$ | **Vertical domination** of error budget |
| Mean `eph` | $\approx 18.9\,\mathrm{m}$ | Reported horizontal uncertainty **understates** observed scatter |
| Mean `epv` | $\approx 35.1\,\mathrm{m}$ | Vertical uncertainty $\approx 1.9\times$ horizontal |

**Terminology outcome:** The antenna did not move; **pseudorange solutions wandered** within a $\approx 50\text{–}100\,\mathrm{m}$ instantaneous envelope. Long-term averaging compressed this to $\approx 10\,\mathrm{m}$ on the TIM-SVIN mean — **not** to the 1 m tier.

### 3.4 Preliminary ARP (running mean, `valid = 0`)

| Quantity | Value | Status |
|----------|-------|--------|
| Latitude | $47.027826°\,\mathrm{N}$ | **Indicative only** |
| Longitude | $28.821180°\,\mathrm{E}$ | **Indicative only** |
| ECEF (cm) | $X=381599418$, $Y=209969789$, $Z=464397471$ | **Not certified ARP** |
| Observations integrated | 128\,953 | Sufficient for mean stability |
| $\sigma_{3\mathrm{D}}$ at end | $9\,961.4\,\mathrm{mm}$ | **Fails reference tier** |

### 3.5 Sky and geometry

| Parameter | Typical value | Terminology outcome |
|-----------|---------------|---------------------|
| `numSV` | 10–11 | Adequate constellation use |
| `pDOP` | 1.5–2.6 | Acceptable geometry |
| `tDOP` | 0.84–1.88 | Timing geometry not the bottleneck |

**Terminology outcome:** Failure is **not** attributable to satellite shortage or poor dilution of precision alone.

### 3.6 Operational time service (parallel path)

| Service | Mechanism | Outcome |
|---------|-----------|---------|
| Stratum 1 NTP | chrony ← PPS + NMEA (gpsd) | **Operational** (documented pre-survey) |
| 3D fix class | `fixType = 3` sustained | **Continuous lock** |
| Practical position tier | PVT + survey mean | **$\approx 10\,\mathrm{m}$** at ARP under site multipath |

**Terminology outcome:** **Stratum 1 at $\approx 10\,\mathrm{m}$ GPS position lock** is what the installation **in fact achieves**. Nanosecond-tier **surveyed** ARP lock at 1 m is **not** achieved.

### 3.7 Termination

The active survey ended after $\approx 35.8\,\mathrm{h}$ when the host rebooted, clearing in-RAM TIM-SVIN state (`timeMode = 0`). This event is **infrastructure-related** and **immaterial** to the accuracy conclusion: the 1 m gate had **already failed** at the 24 h boundary and throughout the extension.

---

## 4. Discussion

### 4.1 Mechanical stability versus ranging stability

**Reasoning:** A fixed magnetic-mount antenna on a rigid rail exhibits **mechanical stationarity**.

**Result:** Running-mean ECEF components drift $\approx 2\text{–}3\,\mathrm{m}$ over 25 h without step discontinuities. **Mechanical stability is confirmed.**

**Reasoning:** TIM-SVIN measures the **statistical spread of epoch-wise 3D fixes**, not physical motion.

**Result:** $\sigma_{3\mathrm{D}} \approx 10\,\mathrm{m}$ with 128\,000+ observations indicates **persistent ranging bias and multipath**, not antenna displacement.

### 4.2 Antenna design versus site reflectors

**Reasoning:** MikroTik magnetic-mount antennas incorporate intentional RF isolation between the magnetic base and the active element.

**Result:** The mount is **fit for purpose** for router-class GNSS. **Magnetic mounting is not the failure mode.**

**Reasoning:** Close metallic structures (rail, sewer, utility mast within $\approx 6\,\mathrm{m}$) produce **static specular and diffuse L1 reflections**.

**Result:** Epoch scatter $\approx 46\text{–}67\,\mathrm{m}$ and vertical dominance match **near-field multipath** from multiple fixed reflectors. Utility **electrical grounding** does not absorb or decouple GPS energy.

### 4.3 Temporal averaging under static multipath

**Reasoning:** Random white measurement noise averages down with $\sqrt{N}$.

**Result:** Early minutes show slight $\sigma_{3\mathrm{D}}$ reduction, then **plateau** for 23+ hours.

**Terminology outcome:** Errors are **correlated and site-structured**, not independent noise. **Extended survey-in is not an effective mitigation** at this ARP.

### 4.4 Code, firmware, and masking interventions

**Reasoning:** Receiver polls, logging cadence, dynamic PRN blacklists, or global minimum-elevation masks alter **which measurements are consumed** or **how they are recorded**.

**Result:** None remove the **physical reflectors** or the **$\approx 10\,\mathrm{m}$ site accuracy ceiling** demonstrated over 25–36 h.

**Terminology outcome:** **Altering code does not benefit the feasibility of environmental conclusions.** It may support **diagnostics** (e.g. NAV-SAT sky plots) or **acceptance-policy changes** (e.g. relaxed `svinAccLimit`), but **cannot reclassify a static multipath-rich volume as a one-metre timing-reference site**.

### 4.5 Achieved versus targeted tier

| Tier | Target | Achieved | Terminology |
|------|--------|----------|-------------|
| u-blox timing reference | $\sigma_{3\mathrm{D}} \leq 1\,\mathrm{m}$, `valid = 1` | **Not achieved** | Survey-in **incomplete** |
| Long-mean site ARP | Stable ECEF mean | **Achieved at $\approx 10\,\mathrm{m}$** | **Site-class ARP**, not reference-class |
| Stratum 1 time | PPS-disciplined NTP | **Achieved** | **Primary operational outcome** |
| Instantaneous PVT | Continuous 3D fix | **Achieved** with large epoch scatter | **Coarse conning** only |

---

## 5. Conclusions

1. **Survey-in at `svinAccLimit = 1\,000\,\mathrm{mm}$ is not feasible** at ARP `voinicel-sma-rail-magnet-01` given the documented static environment, independent of integration beyond 24 h.

2. **The limiting phenomenon is near-field multipath** from ferrous rail, proximate wet metal sewer, and utility mast ($\approx 5\text{–}6\,\mathrm{m}$), producing $\approx 50\text{–}100\,\mathrm{m}$ instantaneous fix excursion and a **stabilized $\approx 10\,\mathrm{m}$ three-dimensional mean**.

3. **Mechanical stationarity and mag-mount antenna integrity are not in question.** The data refute motion and mount-defect hypotheses.

4. **What is in fact achieved:** **stratum-1 time service with $\approx 10\,\mathrm{m}$ GPS position lock** at the ARP — suitable for cluster timing, **unsuitable** for one-metre Fixed-mode timing survey certification without **environmental change** or **explicit relaxation of accuracy requirements**.

5. **Software modification is not a path to overturning these environmental conclusions.** It may document, mask, or re-tier acceptance; it **cannot** convert the site into a u-blox one-metre reference installation by code alone.

---

## 6. Recommendations (non-code)

| Intent | Recommendation |
|--------|----------------|
| Maintain stratum 1 | Continue PVT + PPS; **do not depend** on survey-in `valid` |
| If Fixed-mode ARP required | Re-survey with `svinAccLimit` matched to site tier ($\approx 10\,\mathrm{m}$) **or** relocate antenna away from sewer/mast/rail line |
| If higher tier required | Physical RF mitigation (spacing, elevation, absorbers) — **not** repository script changes |
| Documentation | Treat v1 bundle as **site characterization record** for this ARP |

---

## References (internal)

- u-blox UBX-13003221 §25.3 (CFG-TMODE2 / TIM-SVIN)
- [cluster/voinicel/GPS-STRATUM1-SETUP.md](../cluster/voinicel/GPS-STRATUM1-SETUP.md)
- [agents/colombo/VOINICEL-ANTENNA-SURVEY.md](../agents/colombo/VOINICEL-ANTENNA-SURVEY.md)
- Data: [voinicel-gps-survey-reason-bundle-v1/](voinicel-gps-survey-reason-bundle-v1/)

---

SIGNED: Research (Colombo) | survey conclusion paper | 2026-06-20 | voinicel-sma-rail-magnet-01 · stratum 1 at ~10 m lock
