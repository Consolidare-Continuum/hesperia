# Grace — FREEZE LIFT + CORE-F carve-out

**Owner:** Grace · **Date:** 2026-07-22 · **Project:** ops-method  
**Operator:** chat — **"no more freezes, proceed unbounded to finish up full auto team run"** (2026-07-22).

## Carve-out (Means table)

Explicit exception to “Second book prep while freeze HOLD”:

- **CORE-F-02** schema migration (author / cross-pack columns) — **ALLOWED**
- **CORE-F-04** synthetic dummy-pack smoke — **ALLOWED** (no real second-book content)

Same transparency pattern as MAP-05/CORP-04/05/CSS-13 archival edits.

## Freeze status

**LIFTED** for ops-method RYB-ED01 completion work and CORE harden unbounded finish.

Exit criteria checklist updated on [FREEZE-UNTIL-BOOK-COMPLETE.md](../../projects/ops-method/FREEZE-UNTIL-BOOK-COMPLETE.md). Standing rejector (FRZ-02) stands down for CORE/F/schema work; new *real* second-book content packs still require Ethan+Grace intake (product rule), but freeze HOLD no longer blocks CORE finish.

SIGNED: Triage (Grace) | freeze lift + F carve-out | 2026-07-22 | operator unbounded
