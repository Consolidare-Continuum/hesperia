# METRIC-08 — API distance fields audit (metric_layer)

**Date:** 2026-06-22  
**Owner:** Marcus  
**Spec:** [24_SPEC §3](../user_documents/HESPERIA_ACADEMIA/24_SPEC__Hesperia_Metric_and_Distance_v0_1.md)

## Finding

Public/shipping API responses that expose numeric separation **must** qualify `metric_layer` in field names or adjacent metadata. Bare keys `distance`, `similarity_distance`, or `path_length` without layer context are **non-compliant**.

## Current surface (v0.6)

| Surface | Status | Action |
|---------|--------|--------|
| `POST /analyze` + `engine_result` | OK — scalars are governance/loopability, not distance claims | No change |
| `meta.hesperia_metric` (flag) | OK — registry lists `layers_active` | METRIC-20 DONE |
| Compare / batch summaries | Review — document if any delta fields imply distance | METRIC-16 Olivia |

## Recommendation

Add OpenAPI description strings: “not a geodesic distance unless `metric_layer` is set.” SECURITY-BASELINE cross-ref → METRIC-33.

**SIGNED: Audit (Marcus) | METRIC-08 | 2026-06-22**
