# fpf-thinking-map — PyPI integration (brain)

**Canonical install:** [PyPI fpf-thinking-map](https://pypi.org/project/fpf-thinking-map/) **==1.2.1**

```bash
bash scripts/install-thinking-map.sh   # pip install -r requirements-thinking-map.txt
bash scripts/verify-thinking-map-mcp.sh
```

## Library canonical (Move layer)

**Engine semantics live in the PyPI package only** — guards, TTL evidence, logic glue, outcomes, `response_contract`, verify harness. The operator sealed that speech in the library; **brain repo does not re-document or re-derive Move rules in prose.**

| Layer | Canonical source | Brain repo owns |
|-------|------------------|-----------------|
| Context | CHROMA-1 + `query_knowledge` | ingest, rules, books |
| Task | active.md + pipeline MCP | workflow automation |
| **Move** | **`fpf-thinking-map` (PyPI)** + domain maps | triggers, MCP wire, `team_ops` / `cluster_ops` maps |

**Agents:** call **`thinking_map_step`** → read returned JSON (`kind`, `missing_evidence`, `gate_status`, `llm_prompt_state`, `logic`, `response_contract`) → obey. Do not invent parallel move logic in chat.

Health: `thinking_map_verify` (19 checks) or `python -m fpf_thinking_map.verify`.

## Import pattern (domain maps)

Brain domain maps import via **`thinking_maps.engine`** — not vendored code at repo root:

```python
from thinking_maps.engine import (
    SemanticMap, RuntimeBinding, ThinkingMapTraversal,
    ContextPrimitive, RolePrimitive, GatePrimitive, TransitionPrimitive,
    LogicLayer, DecisionRule, RuleKind, EvidenceFresh, OutcomeKind,
)
```

Engine package (PyPI) owns primitives, guards, traversal, verify harness.

## MCP (Move layer)

| Tool | When |
|------|------|
| `thinking_map_step` | Mandatory triggers — read `kind`, `blockers`, `llm_prompt_state`, `response_contract` |
| `thinking_map_verify` | 19/19 package checks |
| `list_thinking_maps` | `team_ops`, `cluster_ops` |

**Flow:** `query_knowledge` → `get_current_step` → **`thinking_map_step`** (if trigger) → execute → `report_done`

Policy: [governance/SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md](../governance/SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md) · Runbook: `SCRIPT-RUNBOOK-thinking-map-session`

## Hosts

| Host | Venv | Verify |
|------|------|--------|
| prichindel | `/data/chroma/venv` | MCP SSH target |
| alunel | `/data/chroma/venv` | CHROMA-1 co-located |
| altitudine | pyenv or chroma venv | dev pytest |

Ref: [cluster/prichindel/MCP-PYTHON-THINKING-MAP.md](../cluster/prichindel/MCP-PYTHON-THINKING-MAP.md)
