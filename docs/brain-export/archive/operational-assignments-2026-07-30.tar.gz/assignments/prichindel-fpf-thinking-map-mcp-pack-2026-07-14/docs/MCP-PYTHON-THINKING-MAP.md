# Prichindel MCP Python environment — thinking map dependency

**Owner**: Sophia · **ATM-71**

MCP servers on **prichindel** run via `/data/chroma/venv/bin/python`.

## fpf-thinking-map install

```bash
/data/chroma/venv/bin/pip install -r /data/workspaces/cursor/requirements-thinking-map.txt
bash /data/workspaces/cursor/scripts/verify-thinking-map-mcp.sh
```

Pin: **v1.2.1** from [PyPI fpf-thinking-map](https://pypi.org/project/fpf-thinking-map/) (`requirements-thinking-map.txt`).

## MCP module

`python -m agent_mcp_thinking_map` — requires repo on `PYTHONPATH` and package in venv.

## Maintenance cadence (ATM-53)

Include `verify-thinking-map-mcp.sh` in Abelard maintenance / post-deploy checks alongside MCP appendix verify.

SIGNED: Ops (Sophia) | ATM wave | 2026-06-28 | prichindel venv
