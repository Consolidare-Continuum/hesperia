"""Trace persistence for thinking map MCP (no FastMCP import)."""

from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from typing import Any


def trace_enabled() -> bool:
    return os.environ.get("THINKING_MAP_TRACE", "1").strip().lower() not in ("0", "false", "no")


def write_trace(
    repo_root: Path,
    map_id: str,
    task: str,
    outcome: Any,
    *,
    trigger: str = "thinking_map_step",
    task_id: str = "",
) -> None:
    if not trace_enabled():
        return
    gov = repo_root / "governance"
    gov.mkdir(parents=True, exist_ok=True)
    blockers = getattr(outcome, "blockers", None) or []
    if isinstance(blockers, str):
        blockers = [blockers]
    row = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "trace_id": uuid.uuid4().hex[:12],
        "map_id": map_id,
        "trigger": trigger,
        "mcp_id": os.environ.get("THINKING_MAP_MCP_ID", ""),
        "key_point_id": os.environ.get("THINKING_MAP_KEY_POINT_ID", ""),
        "task": task[:200],
        "task_id": task_id.strip(),
        "outcome_kind": str(getattr(outcome, "kind", "")),
        "blockers": list(blockers) if blockers else [],
        "required_gate_id": getattr(outcome, "required_gate_id", None),
        "execution_host": os.environ.get("THINKING_MAP_EXECUTION_HOST", ""),
    }
    (gov / "thinking_map_last.json").write_text(json.dumps(row, indent=2), encoding="utf-8")
    with (gov / "thinking_map_trace.jsonl").open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")

    try:
        from thinking_maps.blocker_registry import register_from_outcome

        reg = register_from_outcome(
            repo_root,
            map_id=map_id,
            task=task,
            outcome=outcome,
            trigger=trigger,
            task_id=task_id,
            trace_id=row["trace_id"],
        )
        if reg:
            row["blocker_id"] = reg["blocker_id"]
            (gov / "thinking_map_last.json").write_text(json.dumps(row, indent=2), encoding="utf-8")
    except Exception:
        pass
