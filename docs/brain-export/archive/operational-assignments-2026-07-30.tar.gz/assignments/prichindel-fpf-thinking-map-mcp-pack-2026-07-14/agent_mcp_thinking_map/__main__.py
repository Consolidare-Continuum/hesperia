"""MCP server: Agentic Thinking Map — lawful next move for team/cluster ops."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from fpf_thinking_map.state import RuntimeBinding
from fpf_thinking_map.traversal import ThinkingMapTraversal

from thinking_maps.cluster_ops.map import build_cluster_ops_map
from thinking_maps.eod_ops.map import build_eod_ops_map
from thinking_maps.engine import OutcomeKind
from thinking_maps.team_ops.map import build_team_ops_logic, build_team_ops_map

from agent_mcp_thinking_map.trace_io import write_trace

mcp = FastMCP("cursor-thinking-map")

MAP_BUILDERS: dict[str, Any] = {
    "team_ops": build_team_ops_map,
    "cluster_ops": build_cluster_ops_map,
    "eod_ops": build_eod_ops_map,
}

LOGIC_BUILDERS: dict[str, Any] = {
    "team_ops": build_team_ops_logic,
}


def _repo_root() -> Path:
    for env in ("CURSOR_REPO_ROOT", "WORKFLOW_REPO_ROOT", "MCP_REPO_ROOT"):
        v = os.environ.get(env, "").strip()
        if v and Path(v).is_dir():
            return Path(v)
    return Path.cwd()


def _engine(map_id: str) -> ThinkingMapTraversal:
    if map_id not in MAP_BUILDERS:
        raise ValueError(f"unknown map_id: {map_id}; use list_thinking_maps")
    sm = MAP_BUILDERS[map_id]()
    logic = LOGIC_BUILDERS[map_id]() if map_id in LOGIC_BUILDERS else None
    return ThinkingMapTraversal(sm, logic_layer=logic)


def _outcome_json(outcome: Any) -> str:
    llm = getattr(outcome, "llm_prompt_state", None)
    response_contract = None
    if isinstance(llm, dict):
        response_contract = llm.get("response_contract")
    payload = {
        "kind": str(outcome.kind),
        "reason": getattr(outcome, "reason", ""),
        "next_state": getattr(outcome, "next_state", None),
        "missing_evidence": getattr(outcome, "missing_evidence", None),
        "blockers": getattr(outcome, "blockers", None),
        "llm_prompt_state": llm,
        "response_contract": response_contract,
    }
    return json.dumps(payload, indent=2, default=str)


@mcp.tool(description="List brain-repo domain thinking map ids and descriptions.")
def list_thinking_maps() -> str:
    rows = [
        {"map_id": "team_ops", "description": "Grace triage, proceed gates, report_done chain"},
        {"map_id": "cluster_ops", "description": "Abelard cluster SSH, trustmaster, cert guards"},
        {"map_id": "eod_ops", "description": "Cursor end-of-day collect, consolidate, commit, Chroma"},
    ]
    return json.dumps(rows, indent=2)


@mcp.tool(description="Run package self-verification (19 checks). Requires fpf_thinking_map v1.2.1+.")
def thinking_map_verify() -> str:
    import subprocess
    import sys

    proc = subprocess.run(
        [sys.executable, "-m", "fpf_thinking_map.verify"],
        capture_output=True,
        text=True,
        cwd=str(_repo_root()),
        timeout=60,
    )
    out = (proc.stdout or "") + (proc.stderr or "")
    if proc.returncode != 0:
        return f"ERROR: verify exit {proc.returncode}\n{out}"
    return out.strip() or "OK"


@mcp.tool(
    description="One lawful traversal step. Returns outcome kind, blockers, llm_prompt_state + response_contract."
)
def thinking_map_step(
    map_id: str = "team_ops",
    task: str = "",
    actor_role_ids: str = "task_owner",
    active_context_id: str = "",
    current_state: str = "start",
    current_evidence: str = "",
    task_id: str = "",
) -> str:
    try:
        engine = _engine(map_id)
    except ValueError as exc:
        return f"ERROR: {exc}"
    roles = [r.strip() for r in actor_role_ids.split(",") if r.strip()]
    evidence = [e.strip() for e in current_evidence.split(",") if e.strip()]
    ctx = active_context_id.strip() or (
        "cursor_eod" if map_id == "eod_ops" else ("team_workflow" if map_id == "team_ops" else "cluster_ops")
    )
    binding = RuntimeBinding(
        task=task or "workflow step",
        actor_role_ids=roles,
        active_context_id=ctx,
        current_evidence=evidence,
    )
    state = engine.build_active_state(binding, current_state=current_state)
    outcome = engine.step(state)
    write_trace(_repo_root(), map_id, task or "workflow step", outcome, task_id=task_id)
    return _outcome_json(outcome)


@mcp.tool(description="Debug: current move slice without advancing (same as step for single-step engine).")
def get_thinking_map_slice(
    map_id: str = "team_ops",
    task: str = "",
    actor_role_ids: str = "task_owner",
    active_context_id: str = "",
    current_state: str = "start",
    current_evidence: str = "",
) -> str:
    return thinking_map_step(
        map_id=map_id,
        task=task,
        actor_role_ids=actor_role_ids,
        active_context_id=active_context_id,
        current_state=current_state,
        current_evidence=current_evidence,
    )


@mcp.tool(description="List all MCP servers and key fpf-thinking-map inquiry points (registry v1).")
def list_mcp_inquiry_points(mcp_id: str = "") -> str:
    from thinking_maps.mcp_inquiry import key_points_for_mcp, list_key_points

    points = key_points_for_mcp(mcp_id) if mcp_id.strip() else list_key_points()
    rows = [
        {
            "id": p.id,
            "mcp": p.mcp,
            "tool": p.tool,
            "inquiry": p.inquiry,
            "evidence_token": p.evidence_token,
            "map_id": p.map_id,
            "current_state": p.current_state,
        }
        for p in points
    ]
    return json.dumps(rows, indent=2)


@mcp.tool(description="Checklist for an inquiry chain — which MCP calls + evidence still missing.")
def get_mcp_inquiry_chain(
    chain_id: str,
    current_evidence: str = "",
) -> str:
    from thinking_maps.mcp_inquiry import chain_checklist

    evidence = [e.strip() for e in current_evidence.split(",") if e.strip()]
    return json.dumps(chain_checklist(chain_id, evidence), indent=2)


@mcp.tool(
    description="Run thinking_map_step for registry chain or key point after MCP evidence collected."
)
def thinking_map_inquire(
    chain_id: str = "",
    key_point_id: str = "",
    task: str = "",
    task_id: str = "",
    actor_role_ids: str = "task_owner",
    current_evidence: str = "",
    destructive: bool = False,
) -> str:
    from thinking_maps.mcp_inquiry import run_inquiry

    evidence = [e.strip() for e in current_evidence.split(",") if e.strip()]
    if task_id and "task_id" not in evidence:
        evidence.append(task_id)
    try:
        result = run_inquiry(
            chain_id=chain_id.strip(),
            key_point_id=key_point_id.strip(),
            task=task or chain_id or key_point_id,
            task_id=task_id,
            actor_role_ids=actor_role_ids,
            current_evidence=evidence,
            destructive=destructive,
        )
    except ValueError as exc:
        return f"ERROR: {exc}"

    outcome = result.pop("_outcome", None)
    if outcome is not None:
        os.environ["THINKING_MAP_KEY_POINT_ID"] = result.get("key_point_id", "")
        os.environ["THINKING_MAP_MCP_ID"] = chain_id or key_point_id or "cursor-thinking-map"
        write_trace(
            _repo_root(),
            result["map_id"],
            task or chain_id or key_point_id,
            outcome,
            trigger="thinking_map_inquire",
            task_id=task_id,
        )

    return json.dumps(result, indent=2, default=str)


@mcp.tool(
    description="Second cortex when Move blocks: allowed self-reasoning plan + next MCP calls. No irreversible bytes."
)
def thinking_map_reason_for_self(
    kind: str = "",
    reason: str = "",
    missing_evidence: str = "",
    blockers: str = "",
    llm_prompt_state_json: str = "",
    chain_id: str = "",
    map_id: str = "team_ops",
    current_evidence: str = "",
    run_step_first: bool = False,
    current_state: str = "executing",
    task: str = "",
    task_id: str = "",
    actor_role_ids: str = "task_owner",
    destructive: bool = False,
) -> str:
    from thinking_maps.reason_for_self import reason_for_self_plan, reason_from_inquiry_result

    mode_path = _repo_root() / "governance" / "thinking_map_reason_for_self_mode"
    if mode_path.is_file() and mode_path.read_text(encoding="utf-8").strip() == "0":
        return json.dumps({"disabled": True, "policy_ref": "governance/thinking_map_reason_for_self_mode=0"})

    if run_step_first:
        step_out = thinking_map_inquire(
            chain_id=chain_id,
            task=task,
            task_id=task_id,
            actor_role_ids=actor_role_ids,
            current_evidence=current_evidence,
            destructive=destructive,
        )
        if step_out.startswith("ERROR"):
            return step_out
        payload = json.loads(step_out)
        if payload.get("reason_for_self"):
            return json.dumps(payload["reason_for_self"], indent=2, default=str)
        return json.dumps(reason_from_inquiry_result(payload), indent=2, default=str)

    llm: dict[str, Any] = {}
    if llm_prompt_state_json.strip():
        try:
            llm = json.loads(llm_prompt_state_json)
        except json.JSONDecodeError:
            llm = {"raw": llm_prompt_state_json}

    missing = [e.strip() for e in missing_evidence.split(",") if e.strip()]
    blockers_list = [b.strip() for b in blockers.split(",") if b.strip()]
    evidence = [e.strip() for e in current_evidence.split(",") if e.strip()]

    plan = reason_for_self_plan(
        kind=kind,
        reason=reason,
        missing_evidence=missing,
        blockers=blockers_list,
        llm_prompt_state=llm,
        chain_id=chain_id.strip(),
        map_id=map_id,
        current_evidence=evidence,
    )
    write_trace(
        _repo_root(),
        map_id,
        task or "reason_for_self",
        type("_O", (), {"kind": kind or "REASON_FOR_SELF", "blockers": blockers_list})(),
        trigger="thinking_map_reason_for_self",
        task_id=task_id,
    )
    return json.dumps(plan, indent=2, default=str)


@mcp.tool(description="List technical blockers caught from fpf-thinking-map (EOD queue).")
def list_thinking_map_blockers(status: str = "open,fixed_runtime") -> str:
    from thinking_maps.blocker_registry import list_blockers

    statuses = tuple(s.strip() for s in status.split(",") if s.strip())
    rows = list_blockers(_repo_root(), statuses=statuses or None)
    return json.dumps(rows, indent=2, default=str)


@mcp.tool(
    description="Mark blocker fixed at runtime — still registered for EOD review (access denied, etc.)."
)
def mark_thinking_map_blocker_fixed_runtime(blocker_id: str, note: str = "") -> str:
    from thinking_maps.blocker_registry import mark_fixed_runtime

    row = mark_fixed_runtime(_repo_root(), blocker_id, note)
    if not row:
        return f"ERROR: unknown blocker_id {blocker_id}"
    return json.dumps(row, indent=2, default=str)


@mcp.tool(description="Close blocker at EOD after review/fix.")
def close_thinking_map_blocker_eod(blocker_id: str, note: str = "") -> str:
    from thinking_maps.blocker_registry import close_eod

    row = close_eod(_repo_root(), blocker_id, note)
    if not row:
        return f"ERROR: unknown blocker_id {blocker_id}"
    return json.dumps(row, indent=2, default=str)


@mcp.tool(description="EOD digest markdown for pending thinking-map blockers.")
def get_thinking_map_blocker_eod_digest() -> str:
    from thinking_maps.blocker_registry import pending_for_eod, render_eod_digest

    digest = render_eod_digest(_repo_root())
    pending = pending_for_eod(_repo_root())
    return json.dumps({"pending_count": len(pending), "digest_markdown": digest}, indent=2)


if __name__ == "__main__":
    mcp.run(transport="stdio")
