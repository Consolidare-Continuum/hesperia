"""cursor-thinking-map MCP — Agentic Thinking Map wrapper."""
