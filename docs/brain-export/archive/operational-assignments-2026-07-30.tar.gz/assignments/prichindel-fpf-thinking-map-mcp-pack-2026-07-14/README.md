# prichindel.com — Agentic Thinking Map MCP solution pack

**Disclosure pack** for how the team wires **[fpf-thinking-map](https://pypi.org/project/fpf-thinking-map/)** (PyPI) into Cursor as MCP **`cursor-thinking-map`**.

| | |
|--|--|
| **Org** | prichindel.com (dev company / agent team) |
| **Engine** | `fpf-thinking-map` on PyPI (pin in `requirements-thinking-map.txt`, currently **1.4.3**) |
| **MCP server** | `agent_mcp_thinking_map` → Cursor server name **`cursor-thinking-map`** |
| **Domain maps** | Brain-owned: `team_ops`, `cluster_ops`, `eod_ops` under `thinking_maps/` |
| **Packed** | 2026-07-14 · Ethan (team lead) · disclosure allowed |

This pack is the **team integration**, not a republish of the library. Engine semantics (guards, traversal, outcomes, `response_contract`) live in the PyPI package. We own **triggers, MCP tools, domain maps, evidence tokens, and runbooks**.

---

## What problem this solves

Agents already have:

1. **Context** — knowledge store + `query_knowledge`
2. **Task** — task board + workflow MCP (`get_current_step` / `report_done`)

They still need a third layer:

3. **Move** — *given this state and evidence, what is the lawful next move — and why is it blocked?*

That is `thinking_map_step` (and friends). Agents **read the JSON outcome and obey**; they do not re-derive Move rules in chat.

---

## How it is used — **when**

Mode flag: `governance/thinking_map_mode` = **`1`** (on) / **`0`** (Ethan scope suspended).

### Mandatory triggers (call `thinking_map_step` / inquire before irreversible work)

| When | `map_id` | Why |
|------|----------|-----|
| Multi-step **workflow proceed** / owner execute on an OPEN task | `team_ops` | Lawful path through triage → evidence → execute → report_done |
| **Destructive / high-risk** actions | `team_ops` | After approval MCP; map surfaces blockers, does not approve humans |
| **Cluster / prod / SSH** preflight (Abelard path) | `cluster_ops` | Cert, trust, access status before cluster bytes |
| **Approval write** (`request_approval` / `record_approval`) | `team_ops` | Align write path with gates |
| **End-of-day** collect → commit → knowledge | `eod_ops` | Structured close |

### Explicitly **not** mandatory

- Single-line edits, read-only status, routine grep
- Grace **triage** (row creation) — map does not replace triage
- Every research or library query (use knowledge / library MCPs; map only on triggers)

### Inquiry chains (after real MCP evidence)

See `governance/MCP-THINKING-MAP-KEY-POINTS.md` and `governance/mcp_thinking_map_registry.json`.

Examples: `session_opener`, `workflow_execute`, `cluster_preflight`, `trustmaster_ops`, `destructive_gate`, `report_done_chain`, `grace_triage`, `eod_close`, …

Pattern: call MCP tool → add registry **`evidence_token`** to `current_evidence` → **`thinking_map_inquire`** (or `thinking_map_step`).

### When blocked (`kind=COLLECT_EVIDENCE` / blockers)

1. Call **`thinking_map_reason_for_self`** (second cortex — plan only)
2. Run recommended **read-only / gate** MCP calls
3. Re-step with honest evidence
4. Irreversible bytes only after `CONTINUE` / `ADVANCE`

Flag: `governance/thinking_map_reason_for_self_mode=1`.

---

## Session flow (agent)

```
query_knowledge          → Context
get_current_step         → Task
thinking_map_step        → Move   (if trigger + mode=1)
  └─ obey JSON outcome
execute (if allowed)
report_done              → Task close
```

Outcome fields to obey (library is law):

- `kind`, `reason`, `missing_evidence`, `blockers`
- `llm_prompt_state` (gates, logic, transitions)
- `response_contract` when present

---

## MCP tools in this pack

| Tool | Role |
|------|------|
| `list_thinking_maps` | Domain map ids |
| `thinking_map_verify` | Package self-check |
| `thinking_map_step` | One lawful traversal step |
| `get_thinking_map_slice` | Debug (same step surface) |
| `list_mcp_inquiry_points` / `get_mcp_inquiry_chain` | Registry chains |
| `thinking_map_inquire` | Terminal move after evidence |
| `thinking_map_reason_for_self` | Second cortex when blocked |
| Blocker tools | EOD queue for technical blockers |

Source: `agent_mcp_thinking_map/__main__.py`

---

## Layout of this zip

```
README.md                          ← this file
requirements-thinking-map.txt      ← PyPI pin
agent_mcp_thinking_map/            ← FastMCP server (stdio)
thinking_maps/                     ← domain maps + inquiry + tests
governance/                        ← Ethan specs, FAQ, evidence tokens, registry
scripts/                           ← install, verify, hard-gate, CLI, session runbook
rules/cursor-thinking-map-mandatory.mdc
docs/FPF-THINKING-MAP-PYPI.md
docs/MCP-PYTHON-THINKING-MAP.md
mcp-config/cursor-thinking-map.example.json
```

**Not included** (intentionally): live SSH host wiring secrets, runtime traces (`thinking_map_trace.jsonl`), ops blocker queues, full team brain / CHROMA stack.

---

## Quick start (observer / local smoke)

```bash
# 1) Install engine into a Python 3.10+ venv
python3 -m venv .venv && source .venv/bin/activate
pip install -U -r requirements-thinking-map.txt
python -m fpf_thinking_map.verify

# 2) From unpacked root (PYTHONPATH = this directory)
export PYTHONPATH="$PWD" CURSOR_REPO_ROOT="$PWD"
python -m agent_mcp_thinking_map   # stdio MCP — Cursor wires this as cursor-thinking-map

# 3) Or CLI inquire (no IDE)
python3 scripts/thinking_map_cli.py --help
```

Wire Cursor with `mcp-config/cursor-thinking-map.example.json` (adapt paths). Production at prichindel.com runs the module via SSH into a shared MCP venv; paths in `docs/MCP-PYTHON-THINKING-MAP.md` are site-specific.

pytest (optional): `pip install pytest` then `PYTHONPATH=. pytest thinking_maps/tests -q`

---

## What this is *not*

| Claim | Reality |
|-------|---------|
| Map replaces Grace triage | No — triage creates task rows |
| Map is human approval | No — **cursor-approval-gates** records approval |
| Map replaces knowledge RAG | No — Context layer stays separate |
| Brain vendors the engine | No — PyPI only; `thinking_maps/engine.py` re-exports |

Companion MCP **`cursor-fpf-test-mcp`** exercises the **library** itself (`dev_mcp` in the fpf-thinking-map repo). This pack is the **team domain + Cursor wire**.

---

## Canonical policy (inside pack)

1. `governance/SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md` — triggers + three-layer model  
2. `scripts/SCRIPT-RUNBOOK-thinking-map-session.md` — session procedure  
3. `governance/THINKING-MAP-FAQ.md` — short FAQ  
4. `governance/MCP-THINKING-MAP-KEY-POINTS.md` — when each inquiry chain fires  
5. `rules/cursor-thinking-map-mandatory.mdc` — agent rule (Cursor)

---

## License / disclosure note

Packaged for architectural transparency under operator permission.  
PyPI package [fpf-thinking-map](https://pypi.org/project/fpf-thinking-map/) retains its own license; install from PyPI.  
Team-authored paths in this zip (MCP wrapper, domain maps, governance prose) may be shared for review of **how the integration works**.

SIGNED: Team lead (Ethan) | fpf-thinking-map MCP disclosure pack | 2026-07-14 | solution zip + when/how
