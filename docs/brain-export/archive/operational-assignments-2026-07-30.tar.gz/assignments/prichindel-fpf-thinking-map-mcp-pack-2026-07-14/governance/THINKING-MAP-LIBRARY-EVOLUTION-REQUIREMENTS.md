# fpf-thinking-map — library evolution requirements

**Author:** igareosh (operator, PyPI maintainer)  
**Contributor:** Cursor (brain repo — MCP, domain maps, enforcement, verify)  
**Package:** https://pypi.org/project/fpf-thinking-map/ · pin [requirements-thinking-map.txt](../requirements-thinking-map.txt)

---

## Process

1. **Observe** friction during real workflow (false COLLECT_EVIDENCE, missing outcome kind, logic noise, TTL too aggressive).  
2. **Record** a row below (requirement id, symptom, proposed change, brain vs library).  
3. **Operator** decides PyPI release; **Cursor** updates pin, domain maps, tests, docs.  
4. **Verify:** `python -m fpf_thinking_map.verify` + `bash scripts/verify-thinking-map-mcp.sh`.

**Do not** vend engine copy in brain repo. **Do not** override library outcomes in agent chat.

---

## Open requirements (brain session 2026-06-28)

| ID | Symptom | Proposed change | Owner |
|----|---------|-----------------|-------|
| **TM-REQ-001** | `response_contract` null on `CONTINUE` at `start` | Optional: emit minimal contract on all non-IDLE outcomes for agent output discipline | Library |
| **TM-REQ-002** | `ci_ready` logic unsatisfied on non-code rows — noise in `llm_prompt_state.logic` | Domain map: scope logic layer to transitions that need CI; or library: context-scoped rule activation | Brain map + library |
| **TM-REQ-003** | Agents forget `snapshot_fresh` token after snapshot MCP | Brain: passport + [THINKING-MAP-EVIDENCE-TOKENS.md](THINKING-MAP-EVIDENCE-TOKENS.md) — **done 2026-06-28** | Brain |
| **TM-REQ-004** | Evidence tokens are honor-system (not cryptographically tied to MCP) | Future: MCP returns signed evidence handles consumable by map | Library + MCP |
| **TM-REQ-005** | At `executing`, non-destructive task with `execute_safe` available still returns `COLLECT_EVIDENCE` (approval_id) because destructive transition is evaluated | **Brain fix 2026-06-28:** split `executing_destructive` + `destructive_scope` evidence; library may still prefer safe transition in outcome kind (follow-up) | Brain **partial** · Library optional |

---

## Closed / accepted (no library change yet)

| ID | Resolution |
|----|------------|
| **TM-REQ-000** | Destructive without `approval_id` → `COLLECT_EVIDENCE` — **correct by design** |

---

## How to add

Append row to **Open requirements**; triage via Grace if product-wide; operator + Cursor pair on PyPI bump.

---

SIGNED: Cursor | library evolution channel | 2026-06-28
