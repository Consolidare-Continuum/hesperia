# Integration contract — cursor-thinking-map ↔ cursor-approval-gates

**Owner**: Emma · **ATM-52** · Status: draft

## Parties

| Service | Role |
|---------|------|
| **cursor-approval-gates** | Human approval record (pending/approved/rejected) |
| **cursor-thinking-map** | Pre-execution move validation |

## Obligations

1. Destructive/high-risk: **approval status approved** before execute — non-negotiable.  
2. Map may require `required_gate_id`; executor must call **get_approval_status** for that id.  
3. Map **cannot** call **record_approval** on behalf of operator — Daniel policy ([THINKING-MAP-APPROVAL-POLICY.md](THINKING-MAP-APPROVAL-POLICY.md)).  
4. Optional: `THINKING_MAP_PREFLIGHT=1` on approval MCP logs map blockers alongside pending list (Felix ATM-37).

## Sequence

```
list_pending_approvals → get_approval_status(id) → [approved?]
  → thinking_map_step (if mode=1) → execute → report_done
```

SIGNED: Integration (Emma) | ATM wave | 2026-06-28 | approval contract
