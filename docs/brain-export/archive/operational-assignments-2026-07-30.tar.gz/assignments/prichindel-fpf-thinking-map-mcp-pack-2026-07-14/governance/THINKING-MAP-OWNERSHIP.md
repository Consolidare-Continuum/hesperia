# Thinking map ownership matrix

**Owner**: Sophia · **ATM-54**

| Component | Owner | Notes |
|-----------|-------|-------|
| `fpf-thinking-map` package pin | Abelard | `requirements-thinking-map.txt`, chroma venv on prichindel/alunel/altitudine |
| `agent_mcp_thinking_map` | Abelard deploy · Felix feature | MCP host prichindel |
| `thinking_maps/team_ops`, `cluster_ops` | Felix | Domain maps + tests |
| Workflow passport / driver hint | Cursor / Olivia | `workflow_driver.py`, context template |
| Governance SPEC + runbooks | Ethan / Liam | Mandatory triggers |
| CHROMA catalog ingest | Abelard | layer `thinking_map_catalog` |
| Hesperia `sphere/fpf_bridge` | Felix | Same package version as brain |
| SuiteCRM ATM rows | Grace | sync batches |
| Security baseline | Daniel | local-only MCP, no creds in slice |

SIGNED: Ops (Sophia) | ATM wave | 2026-06-28 | ownership
