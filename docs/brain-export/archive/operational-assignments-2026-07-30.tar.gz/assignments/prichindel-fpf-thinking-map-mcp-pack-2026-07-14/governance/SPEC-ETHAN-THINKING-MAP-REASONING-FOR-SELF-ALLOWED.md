# SPEC-ETHAN — Thinking map: reasoning for self allowed (second cortex)

**Status:** APPROVED (operator 2026-06-28)  
**Flag:** `governance/thinking_map_reason_for_self_mode` = **1** (default when `thinking_map_mode=1`)  
**Package:** [fpf-thinking-map](https://pypi.org/project/fpf-thinking-map/) v1.2.1  
**Parent:** [SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md](SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md)

---

## 1. Purpose

When **Move** blocks (`COLLECT_EVIDENCE`, gate insufficient, blockers), agents **may** use **fpf-thinking-map** as a **second cortex** for **self-reasoning** — plan the unblock path, interpret `llm_prompt_state`, choose next MCP calls — **without** executing irreversible bytes.

**Not** vendor black-box reasoning. **Not** bypass. **Structured deliberation** on library JSON + MCP registry.

---

## 2. Two cortices (brain workflow)

| Cortex | Layer | Instrument | Role |
|--------|-------|------------|------|
| **Primary** | Context + Task | CHROMA-1 `query_knowledge`, active.md, workflow MCP | What exists; what row; who owns |
| **Second** | Move (when blocked) | `fpf-thinking-map` outcome JSON | Why blocked; lawful next evidence; gate/logic routes |

```
Primary: query_knowledge → get_current_step
Move:    thinking_map_step → blocked?
Second:  thinking_map_reason_for_self → plan MCPs → re-step → CONTINUE → execute bytes
```

---

## 3. When RFSA applies

| Signal | RFSA |
|--------|------|
| `kind` contains COLLECT_EVIDENCE, BLOCK, BLOCKED, INSUFFICIENT, HITL | **Yes** |
| `missing_evidence` non-empty | **Yes** |
| `blockers` non-empty | **Yes** |
| `gate_status.*=insufficient` | **Yes** |
| `kind=CONTINUE` / ADVANCE with empty missing | **No** — execute |
| `kind=IDLE` | **No** — autonomous idle |

---

## 4. Allowed (self-reasoning)

- Read and use `llm_prompt_state.logic`, `gate_status`, `possible_transitions`, `response_contract`
- Call **`thinking_map_reason_for_self`** / **`get_mcp_inquiry_chain`** to plan evidence collection
- Run **read-only** MCP (query_knowledge, get_runbook, list_pending_approvals, get_cluster_snapshot, …)
- Internal agent deliberation: unblock sequence, risk, owner escalation — **report as did/asked/result**, not operator tutorial
- Re-call **`thinking_map_step`** / **`thinking_map_inquire`** after each honest evidence token

---

## 5. Forbidden (until unblock)

- Irreversible bytes while Move layer still blocks
- Fabricated `current_evidence` without real MCP
- Chat paraphrase replacing library `kind`
- Skipping destructive_gate / cluster_ssh_gate because "reasoned it out"

---

## 6. MCP tool

**`thinking_map_reason_for_self`** (cursor-thinking-map) — input: last outcome fields or fresh step; output: RFSA plan JSON (`allowed_self_reasoning`, `forbidden_until_unblock`, `recommended_next_mcp_calls`).

CLI: `python3 scripts/thinking_map_cli.py reason-for-self --json …`

---

## 7. Workflow integration

- **Passport:** `workflow_driver.py` appends RFSA line when `thinking_map_reason_for_self_mode=1`
- **Proceed gates:** [SCRIPT-RUNBOOK-workflow-proceed-gates.md](../scripts/runbooks/SCRIPT-RUNBOOK-workflow-proceed-gates.md) — BLOCKED → second cortex, not stall
- **Runbook:** [SCRIPT-RUNBOOK-thinking-map-session.md](../scripts/SCRIPT-RUNBOOK-thinking-map-session.md) § RFSA
- **Registry:** [mcp_thinking_map_registry.json](mcp_thinking_map_registry.json) maps missing tokens → MCP calls

---

## 8. Suspend

Set `governance/thinking_map_reason_for_self_mode=0` — RFSA hints off; Move obedience unchanged.

---

SIGNED: Developer (Gena) | second cortex RFSA | 2026-06-28 | brain workflow
