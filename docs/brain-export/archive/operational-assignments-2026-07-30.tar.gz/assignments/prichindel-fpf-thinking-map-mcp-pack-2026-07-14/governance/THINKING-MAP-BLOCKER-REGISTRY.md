# Thinking-map technical blocker registry (EOD queue)

**Registry file:** `governance/thinking_map_blockers.jsonl` (append-only; latest row per `blocker_id` wins)  
**Catch source:** fpf-thinking-map outcomes via `write_trace` / `thinking_map_inquire`  
**Spec parent:** [SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md](SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md)

---

## Lifecycle

| status | Meaning |
|--------|---------|
| `open` | Caught; not yet fixed |
| `fixed_runtime` | Fixed during session — **still on EOD queue** |
| `eod_closed` | Reviewed/closed at EOD |

**Rule:** Runtime fix does **not** drop the row. EOD must **`close_thinking_map_blocker_eod`** (or bulk close via CLI).

---

## Classes (auto from catch)

| class | Typical signal |
|-------|----------------|
| `access_denied` | Permission denied, SSH, agent cert, 401/403 |
| `collect_evidence` | COLLECT_EVIDENCE, approval_id, snapshot_fresh |
| `gate_blocker` | library `blockers[]` |
| `missing_evidence` | missing tokens only |
| `technical` | other |

---

## MCP tools

| Tool | Action |
|------|--------|
| `list_thinking_map_blockers` | Queue (`open`, `fixed_runtime`) |
| `mark_thinking_map_blocker_fixed_runtime` | Fixed now; keep for EOD |
| `close_thinking_map_blocker_eod` | EOD closure |
| `get_thinking_map_blocker_eod_digest` | Markdown digest |

## CLI

```bash
python3 scripts/thinking_map_cli.py blockers list
python3 scripts/thinking_map_cli.py blockers fixed-runtime <id> --note "cert renewed"
python3 scripts/thinking_map_cli.py blockers close-eod <id> --note "EOD verified"
bash scripts/thinking-map-blockers-eod.sh
```

---

## EOD flow

1. `end_of_day_run.sh` writes `operational/assignments/reports/EOD-BLOCKERS-YYYY-MM-DD.md`
2. `end_of_day_collect.sh` includes blocker section
3. Review pending → `close_thinking_map_blocker_eod` each (or document waive)
4. Pass evidence **`eod_blockers_reviewed`** on `eod_ops` structure→compliance transition when queue empty

Disable auto-register: `THINKING_MAP_BLOCKER_REGISTER=0`

---

SIGNED: Developer (Gena) | blocker registry EOD | 2026-06-28 | brain workflow
