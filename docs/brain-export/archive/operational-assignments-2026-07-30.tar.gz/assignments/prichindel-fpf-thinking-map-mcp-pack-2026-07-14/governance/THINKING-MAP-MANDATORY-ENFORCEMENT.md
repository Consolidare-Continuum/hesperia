# Thinking map — mandatory enforcement (all agents)

**Status:** BINDING when `governance/thinking_map_mode=1`  
**Package:** [fpf-thinking-map PyPI](https://pypi.org/project/fpf-thinking-map/) v1.2.1 (operator-authored; Cursor brain contributor)  
**Spec:** [SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md](SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md)

---

## Rule (one sentence)

When a **mandatory trigger** fires, every agent **must** call **`thinking_map_step`** via **cursor-thinking-map** MCP and **obey** the returned JSON before irreversible bytes — no skip, no chat substitute.

---

## Who (no exceptions)

| Agent surface | Mandatory |
|---------------|-----------|
| Cursor (default IDE) | Yes |
| Cursor main / product orchestration | Yes — same MCP stack |
| Abelard, Gena, Felix, Colombo | Yes on triggers |
| Copilot CLI / Copilot main | Yes — mirror mcp-config |
| Claude Code (Felix `.claude/settings.json`) | Yes |
| Team prichindel executors (Ethan, Grace, …) | Yes when executing owned rows |
| Grace triage-only (row creation) | **Exempt** from map on triage itself; **not** exempt when Grace executes a row |

---

## Triggers (mandatory)

1. **Workflow proceed** — owner execute on OPEN/IN_PROGRESS row  
2. **Destructive / high-risk** — after approval MCP read; before bytes  
3. **Cluster / prod / Abelard** — preflight before SSH/trustmaster  
4. **Approval write** — request_approval / record_approval path  
5. **Hesperia interpret / calibrate** — product `sphere/fpf_bridge` (same package pin)

**Not mandatory:** read-only status, inbox, single-line edits, Grace triage row creation, colombo-library research turns.

---

## Three-layer flow (non-negotiable)

```
query_knowledge → get_current_step → thinking_map_step → execute → report_done
```

Move semantics = **library output only**. Brain repo documents triggers and evidence tokens — not engine guards.

---

## Reasoning for self allowed (second cortex)

When Move **blocks**, agents **may** self-reason using **fpf-thinking-map** JSON (`llm_prompt_state`, gates, logic) to plan unblock — **not** to bypass bytes.

**Flag:** `governance/thinking_map_reason_for_self_mode=1`  
**Spec:** [SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md](SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md)  
**Tool:** `thinking_map_reason_for_self` · blocked `thinking_map_inquire` includes `reason_for_self` plan

---

## Hard dependency (brain shutdown)

When `thinking_map_mode=1`, removing or breaking **fpf-thinking-map** stops gated brain scripts (exit **42**). Ref: [THINKING-MAP-HARD-DEPENDENCY.md](THINKING-MAP-HARD-DEPENDENCY.md).

---

## Enforcement surfaces (must stay aligned)

| Surface | File |
|---------|------|
| Always-on rules | `.cursor/rules/cursor-thinking-map-mandatory.mdc`, `cursor-mcp-chroma-first.mdc`, `cursor-agent-quality-floor.mdc` |
| Entities | `agents-by-name.mdc`, abelard/felix/gena/colombo `.mdc` |
| MCP compliance | [MCP-COMPLIANCE-AND-OPERATIONAL.md](MCP-COMPLIANCE-AND-OPERATIONAL.md) §3 |
| Quality floor | [AGENT-QUALITY-FLOOR.md](AGENT-QUALITY-FLOOR.md) |
| Targeted runbooks | [ETHAN-TARGETED-RUNBOOKS-MANDATORY.md](ETHAN-TARGETED-RUNBOOKS-MANDATORY.md) |
| Workflow passport | `governance/workflow_context_current.md` (driver-generated) |
| Session opener | `SCRIPT-RUNBOOK-mcp-brain-session-opener` |
| Proceed gates | `SCRIPT-RUNBOOK-workflow-proceed-gates` |
| Evidence tokens | [THINKING-MAP-EVIDENCE-TOKENS.md](THINKING-MAP-EVIDENCE-TOKENS.md) |
| Verify | `bash scripts/verify-thinking-map-mandatory-enforcement.sh` |
| Hard shutdown | [THINKING-MAP-HARD-DEPENDENCY.md](THINKING-MAP-HARD-DEPENDENCY.md) · `scripts/thinking-map-hard-gate.sh` |

---

## Process violation

Skipping `thinking_map_step` on a trigger while executing = same class as skipping mandatory runbook or `report_done` when owner.

---

## Library evolution

Friction or false blocks → [THINKING-MAP-LIBRARY-EVOLUTION-REQUIREMENTS.md](THINKING-MAP-LIBRARY-EVOLUTION-REQUIREMENTS.md). Operator authors PyPI releases; Cursor contributes brain wiring + requirements.

---

SIGNED: Cursor (repo entity) | mandatory enforcement binding | 2026-06-28 | brain compliance
