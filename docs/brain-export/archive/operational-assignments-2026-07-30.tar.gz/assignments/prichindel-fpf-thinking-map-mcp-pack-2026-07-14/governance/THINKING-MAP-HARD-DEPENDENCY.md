# fpf-thinking-map — hard brain dependency

**Status:** BINDING when `governance/thinking_map_mode=1`  
**Integration:** PASSED & usage-allowed 2026-06-28 — flag `governance/thinking_map_integrated=1`; signed [THINKING-MAP-INTEGRATION-PASSED-2026-06-28.md](THINKING-MAP-INTEGRATION-PASSED-2026-06-28.md)  
**Operator intent (2026-06-28):** Brain repo **shuts down** without the library — same class as workflow/Chroma, not optional garnish.

---

## Shutdown semantics

| Exit | Meaning |
|------|---------|
| **42** | `BRAIN_SHUTDOWN` — `fpf-thinking-map` missing, verify failed, or domain maps broken |
| **0** | Gate pass, or `thinking_map_mode=0` (Ethan/CCB suspend only) |

**Breakglass:** `THINKING_MAP_BREAKGLASS=1` logs to `governance/thinking_map_breakglass.log` — not default.

---

## Gated entry points (mode=1)

| Script | When |
|--------|------|
| `scripts/thinking-map-hard-gate.sh` | Canonical gate (all others call this) |
| `scripts/workflow_run.sh` | IDE workflow fasten |
| `scripts/workflow_automation_run.sh` | Cron / drain / full-auto |
| `scripts/end_of_day_collect.sh` | EOD collect |
| `scripts/end_of_day_run.sh` | EOD orchestrator + `eod_ops` map |
| `scripts/detect-cursor-session-mode.sh` | Session start → `thinking_map_gate=pass\|fail` |
| `scripts/git-hooks/pre-commit` | Commits blocked when gate fails |

---

## CLI (no MCP subprocess)

```bash
python3 scripts/thinking_map_cli.py verify
python3 scripts/thinking_map_cli.py step --map-id team_ops --current-state executing --current-evidence task_id,runbook_read
python3 scripts/thinking_map_cli.py eod-phase gate
python3 scripts/thinking_map_cli.py eod-phase collect
```

MCP remains canonical for agents: **cursor-thinking-map** → `thinking_map_step`, `thinking_map_inquire`, `get_mcp_inquiry_chain`, `list_mcp_inquiry_points`.

**MCP registry (all 14 servers):** [MCP-THINKING-MAP-KEY-POINTS.md](MCP-THINKING-MAP-KEY-POINTS.md) · `bash scripts/mcp-thinking-map-inquire.sh`

---

## Domain maps

| map_id | Path |
|--------|------|
| `team_ops` | `thinking_maps/team_ops/` |
| `cluster_ops` | `thinking_maps/cluster_ops/` |
| `eod_ops` | `thinking_maps/eod_ops/` |

Engine: **PyPI only** — `fpf-thinking-map==1.2.1`.

---

## Install / verify

```bash
bash scripts/install-thinking-map.sh
bash scripts/verify-thinking-map-mcp.sh
bash scripts/verify-thinking-map-mandatory-enforcement.sh
```

---

SIGNED: Developer (Gena) | brain hard dependency | 2026-06-28 | ATM/EOD squeeze
