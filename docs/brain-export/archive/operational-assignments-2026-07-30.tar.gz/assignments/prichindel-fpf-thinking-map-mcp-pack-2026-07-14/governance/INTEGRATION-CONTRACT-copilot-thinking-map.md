# Integration contract — Copilot main ↔ cursor-thinking-map

**Owner**: Emma · **ATM-68** · Status: draft

## Scope

**Copilot main** (terminal-primary orchestrator) uses the same MCP stack as Cursor IDE, including **cursor-thinking-map** on mandatory triggers.

## Async path

1. Read `governance/workflow_driver_current.txt` or user invocation for entity context.  
2. On trigger (proceed, destructive, cluster): SSH prichindel MCP **`thinking_map_step`**.  
3. Emit blockers in terminal output before destructive shell commands.  
4. **report_done** via cursor-pipeline-status when row completes.

## Config

Mirror `cursor-thinking-map` block from [governance/mcp-config.json](mcp-config.json) in Copilot MCP config. Ref: [.copilot/COPILOT-CLI-INTEGRATION.md](../.copilot/COPILOT-CLI-INTEGRATION.md).

SIGNED: Integration (Emma) | ATM wave | 2026-06-28 | copilot contract
