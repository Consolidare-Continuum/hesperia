# Test matrix — thinking map (Ava)

**Owner**: Ava · **ATM-48, 49, 50, 69, 70**

Run: `bash scripts/verify-thinking-map-mcp.sh` + `pytest thinking_maps/tests/`

## ATM-48 — Missing approval → COLLECT_EVIDENCE + blockers

| Step | Expected |
|------|----------|
| Invoke `team_ops` with destructive context, no approval in gates | Outcome BLOCKED or COLLECT_EVIDENCE |
| Response includes non-empty `blockers` or `required_gate_id` | Pass |
| Executor does not proceed to destructive shell | Pass |

## ATM-49 — IDLE stops autonomous loop

| Step | Expected |
|------|----------|
| Heartbeat zero OPEN + map step with idle scenario | outcome_kind IDLE |
| Agent reports autonomous idle | No invented tasks |

## ATM-50 — BRIDGE cross-context escape

| Step | Expected |
|------|----------|
| Map scenario requiring handoff (e.g. infra from dev entity) | BRIDGE or equivalent with target entity hint |
| CSP block emitted before context switch | Pass |

## ATM-69 — TTL evidence decay (team_ops)

| Step | Expected |
|------|----------|
| Stale evidence fixture in team_ops test | Guard fails freshness; blockers mention evidence/TTL |

## ATM-70 — response_contract fields

| Step | Expected |
|------|----------|
| Any ADVANCE outcome | `response_contract` object present |
| Required keys per engine v1.2.1 | formality, scope, reliability (FGR) populated |

**Status**: Manual/matrix defined; automate in `thinking_maps/tests/` as follow-up.

SIGNED: QA (Ava) | ATM wave | 2026-06-28 | test matrix
