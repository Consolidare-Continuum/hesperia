# Thinking map — evidence tokens (brain contract)

**Purpose:** After MCP/ops steps, pass **`current_evidence`** comma-list to **`thinking_map_step`**. Domain maps (`thinking_maps/`) declare which tokens satisfy gates. **Engine validates structure; agents supply honest tokens after real MCP calls.**

Ref: [THINKING-MAP-MANDATORY-ENFORCEMENT.md](THINKING-MAP-MANDATORY-ENFORCEMENT.md), [FPF-THINKING-MAP-PYPI.md](../agent_mcp_knowledge/FPF-THINKING-MAP-PYPI.md)

---

## team_ops (`map_id=team_ops`)

| Token | After you… |
|-------|------------|
| `task_id` | Have active.md row / task id for current step |
| `query_knowledge_done` | Called `query_knowledge` for context |
| `get_current_step_done` | Called `get_current_step` / read passport |
| `runbook_read` | Called **get_runbook** for mandatory procedure |
| `approval_id` | **list_pending_approvals** / **get_approval_status** — approved destructive scope |
| `ci_green` | **get_branch_ci** / PR checks green (code rows) |
| `destructive_scope` | Task is **explicitly** destructive/high-risk — required before destructive path (`executing_destructive`) |

**Safe rows (spec ratify, schema, code):** `current_state=executing`, evidence without `destructive_scope` → `execute_safe` path only.

**Destructive rows:** set `current_state=executing_destructive`, include `destructive_scope` + `approval_id` after approval MCP.

---

## cluster_ops (`map_id=cluster_ops`)

| Token | After you… |
|-------|------------|
| `agent_cert_valid` | Cert future in `governance/agent_ssh_cert_status.txt` or **get_agent_access_status** OK |
| `get_agent_access_status_done` | Called **get_agent_access_status** |
| `snapshot_fresh` | Called **get_cluster_snapshot** this session (preflight) |
| `trustmaster_preflight` | Trustmaster runbook + **get_trustmaster_status** before IdP ops |
| `tailscale_logout_approved` | Operator chat approval only — never default |

**Typical cluster preflight evidence string:**

```
task_id,agent_cert_valid,snapshot_fresh,get_agent_access_status_done
```

If map returns `COLLECT_EVIDENCE` → add missing tokens from table, re-step — do not bypass. **RFSA:** call **`thinking_map_reason_for_self`** — second cortex plan ([SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md](SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md)).

---

## MCP registry (all servers)

Full matrix: [MCP-THINKING-MAP-KEY-POINTS.md](MCP-THINKING-MAP-KEY-POINTS.md) · JSON: [mcp_thinking_map_registry.json](mcp_thinking_map_registry.json)

**Tools:** `list_mcp_inquiry_points`, `get_mcp_inquiry_chain`, `thinking_map_inquire` (cursor-thinking-map MCP)

**CLI:** `bash scripts/mcp-thinking-map-inquire.sh chain workflow_execute --evidence task_id,query_knowledge_done,...`

---

## Workflow passport

`workflow_driver.py` writes suggested `map_id` + evidence into `governance/workflow_context_current.md` when `thinking_map_mode=1`.

---

SIGNED: Cursor | evidence token contract | 2026-06-28
