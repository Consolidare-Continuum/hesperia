# Integration contract — cursor-thinking-map ↔ cursor-pipeline-status

**Owner**: Emma · **ATM-51** · Status: draft

## Parties

| Service | Role |
|---------|------|
| **cursor-pipeline-status** | Task truth: heartbeat, current step, report_done |
| **cursor-thinking-map** | Move truth on triggers: lawful next step, blockers |

## Obligations

1. **Order**: Context (`query_knowledge`) → Task (get_current_step / heartbeat) → Move (`thinking_map_step`) on triggers only.  
2. **Pipeline never invents work**: If map returns IDLE and heartbeat shows zero OPEN → autonomous idle.  
3. **report_done** remains mandatory after row execution; map does not mark DONE.  
4. **Passport**: `workflow_context_current.md` may include map outcome summary when `thinking_map_mode=1` (Olivia ATM-65).

## Failure modes

| Condition | Behavior |
|-----------|----------|
| Map BLOCKED | Executor stops; may PAUSE row via report_done |
| Map MCP unavailable | Treat as config bug; proceed with runbook-only gates if trigger allows fallback |
| Mismatch task owner vs map context | CSP + re-read current step |

Ref: [SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md](SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md)

SIGNED: Integration (Emma) | ATM wave | 2026-06-28 | pipeline contract
