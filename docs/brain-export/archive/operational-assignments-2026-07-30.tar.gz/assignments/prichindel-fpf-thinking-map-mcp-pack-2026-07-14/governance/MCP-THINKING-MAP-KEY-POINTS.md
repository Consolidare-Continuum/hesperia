# MCP ↔ fpf-thinking-map — key inquiry points

**Registry (machine):** [mcp_thinking_map_registry.json](mcp_thinking_map_registry.json)  
**Code:** `thinking_maps/mcp_inquiry.py`  
**MCP tools:** `list_mcp_inquiry_points`, `get_mcp_inquiry_chain`, `thinking_map_inquire`  
**CLI:** `python3 scripts/thinking_map_cli.py chain|inquire` · `bash scripts/mcp-thinking-map-inquire.sh`

---

## Rule

After each **key MCP tool** call, add the registry **`evidence_token`** to **`current_evidence`**, then run **`thinking_map_inquire`** for the chain terminal move (or **`thinking_map_step`** directly).

---

## Inquiry chains

| chain_id | When |
|----------|------|
| `session_opener` | Cold session / MCP brain opener |
| `workflow_execute` | Owner execute on active.md row |
| `cluster_preflight` | Abelard / cluster / prod |
| `trustmaster_ops` | Authentik / trustmaster |
| `destructive_gate` | High-risk bytes |
| `report_done_chain` | Completing row + SuiteCRM |
| `grace_triage` | Grace inbox orient |
| `hesperia_context` | Context RAG + knowledge |
| `library_research` | Colombo / CHROMA-2 |
| `eod_close` | End-of-day |
| `outbound_mail` | Postfix / Mailcow send |
| `web_ui` | Frontend / browser verification (cursor-ide-browser) |
| `edge_ops` | Cloudflare edge: observability, builds, bindings (auth-gated) |

---

## All MCP servers (18 — full session coverage)

| MCP | Key tools → evidence token |
|-----|---------------------------|
| chroma-knowledge | query_knowledge → query_knowledge_done |
| cursor-pipeline-status | get_heartbeat, get_current_step, report_done |
| cursor-runbook | get_runbook → runbook_read |
| cursor-approval-gates | list/get/request → approval_id |
| cursor-cluster-snapshot | get_agent_access_status, get_cluster_snapshot, get_trustmaster_status |
| cursor-github-ci | get_branch_ci → ci_green |
| cursor-context-rag | get_context_packet → context_packet_done |
| cursor-inbox-reader | get_inbox_summary → inbox_orient_done |
| cursor-suitecrm | suitecrm_set_done → suitecrm_sync_done |
| colombo-library | query_colombo_library → colombo_library_query_done |
| cursor-postfix-mail / cursor-mailcow-mail | send_mail → outbound_mail_sent |
| cursor-tailscale | tailscale_status → tailscale_status_done |
| cursor-ide-browser | browser_navigate, browser_snapshot → web_snapshot_done |
| cloudflare-observability | query_worker_observability → cf_observability_done (auth-gated) |
| cloudflare-builds | workers_builds_list_builds → cf_build_status_done (auth-gated) |
| cloudflare-bindings | accounts_list → cf_bindings_done (auth-gated) |
| cursor-thinking-map | verify, step, **inquire** (move engine) |

**Auth-gated** (cloudflare plugins): inquiry point activates once `mcp_auth` succeeds for that server; until then only `mcp_auth` is exposed. Wiring is registered regardless so coverage = all MCPs available.

Workflow passport embeds chain for current owner via `workflow_driver.py`.

**When blocked:** `thinking_map_reason_for_self` — second cortex ([SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md](SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md)). Flag: `governance/thinking_map_reason_for_self_mode=1`.

---

SIGNED: Developer (Gena) | MCP thinking-map key points | 2026-06-28 | brain integration
