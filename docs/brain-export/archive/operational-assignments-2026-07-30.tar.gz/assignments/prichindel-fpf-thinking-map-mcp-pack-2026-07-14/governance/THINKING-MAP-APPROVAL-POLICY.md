# Thinking map approval policy

**Owner**: Daniel · **ATM-45**

The agentic thinking map **cannot replace** human approval records.

| Rule | Detail |
|------|--------|
| Approval write | Only **record_approval** / operator action |
| Map role | Surface blockers, required_gate_id, lawful next move |
| Destructive execute | Requires **approved** status in governance/approval_gates.json |
| Audit | Map trace (if enabled) supplements — does not supersede approval JSON |

Ref: [INTEGRATION-CONTRACT-thinking-map-approval-gates.md](INTEGRATION-CONTRACT-thinking-map-approval-gates.md)

SIGNED: Security (Daniel) | ATM wave | 2026-06-28 | approval policy
