# SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY

**Status:** APPROVED (ATM-04) — 2026-06-28  
**Effective target:** 2026-06-28  
**Package:** [fpf-thinking-map on PyPI](https://pypi.org/project/fpf-thinking-map/) **v1.4.3**  
**Pin:** [requirements-thinking-map.txt](../requirements-thinking-map.txt) (`fpf-thinking-map==1.4.3`)

---

## 1. Purpose

Make the **Agentic Thinking Map** the mandatory **runtime move-legality layer** for all prichindel.com agents and decision MCPs on defined **triggers**. The map answers: *given this state, what is the lawful next move — and why is it blocked?*

It does **not** replace:

- **CHROMA-1** + `query_knowledge` (context, rules, patterns)
- **active.md** + workflow MCP (task, owner, status)
- **Grace triage** (row creation)

---

## 2. Three-layer model

| Layer | Instrument | Question |
|-------|------------|----------|
| Context | CHROMA-1, books, fpf catalog | What exists? What is the rule? |
| Task | active.md, get_current_step, report_done | What row? Who owns? |
| Move | `fpf_thinking_map`, **cursor-thinking-map** MCP | Lawful next move + blockers + response_contract |

When `governance/thinking_map_mode` = **1** (default), agents **must** call `thinking_map_step` on triggers below before irreversible action.

**When blocked:** [SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md](SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md) — second cortex self-reasoning allowed (`thinking_map_reason_for_self`); bytes still forbidden until CONTINUE.

When **0**, Ethan/CCB suspended map scope; governance and books still apply.

**Mandatory enforcement (binding):** [THINKING-MAP-MANDATORY-ENFORCEMENT.md](THINKING-MAP-MANDATORY-ENFORCEMENT.md) · Evidence tokens: [THINKING-MAP-EVIDENCE-TOKENS.md](THINKING-MAP-EVIDENCE-TOKENS.md) · Library evolution: [THINKING-MAP-LIBRARY-EVOLUTION-REQUIREMENTS.md](THINKING-MAP-LIBRARY-EVOLUTION-REQUIREMENTS.md)

---

## 3. Mandatory triggers

| Trigger | map_id | When |
|---------|--------|------|
| Multi-step workflow execute | `team_ops` | proceed / owner execute on OPEN row |
| Destructive / high-risk | `team_ops` | after list_pending_approvals, before bytes |
| Cluster / prod Abelard row | `cluster_ops` | cluster preflight chain |
| Approval write | `team_ops` | request_approval / record_approval |
| Hesperia interpret / calibrate | hesperia `fpf_bridge` | FPF-V7-11+ product path |

**Not mandatory:** single-line edits, read-only status, inbox read, routine grep.

---

## 4. MCP contract

**Server:** `cursor-thinking-map` · module `agent_mcp_thinking_map`

| Tool | Use |
|------|-----|
| `thinking_map_step` | One traversal step → JSON outcome |
| `thinking_map_verify` | Package health (19 checks) |
| `list_thinking_maps` | Domain map ids |
| `get_thinking_map_slice` | Debug slice |

**Flow (agent):** query_knowledge → get_current_step → **thinking_map_step** (if trigger) → execute → report_done

---

## 5. Domain maps (brain repo)

| map_id | Path | Owner |
|--------|------|-------|
| `team_ops` | `thinking_maps/team_ops/` | Felix |
| `cluster_ops` | `thinking_maps/cluster_ops/` | Felix + Abelard |

Engine code lives in **PyPI package only** — no vendored copy at repo root (shadowing hazard). Install: `bash scripts/install-thinking-map.sh`.

---

## 6. Hesperia relationship

`sphere/fpf_bridge/` consumes the same package. Brain wave **ATM-57..58** pins identical version. Ratification: **FPF-V7-10** + this spec **ATM-04**.

---

## 7. Anti-patterns

- Map on every turn (noise)
- Map replacing Grace triage or approval human record
- Re-adding C.32 / NQD candidate-multiplying patterns (rejected in package)
- Vendored duplicate of engine in brain repo root

---

## 8. Verification

- `bash scripts/install-thinking-map.sh`
- `bash scripts/verify-thinking-map-mcp.sh`
- [ATM-EXIT-CRITERIA.md](ATM-EXIT-CRITERIA.md) G1–G6

## 9. Library canonical (operator-sealed)

**Move-layer semantics = PyPI package only.** Brain repo documents **when** to call the map (triggers), **which** domain map (`team_ops`, `cluster_ops`), and **how** to wire MCP — not the engine's guard/logic/outcome definitions. Those live in `fpf-thinking-map` and surface via `thinking_map_step` JSON + `python -m fpf_thinking_map.verify`. Agents must not duplicate or override library outcomes in chat.

Ref: [agent_mcp_knowledge/FPF-THINKING-MAP-PYPI.md](../agent_mcp_knowledge/FPF-THINKING-MAP-PYPI.md)

---

SIGNED: Architecture (Ethan) | Agentic Thinking Map mandatory spec DRAFT | 2026-06-28 | ATM-03
