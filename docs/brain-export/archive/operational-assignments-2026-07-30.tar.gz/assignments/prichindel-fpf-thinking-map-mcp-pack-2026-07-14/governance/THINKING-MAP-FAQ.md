# FAQ — Chroma lookup vs thinking map runtime

**Owner**: Noah · **ATM-42**

## When do I use query_knowledge?

- Process, roles, workflow, cluster, agents, rules, books, architecture.  
- **First** for "what's the rule for X?"  
- Layer **`books`** when design/decisions need book-backed reasoning.

## Can agents rewrite move logic in chat?

**No.** Move semantics are in [fpf-thinking-map on PyPI](https://pypi.org/project/fpf-thinking-map/) v1.2.1. Brain repo wires triggers + domain maps + MCP. Agents **read `thinking_map_step` JSON** and obey — same as reading an API contract.

## When do I use cursor-thinking-map?

- **Only on mandatory triggers** (see [SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md](SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md)): workflow proceed, destructive/high-risk, Abelard cluster rows, approval writes, Hesperia `sphere/fpf_bridge`.  
- Returns **next lawful move**, blockers, `response_contract` — not static docs.

## When do I use colombo-library?

- Operator library / Papra books and papers on **CHROMA-2** — Colombo territory.  
- Not a substitute for team `query_knowledge` or thinking map.

## Can the map replace Grace triage?

**No.** Grace → active.md row creation. Map augments execution after triage.

## Can the map approve destructive work?

**No.** Human approval via **cursor-approval-gates** + `record_approval`. Map may surface blockers only.

## Where is map catalog metadata?

After ATM-40 ingest: CHROMA-1 layer **`thinking_map_catalog`** — map ids, triggers, owners. Until ingested, use repo `thinking_maps/` and [ATM-2026-REGISTER.md](ATM-2026-REGISTER.md).

SIGNED: Knowledge (Noah) | ATM wave | 2026-06-28 | FAQ
