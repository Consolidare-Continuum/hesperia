# Workflow API — thinking map metadata (optional)

**Owner**: Olivia · **ATM-46, 47, 65**

## GET /current_step — optional fields (future)

When `thinking_map_mode=1` and last map step ran for current row:

```json
{
  "has_step": true,
  "task_id": "ATM-31",
  "thinking_map": {
    "map_id": "team_ops",
    "outcome_kind": "ADVANCE",
    "blockers": [],
    "ts": "2026-06-28T12:00:00Z"
  }
}
```

Until backend implements: consumers read `governance/workflow_context_current.md` **Thinking map** section.

## Consumers

| Consumer | Read path |
|----------|-----------|
| Cursor IDE | workflow_context_current.md passport |
| Copilot main | Same + MCP get_current_step |
| External cron | GET /workflow/current_step (Bearer token) |

Ref: [BACKEND-API-CONTRACT-PHASE2B.md](BACKEND-API-CONTRACT-PHASE2B.md), [INTEGRATION-CONTRACT-thinking-map-pipeline.md](INTEGRATION-CONTRACT-thinking-map-pipeline.md)

## Passport template block (workflow_context_current.md)

```markdown
## Thinking map (when mode=1)
- map_id: team_ops
- outcome: ADVANCE | BLOCKED | IDLE
- blockers: (list or none)
- required_gate_id: (id or —)
```

SIGNED: Backend (Olivia) | ATM wave | 2026-06-28 | API metadata
