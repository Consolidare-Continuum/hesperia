---
task_id: "cursor|thinking-map|session"
active_md_anchor: "| thinking map |"
---

# Script runbook — Agentic Thinking Map session use

**Id:** `SCRIPT-RUNBOOK-thinking-map-session`  
**Owner:** All agents · **Refs:** [SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md](../governance/SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md)

## When to use (mandatory triggers)

- Multi-step **workflow proceed** as task owner
- **Destructive / high-risk** work (after `list_pending_approvals`)
- **Abelard cluster / prod** rows — preflight before SSH
- **Approval write** path

Skip for read-only status, single-line edits, Grace triage row creation.

## Flow

1. `query_knowledge` — context (CHROMA-1)
2. `get_current_step` — task owner
3. **`thinking_map_step`** with appropriate `map_id`:
   - `team_ops` — workflow, approval, report_done chain
   - `cluster_ops` — SSH, trustmaster, cert guards
   - `eod_ops` — end-of-day collect → commit → Chroma (`scripts/end_of_day_run.sh`)
4. Read outcome JSON — **library is canonical**; do not paraphrase Move rules:
   - `kind`, `reason`, `missing_evidence`, `blockers`
   - `llm_prompt_state.gate_status`, `possible_transitions`, `logic` (rules/actions)
   - `response_contract` when present
5. Execute only if outcome allows; else use **§ RFSA** (second cortex) — not silent stall
6. `report_done` when owner completes row

## RFSA — reasoning for self allowed (when blocked)

When `kind=COLLECT_EVIDENCE`, blockers, or missing evidence:

1. **`thinking_map_reason_for_self`** — plan from outcome JSON (or `run_step_first=true`)
2. Run **recommended_next_mcp_calls** from plan (read-only / gate MCPs)
3. Add honest evidence tokens → **thinking_map_inquire** / **thinking_map_step**
4. Execute bytes only after `kind=CONTINUE` / ADVANCE

Ref: [SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md](../governance/SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md)

## Evidence tokens

Pass comma-separated **`current_evidence`** after real MCP steps. Full table: [governance/THINKING-MAP-EVIDENCE-TOKENS.md](../governance/THINKING-MAP-EVIDENCE-TOKENS.md).

**Mandatory enforcement:** [governance/THINKING-MAP-MANDATORY-ENFORCEMENT.md](../governance/THINKING-MAP-MANDATORY-ENFORCEMENT.md) — process violation if skipped on trigger.

## MCP tools

| Tool | Purpose |
|------|---------|
| `thinking_map_verify` | Health check (19 package checks) |
| `list_thinking_maps` | Available domain maps |
| `thinking_map_step` | One lawful step |
| `thinking_map_inquire` | Chain terminal move after MCP evidence |
| `thinking_map_reason_for_self` | Second cortex plan when blocked |
| `get_thinking_map_slice` | Debug |

## Example

```
thinking_map_step(
  map_id="team_ops",
  task="ATM-05 package pin",
  actor_role_ids="task_owner",
  current_state="executing",
  current_evidence="task_id,runbook_read"
)
```

## Install / verify (Abelard)

```bash
bash scripts/install-thinking-map.sh
bash scripts/verify-thinking-map-mcp.sh
```

## thinking_map_mode

`governance/thinking_map_mode` = **1** → triggers active. **0** → Ethan/CCB suspended scope.

SIGNED: Triage (Grace) | thinking map session runbook | 2026-06-28 | ATM-21
