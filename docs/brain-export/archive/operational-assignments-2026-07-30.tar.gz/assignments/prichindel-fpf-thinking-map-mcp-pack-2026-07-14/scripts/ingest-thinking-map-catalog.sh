#!/usr/bin/env bash
# CHROMA-1 ingest thinking_map_catalog layer (ATM-40). Run on host with CHROMA + venv.
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="${MCP_VENV_PYTHON:-/data/chroma/venv/bin/python}"
export BOOKS_EMBED_CLIENT="${BOOKS_EMBED_CLIENT:-1}"
export CHROMA_SERVER_URL="${CHROMA_SERVER_URL:-http://chroma-1.prichindel.local:8002}"
export PYTHONPATH="$REPO_ROOT"
cd "$REPO_ROOT"
exec "$PY" cluster/chroma-server/ingest_thinking_map_catalog.py
