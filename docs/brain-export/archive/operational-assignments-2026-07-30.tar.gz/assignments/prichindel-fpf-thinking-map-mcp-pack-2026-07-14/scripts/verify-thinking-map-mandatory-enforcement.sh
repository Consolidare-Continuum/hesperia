#!/usr/bin/env bash
# Verify thinking-map mandatory enforcement wiring (rules, mode, MCP config, runbooks).
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"
fail=0

check_file_contains() {
  local file="$1" pattern="$2" label="$3"
  if [[ ! -f "$file" ]]; then
    echo "FAIL missing file: $file ($label)"
    fail=$((fail + 1))
    return
  fi
  if ! grep -qE "$pattern" "$file"; then
    echo "FAIL $label: $file lacks /$pattern/"
    fail=$((fail + 1))
  else
    echo "OK   $label"
  fi
}

mode="$(tr -d '[:space:]' < governance/thinking_map_mode 2>/dev/null || echo 0)"
echo "== thinking_map_mode=$mode =="
if [[ "$mode" != "1" ]]; then
  echo "WARN thinking_map_mode not 1 — enforcement suspended by flag"
fi

echo "== core governance =="
check_file_contains governance/SPEC-ETHAN-AGENTIC-THINKING-MAP-MANDATORY.md "thinking_map_step" "SPEC"
check_file_contains governance/THINKING-MAP-MANDATORY-ENFORCEMENT.md "mandatory" "ENFORCEMENT doc"
check_file_contains governance/ETHAN-TARGETED-RUNBOOKS-MANDATORY.md "SCRIPT-RUNBOOK-thinking-map-session" "targeted runbooks"
check_file_contains governance/MCP-COMPLIANCE-AND-OPERATIONAL.md "cursor-thinking-map" "MCP compliance"
check_file_contains governance/AGENT-QUALITY-FLOOR.md "thinking_map" "quality floor"

echo "== alwaysApply rules =="
for f in \
  .cursor/rules/cursor-thinking-map-mandatory.mdc \
  .cursor/rules/cursor-mcp-chroma-first.mdc \
  .cursor/rules/cursor-agent-quality-floor.mdc \
  .cursor/rules/agents-by-name.mdc \
  .cursor/rules/cursor-main-awareness.mdc; do
  check_file_contains "$f" "thinking_map|cursor-thinking-map" "$(basename "$f")"
done

echo "== entity rules =="
for f in .cursor/rules/abelard-cluster.mdc .cursor/rules/felix-developer.mdc .cursor/rules/gena-developer.mdc .cursor/rules/colombo-researcher.mdc; do
  check_file_contains "$f" "thinking_map|cursor-thinking-map" "$(basename "$f")"
done

echo "== MCP config =="
check_file_contains governance/mcp-config.json "cursor-thinking-map" "mcp-config"
check_file_contains .cursor/mcp.json "cursor-thinking-map" "project mcp.json"

echo "== runbooks =="
check_file_contains scripts/SCRIPT-RUNBOOK-thinking-map-session.md "thinking_map_step" "thinking-map session"
check_file_contains scripts/SCRIPT-RUNBOOK-mcp-brain-session-opener.md "thinking_map" "session opener"
check_file_contains scripts/runbooks/SCRIPT-RUNBOOK-workflow-proceed-gates.md "thinking_map" "proceed gates"
check_file_contains scripts/runbooks/SCRIPT-RUNBOOK-cluster-proceed-preflight.md "thinking_map_step" "cluster preflight"

echo "== workflow driver =="
check_file_contains scripts/workflow_driver.py "thinking_map" "workflow_driver"

echo "== hard gate script =="
check_file_contains scripts/thinking-map-hard-gate.sh "BRAIN_SHUTDOWN" "hard gate"
check_file_contains scripts/workflow_run.sh "thinking-map-hard-gate" "workflow_run gate"
check_file_contains scripts/workflow_automation_run.sh "thinking-map-hard-gate" "workflow_automation gate"
check_file_contains scripts/end_of_day_run.sh "thinking-map-hard-gate" "EOD run gate"
check_file_contains scripts/end_of_day_collect.sh "thinking-map-hard-gate" "EOD collect gate"
check_file_contains thinking_maps/eod_ops/map.py "cursor_eod" "eod_ops map"
check_file_contains governance/mcp_thinking_map_registry.json "workflow_execute" "MCP registry"
check_file_contains thinking_maps/mcp_inquiry.py "run_inquiry" "mcp_inquiry module"
check_file_contains agent_mcp_thinking_map/__main__.py "thinking_map_inquire" "inquire MCP tool"
check_file_contains scripts/mcp-thinking-map-inquire.sh "thinking-map-hard-gate" "mcp inquire script"
check_file_contains agent_mcp_thinking_map/__main__.py "thinking_map_reason_for_self" "RFSA MCP tool"
check_file_contains governance/SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md "second cortex" "RFSA spec"
check_file_contains thinking_maps/blocker_registry.py "register_from_outcome" "blocker registry"
check_file_contains agent_mcp_thinking_map/__main__.py "list_thinking_map_blockers" "blocker MCP list"
check_file_contains scripts/thinking-map-blockers-eod.sh "render_eod_digest" "blocker EOD script"
check_file_contains governance/mcp_thinking_map_registry.json "cursor-ide-browser" "registry covers ide-browser"
check_file_contains governance/mcp_thinking_map_registry.json "cloudflare-observability" "registry covers cloudflare"
check_file_contains governance/mcp_thinking_map_registry.json "\"version\": 2" "registry full-coverage v2"

echo "== package verify =="
bash scripts/verify-thinking-map-mcp.sh

if [[ "$fail" -gt 0 ]]; then
  echo "FAIL: $fail enforcement check(s)"
  exit 1
fi
echo "OK: verify-thinking-map-mandatory-enforcement"
