#!/usr/bin/env bash
# Write EOD blocker digest from fpf-thinking-map registry.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$REPO_ROOT"
PY="${MCP_VENV_PYTHON:-/data/chroma/venv/bin/python}"
[[ -x "$PY" ]] || PY="$(command -v python3)"
export PYTHONPATH="$REPO_ROOT"
DATE_TAG="$(date -u +%F)"
OUT="${1:-$REPO_ROOT/operational/assignments/reports/EOD-BLOCKERS-${DATE_TAG}.md}"
mkdir -p "$(dirname "$OUT")"
"$PY" -c "
from pathlib import Path
from thinking_maps.blocker_registry import pending_for_eod, render_eod_digest
root = Path('$REPO_ROOT')
text = render_eod_digest(root)
Path('$OUT').write_text(text, encoding='utf-8')
print(f'Wrote $OUT ({len(pending_for_eod(root))} pending)')
"
