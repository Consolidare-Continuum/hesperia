#!/usr/bin/env bash
# Smoke: thinking map domain maps + MCP module import (ATM-15).
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${MCP_VENV_PYTHON:-/data/chroma/venv/bin/python}"
if [[ ! -x "$PY" ]]; then
  PY="$(command -v python3)"
fi
export PYTHONPATH="$REPO_ROOT"
cd "$REPO_ROOT"
echo "== fpf_thinking_map verify (PyPI) =="
"$PY" -m pip show fpf-thinking-map | grep -E '^Version:' || true
"$PY" -m fpf_thinking_map.verify
echo "== domain maps =="
"$PY" -c "
from thinking_maps.team_ops.map import build_team_ops_map, build_team_ops_logic
from thinking_maps.cluster_ops.map import build_cluster_ops_map
from thinking_maps.eod_ops.map import build_eod_ops_map
from fpf_thinking_map.state import RuntimeBinding
from fpf_thinking_map.traversal import ThinkingMapTraversal
e = ThinkingMapTraversal(build_team_ops_map(), logic_layer=build_team_ops_logic())
s = e.build_active_state(RuntimeBinding(task='verify', actor_role_ids=['task_owner'], active_context_id='team_workflow', current_evidence=['task_id']), 'start')
assert e.step(s).kind is not None
ThinkingMapTraversal(build_cluster_ops_map())
ThinkingMapTraversal(build_eod_ops_map())
print('domain maps ok')
"
echo "== MCP module import =="
"$PY" -c "import agent_mcp_thinking_map; print('agent_mcp_thinking_map ok')" 2>/dev/null || echo "WARN: mcp package not on this host — import skipped"
echo "== pytest thinking_maps =="
if "$PY" -m pytest --version >/dev/null 2>&1; then
  "$PY" -m pytest thinking_maps/tests/ -q --tb=short
else
  echo "pytest not in venv — domain maps smoke only (install pytest for full matrix on dev office)"
fi
echo "OK: verify-thinking-map-mcp"
