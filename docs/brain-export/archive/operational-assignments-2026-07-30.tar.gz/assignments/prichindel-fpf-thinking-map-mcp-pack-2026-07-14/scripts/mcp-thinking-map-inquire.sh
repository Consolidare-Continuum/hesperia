#!/usr/bin/env bash
# MCP ↔ fpf-thinking-map inquiry at key points (registry-driven).
# Usage:
#   bash scripts/mcp-thinking-map-inquire.sh chain workflow_execute
#   bash scripts/mcp-thinking-map-inquire.sh inquire workflow_execute --evidence task_id,query_knowledge_done,...
#   bash scripts/mcp-thinking-map-inquire.sh list [mcp_id]
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$REPO_ROOT"
bash "$REPO_ROOT/scripts/thinking-map-hard-gate.sh"
PY="${MCP_VENV_PYTHON:-/data/chroma/venv/bin/python}"
[[ -x "$PY" ]] || PY="$(command -v python3)"
export PYTHONPATH="$REPO_ROOT"
export CURSOR_REPO_ROOT="$REPO_ROOT"

cmd="${1:-help}"
shift || true

case "$cmd" in
  chain)
    chain_id="${1:?chain_id}"
    shift || true
    evidence=""
    destructive=0
    while [[ $# -gt 0 ]]; do
      case "$1" in
        --evidence) evidence="$2"; shift 2 ;;
        --require-ready) require=1; shift ;;
        *) shift ;;
      esac
    done
    exec "$PY" "$REPO_ROOT/scripts/thinking_map_cli.py" chain "$chain_id" --current-evidence "$evidence" ${require:+--require-ready}
    ;;
  inquire)
    chain_id="${1:-}"
    shift || true
    key_point=""
    evidence=""
    task_id=""
    destructive=0
    while [[ $# -gt 0 ]]; do
      case "$1" in
        --key-point) key_point="$2"; shift 2 ;;
        --evidence) evidence="$2"; shift 2 ;;
        --task-id) task_id="$2"; shift 2 ;;
        --destructive) destructive=1; shift ;;
        --json) json=1; shift ;;
        *) shift ;;
      esac
    done
    args=(inquire --chain-id "$chain_id" --key-point-id "$key_point" --current-evidence "$evidence" --task-id "$task_id")
    [[ "$destructive" == "1" ]] && args+=(--destructive)
    [[ "${json:-0}" == "1" ]] && args+=(--json)
    exec "$PY" "$REPO_ROOT/scripts/thinking_map_cli.py" "${args[@]}"
    ;;
  list)
    mcp_id="${1:-}"
    exec "$PY" -c "
import json, sys
from thinking_maps.mcp_inquiry import key_points_for_mcp, list_key_points
mcp = sys.argv[1] if len(sys.argv) > 1 else ''
pts = key_points_for_mcp(mcp) if mcp else list_key_points()
print(json.dumps([{'id': p.id, 'mcp': p.mcp, 'tool': p.tool, 'evidence_token': p.evidence_token} for p in pts], indent=2))
" "$mcp_id"
    ;;
  help|*)
    sed -n '2,6p' "$0"
    exit 0
    ;;
esac
