#!/usr/bin/env python3
"""Brain CLI for fpf-thinking-map — scripts/EOD/workflow without MCP subprocess."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from fpf_thinking_map.state import RuntimeBinding
from fpf_thinking_map.traversal import ThinkingMapTraversal

from agent_mcp_thinking_map.trace_io import write_trace
from thinking_maps.cluster_ops.map import build_cluster_ops_map
from thinking_maps.eod_ops.map import build_eod_ops_map
from thinking_maps.team_ops.map import build_team_ops_logic, build_team_ops_map

MAP_BUILDERS: dict[str, Any] = {
    "team_ops": build_team_ops_map,
    "cluster_ops": build_cluster_ops_map,
    "eod_ops": build_eod_ops_map,
}

LOGIC_BUILDERS: dict[str, Any] = {
    "team_ops": build_team_ops_logic,
}


def _engine(map_id: str) -> ThinkingMapTraversal:
    if map_id not in MAP_BUILDERS:
        raise SystemExit(f"unknown map_id: {map_id}")
    sm = MAP_BUILDERS[map_id]()
    logic = LOGIC_BUILDERS[map_id]() if map_id in LOGIC_BUILDERS else None
    return ThinkingMapTraversal(sm, logic_layer=logic)


def _outcome_dict(outcome: Any) -> dict[str, Any]:
    llm = getattr(outcome, "llm_prompt_state", None)
    return {
        "kind": str(outcome.kind),
        "reason": getattr(outcome, "reason", ""),
        "next_state": getattr(outcome, "next_state", None),
        "missing_evidence": getattr(outcome, "missing_evidence", None),
        "blockers": getattr(outcome, "blockers", None),
        "llm_prompt_state": llm,
    }


def cmd_verify(_: argparse.Namespace) -> int:
    proc = subprocess.run(
        [sys.executable, "-m", "fpf_thinking_map.verify"],
        cwd=str(REPO_ROOT),
        check=False,
    )
    return proc.returncode


def cmd_step(args: argparse.Namespace) -> int:
    engine = _engine(args.map_id)
    roles = [r.strip() for r in args.actor_role_ids.split(",") if r.strip()]
    evidence = [e.strip() for e in args.current_evidence.split(",") if e.strip()]
    ctx = args.active_context_id.strip() or (
        "cursor_eod" if args.map_id == "eod_ops" else "team_workflow"
    )
    binding = RuntimeBinding(
        task=args.task or "cli step",
        actor_role_ids=roles,
        active_context_id=ctx,
        current_evidence=evidence,
    )
    state = engine.build_active_state(binding, current_state=args.current_state)
    outcome = engine.step(state)
    write_trace(REPO_ROOT, args.map_id, args.task or "cli step", outcome, task_id=args.task_id)
    payload = _outcome_dict(outcome)
    if args.json:
        print(json.dumps(payload, indent=2, default=str))
    else:
        print(f"kind={payload['kind']} next_state={payload['next_state']} missing={payload['missing_evidence']}")
    kind = str(outcome.kind)
    if "BLOCK" in kind.upper():
        return 2
    return 0


def cmd_eod_phase(args: argparse.Namespace) -> int:
    """Run one EOD map step; exit non-zero if library blocks."""
    phase = args.phase
    state_map = {
        "gate": ("start", "thinking_map_verify_done"),
        "collect": ("collecting", "eod_collect_done"),
        "structure": ("structuring", "eod_structure_checked"),
        "compliance": ("compliance", "eod_compliance_row"),
        "lessons": ("lessons", "eod_lessons_checked"),
        "commit": ("committing", "eod_git_pushed"),
        "chroma": ("chroma", "eod_chroma_closed"),
    }
    if phase not in state_map:
        raise SystemExit(f"unknown phase: {phase}")
    current_state, evidence = state_map[phase]
    if phase == "gate":
        if cmd_verify(args) != 0:
            return 42
        evidence_list = evidence
    else:
        evidence_list = f"thinking_map_verify_done,{evidence}"
    ns = argparse.Namespace(
        map_id="eod_ops",
        task=f"EOD {phase}",
        actor_role_ids="cursor_main",
        active_context_id="cursor_eod",
        current_state=current_state,
        current_evidence=evidence_list,
        task_id=f"EOD-{phase}",
        json=args.json,
    )
    return cmd_step(ns)


def cmd_chain(args: argparse.Namespace) -> int:
    from thinking_maps.mcp_inquiry import chain_checklist

    evidence = [e.strip() for e in args.current_evidence.split(",") if e.strip()]
    payload = chain_checklist(args.chain_id, evidence)
    print(json.dumps(payload, indent=2))
    if args.require_ready and not payload.get("ready_for_move"):
        return 2
    return 0


def cmd_inquire(args: argparse.Namespace) -> int:
    from thinking_maps.mcp_inquiry import run_inquiry

    evidence = [e.strip() for e in args.current_evidence.split(",") if e.strip()]
    result = run_inquiry(
        chain_id=args.chain_id,
        key_point_id=args.key_point_id,
        task=args.task or args.chain_id or args.key_point_id,
        task_id=args.task_id,
        actor_role_ids=args.actor_role_ids,
        current_evidence=evidence,
        destructive=args.destructive,
    )
    outcome = result.pop("_outcome", None)
    if outcome is not None:
        write_trace(
            REPO_ROOT,
            result["map_id"],
            args.task or args.chain_id or args.key_point_id,
            outcome,
            trigger="thinking_map_inquire_cli",
            task_id=args.task_id,
        )
    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        print(f"action={result.get('action')} kind={result.get('kind')} missing={result.get('missing_evidence')}")
    if result.get("action") == "blocked_missing_mcp_evidence":
        return 2
    kind = str(result.get("kind", ""))
    if "BLOCK" in kind.upper():
        return 2
    return 0


def cmd_reason_for_self(args: argparse.Namespace) -> int:
    from thinking_maps.reason_for_self import reason_for_self_plan

    missing = [e.strip() for e in args.missing_evidence.split(",") if e.strip()]
    blockers = [b.strip() for b in args.blockers.split(",") if b.strip()]
    evidence = [e.strip() for e in args.current_evidence.split(",") if e.strip()]
    llm: dict[str, Any] = {}
    if args.llm_json:
        llm = json.loads(args.llm_json)
    plan = reason_for_self_plan(
        kind=args.kind,
        reason=args.reason,
        missing_evidence=missing,
        blockers=blockers,
        llm_prompt_state=llm,
        chain_id=args.chain_id,
        map_id=args.map_id,
        current_evidence=evidence,
    )
    print(json.dumps(plan, indent=2, default=str))
    return 0


def _cmd_blockers_list(args: argparse.Namespace) -> int:
    from thinking_maps.blocker_registry import list_blockers

    statuses = tuple(s.strip() for s in args.status.split(",") if s.strip())
    rows = list_blockers(REPO_ROOT, statuses=statuses)
    print(json.dumps(rows, indent=2))
    return 0


def _cmd_blockers_fixed(args: argparse.Namespace) -> int:
    from thinking_maps.blocker_registry import mark_fixed_runtime

    row = mark_fixed_runtime(REPO_ROOT, args.blocker_id, args.note)
    if not row:
        print(f"ERROR unknown blocker_id {args.blocker_id}")
        return 1
    print(json.dumps(row, indent=2))
    return 0


def _cmd_blockers_close(args: argparse.Namespace) -> int:
    from thinking_maps.blocker_registry import close_eod

    row = close_eod(REPO_ROOT, args.blocker_id, args.note)
    if not row:
        print(f"ERROR unknown blocker_id {args.blocker_id}")
        return 1
    print(json.dumps(row, indent=2))
    return 0


def _cmd_blockers_digest(args: argparse.Namespace) -> int:
    from thinking_maps.blocker_registry import pending_for_eod, render_eod_digest

    text = render_eod_digest(REPO_ROOT)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"Wrote {args.out} ({len(pending_for_eod(REPO_ROOT))} pending)")
    else:
        print(text)
    return 0


def main() -> int:
    os.environ.setdefault("CURSOR_REPO_ROOT", str(REPO_ROOT))
    parser = argparse.ArgumentParser(description="fpf-thinking-map brain CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_verify = sub.add_parser("verify", help="Run fpf_thinking_map.verify")
    p_verify.set_defaults(func=cmd_verify)

    p_step = sub.add_parser("step", help="One lawful traversal step")
    p_step.add_argument("--map-id", default="team_ops")
    p_step.add_argument("--task", default="")
    p_step.add_argument("--actor-role-ids", default="task_owner")
    p_step.add_argument("--active-context-id", default="")
    p_step.add_argument("--current-state", default="start")
    p_step.add_argument("--current-evidence", default="")
    p_step.add_argument("--task-id", default="")
    p_step.add_argument("--json", action="store_true")
    p_step.set_defaults(func=cmd_step)

    p_eod = sub.add_parser("eod-phase", help="EOD eod_ops map step for a phase")
    p_eod.add_argument("phase", choices=["gate", "collect", "structure", "compliance", "lessons", "commit", "chroma"])
    p_eod.add_argument("--json", action="store_true")
    p_eod.set_defaults(func=cmd_eod_phase)

    p_chain = sub.add_parser("chain", help="MCP inquiry chain checklist")
    p_chain.add_argument("chain_id")
    p_chain.add_argument("--current-evidence", default="")
    p_chain.add_argument("--require-ready", action="store_true")
    p_chain.set_defaults(func=cmd_chain)

    p_inq = sub.add_parser("inquire", help="thinking_map_inquire via registry")
    p_inq.add_argument("--chain-id", default="")
    p_inq.add_argument("--key-point-id", default="")
    p_inq.add_argument("--task", default="")
    p_inq.add_argument("--task-id", default="")
    p_inq.add_argument("--actor-role-ids", default="task_owner")
    p_inq.add_argument("--current-evidence", default="")
    p_inq.add_argument("--destructive", action="store_true")
    p_inq.add_argument("--json", action="store_true")
    p_inq.set_defaults(func=cmd_inquire)

    p_rfs = sub.add_parser("reason-for-self", help="Second cortex plan when Move blocks")
    p_rfs.add_argument("--kind", default="COLLECT_EVIDENCE")
    p_rfs.add_argument("--reason", default="")
    p_rfs.add_argument("--missing-evidence", default="")
    p_rfs.add_argument("--blockers", default="")
    p_rfs.add_argument("--llm-json", default="")
    p_rfs.add_argument("--chain-id", default="")
    p_rfs.add_argument("--map-id", default="team_ops")
    p_rfs.add_argument("--current-evidence", default="")
    p_rfs.set_defaults(func=cmd_reason_for_self)

    p_blk = sub.add_parser("blockers", help="Technical blocker registry (fpf-thinking-map catch)")
    blk_sub = p_blk.add_subparsers(dest="blk_cmd", required=True)
    p_blk_list = blk_sub.add_parser("list", help="List blockers")
    p_blk_list.add_argument("--status", default="open,fixed_runtime")
    p_blk_list.set_defaults(func=lambda a: _cmd_blockers_list(a))
    p_blk_fix = blk_sub.add_parser("fixed-runtime", help="Mark fixed at runtime")
    p_blk_fix.add_argument("blocker_id")
    p_blk_fix.add_argument("--note", default="")
    p_blk_fix.set_defaults(func=lambda a: _cmd_blockers_fixed(a))
    p_blk_close = blk_sub.add_parser("close-eod", help="Close at EOD")
    p_blk_close.add_argument("blocker_id")
    p_blk_close.add_argument("--note", default="")
    p_blk_close.set_defaults(func=lambda a: _cmd_blockers_close(a))
    p_blk_digest = blk_sub.add_parser("digest", help="Write EOD digest markdown")
    p_blk_digest.add_argument("--out", default="")
    p_blk_digest.set_defaults(func=lambda a: _cmd_blockers_digest(a))

    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
