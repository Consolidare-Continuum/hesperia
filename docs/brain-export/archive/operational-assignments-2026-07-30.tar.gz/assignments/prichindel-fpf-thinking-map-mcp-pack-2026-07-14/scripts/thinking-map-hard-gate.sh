#!/usr/bin/env bash
# Hard dependency gate: brain repo MUST NOT run without fpf-thinking-map when mode=1.
# Exit 42 = BRAIN_SHUTDOWN (remove package → all gated scripts stop).
# Breakglass only: THINKING_MAP_BREAKGLASS=1 (logged to governance/thinking_map_breakglass.log).
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$REPO_ROOT"

MODE="$(tr -d '[:space:]' < governance/thinking_map_mode 2>/dev/null || echo 0)"
if [[ "$MODE" != "1" ]]; then
  echo "thinking-map-hard-gate: SKIP (thinking_map_mode=$MODE)"
  exit 0
fi

if [[ "${THINKING_MAP_BREAKGLASS:-}" == "1" ]]; then
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "$ts BREAKGLASS caller=${THINKING_MAP_BREAKGLASS_CALLER:-unknown} host=$(hostname -s)" \
    >> governance/thinking_map_breakglass.log
  echo "WARN: thinking-map hard gate bypassed (THINKING_MAP_BREAKGLASS=1)" >&2
  exit 0
fi

PY="${MCP_VENV_PYTHON:-/data/chroma/venv/bin/python}"
if [[ ! -x "$PY" ]]; then
  PY="$(command -v python3 || true)"
fi
if [[ -z "$PY" || ! -x "$PY" ]]; then
  echo "BRAIN_SHUTDOWN: no python for fpf-thinking-map (mode=1)" >&2
  exit 42
fi

if [[ ! -f requirements-thinking-map.txt ]]; then
  echo "BRAIN_SHUTDOWN: missing requirements-thinking-map.txt" >&2
  exit 42
fi

if ! "$PY" -m pip show fpf-thinking-map >/dev/null 2>&1; then
  echo "BRAIN_SHUTDOWN: fpf-thinking-map not installed — run: bash scripts/install-thinking-map.sh" >&2
  exit 42
fi

if ! "$PY" -m fpf_thinking_map.verify >/dev/null 2>&1; then
  echo "BRAIN_SHUTDOWN: fpf_thinking_map.verify failed" >&2
  exit 42
fi

export PYTHONPATH="$REPO_ROOT"
if ! "$PY" -c "
from thinking_maps.team_ops.map import build_team_ops_map
from thinking_maps.cluster_ops.map import build_cluster_ops_map
from thinking_maps.eod_ops.map import build_eod_ops_map
from fpf_thinking_map.traversal import ThinkingMapTraversal
ThinkingMapTraversal(build_team_ops_map())
ThinkingMapTraversal(build_cluster_ops_map())
ThinkingMapTraversal(build_eod_ops_map())
import agent_mcp_thinking_map
" 2>/dev/null; then
  echo "BRAIN_SHUTDOWN: domain maps or agent_mcp_thinking_map import failed" >&2
  exit 42
fi

echo "OK: thinking-map-hard-gate (fpf-thinking-map v1.2.1 + domain maps)"
