#!/usr/bin/env bash
# Install fpf-thinking-map from PyPI into MCP Python venv.
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${MCP_VENV_PYTHON:-/data/chroma/venv/bin/python}"
if [[ ! -x "$PY" ]]; then
  PY="$(command -v python3)"
fi
"$PY" -m pip install -U -r "$REPO_ROOT/requirements-thinking-map.txt"
"$PY" -m fpf_thinking_map.verify
"$PY" -m pip show fpf-thinking-map | grep -E '^(Name|Version|Location):'
echo "OK: fpf-thinking-map (PyPI) installed and verified"
