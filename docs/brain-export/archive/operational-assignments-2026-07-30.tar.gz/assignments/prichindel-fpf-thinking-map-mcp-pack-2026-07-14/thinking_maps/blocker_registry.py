"""Technical blocker registry — caught from fpf-thinking-map, EOD review queue."""

from __future__ import annotations

import json
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any

BLOCKER_REGISTRY = "thinking_map_blockers.jsonl"

STATUS_OPEN = "open"
STATUS_FIXED_RUNTIME = "fixed_runtime"
STATUS_EOD_CLOSED = "eod_closed"

ACCESS_DENIED_PATTERNS = (
    r"access\s+denied",
    r"permission\s+denied",
    r"agent_cert",
    r"ssh.*denied",
    r"forbidden",
    r"\b403\b",
    r"\b401\b",
    r"trusteduserca",
    r"fix_agent_cluster_access",
)

COLLECT_PATTERNS = (
    r"collect_evidence",
    r"missing_evidence",
    r"approval_id",
    r"snapshot_fresh",
)


def registry_path(repo_root: Path) -> Path:
    return repo_root / "governance" / BLOCKER_REGISTRY


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _classify(
    *,
    outcome_kind: str,
    reason: str,
    missing_evidence: list[str] | None,
    blockers: list[str] | None,
) -> str:
    blob = " ".join(
        [outcome_kind, reason]
        + list(missing_evidence or [])
        + list(blockers or [])
    ).lower()
    for pat in ACCESS_DENIED_PATTERNS:
        if re.search(pat, blob, re.I):
            return "access_denied"
    kind = (outcome_kind or "").upper()
    if "COLLECT_EVIDENCE" in kind or any(
        re.search(p, blob, re.I) for p in COLLECT_PATTERNS
    ):
        return "collect_evidence"
    if blockers:
        return "gate_blocker"
    if missing_evidence:
        return "missing_evidence"
    return "technical"


def _is_blocker_outcome(
    outcome_kind: str,
    missing_evidence: list[str] | None,
    blockers: list[str] | None,
) -> bool:
    kind = (outcome_kind or "").upper()
    if any(x in kind for x in ("COLLECT_EVIDENCE", "BLOCK", "BLOCKED", "INSUFFICIENT", "HITL")):
        return True
    return bool(missing_evidence) or bool(blockers)


def _append_row(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")


def _load_rows(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def _latest_by_id(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for row in rows:
        bid = row.get("blocker_id")
        if bid:
            out[bid] = row
    return out


def register_from_outcome(
    repo_root: Path,
    *,
    map_id: str,
    task: str,
    outcome: Any,
    trigger: str = "thinking_map_step",
    task_id: str = "",
    trace_id: str = "",
    mcp_id: str = "",
    key_point_id: str = "",
    chain_id: str = "",
) -> dict[str, Any] | None:
    """Register technical blocker from fpf-thinking-map outcome. Returns row or None."""
    if os.environ.get("THINKING_MAP_BLOCKER_REGISTER", "1").strip().lower() in ("0", "false", "no"):
        return None

    kind = str(getattr(outcome, "kind", ""))
    reason = str(getattr(outcome, "reason", "") or "")
    missing = getattr(outcome, "missing_evidence", None) or []
    blockers = getattr(outcome, "blockers", None) or []
    if isinstance(blockers, str):
        blockers = [blockers]
    if isinstance(missing, str):
        missing = [missing]

    if not _is_blocker_outcome(kind, list(missing), list(blockers)):
        return None

    blocker_class = _classify(
        outcome_kind=kind,
        reason=reason,
        missing_evidence=list(missing),
        blockers=list(blockers),
    )
    row = {
        "blocker_id": uuid.uuid4().hex[:12],
        "registered_at": _now_iso(),
        "status": STATUS_OPEN,
        "class": blocker_class,
        "source": "fpf-thinking-map",
        "catch_trigger": trigger,
        "map_id": map_id,
        "task": (task or "")[:200],
        "task_id": (task_id or "").strip(),
        "trace_id": trace_id,
        "mcp_id": mcp_id or os.environ.get("THINKING_MAP_MCP_ID", ""),
        "key_point_id": key_point_id or os.environ.get("THINKING_MAP_KEY_POINT_ID", ""),
        "chain_id": chain_id,
        "outcome_kind": kind,
        "reason": reason[:500],
        "missing_evidence": list(missing),
        "blockers": list(blockers),
        "execution_host": os.environ.get("THINKING_MAP_EXECUTION_HOST", "") or os.environ.get("HOSTNAME", ""),
        "fixed_runtime_at": None,
        "fixed_runtime_note": "",
        "eod_closed_at": None,
        "eod_note": "",
    }
    _append_row(registry_path(repo_root), row)
    return row


def register_from_result(repo_root: Path, result: dict[str, Any], **meta: Any) -> dict[str, Any] | None:
    """Register from thinking_map_inquire / run_inquiry JSON dict."""

    class _Outcome:
        pass

    o = _Outcome()
    o.kind = result.get("kind") or (
        "COLLECT_EVIDENCE" if result.get("action") == "blocked_missing_mcp_evidence" else ""
    )
    o.reason = result.get("reason", "")
    o.missing_evidence = result.get("missing_evidence") or []
    o.blockers = result.get("blockers") or []
    return register_from_outcome(
        repo_root,
        map_id=str(result.get("map_id") or meta.get("map_id") or "team_ops"),
        task=str(meta.get("task") or result.get("chain_id") or result.get("key_point_id") or ""),
        outcome=o,
        trigger=str(meta.get("trigger") or "thinking_map_inquire"),
        task_id=str(meta.get("task_id") or ""),
        chain_id=str(result.get("chain_id") or meta.get("chain_id") or ""),
    )


def list_blockers(
    repo_root: Path,
    *,
    statuses: tuple[str, ...] | None = None,
    since: str = "",
) -> list[dict[str, Any]]:
    latest = _latest_by_id(_load_rows(registry_path(repo_root)))
    rows = list(latest.values())
    if statuses:
        rows = [r for r in rows if r.get("status") in statuses]
    if since:
        rows = [r for r in rows if (r.get("registered_at") or "") >= since]
    rows.sort(key=lambda r: r.get("registered_at") or "", reverse=True)
    return rows


def pending_for_eod(repo_root: Path) -> list[dict[str, Any]]:
    return list_blockers(repo_root, statuses=(STATUS_OPEN, STATUS_FIXED_RUNTIME))


def mark_fixed_runtime(
    repo_root: Path,
    blocker_id: str,
    note: str = "",
) -> dict[str, Any] | None:
    """Fixed during session — still on EOD queue."""
    latest = _latest_by_id(_load_rows(registry_path(repo_root)))
    base = latest.get(blocker_id)
    if not base:
        return None
    row = {**base, "status": STATUS_FIXED_RUNTIME, "fixed_runtime_at": _now_iso(), "fixed_runtime_note": note[:500]}
    _append_row(registry_path(repo_root), row)
    return row


def close_eod(repo_root: Path, blocker_id: str, note: str = "") -> dict[str, Any] | None:
    latest = _latest_by_id(_load_rows(registry_path(repo_root)))
    base = latest.get(blocker_id)
    if not base:
        return None
    row = {**base, "status": STATUS_EOD_CLOSED, "eod_closed_at": _now_iso(), "eod_note": note[:500]}
    _append_row(registry_path(repo_root), row)
    return row


def render_eod_digest(repo_root: Path) -> str:
    pending = pending_for_eod(repo_root)
    lines = [
        f"# Thinking-map technical blockers — EOD queue ({_now_iso()})",
        "",
        f"Pending (open + fixed_runtime): **{len(pending)}**",
        f"Registry: governance/{BLOCKER_REGISTRY}",
        "",
    ]
    if not pending:
        lines.append("No pending blockers.")
        return "\n".join(lines) + "\n"

    lines.append("| blocker_id | status | class | task_id | outcome | registered |")
    lines.append("|---|---|---|---|---|---|")
    for r in pending:
        lines.append(
            f"| {r.get('blocker_id','')} | {r.get('status','')} | {r.get('class','')} "
            f"| {r.get('task_id','—')} | {r.get('outcome_kind','')[:40]} | {r.get('registered_at','')} |"
        )
    lines.append("")
    for r in pending:
        lines.append(f"### {r.get('blocker_id')} ({r.get('class')}) — {r.get('status')}")
        lines.append(f"- task: {r.get('task','')}")
        lines.append(f"- reason: {r.get('reason','')}")
        if r.get("missing_evidence"):
            lines.append(f"- missing_evidence: {', '.join(r['missing_evidence'])}")
        if r.get("blockers"):
            lines.append(f"- blockers: {', '.join(r['blockers'])}")
        if r.get("fixed_runtime_note"):
            lines.append(f"- fixed_runtime_note: {r['fixed_runtime_note']}")
        lines.append("")
    return "\n".join(lines)


def eod_review_ready(repo_root: Path) -> bool:
    """True when no open/fixed_runtime blockers remain."""
    return len(pending_for_eod(repo_root)) == 0
