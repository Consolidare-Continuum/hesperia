"""MCP ↔ fpf-thinking-map inquiry registry and step runner."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from fpf_thinking_map.state import RuntimeBinding
from fpf_thinking_map.traversal import ThinkingMapTraversal

from thinking_maps.cluster_ops.map import build_cluster_ops_map
from thinking_maps.eod_ops.map import build_eod_ops_map
from thinking_maps.reason_for_self import reason_for_self_plan, reason_from_inquiry_result
from thinking_maps.team_ops.map import build_team_ops_logic, build_team_ops_map

MAP_BUILDERS = {
    "team_ops": build_team_ops_map,
    "cluster_ops": build_cluster_ops_map,
    "eod_ops": build_eod_ops_map,
}
LOGIC_BUILDERS = {"team_ops": build_team_ops_logic}

DEFAULT_REGISTRY = Path(__file__).resolve().parents[1] / "governance" / "mcp_thinking_map_registry.json"


def _repo_root() -> Path:
    for env in ("CURSOR_REPO_ROOT", "WORKFLOW_REPO_ROOT", "MCP_REPO_ROOT"):
        v = os.environ.get(env, "").strip()
        if v and Path(v).is_dir():
            return Path(v)
    return Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class KeyPoint:
    id: str
    mcp: str
    tool: str
    evidence_token: str
    map_id: str
    current_state: str
    inquiry: str
    requires_evidence: tuple[str, ...]
    phase: str
    tool_args_hint: str


def load_registry(path: Path | None = None) -> dict[str, Any]:
    p = path or DEFAULT_REGISTRY
    return json.loads(p.read_text(encoding="utf-8"))


def _parse_key_point(row: dict[str, Any]) -> KeyPoint:
    return KeyPoint(
        id=row["id"],
        mcp=row["mcp"],
        tool=row["tool"],
        evidence_token=row["evidence_token"],
        map_id=row.get("map_id", "team_ops"),
        current_state=row.get("current_state", "start"),
        inquiry=row.get("inquiry", "after"),
        requires_evidence=tuple(row.get("requires_evidence") or []),
        phase=row.get("phase", ""),
        tool_args_hint=row.get("tool_args_hint", ""),
    )


def list_key_points(registry: dict[str, Any] | None = None) -> list[KeyPoint]:
    reg = registry or load_registry()
    return [_parse_key_point(r) for r in reg.get("key_points", [])]


def key_points_for_mcp(mcp_id: str, registry: dict[str, Any] | None = None) -> list[KeyPoint]:
    return [k for k in list_key_points(registry) if k.mcp == mcp_id]


def chain_key_point_ids(chain_id: str, registry: dict[str, Any] | None = None) -> list[str]:
    reg = registry or load_registry()
    return list(reg.get("chains", {}).get(chain_id, []))


def chain_checklist(
    chain_id: str,
    satisfied_evidence: list[str] | None = None,
    registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return MCP call order + missing evidence tokens for a chain."""
    reg = registry or load_registry()
    satisfied = set(satisfied_evidence or [])
    by_id = {k.id: k for k in list_key_points(reg)}
    steps: list[dict[str, Any]] = []
    missing: list[str] = []
    for kid in chain_key_point_ids(chain_id, reg):
        kp = by_id.get(kid)
        if not kp:
            continue
        req = list(kp.requires_evidence) if kp.requires_evidence else [kp.evidence_token]
        if kp.tool.startswith("thinking_map"):
            req = list(kp.requires_evidence)
        step_missing = [t for t in req if t not in satisfied]
        if step_missing and kp.tool.startswith("thinking_map"):
            missing.extend(step_missing)
        steps.append(
            {
                "id": kp.id,
                "mcp": kp.mcp,
                "tool": kp.tool,
                "inquiry": kp.inquiry,
                "evidence_token": kp.evidence_token,
                "satisfied": kp.evidence_token in satisfied,
                "missing_for_step": step_missing,
            }
        )
    return {
        "chain_id": chain_id,
        "steps": steps,
        "missing_evidence": sorted(set(missing)),
        "ready_for_move": len(missing) == 0,
    }


def _engine(map_id: str) -> ThinkingMapTraversal:
    if map_id not in MAP_BUILDERS:
        raise ValueError(f"unknown map_id: {map_id}")
    sm = MAP_BUILDERS[map_id]()
    logic = LOGIC_BUILDERS[map_id]() if map_id in LOGIC_BUILDERS else None
    return ThinkingMapTraversal(sm, logic_layer=logic)


def _context_for_map(map_id: str) -> str:
    return {"team_ops": "team_workflow", "cluster_ops": "cluster_ops", "eod_ops": "cursor_eod"}.get(
        map_id, "team_workflow"
    )


def run_inquiry(
    *,
    chain_id: str = "",
    key_point_id: str = "",
    task: str = "",
    task_id: str = "",
    actor_role_ids: str = "task_owner",
    current_evidence: list[str] | None = None,
    destructive: bool = False,
    registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Run thinking_map_step for a registry key point or chain terminal move step.

    Pass honest evidence tokens after real MCP calls.
    """
    reg = registry or load_registry()
    by_id = {k.id: k for k in list_key_points(reg)}
    evidence = list(current_evidence or [])

    if task_id and "task_id" not in evidence:
        evidence.append("task_id")

    if destructive and "destructive_scope" not in evidence:
        evidence.append("destructive_scope")

    target: KeyPoint | None = None
    if key_point_id:
        target = by_id.get(key_point_id)
        if not target:
            raise ValueError(f"unknown key_point_id: {key_point_id}")
    elif chain_id:
        ids = chain_key_point_ids(chain_id, reg)
        for kid in reversed(ids):
            kp = by_id.get(kid)
            if kp and kp.tool == "thinking_map_step":
                target = kp
                break
        if not target:
            raise ValueError(f"no thinking_map_step in chain: {chain_id}")

    if not target:
        raise ValueError("chain_id or key_point_id required")

    if target.tool != "thinking_map_step":
        return {
            "action": "record_evidence_only",
            "key_point_id": target.id,
            "mcp": target.mcp,
            "tool": target.tool,
            "evidence_token": target.evidence_token,
            "message": f"Call MCP {target.mcp}.{target.tool} then add token {target.evidence_token}",
            "chain_checklist": chain_checklist(chain_id, evidence, reg) if chain_id else None,
        }

    state = target.current_state
    if destructive and target.map_id == "team_ops":
        state = "executing_destructive"

    merged = sorted(set(evidence))
    checklist = chain_checklist(chain_id, merged, reg) if chain_id else None
    if checklist and checklist["missing_evidence"]:
        blocked_result: dict[str, Any] = {
            "action": "blocked_missing_mcp_evidence",
            "key_point_id": target.id,
            "map_id": target.map_id,
            "current_state": state,
            "missing_evidence": checklist["missing_evidence"],
            "chain_checklist": checklist,
            "required_mcps": [
                s for s in checklist["steps"]
                if not s["satisfied"] and s["tool"] != "thinking_map_step"
            ],
            "reason_for_self": reason_for_self_plan(
                kind="COLLECT_EVIDENCE",
                reason="MCP chain evidence incomplete",
                missing_evidence=checklist["missing_evidence"],
                chain_id=chain_id,
                map_id=target.map_id,
                current_evidence=merged,
            ),
            "kind": "COLLECT_EVIDENCE",
            "chain_id": chain_id,
        }
        try:
            from thinking_maps.blocker_registry import register_from_result

            reg_row = register_from_result(
                _repo_root(),
                blocked_result,
                task=task or chain_id or key_point_id,
                task_id=task_id,
                chain_id=chain_id,
            )
            if reg_row:
                blocked_result["blocker_id"] = reg_row["blocker_id"]
        except Exception:
            pass
        return blocked_result

    engine = _engine(target.map_id)
    binding = RuntimeBinding(
        task=task or chain_id or key_point_id,
        actor_role_ids=[r.strip() for r in actor_role_ids.split(",") if r.strip()],
        active_context_id=_context_for_map(target.map_id),
        current_evidence=merged,
    )
    active = engine.build_active_state(binding, current_state=state)
    outcome = engine.step(active)
    llm = getattr(outcome, "llm_prompt_state", None)
    result: dict[str, Any] = {
        "action": "thinking_map_step",
        "key_point_id": target.id,
        "chain_id": chain_id,
        "map_id": target.map_id,
        "current_state": state,
        "current_evidence": merged,
        "kind": str(outcome.kind),
        "reason": getattr(outcome, "reason", ""),
        "missing_evidence": getattr(outcome, "missing_evidence", None),
        "blockers": getattr(outcome, "blockers", None),
        "llm_prompt_state": llm,
        "chain_checklist": checklist,
        "_outcome": outcome,
    }
    rfs = reason_from_inquiry_result(result)
    if rfs.get("blocked"):
        result["reason_for_self"] = rfs
    try:
        from thinking_maps.blocker_registry import register_from_result

        reg = register_from_result(
            _repo_root(),
            result,
            task=task or chain_id or key_point_id,
            task_id=task_id,
            chain_id=chain_id,
        )
        if reg:
            result["blocker_id"] = reg["blocker_id"]
    except Exception:
        pass
    return result


def all_mcps_summary(registry: dict[str, Any] | None = None) -> list[dict[str, str]]:
    """One row per MCP server with inquiry count."""
    reg = registry or load_registry()
    counts: dict[str, int] = {}
    for kp in list_key_points(reg):
        counts[kp.mcp] = counts.get(kp.mcp, 0) + 1
    return [{"mcp": m, "key_points": str(counts[m])} for m in sorted(counts)]
