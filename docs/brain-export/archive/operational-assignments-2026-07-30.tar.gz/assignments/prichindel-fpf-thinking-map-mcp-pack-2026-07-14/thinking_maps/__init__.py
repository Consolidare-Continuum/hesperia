"""Brain domain maps on fpf-thinking-map (PyPI). Engine: thinking_maps.engine."""
