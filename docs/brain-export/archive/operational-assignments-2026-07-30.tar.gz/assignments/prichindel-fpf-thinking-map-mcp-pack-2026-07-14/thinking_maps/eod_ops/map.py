"""End-of-day brain consolidation SemanticMap — Cursor EOD scripting."""

from thinking_maps.engine import (
    AgencyLevel,
    ContextPrimitive,
    EvidencePrimitive,
    FGR,
    Freshness,
    RolePrimitive,
    SemanticMap,
    TransitionPrimitive,
)


def build_eod_ops_map() -> SemanticMap:
    sm = SemanticMap()

    sm.register_context(ContextPrimitive(
        context_id="cursor_eod",
        label="Cursor End-of-Day",
        glossary={
            "collect": "end_of_day_collect.sh snapshot",
            "consolidate": "structure + tone + dedupe pass",
            "compliance": "CURSOR-REPO-COMPLIANCE-CHECK row",
            "commit": "git pull commit push brain",
            "chroma": "CHROMA-1 mass ingest on alunel",
        },
        invariants=[
            "thinking_map_mode=1 requires fpf-thinking-map hard gate before EOD",
            "Move semantics = library JSON only",
        ],
    ))

    sm.register_role(RolePrimitive(
        role_id="cursor_main",
        label="Cursor Main EOD",
        context_id="cursor_eod",
        agency_level=AgencyLevel.DELIBERATIVE,
        responsibilities=["run END-OF-DAY-WORKFLOW", "enforce rules from chats"],
    ))

    for eid, label in (
        ("thinking_map_verify_done", "fpf_thinking_map.verify passed this session"),
        ("eod_collect_done", "EOD collect artifact written"),
        ("eod_structure_checked", "repo structure consolidation pass"),
        ("eod_compliance_row", "compliance check timestamp appended"),
        ("eod_lessons_checked", "lessons-learned session file or explicit skip"),
        ("eod_git_pushed", "brain repo commit pushed"),
        ("eod_chroma_closed", "CHROMA ingest completed or skip documented"),
        ("eod_blockers_reviewed", "EOD review of thinking-map technical blockers queue"),
    ):
        sm.register_evidence(EvidencePrimitive(
            evidence_id=eid,
            label=label,
            context_id="cursor_eod",
            claim=label,
            source="EOD scripts / Cursor",
            fgr=FGR(formality=0.85, scope=0.85, reliability=0.9),
            freshness=Freshness.CURRENT,
        ))

    sm.register_transition(TransitionPrimitive(
        transition_id="open_collect",
        label="Run collect",
        context_id="cursor_eod",
        from_state="start",
        to_state="collecting",
        required_evidence=["thinking_map_verify_done"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="collect_done",
        label="Collect complete",
        context_id="cursor_eod",
        from_state="collecting",
        to_state="structuring",
        required_evidence=["eod_collect_done"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="structure_done",
        label="Structure pass complete",
        context_id="cursor_eod",
        from_state="structuring",
        to_state="compliance",
        required_evidence=["eod_structure_checked", "eod_blockers_reviewed"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="compliance_done",
        label="Compliance row appended",
        context_id="cursor_eod",
        from_state="compliance",
        to_state="lessons",
        required_evidence=["eod_compliance_row"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="lessons_done",
        label="Lessons checked",
        context_id="cursor_eod",
        from_state="lessons",
        to_state="committing",
        required_evidence=["eod_lessons_checked"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="commit_done",
        label="Git pushed",
        context_id="cursor_eod",
        from_state="committing",
        to_state="chroma",
        required_evidence=["eod_git_pushed"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="chroma_done",
        label="Chroma ingest or skip",
        context_id="cursor_eod",
        from_state="chroma",
        to_state="done",
        required_evidence=["eod_chroma_closed"],
    ))

    return sm
