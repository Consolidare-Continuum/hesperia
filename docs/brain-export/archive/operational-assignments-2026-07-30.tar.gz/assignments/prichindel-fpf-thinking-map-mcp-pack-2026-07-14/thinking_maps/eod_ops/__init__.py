"""EOD brain workflow domain map."""
