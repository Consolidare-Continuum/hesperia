"""MCP inquiry registry tests."""

from thinking_maps.mcp_inquiry import (
    all_mcps_summary,
    chain_checklist,
    chain_key_point_ids,
    key_points_for_mcp,
    load_registry,
    run_inquiry,
)


def test_registry_loads() -> None:
    reg = load_registry()
    assert reg["schema"].endswith(".v1")
    assert len(reg["key_points"]) >= 20
    assert "workflow_execute" in reg["chains"]


def test_all_mcps_covered() -> None:
    summary = all_mcps_summary()
    mcps = {r["mcp"] for r in summary}
    expected = {
        "chroma-knowledge",
        "cursor-pipeline-status",
        "cursor-runbook",
        "cursor-approval-gates",
        "cursor-cluster-snapshot",
        "cursor-github-ci",
        "cursor-context-rag",
        "cursor-inbox-reader",
        "cursor-suitecrm",
        "colombo-library",
        "cursor-postfix-mail",
        "cursor-mailcow-mail",
        "cursor-tailscale",
        "cursor-thinking-map",
    }
    assert expected <= mcps


def test_workflow_chain_missing_evidence() -> None:
    cl = chain_checklist("workflow_execute", ["query_knowledge_done"])
    assert cl["ready_for_move"] is False
    assert "get_current_step_done" in cl["missing_evidence"] or "runbook_read" in cl["missing_evidence"]


def test_workflow_chain_ready_with_full_evidence() -> None:
    evidence = [
        "task_id",
        "query_knowledge_done",
        "get_current_step_done",
        "runbook_read",
    ]
    cl = chain_checklist("workflow_execute", evidence)
    assert cl["ready_for_move"] is True


def test_inquire_blocks_without_evidence() -> None:
    result = run_inquiry(chain_id="workflow_execute", current_evidence=["task_id"])
    assert result["action"] == "blocked_missing_mcp_evidence"
    assert result["missing_evidence"]


def test_inquire_executes_with_full_evidence() -> None:
    evidence = [
        "task_id",
        "query_knowledge_done",
        "get_current_step_done",
        "runbook_read",
    ]
    result = run_inquiry(chain_id="workflow_execute", current_evidence=evidence)
    result.pop("_outcome", None)
    assert result["action"] == "thinking_map_step"
    assert "kind" in result


def test_chroma_knowledge_key_points() -> None:
    pts = key_points_for_mcp("chroma-knowledge")
    assert any(p.tool == "query_knowledge" for p in pts)


def test_chain_ids_non_empty() -> None:
    for chain in ("session_opener", "cluster_preflight", "destructive_gate", "eod_close"):
        assert chain_key_point_ids(chain)
