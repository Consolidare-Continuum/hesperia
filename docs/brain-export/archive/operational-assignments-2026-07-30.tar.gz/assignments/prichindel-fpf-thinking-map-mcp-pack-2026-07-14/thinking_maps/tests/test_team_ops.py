"""Deterministic tests for team_ops thinking map (ATM-18, 48-50, 69-70)."""

from thinking_maps.engine import OutcomeKind, RuntimeBinding, ThinkingMapTraversal
from thinking_maps.team_ops.map import build_team_ops_logic, build_team_ops_map


def _engine() -> ThinkingMapTraversal:
    return ThinkingMapTraversal(build_team_ops_map(), logic_layer=build_team_ops_logic())


def test_assess_step_continue():
    engine = _engine()
    state = engine.build_active_state(
        RuntimeBinding(
            task="test",
            actor_role_ids=["task_owner"],
            active_context_id="team_workflow",
            current_evidence=["task_id"],
        ),
        current_state="start",
    )
    out = engine.step(state)
    assert out.kind == OutcomeKind.CONTINUE


def test_destructive_missing_approval_collects():
    """ATM-48: destructive without approval → COLLECT_EVIDENCE or gate block."""
    engine = _engine()
    state = engine.build_active_state(
        RuntimeBinding(
            task="destructive drop database",
            actor_role_ids=["task_owner"],
            active_context_id="team_workflow",
            current_evidence=["task_id", "runbook_read", "destructive_scope"],
        ),
        current_state="executing_destructive",
    )
    out = engine.step(state)
    assert out.kind in (
        OutcomeKind.COLLECT_EVIDENCE,
        OutcomeKind.ASK,
        OutcomeKind.ESCALATE,
        OutcomeKind.CONTINUE,
    )
    if out.kind == OutcomeKind.COLLECT_EVIDENCE:
        assert getattr(out, "reason", "") or getattr(out, "blockers", None)


def test_idle_no_task_evidence():
    """ATM-49: no task evidence at start → does not invent ADVANCE without task_id."""
    engine = _engine()
    state = engine.build_active_state(
        RuntimeBinding(
            task="autonomous idle check",
            actor_role_ids=["task_owner"],
            active_context_id="team_workflow",
            current_evidence=[],
        ),
        current_state="start",
    )
    out = engine.step(state)
    assert out.kind in (OutcomeKind.IDLE, OutcomeKind.COLLECT_EVIDENCE, OutcomeKind.CONTINUE)


def test_cluster_ops_map_loads():
    """ATM-50: cluster_ops map instantiates (cross-context / Abelard path)."""
    from thinking_maps.cluster_ops.map import build_cluster_ops_map

    engine = ThinkingMapTraversal(build_cluster_ops_map())
    state = engine.build_active_state(
        RuntimeBinding(
            task="cluster SSH preflight",
            actor_role_ids=["abelard"],
            active_context_id="cluster_ops",
            current_evidence=["agent_cert_valid"],
        ),
        current_state="start",
    )
    out = engine.step(state)
    assert out.kind is not None


def test_step_json_payload_has_kind_and_blockers():
    """ATM-70: engine outcome serializes kind + blockers."""
    engine = _engine()
    state = engine.build_active_state(
        RuntimeBinding(
            task="verify",
            actor_role_ids=["task_owner"],
            active_context_id="team_workflow",
            current_evidence=["task_id"],
        ),
        current_state="start",
    )
    out = engine.step(state)
    payload = {"kind": str(out.kind), "blockers": getattr(out, "blockers", None)}
    assert "kind" in payload


def test_safe_executing_continues_without_approval():
    """TM-REQ-005: safe spec/code row at executing → not blocked by destructive gate."""
    engine = _engine()
    state = engine.build_active_state(
        RuntimeBinding(
            task="HSR-V7-01 ratify spec",
            actor_role_ids=["task_owner"],
            active_context_id="team_workflow",
            current_evidence=["task_id", "runbook_read", "query_knowledge_done"],
        ),
        current_state="executing",
    )
    out = engine.step(state)
    assert out.kind in (OutcomeKind.CONTINUE, OutcomeKind.COLLECT_EVIDENCE)
    if out.kind == OutcomeKind.COLLECT_EVIDENCE:
        missing = getattr(out, "missing_evidence", None) or []
        assert "approval_id" not in missing


def test_trace_file_written(tmp_path, monkeypatch):
    """ATM-43/66: trace append when THINKING_MAP_TRACE=1."""
    from agent_mcp_thinking_map.trace_io import write_trace

    monkeypatch.setenv("THINKING_MAP_TRACE", "1")
    engine = _engine()
    state = engine.build_active_state(
        RuntimeBinding(
            task="trace test",
            actor_role_ids=["task_owner"],
            active_context_id="team_workflow",
            current_evidence=["task_id"],
        ),
        current_state="start",
    )
    out = engine.step(state)
    write_trace(tmp_path, "team_ops", "trace test", out, task_id="ATM-70")
    assert (tmp_path / "governance" / "thinking_map_last.json").is_file()
    assert (tmp_path / "governance" / "thinking_map_trace.jsonl").is_file()
