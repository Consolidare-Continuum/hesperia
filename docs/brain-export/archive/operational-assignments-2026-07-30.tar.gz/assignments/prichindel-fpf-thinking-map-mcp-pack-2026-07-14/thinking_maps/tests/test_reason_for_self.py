"""Reasoning for self (second cortex) tests."""

from thinking_maps.mcp_inquiry import run_inquiry
from thinking_maps.reason_for_self import reason_for_self_plan


def test_rfsa_plan_when_collect_evidence() -> None:
    plan = reason_for_self_plan(
        kind="OutcomeKind.COLLECT_EVIDENCE",
        missing_evidence=["approval_id", "runbook_read"],
        chain_id="workflow_execute",
    )
    assert plan["blocked"] is True
    assert plan["second_cortex"] == "fpf-thinking-map"
    assert len(plan["recommended_next_mcp_calls"]) >= 1
    assert "Irreversible bytes" in plan["forbidden_until_unblock"][0]


def test_inquire_includes_reason_for_self_when_blocked() -> None:
    result = run_inquiry(chain_id="workflow_execute", current_evidence=["task_id"])
    assert result["action"] == "blocked_missing_mcp_evidence"
    assert "reason_for_self" in result
    assert result["reason_for_self"]["blocked"] is True


def test_rfsa_not_blocked_on_continue() -> None:
    plan = reason_for_self_plan(kind="OutcomeKind.CONTINUE", missing_evidence=[])
    assert plan["blocked"] is False
