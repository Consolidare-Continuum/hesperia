"""Blocker registry tests."""

from pathlib import Path

from thinking_maps.blocker_registry import (
    STATUS_EOD_CLOSED,
    STATUS_FIXED_RUNTIME,
    STATUS_OPEN,
    close_eod,
    list_blockers,
    mark_fixed_runtime,
    pending_for_eod,
    register_from_outcome,
)


class _Outcome:
    kind = "OutcomeKind.COLLECT_EVIDENCE"
    reason = "Permission denied SSH agent cert expired"
    missing_evidence = ["agent_cert_valid", "approval_id"]
    blockers = ["cluster_ssh_gate"]


def test_register_access_denied_class(tmp_path: Path) -> None:
    row = register_from_outcome(
        tmp_path,
        map_id="cluster_ops",
        task="ssh trustmaster",
        outcome=_Outcome(),
        task_id="TEST-1",
    )
    assert row is not None
    assert row["class"] == "access_denied"
    assert row["status"] == STATUS_OPEN


def test_fixed_runtime_still_pending_eod(tmp_path: Path) -> None:
    row = register_from_outcome(tmp_path, map_id="team_ops", task="t", outcome=_Outcome())
    assert row
    mark_fixed_runtime(tmp_path, row["blocker_id"], note="renewed cert on alunel")
    pending = pending_for_eod(tmp_path)
    assert len(pending) == 1
    assert pending[0]["status"] == STATUS_FIXED_RUNTIME


def test_close_eod_removes_from_pending(tmp_path: Path) -> None:
    row = register_from_outcome(tmp_path, map_id="team_ops", task="t", outcome=_Outcome())
    assert row
    close_eod(tmp_path, row["blocker_id"], note="verified in EOD")
    pending = pending_for_eod(tmp_path)
    assert pending == []
    latest = list_blockers(tmp_path, statuses=(STATUS_EOD_CLOSED,))
    assert len(latest) == 1


def test_no_register_on_continue(tmp_path: Path) -> None:
    o = _Outcome()
    o.kind = "OutcomeKind.CONTINUE"
    o.missing_evidence = []
    o.blockers = []
    assert register_from_outcome(tmp_path, map_id="team_ops", task="t", outcome=o) is None
