"""EOD domain map tests."""

from thinking_maps.engine import OutcomeKind, RuntimeBinding, ThinkingMapTraversal

from thinking_maps.eod_ops.map import build_eod_ops_map


def test_eod_ops_gate_and_collect_continue() -> None:
    engine = ThinkingMapTraversal(build_eod_ops_map())
    binding = RuntimeBinding(
        task="EOD test",
        actor_role_ids=["cursor_main"],
        active_context_id="cursor_eod",
        current_evidence=["thinking_map_verify_done"],
    )
    out = engine.step(engine.build_active_state(binding, "start"))
    assert out.kind == OutcomeKind.CONTINUE

    binding.current_evidence = ["eod_collect_done"]
    out2 = engine.step(engine.build_active_state(binding, "collecting"))
    assert out2.kind == OutcomeKind.CONTINUE
