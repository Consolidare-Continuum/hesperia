"""Second cortex — reasoning-for-self when fpf-thinking-map blocks."""

from __future__ import annotations

from typing import Any

BLOCK_KIND_MARKERS = ("COLLECT_EVIDENCE", "BLOCK", "BLOCKED", "INSUFFICIENT", "HITL")


def _is_blocked_kind(kind: str) -> bool:
    k = (kind or "").upper()
    return any(m in k for m in BLOCK_KIND_MARKERS)


def _mcp_for_token(token: str) -> list[dict[str, str]]:
    from thinking_maps.mcp_inquiry import list_key_points

    rows = []
    for kp in list_key_points():
        if kp.evidence_token == token:
            rows.append({"mcp": kp.mcp, "tool": kp.tool, "key_point_id": kp.id})
    return rows


def reason_for_self_plan(
    *,
    kind: str = "",
    reason: str = "",
    missing_evidence: list[str] | None = None,
    blockers: list[str] | None = None,
    llm_prompt_state: dict[str, Any] | None = None,
    chain_id: str = "",
    map_id: str = "team_ops",
    current_evidence: list[str] | None = None,
) -> dict[str, Any]:
    """
    Build an allowed self-reasoning plan when Move layer blocks.

    Does not authorize irreversible bytes — only deliberation + next MCP steps.
    """
    llm = llm_prompt_state or {}
    missing = list(missing_evidence or [])
    blockers_list = list(blockers or [])
    evidence = list(current_evidence or [])
    blocked = _is_blocked_kind(kind) or bool(missing) or bool(blockers_list)

    next_mcp: list[dict[str, str]] = []
    for token in missing:
        next_mcp.extend(_mcp_for_token(token))

    # Dedupe by key_point_id
    seen: set[str] = set()
    deduped: list[dict[str, str]] = []
    for row in next_mcp:
        kid = row.get("key_point_id", "")
        if kid in seen:
            continue
        seen.add(kid)
        deduped.append(row)

    checklist = None
    if chain_id:
        from thinking_maps.mcp_inquiry import chain_checklist

        checklist = chain_checklist(chain_id, evidence)

    return {
        "schema": "hesperia.brain.thinking_map_reason_for_self.v1",
        "second_cortex": "fpf-thinking-map",
        "blocked": blocked,
        "kind": kind,
        "reason": reason,
        "map_id": map_id,
        "chain_id": chain_id or None,
        "missing_evidence": missing,
        "blockers": blockers_list,
        "gate_status": llm.get("gate_status"),
        "logic": llm.get("logic"),
        "possible_transitions": llm.get("possible_transitions"),
        "response_contract": llm.get("response_contract"),
        "allowed_self_reasoning": [
            "Read outcome JSON and llm_prompt_state as second cortex input",
            "Plan which MCP calls satisfy missing_evidence (registry-driven)",
            "Call get_mcp_inquiry_chain / list_mcp_inquiry_points",
            "Re-run thinking_map_step or thinking_map_inquire after honest evidence",
            "Report BLOCKED to operator with concrete unblock path (did/asked/result)",
            "Use query_knowledge for rules — primary cortex stays CHROMA-1",
        ],
        "forbidden_until_unblock": [
            "Irreversible bytes (deploy, delete, SSH mutate, approval write without gate)",
            "Chat-substitute for thinking_map_step outcome kind",
            "Invent evidence tokens without real MCP calls",
            "Bypass destructive_gate or cluster_ssh_gate",
        ],
        "recommended_next_mcp_calls": deduped,
        "chain_checklist": checklist,
        "re_step_hint": (
            "thinking_map_inquire(chain_id=..., current_evidence=<tokens after MCPs>)"
            if chain_id
            else "thinking_map_step(map_id=..., current_evidence=<tokens after MCPs>)"
        ),
        "policy_ref": "governance/SPEC-ETHAN-THINKING-MAP-REASONING-FOR-SELF-ALLOWED.md",
    }


def reason_from_inquiry_result(result: dict[str, Any]) -> dict[str, Any]:
    """Wrap run_inquiry / thinking_map_step JSON into RFSA plan."""
    return reason_for_self_plan(
        kind=str(result.get("kind", "")),
        reason=str(result.get("reason", "")),
        missing_evidence=result.get("missing_evidence") or [],
        blockers=result.get("blockers") or [],
        llm_prompt_state=result.get("llm_prompt_state") or {},
        chain_id=str(result.get("chain_id") or ""),
        map_id=str(result.get("map_id") or "team_ops"),
        current_evidence=result.get("current_evidence") or [],
    )
