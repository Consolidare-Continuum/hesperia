"""Cluster ops SemanticMap — Abelard preflight guards."""

from thinking_maps.engine import (
    AgencyLevel,
    ContextPrimitive,
    EvidencePrimitive,
    FGR,
    Freshness,
    GateCheck,
    GatePrimitive,
    RolePrimitive,
    SemanticMap,
    TransitionPrimitive,
)


def build_cluster_ops_map() -> SemanticMap:
    sm = SemanticMap()

    sm.register_context(ContextPrimitive(
        context_id="cluster_ops",
        label="Cluster Operations",
        glossary={
            "holy_cow": "alunel hypervisor — Proxmox only",
            "trustmaster": "Authentik IdP on trustmaster VM",
        },
        invariants=[
            "agent cert must be valid before cluster SSH",
            "tailscale logout requires operator approval",
        ],
    ))

    sm.register_role(RolePrimitive(
        role_id="abelard_ops",
        label="Abelard DevOps",
        context_id="cluster_ops",
        agency_level=AgencyLevel.DELIBERATIVE,
        responsibilities=["cluster preflight", "infra execute"],
    ))

    for eid, label in (
        ("agent_cert_valid", "Agent SSH CA cert valid"),
        ("get_agent_access_status_done", "get_agent_access_status MCP called"),
        ("trustmaster_preflight", "Trustmaster access preflight passed"),
        ("trustmaster_runbook_read", "Trustmaster runbook read"),
        ("snapshot_fresh", "Cluster snapshot fresh"),
        ("tailscale_status_done", "Tailscale status MCP called"),
        ("tailscale_logout_approved", "Operator approved tailscale logout"),
    ):
        sm.register_evidence(EvidencePrimitive(
            evidence_id=eid,
            label=label,
            context_id="cluster_ops",
            claim=label,
            source="cluster snapshot MCP",
            fgr=FGR(formality=0.9, scope=0.85, reliability=0.9),
            freshness=Freshness.CURRENT,
        ))

    sm.register_gate(GatePrimitive(
        gate_id="cluster_ssh_gate",
        label="Cluster SSH gate",
        context_id="cluster_ops",
        checks=[
            GateCheck(check_id="cert", description="Agent cert", required_evidence=["agent_cert_valid"]),
            GateCheck(check_id="snap", description="Snapshot", required_evidence=["snapshot_fresh"]),
        ],
    ))

    sm.register_gate(GatePrimitive(
        gate_id="trustmaster_gate",
        label="Trustmaster ops gate",
        context_id="cluster_ops",
        checks=[
            GateCheck(
                check_id="preflight",
                description="Preflight",
                required_evidence=["trustmaster_preflight", "agent_cert_valid"],
            ),
        ],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="cluster_preflight",
        label="Cluster preflight",
        context_id="cluster_ops",
        from_state="start",
        to_state="ready",
        required_gate_id="cluster_ssh_gate",
        required_evidence=["agent_cert_valid"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="trustmaster_ops",
        label="Trustmaster operation",
        context_id="cluster_ops",
        from_state="ready",
        to_state="executing",
        required_gate_id="trustmaster_gate",
        required_evidence=["trustmaster_preflight"],
    ))

    return sm
