"""Team workflow SemanticMap — Grace triage, proceed gates, report_done."""

from thinking_maps.engine import (
    AgencyLevel,
    ContextPrimitive,
    DecisionRule,
    EvidencePresent,
    EvidencePrimitive,
    FGR,
    Freshness,
    GateCheck,
    GatePrimitive,
    LogicLayer,
    RolePrimitive,
    RuleKind,
    SemanticMap,
    TransitionPrimitive,
)


def build_team_ops_map() -> SemanticMap:
    sm = SemanticMap()

    sm.register_context(ContextPrimitive(
        context_id="team_workflow",
        label="Team Workflow",
        glossary={
            "triage": "Grace adds executable row to active.md",
            "proceed": "execute current workflow step as owner",
            "report_done": "mark row DONE via report_done MCP",
        },
        invariants=[
            "no execution without active.md row",
            "no row creation except Grace triage",
        ],
    ))

    sm.register_role(RolePrimitive(
        role_id="task_owner",
        label="Task Owner",
        context_id="team_workflow",
        agency_level=AgencyLevel.DELIBERATIVE,
        responsibilities=["execute assigned row", "report_done when complete"],
    ))

    sm.register_role(RolePrimitive(
        role_id="grace_triage",
        label="Grace Triage",
        context_id="team_workflow",
        agency_level=AgencyLevel.DELIBERATIVE,
        responsibilities=["triage inbox", "create active.md rows"],
    ))

    for eid, label, fgr in (
        ("task_id", "Active task id", FGR(formality=0.9, scope=0.85, reliability=0.9)),
        ("runbook_read", "Mandatory runbook consulted", FGR(formality=0.8, scope=0.8, reliability=0.85)),
        ("approval_id", "Approval gate record", FGR(formality=0.95, scope=0.9, reliability=0.95)),
        ("ci_green", "GitHub CI passing", FGR(formality=0.85, scope=0.8, reliability=0.9)),
        ("destructive_scope", "Task explicitly destructive/high-risk", FGR(formality=0.9, scope=0.9, reliability=0.9)),
        ("context_packet_done", "Context RAG packet retrieved", FGR(formality=0.8, scope=0.8, reliability=0.85)),
        ("inbox_orient_done", "Inbox summary read for triage", FGR(formality=0.75, scope=0.75, reliability=0.85)),
        ("colombo_library_query_done", "Colombo library query done", FGR(formality=0.8, scope=0.8, reliability=0.85)),
        ("suitecrm_sync_done", "SuiteCRM sync after report_done", FGR(formality=0.85, scope=0.8, reliability=0.9)),
    ):
        sm.register_evidence(EvidencePrimitive(
            evidence_id=eid,
            label=label,
            context_id="team_workflow",
            claim=label,
            source="workflow MCP",
            fgr=fgr,
            freshness=Freshness.CURRENT,
        ))

    sm.register_gate(GatePrimitive(
        gate_id="destructive_gate",
        label="Destructive / high-risk gate",
        context_id="team_workflow",
        checks=[
            GateCheck(
                check_id="approval",
                description="Approval present",
                required_evidence=["approval_id"],
            ),
        ],
    ))

    sm.register_gate(GatePrimitive(
        gate_id="code_row_gate",
        label="Code row CI gate",
        context_id="team_workflow",
        checks=[
            GateCheck(check_id="ci", description="CI green", required_evidence=["ci_green"]),
        ],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="assess",
        label="Assess task",
        context_id="team_workflow",
        from_state="start",
        to_state="investigating",
        required_evidence=["task_id"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="investigate",
        label="Investigate",
        context_id="team_workflow",
        from_state="investigating",
        to_state="executing",
        required_evidence=["task_id", "runbook_read"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="execute_destructive",
        label="Execute destructive work",
        context_id="team_workflow",
        from_state="executing_destructive",
        to_state="verifying",
        required_gate_id="destructive_gate",
        required_evidence=["task_id", "approval_id", "destructive_scope"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="execute_safe",
        label="Execute safe work",
        context_id="team_workflow",
        from_state="executing",
        to_state="verifying",
        required_evidence=["task_id"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="verify",
        label="Verify outcome",
        context_id="team_workflow",
        from_state="verifying",
        to_state="reporting",
        required_evidence=["task_id"],
    ))

    sm.register_transition(TransitionPrimitive(
        transition_id="report_done",
        label="Report done",
        context_id="team_workflow",
        from_state="reporting",
        to_state="done",
        required_evidence=["task_id"],
    ))

    return sm


def build_team_ops_logic() -> LogicLayer:
    """Logic routes scoped to destructive/code paths — safe executing is gate-only via transitions."""
    logic = LogicLayer()
    logic.add_rule(DecisionRule(
        name="approval_fresh_destructive",
        condition=EvidencePresent("destructive_scope"),
        action_if_true="require_approval_gate",
        action_if_false="safe_path",
        kind=RuleKind.ROUTE,
        tags=["team_workflow", "destructive"],
    ))
    logic.add_rule(DecisionRule(
        name="ci_ready_code_row",
        condition=EvidencePresent("ci_green"),
        action_if_true="proceed_code",
        action_if_false="pause_for_ci",
        kind=RuleKind.ROUTE,
        tags=["team_workflow", "code_row"],
    ))
    return logic
