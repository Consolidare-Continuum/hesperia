#!/usr/bin/env bash
# Preflight before trustmaster / Authentik SSH ops. Delegates to unified cluster access preflight.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$REPO_ROOT"

bash "$REPO_ROOT/scripts/agent-cluster-access-preflight.sh" || exit 1

TRUST_LINE=$(bash "$REPO_ROOT/scripts/agent-ssh-verify-trust.sh" 2>/dev/null | grep '^trustmaster:' || true)
echo "trustmaster trust: ${TRUST_LINE:-unreachable}"

if ssh -o BatchMode=yes -o ConnectTimeout=8 trustmaster 'test -f /etc/ssh/agent_ca.pub && sudo -n true && hostname' 2>/dev/null; then
    echo "OK: ssh trustmaster (agent CA)"
    exit 0
fi

echo "ISSUE: SSH failed; trying qemu guest agent VM 104..."
if command -v qm >/dev/null && sudo qm status 104 2>/dev/null | grep -q running; then
    if sudo qm guest exec 104 -- hostname 2>/dev/null | grep -q trustmaster; then
        echo "OK: qemu guest exec 104 (breakglass). Fix SSH: bash scripts/agent-ssh-install-via-qemu.sh 104"
        exit 0
    fi
fi

echo "BLOCKED: no trustmaster access path. Run: bash scripts/agent-ssh-install-via-qemu.sh 104" >&2
exit 1
