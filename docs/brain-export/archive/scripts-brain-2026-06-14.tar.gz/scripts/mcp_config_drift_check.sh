#!/usr/bin/env bash
# Compare repo canonical MCP config vs deployed Cursor user config (prichindel or any host).
# Exit 1 if diffs; 0 if identical or DEST missing (warn only).
# Cron: 0 6 * * * cd /data/workspaces/cursor && ./scripts/mcp_config_drift_check.sh >> governance/mcp_config_drift.log 2>&1

set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
SRC="$REPO_ROOT/governance/mcp-config.json"
DEST="${MCP_JSON_DEST:-$HOME/.cursor/mcp.json}"
PROJECT_DEST="$REPO_ROOT/.cursor/mcp.json"
LOG="${LOG_FILE:-$REPO_ROOT/governance/mcp_config_drift.log}"
ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

if [[ ! -f "$SRC" ]]; then
  echo "$ts ERROR missing $SRC" | tee -a "$LOG"
  exit 1
fi

check_one() {
  local label="$1"
  local path="$2"
  if [[ ! -f "$path" ]]; then
    echo "$ts WARN $label missing: $path (run scripts/deploy-mcp-config-global.sh)" | tee -a "$LOG"
    return 0
  fi
  if ! diff -q "$SRC" "$path" >/dev/null 2>&1; then
    echo "$ts DRIFT $label: $path differs from $SRC" | tee -a "$LOG"
    diff -u "$path" "$SRC" | head -80 | tee -a "$LOG"
    return 1
  fi
  echo "$ts OK $label matches $SRC"
  return 0
}

failed=0
check_one "user" "$DEST" || failed=1
check_one "project" "$PROJECT_DEST" || failed=1

if [[ "$failed" -ne 0 ]]; then
  echo "$ts RESULT drift_detected=1" | tee -a "$LOG"
  exit 1
fi
echo "$ts RESULT drift_detected=0" | tee -a "$LOG"
exit 0
