# Fix OpenSSH private key ACLs on Windows (Permission denied on id_rsa). Run per profile.
param(
    [Parameter(Mandatory = $true)]
    [string]$ProfileName
)
$ErrorActionPreference = "Stop"
$key = Join-Path "C:\Users\$ProfileName\.ssh" "id_rsa"
if (-not (Test-Path $key)) {
    Write-Host "SKIP: no id_rsa for $ProfileName"
    exit 0
}
& icacls $key /inheritance:r | Out-Null
& icacls $key /grant:r "${ProfileName}:(R)" | Out-Null
& icacls $key /grant "SYSTEM:(F)" | Out-Null
Write-Host "OK: id_rsa ACL fixed for $ProfileName"
