#!/usr/bin/env bash
# Send a message to igareosh via @TersagorBot (Telegram DM) + IMIRC #operator-notify.
# Canonical path for all Cursor agents — see scripts/SCRIPT-RUNBOOK-tersagor-operator-notify.md
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY_NOTIFY="${REPO_ROOT}/cluster/tersagor/operator-notify/operator_notify.py"
TERSAGOR_REPO_NOTIFY="/data/tersagor/src/operator_notify/operator_notify.py"
TERSAGOR_HOST="${TERSAGOR_HOST:-192.168.100.68}"
TERSAGOR_PORT="${TERSAGOR_PORT:-18090}"
ENDPOINT="${TERSAGOR_OPERATOR_NOTIFY_URL:-http://${TERSAGOR_HOST}:${TERSAGOR_PORT}/imirc/operator-notify}"
SSH_HOST="${TERSAGOR_NOTIFY_SSH:-alunel}"
TITLE=""
SEVERITY="info"
SOURCE="cursor_agent"
CHANNEL=""
DEPLOY=0

usage() {
  cat <<EOF
Usage: $(basename "$0") [options] "message text"

Send operator notification via Tersagor (Telegram + IMIRC #operator-notify).

Options:
  -t, --title TITLE     Optional title line
  -s, --severity SEV    info|warn|critical (default: info)
  --source NAME         Sender label in message (default: cursor_agent)
  --channel CHAN        IRC channel override (default: #operator-notify)
  --deploy-gateway      Push approval-gateway app.py to tersagor and restart (Abelard)
  -h, --help            This help

Env:
  TERSAGOR_IMIRC_WEB_TOKEN   Bearer token (else read from prichindel imirc_web_token via SSH)
  TERSAGOR_OPERATOR_NOTIFY_URL  Full URL override

Examples:
  bash scripts/tersagor-operator-notify.sh "Deploy PA-08 done; verify script green."
  bash scripts/tersagor-operator-notify.sh -t "n8n gateway" -s warn "Rotate webhook secret."
  echo "multi line" | bash scripts/tersagor-operator-notify.sh -t "batch"
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -t|--title) TITLE="$2"; shift 2 ;;
    -s|--severity) SEVERITY="$2"; shift 2 ;;
    --source) SOURCE="$2"; shift 2 ;;
    --channel) CHANNEL="$2"; shift 2 ;;
    --deploy-gateway) DEPLOY=1; shift ;;
    -h|--help) usage; exit 0 ;;
    -*) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
    *) break ;;
  esac
done

if [[ $DEPLOY -eq 1 ]]; then
  GW="$REPO_ROOT/cluster/tersagor/approval-gateway/app.py"
  echo "Deploying approval-gateway app.py to tersagor..."
  ssh -o BatchMode=yes "$SSH_HOST" "ssh -o BatchMode=yes tersagor 'mkdir -p ~/approval-gateway-staging'" || \
    ssh -o BatchMode=yes "$SSH_HOST" "ssh -o BatchMode=yes trustmaster 'ssh tersagor mkdir -p ~/approval-gateway-staging'"
  scp -o BatchMode=yes "$GW" "${SSH_HOST}:~/approval-gateway-staging/app.py" 2>/dev/null || \
    scp -o BatchMode=yes "$GW" "${SSH_HOST}:" && ssh "$SSH_HOST" "scp app.py tersagor:~/approval-gateway-staging/app.py" 2>/dev/null || true
  ssh -o BatchMode=yes "$SSH_HOST" bash -s <<'DEPLOY'
set -euo pipefail
if ssh -o BatchMode=yes -o ConnectTimeout=3 tersagor true 2>/dev/null; then T=tersagor
elif ssh -o BatchMode=yes trustmaster 'ssh -o BatchMode=yes tersagor true' 2>/dev/null; then
  ssh trustmaster bash -s <<'INNER'
set -euo pipefail
scp ~/approval-gateway-staging/app.py tersagor:~/approval-gateway-staging/app.py 2>/dev/null || true
ssh tersagor 'sudo cp -f ~/approval-gateway-staging/app.py /opt/tersagor/approval-gateway/app.py && sudo systemctl restart tersagor-approval-gateway.service && sleep 2 && curl -sf http://127.0.0.1:18090/health'
INNER
  exit 0
else echo "Cannot reach tersagor for deploy" >&2; exit 1
fi
ssh "$T" 'sudo cp -f ~/approval-gateway-staging/app.py /opt/tersagor/approval-gateway/app.py && sudo systemctl restart tersagor-approval-gateway.service && sleep 2 && curl -sf http://127.0.0.1:18090/health'
DEPLOY
  echo "Gateway deploy OK"
  [[ $# -eq 0 ]] && exit 0
fi

if [[ $# -gt 0 ]]; then
  TEXT="$*"
elif [[ ! -t 0 ]]; then
  TEXT="$(cat)"
else
  echo "ERROR: message text required" >&2
  usage >&2
  exit 2
fi

TEXT="$(printf '%s' "$TEXT" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
[[ -n "$TEXT" ]] || { echo "ERROR: empty message" >&2; exit 2; }

get_token() {
  if [[ -n "${TERSAGOR_IMIRC_WEB_TOKEN:-}" ]]; then
    printf '%s' "$TERSAGOR_IMIRC_WEB_TOKEN"
    return
  fi
  ssh -o BatchMode=yes "$SSH_HOST" \
    "ssh -o BatchMode=yes prichindel 'sudo cat /data/docker/prometheus/config/imirc_web_token 2>/dev/null'" \
    | tr -d '\n\r'
}

# Prefer Python module (stdlib + remote flag) when available
_py_notify() {
  local py="$1"
  shift
  local args=()
  [[ -n "$TITLE" ]] && args+=(-t "$TITLE")
  [[ -n "$SEVERITY" && "$SEVERITY" != "info" ]] && args+=(-s "$SEVERITY")
  [[ -n "$SOURCE" && "$SOURCE" != "cursor_agent" ]] && args+=("--source" "$SOURCE")
  [[ -n "$CHANNEL" ]] && args+=("--channel" "$CHANNEL")
  args+=(--remote)
  if [[ $# -gt 0 ]]; then
    args+=("$*")
  else
    printf '%s' "$TEXT" | python3 "$py" "${args[@]}"
    return $?
  fi
  python3 "$py" "${args[@]}"
}

if [[ -f "$PY_NOTIFY" ]]; then
  TOKEN="$(get_token 2>/dev/null || true)"
  export TERSAGOR_IMIRC_WEB_TOKEN="${TOKEN:-${TERSAGOR_IMIRC_WEB_TOKEN:-}}"
  if [[ -n "${TERSAGOR_IMIRC_WEB_TOKEN:-}" ]]; then
    if OUT="$(_py_notify "$PY_NOTIFY" "$TEXT" 2>&1)"; then
      echo "$OUT"
      exit 0
    fi
  fi
elif [[ -f "$TERSAGOR_REPO_NOTIFY" ]]; then
  TOKEN="$(get_token 2>/dev/null || true)"
  export TERSAGOR_IMIRC_WEB_TOKEN="${TOKEN:-${TERSAGOR_IMIRC_WEB_TOKEN:-}}"
  if [[ -n "${TERSAGOR_IMIRC_WEB_TOKEN:-}" ]]; then
    if OUT="$(_py_notify "$TERSAGOR_REPO_NOTIFY" "$TEXT" 2>&1)"; then
      echo "$OUT"
      exit 0
    fi
  fi
fi

TOKEN="$(get_token)"
[[ -n "$TOKEN" ]] || { echo "ERROR: no IMIRC web token (set TERSAGOR_IMIRC_WEB_TOKEN or fix prichindel path)" >&2; exit 1; }

PAYLOAD="$(python3 -c "
import json, os, sys
p = {'text': sys.argv[1], 'severity': sys.argv[2], 'source': sys.argv[3]}
if sys.argv[4]: p['title'] = sys.argv[4]
if sys.argv[5]: p['channel'] = sys.argv[5]
print(json.dumps(p))
" "$TEXT" "$SEVERITY" "$SOURCE" "$TITLE" "$CHANNEL")"

post_notify() {
  local url="$1"
  curl -sfS -m 25 -X POST "$url" \
    -H "Authorization: Bearer ${TOKEN}" \
    -H "Content-Type: application/json" \
    -d "$PAYLOAD"
}

# Prefer POST from prichindel (LAN to tersagor :18090)
if OUT="$(ssh -o BatchMode=yes "$SSH_HOST" \
  "ssh -o BatchMode=yes prichindel \"curl -sfS -m 25 -X POST '${ENDPOINT}' -H 'Authorization: Bearer ${TOKEN}' -H 'Content-Type: application/json' -d $(printf '%q' "$PAYLOAD")\"" 2>/dev/null)"; then
  echo "$OUT"
  exit 0
fi

# Fallback: direct from runner (alunel / dev host on LAN)
if OUT="$(post_notify "$ENDPOINT" 2>/dev/null)"; then
  echo "$OUT"
  exit 0
fi

echo "ERROR: operator-notify failed (endpoint ${ENDPOINT}). Run --deploy-gateway if 404." >&2
exit 1
