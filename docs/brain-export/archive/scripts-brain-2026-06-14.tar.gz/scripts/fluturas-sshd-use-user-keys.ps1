# Comment out Match Group administrators so sshd uses user .ssh\authorized_keys. Run as Administrator.
# Then igare (admin user) will use C:\Users\igare\.ssh\authorized_keys where we have prichindel key.
$ErrorActionPreference = 'Stop'
$cfg = "C:\ProgramData\ssh\sshd_config"
if (-not (Test-Path $cfg)) { Write-Error "sshd_config not found"; exit 1 }
$lines = Get-Content $cfg
$changed = $false
$newLines = foreach ($line in $lines) {
    if ($line -match '^\s*Match\s+Group\s+administrators') { $changed = $true; '#' + $line }
    elseif ($line -match '^\s*AuthorizedKeysFile\s+__PROGRAMDATA__') { $changed = $true; '#' + $line }
    else { $line }
}
if ($changed) {
    Copy-Item $cfg "$cfg.bak.$(Get-Date -Format 'yyyyMMdd-HHmm')" -Force
    $newLines | Set-Content $cfg -Encoding ASCII
    Write-Host "Commented out Match Group administrators."
}
Restart-Service sshd -Force -ErrorAction SilentlyContinue
Write-Host "Done. sshd now uses user authorized_keys for admin users."
