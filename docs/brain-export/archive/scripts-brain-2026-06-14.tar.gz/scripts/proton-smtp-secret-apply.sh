#!/usr/bin/env bash
# prichindel (root): single source for Proton external SMTP — shared env file + Postfix sasl_passwd.
# The env file is group-readable by igareosh so MCP/agents/scripts (no root) can use direct SMTP.
# Usage:
#   sudo PROTON_SMTP_USER=igareosh@igareosh.com PROTON_SMTP_TOKEN='...' ./scripts/proton-smtp-secret-apply.sh
# Or run without PROTON_SMTP_TOKEN to be prompted (no echo).
# Ref: cluster/prichindel/smtp/README.md
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "FAIL: run as root (sudo)." >&2
  exit 1
fi

OUT_DIR="${PROTON_SMTP_OUT_DIR:-/data/smtp-outbound}"
ENV_FILE="${PROTON_SMTP_ENV_FILE:-${OUT_DIR}/proton-external.env}"
RELAY_KEY="${PROTON_SMTP_RELAY:-[smtp.protonmail.ch]:587}"
USER_MAIL="${PROTON_SMTP_USER:-igareosh@igareosh.com}"
HOST="${PROTON_SMTP_HOST:-smtp.protonmail.ch}"
PORT="${PROTON_SMTP_PORT:-587}"

if [ -z "${PROTON_SMTP_TOKEN:-}" ]; then
  read -r -s -p "PROTON_SMTP_TOKEN (no echo): " PROTON_SMTP_TOKEN
  echo "" >&2
fi

if [ -z "${PROTON_SMTP_TOKEN}" ]; then
  echo "FAIL: empty token" >&2
  exit 1
fi

mkdir -p "$OUT_DIR"
chmod 755 "$OUT_DIR"

umask 077
TMP=$(mktemp)
trap 'rm -f "$TMP"' EXIT
cat >"$TMP" <<EOF
# Managed by proton-smtp-secret-apply.sh — do not commit to git
PROTON_SMTP_HOST=${HOST}
PROTON_SMTP_PORT=${PORT}
PROTON_SMTP_USER=${USER_MAIL}
PROTON_SMTP_PASSWORD=${PROTON_SMTP_TOKEN}
EOF

install -m 0640 -o root -g igareosh "$TMP" "$ENV_FILE"
echo "OK: wrote ${ENV_FILE} (root:igareosh 640)"

cp -a /etc/postfix/sasl_passwd "/etc/postfix/sasl_passwd.bak.$(date +%s)" 2>/dev/null || true
printf '%s\t%s:%s\n' "$RELAY_KEY" "$USER_MAIL" "$PROTON_SMTP_TOKEN" >/etc/postfix/sasl_passwd
chmod 600 /etc/postfix/sasl_passwd
postmap /etc/postfix/sasl_passwd
systemctl reload postfix@-.service
postqueue -f
echo "OK: Postfix sasl_passwd synced, postfix reloaded, queue flush triggered."
