"""trustmaster: Application + OAuth2 provider for MinIO even library tile (separate client from Papra)."""
from authentik.core.models import Application
from authentik.providers.oauth2.models import OAuth2Provider, RedirectURI

CF_CB = "https://prichindel.cloudflareaccess.com/cdn-cgi/access/callback"
SLUG = "minio-console-even"
LAUNCH = "https://even.prichindel.com"

old = OAuth2Provider.objects.get(pk=1)

if Application.objects.filter(slug=SLUG).exists():
    app = Application.objects.get(slug=SLUG)
    app.meta_launch_url = LAUNCH
    app.save()
    print("UPDATED_LAUNCH_ONLY", SLUG)
    raise SystemExit(0)

np = OAuth2Provider.objects.create(
    name="minio-even-library",
    authorization_flow=old.authorization_flow,
    authentication_flow=old.authentication_flow,
    invalidation_flow=old.invalidation_flow,
    client_type=old.client_type,
    redirect_uris=[
        RedirectURI(url=CF_CB, matching_mode="strict"),
    ],
    include_claims_in_id_token=old.include_claims_in_id_token,
    access_code_validity=old.access_code_validity,
    access_token_validity=old.access_token_validity,
    refresh_token_validity=old.refresh_token_validity,
    refresh_token_threshold=old.refresh_token_threshold,
    sub_mode=old.sub_mode,
    issuer_mode=old.issuer_mode,
    logout_method=old.logout_method,
)
np.property_mappings.set(old.property_mappings.all())

app = Application.objects.create(
    name="MinIO — even.prichindel.com",
    slug=SLUG,
    provider=np,
    meta_launch_url=LAUNCH,
    meta_description="MinIO admin (Cloudflare Access in front).",
)
print("CREATED_APP", app.slug, app.pk, "provider", np.pk, "client_id", np.client_id)
