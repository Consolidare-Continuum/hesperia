---
task_id: "workflow|captain|manual"
active_md_anchor: "| captain |"
---

# Script runbook — Captain on deck (workflow automation manual)

**Purpose**: When [governance/captain_on_deck](../governance/captain_on_deck) is **1** (or env `CAPTAIN_ON_DECK=1`), **half-hourly automation does not** advance the driver/executor chain for unattended execution the same way — orchestrator may still emit heartbeat; **manual** execution is expected for the current phase. Ref: [governance/captain_on_deck](../governance/captain_on_deck), [.cursor/rules/cursor-main-awareness.mdc](../.cursor/rules/cursor-main-awareness.mdc).

**Who**: Operator sets/clears flag; Abelard verifies file on prichindel; Cursor reads heartbeat + current step for awareness.

---

## When to use

- Release week, incident, or operator wants **no unattended workflow progression**.
- Debugging driver/executor without cron overwriting state every 30 minutes.

---

## Procedure

1. **Set**: `echo 1 > governance/captain_on_deck` (repo root) or export `CAPTAIN_ON_DECK=1` for one-shot scripts that respect env.
2. **Verify**: `python3 scripts/workflow_orchestrator.py --stdout` — heartbeat reflects captain state where implemented; read [governance/workflow_heartbeat.txt](../governance/workflow_heartbeat.txt).
3. **Work**: Run [scripts/workflow_run.sh](workflow_run.sh) from IDE when operator says "proceed" — Cursor executes current step as owner; **report_done** when done.
4. **Clear**: `echo 0 > governance/captain_on_deck` when returning to automated cadence.

---

## Do not

- Do **not** leave captain on deck **1** indefinitely without documenting why in inbox or maintenance notes.
- Do **not** assume Cloud Agent runs — out of scope per [cluster/workflow-automation/README.md](../cluster/workflow-automation/README.md).

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| Automation still driving | Confirm file content is exactly `1` / `true`; check orchestrator respects captain (see workflow_driver / orchestrator code). |
| Stale current step | Manual `workflow_run.sh` or fix active.md + driver. |

---

## See also

- [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) — full chain.
- [SCRIPT-RUNBOOK-report-done-workflow.md](SCRIPT-RUNBOOK-report-done-workflow.md) — closing tasks.

SIGNED: Architecture (Ethan) | manual workflow mode | 2026-03-30 | SCRIPT-RUNBOOK
