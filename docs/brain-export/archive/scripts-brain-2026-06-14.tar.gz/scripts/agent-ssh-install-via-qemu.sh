#!/usr/bin/env bash
# Install agent CA trust on a Proxmox VM via qemu-guest-agent (no SSH required).
# Run on alunel as igareosh with sudo. Usage: agent-ssh-install-via-qemu.sh <vmid>
set -euo pipefail

VMID="${1:-}"
CA_PUB="${HOME}/.ssh/agent-ca/agent_ca.pub"

if [ -z "$VMID" ]; then
    echo "Usage: $0 <proxmox-vmid>" >&2
    exit 1
fi
if [ ! -f "$CA_PUB" ]; then
    echo "ERROR: $CA_PUB missing. Run agent-ssh-ca-init.sh on alunel." >&2
    exit 1
fi

CA_B64=$(base64 -w0 <"$CA_PUB")
sudo qm guest exec "$VMID" -- bash -lc "
set -e
echo ${CA_B64} | base64 -d > /tmp/agent_ca.pub
install -m 644 /tmp/agent_ca.pub /etc/ssh/agent_ca.pub
if grep -qE '^TrustedUserCAKeys' /etc/ssh/sshd_config; then
  sed -i 's|^TrustedUserCAKeys.*|TrustedUserCAKeys /etc/ssh/agent_ca.pub|' /etc/ssh/sshd_config
elif grep -qE '^#TrustedUserCAKeys' /etc/ssh/sshd_config; then
  sed -i 's|^#TrustedUserCAKeys.*|TrustedUserCAKeys /etc/ssh/agent_ca.pub|' /etc/ssh/sshd_config
else
  echo 'TrustedUserCAKeys /etc/ssh/agent_ca.pub' >> /etc/ssh/sshd_config
fi
echo 'igareosh ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/igareosh-agent
chmod 440 /etc/sudoers.d/igareosh-agent
visudo -cf /etc/sudoers.d/igareosh-agent
iptables -I INPUT 1 -s 192.168.100.0/24 -p tcp --dport 22 -j ACCEPT 2>/dev/null || true
systemctl reload sshd 2>/dev/null || systemctl reload ssh 2>/dev/null || service ssh reload 2>/dev/null || true
hostname
test -f /etc/ssh/agent_ca.pub && test -f /etc/sudoers.d/igareosh-agent && echo TRUST_OK
"

echo "DONE: vmid $VMID — CA trust via qemu guest agent"
