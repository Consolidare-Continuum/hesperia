#!/bin/bash
# Add IdentityFile and IdentitiesOnly to olgahere block in prichindel ~/.ssh/config.
# Run on prichindel: bash scripts/prichindel-ssh-config-olgahere.sh

set -e
CONFIG="$HOME/.ssh/config"
if ! grep -q "Host olgahere" "$CONFIG"; then
  echo "No olgahere block in config."
  exit 1
fi
if grep -A5 "Host olgahere" "$CONFIG" | grep -q "IdentityFile"; then
  echo "olgahere already has IdentityFile."
  exit 0
fi
cp "$CONFIG" "$CONFIG.bak.$(date +%s)"
sed -i '/^Host olgahere$/,/^Host \|^$/{
  /^  User Olga$/a\
  IdentityFile ~/.ssh/id_rsa\
  IdentitiesOnly yes
}' "$CONFIG"
grep -A8 "Host olgahere" "$CONFIG"
echo "Done."
