$p = 'C:\1\BOOKS_LIST_MACHINE.txt'
$utf8 = New-Object System.Text.UTF8Encoding $false
$c = [System.IO.File]::ReadAllText($p)
$h = "LANG`tAUTHOR`tTITLE`tEXT`tREL_PATH`r`n"
if (-not $c.StartsWith('LANG')) {
    [System.IO.File]::WriteAllText($p, $h + $c, $utf8)
}
