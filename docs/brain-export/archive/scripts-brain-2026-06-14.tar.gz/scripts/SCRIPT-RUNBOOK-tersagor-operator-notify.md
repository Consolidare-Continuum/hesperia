---
task_id: "team|operator-notify|tersagor"
active_md_anchor: "| operator |"
---

# Script runbook — Notify igareosh via Telegram (Tersagor)

**Purpose**: **One command** for any Cursor agent (or Abelard/Gena/Felix) to deliver a message to **igareosh** on Telegram (@TersagorBot private chat) with an IMIRC audit line on **`#operator-notify`**. Replaces ad-hoc Python/curl chains that SSH hop through trustmaster for bot tokens.

**Who**: **Any agent** when the operator asked for Telegram delivery, or when reporting secrets/ops outcomes that must reach igareosh immediately.

**Maintainer**: Architecture (Ethan) · deploy/infra: Abelard.

---

## When to use (mandatory)

| Situation | Use this runbook |
|-----------|------------------|
| Operator says **“send by Tersagor”** / **“Telegram me”** | **Yes** — this script only |
| Deliver **secret or credential** to igareosh (not dima.s / third parties) | **Yes** — never invent SSH+Python paths |
| Pentest / deploy **done** — short status to operator phone | **Yes** |
| Team task triage / Grace escalation | **No** — use [SCRIPT-RUNBOOK-escalate-grace.md](SCRIPT-RUNBOOK-escalate-grace.md) |
| Prometheus / infra **alert** | **No** — Alertmanager → `/imirc/prometheus` (existing path) |

---

## One command (default)

From **brain repo root** on **alunel** (or any host with `ssh alunel` + LAN):

```bash
bash scripts/tersagor-operator-notify.sh "Your message here."
```

**Implementation:** [cluster/tersagor/operator-notify/operator_notify.py](../cluster/tersagor/operator-notify/operator_notify.py) (Python, stdlib) — shell wrapper prefers it when token is available.

**On tersagor VM** (after `deploy-on-vm.sh`):

```bash
operator-notify -t "title" "message"
```

Source of truth: **igareosh/tersagor** → `src/operator_notify/operator_notify.py`.

With title and severity:

```bash
bash scripts/tersagor-operator-notify.sh -t "n8n webhook gateway" -s info \
  "Header X-N8n-Webhook-Gateway — value communicated out of band to dima.s."
```

Multi-line (stdin):

```bash
printf '%s\n' "line 1" "line 2" | bash scripts/tersagor-operator-notify.sh -t "deploy summary"
```

**Success:** JSON `{"ok":true,"telegram":"ok",...}` on stdout.  
**Failure:** non-zero exit; read stderr — do **not** fall back to hand-rolled Telegram API unless this runbook’s failure section says so.

---

## What happens under the hood

```mermaid
flowchart LR
  A[Agent: tersagor-operator-notify.sh] --> B[prichindel: Bearer imirc_web_token]
  B --> C[tersagor :18090 POST /imirc/operator-notify]
  C --> D[Telegram API → igareosh DM]
  C --> E[IMIRC classify JSONL → #operator-notify]
```

| Layer | Detail |
|-------|--------|
| **Auth** | Bearer `IMIRC_WEB_TOKEN` — file on prichindel only: `/data/docker/prometheus/config/imirc_web_token` (same as Prometheus → tersagor path) |
| **Telegram** | Direct `sendMessage` to `TERSAGOR_TELEGRAM_CHAT_ID` (operator DM) |
| **IMIRC** | Audit/task line on **`#operator-notify`** (override: `--channel`) |
| **Gateway** | `tersagor-approval-gateway.service` · `http://192.168.100.68:18090` |

---

## Agent rules (all Cursor / Copilot / Felix)

1. **Do not** assemble one-off `ssh trustmaster` + `python3` + `grep tersagor-approval.env` flows.
2. **Do not** paste bot tokens or `imirc_web_token` in chat, repo, or commits.
3. **Do** run `bash scripts/tersagor-operator-notify.sh "..."` from repo root (via `ssh alunel` if your workspace is altitudine/LAMAITA).
4. **Secrets to operator**: use this script; **secrets to third parties**: operator handoff — not Telegram to external users unless operator explicitly says so.
5. If endpoint returns **404**, run once: `bash scripts/tersagor-operator-notify.sh --deploy-gateway` (Abelard), then retry.

---

## Options reference

| Flag | Meaning |
|------|---------|
| `-t, --title` | Short title in Telegram header |
| `-s, --severity` | `info` \| `warn` \| `critical` (default `info`) |
| `--source` | Label footer (default `cursor_agent`) |
| `--channel` | IRC channel (default `#operator-notify`) |
| `--deploy-gateway` | Push `app.py` to tersagor + restart gateway |

**Env overrides:** `TERSAGOR_IMIRC_WEB_TOKEN`, `TERSAGOR_OPERATOR_NOTIFY_URL`, `TERSAGOR_NOTIFY_SSH` (default `alunel`).

---

## IMIRC channel `#operator-notify`

**Purpose:** Durable audit trail for agent → operator notifications (Lounge / eggdrop classify path), separate from `#agents-ingest` traffic and `#agents-ops` Prometheus alerts.

**On tersagor VM** — add to `tersagor-approval.env` (Abelard, not in git):

```bash
IMIRC_OPERATOR_CHANNEL=#operator-notify
IMIRC_OPERATOR_IRC_PRESENCE=1
# Optional: join channel from presence bot
IMIRC_IRC_CHANNELS=#agents-ingest,#agents-ops,#agents-debug,#operator-notify
```

Ergo must allow the channel (default Ergo on tersagor allows new channels on join). Restart after env change:

```bash
sudo systemctl restart tersagor-approval-gateway.service
# presence bot if IMIRC_IRC_CHANNELS changed:
systemctl --user restart imirc-tersagor-presence.service
```

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| `404` on `/imirc/operator-notify` | Gateway old — `bash scripts/tersagor-operator-notify.sh --deploy-gateway` |
| `401/403` | Token mismatch — on prichindel verify `/data/docker/prometheus/config/imirc_web_token` matches tersagor `IMIRC_WEB_TOKEN` |
| `502 telegram_failed` | Check `TERSAGOR_TELEGRAM_BOT_TOKEN` / `CHAT_ID` on tersagor; `curl http://192.168.100.68:18090/health` |
| `no IMIRC web token` | `ssh prichindel` — ensure prometheus config dir has `imirc_web_token`; see [deploy-prometheus-tersagor-reporting.sh](deploy-prometheus-tersagor-reporting.sh) |
| SSH to prichindel fails | [SCRIPT-RUNBOOK-connection-resolution.md](SCRIPT-RUNBOOK-connection-resolution.md); run from **alunel** |

**Legacy fallback (discouraged):** only if gateway unreachable after Abelard triage — operator mail via Postfix (`igareosh@igareosh.com`), not ad-hoc Telegram token hunting.

---

## Deploy / upgrade gateway

After editing [cluster/tersagor/approval-gateway/app.py](../cluster/tersagor/approval-gateway/app.py) or [cluster/tersagor/operator-notify/operator_notify.py](../cluster/tersagor/operator-notify/operator_notify.py):

```bash
# Brain mirror → tersagor repo (source of truth: igareosh/tersagor), then on VM:
ssh tersagor 'cd /data/tersagor && git pull && bash deploy/deploy-on-vm.sh'

# Quick gateway-only (brain mirror app.py):
bash scripts/tersagor-operator-notify.sh --deploy-gateway
bash scripts/tersagor-operator-notify.sh -t "smoke" "operator-notify runbook smoke test"
```

Or full prometheus bundle: `bash scripts/deploy-prometheus-tersagor-reporting.sh`

---

## See also

- [cluster/tersagor/OPERATOR-HEALTH.md](../cluster/tersagor/OPERATOR-HEALTH.md) — routes and triage
- [cluster/tersagor/approval-gateway/README.md](../cluster/tersagor/approval-gateway/README.md) — env vars
- [agents/abelard/ABELARD_QUICK_OPS.md](../agents/abelard/ABELARD_QUICK_OPS.md) §3a — quick pointer
- [governance/ETHAN-TARGETED-RUNBOOKS-MANDATORY.md](../governance/ETHAN-TARGETED-RUNBOOKS-MANDATORY.md) — mandatory trigger

SIGNED: Architecture (Ethan) | operator Telegram notify | 2026-05-28 | SCRIPT-RUNBOOK
