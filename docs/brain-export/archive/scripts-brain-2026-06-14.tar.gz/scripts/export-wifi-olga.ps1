# Export WiFi profiles Olga 5G and Olga 2.4G (real-world home/office) with key for backup.
# Output: cluster\wifi-backup\ (gitignored — never commit). Run as Administrator for key=clear.
# See cluster/REAL-ENVIRONMENT.md, cluster/LAPTOP.md.

$ErrorActionPreference = 'Stop'
$folder = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "cluster\wifi-backup"
$profiles = @("Olga 5G", "Olga 2.4G")

if (-not (Test-Path $folder)) { New-Item -ItemType Directory -Path $folder -Force | Out-Null }

foreach ($name in $profiles) {
    netsh wlan export profile name="$name" folder="$folder" key=clear
}
Write-Host "Exported to $folder (gitignored)."
