#!/usr/bin/env bash
# Preflight for Cursor on alunel: DNS, SSH to prichindel, MCP files, session detector.
# Run from repo root on alunel. Ref: cluster/alunel/CURSOR-DEV-HOST.md
set -e
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO_ROOT"
fail=0
echo "=== verify-alunel-cursor-env (host=$(hostname -s)) ==="

if ! getent hosts prichindel | grep -q '192.168.100.21'; then
  echo "FAIL: prichindel must resolve to 192.168.100.21 (see /etc/hosts)."
  fail=1
else
  echo "OK: getent hosts prichindel"
fi

if ssh -o BatchMode=yes -o ConnectTimeout=8 prichindel 'echo ok' 2>/dev/null | grep -q ok; then
  echo "OK: ssh prichindel"
else
  echo "FAIL: ssh prichindel (authorize cluster/alunel/alunel-to-prichindel.pub on prichindel; see CURSOR-DEV-HOST.md)"
  fail=1
fi

if command -v python3 >/dev/null && python3 --version; then
  echo "OK: python3"
else
  echo "FAIL: python3 missing"
  fail=1
fi

MCPC="$REPO_ROOT/governance/mcp-config.json"
DEST="${HOME}/.cursor/mcp.json"
if [ -f "$DEST" ] && cmp -s "$MCPC" "$DEST"; then
  echo "OK: ~/.cursor/mcp.json matches governance/mcp-config.json"
else
  echo "WARN: run bash scripts/deploy-mcp-config-global.sh (mcp.json missing or drift)"
  fail=1
fi

bash "$REPO_ROOT/scripts/detect-cursor-session-mode.sh" "$REPO_ROOT" >/dev/null
echo "OK: cursor_session_mode.txt -> $(cat "$REPO_ROOT/governance/cursor_session_mode.txt")"

if [ "$fail" -eq 0 ]; then
  echo "=== all checks passed ==="
  exit 0
fi
echo "=== some checks failed ==="
exit 1
