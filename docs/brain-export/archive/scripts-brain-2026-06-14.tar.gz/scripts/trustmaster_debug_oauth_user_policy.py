"""One-off: print OAuth app bindings and user for trustmaster debug."""
from django.contrib.auth import get_user_model
from authentik.core.models import Application
from authentik.policies.models import PolicyBinding
from authentik.providers.oauth2.models import OAuth2Provider

User = get_user_model()
p = OAuth2Provider.objects.get(client_id__startswith="Qngrwu")
print("Provider", p.pk, p.name)
app = p.application
print("Application", app.pk, app.name, app.slug)
for b in PolicyBinding.objects.filter(target=app).order_by("order"):
    pol = getattr(b, "policy", None)
    print(" binding", b.order, "policy", pol, "group", b.group, "user", getattr(b, "user", None))
for u in ("igareosh-proton", "igareosh@protonmail.com"):
    try:
        user = User.objects.get(username=u)
    except User.DoesNotExist:
        try:
            user = User.objects.get(email=u)
        except User.DoesNotExist:
            print("user not found", u)
            continue
    print("User", user.username, user.email, "active", user.is_active)
    print(" groups", list(user.groups.values_list("name", flat=True)))
