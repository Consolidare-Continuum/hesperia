# fluturas-onedrive-remove.ps1 — OneDrive = spyware: disable, uninstall, remove remnants. Without damaging Windows.
# Run on fluturas as Administrator. Uses official uninstaller only; no deletion of system binaries.
# Requires: -ExecutionPolicy Bypass

$ErrorActionPreference = 'Continue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

Write-Host "=== 1. Kill OneDrive process ==="
Get-Process -Name OneDrive -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Write-Host "OneDrive process stopped (if was running)."

Write-Host "`n=== 2. Policy: prevent OneDrive from running ==="
$policyPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive'
if (-not (Test-Path -LiteralPath $policyPath)) { New-Item -Path $policyPath -Force | Out-Null }
Set-ItemProperty -Path $policyPath -Name DisableFileSyncNGSC -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
Write-Host "Registry DisableFileSyncNGSC = 1 set."

Write-Host "`n=== 3. Uninstall via official OneDriveSetup.exe ==="
$uninstallers = @(
    "${env:ProgramFiles}\Microsoft OneDrive\OneDriveSetup.exe",
    "${env:ProgramFiles(x86)}\Microsoft OneDrive\OneDriveSetup.exe",
    "$env:SystemRoot\SysWOW64\OneDriveSetup.exe",
    "$env:SystemRoot\System32\OneDriveSetup.exe"
)
$done = $false
foreach ($exe in $uninstallers) {
    if (Test-Path -LiteralPath $exe) {
        Write-Host "Running: $exe /uninstall"
        $p = Start-Process -FilePath $exe -ArgumentList '/uninstall' -Wait -PassThru -WindowStyle Hidden
        $done = $true
        break
    }
}
if (-not $done) { Write-Host "OneDriveSetup.exe not found; OneDrive may already be uninstalled or not installed." }

Write-Host "`n=== 4. Remove Run / RunOnce entries ==="
$runPaths = @(
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
)
foreach ($r in $runPaths) {
    if (-not (Test-Path $r)) { continue }
    $props = Get-ItemProperty -Path $r -ErrorAction SilentlyContinue
    if (-not $props) { continue }
    $props.PSObject.Properties | Where-Object { $_.Name -notin @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') } | ForEach-Object {
        $name = $_.Name
        $val = $_.Value
        if ($val -and ($name -like '*OneDrive*' -or $val -like '*OneDrive*')) {
            Remove-ItemProperty -Path $r -Name $name -Force -ErrorAction SilentlyContinue
            Write-Host "  Removed: $r -> $name"
        }
    }
}

Write-Host "`n=== 5. Disable and remove OneDrive scheduled tasks ==="
Get-ScheduledTask -TaskPath '\' -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like '*OneDrive*' } | ForEach-Object {
    Disable-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "  Removed task: $($_.TaskName)"
}

Write-Host "`n=== 6. Remove leftover folders (safe; no system paths) ==="
$localOneDrive = "$env:LOCALAPPDATA\Microsoft\OneDrive"
if (Test-Path -LiteralPath $localOneDrive) {
    Remove-Item -LiteralPath $localOneDrive -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  Removed: $localOneDrive"
}
$userOneDrive = "$env:USERPROFILE\OneDrive"
if (Test-Path -LiteralPath $userOneDrive) {
    $count = (Get-ChildItem -LiteralPath $userOneDrive -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count
    if ($count -eq 0) {
        Remove-Item -LiteralPath $userOneDrive -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  Removed (empty): $userOneDrive"
    } else {
        Write-Host "  Left in place (has $count items): $userOneDrive - remove manually if desired."
    }
}
# ProgramData OneDrive (updater/cache)
$programDataOneDrive = "$env:ProgramData\Microsoft OneDrive"
if (Test-Path -LiteralPath $programDataOneDrive) {
    Remove-Item -LiteralPath $programDataOneDrive -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  Removed: $programDataOneDrive"
}

Write-Host "`nDone. OneDrive disabled/uninstalled/removed where possible. Reboot if prompted."
