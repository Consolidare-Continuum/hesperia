"""trustmaster: allow any Cloudflare Zero Trust team Access callback on OAuth2 pk=1 (REGEX)."""
from authentik.providers.oauth2.models import OAuth2Provider, RedirectURI, RedirectURIMatchingMode

CF_STRICT = "https://prichindel.cloudflareaccess.com/cdn-cgi/access/callback"
# One regex covers prichindel / igareosh / any other team hostname.
CF_REGEX = r"https://[^/]+\.cloudflareaccess\.com/cdn-cgi/access/callback"

p = OAuth2Provider.objects.get(pk=1)
new_uris = []
seen_cf_regex = False
for u in p.redirect_uris:
    url = getattr(u, "url", "")
    mode = getattr(u, "matching_mode", None)
    if CF_STRICT in url or (
        mode == RedirectURIMatchingMode.REGEX and "cloudflareaccess.com" in url
    ):
        continue  # drop old CF rows; we replace with one regex
    new_uris.append(u)

new_uris.append(
    RedirectURI(url=CF_REGEX, matching_mode=RedirectURIMatchingMode.REGEX)
)

p.redirect_uris = new_uris
p.save()
print("OK provider", p.pk, "redirect count", len(list(p.redirect_uris)))
for u in p.redirect_uris:
    print(u.url, u.matching_mode)
