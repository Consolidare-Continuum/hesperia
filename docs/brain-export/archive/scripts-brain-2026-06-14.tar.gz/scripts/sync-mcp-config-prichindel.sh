#!/usr/bin/env bash
# Delegates to deploy-mcp-config-global.sh: governance/mcp-config.json → ~/.cursor/mcp.json and .cursor/mcp.json.
# Run on the machine where Cursor runs (e.g. prichindel). One design. Ref: governance/MCP-COMPLIANCE-AND-OPERATIONAL.md
REPO_ROOT="${REPO_ROOT:-/data/altitudine/prichindel.com}"
exec bash "$(dirname "$0")/deploy-mcp-config-global.sh"
