# olgahere: Install OpenSSH Server, key-only, inbound SSH only from cluster LAN.
# Run as Administrator. See cluster/olgahere/README.md.

$ErrorActionPreference = 'Stop'
$clusterIPs = '192.168.100.21,192.168.100.23,192.168.100.40'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run as Administrator."
    exit 1
}

# 1. Install OpenSSH Server if not present
$cap = Get-WindowsCapability -Online | Where-Object Name -eq 'OpenSSH.Server~~~~0.0.1.0'
if ($cap.State -ne 'Installed') {
    Add-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0'
    Write-Host "OpenSSH Server installed."
} else {
    Write-Host "OpenSSH Server already installed."
}

# 2. Ensure sshd_config exists (Windows creates it on first service start)
$sshDir = "$env:ProgramData\ssh"
$cfg = "$sshDir\sshd_config"
if (-not (Test-Path $cfg)) {
    if (-not (Test-Path $sshDir)) { New-Item -ItemType Directory -Path $sshDir -Force | Out-Null }
    Set-Service -Name sshd -StartupType Automatic -ErrorAction SilentlyContinue
    Start-Service sshd -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 3
}
if (-not (Test-Path $cfg)) {
    $candidates = @(
        "$env:ProgramFiles\OpenSSH\sshd_config_default",
        "$env:SystemRoot\System32\OpenSSH\sshd_config_default"
    )
    $binPath = (Get-WmiObject Win32_Service -Filter "Name='sshd'" -ErrorAction SilentlyContinue).PathName
    if ($binPath -match '"([^"]+)\\sshd\.exe"') { $candidates += "$($Matches[1])\sshd_config_default" }
    $copied = $false
    foreach ($defaultCfg in $candidates) {
        if ($defaultCfg -and (Test-Path $defaultCfg)) {
            Copy-Item $defaultCfg $cfg -Force
            Write-Host "Copied default sshd_config from $defaultCfg"
            $copied = $true
            break
        }
    }
    if (-not $copied) {
        Write-Error "sshd_config not found. Copy manually: copy $env:SystemRoot\System32\OpenSSH\sshd_config_default $cfg (as Admin), then re-run."
        exit 1
    }
}
if (-not (Select-String -Path $cfg -Pattern "PasswordAuthentication no" -Quiet -ErrorAction SilentlyContinue)) {
    Copy-Item $cfg "$cfg.bak.$(Get-Date -Format 'yyyyMMdd-HHmm')" -Force
    Add-Content -Path $cfg -Value "`n# olgahere: key-only (cluster/olgahere)`nPasswordAuthentication no"
    Write-Host "sshd_config: PasswordAuthentication no added."
}

# 3. Firewall: inbound TCP 22 only from cluster LAN
netsh advfirewall firewall delete rule name="OpenSSH SSH Server (cluster only)" dir=in 2>$null
netsh advfirewall firewall delete rule name="OpenSSH SSH Server Preview (sshd)" dir=in 2>$null
netsh advfirewall firewall add rule name="OpenSSH SSH Server (cluster only)" dir=in action=allow protocol=TCP localport=22 remoteip=$clusterIPs profile=private,domain
Write-Host "Firewall: inbound SSH only from $clusterIPs"

# 4. Start sshd
Set-Service -Name sshd -StartupType Automatic
Start-Service sshd -ErrorAction SilentlyContinue
Write-Host "sshd: Automatic, started."
Write-Host "Done. From prichindel: ssh Olga@192.168.100.5 (or igareosh@prichindel then ssh Olga@192.168.100.5)"
exit 0
