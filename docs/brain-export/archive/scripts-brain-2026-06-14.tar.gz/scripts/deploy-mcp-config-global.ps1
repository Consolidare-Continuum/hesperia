# Deploy MCP config globally. Windows: user mcp.json from mcp-config-windows.json (PowerShell+ssh to prichindel).
# Also sync governance/mcp-config.json -> repo .cursor/mcp.json (Linux-canonical; used when workspace is Remote-SSH to prichindel / Linux).
# Run from repo root on Windows. After run: restart Cursor.
$ErrorActionPreference = "Stop"
$RepoRoot = if ($env:REPO_ROOT) { $env:REPO_ROOT } else { (Get-Location).Path }
$WinConfig = Join-Path $RepoRoot "governance\mcp-config-windows.json"
$LinuxCanonical = Join-Path $RepoRoot "governance\mcp-config.json"
$Src = if (Test-Path $WinConfig) { $WinConfig } else { $LinuxCanonical }
$Dest = Join-Path $env:USERPROFILE ".cursor\mcp.json"
$DestDir = Split-Path $Dest -Parent
if (-not (Test-Path $DestDir)) { New-Item -ItemType Directory -Path $DestDir -Force | Out-Null }
Copy-Item -Path $Src -Destination $Dest -Force
Write-Host "Deployed $Src -> $Dest"
$ProjectMcpDir = Join-Path $RepoRoot ".cursor"
if (-not (Test-Path $ProjectMcpDir)) { New-Item -ItemType Directory -Path $ProjectMcpDir -Force | Out-Null }
if (Test-Path $LinuxCanonical) {
    $ProjectMcp = Join-Path $ProjectMcpDir "mcp.json"
    Copy-Item -Path $LinuxCanonical -Destination $ProjectMcp -Force
    Write-Host "Synced $LinuxCanonical -> $ProjectMcp"
}
Write-Host "Restart Cursor."
