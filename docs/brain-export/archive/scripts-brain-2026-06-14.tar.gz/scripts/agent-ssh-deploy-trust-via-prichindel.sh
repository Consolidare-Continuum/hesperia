#!/usr/bin/env bash
# Deploy agent CA trust from prichindel to LAN hosts alunel cannot reach directly.
# Run on alunel: copies CA + install script to prichindel, then SSH hub installs each target.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CA_PUB="$HOME/.ssh/agent-ca/agent_ca.pub"
INSTALL_SCRIPT="$SCRIPT_DIR/agent-ssh-install-trust.sh"
HUB="${AGENT_SSH_HUB:-prichindel}"
SSH_OPTS=(-o ConnectTimeout=6 -o BatchMode=yes)

if [ ! -f "$CA_PUB" ]; then
    echo "ERROR: CA not found. Run agent-ssh-ca-init.sh on alunel first." >&2
    exit 1
fi

# Targets reachable from prichindel (name + optional IPs). Skip if already done via main deploy.
TARGETS=(
    izvoras:192.168.100.58
    trustmaster:192.168.100.67
    tersagor:192.168.100.68:100.76.33.56
    librarymaster:192.168.100.66:100.89.236.59
    stejarel:192.168.100.19
    mugurel:192.168.100.57
    voinicel:192.168.100.90:192.168.100.16
    fulgusor:192.168.100.40
)

echo "=== Hub: $HUB ==="
scp -q "${SSH_OPTS[@]}" "$CA_PUB" "$INSTALL_SCRIPT" "igareosh@${HUB}:/tmp/"
FAILED=()
OK=()

resolve_from_hub() {
    local name="$1"
    shift
    local ips=("$@")
    local t
    for t in "$name" "${name}.prichindel.local" "${ips[@]}"; do
        [ -n "$t" ] || continue
        if ssh "${SSH_OPTS[@]}" "igareosh@${HUB}" \
            "ssh ${SSH_OPTS[*]} igareosh@${t} true" 2>/dev/null; then
            echo "$t"
            return 0
        fi
    done
    return 1
}

for entry in "${TARGETS[@]}"; do
    IFS=: read -r NAME IP1 IP2 <<<"$entry"
    echo "=== $NAME (via $HUB) ==="
    IPS=()
    [ -n "${IP1:-}" ] && IPS+=("$IP1")
    [ -n "${IP2:-}" ] && IPS+=("$IP2")
    if ! TARGET=$(resolve_from_hub "$NAME" "${IPS[@]}"); then
        echo "SKIP: $NAME not reachable from $HUB"
        FAILED+=("$NAME")
        continue
    fi
    echo "Using: $HUB -> $TARGET"
    if ssh "${SSH_OPTS[@]}" "igareosh@${HUB}" \
        "ssh ${SSH_OPTS[*]} igareosh@${TARGET} 'test -f /etc/ssh/agent_ca.pub && test -f /etc/sudoers.d/igareosh-agent'" 2>/dev/null; then
        OK+=("$NAME")
        echo "OK: $NAME (already trusted)"
        continue
    fi
    if ssh "${SSH_OPTS[@]}" "igareosh@${HUB}" \
        "scp ${SSH_OPTS[*]} /tmp/agent_ca.pub /tmp/agent-ssh-install-trust.sh igareosh@${TARGET}:/tmp/ && \
         ssh ${SSH_OPTS[*]} igareosh@${TARGET} 'sudo bash /tmp/agent-ssh-install-trust.sh /tmp/agent_ca.pub; rm -f /tmp/agent_ca.pub /tmp/agent-ssh-install-trust.sh'"; then
        OK+=("$NAME")
        echo "OK: $NAME"
    else
        FAILED+=("$NAME")
        echo "FAILED: $NAME"
    fi
done

echo ""
echo "=== HUB SUMMARY ==="
echo "OK    (${#OK[@]}): ${OK[*]:-none}"
echo "FAILED(${#FAILED[@]}): ${FAILED[*]:-none}"
[ ${#FAILED[@]} -eq 0 ]
