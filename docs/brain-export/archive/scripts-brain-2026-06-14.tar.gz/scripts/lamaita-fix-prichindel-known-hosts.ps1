# Fix stale prichindel host key and refresh ED25519 entry. Run on LAMAITA per Windows profile.
param(
    [Parameter(Mandatory = $true)]
    [string]$ProfileName
)
$ErrorActionPreference = "Continue"
$kh = Join-Path "C:\Users\$ProfileName\.ssh" "known_hosts"
$sshDir = Split-Path $kh -Parent
if (-not (Test-Path $sshDir)) { New-Item -ItemType Directory -Path $sshDir -Force | Out-Null }
if (Test-Path $kh) {
    & ssh-keygen -R 192.168.100.21 -f $kh 2>$null | Out-Null
}
$keyscan = & ssh-keyscan -t ed25519 192.168.100.21 2>$null | Where-Object { $_ -match '^192\.168\.' }
if ($keyscan) {
    Add-Content -Path $kh -Value $keyscan -Encoding ascii
}
Write-Host "OK: known_hosts updated for $ProfileName"
exit 0
