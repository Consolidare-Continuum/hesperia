#!/usr/bin/env python3
"""EOW repo-state research → 50 execution/integration rows (5 × 10 entities) for Grace triage."""
from __future__ import annotations

import json
import re
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent

# Scope: execution, integration, pathing, awareness — not weekly doc generation.
ENTITIES: list[tuple[str, str, str]] = [
    ("Ethan", "Chief Architect", "pathing: host/role, workflow entry points, compliance execution"),
    ("Grace", "Product Director", "workflow path: active.md, triage, OPEN row integrity"),
    ("Olivia", "Backend Lead", "workflow driver/executor/API execution path"),
    ("Ava", "Frontend Lead", "IDE/browser MCP integration path"),
    ("Marcus", "DB Lead", "Chroma ingest path, instance registry wiring"),
    ("Sophia", "DevOps Lead", "cluster reachability, session mode, SSH path"),
    ("Liam", "Automation", "script/runbook execution, MCP drift run/fix"),
    ("Daniel", "Security Lead", "SSH CA, approval gates, no fake DONE on destructive"),
    ("Noah", "AI Systems", "Chroma/MCP context sync, query path alive"),
    ("Emma", "Integrations", "MCP deploy, workflow API, tersagor/mail wiring"),
]


@dataclass
class Signal:
    category: str
    detail: str
    paths: list[str] = field(default_factory=list)


def run_git(args: list[str]) -> str:
    try:
        return subprocess.run(
            ["git", *args],
            cwd=REPO,
            capture_output=True,
            text=True,
            check=False,
        ).stdout.strip()
    except OSError:
        return ""


def collect_signals(week: str, wave_label: str) -> list[Signal]:
    signals: list[Signal] = []
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # Git hygiene
    status = run_git(["status", "--short"])
    if status:
        lines = [ln for ln in status.splitlines() if ln.strip()]
        signals.append(
            Signal("git_dirty", f"{len(lines)} uncommitted path(s)", lines[:12])
        )

    # active.md OPEN
    active = (REPO / "active.md").read_text(encoding="utf-8", errors="replace")
    open_rows = len(re.findall(r"\|\s*OPEN\s*\|", active))
    repo_open = len(
        re.findall(r"REPO-EOW|REPO-AUTO|REPO-EOD", active)
    )
    signals.append(
        Signal("active_md", f"OPEN rows={open_rows}; repo-wave mentions={repo_open}")
    )

    # Cluster README audits (Sophia)
    cluster_rms = sorted((REPO / "cluster").glob("*/README.md"))
    stale_audit: list[str] = []
    for p in cluster_rms:
        text = p.read_text(encoding="utf-8", errors="replace")
        if wave_label not in text and f"**Brain audit:** {today}" not in text:
            stale_audit.append(p.parent.name)
    if stale_audit:
        signals.append(
            Signal(
                "cluster_audit_stale",
                f"{len(stale_audit)}/{len(cluster_rms)} cluster READMEs need {wave_label} audit",
                stale_audit[:15],
            )
        )

    # Runbooks (Liam)
    runbooks = sorted((REPO / "scripts").glob("SCRIPT-RUNBOOK-*.md"))
    tiny = [p.name for p in runbooks if p.stat().st_size < 200]
    if tiny:
        signals.append(Signal("runbook_tiny", f"{len(tiny)} tiny runbook(s)", tiny))

    # MCP drift (Emma / Noah)
    drift_script = REPO / "scripts/mcp_config_drift_check.sh"
    if drift_script.is_file():
        proc = subprocess.run(
            ["bash", str(drift_script)],
            cwd=REPO,
            capture_output=True,
            text=True,
        )
        if "drift_detected=1" in proc.stdout:
            signals.append(Signal("mcp_drift", "MCP config drift detected"))

    # Governance INDEX gaps (Ethan) — sample: governance md not linked from INDEX
    index = (REPO / "INDEX.md").read_text(encoding="utf-8", errors="replace")
    gov_files = sorted((REPO / "governance").glob("*.md"))[:40]
    unlinked = [p.name for p in gov_files if p.name not in index][:8]
    if unlinked:
        signals.append(
            Signal("index_governance_gap", f"{len(unlinked)} governance doc(s) not in INDEX", unlinked)
        )

    # inbox (Grace)
    inbox = (REPO / "inbox.md").read_text(encoding="utf-8", errors="replace")
    if "TODO" in inbox or "OPEN" in inbox.upper():
        signals.append(Signal("inbox_attention", "inbox.md may need weekly triage pass"))

    # operational assignments orphan count
    op_dir = REPO / "operational/assignments"
    if op_dir.is_dir():
        recent = sorted(op_dir.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
        if len(recent) > 30:
            signals.append(
                Signal(
                    "operational_volume",
                    f"{len(list(op_dir.glob('*.md')))} assignment markdown files under operational/assignments",
                )
            )

    # Chroma policy freshness (Noah)
    chroma_policy = REPO / "governance/CHROMA-USAGE-POLICY.md"
    if chroma_policy.is_file() and week not in chroma_policy.read_text(encoding="utf-8", errors="replace"):
        signals.append(Signal("chroma_policy_week", "CHROMA-USAGE-POLICY has no this-week EOW touch marker"))

    # SSH CA cert status (Daniel)
    cert = REPO / "governance/agent_ssh_cert_status.txt"
    if cert.is_file():
        text = cert.read_text(encoding="utf-8", errors="replace")
        if "valid_until" in text:
            m = re.search(r"valid_until=(\S+)", text)
            if m:
                signals.append(Signal("ssh_ca", f"agent SSH CA valid_until={m.group(1)}"))

    return signals


def tasks_for_entity(
    entity: str,
    role: str,
    domain: str,
    seq: int,
    week: str,
    ww: str,
    signals: list[Signal],
) -> list[dict]:
    """Return exactly 5 execution/integration rows for one entity."""
    tasks: list[dict] = []

    def add(n: int, kind: str, summary: str, acceptance: str, signal_ref: str = "") -> None:
        tasks.append(
            {
                "id": f"REPO-EOW-{ww}-{seq + n - 1:03d}",
                "owner": entity,
                "role": role,
                "kind": kind,
                "summary": summary,
                "acceptance": acceptance,
                "signal": signal_ref,
                "project": "cursor-repo",
                "priority": "P1",
            }
        )

    if entity == "Ethan":
        add(1, "pathing", "Run verify-host-role-separation.sh", "Script exit 0 or gaps logged in closure; fix wiring only if broken")
        add(2, "integration", "Match WORKFLOW-SCRIPT-NAMES to scripts/ on disk", "Stale names fixed or listed in closure; no new governance file")
        add(3, "awareness", "Workflow driver entry points resolve", "Each named script in WORKFLOW-SCRIPT-NAMES exists; broken refs fixed")
        add(4, "execution", "Append EOW compliance row", "One row in CURSOR-REPO-COMPLIANCE-CHECK.md with N/50 + what ran")
        add(5, "awareness", "CCB note only if contract changed", "If execution changed governance/contracts this week: one line in closure; else skip")
    elif entity == "Grace":
        add(1, "execution", "Triage register → active.md", "50 REPO-EOW rows triaged OPEN; DONE only after verified execution")
        add(2, "awareness", "active.md OPEN row integrity", "Each OPEN row has owner + project; non-repo OPEN counted for closure", "active_md")
        add(3, "integration", "Workflow context path alive", "Read workflow_heartbeat + workflow_driver_current; stale driver noted or refreshed via workflow_run")
        add(4, "execution", "until-done gate", "end_of_week_run.sh until-done exit 0 before closure")
        add(5, "awareness", "inbox → active path", "Blocking inbox items linked or triaged; no new assignment markdown unless required", "inbox_attention")
    elif entity == "Olivia":
        add(1, "execution", "Run workflow_run.sh one pass", "Driver current step file updated or autonomous_idle confirmed")
        add(2, "integration", "Workflow API 9096 reachability", "curl heartbeat or documented skip in closure")
        add(3, "integration", "workflow_driver.py script refs", "Imports/paths match repo; fix broken wiring only")
        add(4, "awareness", "Context passport path", "workflow_context_current.md present when driver has OPEN step")
        add(5, "integration", "abelard_executor path", "cluster/workflow-automation/abelard_executor.py referenced and reachable")
    elif entity == "Ava":
        add(1, "integration", "Browser MCP in deployed config", "mcp.json template includes cursor-ide-browser; deploy if drift", "mcp_drift")
        add(2, "integration", "docs/CURSOR.md matches MCP deploy paths", "Fix drift in existing doc; no new doc unless MCP setup broken")
        add(3, "execution", "Browser runbook → script path check", "SCRIPT-RUNBOOK-* with browser_* reference real commands")
        add(4, "awareness", "Web task MCP five-tool path", "query_knowledge + pipeline + runbook + approval + browser reachable or noted")
        add(5, "awareness", "Telegram closure readable", "tersagor message is operator-facing summary of execution")
    elif entity == "Marcus":
        add(1, "execution", "Chroma heartbeat curl", "CHROMA-1 heartbeat OK or failure in closure with fix path")
        add(2, "integration", "ingest-whole-repo.sh path + CHROMA-1 URL", "Script exists; URL matches CHROMA-1-DEFAULT-ENV; fix mismatch only")
        add(3, "execution", "Post-push ingest run or skip reason", "alunel ingest executed or skip documented in closure")
        add(4, "integration", "CHROMA-INSTANCES names vs chroma-instances rule", "Fix naming drift in existing files only")
        add(5, "awareness", "Layer path awareness (knowledge/documents/books)", "No wrong instance used in EOW execution; note in closure if ambiguous")
    elif entity == "Sophia":
        stale = next((s for s in signals if s.category == "cluster_audit_stale"), None)
        n_stale = len(stale.paths) if stale else 0
        add(1, "execution", f"Cluster integration pass ({n_stale} stale audits)", "repo_auto_wave_execute cluster block run; JSON in execution report", "cluster_audit_stale")
        add(2, "pathing", "Run detect-cursor-session-mode.sh", "cursor_session_mode.txt current; host/path warning respected")
        add(3, "pathing", "agent SSH CA path valid", "valid_until future or renew/escalate noted", "ssh_ca")
        add(4, "awareness", "Cluster node registry vs disk", "cluster/*/README count matches glob; gaps logged")
        add(5, "integration", "Prod touch via Abelard path only", "Any prichindel/alunel prod step escalated; not faked DONE")
    elif entity == "Liam":
        add(1, "execution", "Run mcp_config_drift_check; deploy if drift", "deploy-mcp-config-global.sh if drift_detected=1", "mcp_drift")
        add(2, "execution", "Run end_of_week_run.sh execute", "Mechanical wave JSON written")
        add(3, "integration", "SCRIPT-RUNBOOK → script path verify", "Each runbook's commands/paths resolve; tiny runbooks flagged", "runbook_tiny")
        add(4, "execution", "EOW scripts smoke", "collect, research, until-done runnable from repo root")
        add(5, "integration", "workflow_automation_run.sh in canon", "Listed in WORKFLOW-SCRIPT-NAMES and exists on disk")
    elif entity == "Daniel":
        add(1, "pathing", "Review agent_ssh_cert_status.txt", "Future valid_until or renew script path executed/noted", "ssh_ca")
        add(2, "awareness", "Approval gates before destructive", "No EOW DONE on destructive rows; pending approvals respected")
        add(3, "execution", "Compliance row execution log", "CURSOR-REPO-COMPLIANCE row states what ran not what was written")
        add(4, "awareness", "Protected paths check", "olgahere G:, /data/ untouched without approval")
        add(5, "awareness", "Product OPEN rows not faked", "Hesperia/Tailscale/etc. remain OPEN unless really executed", "active_md")
    elif entity == "Noah":
        add(1, "execution", "Chroma/query path alive", "query_knowledge path via MCP setup or chroma heartbeat OK")
        add(2, "integration", "MCP chroma-knowledge wiring", "Template matches repo; deploy if drift", "mcp_drift")
        add(3, "execution", "Post-push Chroma sync", "Ingest on alunel done or skip with reason in closure")
        add(4, "awareness", "fpf_mode context", "Read governance/fpf_mode; books layer noted in closure if fpf_mode=1")
        add(5, "integration", "CHROMA-USAGE-POLICY execution refs", "Ingest/runbook paths in policy match reality; fix links only", "chroma_policy_week")
    elif entity == "Emma":
        add(1, "execution", "deploy-mcp-config-global if drift", "MCP configs synced; restart Cursor noted for operator", "mcp_drift")
        add(2, "execution", "tersagor Telegram at closure", "scripts/tersagor-operator-notify.sh run with N/50 summary")
        add(3, "integration", "Workflow API token path", "9096 contract matches scripts; env path in existing runbook")
        add(4, "integration", "Five MCP servers wired", "Repo template vs .cursor/mcp.json parity; fix not duplicate")
        add(5, "integration", "Mail MCP integration path", "cursor-postfix-mail reachable or documented skip")
    else:
        for i in range(5):
            add(i + 1, "execution", f"{entity}: verify {domain}", "Run or verify one integration concern; fix wiring only")

    assert len(tasks) == 5, f"{entity}: expected 5 tasks, got {len(tasks)}"
    return tasks


def build_register_md(week: str, ww: str, wave_label: str, all_tasks: list[dict], signals: list[Signal]) -> str:
    lines = [
        f"# EOW task register — {week}",
        "",
        f"**Generated**: {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}  ",
        f"**Wave**: {wave_label}  ",
        "**Model**: 5 rows × 10 team entities = **50** (Grace triage → active.md → execute until DONE).  ",
        "**Scope**: **compress, compact, integrate, evolve** using defined contexts — not Palantir, not weekly doc churn.",
        "",
        "## Repo-state signals",
        "",
    ]
    if not signals:
        lines.append("(no notable signals — tasks use role defaults)")
    else:
        for s in signals:
            paths = f" — `{', '.join(s.paths[:5])}'" if s.paths else ""
            lines.append(f"- **{s.category}**: {s.detail}{paths}")
    lines.extend(["", "## Tasks by entity", ""])
    current_owner = ""
    for t in all_tasks:
        if t["owner"] != current_owner:
            current_owner = t["owner"]
            lines.append(f"### {current_owner} ({t['role']})")
            lines.append("")
            lines.append("| ID | Kind | Summary | Acceptance |")
            lines.append("|----|------|---------|------------|")
        lines.append(f"| {t['id']} | {t['kind']} | {t['summary']} | {t['acceptance']} |")
    lines.extend(
        [
            "",
            "## Grace triage",
            "",
            "1. Copy rows into `active.md` (project **cursor-repo**, P1, status OPEN).",
            f"2. Triage packet: `operational/assignments/GRACE-TRIAGE-REPO-EOW-WAVE-{week}.md`",
            "3. Cursor main executes with owner **CSP** per row until **zero OPEN** REPO-EOW rows.",
            "",
            f"SIGNED: Research (Cursor main) | EOW register | {datetime.now(timezone.utc).strftime('%Y-%m-%d')} | {week}",
        ]
    )
    return "\n".join(lines) + "\n"


def build_triage_draft(week: str, ww: str, wave_label: str, all_tasks: list[dict]) -> str:
    lines = [
        f"# Grace triage — REPO-EOW wave ({week})",
        "",
        f"**Date**: {datetime.now(timezone.utc).strftime('%Y-%m-%d')}  ",
        "**Invoker**: EOW cadence — Cursor main research → Grace triage → execute until complete.  ",
        "**Project**: cursor-repo  ",
        f"**Register**: [operational/assignments/reports/EOW-TASK-REGISTER-{week}.md](../reports/EOW-TASK-REGISTER-{week}.md)",
        "",
        "| Entity | IDs | Count |",
        "|--------|-----|-------|",
    ]
    for i, (name, role, _) in enumerate(ENTITIES):
        start = i * 5 + 1
        end = start + 4
        lines.append(f"| {name} | REPO-EOW-{ww}-{start:03d}..{end:03d} | 5 |")
    lines.extend(
        [
            "",
            f"**Total**: 50 tasks. **Execution**: Cursor main orchestrates; mechanical pass via `end_of_week_run.sh execute`; mark DONE only when verified.",
            "",
            "## active.md row template",
            "",
            "```",
            f"| P1 | cursor-repo | REPO-EOW-{ww}-NNN | {{summary}} | {{Owner}} | OPEN | EOW {week} |",
            "```",
            "",
            f"SIGNED: Triage (Grace) | EOW wave | {datetime.now(timezone.utc).strftime('%Y-%m-%d')} | {week}",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> int:
    week = datetime.now(timezone.utc).strftime("%G-W%V")
    ww = week.split("-", 1)[1].lstrip("W")  # week number without W prefix for IDs
    if not ww.isdigit():
        ww = week.replace("-", "")
    wave_label = f"REPO-EOW {week}"

    signals = collect_signals(week, wave_label)
    all_tasks: list[dict] = []
    seq = 1
    for name, role, domain in ENTITIES:
        block = tasks_for_entity(name, role, domain, seq, week, ww, signals)
        all_tasks.extend(block)
        seq += 5

    reports = REPO / "operational/assignments/reports"
    reports.mkdir(parents=True, exist_ok=True)
    json_path = reports / f"EOW-RESEARCH-{week}.json"
    reg_path = reports / f"EOW-TASK-REGISTER-{week}.md"
    triage_path = REPO / "operational/assignments" / f"GRACE-TRIAGE-REPO-EOW-WAVE-{week}.md"

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "week": week,
        "wave_label": wave_label,
        "task_count": len(all_tasks),
        "model": "5x10 execution/integration rows",
        "scope": "execution|integration|pathing|awareness",
        "signals": [{"category": s.category, "detail": s.detail, "paths": s.paths} for s in signals],
        "tasks": all_tasks,
    }
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    reg_path.write_text(build_register_md(week, ww, wave_label, all_tasks, signals), encoding="utf-8")
    triage_path.write_text(build_triage_draft(week, ww, wave_label, all_tasks), encoding="utf-8")

    print(f"week={week} tasks={len(all_tasks)} signals={len(signals)}")
    print(f"json={json_path}")
    print(f"register={reg_path}")
    print(f"triage_draft={triage_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
