#!/usr/bin/env bash
# Chroma mandatory path check before workflow automation (same store as MCP query_knowledge).
# Structured JSON on stderr; optional CHROMA_PREFLIGHT_LOG appends same lines.
# Team automation: WORKFLOW_QUIET=1 sends JSON to CHROMA_PREFLIGHT_LOG only (not terminal stderr).
# Escape hatch: CHROMA_SKIP_PREFLIGHT=1 (emergency only).
#
# **CHROMA-1** (alunel): team/repo Chroma. Preflight hits alunel or LAN :8002 — not prichindel chroma-new (retired).
# Ref: governance/CHROMA-1-DEFAULT-ENV.md

set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
export REPO_ROOT

if [[ "${CHROMA_SKIP_PREFLIGHT:-}" == "1" ]]; then
  if [[ "${WORKFLOW_QUIET:-}" == "1" ]]; then
    [[ -n "${CHROMA_PREFLIGHT_LOG:-}" ]] && echo '{"chroma_preflight":"skipped","reason":"CHROMA_SKIP_PREFLIGHT=1"}' >>"${CHROMA_PREFLIGHT_LOG}"
  else
    echo '{"chroma_preflight":"skipped","reason":"CHROMA_SKIP_PREFLIGHT=1"}' >&2
  fi
  exit 0
fi

PY_SCRIPT="${REPO_ROOT}/scripts/chroma_preflight.py"
LOCAL_PYTHON="${CHROMA_PYTHON:-/data/chroma/venv/bin/python3}"
# python-dotenv warnings can come from worker subprocesses (embeddings) — filter here too.
DOTENV_NOISE='python-dotenv could not parse'

_chroma_filter_dotenv_lines() {
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ "$line" == *"$DOTENV_NOISE"* ]] && continue
    printf '%s\n' "$line"
  done
}
# Brain repo on CHROMA-1 host (alunel).
REMOTE_REPO="${CHROMA_PREFLIGHT_REMOTE_REPO:-/data/workspaces/cursor}"
REMOTE_REPO_FALLBACK="${CHROMA_PREFLIGHT_REMOTE_REPO_FALLBACK:-/data/altitudine/prichindel.com}"
SSH_HOST="${CHROMA_PREFLIGHT_SSH_HOST:-alunel}"
REMOTE_PYTHON="${CHROMA_PREFLIGHT_REMOTE_PYTHON:-/data/chroma/venv/bin/python3}"
CHROMA_1_LAN_URL="${CHROMA_1_LAN_URL:-http://chroma-1.prichindel.local:8002}"
LOG_TARGET="${CHROMA_PREFLIGHT_LOG:-}"

_chroma1_local_url() {
  if [[ "$(hostname -s 2>/dev/null)" == "alunel" ]]; then
    echo "http://127.0.0.1:8002"
  else
    echo "$CHROMA_1_LAN_URL"
  fi
}

run_local() {
  export PYTHONPATH="${REPO_ROOT}${PYTHONPATH:+:$PYTHONPATH}"
  export CHROMA_SERVER_URL="${CHROMA_SERVER_URL:-$(_chroma1_local_url)}"
  set -o pipefail
  set +e
  if [[ "${WORKFLOW_QUIET:-}" == "1" ]]; then
    if [[ -n "$LOG_TARGET" ]]; then
      "$LOCAL_PYTHON" "$PY_SCRIPT" 2>&1 | _chroma_filter_dotenv_lines | tee -a "$LOG_TARGET" >/dev/null
    else
      "$LOCAL_PYTHON" "$PY_SCRIPT" 2>&1 | _chroma_filter_dotenv_lines >/dev/null
    fi
  elif [[ -n "$LOG_TARGET" ]]; then
    "$LOCAL_PYTHON" "$PY_SCRIPT" 2>&1 | _chroma_filter_dotenv_lines | tee -a "$LOG_TARGET" >&2
  else
    "$LOCAL_PYTHON" "$PY_SCRIPT" 2>&1 | _chroma_filter_dotenv_lines >&2
  fi
  rc="${PIPESTATUS[0]}"
  set -e
  set +o pipefail
  return "$rc"
}

resolve_remote_repo() {
  if ssh -o BatchMode=yes -o ConnectTimeout=10 "$SSH_HOST" "test -f $REMOTE_REPO/scripts/chroma_preflight.py && test -x $REMOTE_PYTHON" 2>/dev/null; then
    echo "$REMOTE_REPO"
    return 0
  fi
  if ssh -o BatchMode=yes -o ConnectTimeout=10 "$SSH_HOST" "test -f $REMOTE_REPO_FALLBACK/scripts/chroma_preflight.py && test -x $REMOTE_PYTHON" 2>/dev/null; then
    echo "$REMOTE_REPO_FALLBACK"
    return 0
  fi
  return 1
}

run_remote() {
  # Server-side Chroma is localhost-only; force URL for remote run.
  local remote_cmd remote_repo
  remote_repo="$(resolve_remote_repo)"
  remote_cmd=$(printf "cd %q && export REPO_ROOT=%q PYTHONPATH=%q CHROMA_SERVER_URL=http://127.0.0.1:8002 && exec %q %q" \
    "$remote_repo" "$remote_repo" "$remote_repo" "$REMOTE_PYTHON" "$remote_repo/scripts/chroma_preflight.py")
  set -o pipefail
  set +e
  if [[ "${WORKFLOW_QUIET:-}" == "1" ]]; then
    if [[ -n "$LOG_TARGET" ]]; then
      ssh -o BatchMode=yes -o ConnectTimeout=10 "$SSH_HOST" bash -lc "$remote_cmd" 2>&1 | _chroma_filter_dotenv_lines | tee -a "$LOG_TARGET" >/dev/null
    else
      ssh -o BatchMode=yes -o ConnectTimeout=10 "$SSH_HOST" bash -lc "$remote_cmd" 2>&1 | _chroma_filter_dotenv_lines >/dev/null
    fi
  elif [[ -n "$LOG_TARGET" ]]; then
    ssh -o BatchMode=yes -o ConnectTimeout=10 "$SSH_HOST" bash -lc "$remote_cmd" 2>&1 | _chroma_filter_dotenv_lines | tee -a "$LOG_TARGET" >&2
  else
    ssh -o BatchMode=yes -o ConnectTimeout=10 "$SSH_HOST" bash -lc "$remote_cmd" 2>&1 | _chroma_filter_dotenv_lines >&2
  fi
  rc="${PIPESTATUS[0]}"
  set -e
  set +o pipefail
  return "$rc"
}

if [[ -x "$LOCAL_PYTHON" ]]; then
  run_local
  exit $?
fi

if command -v ssh >/dev/null 2>&1 && resolve_remote_repo >/dev/null 2>&1; then
  run_remote
  exit $?
fi

echo '{"event":"chroma_preflight","ok":false,"error":"no_runner","message":"No executable '"$LOCAL_PYTHON"' and SSH '"$SSH_HOST"' preflight failed (install venv on this host or fix ssh + '"$REMOTE_REPO"')"}' >&2
exit 1
