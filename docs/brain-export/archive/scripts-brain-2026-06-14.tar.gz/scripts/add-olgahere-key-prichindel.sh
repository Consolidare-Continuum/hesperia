#!/bin/bash
# Run on prichindel as igareosh. Appends olgahere's key to ~/.ssh/authorized_keys.
# Safe: append only; owner stays igareosh. See cluster/olgahere/README.md
set -e
KEYLINE="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK379JFLA8h3h/Qvf/WkLVMd1eMH/5uD3SutcrkjkyRl olgahere@prichindel"
AUTH="$HOME/.ssh/authorized_keys"
if grep -q "olgahere@prichindel" "$AUTH" 2>/dev/null; then
  echo "olgahere key already in authorized_keys"
  exit 0
fi
chmod 700 "$HOME/.ssh" 2>/dev/null || true
chmod 600 "$AUTH" 2>/dev/null || true
echo "$KEYLINE" >> "$AUTH"
echo "Appended olgahere key. Verify: tail -1 $AUTH"
tail -1 "$AUTH"
