#!/usr/bin/env bash
# Apply Supermicro WPCM450 / X8DT3-F fan policy toward ~1500 RPM (BMC-owned fans).
# Safe in-band path: IPMICFG -fan (download from Supermicro) or BMC web UI at 192.168.100.115.
# ipmitool raw 0x30 0x45 / 0x91 often return 0xc1 until Full + duty set in web UI (FAQ 15634).
# DO NOT run ipmitool raw 0x30 0x70 0x0c (LAN mode) — can wedge BMC (0xd5) until mc reset cold.
set -euo pipefail

IPMICFG="${IPMICFG:-}"
for c in ./IPMICFG-Linux.x86_64 /data/workspaces/cursor/IPMICFG-Linux.x86_64 /usr/local/bin/IPMICFG-Linux.x86_64; do
  [[ -x "$c" ]] && IPMICFG="$c" && break
done

log() { printf '%s\n' "$*"; }

if [[ ! -e /dev/ipmi0 ]]; then
  sudo modprobe ipmi_msghandler ipmi_devintf ipmi_si 2>/dev/null || true
  sleep 2
fi

if ! sudo ipmitool mc info &>/dev/null; then
  log "BLOCKED: /dev/ipmi0 or BMC not responding. Try: sudo ipmitool mc reset cold; sleep 45; sudo modprobe ipmi_si"
  exit 1
fi

log "=== BMC ==="
sudo ipmitool mc info 2>/dev/null | grep -E 'Firmware|Manufacturer|Product' || true

log "=== Fans (before) ==="
sudo ipmitool sdr elist 2>/dev/null | grep -iE '^Fan[0-9]' || true

if [[ -n "$IPMICFG" ]]; then
  log "=== IPMICFG -fan (read) ==="
  sudo "$IPMICFG" -fan 2>&1 || true
  log "=== IPMICFG -fan 2 (Optimal) ==="
  sudo "$IPMICFG" -fan 2 2>&1 || true
  sleep 5
else
  log "NOTE: IPMICFG not found. Set IPMICFG=/path/to/IPMICFG-Linux.x86_64 or install from Supermicro download center."
  for raw in "0x30 0x45 0x01 0x01" "0x30 0x91 0x5A 0x03 0x10 0x7f" "0x30 0x91 0x5A 0x03 0x11 0x7f"; do
    out=$(sudo ipmitool raw $raw 2>&1) || true
    log "raw $raw -> ${out%%$'\n'*}"
  done
fi

log "=== Fans (after) ==="
sudo ipmitool sdr elist 2>/dev/null | grep -iE '^Fan[3-8]' || true

rpm=$(sudo ipmitool sdr elist 2>/dev/null | awk '/^Fan[3-8]/ {print $NF}' | head -1 | grep -oE '[0-9]+' || true)
if [[ -n "${rpm:-}" ]] && [[ "$rpm" -le 1800 ]]; then
  log "DONE. Chassis fans at or below ~1800 RPM."
  exit 0
fi

log "BLOCKED: Fans still high (~3000 RPM). This BMC (Nedam ENG fw 3.03) rejects OEM raw 0x45/0x91 in-band."
log "  1) Cable dedicated IPMI port to LAN; open https://192.168.100.115/ -> Fan Speed -> Full -> ~50% duty -> Save"
log "  2) Or copy IPMICFG-Linux.x86_64 to host and re-run: IPMICFG=/path $0"
exit 2
