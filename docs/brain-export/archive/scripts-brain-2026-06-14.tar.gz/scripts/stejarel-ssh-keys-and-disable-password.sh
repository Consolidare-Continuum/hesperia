#!/usr/bin/env bash
# Run on prichindel as igareosh. Requires: stejarel sshd up, password auth still on.
#
# Usage:
#   ./stejarel-ssh-keys-and-disable-password.sh [HOST_OR_IP]           # full hardening (needs operator ack; see WORKFLOW-NOTES)
#   ./stejarel-ssh-keys-and-disable-password.sh [HOST_OR_IP] keys-only # install prichindel pubkeys only; leaves PasswordAuthentication as-is
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CRED="$REPO_ROOT/cluster/host-credentials/stejarel.txt"
test -r "$CRED" || { echo "Missing $CRED"; exit 1; }
PASS="$(grep '^PASSWORD=' "$CRED" | cut -d= -f2-)"
test -n "$PASS" || { echo "No PASSWORD= in stejarel.txt"; exit 1; }
PWFILE="$(mktemp)"
KEYS_TMP="$(mktemp)"
trap 'rm -f "$PWFILE" "$KEYS_TMP"' EXIT
printf '%s' "$PASS" >"$PWFILE"
chmod 600 "$PWFILE"
KEYS_ONLY=0
if [[ "${2:-}" == keys-only ]] || [[ "${1:-}" == keys-only ]]; then
  KEYS_ONLY=1
  if [[ "${1:-}" == keys-only ]]; then
    TARGET="${2:-stejarel.local}"
  else
    TARGET="${1:-stejarel.local}"
  fi
else
  TARGET="${1:-stejarel.local}"
fi
# Optional override in cred file when still on default hostname (CLI IP/hostname wins).
if [[ "$TARGET" == stejarel.local ]] && grep -q '^TARGET=' "$CRED" 2>/dev/null; then
  T_OVERRIDE="$(grep '^TARGET=' "$CRED" | cut -d= -f2-)"
  if [[ -n "${T_OVERRIDE// /}" ]]; then
    TARGET="$T_OVERRIDE"
  fi
fi
{
  printf '%s\n' '# igareosh — prichindel id_rsa (cluster)'
  cat /home/igareosh/.ssh/id_rsa.pub
  printf '%s\n' '# igareosh — ed25519 (github_key)'
  cat /home/igareosh/.ssh/github_key.pub
} >"$KEYS_TMP"
sshpass -f "$PWFILE" ssh -o StrictHostKeyChecking=accept-new "igareosh@$TARGET" 'umask 077; mkdir -p ~/.ssh; chmod 700 ~/.ssh'
sshpass -f "$PWFILE" scp -o StrictHostKeyChecking=accept-new "$KEYS_TMP" "igareosh@$TARGET:.ssh/authorized_keys"
sshpass -f "$PWFILE" ssh "igareosh@$TARGET" 'chmod 600 ~/.ssh/authorized_keys; wc -l ~/.ssh/authorized_keys'
ssh -o BatchMode=yes -o PasswordAuthentication=no -o PreferredAuthentications=publickey "igareosh@$TARGET" 'echo key-auth-ok; hostname'
if [[ "$KEYS_ONLY" -eq 1 ]]; then
  echo "keys-only: skipping PasswordAuthentication no (password login still allowed)."
  exit 0
fi
{
  printf '%s\n' "$PASS"
  cat <<'SUDO'
set -euo pipefail
f=/etc/ssh/sshd_config.d/99-disable-password-auth.conf
printf '%s\n' \
  '# Managed by scripts/stejarel-ssh-keys-and-disable-password.sh on prichindel' \
  'PasswordAuthentication no' \
  'KbdInteractiveAuthentication no' \
  'PubkeyAuthentication yes' > "$f"
chmod 644 "$f"
sshd -t
systemctl restart ssh
echo sshd-restarted
SUDO
} | ssh -T -o BatchMode=yes -o PasswordAuthentication=no "igareosh@$TARGET" 'sudo -S bash -s'
if sshpass -f "$PWFILE" ssh -o PreferredAuthentications=password -o PubkeyAuthentication=no -o ConnectTimeout=5 "igareosh@$TARGET" 'exit 0' 2>/dev/null; then
  echo "FAILED: password auth still accepted"
  exit 1
fi
ssh -o BatchMode=yes -o PasswordAuthentication=no "igareosh@$TARGET" 'echo final-ok; hostname'
