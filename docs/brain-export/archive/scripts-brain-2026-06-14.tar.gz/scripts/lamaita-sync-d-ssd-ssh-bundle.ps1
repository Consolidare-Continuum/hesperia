# Sync igareosh@lamaita (Bitvise session) cluster SSH identity to portable D:\ssd.
# Run ON LAMAITA as the Bitvise user (igareosh). Abelard: invoke via ssh from prichindel.
$ErrorActionPreference = "Stop"
$src = "C:\Users\BvSsh_lamaita\.ssh"
$dst = "D:\ssd"
if (-not (Test-Path $dst)) {
    throw "D:\ssd not found; insert or mount the flash drive."
}
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$bak = Join-Path $dst "_backup_$ts"
New-Item -ItemType Directory -Force -Path $bak | Out-Null
foreach ($f in @("config", "id_rsa", "id_rsa.pub", "known_hosts", "github_key", "git_rsa")) {
    $p = Join-Path $dst $f
    if (Test-Path $p) {
        Copy-Item $p $bak -Force
    }
}
Copy-Item (Join-Path $src "id_rsa") (Join-Path $dst "id_rsa") -Force
Copy-Item (Join-Path $src "known_hosts") (Join-Path $dst "known_hosts") -Force

# Regenerate .pub from a temp copy with NTFS ACLs (FAT/exFAT USB cannot restrict the on-drive key).
$sshgen = "$env:WINDIR\System32\OpenSSH\ssh-keygen.exe"
$tmpGen = Join-Path $env:TEMP "lamaita-ssd-keygen-$ts"
New-Item -ItemType Directory -Force -Path $tmpGen | Out-Null
try {
    Copy-Item (Join-Path $dst "id_rsa") (Join-Path $tmpGen "id_rsa") -Force
    $tg = Join-Path $tmpGen "id_rsa"
    icacls $tg /inheritance:r 2>$null | Out-Null
    icacls $tg /grant:r "$($env:USERNAME):(R)" 2>$null | Out-Null
    if (Test-Path $sshgen) {
        & $sshgen -y -f $tg | Set-Content -Path (Join-Path $dst "id_rsa.pub") -Encoding ASCII
    }
} finally {
    Remove-Item -Recurse -Force $tmpGen -ErrorAction SilentlyContinue
}

# Best-effort ACL on the USB copy (works on NTFS only).
$keyPath = Join-Path $dst "id_rsa"
icacls $keyPath /inheritance:r 2>$null | Out-Null
icacls $keyPath /grant:r "$($env:USERNAME):(R)" 2>$null | Out-Null

$cfg = @"
# Portable bundle on D:\ssd - cluster LAN. Order: prichindel, alunel, stejarel, izvoras, guests, fulgusor.

Host prichindel dc
  HostName 192.168.100.21
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  AddressFamily inet
  ConnectTimeout 15
  ServerAliveInterval 30
  ServerAliveCountMax 4
  StrictHostKeyChecking accept-new

Host alunel
  HostName alunel.prichindel.local
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  ServerAliveInterval 60
  ConnectTimeout 15

Host stejarel
  HostName stejarel.prichindel.local
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  ServerAliveInterval 60
  ConnectTimeout 15

Host izvoras
  HostName izvoras.prichindel.local
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  ConnectTimeout 15

Host altitudine
  HostName altitudine.prichindel.local
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  ConnectTimeout 15

Host chronomaster
  HostName chronomaster.prichindel.local
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  ConnectTimeout 15

Host mediamaster
  HostName mediamaster.prichindel.local
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  ConnectTimeout 15

Host fulgusor
  HostName fulgusor.prichindel.local
  User igareosh
  IdentityFile D:/ssd/id_rsa
  IdentitiesOnly yes
  ConnectTimeout 20
"@
Set-Content -Path (Join-Path $dst "config") -Value $cfg -Encoding UTF8

$launcher = @'
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$SshArgs
)
$ErrorActionPreference = "Stop"
$ssdRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$keySrc = Join-Path $ssdRoot "id_rsa"
$knSrc = Join-Path $ssdRoot "known_hosts"
$cfgSrc = Join-Path $ssdRoot "config"
if (-not (Test-Path $keySrc)) { throw "Missing id_rsa on flash drive." }
$tmp = Join-Path $env:TEMP ("lamaita-ssd-ssh-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
try {
    Copy-Item $keySrc (Join-Path $tmp "id_rsa") -Force
    if (Test-Path $knSrc) {
        Copy-Item $knSrc (Join-Path $tmp "known_hosts") -Force
    }
    $k = Join-Path $tmp "id_rsa"
    icacls $k /inheritance:r 2>$null | Out-Null
    icacls $k /grant:r "$($env:USERNAME):(R)" 2>$null | Out-Null
    $tmpSlash = $tmp -replace "\\", "/"
    $raw = Get-Content $cfgSrc -Raw -Encoding UTF8
    $raw = $raw -replace [regex]::Escape("D:/ssd"), $tmpSlash
    $cfgOut = Join-Path $tmp "config"
    Set-Content -Path $cfgOut -Value $raw -Encoding UTF8
    $ssh = "$env:WINDIR\System32\OpenSSH\ssh.exe"
    if (-not (Test-Path $ssh)) { $ssh = "ssh" }
    & $ssh -o BatchMode=yes -F $cfgOut @SshArgs
} finally {
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
}
'@
Set-Content -Path (Join-Path $dst "lamaita-ssh-from-ssd.ps1") -Value $launcher -Encoding UTF8

$readme = @"
LAMAITA SSH bundle (igareosh) - synced by Abelard.
Files: id_rsa, id_rsa.pub, known_hosts, config, lamaita-ssh-from-ssd.ps1

If D: is NTFS: ssh -F D:/ssd/config prichindel hostname
If D: is FAT/exFAT: powershell -ExecutionPolicy Bypass -File D:/ssd/lamaita-ssh-from-ssd.ps1 prichindel hostname

Off-LAN: add Host prichindel-remote from cluster/ceres; see cluster/lamaita/README.md.
"@
Set-Content -Path (Join-Path $dst "README-lamaita-SSH.txt") -Value $readme -Encoding UTF8
Get-ChildItem $dst -Force | Select-Object Name, Length, LastWriteTime | Format-Table -AutoSize
