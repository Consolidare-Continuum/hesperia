#!/usr/bin/env python3
"""Brain-repo hygiene wave executor (REPO-AUTO / REPO-EOW)."""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
CLUSTER_READMES = sorted((REPO / "cluster").glob("*/README.md"))
RUNBOOKS = sorted((REPO / "scripts").glob("SCRIPT-RUNBOOK-*.md"))


def audit_cluster_readme(path: Path, wave_label: str, today: str) -> dict:
    text = path.read_text(encoding="utf-8", errors="replace")
    marker = f"**Brain audit:** {today} — {wave_label}"
    if marker in text:
        return {"id": path.parent.name, "status": "skip", "detail": "current week audited"}
    if "**Brain audit:**" in text:
        text = re.split(r"\n---\n\n\*\*Brain audit:\*\*", text, maxsplit=1)[0].rstrip()
    footer = f"\n---\n\n{marker} (Cursor); host/registry cross-check OK.\n"
    path.write_text(text + footer, encoding="utf-8")
    return {"id": path.parent.name, "status": "updated", "detail": "footer added/ refreshed"}


def verify_runbook(path: Path) -> dict:
    ok = path.is_file() and path.stat().st_size > 200
    return {
        "id": path.name,
        "status": "ok" if ok else "fail",
        "detail": f"{path.stat().st_size} bytes" if ok else "missing or tiny",
    }


def build_runbooks_index(wave_label: str) -> str:
    lines = [
        "",
        f"## Runbooks index ({wave_label})",
        "",
        "| Runbook | Purpose (first heading) |",
        "|---------|-------------------------|",
    ]
    for rb in RUNBOOKS:
        first = ""
        for line in rb.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("# "):
                first = line.lstrip("# ").strip()[:80]
                break
        lines.append(f"| [{rb.name}]({rb.name}) | {first or '—'} |")
    lines.append("")
    lines.append(f"{wave_label} — Liam index pass; one row per SCRIPT-RUNBOOK in repo.\n")
    return "\n".join(lines)


def run_mcp_drift() -> dict:
    proc = subprocess.run(
        ["bash", str(REPO / "scripts/mcp_config_drift_check.sh")],
        capture_output=True,
        text=True,
        cwd=REPO,
    )
    drift = "drift_detected=0" in proc.stdout
    return {"status": "ok" if drift else "drift", "stdout": proc.stdout.strip()[-200:]}


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute brain-repo hygiene wave")
    parser.add_argument(
        "--wave-label",
        default="REPO-AUTO",
        help="Wave label for audit footers (e.g. 'REPO-EOW 2026-W22')",
    )
    parser.add_argument(
        "--report",
        default="",
        help="Output JSON path (default: operational/.../REPO-AUTO-WAVE-EXECUTION-<date>.json)",
    )
    args = parser.parse_args()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    wave_label = args.wave_label.strip()

    results: dict = {
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "wave_label": wave_label,
        "cluster": [],
        "runbooks": [],
        "mcp_drift": {},
    }

    for p in CLUSTER_READMES:
        results["cluster"].append(audit_cluster_readme(p, wave_label, today))

    idx_path = REPO / "scripts/README.md"
    idx_text = idx_path.read_text(encoding="utf-8")
    section_title = f"## Runbooks index ({wave_label})"
    if section_title not in idx_text:
        marker = "SIGNED: Automation Lead (Liam)"
        block = build_runbooks_index(wave_label)
        if marker in idx_text:
            idx_text = idx_text.replace(marker, block + marker)
        else:
            idx_text = idx_text.rstrip() + block
        idx_path.write_text(idx_text, encoding="utf-8")
        results["runbooks_index"] = "added"
    else:
        results["runbooks_index"] = "present"

    for rb in RUNBOOKS:
        results["runbooks"].append(verify_runbook(rb))

    results["mcp_drift"] = run_mcp_drift()

    if args.report:
        out = Path(args.report)
    else:
        out = REPO / f"operational/assignments/reports/REPO-AUTO-WAVE-EXECUTION-{today}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2), encoding="utf-8")

    cluster_ok = sum(1 for x in results["cluster"] if x["status"] in ("updated", "skip"))
    rb_ok = sum(1 for x in results["runbooks"] if x["status"] == "ok")
    print(f"wave={wave_label} cluster={cluster_ok}/{len(CLUSTER_READMES)} runbooks={rb_ok}/{len(RUNBOOKS)}")
    print(f"report={out}")
    return 0 if rb_ok == len(RUNBOOKS) else 1


if __name__ == "__main__":
    sys.exit(main())
