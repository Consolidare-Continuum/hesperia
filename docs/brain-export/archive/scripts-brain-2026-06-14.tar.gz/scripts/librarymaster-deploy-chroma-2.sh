#!/usr/bin/env bash
# Deploy CHROMA-2 on librarymaster (Papra library only). Run ON librarymaster or: ssh librarymaster 'bash -s' < scripts/librarymaster-deploy-chroma-2.sh
set -euo pipefail
REPO="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO"

CHROMA2_ROOT=/data/chroma-2
LEGACY=/data/chroma-alunel
IMAGE='ghcr.io/chroma-core/chroma@sha256:607103123fbd79794e3cd8029e16137031a464551e3a61df77191627a9d23c72'

echo "=== librarymaster CHROMA-2 deploy ==="

if [[ "$(hostname -s)" != "librarymaster" ]]; then
  echo "WARN: expected hostname librarymaster, got $(hostname -s)" >&2
fi

# --- Migrate legacy chroma-alunel → chroma-2 (once) ---
sudo mkdir -p "${CHROMA2_ROOT}/archive"
if [[ -d "${LEGACY}/data" && ! -d "${CHROMA2_ROOT}/data" ]]; then
  echo "Migrating ${LEGACY}/data → ${CHROMA2_ROOT}/data"
  sudo mv "${LEGACY}/data" "${CHROMA2_ROOT}/data"
fi
if [[ -d "${LEGACY}/venv" && ! -d "${CHROMA2_ROOT}/venv" ]]; then
  echo "Migrating ${LEGACY}/venv → ${CHROMA2_ROOT}/venv"
  sudo mv "${LEGACY}/venv" "${CHROMA2_ROOT}/venv"
fi
for bak in "${LEGACY}"/data.bak.*; do
  [[ -e "$bak" ]] || continue
  echo "Archiving $bak"
  sudo mv "$bak" "${CHROMA2_ROOT}/archive/" 2>/dev/null || true
done
if [[ -d "${LEGACY}" && ! -f "${LEGACY}/DEPRECATED.md" ]]; then
  sudo tee "${LEGACY}/DEPRECATED.md" >/dev/null <<EOF
# DEPRECATED — do not use on librarymaster

CHROMA-2 moved to **/data/chroma-2/** (2026-06-14).

Ref: cluster/librarymaster/STORAGE-LAYOUT.md
EOF
fi

sudo mkdir -p "${CHROMA2_ROOT}/data"
sudo chown -R root:root "${CHROMA2_ROOT}/data"

# --- Brain repo path: workspaces/cursor only on this host ---
if [[ -d /data/altitudine/prichindel.com && ! -e /data/workspaces/cursor ]]; then
  echo "Moving brain clone /data/altitudine/prichindel.com → /data/workspaces/cursor"
  sudo mkdir -p /data/workspaces
  sudo mv /data/altitudine/prichindel.com /data/workspaces/cursor
  sudo tee /data/altitudine/DEPRECATED.md >/dev/null <<EOF
# DEPRECATED path on librarymaster

Brain repo ops clone: **/data/workspaces/cursor**

This host is **librarymaster** (Papra/CHROMA-2 only), not altitudine dev VM.

Ref: governance/HOST-ALTITUDINE-VS-LIBRARYMASTER.md
EOF
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "Installing docker.io..."
  sudo apt-get update -qq
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y docker.io
  sudo systemctl enable --now docker
fi

if [[ ! -x "${CHROMA2_ROOT}/venv/bin/python3" ]]; then
  echo "Creating ${CHROMA2_ROOT}/venv"
  sudo python3 -m venv "${CHROMA2_ROOT}/venv"
  sudo "${CHROMA2_ROOT}/venv/bin/pip" install -U pip
  sudo "${CHROMA2_ROOT}/venv/bin/pip" install "chromadb>=1.5,<2" sentence-transformers httpx
fi

sudo cp "$REPO/cluster/librarymaster/chroma/chroma-2-docker.service" /etc/systemd/system/
sudo cp "$REPO/cluster/librarymaster/chroma/chroma-2-metrics.service" /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable chroma-2-docker chroma-2-metrics

if [[ "${1:-}" == "--restart" ]]; then
  echo "Preflight before restart..."
  CHROMA2_DATA_DIR="${CHROMA2_ROOT}/data" bash "$REPO/scripts/verify-chroma2-persist.sh"
  sudo systemctl restart chroma-2-docker
  sleep 4
  curl -sf http://127.0.0.1:8002/api/v2/heartbeat
  echo ""
  curl -sf http://192.168.100.66:8002/api/v2/heartbeat
  echo ""
  sudo systemctl restart chroma-2-metrics || true
else
  echo "Units installed. Restart skipped (use --restart after backup + approval)."
fi

echo "OK: CHROMA-2 layout ${CHROMA2_ROOT} image pinned"
