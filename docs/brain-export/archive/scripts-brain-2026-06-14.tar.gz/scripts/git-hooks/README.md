# Git hooks (brain repo guardrails)

**pre-commit** — rejects commits that **add** new files whose path is a single segment (repo root) and basename is **not** listed in [allowed-root-files.txt](allowed-root-files.txt). Assignment-driven deliverables belong under `operational/assignments/` or `operational/partners/`. Ref: [REPO-SELF-SERVICE.md](../../REPO-SELF-SERVICE.md) section 3.

**Install** (from repo root):

```bash
ln -sf ../../scripts/git-hooks/pre-commit .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

To add a canonical root file (rare), edit `allowed-root-files.txt` with team agreement.
