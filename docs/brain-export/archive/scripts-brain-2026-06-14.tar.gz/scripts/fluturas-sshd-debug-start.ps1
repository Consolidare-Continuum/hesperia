# Run sshd in debug mode to see why it fails. Run as Administrator.
# Output goes to console; run from elevated PowerShell to see it.
$sshdExe = $null
foreach ($p in @("$env:ProgramFiles\OpenSSH\sshd.exe", "$env:SystemRoot\System32\OpenSSH\sshd.exe")) {
    if (Test-Path $p) { $sshdExe = $p; break }
}
if (-not $sshdExe) { Write-Host "sshd.exe not found"; exit 1 }
$outFile = "$env:USERPROFILE\fluturas-sshd-debug.log"
Write-Host "Running $sshdExe -d -e (output to $outFile and console). Press Ctrl+C to stop."
& $sshdExe -d -e 2>&1 | Tee-Object -FilePath $outFile
