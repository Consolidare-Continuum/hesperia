# One-time: add prichindel's public key to olgahere so cluster can SSH in.
# Run on olgahere. For user Olga (Administrator): Windows OpenSSH Server uses
# C:\ProgramData\ssh\administrators_authorized_keys for admin users, NOT
# %USERPROFILE%\.ssh\authorized_keys. This script writes to BOTH so it works.
# Run as Administrator to update ProgramData (required for inbound SSH).
# Usage: .\add-prichindel-key-olgahere.ps1 [path-to-prichindel.pub]

param([string]$KeyFile)

$ErrorActionPreference = 'Stop'

$keyLine = if ($KeyFile -and (Test-Path -LiteralPath $KeyFile)) {
    Get-Content -LiteralPath $KeyFile -Raw
} else {
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $defaultPath = Join-Path $scriptDir "..\cluster\olgahere\prichindel.pub"
    if (Test-Path -LiteralPath $defaultPath) {
        Get-Content -LiteralPath $defaultPath -Raw
    } else {
        Write-Error "No key file. Pass path to prichindel.pub or run from repo with cluster/olgahere/prichindel.pub."
        exit 1
    }
}
$keyLine = $keyLine.Trim()
if (-not $keyLine.StartsWith("ssh-")) {
    Write-Error "Invalid key line."
    exit 1
}

function Add-KeyToFile {
    param([string]$Path, [string]$Key, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $dir = Split-Path -Parent $Path
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Set-Content -LiteralPath $Path -Value $Key -Encoding UTF8
        Write-Host "Created $Label and added prichindel key."
    } else {
        $existing = Get-Content -LiteralPath $Path -Raw -ErrorAction SilentlyContinue
        if ($existing -and $existing.IndexOf("prichindel", [StringComparison]::OrdinalIgnoreCase) -ge 0) {
            Write-Host "Prichindel key already in $Label."
        } else {
            Add-Content -LiteralPath $Path -Value $Key
            Write-Host "Appended prichindel key to $Label."
        }
    }
}

# 1. User authorized_keys (for non-admin or fallback)
$sshDir = Join-Path $env:USERPROFILE ".ssh"
$authKeys = Join-Path $sshDir "authorized_keys"
if (-not (Test-Path -LiteralPath $sshDir)) { New-Item -ItemType Directory -Path $sshDir -Force | Out-Null }
Add-KeyToFile -Path $authKeys -Key $keyLine -Label "authorized_keys (user)"

# 2. administrators_authorized_keys (REQUIRED for admin user on Windows OpenSSH)
$programDataSsh = Join-Path $env:ProgramData "ssh"
$adminKeys = Join-Path $programDataSsh "administrators_authorized_keys"
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($isAdmin) {
    if (-not (Test-Path -LiteralPath $programDataSsh)) { New-Item -ItemType Directory -Path $programDataSsh -Force | Out-Null }
    Add-KeyToFile -Path $adminKeys -Key $keyLine -Label "administrators_authorized_keys"
    # ACL: only SYSTEM and Administrators (required by Windows OpenSSH; else key auth can fail)
    icacls.exe $adminKeys /inheritance:r /grant "Administrators:F" /grant "SYSTEM:F" 2>$null
    if ($LASTEXITCODE -eq 0) { Write-Host "ACL set on administrators_authorized_keys (Administrators + SYSTEM only)." }
} else {
    Write-Warning "Not running as Administrator. User authorized_keys updated, but for Olga (Administrator) inbound SSH you must add the key to administrators_authorized_keys."
    Write-Host "Run in an elevated PowerShell:"
    Write-Host "  powershell -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`""
}

Write-Host "Done. From prichindel: ssh olgahere (or ssh Olga@192.168.100.5)"
