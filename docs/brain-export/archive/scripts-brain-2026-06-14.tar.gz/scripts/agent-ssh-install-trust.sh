#!/usr/bin/env bash
# Install agent CA trust + NOPASSWD sudo on a single Linux VM.
# Run on the target host as root (or via sudo).
# Usage: sudo bash agent-ssh-install-trust.sh <path-to-agent_ca.pub>
# Called by agent-ssh-deploy-trust.sh for cluster-wide rollout.
set -euo pipefail

CA_PUB="${1:-}"
if [ -z "$CA_PUB" ] || [ ! -f "$CA_PUB" ]; then
    echo "Usage: $0 <agent_ca.pub>" >&2
    echo "ERROR: File not found or not specified: $CA_PUB" >&2
    exit 1
fi

# Install CA pubkey
install -m 644 "$CA_PUB" /etc/ssh/agent_ca.pub
echo "Installed: /etc/ssh/agent_ca.pub"

# Patch sshd_config — idempotent
SSHD_CONF="/etc/ssh/sshd_config"
if grep -qE "^TrustedUserCAKeys" "$SSHD_CONF"; then
    sed -i 's|^TrustedUserCAKeys.*|TrustedUserCAKeys /etc/ssh/agent_ca.pub|' "$SSHD_CONF"
    echo "Updated TrustedUserCAKeys in $SSHD_CONF"
elif grep -qE "^#TrustedUserCAKeys" "$SSHD_CONF"; then
    sed -i 's|^#TrustedUserCAKeys.*|TrustedUserCAKeys /etc/ssh/agent_ca.pub|' "$SSHD_CONF"
    echo "Uncommented TrustedUserCAKeys in $SSHD_CONF"
else
    echo "TrustedUserCAKeys /etc/ssh/agent_ca.pub" >> "$SSHD_CONF"
    echo "Appended TrustedUserCAKeys to $SSHD_CONF"
fi

# NOPASSWD sudo for igareosh
SUDOERS_FILE="/etc/sudoers.d/igareosh-agent"
echo "igareosh ALL=(ALL) NOPASSWD:ALL" > "$SUDOERS_FILE"
chmod 440 "$SUDOERS_FILE"
# Validate sudoers before applying (visudo check)
if ! visudo -cf "$SUDOERS_FILE" > /dev/null 2>&1; then
    echo "ERROR: sudoers syntax invalid, removing." >&2
    rm -f "$SUDOERS_FILE"
    exit 1
fi
echo "Written: $SUDOERS_FILE"

# Reload sshd
if systemctl reload sshd 2>/dev/null; then
    echo "sshd reloaded"
elif service ssh reload 2>/dev/null; then
    echo "sshd reloaded (service)"
else
    echo "WARNING: Could not reload sshd — reload manually" >&2
fi

echo "DONE: $(hostname) — agent CA trusted, igareosh NOPASSWD sudo active"
