"""Run on trustmaster: docker exec -i authentik-server-1 ak shell < scripts/trustmaster_list_outpost_providers.py"""
from authentik.outposts.models import Outpost
from authentik.providers.proxy.models import ProxyProvider

for o in Outpost.objects.all():
    print("Outpost:", o.pk, o.name, o.uuid)
    for p in o.providers.all():
        print("  provider:", p.pk, getattr(p, "name", None))
print("---")
for p in ProxyProvider.objects.all().order_by("pk"):
    print("ProxyProvider:", p.pk, p.name, p.external_host)
