# Abelard LAMAITA maintenance sweep — excludes Downloads and Desktop
# SIGNED: Abelard | LAMAITA | 2026-06-01
$ErrorActionPreference = 'Continue'
$log = Join-Path $env:TEMP "abelard-lamaita-sweep-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
function Log($m) { $line = "$(Get-Date -Format 'o') $m"; Add-Content -Path $log -Value $line; Write-Output $line }

$excludeRoots = @(
    (Join-Path $env:USERPROFILE 'Downloads'),
    (Join-Path $env:USERPROFILE 'Desktop')
)

Log '=== Abelard LAMAITA sweep start ==='
Log "User: $env:USERNAME Profile: $env:USERPROFILE"

# --- Disk ---
$cd = Get-PSDrive C
Log "C: UsedGB=$([math]::Round($cd.Used/1GB,2)) FreeGB=$([math]::Round($cd.Free/1GB,2))"

# --- Recycle bin ---
try {
    Clear-RecycleBin -Force -ErrorAction Stop
    Log 'RecycleBin: cleared'
} catch { Log "RecycleBin: $($_.Exception.Message)" }

# --- Temp cleanup (user + system; not Downloads/Desktop) ---
$tempTargets = @(
    $env:TEMP,
    (Join-Path $env:LOCALAPPDATA 'Temp'),
    'C:\Windows\Temp'
)
$tempBytes = 0
foreach ($t in $tempTargets) {
    if (-not (Test-Path -LiteralPath $t)) { continue }
    Get-ChildItem -LiteralPath $t -Force -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $sz = if ($_.PSIsContainer) {
                (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            } else { $_.Length }
            Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction Stop
            $tempBytes += [long]$sz
        } catch { }
    }
}
Log "TempCleanup: removed approx $([math]::Round($tempBytes/1MB,1)) MB from temp folders"

# --- Windows Update component cleanup (DISM) ---
try {
    $dism = Start-Process -FilePath 'dism.exe' -ArgumentList '/Online','/Cleanup-Image','/StartComponentCleanup' -Wait -PassThru -NoNewWindow
    Log "DISM ComponentCleanup exit=$($dism.ExitCode)"
} catch { Log "DISM ComponentCleanup: $($_.Exception.Message)" }

try {
    $dismScan = Start-Process -FilePath 'dism.exe' -ArgumentList '/Online','/Cleanup-Image','/ScanHealth' -Wait -PassThru -NoNewWindow
    Log "DISM ScanHealth exit=$($dismScan.ExitCode)"
} catch { Log "DISM ScanHealth: $($_.Exception.Message)" }

# --- SFC verify ---
try {
    $sfc = Start-Process -FilePath 'sfc.exe' -ArgumentList '/verifyonly' -Wait -PassThru -NoNewWindow
    Log "SFC verifyonly exit=$($sfc.ExitCode)"
} catch { Log "SFC: $($_.Exception.Message)" }

# --- Defender ---
try {
    & 'C:\Program Files\Windows Defender\MpCmdRun.exe' -SignatureUpdate -ErrorAction SilentlyContinue | Out-Null
    Log 'Defender: signatures updated'
    $scan = Start-Process -FilePath 'C:\Program Files\Windows Defender\MpCmdRun.exe' -ArgumentList '-Scan','-ScanType','1' -Wait -PassThru -NoNewWindow
    Log "Defender QuickScan exit=$($scan.ExitCode)"
} catch { Log "Defender: $($_.Exception.Message)" }

# --- System Restore point ---
try {
    Enable-ComputerRestore -Drive 'C:\' -ErrorAction SilentlyContinue
    Checkpoint-Computer -Description "Abelard $(Get-Date -Format 'yyyy-MM-dd')" -RestorePointType 'MODIFY_SETTINGS'
    Log "RestorePoint: Abelard $(Get-Date -Format 'yyyy-MM-dd')"
} catch { Log "RestorePoint: $($_.Exception.Message)" }

# --- Storage Sense / Delivery Optimization cache ---
try {
    Stop-Service -Name DoSvc -Force -ErrorAction SilentlyContinue
    $doCache = 'C:\ProgramData\Microsoft\Windows\DeliveryOptimization\Cache'
    if (Test-Path $doCache) {
        Remove-Item -LiteralPath "$doCache\*" -Recurse -Force -ErrorAction SilentlyContinue
        Log 'DeliveryOptimization cache cleared'
    }
    Start-Service -Name DoSvc -ErrorAction SilentlyContinue
} catch { Log "DO cache: $($_.Exception.Message)" }

# --- Thumbnail / icon caches (user) ---
$cacheDirs = @(
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'),
    (Join-Path $env:LOCALAPPDATA 'IconCache')
)
foreach ($c in $cacheDirs) {
    if (-not (Test-Path $c)) { continue }
    Get-ChildItem $c -Filter 'thumbcache_*.db' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Get-ChildItem $c -Filter 'iconcache_*.db' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
}
Log 'Explorer thumbnail/icon caches trimmed'

# --- Profile subfolder sizes (skip Downloads/Desktop) ---
Log '--- Profile folder sizes (MB), excluding Downloads/Desktop ---'
Get-ChildItem $env:USERPROFILE -Force -ErrorAction SilentlyContinue | Where-Object {
    $_.PSIsContainer -and ($excludeRoots -notcontains $_.FullName)
} | ForEach-Object {
    $sum = (Get-ChildItem $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    if ($sum -gt 50MB) {
        Log ("  {0}: {1} MB" -f $_.Name, [math]::Round($sum/1MB,1))
    }
}

# --- Large files in profile (>500MB), excluding Downloads/Desktop ---
Log '--- Large files >500MB outside Downloads/Desktop ---'
$large = @()
Get-ChildItem $env:USERPROFILE -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object {
    $_.Length -gt 500MB -and ($excludeRoots | Where-Object { $_.FullName.StartsWith($_) }).Count -eq 0
} | Select-Object -First 20 FullName, @{N='GB';E={[math]::Round($_.Length/1GB,2)}}
foreach ($f in $large) { Log ("  LARGE: $($f.FullName) ($($f.GB) GB)") }
if (-not $large) { Log '  (none found)' }

# --- WinRE ---
try {
    $re = & reagentc.exe /info 2>&1 | Out-String
    Log "WinRE: $($re.Trim() -replace '\s+',' ')"
} catch { }

# --- Pending reboot ---
$pending = Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
Log "PendingReboot: $pending"

# --- Startup items (report) ---
Log '--- Startup (CurrentUser Run) ---'
Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -ErrorAction SilentlyContinue |
    ForEach-Object { $_.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } } |
    ForEach-Object { Log ("  Run: $($_.Name)") }

# --- Verify display persist task ---
$task = Get-ScheduledTask -TaskName 'Abelard-LamaitaDisplayPersist' -ErrorAction SilentlyContinue
Log "Task Abelard-LamaitaDisplayPersist: $(if ($task) { $task.State } else { 'MISSING' })"

# --- Windows Update: install quality updates (no feature upgrade) ---
try {
    $session = New-Object -ComObject Microsoft.Update.Session
    $searcher = $session.CreateUpdateSearcher()
    $result = $searcher.Search('IsInstalled=0 and Type=''Software'' and IsHidden=0')
    Log "WU pending quality updates: $($result.Updates.Count)"
    if ($result.Updates.Count -gt 0 -and $result.Updates.Count -le 15) {
        $toInstall = New-Object -ComObject Microsoft.Update.UpdateColl
        for ($i = 0; $i -lt $result.Updates.Count; $i++) { $toInstall.Add($result.Updates.Item($i)) | Out-Null }
        $downloader = $session.CreateUpdateDownloader()
        $downloader.Updates = $toInstall
        Log 'WU: downloading...'
        $dl = $downloader.Download()
        Log "WU download result=$($dl.Result)"
        if ($dl.Result -eq 2) {
            $installer = $session.CreateUpdateInstaller()
            $installer.Updates = $toInstall
            $inst = $installer.Install()
            Log "WU install result=$($inst.Result) reboot=$($inst.RebootRequired)"
        }
    }
} catch { Log "WU: $($_.Exception.Message)" }

$cd2 = Get-PSDrive C
Log "C: after FreeGB=$([math]::Round($cd2.Free/1GB,2))"
Log "=== Log file: $log ==="
Get-Content $log
