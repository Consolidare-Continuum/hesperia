---
task_id: "cursor|EOD|collect"
active_md_anchor: "| EOD |"
---

# Script runbook — End-of-day collect (snapshot before consolidation)

**Purpose**: **Collect-only** snapshot: git diff/status, `active.md` excerpt, Chroma heartbeat, optional workflow API — **no commit**. Reduces skip rate for [.cursor/END-OF-DAY-WORKFLOW.md](../.cursor/END-OF-DAY-WORKFLOW.md). Ref: [.cursor/ETHAN-BRAIN-ENHANCEMENTS-NOTES.md](../.cursor/ETHAN-BRAIN-ENHANCEMENTS-NOTES.md).

**Who**: Cursor main / operator on prichindel or any clone with `curl` and git.

---

## When to use

- End of day before steps 1–5 of END-OF-DAY-WORKFLOW (structure, compliance, chats, commit, Chroma ingest).
- Quick health snapshot for operator without opening many files.

---

## Procedure

1. From repo root: `bash scripts/end_of_day_collect.sh` → stdout, **or** `--out /path/eod-$(date -u +%F).txt`.
2. Review: uncommitted work, OPEN rows, Chroma **200**, workflow API reachability (may warn if port shared or service down).
3. Continue with END-OF-DAY-WORKFLOW §1+ (human/Cursor decides commits).

---

## Environment

- `CHROMA_SERVER_URL` — default `http://chroma-1.prichindel.local:8002`.
- `WORKFLOW_API_BASE` — default `http://127.0.0.1:9096`; `WORKFLOW_API_TOKEN` if auth enabled.

---

## Do not

- Do **not** treat collect output as committed state — git state is local until push.
- Do **not** skip Chroma ingest (§5 EOD) when policy says run after push — collect does **not** replace ingest.

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| Workflow API unreachable | `sudo systemctl status workflow-api`; [agents/abelard/MAINTENANCE-BRAIN-REPO-FLOWS.md](../agents/abelard/MAINTENANCE-BRAIN-REPO-FLOWS.md). |
| Chroma curl fail | SURVEILLANCE §8.2; Abelard restart services. |

---

## See also

- [scripts/end_of_day_collect.sh](end_of_day_collect.sh) — implementation.
- [SCRIPT-RUNBOOK-mcp-chroma-session.md](SCRIPT-RUNBOOK-mcp-chroma-session.md) — Chroma path.
- [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) — heartbeat semantics.

SIGNED: Architecture (Ethan) | EOD snapshot interface | 2026-03-30 | SCRIPT-RUNBOOK
