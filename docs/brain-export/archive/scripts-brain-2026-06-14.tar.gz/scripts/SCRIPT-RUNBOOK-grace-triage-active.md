---
task_id: "P6|triage|grace-active"
active_md_anchor: "| Grace |"
---

# Script runbook — Grace triage → active.md row

**Purpose**: Single path of awareness for team execution (P6 Task division → P7 Execution). **Only Grace** adds rows to [active.md](../active.md). Ref: [OPERATIONAL-LAYER.md](../OPERATIONAL-LAYER.md), [LEAN-GOVERNANCE.md](../LEAN-GOVERNANCE.md), [governance/PHASE-INTERFACE-CONTROL-DOCUMENT.md](../governance/PHASE-INTERFACE-CONTROL-DOCUMENT.md).

**Who**: Grace (owner). Boss and leads request triage; they do **not** self-append rows.

---

## When to use

- New work from inbox, assignments, or operator request must appear on the **single** active list.
- Before anyone runs `scripts/workflow_run.sh` / "proceed" for a **team** task, the row must exist.

---

## Procedure

1. **Intake**: Read [inbox.md](../inbox.md), operational assignment notes under [operational/assignments/](../operational/assignments/) if used, or operator message. Classify priority (P1–P3), project, clear task line, owner.
2. **One row** in `active.md` table: Priority | Project | Task | Owner | STATUS | Ref. STATUS = `OPEN` (or `IN_PROGRESS` if already started per policy).
3. **Link**: Add ref column (governance path, operational path, or spec). No orphan tasks without ref when spec exists.
4. **Communicate**: Brief note to operator or lead if assignment is non-obvious.

---

## Do not

- Do **not** let Cursor, Abelard, or Gena **create** rows (Grace-only). They execute when triaged.
- Do **not** duplicate tasks across `active.md` and scattered folders without a ref.

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| "Proceed" but no row | Grace adds row; then re-run workflow. |
| Duplicate rows | Merge rows; keep one canonical task line. |

---

## See also

- [SCRIPT-RUNBOOK-report-done-workflow.md](SCRIPT-RUNBOOK-report-done-workflow.md) — closing rows.
- [operational/templates/grace-triage/README.md](../operational/templates/grace-triage/README.md) — draft templates.

SIGNED: Architecture (Ethan) | team triage interface | 2026-03-30 | SCRIPT-RUNBOOK
