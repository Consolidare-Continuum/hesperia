#!/usr/bin/env bash
# Build operational/library-files-inventory.txt from operational/library_paste_raw.txt
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IN="${ROOT}/operational/library_paste_raw.txt"
OUT="${ROOT}/operational/library-files-inventory.txt"
PY="${ROOT}/scripts/parse_library_file_list.py"

if [[ ! -f "$IN" ]]; then
  echo "BLOCKED: missing $IN — create it and paste the export (Name … through N files)." >&2
  exit 1
fi
if ! grep -qE '^[[:space:]]*(EN|RU) - ' "$IN"; then
  echo "BLOCKED: $IN has no lines starting with EN - or RU -. Paste the full listing." >&2
  exit 1
fi

python3 "$PY" "$IN" -o "$OUT" --header
echo "Result: $OUT ($(wc -l < "$OUT") lines)"
head -n 3 "$OUT"
echo "…"
tail -n 3 "$OUT"
