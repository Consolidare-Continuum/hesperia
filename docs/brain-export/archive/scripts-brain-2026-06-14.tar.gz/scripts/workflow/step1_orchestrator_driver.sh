#!/usr/bin/env bash
# Step 1: Orchestrator (heartbeat, inbox/assignments) then driver (current task). On success, invoke step2.
# Called from workflow_automation_run.sh. Requires REPO_ROOT, LOG_FILE exported.

set -e
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
LOG_FILE="${LOG_FILE:-$REPO_ROOT/governance/workflow_automation.log}"

cd "$REPO_ROOT"
python3 scripts/workflow_orchestrator.py >> "$LOG_FILE" 2>&1
python3 scripts/workflow_driver.py --no-wait >> "$LOG_FILE" 2>&1
bash "$REPO_ROOT/scripts/workflow/step2_executor.sh"
