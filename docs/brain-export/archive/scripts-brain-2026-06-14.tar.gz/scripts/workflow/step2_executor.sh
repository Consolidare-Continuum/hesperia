#!/usr/bin/env bash
# Step 2: Server executor (Abelard tasks only). If not handled (exit 2), do not invoke Cloud Agent (out of scope; not used here).
# Current step stays in workflow_driver_current.txt for Cursor-in-IDE or manual. Write state and END.
# Called from step1 when driver is done. Requires REPO_ROOT, LOG_FILE, STATE_FILE, EXECUTOR exported.

set -e
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
LOG_FILE="${LOG_FILE:-$REPO_ROOT/governance/workflow_automation.log}"
STATE_FILE="${STATE_FILE:-$REPO_ROOT/governance/workflow_automation_state.txt}"
EXECUTOR="${EXECUTOR:-$REPO_ROOT/cluster/workflow-automation/abelard_executor.py}"

cd "$REPO_ROOT"
set +e
python3 "$EXECUTOR" >> "$LOG_FILE" 2>&1
exec_ret=$?
set -e
if [ "$exec_ret" -eq 2 ]; then
  echo "Executor: no server auto-action (not Abelard, or Abelard task has no matched script e.g. maintenance/backup). Cloud Agent out of scope; current step for Cursor-in-IDE or manual." >> "$LOG_FILE"
fi
ts_end=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
epoch=$(date -u +%s)
run_count=1
[ -f "$STATE_FILE" ] && while IFS= read -r line; do
  [[ "$line" =~ ^run_count=([0-9]+)$ ]] && run_count=$((BASH_REMATCH[1] + 1))
done < "$STATE_FILE"
{
  echo "last_run_epoch=$epoch"
  echo "last_run_iso=$ts_end"
  echo "run_count=$run_count"
} > "$STATE_FILE"
echo "--- $ts_end END ---" >> "$LOG_FILE"
