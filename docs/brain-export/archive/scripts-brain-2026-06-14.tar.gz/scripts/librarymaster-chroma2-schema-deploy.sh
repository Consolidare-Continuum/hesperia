#!/usr/bin/env bash
# CHROMA-2 schema deploy only (steps 1–2 of mandatory order: DEV → DEPLOY → DATA).
# Syncs schema v1 ingest worker + CHROMA-2 units; deploy + preflight. Does NOT wipe or reindex.
#
# Run from brain repo (any host with alunel SSH):
#   bash scripts/librarymaster-chroma2-schema-deploy.sh
#
# Ref: governance/PAPRA-CHROMA2-EXIT-CRITERIA.md G0 · PAPRA-03..07
set -euo pipefail

REPO="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
LM=librarymaster
INGEST=/data/docker/papra/ingest
BRAIN=/data/workspaces/cursor

log() { echo "[chroma2-schema-deploy] $*"; }

if [[ "$(hostname -s)" != "alunel" ]]; then
  log "Sync deploy bundle to alunel..."
  rsync -az "$REPO/scripts/librarymaster-chroma2-schema-deploy.sh" \
    "$REPO/scripts/librarymaster-deploy-chroma-2.sh" \
    "$REPO/scripts/verify-chroma2-persist.sh" \
    alunel:/data/workspaces/cursor/scripts/
  rsync -az "$REPO/cluster/librarymaster/" \
    alunel:/data/workspaces/cursor/cluster/librarymaster/
  log "Jumping to alunel..."
  exec ssh -o BatchMode=yes alunel "bash /data/workspaces/cursor/scripts/librarymaster-chroma2-schema-deploy.sh"
fi

REPO=/data/workspaces/cursor
LOG_DIR="${REPO}/operational/assignments/reports"
mkdir -p "$LOG_DIR"
STAMP=$(date +%Y%m%d-%H%M%S)
PREFLIGHT_LOG="${LOG_DIR}/PAPRA-15-CHROMA2-PREFLIGHT-${STAMP}.log"

log "=== CHROMA-2 schema deploy (no data wipe) ==="

log "1) Sync ingest worker v1 + CHROMA units to librarymaster"
ssh "$LM" "sudo mkdir -p ${INGEST} /etc/systemd/system/papra-ingest.service.d ${BRAIN}/scripts ${BRAIN}/cluster/librarymaster/chroma"
rsync -az \
  "$REPO/cluster/librarymaster/papra/filename_metadata.py" \
  "$REPO/cluster/librarymaster/papra/ingest_worker.py" \
  "${LM}:${INGEST}/"
rsync -az "$REPO/cluster/librarymaster/papra/papra-ingest.service.d/" \
  "${LM}:/tmp/papra-ingest.service.d/" 2>/dev/null || true
ssh "$LM" "sudo mkdir -p /etc/systemd/system/papra-ingest.service.d && sudo cp /tmp/papra-ingest.service.d/*.conf /etc/systemd/system/papra-ingest.service.d/ 2>/dev/null || true"
rsync -az "$REPO/cluster/librarymaster/chroma/" "${LM}:${BRAIN}/cluster/librarymaster/chroma/"
rsync -az "$REPO/scripts/librarymaster-deploy-chroma-2.sh" \
  "$REPO/scripts/verify-chroma2-persist.sh" \
  "${LM}:${BRAIN}/scripts/"

log "2) Deploy CHROMA-2 (--restart)"
ssh "$LM" "cd ${BRAIN} && sudo REPO_ROOT=${BRAIN} bash scripts/librarymaster-deploy-chroma-2.sh --restart"

log "3) Preflight CHROMA-2 (PAPRA-15 artifact)"
ssh "$LM" "cd ${BRAIN} && bash scripts/verify-chroma2-persist.sh" | tee "$PREFLIGHT_LOG"

log "4) papra-ingest remains STOPPED until G0 dry-run (PAPRA-10) PASS"
ssh "$LM" "sudo systemctl stop papra-ingest 2>/dev/null || true; systemctl is-active papra-ingest || echo inactive"

log "=== DEPLOY DONE — next: PAPRA-10 dry-run ≤3 docs, then operator may authorize DATA (PAPRA-29) ==="
log "Preflight log: ${PREFLIGHT_LOG}"
