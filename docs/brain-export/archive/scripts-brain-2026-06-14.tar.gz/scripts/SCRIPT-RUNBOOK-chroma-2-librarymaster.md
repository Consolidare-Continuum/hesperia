# CHROMA-2 librarymaster — deploy, persist verify, backup

**Host:** librarymaster only · **Spec:** [governance/SPEC-ETHAN-CHROMA-2-LIBRARYMASTER-PRODUCTION.md](../governance/SPEC-ETHAN-CHROMA-2-LIBRARYMASTER-PRODUCTION.md)

## Deploy (Abelard)

On **librarymaster** from brain repo:

```bash
cd /data/workspaces/cursor
git pull
bash scripts/librarymaster-deploy-chroma-2.sh          # install units + migrate paths
bash scripts/librarymaster-backup-chroma-2.sh          # before any restart
bash scripts/verify-chroma2-persist.sh                 # must PASS
bash scripts/librarymaster-deploy-chroma-2.sh --restart   # only after backup + approval
```

## Persist verify (mandatory before restart)

```bash
bash scripts/verify-chroma2-persist.sh
```

Fails if unit bind is not `/data/chroma-2/data:/data` or chunk_count vs datadir size mismatch.

## Backup (weekly + pre-restart)

```bash
bash scripts/librarymaster-backup-chroma-2.sh
```

Target: **fulgusor** `/mnt/arc/backup/chroma-2/<stamp>/`

## Never again checklist (Abelard)

Before any CHROMA-2 restart, image bump, or datadir move:

1. `bash scripts/verify-chroma2-persist.sh` → PASS  
2. `bash scripts/librarymaster-backup-chroma-2.sh` → fresh snapshot on fulgusor  
3. **`request_approval`** if chunk_count > 0 or operator index at risk  
4. Record chunk_count + `du -sb /data/chroma-2/data` in ops note  
5. **DEV → DEPLOY → DATA** order — no combined deploy+reindex without G0 dry-run PASS  
6. Confirm `findmnt` / unit bind shows `/data/chroma-2/data:/data` not empty Docker layer

Ref: [PAPRA-CHROMA2-EXIT-CRITERIA.md](../governance/PAPRA-CHROMA2-EXIT-CRITERIA.md) G0

## Incident

2026-06-14 P0: [operational/assignments/reports/ETHAN-CHROMA-2-DESTRUCTIVE-INCIDENT-2026-06-14.md](../operational/assignments/reports/ETHAN-CHROMA-2-DESTRUCTIVE-INCIDENT-2026-06-14.md)

SIGNED: DevOps (Abelard) | CHROMA-2 runbook | 2026-06-14
