---
task_id: "P2|im-irc|IM-IRC-T04"
active_md_anchor: "| P2 | im-irc | **IM-IRC-T04**"
---

# Script runbook — IM-IRC mesh (skeleton)

**Purpose**: Operations on the IRC agent mesh on **tersagor VM only** (`192.168.100.68`) — Ergo, eggdrop, **OpenAI mesh** (`IMIRC_BACKEND=openai`, `:18094`), gateway, kill-switch. **Existence map:** [cluster/tersagor/EXISTENCE.md](../cluster/tersagor/EXISTENCE.md). Legacy n8n/Cursor paths **off** (2026-05-25). Wrap-up: [IM-IRC-TERSAGOR-v0.1-WRAPUP](../operational/assignments/IM-IRC-TERSAGOR-v0.1-WRAPUP-2026-05-15.md).

**Refs**: [operational/assignments/GRACE-TRIAGE-IM-IRC-MESH-2026-05-04.md](../operational/assignments/GRACE-TRIAGE-IM-IRC-MESH-2026-05-04.md), [governance/IM-IRC-TASK-ENVELOPE-AND-DELEGATE-v1.md](../governance/IM-IRC-TASK-ENVELOPE-AND-DELEGATE-v1.md), [governance/PHASE-INTERFACE-CONTROL-DOCUMENT.md](../governance/PHASE-INTERFACE-CONTROL-DOCUMENT.md) §6, [operational/assignments/IM-IRC-PROGRAM-TRACKING-GRACE.md](../operational/assignments/IM-IRC-PROGRAM-TRACKING-GRACE.md).

**Phase (PICD)**: IM-IRC build rails **IM-P0** (T01–T04) — this runbook is the **Liam** shell for handoff to Abelard / Gena / Felix as later tasks complete.

---

## 1. girc (IRCd on **tersagor**)

| Item | Value |
|------|--------|
| **What** | Ergo **ergo-girc.service** (user) on **tersagor** `192.168.100.68`. Repo contract: [`cluster/trustmaster/girc/`](../cluster/trustmaster/girc/). **Retired on trustmaster:** [IRC-STACK-RETIRED.md](../cluster/trustmaster/IRC-STACK-RETIRED.md). |
| **Check** | `ssh tersagor 'systemctl --user is-active ergo-girc; ss -lntp \| grep 6667'` |
| **DNS** | `irc.tersagor.prichindel.local` — loopback on VM; **6667** plaintext for colocated clients |
| **Failure** | `journalctl --user -u ergo-girc`; **Abelard** |
| **Purge old host** | `bash scripts/trustmaster-purge-irc-stack.sh` (via prichindel SSH) |

---

## 2. eggdrop (classification / egdropp)

| Item | Stub |
|------|------|
| **What** | Bot classification, `!task`, gateway hooks — **IM-IRC-T13+** (Gena). |
| **Check** | Bot online; triggers reach gateway path. |
| **Failure** | No classification → see gateway + n8n sections. |

*Expand after eggdrop work: config location, restart procedure.*

---

## 3. n8n (workflows)

| Item | Stub |
|------|------|
| **What** | Ingest, OpenAI path, gates, Telegram — **IM-IRC-T17+** (Gena / Liam runbooks). |
| **Check** | Workflow import; last run success; secrets via Authentik / env (no secrets in git). |
| **Failure** | Stuck runs; use import/rollback below (**IM-IRC-T21**). |

### 3.1 n8n import / export / rollback (IM-IRC-T21)

| Step | Action |
|------|--------|
| **Export** | n8n UI → Workflows → ⋮ → **Download** JSON for each workflow under change; store outside git or in versioned **backup** bucket. |
| **Import** | **Import from File** — validate credentials placeholders were stripped from JSON before sharing. |
| **Secrets** | Name-only in docs: `OPENAI_API_KEY`, `WORKFLOW_API_TOKEN`, Telegram bot tokens — values live in host env / Authentik / Docker secrets (**never** in workflow JSON committed to repo). |
| **Rollback** | Re-import last known-good JSON; restart n8n worker if executions stuck (`docker compose restart` on hosting stack — align with prod compose host). |

---

## 3.2 tersagor operator health (routes + triage)

**Canonical:** [cluster/tersagor/OPERATOR-HEALTH.md](../cluster/tersagor/OPERATOR-HEALTH.md) — Telegram routes (natural OpenAI vs `!ping`/Cursor vs `!ops`), sixty-second health check, unreachable order, blockers, log paths, deploy/sync commands.

## 3.3 tersagor + Telegram failure modes (IM-IRC-T35)

| Symptom | Check | Mitigation |
|---------|-------|------------|
| No Telegram ↔ relay | **tersagor** tunnel / Zero Trust app healthy; see hostname **tersagor.prichindel.com** reachability from prichindel | Restore tunnel connector; verify OIDC IdP on trustmaster |
| Webhook timeouts | n8n execution log **timeout** vs IRC gateway latency | Raise gateway timeout; reduce payload; rate limits **IM-IRC-T19** |
| Duplicate replies | Same `cid` on two transports | Enable dedup path **IM-IRC-T34** when parallel Telegram subflow on |

---

## 4. Gateway (IRC → HTTP → n8n)

| Item | Stub |
|------|------|
| **What** | **IM-IRC-T15** gateway MVP — [`cluster/trustmaster/imirc-gateway/`](../cluster/trustmaster/imirc-gateway/README.md) (`forwarder.py` tails **`eggdrop-classify.jsonl`** → POST envelope **v1**). Envelope **v1** in [IM-IRC-TASK-ENVELOPE-AND-DELEGATE-v1.md](../governance/IM-IRC-TASK-ENVELOPE-AND-DELEGATE-v1.md). |
| **Check** | Webhook receives POST; `correlation_id` preserved. |
| **Failure** | 4xx/5xx; check TLS and auth per **T07/T08**. |

### 4.1 Error path (IM-IRC-T22)

| HTTP / runtime | User-visible IRC |
|----------------|------------------|
| 4xx validation | `NOTICE` or `PRIVMSG` to source channel with **`cid`** + short reason; **never** echo secrets or raw stack traces. |
| 5xx / timeout | Same; include **`retry_after`** hint if known. |

*Expand: endpoint path, auth header, rate limit knob.*

---

### 4.2 M5 failure drill (Telegram down / n8n down / OpenAI fallback)

Use this checklist when validating degrade behavior on production-like mesh.

| Drill | Injection | Expected | Evidence to capture |
|------|-----------|----------|---------------------|
| **Telegram down** | `sudo systemctl stop tersagor-approval-gateway.service` on trustmaster | IRC ingress still processes and responds through n8n path | forwarder trace with `http=200` + `processing_state=responded`; service state `inactive` during test |
| **n8n down** | `sudo docker stop n8n` on prichindel | No hang; clean reject/degraded IRC response | forwarder trace with bounded timeout (`http<0` or `>=500`) and `reply_to_irc=true`; n8n restored `healthy` |
| **OpenAI down/fallback** | inject probe command (`openai-down-probe`) | fallback/fail template reaches IRC | trace row includes template response preview and `processing_state=responded` |

**Recovery order**
1) Restore stopped service/container (`start` / `docker start`)  
2) Confirm healthy state (`systemctl is-active`, `docker ps`)  
3) Run one normal probe to verify mesh is back on nominal path.

---

## 5.1 E2E smoke (IM-IRC-T50)

Manual checklist: [IM-IRC-T50-E2E-SMOKE-CHECKLIST.md](IM-IRC-T50-E2E-SMOKE-CHECKLIST.md).

---

## 5. Web (SPA + WS gateway)

| Item | Stub |
|------|------|
| **What** | **IM-IRC-T43+**; Cloudflare Access / Authentik per [governance/ETHAN-CLOUDFLARE-ACCESS-AUTHENTIK-APP-MATRIX.md](../governance/ETHAN-CLOUDFLARE-ACCESS-AUTHENTIK-APP-MATRIX.md). |
| **Check** | Access session; WS or poll health. |
| **Failure** | 403 → Access / Authentik; **Abelard** vhost (**T45**). |

*Expand: hostname, build artifact path.*

---

## 6. Kill-switch and safety

| Item | Stub |
|------|------|
| **What** | **IM-IRC-T40** (metrics + kill); **T42** authority pointer to [governance/ESCALATIONS.md](../governance/ESCALATIONS.md) if present. |
| **Check** | Env or file flag stops outbound tool/OpenAI path without data loss. |
| **Failure** | Runaway spend / loop — engage kill-switch; **Ethan** governance for authority. |

*Expand: exact env names, API if any, who may invoke.*

---

## Related scripts (automation, not product)

| Script | Use |
|--------|-----|
| [workflow_automation_run.sh](workflow_automation_run.sh) | Team `active.md` chain; not the **IM-IRC full run** product name — see [governance/WORKFLOW-SCRIPT-NAMES.md](../governance/WORKFLOW-SCRIPT-NAMES.md). |
| [workflow_run.sh](workflow_run.sh) | Single fasten pass (orchestrator + driver + executor). |

---

SIGNED: Cursor (Cursor) | IM-IRC-T04 (Liam runbook owner) | 2026-05-04 | skeleton sections girc, eggdrop, n8n, gateway, web, kill-switch
