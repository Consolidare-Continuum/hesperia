#!/bin/bash
# Zero Trust report: account id + Access logs. Uses cf-account-id and ZT token (Edit then Report) on prichindel.
# Run on prichindel: bash scripts/cf-zero-trust-report.sh
# ZT tokens are account-scoped; use saved account_id. Optional: CF_ACCOUNT_ID=xxx.
AID="${CF_ACCOUNT_ID:-$(sudo cat /root/.secrets/cloudflare/cf-account-id 2>/dev/null | tr -d '\n\r')}"
if [ -z "$AID" ]; then
  echo "No account_id. Set CF_ACCOUNT_ID or: echo -n '<account_id>' | sudo tee /root/.secrets/cloudflare/cf-account-id"
  exit 1
fi

# Prefer Edit token for Access logs (broader scope); fallback to Report
T=""
for f in /root/.secrets/cloudflare/cf-zero-trust-edit /root/.secrets/cloudflare/cf-zero-trust-report; do
  if sudo test -r "$f" 2>/dev/null; then
    T=$(sudo cat "$f" 2>/dev/null | tr -d '\n\r')
    [ -n "$T" ] && break
  fi
done
if [ -z "$T" ]; then echo "No token (cf-zero-trust-edit or cf-zero-trust-report)"; exit 1; fi

api() {
  curl -sS -H 'Authorization: Bearer '"$T" "$1"
}

echo "=== ACCOUNT (id=$AID) ==="
api "https://api.cloudflare.com/client/v4/accounts/$AID" | jq -r 'if .success then "  \(.result.name)  id=\(.result.id)" else "  (details: \(.errors[0].message // "error"))" end'

echo ""
echo "=== ACCESS LOGS (access_requests, last 10) ==="
R=$(api "https://api.cloudflare.com/client/v4/accounts/$AID/access/logs/access_requests?limit=10")
if echo "$R" | jq -e '.success == true' >/dev/null 2>&1; then
  echo "$R" | jq '.'
else
  echo "$R" | jq '.'
  echo "Hint: Use token with Zero Trust Edit or Report; ZT tokens are account-scoped for this account."
fi
