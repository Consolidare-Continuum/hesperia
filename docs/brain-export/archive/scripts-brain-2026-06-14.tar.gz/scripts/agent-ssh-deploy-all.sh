#!/usr/bin/env bash
# Full Linux CA trust rollout from alunel: direct LAN, prichindel hub, qemu guest (librarymaster).
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

FAIL=0
bash "$SCRIPT_DIR/agent-ssh-deploy-trust.sh" || FAIL=$?
bash "$SCRIPT_DIR/agent-ssh-deploy-trust-via-prichindel.sh" || FAIL=$?

if command -v qm >/dev/null 2>&1 && [ "$(hostname -s 2>/dev/null)" = "alunel" ]; then
    if ! ssh -o ConnectTimeout=4 -o BatchMode=yes igareosh@librarymaster true 2>/dev/null; then
        if sudo qm status 103 2>/dev/null | grep -q running; then
            echo "=== librarymaster (qemu guest 103) ==="
            bash "$SCRIPT_DIR/agent-ssh-install-via-qemu.sh" 103 || FAIL=$?
        fi
    fi
fi

{
    echo "updated: $(date -Iseconds)"
    echo "runner: $(hostname -s)"
    echo "---"
    bash "$SCRIPT_DIR/agent-ssh-verify-trust.sh" 2>&1 || true
} >"$REPO_ROOT/governance/agent_ssh_trust_rollout.txt"

exit "$FAIL"
