# Runbook — Backup prichindel (lightweight + optional full)

**When**: Daily (cron 03:00 if installed), or on demand when operator/Abelard requests backup. Use when "run backup", "backup prichindel", or "what do I do for backup?".

**Where**: On prichindel (SSH or local). Lightweight script may run as igareosh; config snapshot needs sudo. Owner: **Abelard**.

---

## 1. Lightweight backup (configs, cursor workspace, package state)

**Script**: `scripts/backup-prichindel-light.sh` from repo root.

**Command**:
```bash
cd /data/workspaces/cursor
./scripts/backup-prichindel-light.sh
```

**Output**: `/data/backups/prichindel/YYYY-MM-DD/` (configs.tar.gz, cursor-workspace.tar.gz, dpkg-selections.txt, apt-manual.txt, snap-list.txt). If Proton mounted, copies to `/data/proton_backup/prichindel/backups/YYYY-MM-DD/`.

**Cron** (if installed): `0 3 * * * /data/workspaces/cursor/scripts/backup-prichindel-light.sh >> /var/log/backup-prichindel-light.log 2>&1`

---

## 2. Run-backup script (etc snapshot, package list, unit configs)

**Script**: `scripts/run-backup.sh` from repo root. Requires sudo.

**Command**:
```bash
cd /data/workspaces/cursor
sudo ./scripts/run-backup.sh
```

**Output**: Same date dir under `/data/backups/prichindel/`; adds etc-snapshot, dpkg-list, unit-configs-surveillance, services status. Use for duty manifest and config capture.

---

## 3. Chroma backup to fulgusor

Per [docs/BACKUPS.md](../docs/BACKUPS.md) §13: Chroma data → fulgusor `/mnt/arc/backup/chroma/` as `chroma-backup-YYYYMMDD.tar.gz`. Script: `cluster/chroma-server/backup-chroma-to-fulgusor.sh`. Rotation: keep 3 files. Schedule: e.g. `0 3 */3 * *` (every 3 days).

---

## 4. Retention and restore

- **Retention**: 7 daily + 4 weekly in each location. Do not delete recent backups without approval.
- **Restore**: See [docs/BACKUPS.md](../docs/BACKUPS.md) — per-service restore steps (configs, workspace, packages, Chroma).

---

## Failure modes

| Failure | Symptom | Action |
|---------|---------|--------|
| Backup dir not writable | Script exits or permission denied | Check `/data/backups/prichindel` exists; mkdir if needed; permissions (igareosh or root). |
| Proton not mounted | No copy to proton_backup | Lightweight script continues; local backup only. Mount Proton or run again when mounted. |
| Disk full | No space left on device | Free space (log rotate, clean /tmp); do not delete recent backups without approval. |

---

**Ref**: [docs/BACKUPS.md](../docs/BACKUPS.md), [governance/SPEC-ETHAN-DATA-LAYOUT-MAINTENANCE-BACKUP.md](../governance/SPEC-ETHAN-DATA-LAYOUT-MAINTENANCE-BACKUP.md). Owner: Abelard.
