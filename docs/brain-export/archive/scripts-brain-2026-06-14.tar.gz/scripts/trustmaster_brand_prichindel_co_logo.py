#!/usr/bin/env python3
"""
Append prichindel wordmark to Authentik flow login (default Brand `branding_custom_css`).
Image: https://prichindel.com/assets/logo-prichindel.png — Authentik built-in logo unchanged.

Apply from repo root (workspace → prichindel → trustmaster):

  cat scripts/trustmaster_brand_prichindel_co_logo.py | ssh prichindel \\
    'ssh igareosh@192.168.100.67 "sudo docker compose -f /opt/authentik/docker-compose.yml \\
      --env-file /opt/authentik/.env exec -T server python /manage.py shell"'

Idempotent: skips if marker `/* prichindel co-brand v1 */` is already present.
"""
from authentik.brands.models import Brand

MARKER = "/* prichindel co-brand v1 */"
CSS = (
    MARKER
    + """
.pf-c-login::before,
.pf-v5-c-login::before {
  content: "";
  display: block;
  width: min(100%, 26rem);
  height: 3.75rem;
  margin: 0.75rem auto 1rem;
  background: url("https://prichindel.com/assets/logo-prichindel.png") center / contain no-repeat;
}
"""
)

b = Brand.objects.filter(default=True).first()
if b is None:
    raise SystemExit("NO_DEFAULT_BRAND")
existing = (b.branding_custom_css or "").strip()
if MARKER in existing:
    print("ALREADY_APPLIED")
else:
    b.branding_custom_css = (existing + "\n\n" + CSS.strip() + "\n").strip()
    b.save(update_fields=["branding_custom_css"])
    print("UPDATED_OK", b.pk)
