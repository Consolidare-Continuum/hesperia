#!/usr/bin/env bash
# G0 gate: ingest dry-run ≤3 docs with schema v1 (PAPRA-10). No full corpus wipe.
#
#   bash scripts/librarymaster-papra-g0-dry-run-3.sh
#
# Requires: librarymaster-chroma2-schema-deploy.sh already PASS.
set -euo pipefail

REPO="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
LM=librarymaster
INGEST=/data/docker/papra/ingest
MAX_DOCS="${PAPRA_DRY_RUN_MAX_DOCS:-3}"

log() { echo "[papra-g0-dry-run] $*"; }

if [[ "$(hostname -s)" != "alunel" ]]; then
  rsync -az "$REPO/scripts/librarymaster-papra-g0-dry-run-3.sh" alunel:/data/workspaces/cursor/scripts/
  exec ssh -o BatchMode=yes alunel "bash /data/workspaces/cursor/scripts/librarymaster-papra-g0-dry-run-3.sh"
fi

log "=== G0 dry-run: max ${MAX_DOCS} docs ==="

ssh "$LM" "sudo systemctl stop papra-ingest 2>/dev/null || true"

DROPIN="/etc/systemd/system/papra-ingest.service.d/g0-dry-run.conf"
ssh "$LM" "sudo tee ${DROPIN} >/dev/null" <<EOF
[Service]
Environment=DRY_RUN_MAX_DOCS=${MAX_DOCS}
Environment=TURBO_MODE=0
Environment=INGEST_COOLDOWN=2
Environment=FULL_REINDEX=0
EOF

ssh "$LM" "sudo systemctl daemon-reload && sudo systemctl start papra-ingest"
log "Waiting for ${MAX_DOCS} new docs in processed.json (timeout 600s)..."

for i in $(seq 1 120); do
  COUNT=$(ssh "$LM" "python3 -c \"import json; d=json.load(open('${INGEST}/processed.json')); print(len(d))\" 2>/dev/null || echo 0")
  CHUNKS=$(ssh "$LM" "${INGEST}/venv/bin/python -c \"import chromadb; c=chromadb.HttpClient(host='127.0.0.1', port=8002); print(c.get_collection('documents').count())\" 2>/dev/null || echo 0")
  log "poll ${i}: processed_docs=${COUNT} chunk_count=${CHUNKS}"
  if [[ "${COUNT}" -ge "${MAX_DOCS}" ]]; then
    break
  fi
  sleep 5
done

ssh "$LM" "sudo systemctl stop papra-ingest; systemctl is-active papra-ingest || echo inactive"

SAMPLE=$(ssh "$LM" "${INGEST}/venv/bin/python" <<'PY'
import chromadb
c = chromadb.HttpClient(host="127.0.0.1", port=8002)
col = c.get_collection("documents")
r = col.get(limit=1, include=["metadatas"])
m = (r.get("metadatas") or [{}])[0]
print("schema_version", m.get("schema_version"))
print("title", (m.get("title") or "")[:80])
print("lang", m.get("lang"))
PY
)
log "Sample metadata:"
echo "$SAMPLE"

log "=== G0 dry-run complete — verify sample schema_version=1; mark PAPRA-10 DONE ==="
