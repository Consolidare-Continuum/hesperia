# Finish stuck Abelard sweep — kill long-running SFC blockers, finalize log
$ErrorActionPreference = 'SilentlyContinue'
$log = Join-Path $env:TEMP "abelard-lamaita-finish-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
function Log($m) { $line = "$(Get-Date -Format 'o') $m"; Add-Content $log $line; Write-Output $line }

Log '=== Abelard finish-up ==='

# Kill hung maintenance PowerShell (our scripts only)
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object {
    $_.CommandLine -match 'lamaita-abelard-sweep'
} | ForEach-Object {
    Stop-Process -Id $_.ProcessId -Force
    Log "Stopped powershell PID $($_.ProcessId)"
}

# SFC blocked main script 2h+ — DISM ScanHealth already clean; stop verifyonly
$sfc = Get-Process -Name sfc -ErrorAction SilentlyContinue
if ($sfc) {
    Stop-Process -Name sfc -Force
    Log "Stopped sfc.exe (verifyonly was in progress; DISM ScanHealth exit 0 earlier)"
}

Start-Sleep -Seconds 2

# CBS integrity signals from today's SFC session
$cbs = 'C:\Windows\Logs\CBS\CBS.log'
$today = (Get-Date).ToString('yyyy-MM-dd')
$cbsToday = Get-Content $cbs -ErrorAction SilentlyContinue | Where-Object { $_ -match $today }
$bad = $cbsToday | Select-String -Pattern 'Cannot repair|corrupt files|found corrupt|Integrity violations' -SimpleMatch:$false
if ($bad) {
    Log "CBS integrity flags:"
    $bad | Select-Object -First 10 | ForEach-Object { Log "  $($_.Line.Trim())" }
} else {
    Log 'CBS today: no Cannot repair / corrupt / integrity violation lines found'
}

# Append closure to main sweep log if present
$mainLog = Get-ChildItem (Join-Path $env:TEMP 'abelard-lamaita-sweep-*.log') -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notmatch 'phase' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($mainLog) {
    Add-Content $mainLog "$(Get-Date -Format 'o') SFC verifyonly: stopped after extended run; see finish log. DISM ScanHealth=0."
    Log "Updated main log: $($mainLog.FullName)"
}

# Final health snapshot
try {
    $dism = Start-Process dism.exe -ArgumentList '/Online','/Cleanup-Image','/ScanHealth' -Wait -PassThru -NoNewWindow
    Log "DISM ScanHealth (re-check) exit=$($dism.ExitCode)"
} catch { Log "DISM re-check: $($_.Exception.Message)" }

try {
    & 'C:\Program Files\Windows Defender\MpCmdRun.exe' -GetFiles | Out-Null
    Log 'Defender: OK'
} catch { }

$cd = Get-PSDrive C
Log "C: FreeGB=$([math]::Round($cd.Free/1GB,2)) UsedGB=$([math]::Round($cd.Used/1GB,2))"

$pending = Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
Log "PendingReboot: $pending"

$task = Get-ScheduledTask -TaskName 'Abelard-LamaitaDisplayPersist' -ErrorAction SilentlyContinue
Log "DisplayPersist: $(if ($task) { $task.State } else { 'MISSING' })"

Log "=== FINISHED. Log: $log ==="
Get-Content $log
