#!/usr/bin/env bash
# Deploy CHROMA-1/CHROMA-2 Prometheus scrape + alerts → tersagor /imirc/prometheus → Telegram.
# Run from brain repo root on a host with SSH to prichindel, alunel, librarymaster.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
EXPORTER="$REPO_ROOT/cluster/chroma-server/chroma-metrics-exporter.py"
PROM_DIR="$REPO_ROOT/cluster/prichindel/prometheus"

echo "=== CHROMA Prometheus monitoring deploy ==="

echo "--- alunel: CHROMA-1 metrics :8005 ---"
ssh -o BatchMode=yes alunel 'sudo mkdir -p /data/chroma/bin'
scp -o BatchMode=yes "$EXPORTER" alunel:/tmp/chroma-metrics-exporter.py
ssh -o BatchMode=yes alunel 'sudo cp /tmp/chroma-metrics-exporter.py /data/chroma/bin/chroma-metrics-exporter.py && sudo chmod +x /data/chroma/bin/chroma-metrics-exporter.py'
scp -o BatchMode=yes "$REPO_ROOT/cluster/alunel/chroma/chroma-1-metrics.service" alunel:/tmp/chroma-1-metrics.service
ssh -o BatchMode=yes alunel 'sudo cp /tmp/chroma-1-metrics.service /etc/systemd/system/ && sudo systemctl daemon-reload && sudo systemctl enable --now chroma-1-metrics && systemctl is-active chroma-1-metrics chroma-1-docker'
# LAN scrape from prichindel Prometheus (alunel UFW default-deny)
ssh -o BatchMode=yes alunel 'sudo ufw allow from 192.168.100.0/24 to any port 8005 proto tcp comment chroma-1-metrics-prometheus 2>/dev/null || true'

echo "--- librarymaster: CHROMA-2 metrics :8005 ---"
ssh -o BatchMode=yes prichindel 'ssh -o BatchMode=yes igareosh@192.168.100.66 "sudo mkdir -p /data/chroma/bin"'
scp -o BatchMode=yes "$EXPORTER" prichindel:/tmp/chroma-metrics-exporter.py
ssh -o BatchMode=yes prichindel 'scp /tmp/chroma-metrics-exporter.py igareosh@192.168.100.66:/tmp/chroma-metrics-exporter.py'
scp -o BatchMode=yes "$REPO_ROOT/cluster/librarymaster/chroma/chroma-2-metrics.service" prichindel:/tmp/chroma-2-metrics.service
ssh -o BatchMode=yes prichindel 'scp /tmp/chroma-2-metrics.service igareosh@192.168.100.66:/tmp/chroma-2-metrics.service && ssh igareosh@192.168.100.66 "sudo cp /tmp/chroma-metrics-exporter.py /data/chroma/bin/chroma-metrics-exporter.py && sudo chmod +x /data/chroma/bin/chroma-metrics-exporter.py && sudo cp /tmp/chroma-2-metrics.service /etc/systemd/system/ && sudo systemctl daemon-reload && sudo systemctl enable --now chroma-2-metrics && systemctl is-active chroma-2-metrics"'

echo "--- prichindel: Prometheus + Alertmanager ---"
scp -o BatchMode=yes "$PROM_DIR/prometheus.yml" "$PROM_DIR/rules.yml" prichindel:/tmp/
ssh -o BatchMode=yes prichindel 'sudo cp /tmp/prometheus.yml /tmp/rules.yml /data/docker/prometheus/config/ && sudo systemctl disable --now chroma-new-metrics 2>/dev/null || true'
ssh -o BatchMode=yes prichindel 'curl -sf -X POST http://127.0.0.1:9090/-/reload && echo prometheus_reload_ok'
ssh -o BatchMode=yes prichindel 'docker exec alertmanager kill -HUP 1 2>/dev/null && echo alertmanager_reload_ok || true'

echo "--- verify scrape from prichindel ---"
ssh -o BatchMode=yes prichindel 'curl -sf http://192.168.100.62:8005/metrics | grep -E "^chroma_up|CHROMA" | head -3; echo ---; curl -sf http://192.168.100.66:8005/metrics | grep -E "^chroma_up|CHROMA" | head -3'

echo "DONE. Alerts: Alertmanager → http://192.168.100.68:18090/imirc/prometheus → Telegram."
