#!/usr/bin/env bash
# Run ON librarymaster (192.168.100.66): adds IAM user igareosh-ui with consoleAdmin.
set -euo pipefail
OUT=/home/igareosh/.minio-igareosh-ui.key
PW=$(openssl rand -base64 28)
docker exec -e NEWPW="$PW" papra-minio sh -c '
  mc alias set local http://127.0.0.1:9000 "$MINIO_ROOT_USER" "$MINIO_ROOT_PASSWORD" >/dev/null
  mc admin user remove local igareosh-ui 2>/dev/null || true
  mc admin user add local igareosh-ui "$NEWPW"
  mc admin policy attach local consoleAdmin --user igareosh-ui
'
umask 077
printf '%s' "$PW" > "$OUT"
chmod 600 "$OUT"
echo "DONE secret_file=$OUT"
