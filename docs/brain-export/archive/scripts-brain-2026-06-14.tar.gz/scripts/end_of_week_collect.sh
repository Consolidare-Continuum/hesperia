#!/usr/bin/env bash
# Weekly collect: EOD collect + ISO week + REPO-EOW OPEN/DONE hints.
# Usage: ./scripts/end_of_week_collect.sh [--out FILE]
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO_ROOT"
OUT_FILE=""
if [[ "${1:-}" == "--out" && -n "${2:-}" ]]; then
  OUT_FILE="$2"
fi

WEEK="$(date -u +%G-W%V)"

collect() {
  echo "cursor EOW collect week=${WEEK} $(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo ""
  echo "=== REPO-EOW / REPO-AUTO rows (active.md) ==="
  grep -E 'REPO-EOW|REPO-AUTO|REPO-EOD' active.md 2>/dev/null | grep -E '\| (OPEN|DONE|IN_PROGRESS) \|' || echo "(none)"
  echo ""
  echo "=== OPEN count by project ==="
  awk -F'|' '/^\| P[0-9]/ {gsub(/^ +| +$/,"",$3); gsub(/^ +| +$/,"",$5); if ($5=="OPEN") c[$3]++} END {for (p in c) print p, c[p]}' active.md 2>/dev/null || true
  echo ""
  bash "$REPO_ROOT/scripts/end_of_day_collect.sh"
}

if [[ -n "$OUT_FILE" ]]; then
  collect >"$OUT_FILE"
  echo "Wrote $OUT_FILE"
else
  collect
fi
