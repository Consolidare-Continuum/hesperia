# Script runbook — MCP config drift and monthly check

**Purpose**: Detect MCP config drift and verify MCP tooling monthly. Owner: Liam (runbook); Sophia (schedule); Abelard (fix). Ref: agent_mcp_knowledge/CURSOR-MCP-SETUP.md §5.

---

## Script: mcp_config_drift_check.sh

| Item | Value |
|------|-------|
| Path | `scripts/mcp_config_drift_check.sh` |
| Owner | Liam (runbook); Abelard (deploy/fix) |
| Input | `governance/mcp-config.json` (canonical) |
| Output | Stdout: OK/FAIL lines; exit code 0 = no drift |
| Logging | Stdout only; redirect in cron if needed |

### Exit codes (BF-031)

| Code | Meaning |
|------|---------|
| 0 | No drift — user and project configs match canonical |
| 1 | Drift detected — one or both configs differ |
| 2 | Missing file (canonical or target) |

### Usage

```bash
# One-shot check
bash scripts/mcp_config_drift_check.sh

# CI/cron (exit code only)
bash scripts/mcp_config_drift_check.sh > /dev/null; echo $?
```

---

## Monthly MCP check procedure (BF-032)

Run at **start of each month** or after any MCP config change:

1. `bash scripts/mcp_config_drift_check.sh` — expect `drift_detected=0`
2. In Cursor IDE: invoke **query_knowledge** with any query — expect non-empty result
3. Invoke **get_heartbeat** — expect text with `last_run` line
4. Invoke **get_current_step** — expect text (may be "No OPEN tasks")
5. SSH to prichindel: `curl -s http://chroma-1.prichindel.local:8002/api/v2/heartbeat` — expect HTTP 200
6. Append row to `governance/CURSOR-REPO-COMPLIANCE-CHECK.md`

**If any step fails**: treat as config bug per agent_mcp_knowledge/CURSOR-MCP-SETUP.md §0. Fix: redeploy MCP config, restart Cursor, check SSH/Chroma on prichindel.

---

SIGNED: Automation (Liam) | scripts context | 2026-05-14 | BF-031 + BF-032
