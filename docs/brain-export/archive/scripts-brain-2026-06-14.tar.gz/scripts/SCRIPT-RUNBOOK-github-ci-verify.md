---
task_id: "WF-APP|github-ci-verify"
active_md_anchor: "github-ci-verify"
---

# Script runbook — GitHub CI verify (soft gate)

**Purpose**: Before **report_done DONE** on code rows with an open PR, verify CI/checks status. **Soft gate** — red CI → **PAUSE** with note or fix; not a hard block unless operator policy says otherwise.

**Who**: Gena, Felix, Cursor (code owners).  
**Automation**: MCP `get_pr_checks`, `get_branch_ci` (cursor-github-ci on prichindel; requires `gh` auth on prichindel).  
**Refs**: [SPEC-ETHAN-MCP-APPENDIX-DAILY-USE.md](../governance/SPEC-ETHAN-MCP-APPENDIX-DAILY-USE.md), [SCRIPT-RUNBOOK-github.md](SCRIPT-RUNBOOK-github.md)

---

## When mandatory

| Trigger | Mandatory |
|---------|-----------|
| Code row (cursor-repo, hesperia, client) with **open PR** before DONE | Yes (soft) |
| Operator says "ship" / merge pending | Recommended |

---

## Procedure (MCP)

1. **get_branch_ci("igareosh/cursor", "<branch>")** — latest workflow run, conclusion, failed job tail.
2. For PR-specific checks: **get_pr_checks("igareosh/cursor", <pr_number>)**.
3. **conclusion = success** or no runs → OK to DONE.
4. **failure** → PAUSE row; fix CI or note in outcome_summary.

---

## Procedure (manual — prichindel)

```bash
gh run list --repo igareosh/cursor --branch main --limit 1
gh pr checks <n> --repo igareosh/cursor
```

Auth: `/root/.config/gh/hosts.yml` + optional `/root/.secrets/github_token.env` (paths only; no values in docs). Ref: [agents/abelard/ABELARD_QUICK_OPS.md](../agents/abelard/ABELARD_QUICK_OPS.md) § GitHub CLI.

---

## Outcomes

| CI state | report_done |
|----------|-------------|
| success / no workflows | DONE allowed |
| failure / pending | PAUSE or IN_PROGRESS with summary |
| gh auth missing | BLOCKED for CI-dependent DONE — Abelard fix auth |

SIGNED: Runbooks (Liam) | github ci verify soft gate | 2026-05-31 | WF-APP-010
