#!/usr/bin/env python3
"""
Play a Plex playlist on a client (e.g. TV).

Usage:
  plex_play_playlist.py <playlist_name> [client_name]
  plex_play_playlist.py work              # Play "work" playlist on first available client
  plex_play_playlist.py work "Living Room" # Prefer client named "Living Room"

Requires: Plex token from fulgusor (Preferences.xml). Run from prichindel; SSH to fulgusor for token.
TV/client must have Plex app open and connected so it appears in /clients.
"""

import argparse
import json
import re
import subprocess
import sys

# Plex server on fulgusor (local LAN from prichindel)
PLEX_BASE = "http://192.168.100.40:32400"
FULGUSOR_PREFS = "/var/lib/plexmediaserver/Library/Application Support/Plex Media Server/Preferences.xml"


def get_token():
    """Get Plex token from fulgusor Preferences.xml via SSH."""
    cmd = [
        "ssh", "fulgusor",
        "sudo grep -oE 'PlexOnlineToken=\"[^\"]+\"' '" + FULGUSOR_PREFS + "'"
    ]
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    if out.returncode != 0 or not out.stdout.strip():
        print("Could not get Plex token from fulgusor (SSH or Preferences.xml).", file=sys.stderr)
        sys.exit(1)
    match = re.search(r'PlexOnlineToken="([^"]+)"', out.stdout.strip())
    if not match:
        print("No PlexOnlineToken found in Preferences.xml.", file=sys.stderr)
        sys.exit(1)
    token = match.group(1)
    if token.startswith("claim-"):
        print("Plex server is not claimed (token is claim-...). Claim at https://www.plex.tv/claim/", file=sys.stderr)
        sys.exit(1)
    return token


def plex_get(path, token, headers=None):
    """GET Plex API; returns parsed JSON or None."""
    import urllib.request
    url = PLEX_BASE + path
    if "?" in path:
        url += "&X-Plex-Token=" + token
    else:
        url += "?X-Plex-Token=" + token
    req = urllib.request.Request(url, headers=headers or {})
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        print(f"Plex API error: {e}", file=sys.stderr)
        return None


def plex_identity(token):
    """Get server machineIdentifier."""
    data = plex_get("/identity", token)
    if not data:
        return None
    return data.get("MediaContainer", {}).get("machineIdentifier")


def find_playlist(token, name):
    """Find playlist by title (case-insensitive). Returns (ratingKey, key, playlistType) or (None, None, None)."""
    for playlist_type in ("audio", "video"):
        data = plex_get(f"/playlists?playlistType={playlist_type}", token)
        if not data:
            continue
        for m in data.get("MediaContainer", {}).get("Metadata", []) or []:
            if m.get("title", "").strip().lower() == name.strip().lower():
                rating_key = m.get("ratingKey")
                key = m.get("key") or f"/playlists/{rating_key}/items"
                ptype = m.get("playlistType", playlist_type)
                return str(rating_key), key, ptype
    return None, None, None


def get_playlist_first_item_key(token, playlist_key):
    """Get key of first item in playlist (for playMedia 'key' param)."""
    path = playlist_key if playlist_key.startswith("/") else "/" + playlist_key
    data = plex_get(path, token)
    if not data:
        return None
    meta = data.get("MediaContainer", {}).get("Metadata", [])
    if not meta:
        return None
    return meta[0].get("key")


def get_clients(token):
    """List available Plex clients. Returns list of {name, host, port, machineIdentifier}."""
    data = plex_get("/clients", token)
    if not data:
        return []
    servers = data.get("MediaContainer", {}).get("Server", [])
    if not isinstance(servers, list):
        servers = [servers] if servers else []
    return [
        {
            "name": s.get("name", "?"),
            "host": s.get("address") or s.get("host"),
            "port": int(s.get("port", 0)),
            "machineIdentifier": s.get("machineIdentifier"),
        }
        for s in servers
        if s.get("address") or s.get("host")
    ]


def play_media_on_client(client_host, client_port, client_machine_id, token, server_machine_id, media_key, container_key, media_type="video", command_id=0):
    """
    Send playMedia to Plex client. Tries server proxy first (TVs often refuse direct),
    then direct to client.
    """
    import urllib.request
    import urllib.parse
    params = {
        "key": media_key,
        "containerKey": container_key,
        "machineIdentifier": server_machine_id,
        "address": "192.168.100.40",
        "port": "32400",
        "protocol": "http",
        "token": token,
        "commandID": command_id,
        "type": "music" if media_type in ("audio", "music") else "video",
    }
    url_encoded = urllib.parse.urlencode(params)
    headers = {
        "X-Plex-Client-Identifier": "plex-play-playlist-script",
        "X-Plex-Device-Name": "Cursor Script",
        "X-Plex-Target-Client-Identifier": client_machine_id,
    }
    # 1) Proxy via server (works when TV doesn't accept direct connections)
    server_url = PLEX_BASE + "/player/playback/playMedia?" + url_encoded
    req = urllib.request.Request(server_url, method="GET", headers=headers)
    req.add_header("X-Plex-Token", token)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            if r.status == 200:
                return True
    except Exception as e:
        pass  # fall back to direct
    # 2) Direct to client
    base = f"http://{client_host}:{client_port}"
    direct_url = base + "/player/playback/playMedia?" + url_encoded
    req = urllib.request.Request(direct_url, method="GET", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status == 200
    except Exception as e:
        print(f"Client playMedia error: {e}", file=sys.stderr)
        return False


def main():
    parser = argparse.ArgumentParser(description="Play a Plex playlist on a client (e.g. TV).")
    parser.add_argument("playlist_name", help="Playlist title (e.g. work)")
    parser.add_argument("client_name", nargs="?", help="Optional: prefer client with this name")
    args = parser.parse_args()

    token = get_token()
    server_machine_id = plex_identity(token)
    if not server_machine_id:
        print("Could not get Plex server identity.", file=sys.stderr)
        sys.exit(1)

    rating_key, playlist_key, playlist_type = find_playlist(token, args.playlist_name)
    if not rating_key:
        print(f'Playlist "{args.playlist_name}" not found.', file=sys.stderr)
        sys.exit(1)
    container_key = playlist_key if "/items" in playlist_key else f"/playlists/{rating_key}/items"
    media_key = get_playlist_first_item_key(token, playlist_key) or playlist_key

    clients = get_clients(token)
    if not clients:
        print("No Plex clients available. Open the Plex app on the TV (or desired device).", file=sys.stderr)
        sys.exit(1)

    client = None
    if args.client_name:
        name_lower = args.client_name.strip().lower()
        for c in clients:
            if name_lower in (c["name"] or "").lower():
                client = c
                break
    if not client:
        client = clients[0]

    ok = play_media_on_client(
        client["host"], client["port"], client["machineIdentifier"], token,
        server_machine_id, media_key, container_key, playlist_type or "video"
    )
    if ok:
        print(f'Playing playlist "{args.playlist_name}" on {client["name"]}.')
    else:
        print(f'Failed to send play command to {client["name"]}.', file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
