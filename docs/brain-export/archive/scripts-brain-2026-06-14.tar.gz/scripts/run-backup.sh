#!/usr/bin/env bash
# Prichindel.com — backup run (Abelard)
# Run from Abelard workspace: sudo ./scripts/run-backup.sh [--dry-run]
# No secrets in output.

set -euo pipefail
DRY_RUN=false
BACKUP_BASE="${PRICHINDEL_BACKUP_BASE:-/data/backups/prichindel}"
LOG_PREFIX="[prichindel-backup]"

for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=true ;;
  esac
done

run() {
  if "$DRY_RUN"; then
    echo "$LOG_PREFIX [DRY-RUN] $*"
    return 0
  fi
  "$@"
}

echo "$LOG_PREFIX $(date -Iseconds) start"

STAMP=$(date +%Y-%m-%d)
BACKUP_DIR="${BACKUP_BASE}/${STAMP}"
echo "$LOG_PREFIX backup dir: $BACKUP_DIR"
if "$DRY_RUN"; then
  echo "$LOG_PREFIX [DRY-RUN] mkdir -p $BACKUP_DIR"
else
  mkdir -p "$BACKUP_DIR"
fi

# ——— /etc snapshot ———
if ! "$DRY_RUN"; then
  TARBALL="${BACKUP_DIR}/etc-snapshot.tar.gz"
  echo "$LOG_PREFIX config snapshot: $TARBALL"
  tar czf "$TARBALL" -C / etc 2>/dev/null || echo "$LOG_PREFIX config snapshot skipped (permissions or missing)"
else
  echo "$LOG_PREFIX [DRY-RUN] etc-snapshot would be written to $BACKUP_DIR"
fi

# ——— Package list (manifest) ———
if ! "$DRY_RUN"; then
  MANIFEST="${BACKUP_DIR}/dpkg-list.txt"
  echo "$LOG_PREFIX package list: $MANIFEST"
  dpkg -l > "$MANIFEST" 2>/dev/null || echo "$LOG_PREFIX package list skipped"
else
  echo "$LOG_PREFIX [DRY-RUN] dpkg-list would be written to $BACKUP_DIR"
fi

# ——— Unit configs in surveillance (custom systemd units) ———
if ! "$DRY_RUN"; then
  UNIT_TARBALL="${BACKUP_DIR}/unit-configs-surveillance.tar.gz"
  echo "$LOG_PREFIX unit configs (surveillance): $UNIT_TARBALL"
  tar czf "$UNIT_TARBALL" -C / etc/systemd/system 2>/dev/null || echo "$LOG_PREFIX unit-configs skipped (permissions or missing)"
else
  echo "$LOG_PREFIX [DRY-RUN] unit-configs-surveillance would be written to $BACKUP_DIR"
fi

# ——— Services (duties): unit-files and status ———
if ! "$DRY_RUN"; then
  echo "$LOG_PREFIX services (unit-files): $BACKUP_DIR/services-unit-files.txt"
  systemctl list-unit-files --no-pager > "${BACKUP_DIR}/services-unit-files.txt" 2>/dev/null || echo "$LOG_PREFIX services-unit-files skipped"
  echo "$LOG_PREFIX services (status): $BACKUP_DIR/services-status.txt"
  { echo "=== list-units --all ==="; systemctl list-units --all --no-legend --no-pager; echo "=== failed ==="; systemctl list-units --state=failed --no-legend --no-pager; } > "${BACKUP_DIR}/services-status.txt" 2>/dev/null || echo "$LOG_PREFIX services-status skipped"
else
  echo "$LOG_PREFIX [DRY-RUN] services-unit-files and services-status would be written to $BACKUP_DIR"
fi

# ——— Duties manifest (surveillance components at backup time) ———
if ! "$DRY_RUN"; then
  DUTIES="${BACKUP_DIR}/duties-manifest.txt"
  echo "$LOG_PREFIX duties manifest: $DUTIES"
  {
    echo "prichindel.com backup duties manifest"
    echo "date $(date -Iseconds)"
    echo "components: Backups Configs Packages Secrets Services Connectivity"
    echo "source: SURVEILLANCE_AND_DUTIES.md (Abelard workspace: /home/igareosh/cursor)"
  } > "$DUTIES"
else
  echo "$LOG_PREFIX [DRY-RUN] duties-manifest would be written to $BACKUP_DIR"
fi

# ——— Copy to /mnt/act if mounted ———
ACT_MOUNT="${PRICHINDEL_ACT_MOUNT:-/mnt/act}"
if ! "$DRY_RUN"; then
  if mountpoint -q "$ACT_MOUNT" 2>/dev/null; then
    ACT_DEST="${ACT_MOUNT}/prichindel/${STAMP}"
    echo "$LOG_PREFIX copy to $ACT_MOUNT: $ACT_DEST"
    mkdir -p "$ACT_DEST" && cp -a "${BACKUP_DIR}/"* "$ACT_DEST/" 2>/dev/null || echo "$LOG_PREFIX copy to $ACT_MOUNT failed"
  else
    echo "$LOG_PREFIX $ACT_MOUNT not mounted; skip"
  fi
else
  echo "$LOG_PREFIX [DRY-RUN] would copy to $ACT_MOUNT if mounted"
fi

# ——— Copy to Proton backup dir if present (/data/proton_backup) ———
PROTON_BACKUP="${PRICHINDEL_PROTON_BACKUP:-/data/proton_backup/prichindel}"
if ! "$DRY_RUN"; then
  if [[ -d "$PROTON_BACKUP" ]]; then
    PROTON_DEST="${PROTON_BACKUP}/${STAMP}"
    echo "$LOG_PREFIX copy to Proton backup: $PROTON_DEST"
    mkdir -p "$PROTON_DEST" && cp -a "${BACKUP_DIR}/"* "$PROTON_DEST/" 2>/dev/null || echo "$LOG_PREFIX copy to Proton backup failed"
  else
    echo "$LOG_PREFIX $PROTON_BACKUP not present; skip (rclone mount or manual)"
  fi
else
  echo "$LOG_PREFIX [DRY-RUN] would copy to $PROTON_BACKUP if present"
fi

echo "$LOG_PREFIX $(date -Iseconds) end"
