#!/usr/bin/env bash
# Refresh OpenSSH known_hosts for prod prichindel (.21 / .23) after VM cutover.
# Run from alunel or any LAN host with SSH to cluster nodes.
set -euo pipefail

HOSTS=(
  192.168.100.21
  192.168.100.23
)

TARGETS=(
  igareosh@192.168.100.62
  igareosh@192.168.100.25
  igareosh@192.168.100.67
  igareosh@192.168.100.58
  igareosh@192.168.100.21
)

log() { echo "[hostkeys] $*"; }

refresh_local() {
  local kh="${HOME}/.ssh/known_hosts"
  install -d -m 700 "${HOME}/.ssh"
  touch "$kh"
  for ip in "${HOSTS[@]}"; do
    ssh-keygen -f "$kh" -R "$ip" 2>/dev/null || true
  done
  ssh-keyscan -H "${HOSTS[@]}" >>"$kh" 2>/dev/null || true
  log "local known_hosts updated"
}

refresh_remote() {
  local target=$1
  ssh -o BatchMode=yes -o ConnectTimeout=8 "$target" "bash -s" <<'REMOTE'
set -euo pipefail
kh="${HOME}/.ssh/known_hosts"
install -d -m 700 "${HOME}/.ssh"
touch "$kh"
for ip in 192.168.100.21 192.168.100.23; do
  ssh-keygen -f "$kh" -R "$ip" 2>/dev/null || true
done
ssh-keyscan -H 192.168.100.21 192.168.100.23 >>"$kh" 2>/dev/null || true
echo ok
REMOTE
}

main() {
  refresh_local
  for t in "${TARGETS[@]}"; do
    if refresh_remote "$t" 2>/dev/null; then
      log "$t OK"
    else
      log "$t skip (unreachable or no key)"
    fi
  done
  log "DONE — LAMAITA/Windows: run ssh-keygen -R 192.168.100.21 on laptop if SSH warns"
}

main "$@"
