#!/usr/bin/env python3
"""IM-IRC-T20 — OpenAI smoke (no MCP): one completion; cid in system text; stdout only."""
from __future__ import annotations

import os
import sys
import uuid


def main() -> int:
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        print("OPENAI_API_KEY unset", file=sys.stderr)
        return 2
    try:
        from openai import OpenAI
    except ImportError:
        print("pip install openai", file=sys.stderr)
        return 3
    cid = str(uuid.uuid4())
    client = OpenAI(api_key=key)
    r = client.chat.completions.create(
        model=os.environ.get("IMIRC_OPENAI_MODEL", "gpt-4o-mini"),
        messages=[
            {"role": "system", "content": f"Correlation id {cid}. Reply with pong and the cid."},
            {"role": "user", "content": "smoke test"},
        ],
        max_tokens=80,
    )
    text = (r.choices[0].message.content or "").strip()
    print(f"cid={cid}\nreply={text}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
