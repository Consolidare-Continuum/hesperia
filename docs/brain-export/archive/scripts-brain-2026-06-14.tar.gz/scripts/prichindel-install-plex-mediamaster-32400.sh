#!/usr/bin/env bash
# Install external Plex path: prichindel :32400 → mediamaster 192.168.100.64:32400
# Run on prichindel (or: ssh prichindel 'sudo bash -s' < scripts/prichindel-install-plex-mediamaster-32400.sh)
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STREAM_SRC="${REPO_ROOT}/cluster/prichindel/nginx-stream-plex-mediamaster.conf"
HTTP_SRC="${REPO_ROOT}/cluster/prichindel/nginx-mediamaster.prichindel.com.conf"
SNIPPET="${REPO_ROOT}/cluster/prichindel/ufw-before.rules.d/plex-32400-mediamaster.snippet"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run as root on prichindel (sudo)." >&2
  exit 1
fi

if [[ ! -f "${STREAM_SRC}" ]]; then
  echo "Missing ${STREAM_SRC}" >&2
  exit 1
fi

# --- nginx stream (primary path for :32400) ---
mkdir -p /etc/nginx/stream.d
cp -a "${STREAM_SRC}" /etc/nginx/stream.d/plex-mediamaster.conf

if ! grep -q 'include /etc/nginx/stream.d/\*\.conf' /etc/nginx/nginx.conf 2>/dev/null; then
  if grep -q '^stream {' /etc/nginx/nginx.conf 2>/dev/null; then
    sed -i '/^stream {/a\    include /etc/nginx/stream.d/*.conf;' /etc/nginx/nginx.conf
  else
    cat >>/etc/nginx/nginx.conf <<'NGINX_STREAM'

stream {
    include /etc/nginx/stream.d/*.conf;
}
NGINX_STREAM
  fi
fi

# HTTPS vhost for mediamaster.prichindel.com (Authentik wall → :80 on VM)
if [[ -f "${HTTP_SRC}" ]]; then
  cp -a "${HTTP_SRC}" /etc/nginx/sites-available/mediamaster.prichindel.com.conf
  ln -sf /etc/nginx/sites-available/mediamaster.prichindel.com.conf \
    /etc/nginx/sites-enabled/mediamaster.prichindel.com.conf
fi

nginx -t
systemctl reload nginx

# --- UFW: allow inbound 32400 on prichindel (router hits .21/.23) ---
ufw allow 32400/tcp comment 'Plex WAN → nginx stream → mediamaster' 2>/dev/null || true

# --- Optional DNAT in before.rules (only if snippet lines not already present) ---
if [[ -f "${SNIPPET}" ]] && [[ -f /etc/ufw/before.rules ]]; then
  if ! grep -q '192.168.100.64:32400' /etc/ufw/before.rules; then
    cp -a /etc/ufw/before.rules "/etc/ufw/before.rules.bak.plex32400.$(date +%Y%m%d%H%M%S)"
    echo "NOTE: Add lines from ${SNIPPET} into *nat and *filter sections of /etc/ufw/before.rules, then: ufw reload"
    echo "      Skipping auto-merge — use nginx stream unless you require kernel DNAT."
  fi
fi

# --- sysctl forward (needed for DNAT path; harmless for nginx stream) ---
sysctl -w net.ipv4.ip_forward=1
grep -q '^net.ipv4.ip_forward=1' /etc/sysctl.d/99-tailscale-ipforward.conf 2>/dev/null || \
  echo 'net.ipv4.ip_forward=1' >>/etc/sysctl.d/99-tailscale-ipforward.conf

echo "--- verify ---"
ss -tlnp | grep ':32400' || true
nc -zv -w3 192.168.100.64 32400 || true
echo "DONE: Plex stream on .21/.23:32400 → 192.168.100.64:32400"
