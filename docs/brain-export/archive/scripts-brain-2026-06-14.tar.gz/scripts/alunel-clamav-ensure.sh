#!/usr/bin/env bash
# alunel — idempotent ClamAV install + DB bootstrap + enable units (run on alunel with sudo).
# Ref: cluster/alunel/CLAMAV.md
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq || true
apt-get install -y clamav-daemon clamav-freshclam clamdscan

systemctl stop clamav-daemon.service clamav-daemon.socket 2>/dev/null || true

if ! compgen -G "/var/lib/clamav/main.cvd" >/dev/null && ! compgen -G "/var/lib/clamav/main.cld" >/dev/null; then
  echo "Downloading initial signature databases (freshclam)…"
  freshclam
fi
# Ongoing updates: clamav-freshclam-once.timer (daily). Run `sudo freshclam` anytime for a manual pull.

systemctl enable clamav-daemon.socket clamav-daemon.service
systemctl enable clamav-freshclam-once.timer
systemctl start clamav-daemon.socket
systemctl start clamav-daemon.service
systemctl start clamav-freshclam-once.timer

echo "OK: ClamAV daemon + daily freshclam timer."
systemctl is-active clamav-daemon.socket clamav-daemon.service
systemctl is-enabled clamav-freshclam-once.timer
