#!/usr/bin/env bash
# alunel — stop OS fan daemon; verify W83795 thermal-cruise state; set quiet governor.
# Run: sudo bash scripts/alunel-fan-passive.sh
#
# WARNING: DO NOT write pwm2_enable=1 or any value to pwm2 sysfs on this host.
# W83795 pwm2 must stay in thermal-cruise mode (pwm2_enable=3).
# Writing pwm2_enable=1 clears TFMR registers → BIOS override → 3000 RPM.
# Use scripts/alunel-w83795-guard.sh to verify/restore if needed.
set -euo pipefail

if [[ "$(id -u)" -ne 0 ]]; then
  echo "alunel-fan-passive: run as root (sudo)" >&2
  exit 1
fi

W83795_DEV="pci0000:00/0000:00:1f.3/i2c-0/0-002f"
PWM_SYSFS="/sys/devices/${W83795_DEV}"

systemctl stop alunel-fan-cpu-quiet.service 2>/dev/null || true
systemctl disable alunel-fan-cpu-quiet.service 2>/dev/null || true

modprobe w83795 2>/dev/null || true

# pwm1 (CPU fans / FAN1-FAN2 headers, currently empty) — manual is fine.
# DO NOT touch pwm2 or pwm2_enable — pwm2 controls FAN3-FAN8 via thermal cruise.
if [[ -d "$PWM_SYSFS" && -f "${PWM_SYSFS}/pwm1" ]]; then
  echo 1 >"${PWM_SYSFS}/pwm1_enable" 2>/dev/null || true
  echo 0 >"${PWM_SYSFS}/pwm1" 2>/dev/null || true
fi

if [[ -d /sys/devices/system/cpu/cpu0/cpufreq ]]; then
  for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [[ -f "$g" ]] && echo schedutil >"$g" 2>/dev/null || true
  done
fi

mkdir -p /etc/alunel
date -Iseconds > /etc/alunel/fan-passive-mode.txt
echo "policy=w83795_thermal_cruise os_daemon=disabled governor=schedutil" >> /etc/alunel/fan-passive-mode.txt

echo "=== alunel fan passive (W83795 thermal cruise owns FAN3-FAN8) ==="
systemctl is-enabled alunel-fan-cpu-quiet.service 2>&1 || true
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || true
if command -v sensors >/dev/null; then
  sensors w83795adg-i2c-0-2f 2>/dev/null | grep -E 'fan[24678]:|pwm1:|pwm2:|temp1:|intrusion' || true
fi
echo "--- pwm2_enable (must be 3=thermal cruise) ---"
cat "${PWM_SYSFS}/pwm2_enable" 2>/dev/null || echo 'N/A'
echo "marker: /etc/alunel/fan-passive-mode.txt"
echo "To verify/restore thermal cruise: sudo bash scripts/alunel-w83795-guard.sh status"
