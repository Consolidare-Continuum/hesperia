"""trustmaster: ProxyProvider + Application for even.prichindel.com (nginx forward-auth / outpost).
Run: docker exec -i authentik-server-1 ak shell < scripts/trustmaster_authentik_proxy_even_minio.py
"""
from authentik.core.models import Application
from authentik.policies.models import PolicyBinding
from authentik.providers.oauth2.models import RedirectURI
from authentik.providers.proxy.models import ProxyProvider

APP_SLUG = "even-minio-console"
PROVIDER_NAME = "even-minio-console-proxy"
EVEN = "https://even.prichindel.com"
CF_CB = "https://prichindel.cloudflareaccess.com/cdn-cgi/access/callback"

base = ProxyProvider.objects.get(pk=1)
papra_app = Application.objects.get(slug="shetiyya-papra")

if Application.objects.filter(slug=APP_SLUG).exists():
    print("EXISTS", APP_SLUG)
    raise SystemExit(0)

np = ProxyProvider.objects.create(
    name=PROVIDER_NAME,
    authorization_flow=base.authorization_flow,
    authentication_flow=base.authentication_flow,
    invalidation_flow=base.invalidation_flow,
    client_type=base.client_type,
    mode=base.mode,
    external_host=EVEN,
    internal_host=EVEN,
    internal_host_ssl_validation=True,
    intercept_header_auth=base.intercept_header_auth,
    skip_path_regex=base.skip_path_regex,
    basic_auth_enabled=False,
    redirect_uris=[
        RedirectURI(
            url=f"{EVEN}/outpost.goauthentik.io/callback?X-authentik-auth-callback=true",
            matching_mode="strict",
        ),
        RedirectURI(url=f"{EVEN}?X-authentik-auth-callback=true", matching_mode="strict"),
        RedirectURI(url=CF_CB, matching_mode="strict"),
    ],
    logout_uri=f"{EVEN}/",
    logout_method=base.logout_method,
    include_claims_in_id_token=base.include_claims_in_id_token,
    access_code_validity=base.access_code_validity,
    access_token_validity=base.access_token_validity,
    refresh_token_validity=base.refresh_token_validity,
    refresh_token_threshold=base.refresh_token_threshold,
    sub_mode=base.sub_mode,
    issuer_mode=base.issuer_mode,
)
np.property_mappings.set(base.property_mappings.all())

app = Application.objects.create(
    name="MinIO Console — even.prichindel.com",
    slug=APP_SLUG,
    provider=np,
    meta_launch_url=EVEN,
    meta_description="MinIO admin — nginx forward-auth + Cloudflare Access.",
)

for b in PolicyBinding.objects.filter(target=papra_app):
    PolicyBinding.objects.create(
        order=b.order,
        target=app,
        policy=b.policy,
        group=b.group,
        user=b.user,
    )

print("CREATED_PROXY_APP", APP_SLUG, "provider_pk", np.pk, "client_id", np.client_id)
