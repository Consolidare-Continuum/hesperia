#!/usr/bin/env bash
# Apply alunel boot-order fixes: systemd units, VM startup order, tunnel key.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ALUNEL="${ALUNEL_SSH:-igareosh@192.168.100.62}"
SSH=(ssh -o BatchMode=yes -o ConnectTimeout=15 ${SSH_OPTS:-} "$ALUNEL")
SCP=(scp -q -o BatchMode=yes -o ConnectTimeout=15 ${SSH_OPTS:-})

remote() { "${SSH[@]}" "$@"; }
remote_sudo() { "${SSH[@]}" "sudo $*"; }

echo "==> alunel: copy systemd units + scripts"
TMP=/tmp/alunel-fix-$$
remote "mkdir -p $TMP"
"${SCP[@]}" \
  "$REPO_ROOT/cluster/alunel/systemd/alunel-tailscale-exit-de-fra.service" \
  "$REPO_ROOT/cluster/alunel/systemd/alunel-w83795-guard.service" \
  "$REPO_ROOT/cluster/alunel/systemd/alunel-nginx-after-tailscale.service" \
  "$REPO_ROOT/cluster/alunel/systemd/hesperia-analyze-dev.service" \
  "$REPO_ROOT/cluster/alunel/systemd/nginx-override.conf" \
  "$REPO_ROOT/cluster/alunel/nginx-alunel.prichindel.com.conf.template" \
  "$REPO_ROOT/scripts/alunel-nginx-render-vhost.sh" \
  "$REPO_ROOT/scripts/alunel-nginx-wait-tailscale.sh" \
  "$REPO_ROOT/scripts/alunel-w83795-guard.sh" \
  "$ALUNEL:$TMP/"

remote_sudo "mkdir -p /data/hesperia/reflection /data/hesperia/ksi
  chown igareosh:igareosh /data/hesperia/reflection /data/hesperia/ksi
  cp $TMP/hesperia-analyze-dev.service /etc/systemd/system/
  systemctl daemon-reload
  systemctl enable hesperia-analyze-dev.service
  systemctl restart hesperia-analyze-dev.service || true
  cp $TMP/alunel-tailscale-exit-de-fra.service /etc/systemd/system/
  cp $TMP/alunel-w83795-guard.service /etc/systemd/system/
  cp $TMP/alunel-nginx-after-tailscale.service /etc/systemd/system/
  mkdir -p /etc/nginx/templates
  cp $TMP/nginx-alunel.prichindel.com.conf.template /etc/nginx/templates/alunel.prichindel.com.conf.template
  install -m 755 $TMP/alunel-nginx-render-vhost.sh /usr/local/sbin/alunel-nginx-render-vhost.sh
  install -m 755 $TMP/alunel-nginx-wait-tailscale.sh /usr/local/sbin/alunel-nginx-wait-tailscale.sh
  install -m 755 $TMP/alunel-w83795-guard.sh /usr/local/sbin/alunel-w83795-guard.sh
  mkdir -p /etc/systemd/system/nginx.service.d
  cp $TMP/nginx-override.conf /etc/systemd/system/nginx.service.d/override.conf
  /usr/local/sbin/alunel-nginx-render-vhost.sh
  systemctl daemon-reload
  systemctl enable alunel-nginx-after-tailscale.service alunel-tailscale-exit-de-fra.service alunel-w83795-guard.service
  systemctl restart alunel-tailscale-exit-de-fra.service || true
  systemctl start alunel-nginx-after-tailscale.service || true
  systemctl restart alunel-w83795-guard.service || true
  rm -rf $TMP"

echo "==> alunel: VM startup order (dnsmaster → chronomaster → prod)"
remote_sudo "qm set 106 -onboot 1 -startup order=1,up=15
  qm set 100 -onboot 1 -startup order=2,up=15
  qm set 107 -startup order=5,up=30
  qm set 103 -startup order=8,up=20
  qm set 104 -startup order=8,up=20
  qm set 102 -onboot 1 -startup order=10,up=20
  qm set 101 -onboot 1 -startup order=12,up=10
  qm set 105 -startup order=12,up=10"

echo "==> prichindel VM: authorize alunel gate tunnel key"
GATE_PUB="$(remote 'cat ~/.ssh/id_ed25519_gate_tunnel.pub')"
ssh -o BatchMode=yes -o ConnectTimeout=15 prichindel \
  "grep -Fq '${GATE_PUB}' ~/.ssh/authorized_keys 2>/dev/null || echo '${GATE_PUB}' >> ~/.ssh/authorized_keys; chmod 600 ~/.ssh/authorized_keys"

echo "==> alunel: restart tunnel + verify"
remote "systemctl restart alunel-prichindel-local-forwards.service 2>/dev/null || true
  systemctl restart alunel-vaporas-gate-tunnels.service 2>/dev/null || true
  systemctl restart alunel-trustmaster-access-tunnels.service 2>/dev/null || true
  sleep 4
  echo nginx=\$(systemctl is-active nginx)
  echo tailscale-exit=\$(systemctl is-active alunel-tailscale-exit-de-fra)
  echo w83795=\$(systemctl is-active alunel-w83795-guard)
  echo local-forwards=\$(systemctl is-active alunel-prichindel-local-forwards)
  curl -sk -o /dev/null -w 'pve-ui:%{http_code}\n' --resolve alunel.prichindel.com:443:192.168.100.62 https://alunel.prichindel.com/ || true"

echo "DONE alunel-post-boot-fixups"
