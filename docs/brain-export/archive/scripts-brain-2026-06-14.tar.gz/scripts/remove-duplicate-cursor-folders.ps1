# Remove duplicate cursor folders cluster-wide (Windows). One source = Proton Drive main folder.
# Run on CERES and olgahere. Force-removes known legacy/duplicate paths only.
# Usage: powershell -ExecutionPolicy Bypass -File .\scripts\remove-duplicate-cursor-folders.ps1 [-WhatIf]
# Canonical: CERES = C:\Users\igare\Proton Drive\igareosh\My files\cursor ; olgahere = C:\Users\Olga\Proton Drive\igareosh\My files\cursor

param([switch]$WhatIf)

$ErrorActionPreference = 'Continue'
$canonicalCERES   = 'C:\Users\igare\Proton Drive\igareosh\My files\cursor'
$canonicalOlgahere = 'C:\Users\Olga\Proton Drive\igareosh\My files\cursor'

# Paths to remove (duplicates / legacy) — do not add canonical paths
$toRemove = @(
    'C:\ceres_proton_drive\cursor',
    'C:\backup\cursor',
    (Join-Path $env:USERPROFILE 'Proton Drive\igareosh\Other computers\CERES\ceres_proton_drive\cursor')
)

foreach ($path in $toRemove) {
    if (-not (Test-Path -LiteralPath $path)) { continue }
    if ($path -eq $canonicalCERES -or $path -eq $canonicalOlgahere) { continue }
    try {
        if ($WhatIf) {
            Write-Host "WhatIf: would remove: $path"
        } else {
            Remove-Item -LiteralPath $path -Recurse -Force
            Write-Host "Removed: $path"
        }
    } catch {
        Write-Warning "Failed to remove $path : $_"
    }
}
Write-Host "Done. Canonical only: CERES $canonicalCERES ; olgahere $canonicalOlgahere"
