#!/usr/bin/env bash
# Lightweight backup for prichindel: configs, cursor workspace, package state.
# No huge GB: no full /etc, no DB dumps, no Docker images.
# Output: /data/backups/prichindel/<date>/ and optionally /data/proton_backup/prichindel/backups/<date>/

set -euo pipefail
DATE=$(date +%Y-%m-%d)
LOCAL_BASE="/data/backups/prichindel"
REMOTE_BASE="/data/proton_backup/prichindel/backups"
LOCAL_DIR="${LOCAL_BASE}/${DATE}"
REMOTE_DIR="${REMOTE_BASE}/${DATE}"

mkdir -p "$LOCAL_DIR"
cd "$LOCAL_DIR"

# --- 1. Configs tarball (nginx, apache, cloudflared, systemd, ssl, postfix, clamav, Docker: superset, prometheus, php, dbs) ---
CONFIG_TAR="configs.tar.gz"
TMP_CONFIGS=$(mktemp -d)
trap "rm -rf '$TMP_CONFIGS'" EXIT

sudo cp -a /etc/nginx "$TMP_CONFIGS/" 2>/dev/null || true
sudo cp -a /etc/apache2 "$TMP_CONFIGS/" 2>/dev/null || true
sudo cp -a /etc/cloudflared "$TMP_CONFIGS/" 2>/dev/null || true
sudo cp -a /etc/ssl/cloudflare "$TMP_CONFIGS/" 2>/dev/null || true
mkdir -p "$TMP_CONFIGS/postfix" "$TMP_CONFIGS/clamav"
sudo cp /etc/postfix/main.cf "$TMP_CONFIGS/postfix/" 2>/dev/null || true
sudo cp /etc/clamav/clamd.conf /etc/clamav/freshclam.conf "$TMP_CONFIGS/clamav/" 2>/dev/null || true
# Docker: /data/docker/{php81,databases,prometheus,superset}
sudo cp -a /data/docker/prometheus/config "$TMP_CONFIGS/prometheus_config" 2>/dev/null || true
sudo cp /data/docker/prometheus/docker-compose.yml "$TMP_CONFIGS/prometheus-compose.yml" 2>/dev/null || true
sudo cp /data/docker/php81/docker-compose.yml "$TMP_CONFIGS/docker-php81-compose.yml" 2>/dev/null || true
sudo cp /data/docker/databases/docker-compose.yml "$TMP_CONFIGS/docker-databases-compose.yml" 2>/dev/null || true
sudo cp /data/docker/databases/.env "$TMP_CONFIGS/docker-databases.env" 2>/dev/null || true
sudo cp /data/docker/superset/docker-compose-non-dev.yml "$TMP_CONFIGS/superset-compose.yml" 2>/dev/null || true
sudo cp -a /data/docker/superset/config "$TMP_CONFIGS/superset_config" 2>/dev/null || true
sudo cp /data/docker/superset/docker/.env "$TMP_CONFIGS/superset-docker.env" 2>/dev/null || true

# Surveilled systemd units
for u in acc cloudflared cloudflared-gradina cloudflared-gradina1 protonmail-bridge rclone-proton-backup; do
  sudo cp "/etc/systemd/system/${u}.service" "$TMP_CONFIGS/systemd-${u}.service" 2>/dev/null || true
  sudo [ -d "/etc/systemd/system/${u}.service.d" ] && sudo cp -a "/etc/systemd/system/${u}.service.d" "$TMP_CONFIGS/systemd-${u}.service.d" 2>/dev/null || true
done

sudo chown -R "$(whoami):" "$TMP_CONFIGS"
tar czf "$CONFIG_TAR" -C "$TMP_CONFIGS" .
echo "[+] Wrote $LOCAL_DIR/$CONFIG_TAR"

# --- 2. Cursor workspace (docs only, small) ---
tar czf cursor-workspace.tar.gz -C /data/workspaces cursor 2>/dev/null || true
echo "[+] Wrote $LOCAL_DIR/cursor-workspace.tar.gz"

# --- 3. Package state (text, tiny) ---
dpkg --get-selections > dpkg-selections.txt 2>/dev/null || true
apt-mark showmanual > apt-manual.txt 2>/dev/null || true
snap list > snap-list.txt 2>/dev/null || true
echo "[+] Wrote package state files"

# --- 4. Optional: rclone config (sensitive; owner only) ---
if [ -f "$HOME/.config/rclone/rclone.conf" ]; then
  cp "$HOME/.config/rclone/rclone.conf" "$LOCAL_DIR/rclone.conf.bak" 2>/dev/null && chmod 600 "$LOCAL_DIR/rclone.conf.bak" && echo "[+] Wrote rclone.conf.bak (sensitive)"
fi

# --- 5. Fulgusor: Plex Preferences.xml (contains auth token) ---
PLEX_PREFS_REMOTE="/var/lib/plexmediaserver/Library/Application Support/Plex Media Server/Preferences.xml"
if ssh -o ConnectTimeout=5 fulgusor "test -f '$PLEX_PREFS_REMOTE'" 2>/dev/null; then
  ssh fulgusor "sudo cat '$PLEX_PREFS_REMOTE'" > "$LOCAL_DIR/fulgusor-plex-Preferences.xml" 2>/dev/null && chmod 600 "$LOCAL_DIR/fulgusor-plex-Preferences.xml" && echo "[+] Wrote fulgusor-plex-Preferences.xml (sensitive)" || echo "[!] Could not fetch Plex Preferences.xml from fulgusor"
else
  echo "[!] Fulgusor unreachable or Plex not installed; skipping Plex backup"
fi

# --- 6. Copy to Proton Drive if mounted ---
if [ -d /data/proton_backup/prichindel ]; then
  mkdir -p "$REMOTE_DIR"
  cp -a "$LOCAL_DIR"/* "$REMOTE_DIR/" 2>/dev/null && echo "[+] Synced to $REMOTE_DIR" || echo "[!] Could not sync to Proton (mount ok?)"
else
  echo "[!] Proton Drive not mounted; local only: $LOCAL_DIR"
fi

echo "[✓] Lightweight backup done: $LOCAL_DIR"
