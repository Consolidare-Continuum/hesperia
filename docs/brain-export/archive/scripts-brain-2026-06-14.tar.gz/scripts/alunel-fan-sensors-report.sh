#!/usr/bin/env bash
# alunel — W83795 fan/PWM report (no secrets). Run on alunel: bash scripts/alunel-fan-sensors-report.sh
set -euo pipefail
modprobe w83795 2>/dev/null || true
modprobe jc42 2>/dev/null || true
D=/sys/devices/pci0000:00/0000:00:1f.3/i2c-0/0-002f
echo "=== $(hostname -s) fans $(date -Iseconds) ==="
if command -v sensors >/dev/null; then
  sensors 2>/dev/null | grep -E '^fan|^pwm' || sensors
else
  echo "lm-sensors not installed"
fi
if [ -d "$D" ]; then
  echo "--- pwm sysfs ---"
  for i in 1 2; do
    [ -f "$D/pwm$i" ] && printf "pwm%d=%s enable=%s\n" "$i" "$(cat "$D/pwm$i")" "$(cat "$D/pwm${i}_enable" 2>/dev/null)"
  done
  echo "(fan4/fan8 RPM unchanged when pwm2 changes => rewire PWM pin; see cluster/alunel/FANS-W83795.md)"
fi
