#!/usr/bin/env bash
# Deploy CHROMA-1 (team canonical) on alunel.
set -euo pipefail
REPO="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO"

if ! command -v docker >/dev/null 2>&1; then
  echo "Installing docker.io..."
  sudo apt-get update -qq
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y docker.io
  sudo systemctl enable --now docker
fi

sudo mkdir -p /data/chroma/data /data/chroma/migration/export
sudo chown -R igareosh:igareosh /data/chroma

if [[ ! -x /data/chroma/venv/bin/python3 ]]; then
  python3 -m venv /data/chroma/venv
  /data/chroma/venv/bin/pip install -U pip
  /data/chroma/venv/bin/pip install "chromadb==0.6.3" uvicorn fastapi sentence-transformers pysqlite3-binary
fi

sudo cp "$REPO/cluster/alunel/chroma/chroma-1-docker.service" /etc/systemd/system/
sudo cp "$REPO/cluster/alunel/chroma/chroma-1-query-api.service" /etc/systemd/system/
if [[ -f "$REPO/cluster/chroma-server/chroma-new-metrics.service" ]]; then
  sudo sed 's|/data/workspaces/cursor|/data/workspaces/cursor|g' \
    "$REPO/cluster/chroma-server/chroma-new-metrics.service" \
    | sudo sed 's/chroma-new-metrics/chroma-1-metrics/g' \
    | sudo tee /etc/systemd/system/chroma-1-metrics.service >/dev/null
fi

sudo systemctl disable chroma-new-docker chroma-query-api chroma 2>/dev/null || true
sudo systemctl stop chroma-new-docker chroma-query-api chroma 2>/dev/null || true

sudo systemctl daemon-reload
sudo systemctl enable chroma-1-docker chroma-1-query-api
sudo systemctl restart chroma-1-docker
sleep 3
curl -sf http://127.0.0.1:8002/api/v2/heartbeat
echo ""
sudo systemctl restart chroma-1-query-api || true
echo "OK: CHROMA-1 on alunel"
