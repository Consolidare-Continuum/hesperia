#!/usr/bin/env bash
# CHROMA-2 preflight — fail closed before restart/migration. Ref: SPEC-ETHAN-CHROMA-2-LIBRARYMASTER-PRODUCTION.md
set -euo pipefail

HOST="${CHROMA2_HOST:-librarymaster}"
URL="${CHROMA_SERVER_URL:-http://chroma-2.prichindel.local:8002}"
DATA_DIR="${CHROMA2_DATA_DIR:-/data/chroma-2/data}"
VENV="${CHROMA2_VENV:-/data/chroma-2/venv}"
UNIT="${CHROMA2_UNIT:-chroma-2-docker.service}"

fail() { echo "CHROMA-2 PREFLIGHT FAIL: $*" >&2; exit 1; }
ok() { echo "CHROMA-2 PREFLIGHT OK: $*"; }

run_lm() {
  if [[ "$(hostname -s 2>/dev/null || true)" == "librarymaster" ]]; then
    bash -c "$1"
  else
    ssh -o BatchMode=yes "$HOST" "$1"
  fi
}

echo "=== CHROMA-2 persist verify (librarymaster) ==="

run_lm "grep '^ExecStart=' /etc/systemd/system/${UNIT} | grep -q '/data/chroma-2/data:/data'" \
  || fail "ExecStart missing /data/chroma-2/data:/data bind."

run_lm "grep '^ExecStart=' /etc/systemd/system/${UNIT} | grep -q '192.168.100.66:8002'" \
  || fail "ExecStart missing LAN bind 192.168.100.66:8002."

run_lm "! grep '^ExecStart=' /etc/systemd/system/${UNIT} | grep -q 'chroma-alunel'" \
  || fail "ExecStart still references deprecated chroma-alunel path."

if ! curl -sf "${URL}/api/v2/heartbeat" >/dev/null 2>&1; then
  fail "heartbeat unreachable at ${URL}"
fi

CHUNKS=$(run_lm "${VENV}/bin/python -c \"import chromadb; c=chromadb.HttpClient(host='127.0.0.1', port=8002); cols=c.list_collections(); print(c.get_collection('documents').count() if cols else 0)\"" 2>/dev/null || echo 0)
DATASZ=$(run_lm "du -sb '${DATA_DIR}' 2>/dev/null | awk '{print \$1}'" || echo 0)

echo "chunk_count=${CHUNKS} data_dir_bytes=${DATASZ}"

MOUNT=$(run_lm "docker inspect chroma-2 --format '{{range .Mounts}}{{if eq .Destination \"/data\"}}{{.Source}}{{end}}{{end}}' 2>/dev/null" || echo "")
echo "docker_persist_mount=${MOUNT:-unknown}"

if [[ -n "${MOUNT}" && "${MOUNT}" != "/data/chroma-2/data" ]]; then
  fail "container /data mount is ${MOUNT}, expected /data/chroma-2/data"
fi

if [[ "${CHUNKS}" -gt 1000 && "${DATASZ}" -lt 1000000 ]]; then
  fail "chunk_count high (${CHUNKS}) but data_dir tiny (${DATASZ} bytes) — index likely ephemeral; STOP."
fi

ok "heartbeat chunk_count=${CHUNKS} data_dir=${DATASZ} bytes librarymaster_paths_ok"
