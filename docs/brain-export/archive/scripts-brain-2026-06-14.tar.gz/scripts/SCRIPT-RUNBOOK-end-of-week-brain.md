---
task_id: "cursor-repo|eow|weekly-brain"
active_md_anchor: "| REPO-EOW |"
---

# Script runbook — End-of-week brain workflow (EOW)

**Purpose**: Weekly **~50-row integration pass** — **execution, pathing, awareness**; not artifact churn. Mandatory when operator invokes **EOW**.

**Spec**: [governance/SPEC-ETHAN-END-OF-WEEK-BRAIN-WORKFLOW.md](../governance/SPEC-ETHAN-END-OF-WEEK-BRAIN-WORKFLOW.md)  
**Workflow**: [.cursor/END-OF-WEEK-WORKFLOW.md](../.cursor/END-OF-WEEK-WORKFLOW.md)  
**Care mandate**: [.cursor/EOW-CARE-MANDATE.md](../.cursor/EOW-CARE-MANDATE.md)

**New brain files**: only new brain **function** or Cursor **autoupdate wiring** — not weekly prose.

---

## When to use (mandatory)

| Trigger | Action |
|---------|--------|
| **EOW**, **weekly brain**, scheduled Sunday UTC | Full EOW workflow |
| Operator: brain repo care / ~50 repo tasks | Research → triage → until DONE |

---

## Flow (canonical)

```bash
# 1. Collect + research (generates 50 tasks)
bash scripts/end_of_week_run.sh full

# 2. Grace triage → active.md (REPO-EOW-{ww}-001..050)
#    Register: operational/assignments/reports/EOW-TASK-REGISTER-YYYY-Www.md

# 3. Mechanical pass + per-row owner execution
bash scripts/end_of_week_run.sh execute

# 4. Loop until zero OPEN REPO-EOW
bash scripts/end_of_week_run.sh until-done

# 5. Closure report, commit/push

# 6. Chroma (alunel — Abelard path)
ssh alunel 'cd /data/workspaces/cursor && git pull --rebase origin main && \
  export CHROMA_SERVER_URL=http://127.0.0.1:8002 && \
  bash cluster/chroma-server/ingest-whole-repo.sh'

# 7. Telegram
bash scripts/tersagor-operator-notify.sh -t "Brain repo EOW" --source "Cursor" \
  "REPO-EOW YYYY-Www: N/50 DONE. See REPO-EOW-WAVE-CLOSURE-YYYY-Www.md"
```

---

## Task model

| Item | Value |
|------|-------|
| Count | **50** = 5 × 10 team entities |
| Generation | `python3 scripts/end_of_week_research.py` |
| IDs | `REPO-EOW-{ww}-001..050` |
| Static register | **No** — [REPO-AUTO-2026-REGISTER.md](../governance/REPO-AUTO-2026-REGISTER.md) is bootstrap only |

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| OPEN rows remain | Cursor continues owner CSP execution; re-run `until-done` |
| alunel `git pull` blocked | stash/clean alunel clone; re-ingest |
| MCP drift | `deploy-mcp-config-global.sh`; restart Cursor |
| Telegram fail | [SCRIPT-RUNBOOK-tersagor-operator-notify.md](SCRIPT-RUNBOOK-tersagor-operator-notify.md) |

---

SIGNED: Architecture (Ethan) | EOW runbook | 2026-05-31 | dynamic 5×10 + until-done
