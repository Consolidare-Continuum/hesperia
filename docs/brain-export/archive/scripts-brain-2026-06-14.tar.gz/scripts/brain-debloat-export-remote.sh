#!/usr/bin/env bash
# Export brain Hesperia/Tersagor content to dev repos on alunel (remote phase).
set -euo pipefail
BRAIN="${1:?brain path}"
ALUNEL="${2:-alunel}"
HES="/data/workspaces/atomic-commit-hesperia/docs/brain-export"
TER="/data/workspaces/tersagor/docs/brain-export"
STAMP="$(date -u +%Y-%m-%dT%H%MZ)"

ssh "$ALUNEL" "mkdir -p $HES/{operational,governance,cluster,root,scripts,CLIENTS/hesperia} $TER/{operational,governance,scripts,cluster-prichindel,cluster-tersagor,github-workflows,cursor-rules}"

cd "$BRAIN"

# Hesperia operational
if compgen -G "operational/**/*[Hh]esperia*" > /dev/null || find operational -iname '*hesperia*' -print -quit | grep -q .; then
  find operational -iname '*hesperia*' -print0 | tar cf - --null -T - | ssh "$ALUNEL" "cd $HES && tar xf -"
fi

# Hesperia governance (except policy trio)
find governance -iname '*hesperia*' ! -name 'ETHAN-POLICY-HESPERIA-*' -print0 | tar cf - --null -T - | ssh "$ALUNEL" "cd $HES && tar xf -"

# Cluster hesperia
for p in cluster/hesperia cluster/tersagor-h063 cluster/hesperia-api.service cluster/hesperia.prichindel.com.conf \
  cluster/alunel/systemd/hesperia-analyze-dev.service cluster/alunel/systemd/hesperia-output-views.service \
  cluster/prichindel/nginx-hesperia.prichindel.com.conf \
  cluster/prichindel/systemd/hesperia-output-views-prichindel.service \
  cluster/prichindel/systemd/hesperia-inspection-viewer.service; do
  [[ -e "$p" ]] && tar cf - "$p" | ssh "$ALUNEL" "cd $HES && tar xf -"
done

# Root + CLIENTS
for p in HESPERIA-TFP-RUNTIME-VARIABLES-TABLE.md HESPERIA-TFP-YIELDED-PARAMETERS-TABLE.md \
  hesperia-0.6.3-archive.zip hesperia-0.6.3-archive.SHA256SUMS.txt CLIENTS/hesperia/v0.1; do
  [[ -e "$p" ]] && tar cf - "$p" | ssh "$ALUNEL" "cd $HES && mkdir -p root CLIENTS/hesperia && tar xf -" 2>/dev/null || tar cf - "$p" | ssh "$ALUNEL" "cd $HES && tar xf -"
done

# Hesperia scripts (exclude keepers)
find scripts -maxdepth 1 -iname '*hesperia*' \
  ! -name 'hesperia-prod-deploy.sh' ! -name 'hesperia-sync-brain-links-to-dev.sh' \
  ! -name 'verify-hesperia-*' ! -name 'verify-brain-no-hesperia-product-ingest.sh' \
  ! -name 'alunel-hesperia-bootstrap.sh' ! -name 'alunel-hesperia-dev-env.sh' \
  ! -name 'brain-debloat-*' -print0 | tar cf - --null -T - | ssh "$ALUNEL" "cd $HES/scripts && tar xf -" 2>/dev/null || true

# Tersagor
[[ -d cluster/tersagor ]] && tar cf - cluster/tersagor | ssh "$ALUNEL" "cd $TER && tar xf -"
find operational -iname '*tersagor*' -print0 | tar cf - --null -T - | ssh "$ALUNEL" "cd $TER && tar xf -"
find governance -iname '*tersagor*' -print0 | tar cf - --null -T - | ssh "$ALUNEL" "cd $TER && tar xf -"
find scripts -maxdepth 1 -iname '*tersagor*' ! -name 'tersagor-operator-notify.sh' -print0 | tar cf - --null -T - | ssh "$ALUNEL" "cd $TER/scripts && tar xf -" 2>/dev/null || true
for p in cluster/prichindel/nginx-tersagor*.conf cluster/prichindel/nginx-lounge.tersagor*.conf; do
  [[ -f "$p" ]] && tar cf - "$p" | ssh "$ALUNEL" "cd $TER/cluster-prichindel && tar xf -"
done
[[ -f .github/workflows/tersagor-agent-ci.yml ]] && tar cf - .github/workflows/tersagor-agent-ci.yml | ssh "$ALUNEL" "cd $TER/github-workflows && tar xf -"
[[ -f .cursor/rules/cursor-operator-notify-tersagor.mdc ]] && tar cf - .cursor/rules/cursor-operator-notify-tersagor.mdc | ssh "$ALUNEL" "cd $TER/cursor-rules && tar xf -"
[[ -f src/REMOVED-TERSAGOR-AGENT.md ]] && tar cf - src/REMOVED-TERSAGOR-AGENT.md | ssh "$ALUNEL" "cd $TER && tar xf -"

ssh "$ALUNEL" "cat > $HES/README.md <<EOF
# Brain export (cursor) — Hesperia wave 2
Imported: $STAMP
Source: $BRAIN
Canonical: igareosh/hesperia — brain keeps links only.
EOF
cat > $TER/README.md <<EOF
# Brain export (cursor) — Tersagor wave 2
Imported: $STAMP
Source: $BRAIN
Canonical: igareosh/tersagor
EOF"

GIT='-c user.email=igareosh@igareosh.com -c user.name=igareosh'
ssh "$ALUNEL" "cd /data/workspaces/atomic-commit-hesperia && git $GIT add docs/brain-export/ && git $GIT diff --cached --quiet || git $GIT commit -m 'docs(dev): brain-export wave2 Hesperia from cursor ($STAMP)' && git $GIT push dev main"
ssh "$ALUNEL" "cd /data/workspaces/tersagor && git $GIT add docs/brain-export/ && git $GIT diff --cached --quiet || git $GIT commit -m 'docs: brain-export wave2 Tersagor from cursor ($STAMP)' && git $GIT push origin main"

echo "export-remote: OK ($STAMP)"
