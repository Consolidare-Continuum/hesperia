#!/usr/bin/env bash
# Read-only JSON snapshot: workflow API heartbeat, current_step, approval_metrics (Phase 2b).
# WORKFLOW_API_BASE default http://127.0.0.1:9096; WORKFLOW_API_TOKEN optional Bearer.

set -euo pipefail
BASE="${WORKFLOW_API_BASE:-http://127.0.0.1:9096}"
HDR=()
if [[ -n "${WORKFLOW_API_TOKEN:-}" ]]; then
  HDR=(-H "Authorization: Bearer ${WORKFLOW_API_TOKEN}")
fi

hb=$(curl -sS --max-time 5 "${HDR[@]}" "$BASE/workflow/heartbeat" || echo '{"error":"curl_failed"}')
cs=$(curl -sS --max-time 5 "${HDR[@]}" "$BASE/workflow/current_step" || echo '{"error":"curl_failed"}')
am=$(curl -sS --max-time 5 "${HDR[@]}" "$BASE/workflow/approval_metrics" || echo '{"error":"curl_failed"}')

python3 -c "
import json, sys
hb, cs, am, base = sys.argv[1:5]
def j(s):
    try:
        return json.loads(s)
    except Exception:
        return {'raw': s[:300]}
print(json.dumps(
    {'workflow_api_base': base, 'heartbeat': j(hb), 'current_step': j(cs), 'approval_metrics': j(am)},
    indent=2,
))
" "$hb" "$cs" "$am" "$BASE"
