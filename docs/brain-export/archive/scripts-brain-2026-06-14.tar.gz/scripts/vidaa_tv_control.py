#!/usr/bin/env python3
"""
VIDAA TV HomeKit Control

Usage:
  vidaa_tv_control.py status              # Show TV status
  vidaa_tv_control.py sources             # List all inputs
  vidaa_tv_control.py power on|off        # Power control
  vidaa_tv_control.py volume <0-100>      # Set volume
  vidaa_tv_control.py mute on|off         # Mute control
  vidaa_tv_control.py input <name|id>     # Switch input (hdmi1/hdmi2/tv/av/airplay or ID)
  vidaa_tv_control.py brightness <0-100>  # Set brightness
  vidaa_tv_control.py key <name>          # Send remote key (up/down/left/right/ok/back/menu/home)
"""

import sys
sys.path.insert(0, '/home/igareosh/.local/lib/python3.10/site-packages')

import json
from homekit.controller.ip_implementation import IpPairing

CREDS_FILE = '/data/workspaces/cursor/cluster/fulgusor/vidaa-homekit.json'

# Characteristic IDs (AID=1)
CHAR_POWER = (1, 52)          # Active (0=off, 1=on)
CHAR_INPUT = (1, 53)          # ActiveIdentifier (input ID)
CHAR_MEDIA_STATE = (1, 54)    # CurrentMediaState
CHAR_BRIGHTNESS = (1, 61)     # Brightness (0-100)
CHAR_VOLUME = (1, 84)         # Volume (0-100)
CHAR_MUTE = (1, 82)           # Mute (bool)
CHAR_REMOTE_KEY = (1, 130)    # RemoteKey

# Input name to ID mapping (from TV's HomeKit services)
INPUTS = {
    'home': 1,
    'tv': 2, 'livetv': 2,
    'hdmi1': 3, 'hdmi': 3,
    'hdmi2': 4,
    'av': 6,
    'airplay': 9
}

# Reverse mapping
INPUT_NAMES = {v: k for k, v in INPUTS.items() if k not in ('hdmi', 'livetv')}

# Remote keys (HomeKit RemoteKey values)
REMOTE_KEYS = {
    'rewind': 0, 'fastforward': 1, 'ff': 1,
    'nexttrack': 2, 'next': 2,
    'prevtrack': 3, 'prev': 3,
    'up': 4, 'down': 5, 'left': 6, 'right': 7,
    'select': 8, 'ok': 8, 'enter': 8,
    'back': 9, 'return': 9,
    'exit': 10,
    'playpause': 11, 'play': 11, 'pause': 11,
    'info': 15, 'menu': 15
}


def get_pairing():
    creds = json.load(open(CREDS_FILE))
    return IpPairing({
        'AccessoryPairingID': creds['accessory_id'],
        'AccessoryLTPK': creds['accessory_ltpk'],
        'iOSPairingId': creds['ios_device_id'],
        'iOSDeviceLTSK': creds['ios_ltsk'],
        'iOSDeviceLTPK': creds['ios_ltpk'],
        'Connection': 'IP',
        'AccessoryIP': creds['host'],
        'AccessoryPort': creds['port']
    })


def cmd_status():
    pairing = get_pairing()
    result = pairing.get_characteristics([
        CHAR_POWER, CHAR_INPUT, CHAR_VOLUME, CHAR_MUTE,
        CHAR_BRIGHTNESS, CHAR_MEDIA_STATE
    ])
    pairing.close()

    power = result.get(CHAR_POWER, {}).get('value', '?')
    input_id = result.get(CHAR_INPUT, {}).get('value', '?')
    volume = result.get(CHAR_VOLUME, {}).get('value', '?')
    mute = result.get(CHAR_MUTE, {}).get('value', '?')
    brightness = result.get(CHAR_BRIGHTNESS, {}).get('value', '?')

    input_name = INPUT_NAMES.get(input_id, str(input_id))

    print(f"Power:      {'ON' if power == 1 else 'OFF'}")
    print(f"Input:      {input_name} (id={input_id})")
    print(f"Volume:     {volume}%")
    print(f"Mute:       {'ON' if mute == 1 else 'OFF'}")
    print(f"Brightness: {brightness}%")


def cmd_sources():
    """List all available inputs from the TV."""
    pairing = get_pairing()
    accessories = pairing.list_accessories_and_characteristics()
    pairing.close()

    print("Available inputs:")
    print("-" * 40)
    for acc in accessories:
        for svc in acc['services']:
            # Input Source service type is D9
            if 'D9' in svc['type']:
                name = None
                input_id = None
                for char in svc['characteristics']:
                    if char['type'].startswith('E6'):  # Identifier
                        input_id = char.get('value')
                    if char['type'].startswith('00000023'):  # Name
                        name = char.get('value')
                if name and input_id:
                    print(f"  {input_id:2d}  {name}")
    print("-" * 40)
    print("Use: vidaa_tv_control.py input <name|id>")


def cmd_power(state):
    value = 1 if state.lower() in ('on', '1', 'true') else 0
    pairing = get_pairing()
    pairing.put_characteristics([(CHAR_POWER[0], CHAR_POWER[1], value)])
    pairing.close()
    print(f"Power {'ON' if value else 'OFF'}")


def cmd_volume(level):
    level = max(0, min(100, int(level)))
    pairing = get_pairing()
    pairing.put_characteristics([(CHAR_VOLUME[0], CHAR_VOLUME[1], level)])
    pairing.close()
    print(f"Volume set to {level}%")


def cmd_mute(state):
    value = 1 if state.lower() in ('on', '1', 'true') else 0
    pairing = get_pairing()
    pairing.put_characteristics([(CHAR_MUTE[0], CHAR_MUTE[1], value)])
    pairing.close()
    print(f"Mute {'ON' if value else 'OFF'}")


def cmd_input(name_or_id):
    # Accept both name and numeric ID
    try:
        input_id = int(name_or_id)
    except ValueError:
        name = name_or_id.lower()
        if name not in INPUTS:
            print(f"Unknown input: {name}")
            print(f"Available: {', '.join(k for k in INPUTS.keys() if k not in ('hdmi', 'livetv'))}")
            print("Or use numeric ID (run 'sources' to list)")
            return
        input_id = INPUTS[name]

    pairing = get_pairing()
    pairing.put_characteristics([(CHAR_INPUT[0], CHAR_INPUT[1], input_id)])
    pairing.close()
    input_name = INPUT_NAMES.get(input_id, str(input_id))
    print(f"Input switched to {input_name} (id={input_id})")


def cmd_key(keyname):
    """Send a remote control key press."""
    keyname = keyname.lower()
    if keyname not in REMOTE_KEYS:
        print(f"Unknown key: {keyname}")
        print(f"Available: {', '.join(sorted(set(REMOTE_KEYS.keys())))}")
        return

    pairing = get_pairing()
    pairing.put_characteristics([(CHAR_REMOTE_KEY[0], CHAR_REMOTE_KEY[1], REMOTE_KEYS[keyname])])
    pairing.close()
    print(f"Sent key: {keyname}")


def cmd_brightness(level):
    level = max(0, min(100, int(level)))
    pairing = get_pairing()
    pairing.put_characteristics([(CHAR_BRIGHTNESS[0], CHAR_BRIGHTNESS[1], level)])
    pairing.close()
    print(f"Brightness set to {level}%")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1].lower()

    try:
        if cmd == 'status':
            cmd_status()
        elif cmd == 'sources':
            cmd_sources()
        elif cmd == 'power':
            if len(sys.argv) < 3:
                print("Usage: power on|off")
                sys.exit(1)
            cmd_power(sys.argv[2])
        elif cmd == 'volume':
            if len(sys.argv) < 3:
                print("Usage: volume <0-100>")
                sys.exit(1)
            cmd_volume(sys.argv[2])
        elif cmd == 'mute':
            if len(sys.argv) < 3:
                print("Usage: mute on|off")
                sys.exit(1)
            cmd_mute(sys.argv[2])
        elif cmd == 'input':
            if len(sys.argv) < 3:
                print("Usage: input <hdmi1|hdmi2|tv|av|airplay|ID>")
                sys.exit(1)
            cmd_input(sys.argv[2])
        elif cmd == 'brightness':
            if len(sys.argv) < 3:
                print("Usage: brightness <0-100>")
                sys.exit(1)
            cmd_brightness(sys.argv[2])
        elif cmd == 'key':
            if len(sys.argv) < 3:
                print("Usage: key <up|down|left|right|ok|back|menu|play|pause>")
                sys.exit(1)
            cmd_key(sys.argv[2])
        else:
            print(f"Unknown command: {cmd}")
            print(__doc__)
            sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
