#!/usr/bin/env bash
# Report CA trust + cert SSH per cluster host (non-secret). Run from alunel.
set -u
PATH="/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
QM="${QM:-$(command -v qm || echo /usr/sbin/qm)}"
SSH_OPTS=(-o BatchMode=yes -o ConnectTimeout=5)
HOSTS=(
    prichindel:direct
    alunel:local
    dnsmaster:192.168.100.25
    chronomaster:chronomaster
    mediamaster:mediamaster
    altitudine:altitudine
    izvoras:izvoras
    trustmaster:trustmaster
    tersagor:100.76.33.56
    librarymaster:192.168.100.66
    stejarel:192.168.100.19
    mugurel:192.168.100.57
    voinicel:192.168.100.90
    fulgusor:192.168.100.40
)

for entry in "${HOSTS[@]}"; do
    IFS=: read -r name target <<<"$entry"
    if [ "$target" = "local" ]; then
        if [ -f /etc/ssh/agent_ca.pub ] && [ -f /etc/sudoers.d/igareosh-agent ]; then
            echo "$name: trusted_local"
        else
            echo "$name: untrusted_local"
        fi
        continue
    fi
    if [ "$target" = "direct" ]; then
        target="$name"
    fi
    # sudoers.d files are mode 440 — unprivileged test -f fails; use sudo -n test -f
    TRUST_CMD='test -f /etc/ssh/agent_ca.pub && sudo -n test -f /etc/sudoers.d/igareosh-agent && sudo -n true'
    if ssh "${SSH_OPTS[@]}" "igareosh@${target}" "$TRUST_CMD" 2>/dev/null; then
        echo "$name: trusted_cert_ssh"
    elif ssh "${SSH_OPTS[@]}" "igareosh@prichindel" \
        "ssh ${SSH_OPTS[*]} igareosh@${target} '$TRUST_CMD'" 2>/dev/null; then
        echo "$name: trusted_via_prichindel"
    elif [ "$name" = "librarymaster" ] && [ -x "$QM" ] && sudo "$QM" status 103 2>/dev/null | grep -q running; then
        if sudo "$QM" guest exec 103 -- test -f /etc/ssh/agent_ca.pub 2>/dev/null | grep -q '"exitcode" : 0'; then
            echo "$name: trusted_qemu_lan_ssh_down"
        else
            echo "$name: unreachable"
        fi
    elif [ "$name" = "trustmaster" ] && [ -x "$QM" ] && sudo "$QM" status 104 2>/dev/null | grep -q running; then
        if sudo "$QM" guest exec 104 -- test -f /etc/ssh/agent_ca.pub 2>/dev/null | grep -q '"exitcode" : 0'; then
            echo "$name: trusted_qemu_ssh_down"
        else
            echo "$name: unreachable"
        fi
    else
        echo "$name: unreachable"
    fi
done
