#!/usr/bin/env python3
"""Chroma preflight: one query via agent_mcp_knowledge.store (same path as MCP). Exit 1 if empty/error."""
from __future__ import annotations

import json
import os
import sys
import warnings
from pathlib import Path


def _filter_dotenv_parse_noise() -> None:
    """Drop python-dotenv 'could not parse' noise (malformed .env read by a dependency)."""
    warnings.filterwarnings(
        "ignore",
        message=r".*python-dotenv could not parse.*",
    )
    if getattr(sys.stderr, "_chroma_preflight_dotenv_filter", False):
        return
    orig = sys.stderr

    class _F:
        _chroma_preflight_dotenv_filter = True

        def write(self, s: str | bytes) -> int:
            if isinstance(s, bytes):
                text = s.decode("utf-8", errors="replace")
                if "python-dotenv could not parse" in text:
                    return len(s)
                return orig.write(s)
            if s and "python-dotenv could not parse" in s:
                return len(s)
            return orig.write(s)

        def flush(self) -> None:
            orig.flush()

        def __getattr__(self, name: str):
            return getattr(orig, name)

    sys.stderr = _F()  # type: ignore[assignment]


# Before Chroma / dotenv in any dependency import path.
_filter_dotenv_parse_noise()

REPO_ROOT = Path(os.environ.get("REPO_ROOT", Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(REPO_ROOT))
os.environ.setdefault("CHROMA_SERVER_URL", os.environ.get("CHROMA_SERVER_URL", "http://127.0.0.1:8002"))


def main() -> int:
    if os.environ.get("CHROMA_SKIP_PREFLIGHT", "").strip() == "1":
        rec = {"event": "chroma_preflight", "ok": True, "skipped": True, "reason": "CHROMA_SKIP_PREFLIGHT"}
        print(json.dumps(rec), file=sys.stderr)
        return 0
    try:
        from agent_mcp_knowledge.store import query

        results = query("workflow automation preflight", n_results=2)
    except Exception as e:
        rec = {"event": "chroma_preflight", "ok": False, "error": type(e).__name__, "message": str(e)[:500]}
        print(json.dumps(rec), file=sys.stderr)
        return 1
    if not results:
        rec = {"event": "chroma_preflight", "ok": False, "error": "no_results"}
        print(json.dumps(rec), file=sys.stderr)
        return 1
    src = (results[0].get("metadata") or {}).get("source", "?")
    rec = {
        "event": "chroma_preflight",
        "ok": True,
        "sample_source": src,
        "n": len(results),
    }
    print(json.dumps(rec), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
