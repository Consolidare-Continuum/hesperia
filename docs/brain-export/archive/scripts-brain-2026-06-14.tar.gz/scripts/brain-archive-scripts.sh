#!/usr/bin/env bash
# Archive scripts/ → igareosh/hesperia; slim brain to live essentials in subdirs.
set -euo pipefail

BRAIN="${BRAIN_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
SCR="$BRAIN/scripts"
STAMP="${ARCHIVE_STAMP:-$(date -u +%Y-%m-%d)}"
ARCHIVE_NAME="scripts-brain-${STAMP}.tar.gz"
SUMS_NAME="scripts-brain-${STAMP}.SHA256SUMS.txt"
REMOTE="${ARCHIVE_REMOTE:-altitudine}"
HES_DEV="${HESPERIA_DEV:-/data/workspaces/atomic-commit-hesperia}"
ARCHIVE_DIR="$HES_DEV/docs/brain-export/archive"
GIT="-c user.email=igareosh@igareosh.com -c user.name=igareosh"

# Exact paths to keep (relative to scripts/). workflow/ workflow_tests/ oracle/ cron/ git-hooks/ kept whole.
KEEP_EXACT=(
  workflow_run.sh
  workflow_automation_run.sh
  workflow_automation_manual_start.sh
  workflow_driver.py
  workflow_orchestrator.py
  workflow_active_burn_down.sh
  workflow_imirc_automation_run.sh
  workflow_imirc_burn_down.sh
  workflow_full_auto_dispatch.py
  detect-cursor-session-mode.sh
  detect-cursor-session-mode.ps1
  deploy-mcp-config-global.sh
  deploy-mcp-config-global.ps1
  deploy-mcp-altitudine-remote.sh
  verify-mcp-handshake.sh
  verify-mcp-appendix.sh
  verify-altitudine-cursor-env.sh
  verify-host-role-separation.sh
  agent-cluster-access-preflight.sh
  agent-ssh-cert-renew.sh
  agent-ssh-verify-trust.sh
  git-repo-identity.sh
  hesperia-prod-deploy.sh
  hesperia-sync-brain-links-to-dev.sh
  verify-hesperia-prod-https.sh
  verify-hesperia-prod-code-only.sh
  verify-hesperia-dev-pytest.sh
  verify-hesperia-git-remotes.sh
  verify-brain-no-hesperia-product-ingest.sh
  alunel-hesperia-bootstrap.sh
  alunel-hesperia-dev-env.sh
  brain-archive-operational-assignments.sh
  brain-archive-scripts.sh
  brain-debloat-cleanup-local.sh
  brain-debloat-export-remote.sh
  librarymaster-papra-evening-reindex.sh
  librarymaster-papra-g0-dry-run-3.sh
  librarymaster-backup-chroma-2.sh
  librarymaster-deploy-chroma-2.sh
  librarymaster-chroma2-schema-deploy.sh
  verify-chroma2-persist.sh
  colombo-chroma2-query.sh
  end_of_week_run.sh
  end_of_week_collect.sh
  end_of_week_research.py
  end_of_day_collect.sh
  run-maintenance.sh
  run-backup.sh
  tersagor-operator-notify.sh
  trustmaster-access-preflight.sh
  job_done_effect.py
  vidaa_tv_control.py
  plex_play_playlist.py
  mcp_config_drift_check.sh
  deploy-mcp-lamaita-remote.sh
  SCRIPT-RUNBOOK-workflow-orchestrator.md
  SCRIPT-RUNBOOK-workflow-proceed-gates.md
  SCRIPT-RUNBOOK-report-done-workflow.md
  SCRIPT-RUNBOOK-papra-ingest-v1.md
  SCRIPT-RUNBOOK-chroma-2-librarymaster.md
  SCRIPT-RUNBOOK-mcp.md
  SCRIPT-RUNBOOK-cluster-proceed-preflight.md
  SCRIPT-RUNBOOK-end-of-week-brain.md
  SCRIPT-RUNBOOK-tersagor-operator-notify.md
)

KEEP_DIRS=(workflow workflow_tests oracle cron git-hooks alunel-python)

[[ -d "$SCR" ]] || { echo "FAIL: missing $SCR" >&2; exit 1; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "=== archive scripts/ ($STAMP) ==="
tar -C "$BRAIN" -czf "$TMP/$ARCHIVE_NAME" scripts
sha256sum "$TMP/$ARCHIVE_NAME" | tee "$TMP/$SUMS_NAME"
ls -lh "$TMP/$ARCHIVE_NAME"

scp "$TMP/$ARCHIVE_NAME" "$TMP/$SUMS_NAME" "$REMOTE:/tmp/"
ssh "$REMOTE" "set -e
mkdir -p $ARCHIVE_DIR
mv /tmp/$ARCHIVE_NAME /tmp/$SUMS_NAME $ARCHIVE_DIR/
cd $HES_DEV
git $GIT add docs/brain-export/archive/$ARCHIVE_NAME docs/brain-export/archive/$SUMS_NAME
touch docs/brain-export/archive/README.md
grep -q '$ARCHIVE_NAME' docs/brain-export/archive/README.md 2>/dev/null || cat >> docs/brain-export/archive/README.md <<EOF

## $ARCHIVE_NAME
- **Created:** $(date -u +%Y-%m-%dT%H:%MZ)
- **Source:** brain \`scripts/\` full tree
- **SHA256:** \$(awk '{print \$1}' $ARCHIVE_DIR/$SUMS_NAME)
EOF
git $GIT add docs/brain-export/archive/README.md
git $GIT diff --cached --quiet || git $GIT commit -m 'docs(dev): archive brain scripts tree ($STAMP)'
git $GIT push dev main
echo remote: \$(git rev-parse --short HEAD)
"

# Save keep set
SAVE="$TMP/keep"
mkdir -p "$SAVE"/{runbooks,cluster,hesperia,mcp,papra,colombo,brain}
for d in "${KEEP_DIRS[@]}"; do
  [[ -d "$SCR/$d" ]] && cp -a "$SCR/$d" "$SAVE/"
done
for f in "${KEEP_EXACT[@]}"; do
  [[ -f "$SCR/$f" ]] || continue
  case "$f" in
    SCRIPT-RUNBOOK-*) cp -a "$SCR/$f" "$SAVE/runbooks/" ;;
    hesperia-*|verify-hesperia-*|verify-brain-no-hesperia-*|alunel-hesperia-*) cp -a "$SCR/$f" "$SAVE/hesperia/" ;;
    deploy-mcp-*|verify-mcp-*|mcp_config_drift_check.sh) cp -a "$SCR/$f" "$SAVE/mcp/" ;;
    librarymaster-*|verify-chroma2-*) cp -a "$SCR/$f" "$SAVE/papra/" ;;
    colombo-*) cp -a "$SCR/$f" "$SAVE/colombo/" ;;
    brain-*) cp -a "$SCR/$f" "$SAVE/brain/" ;;
    workflow*) cp -a "$SCR/$f" "$SAVE/" ;;
    detect-*|verify-host-*|agent-*|git-repo-*|run-maintenance.sh|run-backup.sh|trustmaster-access-preflight.sh|job_done_effect.py|vidaa_*|plex_*|tersagor-operator-notify.sh|end_of_*)
      cp -a "$SCR/$f" "$SAVE/cluster/" ;;
    *) cp -a "$SCR/$f" "$SAVE/" ;;
  esac
done

# Wipe and restore organized tree
find "$SCR" -mindepth 1 -maxdepth 1 -exec rm -rf {} +

for d in "${KEEP_DIRS[@]}"; do
  [[ -d "$SAVE/$d" ]] && mv "$SAVE/$d" "$SCR/"
done
[[ -d "$SAVE/runbooks" ]] && mv "$SAVE/runbooks" "$SCR/"
for sub in cluster hesperia mcp papra colombo brain; do
  [[ -d "$SAVE/$sub" ]] && mv "$SAVE/$sub" "$SCR/"
done
# Root-level workflow scripts
for f in workflow_run.sh workflow_automation_run.sh workflow_automation_manual_start.sh \
  workflow_driver.py workflow_orchestrator.py workflow_active_burn_down.sh \
  workflow_imirc_automation_run.sh workflow_imirc_burn_down.sh workflow_full_auto_dispatch.py; do
  [[ -f "$SAVE/$f" ]] && mv "$SAVE/$f" "$SCR/"
done

# Wrappers at legacy paths for top references
link_wrapper() {
  local target="$1" link="$2"
  [[ -f "$SCR/$target" ]] || return 0
  ln -sf "$target" "$SCR/$link"
}
link_wrapper cluster/detect-cursor-session-mode.sh detect-cursor-session-mode.sh
link_wrapper mcp/deploy-mcp-config-global.sh deploy-mcp-config-global.sh
link_wrapper hesperia/hesperia-prod-deploy.sh hesperia-prod-deploy.sh
link_wrapper papra/verify-chroma2-persist.sh verify-chroma2-persist.sh
link_wrapper papra/librarymaster-papra-evening-reindex.sh librarymaster-papra-evening-reindex.sh
link_wrapper brain/brain-archive-operational-assignments.sh brain-archive-operational-assignments.sh
link_wrapper cluster/end_of_week_run.sh end_of_week_run.sh

cat > "$SCR/README.md" <<EOF
# scripts — slim index (archived ${STAMP})

**Full tree archived** (\$(tar -tzf $ARCHIVE_DIR/$ARCHIVE_NAME 2>/dev/null | wc -l || echo '?') paths) →
[\`docs/brain-export/archive/${ARCHIVE_NAME}\`](https://github.com/igareosh/hesperia/tree/main/docs/brain-export/archive)

**SHA256:** see \`${SUMS_NAME}\` on dev repo.

## Layout (brain — live only)

| Dir | Purpose |
|-----|---------|
| \`workflow/\`, \`workflow_*.sh\`, \`workflow_*.py\` | Team workflow automation |
| \`cluster/\` | Session mode, agent SSH, maintenance, EOW |
| \`mcp/\` | MCP deploy + verify |
| \`hesperia/\` | Prod deploy + verify (orchestration) |
| \`papra/\` | CHROMA-2 / Papra reindex (live wave) |
| \`colombo/\` | CHROMA-2 CLI query |
| \`brain/\` | Brain debloat + archive scripts |
| \`runbooks/\` | Essential SCRIPT-RUNBOOK only |
| \`oracle/\` | UAIC Oracle/APEX helpers |

Legacy top-level names (\`detect-cursor-session-mode.sh\`, etc.) are **symlinks** into subdirs.

Historical script or runbook → extract tarball or search \`docs/brain-export/\` on **igareosh/hesperia**.
EOF

echo "=== scripts slim complete ==="
find "$SCR" -type f | wc -l
du -sh "$SCR"
find "$SCR" -maxdepth 1 | head -20
