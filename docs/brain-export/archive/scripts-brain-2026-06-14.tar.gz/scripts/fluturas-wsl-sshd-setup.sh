#!/bin/bash
# Run inside WSL on fluturas (or any Windows node). Installs openssh-server, adds prichindel key, starts sshd.
# Usage: from WSL, from repo root (e.g. /mnt/c/Users/igare/Proton\ Drive/.../cursor):
#   bash scripts/fluturas-wsl-sshd-setup.sh
# Or: wsl -e bash -c "cd /mnt/c/Users/igare/Proton\ Drive/igareosh/Other\ computers/CERES/ceres_proton_drive/cursor && bash scripts/fluturas-wsl-sshd-setup.sh"
# Prichindel key must be in cluster/fluturas/prichindel.pub (same path relative to repo root).
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
KEY_FILE="$REPO_ROOT/cluster/fluturas/prichindel.pub"

if [ ! -f "$KEY_FILE" ]; then
  echo "ERROR: prichindel.pub not found at $KEY_FILE"
  exit 1
fi

# Install openssh-server
sudo apt-get update -qq
sudo apt-get install -y openssh-server

# authorized_keys
mkdir -p ~/.ssh
chmod 700 ~/.ssh
grep -q -F "$(cat "$KEY_FILE")" ~/.ssh/authorized_keys 2>/dev/null || cat "$KEY_FILE" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
echo "Added prichindel key to ~/.ssh/authorized_keys"

# sshd: key-only
sudo sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo systemctl start ssh 2>/dev/null || sudo service ssh start
sudo systemctl enable ssh 2>/dev/null || true
echo "sshd started. From prichindel: ssh $(whoami)@<fluturas_ip> hostname"
echo "Windows firewall: allow TCP 22 from 192.168.100.21,192.168.100.23,192.168.100.40 (run in PowerShell Admin if needed)."
