#!/usr/bin/env bash
# Verify appendix MCP modules import and one tool smoke on prichindel (via alunel hop).
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
HOP="${MCP_VERIFY_SSH_HOP:-alunel}"
TARGET="${MCP_VERIFY_SSH_TARGET:-prichindel}"
PY="${MCP_VENV_PYTHON:-/data/chroma/venv/bin/python}"

remote() {
  local cmd="$1"
  local here
  here="$(hostname -s 2>/dev/null || true)"
  if [ "$here" = "$TARGET" ]; then
    bash -lc "$cmd"
  elif [ "$here" = "alunel" ] && [ "$TARGET" = "prichindel" ]; then
    ssh -o BatchMode=yes "$TARGET" "bash -lc $(printf '%q' "$cmd")"
  else
    ssh -o BatchMode=yes "$HOP" "ssh -o BatchMode=yes $TARGET bash -lc $(printf '%q' "$cmd")"
  fi
}

REPO="/data/workspaces/cursor"
CMD="REPO=$REPO; cd \"\$REPO\" && PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" $PY"

echo "== MCP venv =="
remote "$PY -c 'import mcp; print(\"mcp ok\")'"

echo "== imports =="
for mod in agent_mcp_cluster_snapshot agent_mcp_github_ci agent_mcp_context_rag agent_mcp_inbox_reader; do
  remote "$CMD -c 'import $mod; print(\"$mod ok\")'" || exit 1
done

echo "== cluster snapshot smoke =="
remote "$CMD -c \"
from agent_mcp_cluster_snapshot.__main__ import get_cluster_snapshot
print(get_cluster_snapshot()[:400])
\""

echo "== inbox reader smoke =="
remote "$CMD -c \"
from agent_mcp_inbox_reader.__main__ import get_inbox_summary
print(get_inbox_summary(status_filter='all', limit=3)[:400])
\""

echo "OK: appendix MCP verify passed on $TARGET via $HOP"
