# Runbook — Cloudflare upkeep (tunnels, tokens, DNS)

**When**: Tunnel down, connector token rotation, DNS change for cluster services, origin cert renewal, or operator/Abelard requests "Cloudflare" / "tunnel" / "fix Cloudflare". **Leave alone**: prichindel.prichindel.com tunnel = external SSH + Cursor gateway; do not break it. Owner: **Abelard**.

**Where**: Prichindel (tunnel services, token files); DNS/Zero Trust may be done from laptop with token from prichindel.

---

## 1. Tunnel status (primary + Gradina1)

**Check**:
```bash
sudo systemctl status cloudflared.service --no-pager
sudo systemctl status cloudflared-gradina1.service --no-pager
```

**Restart** (if down):
```bash
sudo systemctl restart cloudflared.service
sudo systemctl restart cloudflared-gradina1.service
```

**Token (primary)**: `/etc/cloudflared/primary/token` — root-only, 0600. Run script: `/etc/cloudflared/primary/run.sh`. If token rotated in dashboard, update this file; restart service.

---

## 2. Token locations (never log or commit values)

| Token | Purpose | Location |
|-------|---------|----------|
| Connectors (primary tunnel) | Runtime for cloudflared | `/etc/cloudflared/primary/token` |
| Network (API) | Tunnel/network management | `/root/.secrets/cloudflare/cf-api-token` |
| Zone DNS | Certbot DNS-01, DNS automation | `/root/.secrets/certbot/cloudflare.ini` |
| Zero Trust Read/Report/Edit/Seats | Zero Trust API | `/root/.secrets/cloudflare/cf-zero-trust-*` |

Rotation: update file on prichindel; restart affected service (e.g. cloudflared after connector token change).

---

## 3. Origin certificates (Apache2 SSL)

- **prichindel.com**: Cert `/etc/ssl/cloudflare/prichindel.origin.pem`, Key `prichindel.origin.key`. Used by Apache2 on 10443. Renew or replace per Cloudflare dashboard; copy to prichindel; reload Apache2.

---

## 4. DNS (Zone DNS token)

Certbot DNS-01: uses `/root/.secrets/certbot/cloudflare.ini`. For DNS record changes: use Zone DNS token; script or API per [docs/CLOUDFLARE.md](../docs/CLOUDFLARE.md).

---

## Failure modes

| Failure | Symptom | Action |
|---------|---------|--------|
| Primary tunnel down | cloudflared.service failed or inactive | Restart; check token file exists and is valid; rotate token in dashboard if expired. |
| Gradina1 tunnel down | cloudflared-gradina1.service failed | Restart; check `/etc/cloudflared/account2/gradina1.yml` and credentials. |
| Token invalid/expired | Tunnel exits or 4xx from API | Rotate token in Cloudflare dashboard; update secret file on prichindel; restart service. |

---

**Ref**: [docs/CLOUDFLARE.md](../docs/CLOUDFLARE.md). Owner: Abelard. Tokens under Abelard control; never log or expose.
