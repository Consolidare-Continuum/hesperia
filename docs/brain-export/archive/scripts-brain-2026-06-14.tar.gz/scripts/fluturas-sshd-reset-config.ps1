# Reset sshd_config to default + PasswordAuthentication no. Run as Administrator.
# Use when sshd won't start (e.g. config corrupted). Then run fluturas-fix-admin-keys.ps1.
$ErrorActionPreference = 'Stop'
$sshDir = "$env:ProgramData\ssh"
$cfg = "$sshDir\sshd_config"
$candidates = @(
    "$env:ProgramFiles\OpenSSH\sshd_config_default",
    "$env:SystemRoot\System32\OpenSSH\sshd_config_default"
)
$binPath = (Get-WmiObject Win32_Service -Filter "Name='sshd'" -ErrorAction SilentlyContinue).PathName
if ($binPath -match '"([^"]+)\\sshd\.exe"') { $candidates += "$($Matches[1])\sshd_config_default" }
$defaultCfg = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $defaultCfg) { Write-Error "sshd_config_default not found"; exit 1 }
Copy-Item $cfg "$cfg.bak.before_reset_$(Get-Date -Format 'yyyyMMdd-HHmm')" -Force -ErrorAction SilentlyContinue
Copy-Item $defaultCfg $cfg -Force
Add-Content -Path $cfg -Value "`n# fluturas: key-only`nPasswordAuthentication no"
Write-Host "Reset sshd_config from $defaultCfg; added PasswordAuthentication no."
Start-Service sshd -ErrorAction SilentlyContinue
Write-Host "sshd status:" (Get-Service sshd -ErrorAction SilentlyContinue).Status
