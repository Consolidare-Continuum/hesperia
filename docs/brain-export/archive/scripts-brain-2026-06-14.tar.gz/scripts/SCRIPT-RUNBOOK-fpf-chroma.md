# SCRIPT-RUNBOOK — FPF layer (Chroma catalog)

**Id**: `fpf-chroma`  
**Purpose**: Recover or refresh **FPF catalog** chunks (`layer=fpf`, `document_type=fpf_catalog`) when search is empty, ingest fails, or spec was updated.

**Owner**: Abelard. **Refs**: [governance/FPF-CHROMA-CATALOG-STRATEGY.md](../governance/FPF-CHROMA-CATALOG-STRATEGY.md), [governance/TASK-ETHAN-FPF-USABLE-FIVE.md](../governance/TASK-ETHAN-FPF-USABLE-FIVE.md).

---

## Preconditions

- Repo root on **prichindel** (or host with Chroma + `FPrincipleF/FPF-Spec.md`).
- `CHROMA_SERVER_URL` (default `http://chroma-1.prichindel.local:8002`), `PYTHONPATH` = repo root, venv: `/data/chroma/venv/bin/python` when applicable.

---

## Steps

1. **Extract JSONL** from spec (large file; may take a minute):
   ```bash
   python3 cluster/chroma-server/extract_fpf_catalog.py FPrincipleF/FPF-Spec.md > FPrincipleF/fpf-catalog.jsonl
   ```
2. **Ingest catalog** (replaces prior `fpf_catalog` chunks only):
   ```bash
   PYTHONPATH=. python3 -m agent_mcp_knowledge.ingest --fpf-catalog FPrincipleF/fpf-catalog.jsonl
   ```
   Or: `bash cluster/chroma-server/ingest-fpf.sh` if `fpf-catalog.jsonl` exists.
3. **Verify** (IDE MCP): `query_knowledge` with **`fpf_catalog_only=true`**, query_text `A.1` or `Holonic Foundation` — expect hits with **`fpf_pattern_id`** in header.

---

## Failure modes

| Symptom | Action |
|---------|--------|
| `FPrincipleF/` missing | Clone: `ingest-fpf.sh` clones `ailev/FPF` into `FPrincipleF/` if absent. |
| Empty results | Confirm `governance/fpf_mode` intent; run § Steps 1–2; check Chroma `chromadb` collection `knowledge` count. |
| MCP “empty store” | Run team ingest or confirm Chroma process up; see [docs/SURVEILLANCE.md](../docs/SURVEILLANCE.md) § Chroma. |
| **`--fpf` instead of catalog** | Legacy `ingest --fpf` **wipes all** `layer=fpf` including catalog — re-run **§2** after. |

---

SIGNED: DevOps (Abelard) | FPF Chroma runbook | 2026-03-30 | operational
