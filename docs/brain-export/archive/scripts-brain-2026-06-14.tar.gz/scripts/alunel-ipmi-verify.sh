#!/usr/bin/env bash
# alunel X8DT3-F — verify BMC/IPMI after JPB enable + cold boot.
set -euo pipefail

echo "=== board ==="
dmidecode -t baseboard 2>/dev/null | grep -E "Manufacturer|Product|Version" || true

echo "=== dmesg ipmi ==="
dmesg 2>/dev/null | grep -i ipmi | tail -12 || sudo dmesg | grep -i ipmi | tail -12

modprobe ipmi_msghandler ipmi_devintf 2>/dev/null || true
modprobe ipmi_si 2>/dev/null || modprobe ipmi_si type=kcs 2>/dev/null || true

if [[ ! -e /dev/ipmi0 ]]; then
  echo "FAIL: no /dev/ipmi0 — BMC disabled (JPB 2-3?) or non-F board. See cluster/alunel/IPMI-X8DT3-F.md"
  exit 1
fi

echo "=== ipmitool mc info ==="
ipmitool mc info

echo "=== fan sensors ==="
ipmitool sensor list 2>/dev/null | grep -iE "fan|FAN" || true

echo "OK: IPMI up"
