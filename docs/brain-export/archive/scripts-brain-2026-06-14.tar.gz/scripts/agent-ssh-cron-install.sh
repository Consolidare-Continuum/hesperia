#!/usr/bin/env bash
# Install daily agent SSH cert renewal cron on alunel (idempotent).
set -euo pipefail
HOST="$(hostname -s 2>/dev/null || hostname)"
if [ "$HOST" != "alunel" ]; then
    echo "Run on alunel (got $HOST)" >&2
    exit 1
fi
REPO="${REPO_ROOT:-/data/workspaces/cursor}"
MARKER="# cluster-agent-ssh-ca-cron"
TMP="$(mktemp)"
(crontab -l 2>/dev/null | grep -v "$MARKER" | grep -v 'agent-ssh-cert-renew' | grep -v 'agent-ssh-deploy-trust-via-prichindel' || true) >"$TMP"
{
    cat "$TMP"
    echo "17 3 * * * $MARKER; $REPO/scripts/agent-ssh-cert-renew.sh >> /var/log/agent-ssh-cert-renew.log 2>&1"
    echo "20 3 * * * $MARKER; $REPO/scripts/agent-ssh-deploy-trust-via-prichindel.sh >> /var/log/agent-ssh-deploy.log 2>&1"
} | crontab -
rm -f "$TMP"
echo "OK: agent SSH cron installed on alunel"
crontab -l | grep agent-ssh
