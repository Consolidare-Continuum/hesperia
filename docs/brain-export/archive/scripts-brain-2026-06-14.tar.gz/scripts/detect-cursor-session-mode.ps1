# Detect session mode when Cursor runs on LAMAITA (local). Determines LAN vs tunnel.
# Writes governance/cursor_session_mode.txt for agent to read at session start.
# Operator has exactly two modes: (1) LAN = prichindel 192.168.100.21 reachable; (2) tunnel = hotspot + Cloudflare.
# Ref: cursor-main-awareness.mdc § Session mode; cluster/LAPTOP.md.

param([string]$RepoRoot = ".")

$ModeFile = Join-Path $RepoRoot "governance\cursor_session_mode.txt"
$PrichindelLan = "192.168.100.21"
$Port = 22

$lan = $false
try {
    $tcp = New-Object System.Net.Sockets.TcpClient
    $async = $tcp.BeginConnect($PrichindelLan, $Port, $null, $null)
    $wait = $async.AsyncWaitHandle.WaitOne(2000, $false)
    if ($wait -and $tcp.Connected) {
        $lan = $true
        $tcp.Close()
    }
} catch {
    # ignore
}
if ($tcp -and $tcp.Connected) { $tcp.Close() }

$connectivity = if ($lan) { "lan" } else { "tunnel" }
$line = "host=lamaita connectivity=$connectivity"
Set-Content -Path $ModeFile -Value $line -NoNewline
Write-Host "Session mode: host=lamaita connectivity=$connectivity. Written to $ModeFile"
