#!/usr/bin/env python3
"""
HomeKit Pairing for VIDAA TV
Complete HAP pair-setup (M1-M6) using correct SRP and encryption.

Usage: python3 homekit_pair.py <PIN>
  PIN format: XXXX-XXXX or XXXXXXXX (8 digits from TV screen)

IMPORTANT: PIN rotates on each attempt. Run immediately after getting code!
"""

import sys
sys.path.insert(0, '/home/igareosh/.local/lib/python3.10/site-packages')

import socket
import json
import hashlib
import hkdf
from homekit.crypto.srp import SrpClient, Srp
from homekit.crypto import chacha20_aead_encrypt, chacha20_aead_decrypt
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

HOST = '192.168.100.54'
PORT = 7001
OUTPUT_FILE = '/data/workspaces/cursor/cluster/fulgusor/vidaa-homekit.json'


def tlv_encode(d):
    """Encode dict to TLV8."""
    r = b''
    for t, v in d.items():
        if isinstance(v, int):
            v = bytes([v])
        while len(v) > 255:
            r += bytes([t, 255]) + v[:255]
            v = v[255:]
        r += bytes([t, len(v)]) + v
    return r


def tlv_decode(d):
    """Decode TLV8 to dict."""
    r = {}
    i = 0
    while i < len(d):
        t, l = d[i], d[i + 1]
        r[t] = r.get(t, b'') + d[i + 2:i + 2 + l]
        i += 2 + l
    return r


def http_post(sock, path, body):
    """Send HTTP POST, return response body."""
    req = f'POST {path} HTTP/1.1\r\nHost: {HOST}\r\nContent-Type: application/pairing+tlv8\r\nContent-Length: {len(body)}\r\n\r\n'
    sock.sendall(req.encode() + body)

    resp = b''
    while b'\r\n\r\n' not in resp:
        resp += sock.recv(4096)

    header, body_data = resp.split(b'\r\n\r\n', 1)
    content_length = 0
    for line in header.decode().split('\r\n'):
        if line.lower().startswith('content-length:'):
            content_length = int(line.split(':')[1].strip())

    while len(body_data) < content_length:
        body_data += sock.recv(4096)

    return body_data[:content_length]


def format_pin(pin):
    """Format PIN as XXX-XX-XXX."""
    pin = pin.replace('-', '')
    if len(pin) != 8:
        raise ValueError("PIN must be 8 digits")
    return f"{pin[:3]}-{pin[3:5]}-{pin[5:]}"


def pair(pin_raw):
    """Perform HomeKit pairing."""
    pin = format_pin(pin_raw)
    print(f"HomeKit Pairing: {HOST}:{PORT}")
    print(f"PIN: {pin}\n")

    sock = socket.socket()
    sock.settimeout(30)
    sock.connect((HOST, PORT))
    print("Connected")

    try:
        # M1: Start pairing
        print("[M1] Starting...")
        r = tlv_decode(http_post(sock, '/pair-setup', tlv_encode({0x00: 0x00, 0x06: 0x01})))
        if 0x07 in r:
            raise Exception(f"M2 error: {r[0x07]}")
        salt, B = r[0x02], r[0x03]
        print(f"[M2] salt={len(salt)}B, B={len(B)}B")

        # M3: SRP (using homekit's correct implementation)
        print("[M3] SRP...")
        srp = SrpClient('Pair-Setup', pin)
        srp.set_salt(salt)
        srp.set_server_public_key(B)

        A = bytes(Srp.to_byte_array(srp.get_public_key()))
        proof = bytes(Srp.to_byte_array(srp.get_proof()))

        r = tlv_decode(http_post(sock, '/pair-setup', tlv_encode({0x06: 0x03, 0x03: A, 0x04: proof})))
        if 0x07 in r:
            err = r[0x07][0] if r[0x07] else 0
            errors = {2: 'Unknown', 3: 'Wrong PIN', 4: 'Backoff', 5: 'MaxPeers', 6: 'MaxTries'}
            raise Exception(f"M4 error {err}: {errors.get(err, '?')}")
        if 0x04 not in r:
            raise Exception("M4: No proof - PIN likely wrong/expired")

        if not srp.verify_servers_proof(r[0x04]):
            raise Exception("Server proof verification failed")
        print("[M4] OK - PIN verified!")

        # Get SRP session key
        srp_sk = bytes(Srp.to_byte_array(srp.get_session_key()))

        # M5: Key exchange
        # IMPORTANT: Two separate HKDF derivations!
        print("[M5] Key exchange...")

        # 1. For signing
        hkdf1 = hkdf.Hkdf(b'Pair-Setup-Controller-Sign-Salt', srp_sk, hash=hashlib.sha512)
        ios_device_x = hkdf1.expand(b'Pair-Setup-Controller-Sign-Info', 32)

        # 2. For encryption (different!)
        hkdf2 = hkdf.Hkdf(b'Pair-Setup-Encrypt-Salt', srp_sk, hash=hashlib.sha512)
        enc_key = hkdf2.expand(b'Pair-Setup-Encrypt-Info', 32)

        # Generate controller long-term keys
        ltsk = Ed25519PrivateKey.generate()
        ltpk = ltsk.public_key().public_bytes_raw()
        did = b'PyHAPCtrl001'

        # Sign: ios_device_x || pairing_id || ltpk
        sig = ltsk.sign(ios_device_x + did + ltpk)

        # Encrypt sub-TLV (IMPORTANT: correct nonce order!)
        sub_tlv = tlv_encode({0x01: did, 0x03: ltpk, 0x0a: sig})
        enc_data, tag = chacha20_aead_encrypt(bytes(), enc_key, b'PS-Msg05', bytes([0,0,0,0]), sub_tlv)
        encrypted = bytearray(enc_data) + tag

        r = tlv_decode(http_post(sock, '/pair-setup', tlv_encode({0x06: 0x05, 0x05: bytes(encrypted)})))
        if 0x07 in r:
            raise Exception(f"M6 error: {r[0x07]}")
        if 0x05 not in r:
            raise Exception("M6: No encrypted data")

        # M6: Receive accessory info
        dec = chacha20_aead_decrypt(bytes(), enc_key, b'PS-Msg06', bytes([0,0,0,0]), r[0x05])
        if dec is False:
            raise Exception("M6 decryption failed")

        ac = tlv_decode(dec)
        acc_id = ac[0x01].decode()
        acc_ltpk = ac[0x03]
        print(f"[M6] Accessory ID: {acc_id}")

        # Save credentials
        creds = {
            'accessory_id': acc_id,
            'accessory_ltpk': acc_ltpk.hex(),
            'ios_device_id': did.decode(),
            'ios_ltsk': ltsk.private_bytes_raw().hex(),
            'ios_ltpk': ltpk.hex(),
            'host': HOST,
            'port': PORT
        }

        with open(OUTPUT_FILE, 'w') as f:
            json.dump(creds, f, indent=2)

        print(f"\n*** PAIRING SUCCESSFUL! ***")
        print(f"Saved to {OUTPUT_FILE}")
        return True

    finally:
        sock.close()


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)

    try:
        pair(sys.argv[1])
    except Exception as e:
        print(f"\nFAILED: {e}")
        sys.exit(1)
