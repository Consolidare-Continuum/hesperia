#!/bin/bash
# One-time: rename /mnt/heimdall/proton_backup to /mnt/heimdall/fulgusor_proton_drive on fulgusor.
# Run from prichindel: ./scripts/fulgusor-rename-proton-drive.sh
# After running: on fulgusor, from igareosh login session run: systemctl --user daemon-reload && systemctl --user start rclone-proton-backup.mount.service

set -e
ssh fulgusor "systemctl --user stop rclone-proton-backup.mount.service 2>/dev/null; sleep 2; fusermount -uz /mnt/heimdall/fulgusor_proton_drive 2>/dev/null; sudo mkdir -p /mnt/heimdall/fulgusor_proton_drive && sudo chown igareosh:igareosh /mnt/heimdall/fulgusor_proton_drive"
# Service file: use cluster/fulgusor/rclone-fulgusor-proton-drive.service and copy to fulgusor ~/.config/systemd/user/rclone-proton-backup.mount.service
echo "Copy cluster/fulgusor/rclone-fulgusor-proton-drive.service to fulgusor; then from igareosh login on fulgusor: systemctl --user daemon-reload && systemctl --user start rclone-proton-backup.mount.service"
echo "Done. Fulgusor Proton Drive path: /mnt/heimdall/fulgusor_proton_drive"
