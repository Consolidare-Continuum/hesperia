#!/usr/bin/env bash
# Fresh Authentik redeploy on trustmaster (192.168.100.67).
# Run from brain repo:
#   ssh prichindel 'ssh igareosh@192.168.100.67 sudo bash -s' < scripts/trustmaster_authentik_fresh_redeploy.sh
#
# Backup: /root/authentik-full-backup-<tag>.tgz ; data dirs moved under /opt/authentik-archive/pre-redeploy-<tag>/
# Rotates PG_PASS + AUTHENTIK_SECRET_KEY; preserves bootstrap and other .env keys.
# After run, separately pipe trustmaster_ensure_core_identities.py into ak shell if you want team users.
set -euo pipefail

ROOT=/opt/authentik
COMPOSE=(docker compose -f "$ROOT/docker-compose.yml" --env-file "$ROOT/.env")
TAG="$(date +%Y%m%d-%H%M%S)"
ARCHIVE="/opt/authentik-archive/pre-redeploy-$TAG"
HEALTH_URL="${TRUSTMASTER_HEALTH_URL:-http://192.168.100.67:9000/-/health/live/}"

mkdir -p "$ARCHIVE"
echo "== Backup /opt/authentik -> /root/authentik-full-backup-${TAG}.tgz"
tar czf "/root/authentik-full-backup-${TAG}.tgz" -C /opt authentik

cd "$ROOT"
echo "== compose down"
"${COMPOSE[@]}" down --remove-orphans || true

echo "== remove orphan authentik-proxy containers"
mapfile -t PROXY_IDS < <(docker ps -aq --filter name=authentik-proxy)
if ((${#PROXY_IDS[@]})); then docker rm -f "${PROXY_IDS[@]}"; fi

for d in postgres redis media; do
  if [[ -d "$ROOT/$d" ]]; then
    mv "$ROOT/$d" "$ARCHIVE/${d}"
  fi
  mkdir -p "$ROOT/$d"
done

echo "== rotate PG_PASS + AUTHENTIK_SECRET_KEY (bootstrap preserved)"
python3 <<'PY'
import secrets
from pathlib import Path
p = Path("/opt/authentik/.env")
lines = p.read_text().splitlines()
out = []
pg = secrets.token_hex(24)
sk = secrets.token_hex(48)
for line in lines:
    if line.startswith("PG_PASS="):
        out.append(f"PG_PASS={pg}")
    elif line.startswith("AUTHENTIK_SECRET_KEY="):
        out.append(f"AUTHENTIK_SECRET_KEY={sk}")
    else:
        out.append(line)
p.write_text("\n".join(out) + "\n")
p.chmod(0o600)
print("Rotated PG_PASS and AUTHENTIK_SECRET_KEY")
PY

echo "== compose pull + up"
"${COMPOSE[@]}" pull || true
"${COMPOSE[@]}" up -d

echo "== wait for $HEALTH_URL"
for _ in $(seq 1 90); do
  if curl -sf "$HEALTH_URL" >/dev/null 2>&1; then
    echo "server healthy"
    break
  fi
  sleep 2
done

echo "== embedded outpost: authentik_host → http://server:9000 (browser URL unchanged)"
docker exec -i authentik-server-1 ak shell <<'EOS'
from dataclasses import replace
from authentik.outposts.models import Outpost
for o in Outpost.objects.all():
    o.config = replace(o.config, authentik_host="http://server:9000")
    o.save()
    print("outpost", o.name, o.config.authentik_host, o.config.authentik_host_browser)
EOS

echo "== apply blueprint prichindel-oauth-cf-access-redirects (empty on fresh DB; add OAuth clients later)"
docker exec authentik-server-1 ak apply_blueprint /blueprints/prichindel-oauth-cf-access-redirects.yaml || \
docker exec authentik-server-1 python /manage.py apply_blueprint /blueprints/prichindel-oauth-cf-access-redirects.yaml || true

echo "== post-fresh (required once per empty DB): copy repo cluster/trustmaster/docker-compose.authentik.yml to /opt/authentik/docker-compose.yml, then:"
echo "    sudo bash /opt/authentik/append_outpost_key_to_env.sh && cd /opt/authentik && sudo docker compose -f docker-compose.yml --env-file .env up -d outpost-proxy"
echo "    + ak shell: link Embedded Outpost to Local Docker connection, authentik_host http://server:9000, docker_network authentik_default, at least one ProxyProvider (see operational notes)."

echo "DONE. Backup /root/authentik-full-backup-${TAG}.tgz | archived dirs $ARCHIVE"
curl -sS -o /dev/null -w "health HTTP %{http_code}\n" "$HEALTH_URL" || true
"${COMPOSE[@]}" ps
