#Requires -Version 5.1
# LAMAITA: merge Host altitudine into OpenSSH config (VS Code Remote-SSH). Run on LAMAITA from repo root.
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File scripts/lamaita-append-altitudine-ssh.ps1

$ErrorActionPreference = "Stop"
$RepoRoot = Split-Path -Parent $PSScriptRoot
$FragmentPath = Join-Path $RepoRoot "cluster\lamaita\ssh-config-altitudine.fragment"
$Marker = "Host altitudine"

if (-not (Test-Path $FragmentPath)) {
    throw "Missing $FragmentPath"
}

$fragment = Get-Content $FragmentPath -Raw -Encoding UTF8

function Merge-Config([string]$SshDir) {
    if (-not (Test-Path $SshDir)) {
        New-Item -ItemType Directory -Path $SshDir -Force | Out-Null
    }
    $config = Join-Path $SshDir "config"
    if ((Test-Path $config) -and (Select-String -Path $config -Pattern "^\s*Host\s+altitudine\s*$" -Quiet)) {
        Write-Host "OK: $config already has Host altitudine"
        return
    }
    Add-Content -Path $config -Value $fragment -Encoding utf8
    Write-Host "OK: appended altitudine hosts to $config"
}

foreach ($profile in @(
        (Join-Path $env:USERPROFILE ".ssh"),
        "C:\Users\BvSsh_lamaita\.ssh"
    )) {
    if (Test-Path (Split-Path $profile -Parent)) {
        Merge-Config $profile
    }
}

Write-Host "Test (LAN): ssh altitudine hostname"
Write-Host "VS Code: Remote-SSH -> altitudine -> open folder on dev VM"
