#!/usr/bin/env python3
"""
Full-auto product: after each workflow pass, append one JSONL record with routing hint + Chroma snippet + stuck detection.
Spec: governance/SPEC-ETHAN-FULL-AUTO-ACTIVE-MD-PRODUCT.md
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(os.environ.get("WORKFLOW_REPO_ROOT", os.getcwd())).resolve()
CURRENT = REPO / "governance" / "workflow_driver_current.txt"
CONTEXT = REPO / "governance" / "workflow_context_current.md"
OUT = REPO / "operational" / "workflow_full_auto_escalation.jsonl"
STUCK = REPO / "governance" / "workflow_full_auto_stuck_state.json"
THRESH = int(os.environ.get("WORKFLOW_FULL_AUTO_STUCK_ROUNDS", "8"))

# Driver appends `| <ISO8601>Z` (workflow_driver.py). Strip by regex so we do not depend on
# counting `|` splits (task text can theoretically contain `|`).
_TRAILING_DRIVER_TS = re.compile(
    r"\|\s*\d{4}-\d{2}-\d{2}T[\d:.+-]+(?:Z|[+-]\d{2}:?\d{2})?\s*$"
)


def _stable_current_step_line(line: str) -> str:
    """Strip trailing `| timestamp` from driver line — same logical OPEN step must fingerprint stable."""
    return _TRAILING_DRIVER_TS.sub("", line.strip()).strip()


def _fingerprint(line: str) -> str:
    stable = _stable_current_step_line(line)
    return hashlib.sha256(stable.encode("utf-8", errors="replace")).hexdigest()[:16]


def _chroma_hint(owner: str, project: str) -> str:
    try:
        if str(REPO) not in sys.path:
            sys.path.insert(0, str(REPO))
        from agent_mcp_knowledge.store import query as chroma_query

        qt = f"workflow escalation runbook {project} {owner} active.md OPEN"
        res = chroma_query(qt, n_results=2, layer="governance")
        if not res:
            res = chroma_query(qt, n_results=2)
        if res and isinstance(res[0], dict):
            return (res[0].get("text") or "")[:500]
    except Exception as exc:
        return f"(chroma_skip:{type(exc).__name__})"
    return ""


def _stuck_update(fp: str) -> tuple[int, bool]:
    if not fp:
        return 0, False
    prev_fp = ""
    n = 0
    if STUCK.exists():
        try:
            data = json.loads(STUCK.read_text(encoding="utf-8", errors="replace"))
            prev_fp = data.get("fingerprint", "")
            n = int(data.get("count", 0))
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            pass
    if fp == prev_fp:
        n += 1
    else:
        n = 1
    STUCK.write_text(json.dumps({"fingerprint": fp, "count": n}) + "\n", encoding="utf-8")
    stuck = n >= THRESH
    return n, stuck


def main() -> int:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    raw = CURRENT.read_text(encoding="utf-8", errors="replace") if CURRENT.exists() else ""
    first = raw.strip().split("\n")[0] if raw.strip() else ""

    owner = ""
    project = ""
    route = "UNKNOWN"
    fp = ""

    if "No OPEN tasks" in raw or "project_idle" in raw or "autonomous_idle" in raw:
        route = "IDLE"
    elif first and not first.startswith("#"):
        stable = _stable_current_step_line(first)
        seg = [p.strip() for p in stable.split("|")]
        # Driver: priority | project | task... | owner (task may contain '|')
        if len(seg) >= 4:
            project = seg[1]
            owner = seg[-1]
            ol = owner.lower()
            if "abelard" in ol:
                route = "ABELARD_SERVER_OR_MCP"
            else:
                route = "MCP_CURSOR_REPORT_DONE"
            fp = _fingerprint(first)

    stuck_n, stuck = _stuck_update(fp)
    hint = _chroma_hint(owner, project) if route not in ("IDLE",) else ""
    context_passport = CONTEXT.read_text(encoding="utf-8", errors="replace")[:1200] if CONTEXT.exists() else ""

    rec: dict = {
        "ts": ts,
        "current_step_line": first[:500],
        "owner": owner,
        "project": project,
        "route_hint": route,
        "chroma_hint": hint,
        "context_passport": context_passport,
        "stuck_rounds": stuck_n,
        "stuck_threshold": THRESH,
    }
    if stuck:
        rec["escalation"] = "task_grace_triage"
        rec["stuck"] = True

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(json.dumps(rec, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
