#!/usr/bin/env bash
# One-time: install prichindel igareosh id_rsa.pub onto izvoras igareosh authorized_keys.
# Run ON prichindel as igareosh. Password only via env (never commit; unset after).
#
#   export SSHPASS='your-one-time-password'
#   bash scripts/izvoras-ssh-copy-id-from-prichindel.sh
#   unset SSHPASS
#
# Requires: TCP 22 reachable (nc -zv 192.168.100.58 22), sshpass, ssh-copy-id.
set -euo pipefail
TARGET="${IZVORAS_IP:-192.168.100.58}"
USERN="${IZVORAS_USER:-igareosh}"
PUB="${HOME}/.ssh/id_rsa.pub"
if [[ -z "${SSHPASS:-}" ]]; then
  echo "BLOCKED: set SSHPASS for one-time password auth, then rerun. Example: export SSHPASS='...'; bash $0; unset SSHPASS"
  exit 1
fi
if [[ ! -f "$PUB" ]]; then
  echo "FAIL: missing $PUB"
  exit 1
fi
command -v sshpass >/dev/null || { echo "FAIL: install sshpass (apt install sshpass)"; exit 1; }
command -v ssh-copy-id >/dev/null || { echo "FAIL: install openssh-client"; exit 1; }
# Password first: default ssh-copy-id tries pubkey and can fail before password.
sshpass -e ssh-copy-id -i "$PUB" \
  -o PreferredAuthentications=password -o PubkeyAuthentication=no \
  -o StrictHostKeyChecking=accept-new -o ConnectTimeout=12 \
  "${USERN}@${TARGET}"
echo "DONE: test with: ssh -o BatchMode=yes ${USERN}@${TARGET} hostname"
