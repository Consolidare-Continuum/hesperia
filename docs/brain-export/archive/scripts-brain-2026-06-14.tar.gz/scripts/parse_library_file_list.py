#!/usr/bin/env python3
"""Parse Proton/Drive-style paste into TSV: Name\\tSize\\tModified.

Reads from a file path or stdin. Never pipe multi-megabyte pastes through the agent shell JSON;
save to operational/library_paste_raw.txt and run scripts/library_list_from_paste.sh instead.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


def parse_paste(text: str) -> list[tuple[str, str, str]]:
    lines = [ln.rstrip("\n") for ln in text.splitlines()]
    out: list[tuple[str, str, str]] = []
    i = 0
    skip_prefixes = ("Name", "Size", "Modified", "FavoriteSelect", "ShareActions")
    while i < len(lines):
        line = lines[i].strip()
        if line in skip_prefixes or (
            line.endswith(" files") and line[:-6].strip().isdigit()
        ):
            i += 1
            continue
        if line.startswith(("EN - ", "RU - ")):
            name = line.replace("&amp;", "&")
            i += 1
            if i < len(lines) and lines[i].strip() == "ShareActions":
                i += 1
            if i >= len(lines):
                break
            sm = lines[i].strip()
            i += 1
            if "\t" in sm:
                size, mod = sm.split("\t", 1)
            else:
                m = re.match(
                    r"^(.+?)\s+((?:\d+|a)\s+(?:hour|hours|day|days|month|months|year|years)\s+ago)$",
                    sm,
                )
                if m:
                    size, mod = m.group(1).strip(), m.group(2).strip()
                else:
                    size, mod = sm, ""
            out.append((name, size.strip(), mod.strip()))
            continue
        i += 1
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument(
        "input",
        nargs="?",
        help="Paste file (UTF-8). Omit to read stdin.",
    )
    ap.add_argument(
        "-o",
        "--output",
        metavar="FILE",
        help="Write TSV here instead of stdout.",
    )
    ap.add_argument(
        "--header",
        action="store_true",
        help="Emit header row Name<TAB>Size<TAB>Modified.",
    )
    args = ap.parse_args()

    if args.input:
        text = Path(args.input).read_text(encoding="utf-8", errors="replace")
    else:
        text = sys.stdin.read()

    rows = parse_paste(text)
    lines_out: list[str] = []
    if args.header:
        lines_out.append("Name\tSize\tModified")
    lines_out.extend(f"{n}\t{s}\t{m}" for n, s, m in rows)
    body = "\n".join(lines_out) + ("\n" if lines_out else "")

    if args.output:
        Path(args.output).write_text(body, encoding="utf-8", newline="\n")
    else:
        sys.stdout.write(body)


if __name__ == "__main__":
    main()
