# fluturas-uninstall-cruft.ps1 — Uninstall programs not in FLUTURAS-POLICY keep list.
# Run on fluturas as Administrator. Keep: SQL Server 2022, Proton Drive, cloudflared, WSL, VC++, VS Code/Cursor, Plexamp, Chrome, Cursor, Git.
# OneDrive = spyware: run scripts/fluturas-onedrive-remove.ps1 separately (disable, uninstall, remove remnants).
# Requires: -ExecutionPolicy Bypass

$ErrorActionPreference = 'Continue'
$remove = @(
    'DiagnosticsHub_CollectionService',
    'Microsoft Update Health Tools',
    'Microsoft MPI (10.1.12498.18)',
    'Browser for SQL Server 2022'
)
foreach ($name in $remove) {
    $p = Get-WmiObject -Class Win32_Product -Filter "Name='$name'" -ErrorAction SilentlyContinue
    if ($p) {
        Write-Host "Uninstalling: $name"
        $p.Uninstall() | Out-Null
    }
}
Write-Host "Done. Reboot if prompted."
