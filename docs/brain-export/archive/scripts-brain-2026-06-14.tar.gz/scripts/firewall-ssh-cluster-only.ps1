# Restrict laptop SSH server (inbound 22) to cluster only: prichindel + fulgusor.
# Outbound SSH from laptop stays unrestricted (internet-wide). Run as Administrator.
# See cluster/LAPTOP-SECURITY.md.

$ErrorActionPreference = 'Stop'
$clusterIPs = '192.168.100.21,192.168.100.23,192.168.100.40'  # prichindel, fulgusor

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run as Administrator."
    exit 1
}

# Remove default rule that allows Any
netsh advfirewall firewall delete rule name="OpenSSH SSH Server Preview (sshd)" dir=in 2>$null

# Allow inbound TCP 22 only from cluster
netsh advfirewall firewall add rule name="OpenSSH SSH Server (cluster only)" dir=in action=allow protocol=TCP localport=22 remoteip=$clusterIPs profile=private,domain
Write-Host "Inbound SSH (port 22) allowed only from: $clusterIPs. Outbound SSH unchanged."
