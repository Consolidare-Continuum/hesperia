#!/usr/bin/env bash
# End-of-week brain workflow entry — Ethan product cadence.
# Usage: bash scripts/end_of_week_run.sh [collect|research|execute|until-done|full]
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"
MODE="${1:-full}"
WEEK="$(date -u +%G-W%V)"
WW="$(date -u +%V | sed 's/^0//')"
COLLECT="operational/assignments/reports/EOW-COLLECT-${WEEK}.txt"
WAVE_LABEL="REPO-EOW ${WEEK}"

open_eow_count() {
  grep -E 'REPO-EOW' active.md 2>/dev/null | grep -c '| OPEN |' || true
}

case "$MODE" in
  collect)
    bash scripts/end_of_week_collect.sh --out "$COLLECT"
    ;;
  research)
    python3 scripts/end_of_week_research.py
    ;;
  execute)
    python3 scripts/repo_auto_wave_execute.py --wave-label "$WAVE_LABEL" \
      --report "operational/assignments/reports/REPO-EOW-WAVE-EXECUTION-${WEEK}.json"
    ;;
  until-done)
    n="$(open_eow_count)"
    echo "REPO-EOW OPEN rows: ${n}"
    if [[ "${n}" -eq 0 ]]; then
      echo "EOW complete — zero OPEN REPO-EOW rows."
      exit 0
    fi
    echo "Continue: execute rows as owners; re-run until-done after marking DONE."
    grep -E 'REPO-EOW.*\| OPEN \|' active.md 2>/dev/null | head -20 || true
    exit 1
    ;;
  full)
    echo "EOW week=${WEEK} — follow .cursor/END-OF-WEEK-WORKFLOW.md"
    echo "Care: .cursor/EOW-CARE-MANDATE.md"
    echo "Spec: governance/SPEC-ETHAN-END-OF-WEEK-BRAIN-WORKFLOW.md"
    bash scripts/end_of_week_collect.sh --out "$COLLECT"
    python3 scripts/end_of_week_research.py
    echo ""
    echo "Next: Grace triage REPO-EOW-${WW}-001..050 → active.md (from EOW-TASK-REGISTER-${WEEK}.md)"
    echo "Then: bash scripts/end_of_week_run.sh execute"
    echo "Loop: bash scripts/end_of_week_run.sh until-done"
    echo "Then: commit/push, Chroma ingest, tersagor-operator-notify.sh"
    ;;
  *)
    echo "Usage: $0 [collect|research|execute|until-done|full]" >&2
    exit 2
    ;;
esac
