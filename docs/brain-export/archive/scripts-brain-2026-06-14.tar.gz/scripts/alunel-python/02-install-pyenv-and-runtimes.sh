#!/usr/bin/env bash
# alunel — pyenv + pinned CPython versions for development (run as igareosh, NOT root).
# Installs: 3.10.16 (legacy), 3.12.8 (primary global), 3.13.2 (forward stable).
# If pyenv lists a stable 3.14.x, installs the newest 3.14.x as well.
# After distro OpenSSL jump (e.g. 1.1 → 3): `pyenv install -f 3.12.8` (and other versions) or `_ssl` breaks.
# Ref: cluster/alunel/PYTHON-STANDARD.md
set -euo pipefail
export PYENV_ROOT="${PYENV_ROOT:-$HOME/.pyenv}"
export PATH="$PYENV_ROOT/bin:$PATH"

if [ "$(id -u)" -eq 0 ]; then
  echo "FAIL: run as igareosh, not root." >&2
  exit 1
fi

if ! command -v curl >/dev/null; then
  echo "FAIL: curl missing; run 01-install-build-deps.sh with sudo first." >&2
  exit 1
fi

if [ ! -d "$PYENV_ROOT" ]; then
  curl -fsSL https://pyenv.run | bash
fi

SHELL_RC="$HOME/.bashrc"
MARK="# alunel pyenv (PYTHON-STANDARD)"
if ! grep -qF "$MARK" "$SHELL_RC" 2>/dev/null; then
  {
    echo ""
    echo "$MARK"
    echo 'export PYENV_ROOT="$HOME/.pyenv"'
    echo 'command -v pyenv >/dev/null || export PATH="$PYENV_ROOT/bin:$PATH"'
    echo 'eval "$(pyenv init -)"'
  } >>"$SHELL_RC"
fi

eval "$(pyenv init -)"

pyenv install -s 3.10.16
pyenv install -s 3.12.8
pyenv install -s 3.13.2

# Forward: stable 3.14.x when pyenv provides it (not prerelease-only gate — install highest 3.14 patch)
V314=$(pyenv install -l 2>/dev/null | sed 's/^[[:space:]]*//' | grep -E '^3\.14\.[0-9]+$' | sort -V | tail -1 || true)
if [ -n "$V314" ]; then
  pyenv install -s "$V314"
fi

pyenv global 3.12.8
pyenv rehash

echo "--- pyenv versions ---"
pyenv versions
echo "OK: pyenv global=$(pyenv global). source ~/.bashrc or re-login."
