#!/usr/bin/env bash
# alunel — Python toolchain build dependencies (pyenv / source builds). Run with sudo.
# Does NOT install application pip packages. Ref: cluster/alunel/PYTHON-STANDARD.md
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
# Mirror sync glitches on us.archive sometimes return partial failures; retry, then install if lists are usable.
UPD_OK=0
for _ in 1 2 3; do
  if apt-get update -qq; then UPD_OK=1; break; fi
  sleep 8
done
if [ "$UPD_OK" -ne 1 ]; then
  echo "WARN: apt-get update failed after retries; attempting install (cached lists may suffice)." >&2
fi
apt-get install -y --no-install-recommends \
  make build-essential libssl-dev zlib1g-dev \
  libbz2-dev libreadline-dev libsqlite3-dev wget curl llvm \
  libncursesw5-dev xz-utils tk-dev libxml2-dev libxmlsec1-dev libffi-dev liblzma-dev \
  git ca-certificates
echo "OK: pyenv build deps installed."
