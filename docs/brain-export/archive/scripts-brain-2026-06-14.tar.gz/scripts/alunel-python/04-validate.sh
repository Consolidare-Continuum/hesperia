#!/usr/bin/env bash
# alunel — validation checklist (run as igareosh; docker commands may need sudo or docker group).
# Ref: cluster/alunel/PYTHON-STANDARD.md
set -euo pipefail
REPO="${REPO:-/data/workspaces/cursor}"
PY_DOCKER="$REPO/cluster/alunel/python/docker"
FAIL=0

echo "=== /usr/bin/python3 (OS only; noble = 3.12.x — not for Hesperia/app per PYTHON-STANDARD) ==="
/usr/bin/python3 --version || true

echo "=== /usr/local/bin/python3.12 (baseline symlink) ==="
if [ -e /usr/local/bin/python3.12 ] && /usr/local/bin/python3.12 --version >/dev/null 2>&1; then
  /usr/local/bin/python3.12 --version
else
  echo "WARN: /usr/local/bin/python3.12 missing or not runnable — run 03-symlink-system-python312.sh"
  FAIL=1
fi

echo "=== pyenv ==="
export PYENV_ROOT="${PYENV_ROOT:-$HOME/.pyenv}"
export PATH="$PYENV_ROOT/bin:$PATH"
if command -v pyenv >/dev/null; then
  eval "$(pyenv init -)" 2>/dev/null || true
  pyenv versions || true
  echo "global: $(pyenv global 2>/dev/null || echo n/a)"
else
  echo "WARN: pyenv not in PATH"
  FAIL=1
fi

echo "=== global pip packages (pyenv 3.12.8) — should be empty or minimal ==="
PY312_BIN="$HOME/.pyenv/versions/3.12.8/bin/python3.12"
if [ -x "$PY312_BIN" ]; then
  "$PY312_BIN" -m pip list --format=columns 2>/dev/null | head -20 || true
else
  echo "WARN: no pyenv 3.12.8"
  FAIL=1
fi

echo "=== Docker prod baseline image build ==="
if command -v docker >/dev/null; then
  if groups 2>/dev/null | grep -qw docker || [ "$(id -u)" -eq 0 ]; then
    DC=(docker)
  else
    DC=(sudo docker)
  fi
  if "${DC[@]}" build -f "$PY_DOCKER/Dockerfile.prod-baseline" -t alunel-python-prod:3.12.8-baseline "$PY_DOCKER"; then
    "${DC[@]}" run --rm alunel-python-prod:3.12.8-baseline
  else
    FAIL=1
  fi
else
  echo "WARN: docker CLI not found"
  FAIL=1
fi

if [ "$FAIL" -ne 0 ]; then
  echo "=== VALIDATION: INCOMPLETE / WARNINGS ==="
  exit 1
fi
echo "=== VALIDATION: OK ==="
