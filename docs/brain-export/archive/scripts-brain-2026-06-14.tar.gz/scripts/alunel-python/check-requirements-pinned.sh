#!/usr/bin/env bash
# Fail if requirements.txt has unpinned or range specifiers (== only for prod contract).
# Usage: check-requirements-pinned.sh [path/to/requirements.txt]
set -euo pipefail
FILE="${1:-cluster/alunel/python/docker/requirements.txt}"
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
cd "$REPO_ROOT"
if [ ! -f "$FILE" ]; then
  echo "FAIL: missing $FILE" >&2
  exit 1
fi
LINE_NO=0
ERR=0
while IFS= read -r line || [ -n "$line" ]; do
  LINE_NO=$((LINE_NO + 1))
  # strip comments
  line="${line%%#*}"
  # trim
  line="${line#"${line%%[![:space:]]*}"}"
  line="${line%"${line##*[![:space:]]}"}"
  [ -z "$line" ] && continue
  # forbid range / loose pins
  if echo "$line" | grep -qE '>=|<=|~=|!=|[<>]'; then
    echo "FAIL:$LINE_NO: range or loose pin not allowed: $line" >&2
    ERR=1
    continue
  fi
  # require == version (PEP 440 exact)
  if ! echo "$line" | grep -qE '==[0-9A-Za-z.*+!-]+'; then
    echo "FAIL:$LINE_NO: must use package==exact.version: $line" >&2
    ERR=1
  fi
done < "$FILE"
if [ "$ERR" -ne 0 ]; then
  exit 1
fi
echo "OK: $FILE — all lines pinned with =="
