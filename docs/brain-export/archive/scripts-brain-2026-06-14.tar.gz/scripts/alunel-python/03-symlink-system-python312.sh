#!/usr/bin/env bash
# alunel — expose pinned CPython 3.12.8 (pyenv) at /usr/local/bin/python3.12.
# On noble, /usr/bin/python3 is also 3.12.x (OS); Hesperia/app still use this path or Docker per PYTHON-STANDARD.
# Run with sudo after 02-install-pyenv-and-runtimes.sh (igareosh pyenv).
# Ref: cluster/alunel/PYTHON-STANDARD.md
set -euo pipefail
TARGET_USER="${TARGET_USER:-igareosh}"
PY312="/home/${TARGET_USER}/.pyenv/versions/3.12.8/bin/python3.12"

if [ "$(id -u)" -ne 0 ]; then
  echo "FAIL: run with sudo" >&2
  exit 1
fi

if [ ! -x "$PY312" ]; then
  echo "FAIL: missing $PY312 — run ~igareosh: bash scripts/alunel-python/02-install-pyenv-and-runtimes.sh" >&2
  exit 1
fi

ln -sf "$PY312" /usr/local/bin/python3.12
chmod +x /usr/local/bin/python3.12 2>/dev/null || true

echo "OK: /usr/local/bin/python3.12 -> $PY312"
/usr/local/bin/python3.12 --version
