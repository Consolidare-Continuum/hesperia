#!/usr/bin/env python3
# Copyright (c) prichindel.com. All rights reserved.
"""
Workflow orchestrator — heartbeat only (Invoke 2.2).

Reads active.md and agents/grace/assignments.md; emits a status report (heartbeat).
Runnable by Cursor on prichindel. No credentials; read-only. SECURITY-BASELINE applies.

Usage:
  workflow_orchestrator.py                    # write heartbeat to default file
  workflow_orchestrator.py --stdout            # also print report to stdout
  workflow_orchestrator.py --output PATH       # write to PATH instead of default

Default heartbeat file: governance/workflow_heartbeat.txt (relative to repo root).
Captain on deck: if governance/captain_on_deck contains 1 (or env CAPTAIN_ON_DECK set), script still emits heartbeat only (no trigger chain). Ref: governance/WORKFLOW-AUTOMATION-CODE-PLAN-TASK.md §7.2, governance/AUTOMATION-SCRIPTING-TEAM-POLICY.md §8.1.
"""
from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


def _repo_root() -> Path:
    root = Path(__file__).resolve().parent.parent
    env_root = os.environ.get("WORKFLOW_REPO_ROOT", "").strip()
    if env_root and Path(env_root).is_dir():
        return Path(env_root)
    return root


def _parse_active_md(path: Path) -> dict:
    """Parse active.md table: count by status (OPEN, IN_PROGRESS, PAUSED, DONE); sample OPEN rows; IN_PROGRESS (who-is-working) rows."""
    out = {"OPEN": 0, "IN_PROGRESS": 0, "PAUSED": 0, "DONE": 0, "open_rows": [], "in_progress_rows": []}
    if not path.exists():
        return out
    text = path.read_text(encoding="utf-8", errors="replace")
    # Table rows: | Priority | Project | Task | Owner | STATUS | Link |
    for line in text.splitlines():
        if not line.strip().startswith("|") or line.strip() == "|--":
            continue
        parts = [p.strip() for p in line.split("|") if p]
        if len(parts) < 5:
            continue
        status = parts[4].upper()
        if status in out:
            out[status] += 1
        if status == "OPEN" and len(parts) >= 4:
            out["open_rows"].append(f"{parts[1]} | {parts[2]} | {parts[3]}")
        if status == "IN_PROGRESS" and len(parts) >= 4:
            # Who-is-working: owner, task (and project for context)
            out["in_progress_rows"].append(f"{parts[3]} | {parts[1]} | {parts[2]}")
    return out


def _parse_assignments_md(path: Path) -> list[str]:
    """Extract lines that look like '**Assign to: ...' or '→ **Picked up' (latest assignments)."""
    out: list[str] = []
    if not path.exists():
        return out
    text = path.read_text(encoding="utf-8", errors="replace")
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("**Assign to:") or s.startswith("→ **Picked up") or s.startswith("**Assign to :"):
            out.append(s[:200] + ("…" if len(s) > 200 else ""))
    return out[-5:]  # last 5 assignment-like lines


def _captain_on_deck(repo_root: Path) -> bool:
    """True if captain on deck (workflow automation disabled; heartbeat-only still allowed). Env CAPTAIN_ON_DECK overrides file for tests."""
    env_val = os.environ.get("CAPTAIN_ON_DECK", "").strip().lower()
    if env_val in ("1", "true", "yes"):
        return True
    if env_val in ("0", "false", "no"):
        return False
    path = repo_root / "governance" / "captain_on_deck"
    if not path.exists():
        return False
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        for line in text.splitlines():
            val = line.strip().lower()
            if not val:
                continue
            if val in ("1", "true", "yes"):
                return True
            return False
    except OSError:
        return False
    return False


def _build_report(repo_root: Path, captain_on_deck: bool = False) -> str:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    active_path = repo_root / "active.md"
    assignments_path = repo_root / "agents" / "grace" / "assignments.md"

    active = _parse_active_md(active_path)
    assignments = _parse_assignments_md(assignments_path)

    lines = [
        "# Workflow heartbeat",
        f"last_run: {now}",
        f"captain_on_deck: {'true' if captain_on_deck else 'false'}",
        "",
        "## active.md summary",
        f"OPEN: {active['OPEN']}  IN_PROGRESS: {active['IN_PROGRESS']}  PAUSED: {active['PAUSED']}  DONE: {active['DONE']}",
        "",
    ]
    if active["in_progress_rows"]:
        lines.append("## Who is working (IN_PROGRESS)")
        for row in active["in_progress_rows"]:
            lines.append(f"  - {row}")
        lines.append("")
    if active["open_rows"]:
        lines.append("Open tasks (sample):")
        for row in active["open_rows"][:10]:
            lines.append(f"  - {row}")
        lines.append("")
    lines.append("## Latest assignments (agents/grace/assignments.md)")
    if assignments:
        for a in assignments:
            lines.append(f"  {a}")
    else:
        lines.append("  (none)")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Workflow orchestrator heartbeat (read active + assignments, write report).")
    parser.add_argument("--stdout", action="store_true", help="Print report to stdout in addition to file")
    parser.add_argument("--output", metavar="PATH", help="Heartbeat file path (default: governance/workflow_heartbeat.txt)")
    args = parser.parse_args()

    repo_root = _repo_root()
    captain = _captain_on_deck(repo_root)
    report = _build_report(repo_root, captain_on_deck=captain)

    out_path = args.output
    if not out_path:
        out_path = repo_root / "governance" / "workflow_heartbeat.txt"
    else:
        out_path = Path(out_path)
    out_path = out_path.resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(report, encoding="utf-8")

    if args.stdout:
        print(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
