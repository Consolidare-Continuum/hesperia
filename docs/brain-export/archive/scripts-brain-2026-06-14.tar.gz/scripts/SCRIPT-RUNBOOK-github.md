# Runbook: GitHub PR check flow (optional)

**Owner**: Liam (automation lead).
**Purpose**: Optional CI-like PR status check using `gh` CLI. Gracefully skips if `gh` is not installed.

---

## Usage

```bash
gh pr checks
```

**Prerequisites**: `gh` CLI installed and authenticated (`gh auth login`).

## Exit codes

| Code | Meaning |
|------|---------|
| 0 | All checks pass |
| 1 | One or more checks failed |
| 127 | `gh` not found (not installed) — skip gracefully |

## Monthly check

Once per month, verify no stale open PRs:

```bash
gh pr list --repo igareosh/cursor --state open
```

If `gh` is not available, skip — this flow is optional and does not block workflow.

## Integration

- Not wired into workflow automation (optional manual use).
- If `gh` becomes available cluster-wide, Liam may add a cron or pre-push hook.

SIGNED: Automation Lead (Liam) | Ethan context | 2026-05-14 | BF-033 runbook
