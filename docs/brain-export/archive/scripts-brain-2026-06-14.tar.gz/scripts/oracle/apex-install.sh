#!/usr/bin/env bash
# Install APEX application export (.sql) into prichindelbd.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
CONNECT="${REPO_ROOT}/scripts/oracle/sqlcl-connect.sh"

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <apex_export.sql>" >&2
  exit 1
fi
EXPORT="$1"
if [[ ! -f "${EXPORT}" ]]; then
  echo "Not found: ${EXPORT}" >&2
  exit 1
fi

"${CONNECT}" @"${EXPORT}"
echo "Installed: ${EXPORT}"
