#!/usr/bin/env bash
# Build teatru App 100 v6 Ethan download zip.
# Output: <repo-root>/teatru-app100-v6-YYYYMMDD.zip
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ORDS_SQL="${REPO_ROOT}/scripts/oracle/ords-sql.sh"
FLOW100="${REPO_ROOT}/user_documents/oracle_apex/apex/apps/flow_100"
APEX_SQL="${REPO_ROOT}/user_documents/oracle_apex/sql"
STAMP="$(date +%Y%m%d)"
WORK="${REPO_ROOT}/.export/teatru-app100-v6-${STAMP}"
ZIP="${REPO_ROOT}/teatru-app100-v6-${STAMP}.zip"

need_sudo() {
  local secrets="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
  if [[ "${EUID}" -ne 0 ]] && [[ ! -r "${secrets}" ]]; then
    exec sudo -E "$0" "$@"
  fi
}

run_query_scalar() {
  local sql="$1"
  local py="$2"
  sudo "${ORDS_SQL}" "${sql}" | python3 -c "${py}"
}

export_live_ddl() {
  local out="$1"
  local tables=(SPECTACOLE PROGRAM_SPECTACOLE LOCURI BILETE CLIENTI REZERVARI ACHITARI)
  local views=(V_PROGRAM_SPECTACOLE V_REZERVARI_ACHITARI)

  cat >"${out}" <<EOF
-- App 100 Teatru — live PRICHINDEL schema DDL export
-- Generated: $(date -u +%Y-%m-%dT%H:%MZ) via export-teatru-v6-bundle.sh

SET DEFINE OFF

EOF

  for t in "${tables[@]}"; do
    echo "-- TABLE ${t}" >>"${out}"
    run_query_scalar \
      "SELECT DBMS_METADATA.GET_DDL('TABLE', '${t}') AS ddl FROM dual" \
      "import sys,json; d=json.load(sys.stdin); i=d['items'][0];
assert 'errorMessage' not in i, i.get('errorMessage','error');
print(i['resultSet']['items'][0]['ddl'])" >>"${out}" || {
        echo "-- WARN: could not export TABLE ${t}" >>"${out}"
      }
    echo >>"${out}"
  done

  for v in "${views[@]}"; do
    echo "-- VIEW ${v}" >>"${out}"
    run_query_scalar \
      "SELECT DBMS_METADATA.GET_DDL('VIEW', '${v}') AS ddl FROM dual" \
      "import sys,json; d=json.load(sys.stdin); i=d['items'][0];
assert 'errorMessage' not in i, i.get('errorMessage','error');
print(i['resultSet']['items'][0]['ddl'])" >>"${out}" 2>/dev/null || {
        echo "-- WARN: view ${v} not present in live schema" >>"${out}"
      }
    echo >>"${out}"
  done
}

build_app_bundle() {
  local out="$1"
  cat >"${out}" <<EOF
-- App 100 prichindel-ulim — v6 Ethan deploy bundle (concatenated)
-- Generated: $(date -u +%Y-%m-%dT%H:%MZ)
-- Matches: scripts/oracle/oracle-dev.sh deploy-teatru-v6

SET DEFINE OFF

EOF
  for f in \
    "${FLOW100}/remove_teatru_pages_v5.sql" \
    "${FLOW100}/add_teatru_pages_v6_stacked_md.sql" \
    "${FLOW100}/add_teatru_v6_form_overlay.sql" \
    "${FLOW100}/fix_teatru_page_no_auto_nav.sql" \
    "${FLOW100}/purge_teatru_nav.sql" \
    "${FLOW100}/add_teatru_nav_v4.sql"
  do
    echo "-- ===== FILE: $(basename "${f}") =====" >>"${out}"
    cat "${f}" >>"${out}"
    echo >>"${out}"
  done
}

main() {
  need_sudo "$@"
  python3 "${FLOW100}/build_v6_ethan.py"
  rm -rf "${WORK}"
  mkdir -p "${WORK}/database" "${WORK}/app" "${WORK}/v6"

  echo "Exporting live database DDL..."
  export_live_ddl "${WORK}/database/teatru_schema_live_ddl.sql"
  cp "${APEX_SQL}/teatru_odata_ca_niciodata_schema.sql" "${WORK}/database/teatru_schema_repo_bootstrap.sql"

  echo "Building app deploy bundle..."
  build_app_bundle "${WORK}/app/flow_100_v6_deploy_bundle.sql"

  cp "${FLOW100}/TEATRU-V6-ETHAN-BASELINE.md" "${WORK}/v6/" 2>/dev/null || true
  cp "${FLOW100}/README.md" "${WORK}/v6/"
  for f in \
    build_v6_ethan.py \
    build_v5_stacked_md.py \
    build_v5_form_baseline_overlay.py \
    add_teatru_pages_v6_stacked_md.sql \
    add_teatru_v6_form_overlay.sql \
    verify_v6_ethan.sql \
    remove_teatru_pages_v5.sql \
    fix_teatru_page_no_auto_nav.sql \
    purge_teatru_nav.sql \
    add_teatru_nav_v4.sql
  do
    cp "${FLOW100}/${f}" "${WORK}/v6/${f}"
  done

  cat >"${WORK}/MANIFEST.md" <<EOF
# Teatru App 100 v6 Ethan bundle (${STAMP})

Canonical UI path: \`deploy-teatru-v6\`

| Path | Contents |
|------|----------|
| \`database/teatru_schema_live_ddl.sql\` | Live PRICHINDEL DDL |
| \`app/flow_100_v6_deploy_bundle.sql\` | v6 stacked + form overlay + nav |
| \`v6/\` | Generators, verify SQL, docs |

Deploy: \`scripts/oracle/oracle-dev.sh deploy-teatru-v6\`

Generated: $(date -u +%Y-%m-%dT%H:%MZ)
EOF

  rm -f "${ZIP}"
  (cd "$(dirname "${WORK}")" && zip -rq "${ZIP}" "$(basename "${WORK}")")
  rm -rf "${WORK}"
  ln -sfn "$(basename "${ZIP}")" "${REPO_ROOT}/teatru-app100-v6-latest.zip"

  echo "DONE: ${ZIP}"
  echo "LINK: ${REPO_ROOT}/teatru-app100-v6-latest.zip"
  ls -lh "${ZIP}"
}

main "$@"
