#!/usr/bin/env bash
# REST Enabled SQL via ORDS — ADMIN schema (DBA queries, apex_util, ORDS_ADMIN).
# Endpoint: .../ords/admin/_/sql
set -euo pipefail

SECRETS_DIR="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}"
CREDS="${SECRETS_DIR}/credentials.env"

if [[ ! -f "${CREDS}" ]]; then
  echo "BLOCKED: missing ${CREDS}" >&2
  exit 1
fi
# shellcheck disable=SC1090
source "${CREDS}"

: "${ADB_ORDS_BASE:?}"
: "${ADB_ADMIN_USER:=ADMIN}"
: "${ADB_ADMIN_PASSWORD:?set ADB_ADMIN_PASSWORD in ${CREDS}}"

URL="${ADB_ORDS_BASE}/${ADB_ORDS_ADMIN_SCHEMA:-admin}/_/sql"

if [[ $# -eq 0 ]]; then
  exec curl -sS -u "${ADB_ADMIN_USER}:${ADB_ADMIN_PASSWORD}" "${URL}"
fi

if [[ "$1" == "-f" ]]; then
  shift
  SQL_FILE="${1:?Usage: $0 -f file.sql}"
  [[ -f "${SQL_FILE}" ]] || { echo "Not found: ${SQL_FILE}" >&2; exit 1; }
  SQL="$(cat "${SQL_FILE}")"
else
  SQL="$*"
fi

curl -sS -u "${ADB_ADMIN_USER}:${ADB_ADMIN_PASSWORD}" \
  -H 'Content-Type: application/sql' \
  -X POST "${URL}" \
  -d "${SQL}"
