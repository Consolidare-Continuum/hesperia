#!/usr/bin/env bash
# Build teatru App 100 v7 university closure zip — full deploy + LLM chat context.
# Output: <repo-root>/teatru-app100-v7-university-YYYYMMDD.zip
# Symlink: teatru-app100-v7-university-latest.zip
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ORDS_SQL="${REPO_ROOT}/scripts/oracle/ords-sql.sh"
FLOW100="${REPO_ROOT}/user_documents/oracle_apex/apex/apps/flow_100"
APEX_SQL="${REPO_ROOT}/user_documents/oracle_apex/sql"
OPS="${REPO_ROOT}/operational/assignments"
STAMP="$(date +%Y%m%d)"
WORK="${REPO_ROOT}/.export/teatru-app100-v7-university-${STAMP}"
ZIP="${REPO_ROOT}/teatru-app100-v7-university-${STAMP}.zip"

need_sudo() {
  local secrets="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
  if [[ "${EUID}" -ne 0 ]] && [[ ! -r "${secrets}" ]]; then
    exec sudo -E "$0" "$@"
  fi
}

run_query_scalar() {
  local sql="$1"
  local py="$2"
  sudo "${ORDS_SQL}" "${sql}" | python3 -c "${py}"
}

export_live_ddl() {
  local out="$1"
  local tables=(SPECTACOLE PROGRAM_SPECTACOLE LOCURI BILETE CLIENTI REZERVARI ACHITARI OPERATII)
  local views=(V_PROGRAM_SPECTACOLE V_REZERVARI_ACHITARI)

  cat >"${out}" <<EOF
-- App 100 Teatru — live PRICHINDEL schema DDL export (university closure)
-- Generated: $(date -u +%Y-%m-%dT%H:%MZ) via export-teatru-v7-university-bundle.sh

SET DEFINE OFF

EOF

  for t in "${tables[@]}"; do
    echo "-- TABLE ${t}" >>"${out}"
    run_query_scalar \
      "SELECT DBMS_METADATA.GET_DDL('TABLE', '${t}') AS ddl FROM dual" \
      "import sys,json; d=json.load(sys.stdin); i=d['items'][0];
assert 'errorMessage' not in i, i.get('errorMessage','error');
print(i['resultSet']['items'][0]['ddl'])" >>"${out}" 2>/dev/null || {
        echo "-- WARN: could not export TABLE ${t}" >>"${out}"
      }
    echo >>"${out}"
  done

  for v in "${views[@]}"; do
    echo "-- VIEW ${v}" >>"${out}"
    run_query_scalar \
      "SELECT DBMS_METADATA.GET_DDL('VIEW', '${v}') AS ddl FROM dual" \
      "import sys,json; d=json.load(sys.stdin); i=d['items'][0];
assert 'errorMessage' not in i, i.get('errorMessage','error');
print(i['resultSet']['items'][0]['ddl'])" >>"${out}" 2>/dev/null || {
        echo "-- WARN: view ${v} not present in live schema" >>"${out}"
      }
    echo >>"${out}"
  done
}

concat_sql() {
  local out="$1"
  shift
  cat >"${out}" <<EOF
-- App 100 prichindel-ulim — v7 university full UI deploy (concatenated)
-- Generated: $(date -u +%Y-%m-%dT%H:%MZ)
-- Matches: deploy-teatru-v7 (canonical). Hotfix SQLs included separately in v7/ for surgical reruns.

SET DEFINE OFF

EOF
  for f in "$@"; do
    echo "-- ===== FILE: $(basename "${f}") =====" >>"${out}"
    cat "${f}" >>"${out}"
    echo >>"${out}"
  done
}

main() {
  need_sudo "$@"
  echo "Regenerating v7 SQL from build_v7_ethan.py..."
  python3 "${FLOW100}/build_v7_ethan.py"

  rm -rf "${WORK}"
  mkdir -p "${WORK}/database" "${WORK}/app/pieces" "${WORK}/v7" "${WORK}/governance" "${WORK}/scripts"

  echo "Exporting live database DDL..."
  export_live_ddl "${WORK}/database/teatru_schema_live_ddl.sql"
  cp "${APEX_SQL}/teatru_odata_ca_niciodata_schema.sql" "${WORK}/database/teatru_schema_repo_bootstrap.sql"
  cp "${APEX_SQL}/teatru_operatii_schema.sql" "${WORK}/database/"
  cp "${APEX_SQL}/teatru_operatii_backfill.sql" "${WORK}/database/"
  cp "${APEX_SQL}/teatru_format_datetimes.sql" "${WORK}/database/" 2>/dev/null || true

  echo "Copying v7 app SQL..."
  local v7_files=(
    remove_teatru_pages_v7.sql
    add_teatru_pages_v7.sql
    fix_teatru_page_no_auto_nav.sql
    purge_teatru_nav.sql
    add_teatru_nav_v7.sql
    verify_v7.sql
    clear_app100_cache.sql
    fix_teatru_sales_flow_nav.sql
    fix_teatru_page21_ledger.sql
    fix_teatru_page46_operatie_id.sql
    fix_teatru_page20_rez_sort.sql
    fix_teatru_page45_rez_sort.sql
  )
  for f in "${v7_files[@]}"; do
    cp "${FLOW100}/${f}" "${WORK}/v7/${f}"
    cp "${FLOW100}/${f}" "${WORK}/app/pieces/${f}"
  done

  concat_sql "${WORK}/app/flow_100_v7_university_deploy.sql" \
    "${WORK}/v7/remove_teatru_pages_v7.sql" \
    "${WORK}/v7/add_teatru_pages_v7.sql" \
    "${WORK}/v7/fix_teatru_page_no_auto_nav.sql" \
    "${WORK}/v7/purge_teatru_nav.sql" \
    "${WORK}/v7/add_teatru_nav_v7.sql" \
    "${WORK}/v7/verify_v7.sql" \
    "${WORK}/v7/clear_app100_cache.sql"

  echo "Copying generators and docs..."
  cp "${FLOW100}/build_v7_ethan.py" "${WORK}/v7/"
  cp "${FLOW100}/build_v5_stacked_md.py" "${WORK}/v7/"
  cp "${FLOW100}/README.md" "${WORK}/v7/" 2>/dev/null || true
  cp "${FLOW100}/TEATRU-V7-PRESENTATION-PINNACLE.md" "${WORK}/v7/"
  cp "${FLOW100}/APEX-TASK-01-RESET.md" "${WORK}/v7/" 2>/dev/null || true
  cp "${OPS}/TEATRU-APP100-UNIVERSITY-SCOPE-CLOSURE-ETHAN.md" "${WORK}/governance/"
  cp "${OPS}/TEATRU-APP100-PAGE-TEMPLATE-DECISION-ETHAN.md" "${WORK}/governance/"

  cat >"${WORK}/scripts/oracle-dev-commands.txt" <<'EOF'
# From prichindel.com repo root (or adapt paths to bundled SQL)

# --- Schema (greenfield / review DDL first) ---
scripts/oracle/oracle-dev.sh run database/teatru_schema_repo_bootstrap.sql
scripts/oracle/oracle-dev.sh run database/teatru_operatii_schema.sql
scripts/oracle/oracle-dev.sh run database/teatru_operatii_backfill.sql

# --- App 100 UI: university closure (canonical) ---
scripts/oracle/oracle-dev.sh deploy-teatru-v7

# --- Surgical hotfixes (only if live drift; bundled add_teatru_pages_v7.sql is source of truth) ---
scripts/oracle/oracle-dev.sh fix-teatru-sales-nav
scripts/oracle/oracle-dev.sh fix-teatru-ledger-sort
scripts/oracle/oracle-dev.sh fix-teatru-page46-id
scripts/oracle/oracle-dev.sh fix-teatru-page20-sort
scripts/oracle/oracle-dev.sh fix-teatru-page45-sort

# --- One-shot from this zip (no oracle-dev.sh) ---
# scripts/oracle/oracle-dev.sh run app/flow_100_v7_university_deploy.sql
EOF

  cat >"${WORK}/DEPLOY.md" <<EOF
# Deploy — App 100 prichindel-ulim (university closure)

**App:** Oracle APEX 100 · workspace PRICHINDELWS · schema PRICHINDEL  
**Runtime URL:** \`/ords/r/prichindel/prichindel-ulim/...\` (friendly URLs only)

## Prerequisites

- Oracle ADB **prichindelbd** with ORDS REST SQL enabled for user PRICHINDEL
- App 100 exists with catalog pages **2–14** (run \`deploy-teatru-v6-reset\` once if greenfield)
- Secrets: \`/root/.secrets/oracle/prichindelbd/credentials.env\` on deploy host

## Path A — existing App 100 (recommended)

\`\`\`bash
cd /path/to/prichindel.com
sudo scripts/oracle/oracle-dev.sh deploy-teatru-v7
\`\`\`

Regenerates SQL from \`v7/build_v7_ethan.py\`, replaces pages 20–46, refreshes nav, runs \`verify_v7.sql\`.

## Path B — greenfield schema + UI

1. \`database/teatru_schema_repo_bootstrap.sql\`
2. \`database/teatru_operatii_schema.sql\` + \`teatru_operatii_backfill.sql\`
3. Repo: \`deploy-teatru-v6-reset\` (catalog + operatii-aware baseline)
4. \`deploy-teatru-v7\` or \`app/flow_100_v7_university_deploy.sql\`

## Path C — zip-only (REST SQL / SQLcl)

Import in order: pieces under \`app/pieces/\` same as \`app/flow_100_v7_university_deploy.sql\`.

## Demo arc

See \`v7/TEATRU-V7-PRESENTATION-PINNACLE.md\`.

Generated: $(date -u +%Y-%m-%dT%H:%MZ)
EOF

  cat >"${WORK}/LLM_CONTEXT.md" <<EOF
# LLM context — Teatru App 100 (university scope)

Use this file when chatting casually about deploy, structure, or fixes. **Do not guess paths** — they are listed here.

## What this project is

- **Oracle APEX app 100** alias **prichindel-ulim** — theatre ticket sales lab (ULIM)
- **Schema:** PRICHINDEL — tables: spectacole, program_spectacole, locuri, bilete, clienti, rezervari, achitari, **operatii**
- **Canonical UI generator:** \`v7/build_v7_ethan.py\` → \`v7/add_teatru_pages_v7.sql\`

## Zip layout (you are here)

| Folder | Purpose |
|--------|---------|
| \`LLM_CONTEXT.md\` | This file — structure for chat |
| \`MANIFEST.md\` | Human index |
| \`DEPLOY.md\` | Step-by-step deploy |
| \`database/\` | Schema DDL (live export + repo bootstrap + operatii) |
| \`app/\` | Concatenated APEX deploy + \`pieces/\` per file |
| \`v7/\` | Generators, generated SQL, verify, presentation doc |
| \`governance/\` | Ethan decisions + university closure record |
| \`scripts/oracle-dev-commands.txt\` | Copy-paste deploy commands |

## Key pages (live v7 university)

| Page | Alias | Role |
|------|-------|------|
| 20 | SALES-WORKSPACE | Sales hub — master-detail, Ajax actions |
| 45 | REZERVARE-NOUA | Editable IG — new ACTIVA reservations |
| 46 | VANZARE-DIRECTA | Walk-in sale — operatie_id visible |
| 21 | OPERATIONS-LEDGER | Audit ledger — operatie_id DESC |
| 22 | SPECTACOLE-PROGRAM | Catalog master-detail |
| 23 | DOSAR-PROIECT | Project dossier |
| 24 | INTEROGARI | SQL homework hub |
| 25–44 | INTEROGARE-NN | One page per homework query |
| 2–14 | (catalog) | Admin CRUD — unchanged by v7 |

## Deploy truth

- **One command (repo):** \`sudo scripts/oracle/oracle-dev.sh deploy-teatru-v7\`
- **Source of truth for pages 20–46:** regenerate \`build_v7_ethan.py\`, then import \`add_teatru_pages_v7.sql\`
- **Hotfix SQLs** in \`v7/fix_*.sql\` — surgical page replace; prefer full regen when unsure
- **Never** \`create_page\` on existing page without \`remove_page\` first (silent failure)
- **Modals abandoned** — ADB blocks iframe; use full-page links (pages 20/45/46)

## Demo order (presentation)

1. Page 46 Vânzare directă → 2. Page 20 hub → 3. Page 21 ledger → 4. Page 23 docs

## Status

University scope **DONE** $(date +%Y-%m-%d). Closure: \`governance/TEATRU-APP100-UNIVERSITY-SCOPE-CLOSURE-ETHAN.md\`.

## Regenerate SQL locally

\`\`\`bash
python3 v7/build_v7_ethan.py
\`\`\`

Produces \`add_teatru_pages_v7.sql\` and all \`fix_teatru_*.sql\` hotfixes.
EOF

  cat >"${WORK}/MANIFEST.md" <<EOF
# Teatru App 100 v7 university bundle (${STAMP})

**Status:** university scope closed · deploy-ready  
**Symlink name:** \`teatru-app100-v7-university-latest.zip\`

| Path | Contents |
|------|----------|
| \`LLM_CONTEXT.md\` | **Start here for LLM chat** — structure, pages, deploy truth |
| \`DEPLOY.md\` | Human deploy steps |
| \`database/teatru_schema_live_ddl.sql\` | Live PRICHINDEL DDL snapshot |
| \`database/teatru_schema_repo_bootstrap.sql\` | Repo idempotent schema + seed |
| \`database/teatru_operatii_*.sql\` | Operations ledger table |
| \`app/flow_100_v7_university_deploy.sql\` | Concatenated v7 UI deploy |
| \`app/pieces/\` | Same SQL split per file |
| \`v7/\` | \`build_v7_ethan.py\`, generated SQL, verify, presentation |
| \`governance/\` | Ethan closure + page template decision |

**Canonical deploy:** \`scripts/oracle/oracle-dev.sh deploy-teatru-v7\`

Generated: $(date -u +%Y-%m-%dT%H:%MZ)
EOF

  rm -f "${ZIP}"
  (cd "$(dirname "${WORK}")" && zip -rq "${ZIP}" "$(basename "${WORK}")")
  rm -rf "${WORK}"
  ln -sfn "$(basename "${ZIP}")" "${REPO_ROOT}/teatru-app100-v7-university-latest.zip"

  echo "DONE: ${ZIP}"
  echo "LINK: ${REPO_ROOT}/teatru-app100-v7-university-latest.zip"
  ls -lh "${ZIP}"
}

main "$@"
