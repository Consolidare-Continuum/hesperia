#!/usr/bin/env bash
# Team dev entry — UAIC Oracle APEX / prichindelbd (no wallet).
# Ref: user_documents/oracle_apex/DEV-WORKFLOW.md
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ORDS_SQL="${REPO_ROOT}/scripts/oracle/ords-sql.sh"
ORDS_CURL="${REPO_ROOT}/scripts/oracle/ords-curl.sh"
RUN_SQL="${REPO_ROOT}/scripts/oracle/run-sql.sh"
APEX_DIR="${REPO_ROOT}/user_documents/oracle_apex"
FLOW103="${APEX_DIR}/apex/apps/flow_103"
FLOW100="${APEX_DIR}/apex/apps/flow_100"

usage() {
  cat <<EOF
Usage: $(basename "$0") <command> [args]

Commands:
  ping              ORDS metadata (19c + ORDS version JSON)
  smoke             Quick schema + REST facultate checks
  sql "QUERY"       Ad-hoc SQL via REST Enabled SQL (PRICHINDEL)
  run FILE.sql      Deploy SQL file from repo
  rest PATH         GET .../ords/prichindel/PATH (ALTITUDINE)
  deploy-pages      Redeploy app 103 pages 20-22
  deploy-nav        Add nav menu entries for pages 20-22
  deploy-labs       Deploy laboratoare 1-9 pages (30-38) + nav
  setup-bilet1-schema  Create Tari/Furnizori/Producatori/Produse/Furnizare/Clienti + seed data
  deploy-bilet1     Add page 39 (Bilet 1 queries II.2 + II.3 live, II.1 + 1NF theory)
  deploy-academic   Final academic polish: Home, menu order, lab narratives
  fix-lab-html      Set Static Content output_as=HTML on lab narrative regions
  fix-catalog-page  Fix page 21 v_catalog_note ORDER BY (student, titlu_curs)
  fix-despre-page   Page 22 student referat style (ULIM FIID, no AI/ORDS)
  fix-footer        Page 0 global footer: student/group/prof/year
  fix-nav-order     Resequence nav: Labs 11-19, Despre lab 20, Dashboard 21, Catalog 22
  add-app-user      Create/reset COLEG APEX user (ADMIN)
  reset-igareosh-password  Reset IGAREOSH APEX web + DB password (ADMIN)
  grant-igareosh-workspace  Add IGAREOSH as PRICHINDELWS workspace developer
  redeploy-labs     Remove pages 30-38 then deploy-labs (fixes Static HTML)
  deploy-ords       Deploy full ORDS export (HR + facultate)
  deploy-ords-facultate  Deploy uaic.facultate module only
  deploy-teatru-schema  Teatru DDL + seed + views only (no page replace)
  deploy-teatru-v5      App 100 UI — editable IGs + business overlay (legacy — do not UAT)
  deploy-teatru-v5-form App 100 UI — form-first (superseded by deploy-teatru-v6)
  deploy-teatru-v6      App 100 UI — **Ethan v6 canonical** (Type B form + read-only IG)
  deploy-teatru-v6-reset App 100 — **APEX-TASK-01-RESET** 3 template pages + Catalog archive
  deploy-teatru-v7      App 100 — **v7 Ethan** v6-reset + modal Rezervare nouă (page 41)
  fix-teatru-page20-modal  Page 20 only — legacy alias for fix-teatru-sales-nav
  fix-teatru-sales-nav     Pages 20/45/46 — full-page flow (no modal iframe)
  fix-teatru-ledger-sort   Page 21 — Registrul operațiilor: operatie_id DESC (latest first)
  fix-teatru-page46-id     Page 46 — Vânzare directă ID = operatie_id (matches ledger)
  fix-teatru-page20-sort   Page 20 pane 1 — Rezervări by rezervare_id DESC
  fix-teatru-page45-sort   Page 45 — Rezervare nouă by rezervare_id DESC
  deploy-teatru-nav-v4  App 100 nav only (normally included in deploy-teatru-v6)
  populate-teatru-may  Random demo data May 2026 (5 shows, 10x10 seats, sales/returns)
  seed-teatru-rez-active  25 rezervări ACTIVA neachitate (pagina Achitare)
  format-teatru-dates  Recreate views with DD/MM/YYYY HH24:MI display for timestamps
  export-teatru-v5-bundle  Zip: live DB DDL + v5 sources (archive)
  export-teatru-v6-bundle  Zip: live DB DDL + v6 Ethan bundle → repo root
  export-teatru-v7-university  Zip: v7 university closure — full deploy + LLM_CONTEXT.md
  lab N             Run sql/labNN_*.sql (N=02..09)

  DO NOT USE on live App 100 (archive — mixing caused ~40min debug):
  deploy-teatru, deploy-teatru-ui, deploy-teatru-v4, fix-teatru-*, deploy-teatru-pages/forms/nav

Secrets: /root/.secrets/oracle/prichindelbd/credentials.env (sudo on altitudine).
EOF
}

need_sudo() {
  local secrets="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
  if [[ "${EUID}" -ne 0 ]] && [[ ! -r "${secrets}" ]]; then
    exec sudo -E "$0" "${cmd}" "$@"
  fi
}

cmd="${1:-help}"
shift || true

case "${cmd}" in
  ping)
    need_sudo "$@"
    "${ORDS_SQL}" | python3 -m json.tool 2>/dev/null || "${ORDS_SQL}"
    ;;
  smoke)
    need_sudo "$@"
    echo "== SQL =="
    "${ORDS_SQL}" "SELECT COUNT(*) AS studenti FROM studenti" | python3 -c "
import sys,json
d=json.load(sys.stdin)
items=d['items'][0]['resultSet']['items'][0]
print('studenti:', items.get('studenti', items))
" 2>/dev/null || "${ORDS_SQL}" "SELECT COUNT(*) AS n FROM studenti"
    echo "== REST facultate/studenti/ =="
    "${ORDS_CURL}" 'facultate/studenti/' | head -c 300
    echo
    ;;
  sql)
    need_sudo "$@"
    [[ $# -ge 1 ]] || { echo "Usage: $0 sql \"SELECT ...\"" >&2; exit 1; }
    "${ORDS_SQL}" "$*"
    ;;
  run)
    need_sudo "$@"
    [[ $# -ge 1 ]] || { echo "Usage: $0 run path/to/file.sql" >&2; exit 1; }
    SQL_FILE="$1"
    [[ "${SQL_FILE}" != /* ]] && SQL_FILE="${REPO_ROOT}/${SQL_FILE}"
    "${RUN_SQL}" "${SQL_FILE}"
    ;;
  rest)
    need_sudo "$@"
    [[ $# -ge 1 ]] || { echo "Usage: $0 rest facultate/studenti/" >&2; exit 1; }
    "${ORDS_CURL}" "$1"
    ;;
  deploy-pages)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/add_trivial_pages.sql"
    ;;
  deploy-nav)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/add_nav_items.sql"
    ;;
  deploy-labs)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/add_lab_pages.sql"
    "${RUN_SQL}" "${FLOW103}/add_lab_nav.sql"
    ;;
  setup-bilet1-schema)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/bilet01_schema.sql"
    ;;
  deploy-bilet1)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/add_bilet01_page.sql"
    ;;
  deploy-academic)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/apply_academic_polish.sql"
    ;;
  fix-lab-html)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/fix_lab_static_html.sql"
    ;;
  fix-catalog-page)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/fix_catalog_page.sql"
    ;;
  fix-despre-page)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/fix_despre_page.sql"
    ;;
  fix-footer)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/fix_footer_global.sql"
    ;;
  fix-nav-order)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/fix_nav_order.sql"
    ;;
  add-app-user)
    need_sudo "$@"
    # APEX user management requires ADB ADMIN — run via admin SQL endpoint
    SECRETS="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
    source "${SECRETS}"
    ADMIN_URL="${ADB_ORDS_BASE}/admin/_/sql"
    SQL="$(cat "${FLOW103}/add_app_user.sql")"
    curl -sS -u "${ADB_ADMIN_USER}:${ADB_ADMIN_PASSWORD}" \
      -H 'Content-Type: application/sql' -X POST "${ADMIN_URL}" \
      --data-binary "${SQL}" | python3 -c "
import sys,json
d=json.load(sys.stdin)
for item in d.get('items',[]):
    err=item.get('errorDetails')
    resp=''.join(item.get('response',[]))
    if err: print('ERR:',err[:300])
    elif resp.strip(): print(resp.strip())
"
    ;;
  reset-igareosh-password)
    need_sudo "$@"
    SECRETS="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
    source "${SECRETS}"
    NEW_PASS="${1:-Ul1mBd2026!}"
    ADMIN_URL="${ADB_ORDS_BASE}/admin/_/sql"
    SQL="$(python3 -c "
import pathlib, sys
p = pathlib.Path('${FLOW103}/reset_apex_user_igareosh.sql').read_text()
print(p.replace('__NEW_PASSWORD__', sys.argv[1]))
" "${NEW_PASS}")"
    curl -sS -u "${ADB_ADMIN_USER}:${ADB_ADMIN_PASSWORD}" \
      -H 'Content-Type: application/sql' -X POST "${ADMIN_URL}" \
      --data-binary "${SQL}" | python3 -c "
import sys,json
d=json.load(sys.stdin)
ok=True
for item in d.get('items',[]):
    err=item.get('errorDetails')
    resp=''.join(item.get('response',[]))
    if err:
        ok=False
        print('ERR:',err[:500])
    elif resp.strip():
        print(resp.strip())
if not ok: sys.exit(1)
"
    if grep -q '^ADB_OPERATOR_PASSWORD=' "${SECRETS}"; then
      sed -i "s|^ADB_OPERATOR_PASSWORD=.*|ADB_OPERATOR_PASSWORD=${NEW_PASS}|" "${SECRETS}"
    else
      echo "ADB_OPERATOR_PASSWORD=${NEW_PASS}" >> "${SECRETS}"
    fi
    echo "Updated ${SECRETS} ADB_OPERATOR_PASSWORD"
    ;;
  grant-igareosh-workspace)
    need_sudo "$@"
    SECRETS="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
    source "${SECRETS}"
    NEW_PASS="${ADB_OPERATOR_PASSWORD:?set ADB_OPERATOR_PASSWORD in secrets}"
    ADMIN_URL="${ADB_ORDS_BASE}/admin/_/sql"
    SQL="$(python3 -c "
import pathlib, sys
p = pathlib.Path('${FLOW103}/grant_workspace_developer_igareosh.sql').read_text()
print(p.replace('__NEW_PASSWORD__', sys.argv[1]))
" "${NEW_PASS}")"
    curl -sS -u "${ADB_ADMIN_USER}:${ADB_ADMIN_PASSWORD}" \
      -H 'Content-Type: application/sql' -X POST "${ADMIN_URL}" \
      --data-binary "${SQL}" | python3 -c "
import sys,json
d=json.load(sys.stdin)
ok=True
for item in d.get('items',[]):
    err=item.get('errorDetails')
    resp=''.join(item.get('response',[]))
    if err:
        ok=False
        print('ERR:',err[:800])
    elif resp.strip():
        print(resp.strip())
if not ok: sys.exit(1)
"
    ;;
  redeploy-labs)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW103}/remove_lab_pages.sql"
    "${RUN_SQL}" "${FLOW103}/add_lab_pages.sql"
    "${RUN_SQL}" "${FLOW103}/add_lab_nav.sql"
    ;;
  deploy-ords)
    need_sudo "$@"
    "${RUN_SQL}" "${APEX_DIR}/ORDS_REST_PRICHINDEL_EXPORT_2026_05_28.sql"
    ;;
  deploy-ords-facultate)
    need_sudo "$@"
    "${RUN_SQL}" "${APEX_DIR}/ORDS_REST_FACULTATE_2026_05_26.sql"
    ;;
  deploy-teatru-schema)
    need_sudo "$@"
    "${RUN_SQL}" "${APEX_DIR}/sql/teatru_odata_ca_niciodata_schema.sql"
    ;;
  deploy-teatru-pages)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages.sql"
    ;;
  deploy-teatru-forms)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW100}/add_teatru_forms.sql"
    ;;
  deploy-teatru-nav)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v2.sql"
    ;;
  deploy-teatru-ui)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW100}/fix_dashboard_cleanup.sql"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages.sql"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v3_2.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_forms_v3_2.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_split_ui_v3_3.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_save_upsert_v3_4.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v3.sql"
    ;;
  fix-teatru-split-ui)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_split_ui_v3_3.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_save_upsert_v3_4.sql"
    ;;
  fix-teatru-save)
    need_sudo "$@"
    # wwv_flow_imp create_page_process is no-op when id exists — remove pages 2-5 first
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_2_5.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v3_2.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_forms_v3_2.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_split_ui_v3_3.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_save_upsert_v3_4.sql"
    ;;
  deploy-teatru-v4)
    need_sudo "$@"
    python3 "${FLOW100}/build_v4_masters.py"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_masters_v4.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v4_masters.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_forms_v3_2.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page_no_auto_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_page_hub_v4.sql"
    "${RUN_SQL}" "${FLOW100}/purge_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v4.sql"
    ;;
  deploy-teatru-nav-v4)
    need_sudo "$@"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page_no_auto_nav.sql"
    "${RUN_SQL}" "${FLOW100}/purge_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v4.sql"
    ;;
  deploy-teatru-v5)
    need_sudo "$@"
    python3 "${FLOW100}/build_v5_stacked_md.py"
    python3 "${FLOW100}/build_v5_business_overlay.py"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_v5.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v5_stacked_md.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_v5_business_overlay.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page_no_auto_nav.sql"
    "${RUN_SQL}" "${FLOW100}/purge_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v4.sql"
    "${ORDS_SQL}" "SELECT COUNT(*) cnt FROM apex_application_pages WHERE application_id=100 AND page_id IN (2,3,4,5,7,8,9,10,12)" | python3 -c "
import sys,json
d=json.load(sys.stdin)
cnt=d['items'][0]['resultSet']['items'][0]['cnt']
if int(cnt)!=9:
    print(f'FAILED: deploy-teatru-v5 expected 9 teatru pages, got {cnt}', file=sys.stderr)
    sys.exit(1)
print(f'OK: {cnt} teatru pages present (2-5,7-10,12)')
"
    "${RUN_SQL}" "${FLOW100}/verify_page5_ig_native.sql"
    ;;
  deploy-teatru-v5-form)
    need_sudo "$@"
    python3 "${FLOW100}/build_v5_stacked_md.py" --form-first
    python3 "${FLOW100}/build_v5_form_baseline_overlay.py"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_v5.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v5_stacked_md.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_v5_form_baseline_overlay.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page_no_auto_nav.sql"
    "${RUN_SQL}" "${FLOW100}/purge_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v4.sql"
    "${ORDS_SQL}" "SELECT COUNT(*) cnt FROM apex_application_pages WHERE application_id=100 AND page_id IN (2,3,4,5,7,8,9,10,12)" | python3 -c "
import sys,json
d=json.load(sys.stdin)
cnt=d['items'][0]['resultSet']['items'][0]['cnt']
if int(cnt)!=9:
    print(f'FAILED: deploy-teatru-v5-form expected 9 teatru pages, got {cnt}', file=sys.stderr)
    sys.exit(1)
print(f'OK: {cnt} teatru pages present (2-5,7-10,12)')
"
    "${RUN_SQL}" "${FLOW100}/verify_page5_form_template.sql"
    ;;
  deploy-teatru-v6)
    need_sudo "$@"
    python3 "${FLOW100}/build_v6_ethan.py"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_v5.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v6_stacked_md.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_v6_form_overlay.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page_no_auto_nav.sql"
    "${RUN_SQL}" "${FLOW100}/purge_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v4.sql"
    "${RUN_SQL}" "${FLOW100}/verify_v6_ethan.sql"
    ;;
  deploy-teatru-v6-reset)
    need_sudo "$@"
    python3 "${FLOW100}/build_v6_ethan.py"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_v5.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v6_stacked_md.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_v6_form_overlay.sql"
    "${RUN_SQL}" "${APEX_DIR}/sql/teatru_operatii_schema.sql"
    "${RUN_SQL}" "${APEX_DIR}/sql/teatru_operatii_backfill.sql"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_v6_reset.sql"
    python3 "${FLOW100}/build_v6_reset_ethan.py"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v6_reset.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page_no_auto_nav.sql"
    "${RUN_SQL}" "${FLOW100}/purge_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v6_reset.sql"
    "${RUN_SQL}" "${FLOW100}/verify_v6_ethan.sql"
    "${RUN_SQL}" "${FLOW100}/verify_v6_reset.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  deploy-teatru-v7)
    need_sudo "$@"
    python3 "${FLOW100}/build_v7_ethan.py"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages_v7.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v7.sql"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page_no_auto_nav.sql"
    "${RUN_SQL}" "${FLOW100}/purge_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v7.sql"
    "${RUN_SQL}" "${FLOW100}/verify_v7.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  fix-teatru-page20-modal)
    need_sudo "$@"
    python3 "${FLOW100}/build_v7_ethan.py"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_sales_flow_nav.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  fix-teatru-sales-nav)
    need_sudo "$@"
    python3 "${FLOW100}/build_v7_ethan.py"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_sales_flow_nav.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  fix-teatru-ledger-sort)
    need_sudo "$@"
    python3 "${FLOW100}/build_v7_ethan.py"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page21_ledger.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  fix-teatru-page46-id)
    need_sudo "$@"
    python3 "${FLOW100}/build_v7_ethan.py"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page46_operatie_id.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  fix-teatru-page20-sort)
    need_sudo "$@"
    python3 "${FLOW100}/build_v7_ethan.py"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page20_rez_sort.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  fix-teatru-page45-sort)
    need_sudo "$@"
    python3 "${FLOW100}/build_v7_ethan.py"
    "${RUN_SQL}" "${FLOW100}/fix_teatru_page45_rez_sort.sql"
    "${RUN_SQL}" "${FLOW100}/clear_app100_cache.sql"
    ;;
  deploy-teatru)
    need_sudo "$@"
    "${RUN_SQL}" "${APEX_DIR}/sql/teatru_odata_ca_niciodata_schema.sql"
    "${RUN_SQL}" "${FLOW100}/fix_dashboard_cleanup.sql"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_pages.sql"
    "${RUN_SQL}" "${FLOW100}/remove_teatru_nav.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_pages_v3_2.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_forms_v3_2.sql"
    "${RUN_SQL}" "${FLOW100}/add_teatru_nav_v3.sql"
    ;;
  populate-teatru-may)
    need_sudo "$@"
    "${RUN_SQL}" "${APEX_DIR}/sql/teatru_populate_may2026.sql"
    ;;
  seed-teatru-rez-active)
    need_sudo "$@"
    "${RUN_SQL}" "${APEX_DIR}/sql/teatru_seed_rezervari_active.sql"
    ;;
  format-teatru-dates)
    need_sudo "$@"
    "${RUN_SQL}" "${APEX_DIR}/sql/teatru_format_datetimes.sql"
    ;;
  export-teatru-v5-bundle)
    need_sudo "$@"
    bash "${REPO_ROOT}/scripts/oracle/export-teatru-v5-bundle.sh"
    ;;
  export-teatru-v6-bundle)
    need_sudo "$@"
    bash "${REPO_ROOT}/scripts/oracle/export-teatru-v6-bundle.sh"
    ;;
  export-teatru-v7-university)
    need_sudo "$@"
    bash "${REPO_ROOT}/scripts/oracle/export-teatru-v7-university-bundle.sh"
    ;;
  add-teatru-user)
    need_sudo "$@"
    SECRETS="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
    source "${SECRETS}"
    ADMIN_URL="${ADB_ORDS_BASE}/admin/_/sql"
    SQL="$(cat "${FLOW100}/grant_app100_user_igareosh.sql")"
    curl -sS -u "${ADB_ADMIN_USER}:${ADB_ADMIN_PASSWORD}" \
      -H 'Content-Type: application/sql' -X POST "${ADMIN_URL}" \
      --data-binary "${SQL}" | python3 -c "
import sys,json
d=json.load(sys.stdin)
ok=True
for item in d.get('items',[]):
    err=item.get('errorDetails')
    resp=''.join(item.get('response',[]))
    if err:
        ok=False
        print('ERR:',err[:800])
    elif resp.strip():
        print(resp.strip())
if not ok: sys.exit(1)
"
    ;;
  lab)
    need_sudo "$@"
    N="${1:?Usage: $0 lab NN  (e.g. lab 04)}"
    N="${N#0}"
    FILE="${APEX_DIR}/sql/lab${N}_"*
    MATCH=( ${FILE} )
    [[ -f "${MATCH[0]}" ]] || { echo "No lab file: ${FILE}" >&2; exit 1; }
    "${RUN_SQL}" "${MATCH[0]}"
    ;;
  help|-h|--help)
    usage
    ;;
  *)
    echo "Unknown command: ${cmd}" >&2
    usage >&2
    exit 1
    ;;
esac
