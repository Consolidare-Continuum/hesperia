#!/usr/bin/env bash
# Export APEX application by ID to user_documents/oracle_apex/apex/apps/
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
CONNECT="${REPO_ROOT}/scripts/oracle/sqlcl-connect.sh"
OUT_DIR="${REPO_ROOT}/user_documents/oracle_apex/apex/apps"
STAMP="$(date +%Y%m%d)"
APP_ID="${1:?Usage: $0 <application_id>}"

mkdir -p "${OUT_DIR}"
OUT_FILE="${OUT_DIR}/flow_${APP_ID}_export_${STAMP}.sql"

# APEX export via SQLcl (requires APEX_EXPORT or apex export depending on SQLcl version)
"${CONNECT}" <<EOF
apex export -applicationid ${APP_ID} -skipExportDate -expFile ${OUT_FILE}
EXIT
EOF

echo "Exported: ${OUT_FILE}"
