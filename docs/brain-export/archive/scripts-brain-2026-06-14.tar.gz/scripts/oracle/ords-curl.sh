#!/usr/bin/env bash
# ORDS GET with basic auth (no wallet). Usage: ords-curl.sh facultate/studenti/
set -euo pipefail

SECRETS_DIR="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}"
CREDS="${SECRETS_DIR}/credentials.env"
PATH_SUFFIX="${1:?Usage: $0 <path-after-/ords/prichindel/>}"

if [[ ! -f "${CREDS}" ]]; then
  echo "BLOCKED: missing ${CREDS}" >&2
  exit 1
fi
# shellcheck disable=SC1090
source "${CREDS}"

: "${ADB_ORDS_BASE:?}"
: "${ADB_ORDS_SCHEMA:?}"
: "${ADB_APP_USER:?}"
: "${ADB_APP_PASSWORD:?}"

URL="${ADB_ORDS_BASE}/${ADB_ORDS_SCHEMA}/${PATH_SUFFIX}"
curl -sS -u "${ADB_APP_USER}:${ADB_APP_PASSWORD}" "${URL}"
