#!/usr/bin/env bash
# REST Enabled SQL via ORDS — POST SQL or GET metadata.
# Endpoint: .../ords/prichindel/_/sql
# Auth: PRICHINDEL (not ALTITUDINE — REST data vs SQL differ).
set -euo pipefail

SECRETS_DIR="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}"
CREDS="${SECRETS_DIR}/credentials.env"

if [[ ! -f "${CREDS}" ]]; then
  echo "BLOCKED: missing ${CREDS}" >&2
  exit 1
fi
# shellcheck disable=SC1090
source "${CREDS}"

: "${ADB_ORDS_BASE:?}"
: "${ADB_ORDS_SCHEMA:?}"
: "${ADB_SQL_USER:=${ADB_SCHEMA_USER:-PRICHINDEL}}"
: "${ADB_SQL_PASSWORD:=${ADB_SCHEMA_PASSWORD:-${ADB_APP_PASSWORD:-}}}"

if [[ -z "${ADB_SQL_PASSWORD}" ]]; then
  echo "BLOCKED: set ADB_SQL_PASSWORD or ADB_SCHEMA_PASSWORD in ${CREDS}" >&2
  exit 1
fi

URL="${ADB_ORDS_BASE}/${ADB_ORDS_SCHEMA}/_/sql"

if [[ $# -eq 0 ]]; then
  # Metadata (database version, ORDS version)
  exec curl -sS -u "${ADB_SQL_USER}:${ADB_SQL_PASSWORD}" "${URL}"
fi

if [[ "$1" == "-f" ]]; then
  shift
  SQL_FILE="${1:?Usage: $0 -f file.sql}"
  [[ -f "${SQL_FILE}" ]] || { echo "Not found: ${SQL_FILE}" >&2; exit 1; }
  exec curl -sS -u "${ADB_SQL_USER}:${ADB_SQL_PASSWORD}" \
    -H 'Content-Type: application/sql' \
    -X POST "${URL}" \
    --data-binary "@${SQL_FILE}"
else
  SQL="$*"
fi

curl -sS -u "${ADB_SQL_USER}:${ADB_SQL_PASSWORD}" \
  -H 'Content-Type: application/sql' \
  -X POST "${URL}" \
  --data-binary "${SQL}"
