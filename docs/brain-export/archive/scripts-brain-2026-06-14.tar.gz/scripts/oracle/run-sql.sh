#!/usr/bin/env bash
# Run a SQL file against prichindelbd.
# Prefers REST Enabled SQL (no wallet); falls back to SQLcl when wallet present.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ORDS_SQL="${REPO_ROOT}/scripts/oracle/ords-sql.sh"
SQLCL_RUN="${REPO_ROOT}/scripts/oracle/sqlcl-connect.sh"

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <file.sql>" >&2
  exit 1
fi
SQL_FILE="$1"
if [[ ! -f "${SQL_FILE}" ]]; then
  echo "Not found: ${SQL_FILE}" >&2
  exit 1
fi

SECRETS_DIR="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}"
if [[ -r "${SECRETS_DIR}/credentials.env" ]] && grep -q 'ADB_SQL_PASSWORD\|ADB_SCHEMA_PASSWORD' "${SECRETS_DIR}/credentials.env" 2>/dev/null; then
  exec "${ORDS_SQL}" -f "${SQL_FILE}"
fi

WALLET_DIR="${SECRETS_DIR}/wallet"
if [[ -d "${WALLET_DIR}" ]] && [[ -x /opt/oracle/sqlcl/bin/sql ]] 2>/dev/null; then
  exec "${SQLCL_RUN}" @"${SQL_FILE}"
fi

echo "BLOCKED: need REST Enabled SQL creds or SQLcl wallet — see user_documents/oracle_apex/CURSOR-APEX-ACCESS.md" >&2
exit 1
