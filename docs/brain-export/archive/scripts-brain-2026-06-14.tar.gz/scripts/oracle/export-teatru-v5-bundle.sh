#!/usr/bin/env bash
# Build teatru App 100 v5 download zip: live DB DDL + app deploy bundle + v5 sources.
# Output: <repo-root>/teatru-app100-v5-YYYYMMDD.zip
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ORDS_SQL="${REPO_ROOT}/scripts/oracle/ords-sql.sh"
FLOW100="${REPO_ROOT}/user_documents/oracle_apex/apex/apps/flow_100"
APEX_SQL="${REPO_ROOT}/user_documents/oracle_apex/sql"
STAMP="$(date +%Y%m%d)"
WORK="${REPO_ROOT}/.export/teatru-app100-v5-${STAMP}"
ZIP="${REPO_ROOT}/teatru-app100-v5-${STAMP}.zip"

need_sudo() {
  local secrets="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}/credentials.env"
  if [[ "${EUID}" -ne 0 ]] && [[ ! -r "${secrets}" ]]; then
    exec sudo -E "$0" "$@"
  fi
}

run_query_scalar() {
  local sql="$1"
  local py="$2"
  sudo "${ORDS_SQL}" "${sql}" | python3 -c "${py}"
}

export_live_ddl() {
  local out="$1"
  local tables=(SPECTACOLE PROGRAM_SPECTACOLE LOCURI BILETE CLIENTI REZERVARI ACHITARI)
  local views=(V_PROGRAM_SPECTACOLE V_REZERVARI_ACHITARI)

  cat >"${out}" <<EOF
-- App 100 Teatru — live PRICHINDEL schema DDL export
-- Generated: $(date -u +%Y-%m-%dT%H:%MZ) via export-teatru-v5-bundle.sh (DBMS_METADATA)
-- Schema user: PRICHINDEL · ADB: prichindelbd

SET DEFINE OFF

EOF

  for t in "${tables[@]}"; do
    echo "-- TABLE ${t}" >>"${out}"
    run_query_scalar \
      "SELECT DBMS_METADATA.GET_DDL('TABLE', '${t}') AS ddl FROM dual" \
      "import sys,json; d=json.load(sys.stdin); i=d['items'][0];
assert 'errorMessage' not in i, i.get('errorMessage','error');
print(i['resultSet']['items'][0]['ddl'])" >>"${out}" || {
        echo "-- WARN: could not export TABLE ${t}" >>"${out}"
      }
    echo >>"${out}"
  done

  for v in "${views[@]}"; do
    echo "-- VIEW ${v}" >>"${out}"
    run_query_scalar \
      "SELECT DBMS_METADATA.GET_DDL('VIEW', '${v}') AS ddl FROM dual" \
      "import sys,json; d=json.load(sys.stdin); i=d['items'][0];
assert 'errorMessage' not in i, i.get('errorMessage','error');
print(i['resultSet']['items'][0]['ddl'])" >>"${out}" 2>/dev/null || {
        echo "-- WARN: view ${v} not present in live schema" >>"${out}"
      }
    echo >>"${out}"
  done
}

build_app_bundle() {
  local out="$1"
  cat >"${out}" <<EOF
-- App 100 prichindel-ulim — v5 form-first deploy bundle (concatenated)
-- Generated: $(date -u +%Y-%m-%dT%H:%MZ)
-- Matches: scripts/oracle/oracle-dev.sh deploy-teatru-v5
-- Import order: remove pages → stacked MD → form overlay → nav fix → nav v4
-- Live full APEX export (wwv_flow) requires SQLcl: scripts/oracle/apex-export.sh 100

SET DEFINE OFF

EOF
  for f in \
    "${FLOW100}/remove_teatru_pages_v5.sql" \
    "${FLOW100}/add_teatru_pages_v5_stacked_md.sql" \
    "${FLOW100}/add_teatru_v5_form_baseline_overlay.sql" \
    "${FLOW100}/fix_teatru_page_no_auto_nav.sql" \
    "${FLOW100}/purge_teatru_nav.sql" \
    "${FLOW100}/add_teatru_nav_v4.sql"
  do
    echo "-- ===== FILE: $(basename "${f}") =====" >>"${out}"
    cat "${f}" >>"${out}"
    echo >>"${out}"
  done
}

main() {
  need_sudo "$@"
  rm -rf "${WORK}"
  mkdir -p "${WORK}/database" "${WORK}/app" "${WORK}/v5"

  echo "Exporting live database DDL..."
  export_live_ddl "${WORK}/database/teatru_schema_live_ddl.sql"
  cp "${APEX_SQL}/teatru_odata_ca_niciodata_schema.sql" "${WORK}/database/teatru_schema_repo_bootstrap.sql"
  cp "${APEX_SQL}/teatru_format_datetimes.sql" "${WORK}/database/" 2>/dev/null || true

  echo "Building app deploy bundle..."
  build_app_bundle "${WORK}/app/flow_100_v5_deploy_bundle.sql"

  echo "Copying v5 sources..."
  cp "${FLOW100}/README.md" "${WORK}/v5/"
  cp "${FLOW100}/TEATRU-V5-IG-SESSION-FINDINGS.md" "${WORK}/v5/"
  for f in \
    build_v5_stacked_md.py \
    build_v5_form_baseline_overlay.py \
    add_teatru_pages_v5_stacked_md.sql \
    add_teatru_v5_form_baseline_overlay.sql \
    remove_teatru_pages_v5.sql \
    fix_teatru_page_no_auto_nav.sql \
    purge_teatru_nav.sql \
    add_teatru_nav_v4.sql
  do
    cp "${FLOW100}/${f}" "${WORK}/v5/${f}"
  done

  cat >"${WORK}/MANIFEST.md" <<EOF
# Teatru App 100 v5 bundle (${STAMP})

| Path | Contents |
|------|----------|
| \`database/teatru_schema_live_ddl.sql\` | Live PRICHINDEL DDL (DBMS_METADATA) — tables + views |
| \`database/teatru_schema_repo_bootstrap.sql\` | Repo bootstrap schema + seed (idempotent re-run caution) |
| \`app/flow_100_v5_deploy_bundle.sql\` | **App export (deploy bundle)** — v5 stacked read-only IGs + form overlay + nav v4 |
| \`v5/\` | Generators, generated SQL, README — **only** live UI path |

## Deploy (target ADB)

\`\`\`bash
# Schema (greenfield or review DDL first)
scripts/oracle/oracle-dev.sh run database/teatru_schema_repo_bootstrap.sql

# App 100 UI — use repo command (regenerates from v5/) OR import bundle:
scripts/oracle/oracle-dev.sh deploy-teatru-v5
# OR: scripts/oracle/oracle-dev.sh run app/flow_100_v5_deploy_bundle.sql
\`\`\`

**No v3/v4 UI deploy.** Only \`deploy-teatru-v5\`.

Full \`wwv_flow\` application export (single-file APEX export): \`scripts/oracle/apex-export.sh 100\` when SQLcl + wallet on host.

Generated: $(date -u +%Y-%m-%dT%H:%MZ)
EOF

  rm -f "${ZIP}"
  (cd "$(dirname "${WORK}")" && zip -rq "${ZIP}" "$(basename "${WORK}")")
  rm -rf "${WORK}"
  ln -sfn "$(basename "${ZIP}")" "${REPO_ROOT}/teatru-app100-v5-latest.zip"

  echo "DONE: ${ZIP}"
  echo "LINK: ${REPO_ROOT}/teatru-app100-v5-latest.zip"
  ls -lh "${ZIP}"
}

main "$@"
