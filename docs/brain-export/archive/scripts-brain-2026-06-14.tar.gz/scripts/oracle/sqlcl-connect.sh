#!/usr/bin/env bash
# SQLcl wrapper for prichindelbd ADB (wallet auth). Secrets never in repo.
set -euo pipefail

SECRETS_DIR="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}"
WALLET_DIR="${SECRETS_DIR}/wallet"
CREDS="${SECRETS_DIR}/credentials.env"
SQLCL="${SQLCL_BIN:-/opt/oracle/sqlcl/bin/sql}"

if [[ ! -f "${CREDS}" ]]; then
  echo "BLOCKED: missing ${CREDS} — see user_documents/oracle_apex/CURSOR-APEX-ACCESS.md" >&2
  exit 1
fi
# shellcheck disable=SC1090
source "${CREDS}"

: "${ADB_TNS:?ADB_TNS not set in credentials.env}"
: "${ADB_APP_USER:?ADB_APP_USER not set}"
: "${ADB_APP_PASSWORD:?ADB_APP_PASSWORD not set}"

export TNS_ADMIN="${WALLET_DIR}"
CONN="${ADB_APP_USER}/${ADB_APP_PASSWORD}@${ADB_TNS}"

if [[ ! -x "${SQLCL}" ]] && ! command -v sqlcl >/dev/null 2>&1; then
  echo "BLOCKED: SQLcl not installed — Abelard: /opt/oracle/sqlcl (see CURSOR-APEX-ACCESS.md)" >&2
  exit 1
fi
SQLCL="${SQLCL:-$(command -v sqlcl)}"

if [[ $# -eq 0 ]]; then
  exec "${SQLCL}" -S "${CONN}"
fi

if [[ "$1" == "-c" ]]; then
  shift
  printf '%s\n' "$@" | "${SQLCL}" -S "${CONN}"
else
  exec "${SQLCL}" -S "${CONN}" "$@"
fi
