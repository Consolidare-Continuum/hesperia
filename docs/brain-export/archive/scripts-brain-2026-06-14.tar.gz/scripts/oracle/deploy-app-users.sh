#!/usr/bin/env bash
# Seed / update front-end app users from host secrets (never commit passwords).
# Ref: user_documents/oracle_apex/DEV-WORKFLOW.md
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ORDS_SQL="${REPO_ROOT}/scripts/oracle/ords-sql.sh"
RUN_SQL="${REPO_ROOT}/scripts/oracle/run-sql.sh"
FLOW103="${REPO_ROOT}/user_documents/oracle_apex/apex/apps/flow_103"
SECRETS_DIR="${ADB_SECRETS_DIR:-/root/.secrets/oracle/prichindelbd}"
CREDS="${SECRETS_DIR}/credentials.env"

if [[ "${EUID}" -ne 0 ]] && [[ ! -r "${CREDS}" ]]; then
  exec sudo -E "$0" "$@"
fi

if [[ ! -f "${CREDS}" ]]; then
  echo "BLOCKED: missing ${CREDS}" >&2
  exit 1
fi
# shellcheck disable=SC1090
source "${CREDS}"

: "${APEX_FRONT_USER_PROFESOR:=PROFESOR}"
: "${APEX_FRONT_USER_PROFESOR_PASSWORD:?Set APEX_FRONT_USER_PROFESOR_PASSWORD in ${CREDS}}"

sql_escape() {
  printf "%s" "$1" | sed "s/'/''/g"
}

USER_ESC="$(sql_escape "${APEX_FRONT_USER_PROFESOR}")"
PASS_ESC="$(sql_escape "${APEX_FRONT_USER_PROFESOR_PASSWORD}")"

echo "== DDL + auth function =="
"${RUN_SQL}" "${FLOW103}/01_app_front_users.sql" >/dev/null

echo "== Custom auth scheme (app 103) =="
"${RUN_SQL}" "${FLOW103}/02_app_custom_auth_scheme.sql" >/dev/null

echo "== Merge user ${APEX_FRONT_USER_PROFESOR} =="
"${ORDS_SQL}" <<EOSQL
MERGE INTO app_front_users t
USING (
  SELECT '${USER_ESC}' AS username,
         '${PASS_ESC}' AS password_value,
         'Profesor UAIC' AS display_name,
         'PROFESOR' AS role_code
    FROM dual
) s
ON (UPPER(t.username) = UPPER(s.username))
WHEN MATCHED THEN
  UPDATE SET t.password_value = s.password_value,
             t.display_name   = s.display_name,
             t.role_code      = s.role_code,
             t.active_flag    = 'Y',
             t.updated_on     = SYSDATE
WHEN NOT MATCHED THEN
  INSERT (username, password_value, display_name, role_code, active_flag)
  VALUES (s.username, s.password_value, s.display_name, s.role_code, 'Y');
COMMIT;
EOSQL

echo "DONE. Front login: user=${APEX_FRONT_USER_PROFESOR} (password in ${CREDS})"
