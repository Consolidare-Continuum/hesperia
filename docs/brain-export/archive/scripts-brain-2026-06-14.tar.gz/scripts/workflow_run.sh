#!/usr/bin/env bash
# One command to fasten the flow: orchestrator → driver → executor. Run from IDE or repo root.
# Current task written to governance/workflow_driver_current.txt.
# Required owner context is written to governance/workflow_context_current.md; Cursor-in-IDE must execute as that named owner/context.
# Ref: cluster/workflow-automation/README.md

set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO_ROOT"
# Brain workflow host (prichindel) has no local chromadb; skip preflight unless overridden.
export CHROMA_SKIP_PREFLIGHT="${CHROMA_SKIP_PREFLIGHT:-1}"
bash "$REPO_ROOT/scripts/workflow_automation_manual_start.sh"
echo ""
echo "--- Current step (Cursor-in-IDE can execute as owner) ---"
cat "$REPO_ROOT/governance/workflow_driver_current.txt" 2>/dev/null || true
echo ""
echo "--- Required owner context passport (do not flatten into generic Cursor) ---"
cat "$REPO_ROOT/governance/workflow_context_current.md" 2>/dev/null || true
