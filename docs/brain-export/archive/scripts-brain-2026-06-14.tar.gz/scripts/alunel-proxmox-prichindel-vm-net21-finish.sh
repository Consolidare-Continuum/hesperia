#!/usr/bin/env bash
# Finish prichindel VM .21 cutover on alunel — run AFTER nic0 has link (cable on vmbr21).
# Removes bootstrap net2 (.121 on vmbr0). Permanent prox bridges must already exist.
set -euo pipefail

VMID=107
REPO="${REPO:-}"
if [[ -z "$REPO" ]]; then
  if [[ -d /data/workspaces/cursor ]]; then REPO=/data/workspaces/cursor
  elif [[ -d /data/altitudine/prichindel.com ]]; then REPO=/data/altitudine/prichindel.com
  else REPO="$(cd "$(dirname "$0")/.." && pwd)"; fi
fi

log() { echo "[net21-finish] $*"; }

need_root() { [[ $(id -u) -eq 0 ]] || exec sudo -n bash "$0" "$@"; }

check_nic1() {
  local c
  c=$(cat /sys/class/net/nic1/carrier 2>/dev/null || echo 0)
  if [[ "$c" != "1" ]]; then
    log "BLOCKED: nic1 NO-CARRIER — vmbr21 needs link on nic1 (see 50-prichindel-vm-bridges.cfg)"
    exit 1
  fi
  log "nic1 carrier=1 (vmbr21)"
}

verify_vm21() {
  ping -c1 -W2 192.168.100.21 >/dev/null || { log "BLOCKED: .21 not pingable"; exit 1; }
  log "ping 192.168.100.21 OK"
}

apply_guest_netplan() {
  log "Guest netplan: .21 default, eth2 optional down"
  qm guest exec "$VMID" -- bash -lc '
set -e
cat > /etc/netplan/99-prichindel-production.yaml <<YAML
network:
  version: 2
  ethernets:
    eth0:
      addresses: [192.168.100.21/24]
      routes:
        - to: default
          via: 192.168.100.1
      nameservers:
        addresses: [192.168.100.25, 192.168.100.19]
        search: [prichindel.local]
    eth1:
      addresses: [192.168.100.23/24]
YAML
chmod 600 /etc/netplan/99-prichindel-production.yaml
netplan apply
ip link set eth2 down 2>/dev/null || true
ip addr flush dev eth2 2>/dev/null || true
' 2>/dev/null || { log "BLOCKED: guest exec failed"; exit 1; }
}

remove_bootstrap_cloudinit() {
  log "Removing ipconfig2 (.121) from cloud-init"
  qm set "$VMID" --delete ipconfig2 2>/dev/null || true
  qm cloudinit update "$VMID"
}

remove_bootstrap_nic_cold() {
  log "Cold-remove net2 (VM must be stopped)"
  if qm status "$VMID" | grep -q running; then
    log "Stopping VM $VMID for safe net2 removal"
    qm stop "$VMID"
    sleep 3
  fi
  qm set "$VMID" --delete net2 2>/dev/null || true
  qm start "$VMID"
  log "VM $VMID started without net2"
}

main() {
  need_root "$@"
  check_nic1
  verify_vm21
  apply_guest_netplan
  remove_bootstrap_cloudinit
  remove_bootstrap_nic_cold
  log "DONE — prichindel-vm: .21 default, .23 corp; bootstrap .121 removed. net2 virtio removed cold."
  qm config "$VMID" | grep -E '^net|^ipconfig' || true
}

main "$@"
