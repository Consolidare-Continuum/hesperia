#!/usr/bin/env bash
# prichindel (root): create /data/smtp-outbound/proton-external.env from existing /etc/postfix/sasl_passwd
# so igareosh-readable creds exist without re-entering the token. Does not change Postfix.
# Ref: cluster/prichindel/smtp/README.md
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "FAIL: run as root (sudo)." >&2
  exit 1
fi

SASL=/etc/postfix/sasl_passwd
OUT_DIR="${PROTON_SMTP_OUT_DIR:-/data/smtp-outbound}"
ENV_FILE="${PROTON_SMTP_ENV_FILE:-${OUT_DIR}/proton-external.env}"

if [ ! -f "$SASL" ]; then
  echo "FAIL: missing $SASL" >&2
  exit 1
fi

line=$(grep -v '^[[:space:]]*#' "$SASL" | grep -v '^[[:space:]]*$' | head -1)
if [ -z "${line}" ]; then
  echo "FAIL: no usable line in $SASL" >&2
  exit 1
fi

key=$(printf '%s' "$line" | awk '{print $1}')
cred=$(printf '%s' "$line" | awk '{print $2}')
user=${cred%%:*}
pass=${cred#*:}
if [ -z "$user" ] || [ -z "$pass" ] || [ "$user" = "$cred" ]; then
  echo "FAIL: could not parse user:password from sasl line" >&2
  exit 1
fi

host=smtp.protonmail.ch
port=587
case "$key" in
  *protonmail.ch*|"[smtp.protonmail.ch]:587") ;;
  *127.0.0.1*|:1025*)
    echo "FAIL: sasl key is ${key} — use proton-smtp-secret-apply.sh after relay is smtp.protonmail.ch:587" >&2
    exit 1
    ;;
esac

mkdir -p "$OUT_DIR"
chmod 755 "$OUT_DIR"

umask 077
TMP=$(mktemp)
trap 'rm -f "$TMP"' EXIT
cat >"$TMP" <<EOF
# Bootstrapped from Postfix sasl_passwd — rotate token in Bridge if this file was ever exposed
PROTON_SMTP_HOST=${host}
PROTON_SMTP_PORT=${port}
PROTON_SMTP_USER=${user}
PROTON_SMTP_PASSWORD=${pass}
EOF

install -m 0640 -o root -g igareosh "$TMP" "$ENV_FILE"
echo "OK: wrote ${ENV_FILE} (root:igareosh 640) from ${SASL}"
