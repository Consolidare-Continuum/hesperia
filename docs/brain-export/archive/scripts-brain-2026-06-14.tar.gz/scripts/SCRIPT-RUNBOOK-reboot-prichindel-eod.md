# Runbook — Reboot prichindel (end of day)

**When**: After EOD workflow steps 1–5 (repo consolidation, commit/push, Chroma ingest). Run only when operator requests "reboot prichindel EOD" or equivalent.

**Where**: On prichindel (SSH or local). Requires sudo.

---

## 1. Pre-reboot (optional)

- Confirm EOD workflow step 4 (push) and step 5 (Chroma ingest) are done if they were run today.
- Optional: `uname -r` to note current kernel (e.g. 5.15.0-164 before reboot to 5.15.0-168).

---

## 2. Schedule reboot

**Command** (reboot in 10 minutes; wall message to logged-in users):

```bash
sudo shutdown -r +10 "Prichindel EOD reboot — back in ~8 min"
```

**Cancel** if you change your mind:

```bash
sudo shutdown -c
```

**Immediate reboot** (no delay):

```bash
sudo shutdown -r now "Prichindel EOD reboot"
```

---

## 3. After reboot

- Server typically takes **7–8 minutes** to be fully back (network, systemd, Chroma, tunnels).
- Then: `curl -s http://chroma-1.prichindel.local:8002/api/v2/heartbeat` and `curl -s http://127.0.0.1:8006/health` to confirm Chroma and query API.

---

## 4. Next maintenance run (upcoming week)

**After** the EOD reboot, the **first maintenance run** of the upcoming week is a **post-reboot** run. Abelard (or whoever runs it) should:

- **Read**: [agents/abelard/MAINTENANCE-NEXT-RUN-AWARENESS.md](../agents/abelard/MAINTENANCE-NEXT-RUN-AWARENESS.md) for the current "next run" checklist.
- **Do**: Create run dir per MAINTENANCE_POLICY; post-reboot capture (kernel, failed units, disk); Chroma + query API + key services check; notes/README.md and notes/NEXT_RUN.md; update `latest`.

One-line reminder: `sudo cat /data/system_maintenance/latest/notes/NEXT_RUN.md` after the run to carry forward any deferred items.

---

**Ref**: MAINTENANCE.md (reboot when convenient; kernel 5.15.0-168). EOD workflow: .cursor/END-OF-DAY-WORKFLOW.md. Post-reboot awareness: agents/abelard/MAINTENANCE-NEXT-RUN-AWARENESS.md.
