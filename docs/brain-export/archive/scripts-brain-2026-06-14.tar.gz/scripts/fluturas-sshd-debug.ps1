# Run as Administrator. Output sshd config and admin keys to file for debugging.
$cfg = "C:\ProgramData\ssh\sshd_config"
$adminKeys = "C:\ProgramData\ssh\administrators_authorized_keys"
$out = "$env:USERPROFILE\fluturas-sshd-debug.txt"
@(
  "sshd_config exists: $(Test-Path $cfg)",
  (if (Test-Path $cfg) { Get-Content $cfg | Select-String -Pattern "AuthorizedKeysFile|Match|PubkeyAuthentication|PasswordAuthentication" | ForEach-Object { $_.Line } }),
  "administrators_authorized_keys exists: $(Test-Path $adminKeys)",
  (if (Test-Path $adminKeys) { "Size: $((Get-Item $adminKeys -Force).Length)"; (Get-Content $adminKeys -Raw).Substring(0, [Math]::Min(80, (Get-Content $adminKeys -Raw).Length)) + "..." })
) | Set-Content $out -Encoding UTF8
Write-Host "Wrote $out"
