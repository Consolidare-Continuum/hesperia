#!/usr/bin/env bash
# List all GitHub repos (user + default org) and write to cluster/github-repos-list.txt
# Run from workspace root. Requires: gh auth login first.
# Abelard: cluster/GITHUB-REPOS.md

set -euo pipefail
WORKSPACE_ROOT="${CURSOR_WORKSPACE:-/data/workspaces/cursor}"
OUT_TXT="${WORKSPACE_ROOT}/cluster/github-repos-list.txt"
OUT_JSON="${WORKSPACE_ROOT}/cluster/github-repos-list.json"

cd "$WORKSPACE_ROOT"

if ! command -v gh &>/dev/null; then
  echo "gh not found. Install GitHub CLI." >&2
  exit 1
fi

if ! gh auth status &>/dev/null; then
  echo "gh not authenticated. Run: gh auth login" >&2
  exit 1
fi

echo "Listing repos (user + orgs)..." >&2
{
  echo "# GitHub repos list — generated $(date -Iseconds)"
  echo "# Command: gh repo list --limit 500"
  echo ""
  gh repo list --limit 500
} > "$OUT_TXT"

# Optional: JSON for machine use
if gh repo list --limit 500 --json name,owner,nameWithOwner,description,visibility,url 2>/dev/null | head -c 1 | grep -q .; then
  gh repo list --limit 500 --json name,owner,nameWithOwner,description,visibility,url > "$OUT_JSON" 2>/dev/null || true
fi

echo "Wrote $OUT_TXT" >&2
[[ -f "$OUT_JSON" ]] && echo "Wrote $OUT_JSON" >&2
