"""trustmaster: remove even MinIO Authentik Application + OAuth2 provider; keep shetiyya-papra-proxy (pk=1) only.

Run: pipe into docker exec -i authentik-server-1 ... manage.py shell on trustmaster (192.168.100.67).

Idempotent: skips if slug / provider already absent.
"""

from authentik.core.models import Application
from authentik.providers.oauth2.models import OAuth2Provider

SLUG = "even-minio-console"
PROVIDER_NAME = "even-minio-console-proxy"

if Application.objects.filter(slug=SLUG).exists():
    a = Application.objects.get(slug=SLUG)
    a.delete()
    print("DELETED application", SLUG)
else:
    print("SKIP no application", SLUG)

if OAuth2Provider.objects.filter(name=PROVIDER_NAME).exists():
    p = OAuth2Provider.objects.get(name=PROVIDER_NAME)
    pid = p.pk
    p.delete()
    print("DELETED provider", PROVIDER_NAME, "was_pk", pid)
else:
    print("SKIP no provider", PROVIDER_NAME)

rem = OAuth2Provider.objects.count()
print("REMAINING_OAUTH2_PROVIDERS", rem, list(OAuth2Provider.objects.values_list("pk", "name")))
