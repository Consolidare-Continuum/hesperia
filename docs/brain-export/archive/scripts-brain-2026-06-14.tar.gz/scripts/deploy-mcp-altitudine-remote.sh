#!/usr/bin/env bash
# Permanent MCP deploy for altitudine dev VM (Linux). Run from alunel (or any host with SSH to altitudine).
# Idempotent: agent cert sync, SSH CA merge, mcp-config deploy, handshake verify.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
ALT_HOST="${ALT_HOST:-altitudine}"
ALUNEL_HOST="${ALUNEL_HOST:-alunel}"
SSH_OPTS=(-o BatchMode=yes -o ConnectTimeout=10)
DEPLOY_STAGING="${DEPLOY_STAGING:-/tmp/cursor-mcp-altitudine-deploy}"

echo "== deploy-mcp-altitudine-remote (repo=$REPO_ROOT target=$ALT_HOST) =="

HERE="$(hostname -s 2>/dev/null || true)"
if [ "$HERE" != "$ALUNEL_HOST" ]; then
  ssh "${SSH_OPTS[@]}" "$ALUNEL_HOST" true
fi
ssh "${SSH_OPTS[@]}" "$ALT_HOST" true

echo "== sync agent SSH CA cert from alunel =="
ssh "${SSH_OPTS[@]}" "$ALT_HOST" 'mkdir -p ~/.ssh/agent-ca && chmod 700 ~/.ssh/agent-ca'
if [ "$HERE" = "$ALUNEL_HOST" ]; then
  scp "${SSH_OPTS[@]}" \
    "${HOME}/.ssh/agent-ca/id_agent" \
    "${HOME}/.ssh/agent-ca/id_agent-cert.pub" \
    "${HOME}/.ssh/agent-ca/agent_ca.pub" \
    "$ALT_HOST:~/.ssh/agent-ca/"
else
  scp "${SSH_OPTS[@]}" \
    "$ALUNEL_HOST:~/.ssh/agent-ca/id_agent" \
    "$ALUNEL_HOST:~/.ssh/agent-ca/id_agent-cert.pub" \
    "$ALUNEL_HOST:~/.ssh/agent-ca/agent_ca.pub" \
    "$ALT_HOST:~/.ssh/agent-ca/"
fi
ssh "${SSH_OPTS[@]}" "$ALT_HOST" 'chmod 600 ~/.ssh/agent-ca/id_agent ~/.ssh/agent-ca/id_agent-cert.pub'

echo "== stage merge helpers on altitudine =="
ssh "${SSH_OPTS[@]}" "$ALT_HOST" "rm -rf $DEPLOY_STAGING && mkdir -p $DEPLOY_STAGING/scripts $DEPLOY_STAGING/cluster"
scp "${SSH_OPTS[@]}" "$REPO_ROOT/scripts/agent-ssh-merge-config.sh" "$ALT_HOST:$DEPLOY_STAGING/scripts/agent-ssh-merge-config.sh"
scp "${SSH_OPTS[@]}" -r "$REPO_ROOT/cluster/agent-ssh" "$ALT_HOST:$DEPLOY_STAGING/cluster/agent-ssh"
ssh "${SSH_OPTS[@]}" "$ALT_HOST" "chmod +x $DEPLOY_STAGING/scripts/agent-ssh-merge-config.sh"

echo "== merge agent SSH CA block =="
ssh "${SSH_OPTS[@]}" "$ALT_HOST" "REPO_ROOT=$DEPLOY_STAGING bash $DEPLOY_STAGING/scripts/agent-ssh-merge-config.sh"

echo "== ensure prichindel in /etc/hosts =="
ssh "${SSH_OPTS[@]}" "$ALT_HOST" 'grep -q "192.168.100.21.*prichindel" /etc/hosts || echo "192.168.100.21 prichindel prichindel.prichindel.local" | sudo tee -a /etc/hosts >/dev/null'

echo "== deploy mcp-config.json =="
scp "${SSH_OPTS[@]}" "$REPO_ROOT/governance/mcp-config.json" "$ALT_HOST:/tmp/mcp-config.json"
ssh "${SSH_OPTS[@]}" "$ALT_HOST" 'mkdir -p ~/.cursor && cp /tmp/mcp-config.json ~/.cursor/mcp.json && chmod 600 ~/.cursor/mcp.json'

echo "== verify SSH prichindel =="
ssh "${SSH_OPTS[@]}" "$ALT_HOST" 'ssh -o BatchMode=yes prichindel echo ok' | grep -q ok

echo "== MCP handshake (9 servers) =="
scp "${SSH_OPTS[@]}" "$REPO_ROOT/scripts/verify-mcp-handshake.sh" "$ALT_HOST:/tmp/verify-mcp-handshake.sh"
ssh "${SSH_OPTS[@]}" "$ALT_HOST" 'chmod +x /tmp/verify-mcp-handshake.sh && bash /tmp/verify-mcp-handshake.sh'

echo "OK: altitudine MCP deploy complete. Restart Cursor on altitudine."
