---
task_id: "WF-APP|workflow-proceed-gates"
active_md_anchor: "workflow-proceed-gates"
---

# Script runbook — workflow proceed gates (umbrella)

**Purpose**: Single map of **when which proceed gate** applies in daily dev workflow. Gates are **process** (runbooks + MCP when available); operator excluded from MCP build.

**Refs**: [SPEC-ETHAN-MCP-APPENDIX-DAILY-USE.md](../governance/SPEC-ETHAN-MCP-APPENDIX-DAILY-USE.md), [WF-APP-2026-REGISTER.md](../governance/WF-APP-2026-REGISTER.md)

---

## Daily loop

```
Orient → CSP/passport → gates → execute → verify → report_done
```

---

## Gate matrix

| Gate | Hard/soft | Runbook | MCP tool (when in session) | When |
|------|-----------|---------|----------------------------|------|
| **Cluster preflight** | **Hard** | [SCRIPT-RUNBOOK-cluster-proceed-preflight.md](SCRIPT-RUNBOOK-cluster-proceed-preflight.md) | `get_cluster_snapshot`, `list_firing_alerts` | Abelard owner; cluster/prod/services project |
| **CI verify** | Soft | [SCRIPT-RUNBOOK-github-ci-verify.md](SCRIPT-RUNBOOK-github-ci-verify.md) | `get_branch_ci`, `get_pr_checks` | Code row + open PR before DONE |
| **Context packet** | Domain | Hesperia workflow doc (Felix) | `get_context_packet`, `get_context_retrieval` | Hesperia / IPoV / matrix work |
| **Inbox orient** | Read-only | [SCRIPT-RUNBOOK-grace-triage-active.md](SCRIPT-RUNBOOK-grace-triage-active.md) | `get_inbox_summary`, `get_inbox_entry` | Triage / orient |
| **Destructive** | **Hard** | [SCRIPT-RUNBOOK-approval-gate-destructive.md](SCRIPT-RUNBOOK-approval-gate-destructive.md) | `list_pending_approvals`, `get_approval_status` | Before destructive/high-risk |
| **report_done** | Required | [SCRIPT-RUNBOOK-report-done-workflow.md](SCRIPT-RUNBOOK-report-done-workflow.md) | `report_done` | Owner completes row |

---

## BLOCKED vs PAUSE

| Signal | Status |
|--------|--------|
| Critical Prometheus alert firing | **BLOCKED** — no prod/deploy |
| Red CI on code row | **PAUSE** (soft) — fix or document |
| Missing MCP session | Continue from repo runbooks; fix config per [SCRIPT-RUNBOOK-mcp-chroma-session.md](SCRIPT-RUNBOOK-mcp-chroma-session.md) |
| Missing approval for destructive | **BLOCKED** |

---

## Passport

Read [governance/workflow_context_current.md](../governance/workflow_context_current.md) for owner CSP and gate hints when driver assigns current step.

SIGNED: Runbooks (Liam) | workflow proceed gates umbrella | 2026-05-31 | WF-APP-011
