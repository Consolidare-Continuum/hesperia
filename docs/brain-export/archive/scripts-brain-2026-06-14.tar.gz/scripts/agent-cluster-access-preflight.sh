#!/usr/bin/env bash
# Unified agent cluster access preflight. Run on alunel (or via: ssh alunel 'bash -s' < this).
# Writes governance/agent_cluster_access_last.txt for MCP/agents.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$REPO_ROOT"
OUT="$REPO_ROOT/governance/agent_cluster_access_last.txt"
HOST="$(hostname -s 2>/dev/null || hostname)"
NOW_ISO="$(date -Iseconds)"

status() { echo "$1" | tee -a /tmp/agent-access-preflight.log; }

: > /tmp/agent-access-preflight.log

if [ "$HOST" != "alunel" ]; then
    if ssh -o BatchMode=yes -o ConnectTimeout=8 alunel "REPO_ROOT=$REPO_ROOT bash $REPO_ROOT/scripts/agent-cluster-access-preflight.sh" 2>/dev/null; then
        exit 0
    fi
    cat >"$OUT" <<EOF
checked_at: $NOW_ISO
session_host: $HOST
cluster_ssh_origin: jump_required
cluster_ssh_blocked: true
reason: not_alunel_and_alunel_jump_failed
action: ssh alunel then re-run bash scripts/agent-cluster-access-preflight.sh
authentik_ui: https://trustmaster.prichindel.com
EOF
    echo "BLOCKED: run on alunel (session=$HOST). Try: ssh alunel"
    exit 1
fi

STATUS_FILE="$REPO_ROOT/governance/agent_ssh_cert_status.txt"
VALID_UNTIL=""
CERT_OK=false
if [ -f "$STATUS_FILE" ]; then
    VALID_UNTIL=$(grep '^valid_until:' "$STATUS_FILE" | cut -d' ' -f2-)
    VALID_EPOCH=$(date -d "$VALID_UNTIL" +%s 2>/dev/null || echo 0)
    NOW_EPOCH=$(date +%s)
    if [ "$VALID_EPOCH" -gt "$NOW_EPOCH" ]; then
        CERT_OK=true
    fi
fi

if [ "$CERT_OK" = false ]; then
    status "ISSUE: agent cert missing or expired ($VALID_UNTIL). Renewing..."
    bash "$REPO_ROOT/scripts/agent-ssh-cert-renew.sh"
    VALID_UNTIL=$(grep '^valid_until:' "$STATUS_FILE" | cut -d' ' -f2-)
fi

bash "$REPO_ROOT/scripts/agent-ssh-merge-config.sh" >/dev/null

TRUST_REPORT=$(bash "$REPO_ROOT/scripts/agent-ssh-verify-trust.sh" 2>/dev/null || true)
TRUSTMASTER_LINE=$(echo "$TRUST_REPORT" | grep '^trustmaster:' || echo 'trustmaster: unknown')
PRICHINDEL_LINE=$(echo "$TRUST_REPORT" | grep '^prichindel:' || echo 'prichindel: unknown')

SSH_OK=false
if ssh -o BatchMode=yes -o ConnectTimeout=8 trustmaster 'sudo -n true' 2>/dev/null; then
    SSH_OK=true
fi

BLOCKED=false
REASON=""
if [ "$SSH_OK" = false ]; then
    BLOCKED=true
    REASON="trustmaster_ssh_failed_after_preflight"
fi

cat >"$OUT" <<EOF
checked_at: $NOW_ISO
session_host: alunel
cluster_ssh_origin: alunel
agent_cert_valid_until: $VALID_UNTIL
cluster_ssh_blocked: $BLOCKED
trustmaster: $TRUSTMASTER_LINE
prichindel: $PRICHINDEL_LINE
authentik_ui: https://trustmaster.prichindel.com
authentik_ops_doc: cluster/trustmaster/ACCESS.md
runbook: SCRIPT-RUNBOOK-trustmaster-access
reason: $REASON
EOF

echo "agent cert valid_until: $VALID_UNTIL"
echo "$TRUSTMASTER_LINE"
echo "$PRICHINDEL_LINE"

if [ "$BLOCKED" = true ]; then
    echo "ISSUE: trustmaster SSH still failing — try: bash scripts/agent-ssh-install-via-qemu.sh 104"
    exit 1
fi

# Sync visibility files to prichindel (MCP host reads that repo copy)
if ssh -o BatchMode=yes -o ConnectTimeout=5 prichindel 'test -d /data/workspaces/cursor/governance' 2>/dev/null; then
    scp -q "$STATUS_FILE" "$OUT" prichindel:/data/workspaces/cursor/governance/ 2>/dev/null || true
fi

echo "OK: agent cluster access preflight passed"
exit 0
