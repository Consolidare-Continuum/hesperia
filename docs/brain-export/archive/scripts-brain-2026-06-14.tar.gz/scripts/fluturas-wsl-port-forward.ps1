# Run as Administrator. Stop and disable Windows sshd (so it never grabs 22), forward host port 22 to WSL sshd.
# If you see "Connection timed out during banner exchange", run this on fluturas — WSL IP changed.
$ErrorActionPreference = 'Stop'
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Warning "Not running as Administrator. Port forward and firewall will NOT be applied. Right-click PowerShell -> Run as administrator, or run cluster\fluturas\RUN-PORT-FORWARD-ON-FLUTURAS.bat as Admin." }
Write-Host "Stopping Windows sshd..."
Stop-Service sshd -ErrorAction SilentlyContinue
Set-Service sshd -StartupType Disabled -ErrorAction SilentlyContinue
Write-Host "Getting WSL IP (timeout 15s)..."
$outFile = [System.IO.Path]::GetTempFileName()
try {
  $errFile = [System.IO.Path]::GetTempFileName()
  $p = Start-Process -FilePath "wsl" -ArgumentList "-d","Ubuntu","-e","hostname","-I" -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
  $done = $p.WaitForExit(15000)  # 15s
  if (-not $done) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; Write-Host "WSL IP call timed out." }
  $wslIp = (Get-Content $outFile -Raw -ErrorAction SilentlyContinue).Trim().Split()[0]
} finally { Remove-Item $outFile -Force -ErrorAction SilentlyContinue; if ($errFile) { Remove-Item $errFile -Force -ErrorAction SilentlyContinue } }
if (-not $wslIp) { Write-Error "Could not get WSL IP in 15s. Is WSL running? Try: wsl -d Ubuntu -e hostname -I"; exit 1 }
Write-Host "WSL IP: $wslIp"
# Ensure WSL sshd is running so banner exchange succeeds (fire-and-forget; don't block on sudo)
Start-Process -FilePath "wsl" -ArgumentList "-d","Ubuntu","-e","sudo","service","ssh","start" -NoNewWindow -ErrorAction SilentlyContinue
netsh interface portproxy delete v4tov4 listenport=22 listenaddress=0.0.0.0 2>$null
netsh interface portproxy add v4tov4 listenport=22 listenaddress=0.0.0.0 connectport=22 connectaddress=$wslIp
netsh advfirewall firewall add rule name="WSL SSH (cluster only)" dir=in action=allow protocol=TCP localport=22 remoteip=192.168.100.21,192.168.100.23,192.168.100.40 profile=private,domain 2>$null
Write-Host "Port 22 -> WSL $wslIp`:22; firewall allow cluster IPs. From prichindel: ssh igare@192.168.100.8"
Write-Host "If SSH still times out during banner exchange, retry after a few seconds (WSL sshd may be starting)."