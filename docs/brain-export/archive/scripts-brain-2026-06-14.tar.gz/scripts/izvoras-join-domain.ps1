# Join izvoras to PRICHINDEL.LOCAL. Run with: <password> | powershell -ExecutionPolicy Bypass -File izvoras-join-domain.ps1
# Requires admin (igare is in Administrators).
$pass = [System.Console]::In.ReadToEnd().Trim()
if (-not $pass) { Write-Error "No password on stdin"; exit 1 }
Set-DnsClientServerAddress -InterfaceAlias "Wi-Fi" -ServerAddresses "192.168.100.23" -ErrorAction Stop
$sec = ConvertTo-SecureString $pass -AsPlainText -Force
$cred = New-Object PSCredential("PRICHINDELAD\Administrator", $sec)
Add-Computer -DomainName "PRICHINDEL.LOCAL" -Credential $cred -Restart -Force
