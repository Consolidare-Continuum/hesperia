#!/usr/bin/env bash
# Abelard — reset / verify cursor workspace (Linux)
# Run from repo root: ./scripts/reset-repo-abelard.sh [--dry-run]
# Policy: REPO-POLICY.md, cluster/MAINTENANCE_POLICY.md.
# No secrets in output.

set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd -P "$(dirname "$0")/.." && pwd)}"
DRY_RUN=false
LOG_PREFIX="[reset-repo-abelard]"

for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=true ;;
  esac
done

run() {
  if "$DRY_RUN"; then
    echo "$LOG_PREFIX [DRY-RUN] $*"
    return 0
  fi
  "$@"
}

echo "$LOG_PREFIX $(date -Iseconds) start (repo=$REPO_ROOT)"

# ——— Workspace present ———
if [[ ! -d "$REPO_ROOT/.git" ]]; then
  echo "$LOG_PREFIX ERROR: not a git repo: $REPO_ROOT" >&2
  exit 1
fi
echo "$LOG_PREFIX workspace OK: $REPO_ROOT"

# ——— Git state (no modify) ———
echo "$LOG_PREFIX --- git status ---"
run git -C "$REPO_ROOT" status --short
echo "$LOG_PREFIX --- git branch ---"
run git -C "$REPO_ROOT" branch -v

# ——— Policy / consistency docs present ———
for f in REPO-POLICY.md CONSISTENCY.md AGENTS.md; do
  if [[ -f "$REPO_ROOT/$f" ]]; then
    echo "$LOG_PREFIX doc OK: $f"
  else
    echo "$LOG_PREFIX WARN: missing $f"
  fi
done

# ——— .vscode present ———
if [[ -d "$REPO_ROOT/.vscode" ]]; then
  echo "$LOG_PREFIX .vscode OK"
else
  echo "$LOG_PREFIX WARN: .vscode missing"
fi

# ——— Optional: run maintenance (Abelard) ———
# Uncomment to run maintenance after reset check:
# if ! "$DRY_RUN"; then
#   echo "$LOG_PREFIX running maintenance..."
#   sudo "$REPO_ROOT/scripts/run-maintenance.sh" || true
# fi

echo "$LOG_PREFIX $(date -Iseconds) done"
