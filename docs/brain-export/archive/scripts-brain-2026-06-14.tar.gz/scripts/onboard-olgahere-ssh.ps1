# Onboard olgahere: ensure .ssh, generate key, show pubkey for prichindel authorized_keys.
# Run on olgahere (192.168.100.5). Do not lock out: owner of .ssh = current user.
# See cluster/olgahere/README.md
#
# Run from repo root, e.g.:
#   cd C:\Users\<you>\Proton Drive\...\cursor
#   .\scripts\onboard-olgahere-ssh.ps1
# Or by full path:
#   & "C:\Users\<you>\Proton Drive\...\cursor\scripts\onboard-olgahere-ssh.ps1"

$ErrorActionPreference = 'Stop'
$sshDir = Join-Path $env:USERPROFILE '.ssh'
$keyPath = Join-Path $sshDir 'id_ed25519_prichindel'

if (-not (Test-Path $sshDir)) {
    New-Item -ItemType Directory -Path $sshDir | Out-Null
    Write-Host "Created $sshDir"
}

# Owner check (informational; do not change owner blindly)
$acl = Get-Acl $sshDir
Write-Host "Owner of .ssh: $($acl.Owner)"

if (-not (Test-Path "$keyPath.pub")) {
    ssh-keygen -t ed25519 -f $keyPath -C "olgahere@prichindel" -N '""'
    Write-Host "Generated $keyPath"
} else {
    Write-Host "Key already exists: $keyPath"
}

# Add prichindel host keys to known_hosts if not present
$knownHosts = Join-Path $sshDir 'known_hosts'
if (-not (Test-Path $knownHosts)) { New-Item -ItemType File -Path $knownHosts -Force | Out-Null }
foreach ($ip in '192.168.100.21', '192.168.100.23') {
    if (-not (Select-String -Path $knownHosts -Pattern $ip -Quiet -ErrorAction SilentlyContinue)) {
        ssh-keyscan -t ed25519 $ip 2>$null | Add-Content -Path $knownHosts
        Write-Host "Added $ip to known_hosts"
    }
}

Write-Host "`n--- Paste this line into authorized_keys on prichindel (igareosh) ---"
Get-Content "$keyPath.pub"
Write-Host "--- End ---"
