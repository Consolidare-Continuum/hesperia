# Start sshd and set Automatic. Run as Administrator.
Set-Service sshd -StartupType Automatic
Start-Service sshd
Get-Service sshd
