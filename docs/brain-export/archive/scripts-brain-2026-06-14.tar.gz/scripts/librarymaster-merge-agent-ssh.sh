#!/usr/bin/env bash
# librarymaster (or any host): merge cluster SSH config + known_hosts + LAN /etc/hosts block.
# Run as igareosh; sudo only for cluster-merge-lan-hosts.sh.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
FRAGMENT="$REPO_ROOT/cluster/librarymaster/ssh-config-cluster.fragment"
MARKER="Host prichindel"
SSH_CONFIG="${HOME}/.ssh/config"
KEY="${HOME}/.ssh/id_ed25519_altitudine_travel"

mkdir -p "${HOME}/.ssh"
chmod 700 "${HOME}/.ssh"

if [[ ! -f "$KEY" ]]; then
  echo "ERROR: missing $KEY — agent cannot SSH to cluster." >&2
  exit 1
fi

DEST_BLOCK="${HOME}/.ssh/config.cluster-agent"
{
  echo "# Cluster agent SSH — librarymaster (managed: scripts/librarymaster-merge-agent-ssh.sh)"
  cat "$FRAGMENT"
  echo ""
  echo "Host github.com"
  echo "    HostName github.com"
  echo "    User git"
  echo "    IdentityFile ~/.ssh/github_key"
  echo "    IdentitiesOnly yes"
} >"$DEST_BLOCK"
if [[ -f "$SSH_CONFIG" ]] && grep -qF "$MARKER" "$SSH_CONFIG" 2>/dev/null && ! grep -qF "BEGIN cluster agent SSH" "$SSH_CONFIG" 2>/dev/null; then
  cp -a "$SSH_CONFIG" "${SSH_CONFIG}.bak.$(date +%s)"
fi
cp "$DEST_BLOCK" "$SSH_CONFIG"
chmod 600 "$SSH_CONFIG"
echo "OK: installed $SSH_CONFIG from cluster fragment"

# known_hosts for LAN + tailnet names
for host in \
  prichindel.prichindel.local 192.168.100.21 \
  alunel.prichindel.local 192.168.100.62 100.75.161.108 \
  altitudine.prichindel.local 192.168.100.65 \
  100.98.190.22 100.114.133.33; do
  ssh-keyscan -H "$host" 2>/dev/null >>"${HOME}/.ssh/known_hosts" || true
  done
sort -u "${HOME}/.ssh/known_hosts" -o "${HOME}/.ssh/known_hosts.tmp" 2>/dev/null && mv "${HOME}/.ssh/known_hosts.tmp" "${HOME}/.ssh/known_hosts" || true
echo "OK: known_hosts updated"

if [[ "$(id -u)" -eq 0 ]]; then
  bash "$REPO_ROOT/scripts/cluster-merge-lan-hosts.sh"
else
  if command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
    sudo -n bash "$REPO_ROOT/scripts/cluster-merge-lan-hosts.sh"
    echo "OK: /etc/hosts cluster LAN block merged"
  else
    echo "WARN: run sudo $REPO_ROOT/scripts/cluster-merge-lan-hosts.sh for full LAN DNS"
  fi
fi

# Tailscale hostname: this VM should be librarymaster, not altitudine (legacy enroll name).
if command -v tailscale >/dev/null 2>&1; then
  ts_name="$(tailscale status --json 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print((d.get('Self') or {}).get('HostName',''))" 2>/dev/null || true)"
  if [[ "$ts_name" == "altitudine" && "$(hostname -s)" == "librarymaster" ]]; then
    if sudo -n tailscale set --hostname=librarymaster 2>/dev/null; then
      echo "OK: tailscale hostname set to librarymaster (was altitudine)"
    else
      echo "WARN: tailscale still registered as altitudine — sudo tailscale set --hostname=librarymaster"
    fi
  fi
fi

echo "Smoke:"
for h in prichindel alunel altitudine; do
  if ssh -o BatchMode=yes -o ConnectTimeout=8 "$h" 'hostname' 2>/dev/null; then
    echo "  $h OK"
  else
    echo "  $h FAIL" >&2
  fi
done
