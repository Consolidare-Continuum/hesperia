#!/usr/bin/env bash
# Colombo — query CHROMA-2 (librarymaster Papra library). Domain asset for books/papers/objects.
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

export CHROMA_SERVER_URL="${CHROMA_SERVER_URL:-http://chroma-2.prichindel.local:8002}"
export CHROMA_COLLECTION="${CHROMA_COLLECTION:-documents}"
export ANONYMIZED_TELEMETRY=FALSE

# Prefer librarymaster venv when local; else alunel chroma venv; else python3 on PATH.
if [[ -x /data/chroma-2/venv/bin/python ]]; then
  PY=/data/chroma-2/venv/bin/python
elif [[ -x /data/chroma-alunel/venv/bin/python ]]; then
  PY=/data/chroma-alunel/venv/bin/python
elif [[ -x /data/chroma/venv/bin/python ]]; then
  PY=/data/chroma/venv/bin/python
else
  PY=python3
fi

# Preflight heartbeat (LAN)
if ! curl -sf "${CHROMA_SERVER_URL}/api/v2/heartbeat" >/dev/null 2>&1; then
  if ! curl -sf "${CHROMA_SERVER_URL}/api/v1/heartbeat" >/dev/null 2>&1; then
    echo "BLOCKED: CHROMA-2 unreachable at ${CHROMA_SERVER_URL}" >&2
    echo "Check: curl -s ${CHROMA_SERVER_URL}/api/v2/heartbeat · host librarymaster .66" >&2
    exit 1
  fi
fi

export PYTHONPATH="$REPO_ROOT${PYTHONPATH:+:$PYTHONPATH}"
exec "$PY" "$REPO_ROOT/cluster/librarymaster/colombo_chroma2_query.py" "$@"
