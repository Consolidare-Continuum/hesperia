#!/usr/bin/env bash
# Operator-approved Papra **DATA phase** full reindex on librarymaster (CHROMA-2).
# **Requires G0 PASS** (PAPRA-10 ≤3-doc dry-run) + deploy script already run.
# Do NOT run before: librarymaster-chroma2-schema-deploy.sh + papra-g0-dry-run-3.sh
#
# - Bump VM to 24 cores (Proxmox 103 on alunel)
# - Turbo systemd drop-in, clear processed state, start papra-ingest
#
# Run from brain repo on alunel:
#   bash scripts/librarymaster-papra-evening-reindex.sh
#
# Ref: governance/PAPRA-CHROMA2-2026-REGISTER.md · PAPRA-18 operator approval 2026-06-14
set -euo pipefail

REPO="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
VMID=103
LM=librarymaster
INGEST=/data/docker/papra/ingest
BRAIN=/data/workspaces/cursor

log() { echo "[papra-evening] $*"; }

if [[ "$(hostname -s)" != "alunel" ]]; then
  log "Sync deploy bundle to alunel..."
  rsync -az "$REPO/scripts/librarymaster-deploy-chroma-2.sh" \
    "$REPO/scripts/verify-chroma2-persist.sh" \
    "$REPO/scripts/librarymaster-papra-evening-reindex.sh" \
    alunel:/data/workspaces/cursor/scripts/
  rsync -az "$REPO/cluster/librarymaster/" \
    alunel:/data/workspaces/cursor/cluster/librarymaster/
  log "Jumping to alunel..."
  exec ssh -o BatchMode=yes alunel "bash /data/workspaces/cursor/scripts/librarymaster-papra-evening-reindex.sh"
fi

REPO=/data/workspaces/cursor

if [[ "${ALLOW_PAPRA_REINDEX:-0}" != "1" ]]; then
  log "BLOCKED: set ALLOW_PAPRA_REINDEX=1 only after G0 dry-run (PAPRA-10) PASS"
  log "Use scripts/librarymaster-chroma2-schema-deploy.sh then librarymaster-papra-g0-dry-run-3.sh first"
  exit 1
fi

log "=== PAPRA DATA phase reindex (operator approved, G0 assumed PASS) ==="

log "1) VM ${VMID} → 24 cores"
sudo qm set "${VMID}" -cores 24

log "2) Sync ingest worker v1 + CHROMA units to librarymaster"
ssh "$LM" "sudo mkdir -p ${INGEST} /etc/systemd/system/papra-ingest.service.d ${BRAIN}/scripts ${BRAIN}/cluster/librarymaster/chroma"
rsync -az \
  "$REPO/cluster/librarymaster/papra/filename_metadata.py" \
  "$REPO/cluster/librarymaster/papra/ingest_worker.py" \
  "${LM}:${INGEST}/"
rsync -az "$REPO/cluster/librarymaster/papra/papra-ingest.service.d/" \
  "${LM}:/tmp/papra-ingest.service.d/"
ssh "$LM" "sudo mkdir -p /etc/systemd/system/papra-ingest.service.d && sudo cp /tmp/papra-ingest.service.d/*.conf /etc/systemd/system/papra-ingest.service.d/"
rsync -az "$REPO/cluster/librarymaster/chroma/" "${LM}:${BRAIN}/cluster/librarymaster/chroma/"
rsync -az "$REPO/scripts/librarymaster-deploy-chroma-2.sh" \
  "$REPO/scripts/verify-chroma2-persist.sh" \
  "${LM}:${BRAIN}/scripts/"

log "3) Deploy CHROMA-2 (--restart)"
ssh "$LM" "cd ${BRAIN} && sudo REPO_ROOT=${BRAIN} bash scripts/librarymaster-deploy-chroma-2.sh --restart"

log "4) Backup processed.json + wipe Chroma + reset state for full reindex"
ssh "$LM" "cd ${INGEST} && cp -a processed.json processed.json.bak.evening-\$(date +%Y%m%d-%H%M%S) 2>/dev/null || true; echo '{}' > processed.json"
ssh "$LM" "${INGEST}/venv/bin/python" <<'PY'
import chromadb
c = chromadb.HttpClient(host="127.0.0.1", port=8002)
col = c.get_collection("documents")
n = 0
while True:
    part = col.get(limit=5000, include=[])
    ids = part.get("ids") or []
    if not ids:
        break
    col.delete(ids=ids)
    n += len(ids)
print("wiped_chunks", n)
PY

log "5) Reboot librarymaster to pick up 24 cores (if still 8)"
CORES=$(ssh "$LM" nproc)
if [[ "${CORES}" -lt 24 ]]; then
  log "nproc=${CORES} — rebooting librarymaster for vCPU hotplug"
  ssh "$LM" "sudo reboot" || true
  log "Waiting for librarymaster..."
  for i in $(seq 1 60); do
    sleep 5
    if ssh -o ConnectTimeout=5 "$LM" true 2>/dev/null; then
      break
    fi
  done
  ssh "$LM" "nproc; free -h | head -2"
fi

log "6) Preflight CHROMA-2"
ssh "$LM" "cd ${BRAIN} && bash scripts/verify-chroma2-persist.sh"

log "7) Restart papra-ingest (turbo drop-in)"
ssh "$LM" "sudo systemctl daemon-reload && sudo systemctl restart papra-ingest && sleep 3 && systemctl is-active papra-ingest"

log "8) Status"
ssh "$LM" "${INGEST}/venv/bin/python -c \"
import chromadb
c=chromadb.HttpClient(host='127.0.0.1', port=8002)
col=c.get_collection('documents')
print('chunk_count', col.count())
\""

log "=== STARTED — tail: ssh librarymaster journalctl -u papra-ingest -f ==="
log "Operator approval PAPRA-18 recorded 2026-06-14"
