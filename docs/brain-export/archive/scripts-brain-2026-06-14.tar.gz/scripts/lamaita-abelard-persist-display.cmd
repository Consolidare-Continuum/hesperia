@echo off
:: Re-apply display stack tweaks after GPU driver load (Intel may reset FeatureTestControl).
:: Abelard LAMAITA — run as SYSTEM at startup. 2026-03-24
reg add "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /t REG_DWORD /d 5 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000" /v FeatureTestControl /t REG_DWORD /d 0x1210 /f >nul 2>&1
exit /b 0
