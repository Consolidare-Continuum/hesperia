---
task_id: "P2|workflow-automation|orchestrator"
active_md_anchor: "| P2 | workflow-automation |"
---

# Script runbook — Workflow orchestrator (heartbeat)

**Purpose**: Usage, owner, triggers, and failure modes for the workflow orchestrator script. Hand off to Sophia for automation/deploy. Ref: [archive/governance-2026/WORKFLOW-AUTOMATION-DESIGN.md](../archive/governance-2026/WORKFLOW-AUTOMATION-DESIGN.md), [archive/governance-2026/WORKFLOW-AUTOMATION-ARCHITECTURE-TASK.md](../archive/governance-2026/WORKFLOW-AUTOMATION-ARCHITECTURE-TASK.md) §Phase 2 (Liam 2.3).

**Phase context (PICD)**: Workflow automation supports **P6 → P7** (Task division → Execution). It reads **active.md** (Grace’s output from P6) and drives the **current step** for leads (P7 Execution). Orchestrator emits heartbeat; driver writes `workflow_driver_current.txt`; executor runs server-side when owner=Abelard. Phase boundaries and full interface matrix: [governance/PHASE-INTERFACE-CONTROL-DOCUMENT.md](../governance/PHASE-INTERFACE-CONTROL-DOCUMENT.md).

---

## Script covered

| Script | Role | Owner |
|--------|------|--------|
| **workflow_orchestrator.py** | Read active.md and agents/grace/assignments.md; emit heartbeat (status report) to file and/or stdout. Includes OPEN/IN_PROGRESS/PAUSED/DONE counts and **Who is working (IN_PROGRESS)** rows (owner | project | task). Read-only; no credentials. | Gena (code); Liam (runbook); Sophia (automation/deploy); Abelard (deploy on prichindel). |
| **workflow_driver.py** | Trigger-after-result: read active.md; pick first OPEN task; write current step to governance/workflow_driver_current.txt; poll until row DONE/PAUSED or timeout; then next OPEN. Captain on deck → heartbeat only. Ref: §Workflow driver below. | Gena (code); Liam (runbook); Sophia (automation/deploy); Abelard (deploy on prichindel). |

---

## Usage

- **Default**: From repo root, `python3 scripts/workflow_orchestrator.py`. Writes heartbeat to `governance/workflow_heartbeat.txt`.
- **Print report**: `python3 scripts/workflow_orchestrator.py --stdout` (writes file and prints).
- **Custom output path**: `python3 scripts/workflow_orchestrator.py --output /path/to/heartbeat.txt`.
- **Repo root**: Script infers repo root as parent of `scripts/`. Override with env `WORKFLOW_REPO_ROOT=/path/to/repo`.

---

## Triggers

- **Current**: Manual (Cursor or operator runs from repo root). Optional: cron (e.g. hourly) or systemd timer — Abelard/Sophia per Invoke 2.4.
- **Future**: Triggers on "report done" or events TBD by Phase 1 proposals.

---

## Logging

- Script has no built-in log file. Stdout/stderr go to caller. Heartbeat output is the only persistent artifact (default `governance/workflow_heartbeat.txt`). If run from cron, redirect stdout/stderr in crontab or wrapper.

---

## Failure modes

| Failure | Symptom | Action |
|---------|---------|--------|
| active.md or agents/grace/assignments.md missing / unreadable | Script runs; counts or assignments empty. | Ensure repo path correct (WORKFLOW_REPO_ROOT or run from repo root). Check file permissions. |
| Output path not writable | Script exits with error. | Create governance/ or set --output to a writable path; check permissions. |
| Repo root wrong | Heartbeat shows zeros or wrong paths. | Set WORKFLOW_REPO_ROOT or run from repo root. |

---

## Infra and release (Sophia)

**Schedule decision**: Run **every half hour** via cron on prichindel from repo root: `*/30 * * * * /data/workspaces/cursor/scripts/workflow_automation_run.sh`. (Cron currently disabled 2026-02-15; no cloud.) **Cursor workflow automation** is split into chained scripts: entry point `workflow_automation_run.sh` → **step1** (`scripts/workflow/step1_orchestrator_driver.sh`: orchestrator then driver; addresses inbox/assignments and current task; invokes step2) → **step2** (`scripts/workflow/step2_executor.sh`: server executor only; no Cloud Agent; writes state and END). Logs: `governance/workflow_automation.log`, state: `governance/workflow_automation_state.txt`. **Manual start**: `./scripts/workflow_automation_manual_start.sh`. Ref: [cluster/workflow-automation/README.md](../cluster/workflow-automation/README.md).

**Infra duration**: Script run &lt;1 min per execution; no persistent process. Exporter (workflow-automation-exporter.service) runs continuously for Prometheus. Logging throughout; backup and surveillance: Abelard duty. See SURVEILLANCE.md §8.1, BACKUPS.md.

**Release notice**: Workflow orchestrator (Invoke 2.4) — new script `scripts/workflow_orchestrator.py`, heartbeat `governance/workflow_heartbeat.txt`. Deploy = cron or manual on prichindel. No change to headless container.

**Hand off to Abelard**: Deploy on prichindel: half-hourly cron (`scripts/workflow_automation_run.sh`), exporter service, Prometheus scrape config; ensure repo path and permissions allow write to `governance/`. Logging, backup, surveillance per [cluster/workflow-automation/README.md](../cluster/workflow-automation/README.md) and SURVEILLANCE.md §8.1. Canonical script names: [governance/WORKFLOW-SCRIPT-NAMES.md](../governance/WORKFLOW-SCRIPT-NAMES.md).

---

## Workflow API parity checklist (BF-011)

Compare live HTTP API at `:9096` against governance files. Run **monthly** or after any workflow API change.

| Check | HTTP (9096) | File (governance/) | Parity |
|-------|-------------|---------------------|--------|
| Heartbeat | `GET /workflow/heartbeat` → 200 JSON | `workflow_heartbeat.txt` (plain text) | ☐ Both reflect same OPEN/IN_PROGRESS/DONE counts |
| Current step | `GET /workflow/current_step` → 200 JSON | `workflow_driver_current.txt` (plain text) | ☐ Same task/owner/project; `has_step` matches file content |
| Report done | `POST /workflow/report_done` → 200 `ok:true` | `active.md` row status updated | ☐ Row status matches response; no duplicate audit lines |
| Auth (Bearer token) | `Authorization: Bearer <token>` required; 401 without | env `WORKFLOW_API_TOKEN` on prichindel | ☐ Token matches env; 401 returned when missing/invalid |
| Error codes | 400/401/404/409/500 per endpoint | `BACKEND-API-CONTRACT-PHASE2B.md` §Errors | ☐ All documented codes match actual API responses |

**Owner**: Olivia (contract parity); Sophia (infra/schedule).

---

## Handoff

- **Owner (automation / deploy)**: Sophia. Runbook handed off for schedule (cron/systemd), infra duration, and release notice per LOGS-AND-PATHS. Abelard performs deploy on prichindel (Invoke 2.4).
- **Runbook location**: This file. Referenced from [governance/WORKFLOW-AUTOMATION-ARCHITECTURE-TASK.md](../governance/WORKFLOW-AUTOMATION-ARCHITECTURE-TASK.md) §Phase 2.

---

## Phase 2b scripts (future)

When Phase 2b adds new workflow scripts (e.g. "report done" handler, assignment consumer, status API):

- **Same pattern**: One runbook entry per script: usage, owner, triggers (schedule or event), failure modes, log path. **Liam** provides runbook content; **Sophia** owns schedule, infra duration, release notice; **Abelard** performs deploy on prichindel.
- **Triggers**: Document trigger type (cron, event, webhook), source, and failure handling. Update this section or add a new runbook file per script.
- **Failure modes**: Input missing, output path not writable, wrong repo root, timeout, external call failure — document symptom and action per script.
- **Ref**: [governance/WORKFLOW-AUTOMATION-ARCHITECTURE-REPORT.md](../governance/WORKFLOW-AUTOMATION-ARCHITECTURE-REPORT.md) §3, §Phase 2b readiness.

---

## Phase 2b — MCP extensions and backend API (2026-03-07)

**Ref**: [governance/SPEC-ETHAN-PHASE2B-MCP-EXTENSIONS-AND-BACKEND-API.md](../governance/SPEC-ETHAN-PHASE2B-MCP-EXTENSIONS-AND-BACKEND-API.md), [governance/BACKEND-API-CONTRACT-PHASE2B.md](../governance/BACKEND-API-CONTRACT-PHASE2B.md).

| Component | Role | Owner |
|-----------|------|--------|
| **Approval write (cursor-approval-gates)** | MCP tools `request_approval(scope, reason)`, `record_approval(id, status)`; writes to `governance/approval_gates.json`. | Gena (code); Liam (runbook); Abelard (deploy MCP config). |
| **Task-report MCP** | `report_done(task_id, status)`, optional `get_task_row(task_id)`; writes STATUS to existing row in active.md. Extend cursor-pipeline-status or new MCP. | Gena (code); Liam (runbook); Abelard (deploy). |
| **Backend API** | GET /workflow/heartbeat, GET /workflow/current_step, POST /workflow/report_done. File-based; auth via env/mounted token. | Gena (code); Sophia (infra/logs/release); Liam (runbook); Abelard (deploy). |

**Triggers**: MCP = when Cursor (or agent) calls tools. Backend API = on demand (HTTP); same host as orchestrator or dedicated process; no cron for API itself.

**Failure modes**: (1) MCP: approval_gates.json or active.md not writable → tool returns error; check repo path and permissions. (2) API: auth missing/invalid → 401; task_id not found → 404; active.md write failure → 500; document in BACKEND-API-CONTRACT error codes. (3) Log path for API: per Sophia (e.g. `governance/workflow_api.log` or cluster/workflow-automation).

**Handoff Sophia**: Infra, logs, release ownership per BACKEND-API-CONTRACT-PHASE2B §Infra. Abelard deploys per runbook.

**Abelard deploy (Phase 2b)** — (1) **MCP**: No config change; cursor-pipeline-status and cursor-approval-gates already in [governance/mcp-config.json](../governance/mcp-config.json); new tools (report_done, get_task_row, request_approval, record_approval) run on prichindel when Cursor calls them. Ensure deploy script has been run on each Cursor client so mcp.json is current; restart Cursor. (2) **Workflow API**: On prichindel, optional systemd unit: `sudo cp cluster/workflow-automation/workflow-api.service /etc/systemd/system/`, `sudo systemctl daemon-reload`, `sudo systemctl enable --now workflow-api`. Log: `governance/workflow_api.log`. Port 9096 (127.0.0.1). Optional auth: set WORKFLOW_API_TOKEN in environment (see SECURITY-BASELINE). **Whole Cursor party**: prichindel = fixed host for MCP; any new MCP must align with existing (governance/MCP-COMPLIANCE-AND-OPERATIONAL.md §0.1).

---

## Phase 2b — Code plan (captain on deck, trigger-after-result)

**Ref**: [WORKFLOW-AUTOMATION-CODE-PLAN-TASK.md](../governance/WORKFLOW-AUTOMATION-CODE-PLAN-TASK.md). Flag: [governance/AUTOMATION-SCRIPTING-TEAM-POLICY.md](../governance/AUTOMATION-SCRIPTING-TEAM-POLICY.md) §8.1.

### Captain on deck check (all workflow scripts)

- **File**: `governance/captain_on_deck` (repo root relative). Content: one line `1` (captain on deck) or `0` (automation allowed). Absent or empty = automation allowed. Optional override: env `CAPTAIN_ON_DECK` for tests.
- **Behaviour**: Every workflow script (orchestrator, future driver) **checks at start**. If captain on deck = 1: do not run trigger chain or entity invocation; orchestrator still emits heartbeat (read-only awareness) with `captain_on_deck: true`. If 0 or unset: run normally.
- **Orchestrator**: Implemented in `workflow_orchestrator.py` — reads file at start; heartbeat always emitted; report includes `captain_on_deck: true|false`. No trigger chain yet; when added, skip when captain on deck.
- **Failure**: If file unreadable (perms), treat as 0 (allow automation). No credentials in file.

### Workflow driver (workflow_driver.py) — implemented

- **Usage**: From repo root. Checks captain_on_deck first; if 1 (or --heartbeat-only): runs orchestrator heartbeat only and exits.
  - `python3 scripts/workflow_driver.py` — semi-run: one step (write current, poll until result or timeout).
  - `python3 scripts/workflow_driver.py --max-steps N` — run up to N steps per run.
  - `python3 scripts/workflow_driver.py --no-wait` — write current step only (fire-and-forget); do not poll.
  - `python3 scripts/workflow_driver.py --heartbeat-only` — refresh heartbeat only.
- **Output**: `governance/workflow_driver_current.txt` — one line: priority | project | task (truncated) | owner | timestamp. Cursor/operator reads this to know which task to execute. The driver also writes `governance/workflow_context_current.md` — the **owner context passport** with the required named context, CSP block, source docs, and MCP/report_done requirements. Cursor-in-IDE must execute using that named context (Grace/Ethan/Gena/Felix/etc.) and must not flatten owner rows into generic Cursor. When no OPEN tasks: current-step file includes `# No OPEN tasks`, `last_run_iso`, `workflow_mode: autonomous_idle` and context passport says no owner context is active (see [cluster/workflow-automation/README.md](../cluster/workflow-automation/README.md) §Autonomous idle).
- **Result (report done)**: Driver polls active.md. Result = that row's status becomes DONE, PAUSED, or ARCHIVED (or row removed). Grace/Cursor updates active.md; driver detects and proceeds. No external API.
- **Timeout/retask**: Max wait per step = env `DRIVER_STEP_TIMEOUT_SEC` (default 300). Poll interval 30s. On timeout, driver exits; next run re-picks. PAUSED = treated as result (defer/retask).
- **Triggers**: Manual (Cursor/operator), cron (e.g. hourly), or Cursor. Schedule per Sophia. Same host as orchestrator (prichindel, repo root).
- **Failure modes**: Same as orchestrator (wrong repo root, missing active.md, unwritable governance/) plus: timeout waiting for step result → driver exits, next run continues; captain_on_deck file missing → treat as 0 (allow automation).

### Chained steps (Ethan 2026-02-15; agent loop removed 2026-02-15)

- **Entry**: `scripts/workflow_automation_run.sh` — sets env (REPO_ROOT, LOG_FILE, STATE_FILE, EXECUTOR, AGENT_LOOP, CHROMA_PYTHON), echoes START to log, invokes step1.
- **Step1** (`scripts/workflow/step1_orchestrator_driver.sh`): Runs orchestrator (heartbeat; addresses inbox/assignments) then driver (`--no-wait`; current task). On success, invokes step2.
- **Step2** (`scripts/workflow/step2_executor.sh`): Runs **server executor only**; logs if exit 2 (not handled on server). **Does not** invoke `cursor_agent_loop.py` (Cloud Agent out of scope). Writes state file and END to log. End of chain.
- **Inbox / invoke next**: Orchestrator and driver address inbox and current task; each step invokes the next when done.

### Server executor (abelard_executor.py) — Abelard scope only

- **Role**: Server-side on prichindel only. Reads `governance/workflow_driver_current.txt`; if owner = Abelard and task text matches a known action (e.g. "weekly maintenance", "run backup"), runs the script and marks the row DONE in active.md. Exit: 0 = handled, 2 = not handled, 1 = error. **Automation run is Cursor**; this script only handles the Abelard-task branch.
- **Integration**: **Cursor workflow automation** (entry → step1 → step2): step1 runs orchestrator then driver then invokes step2; step2 runs **server executor** (Abelard tasks only). Exit 2 = current step remains for **Cursor-in-IDE or manual**; no Cloud Agent invocation in `step2_executor.sh`. Ref: [cluster/workflow-automation/README.md](../cluster/workflow-automation/README.md).
- **Chroma**: Entry chain runs Chroma preflight before step1. IDE execution still uses MCP `query_knowledge` per policy; not the deprecated cloud agent path.
- **Manual start (test without cron)**: From repo root, `./scripts/workflow_automation_manual_start.sh` — one full run: orchestrator → driver → server executor. Use to verify heartbeat, `workflow_driver_current.txt` (task line or `autonomous_idle`), and Abelard handling.

### Cursor runs the workflow

- **From repo root (on prichindel or via SSH to prichindel)**: Run `bash scripts/workflow_automation_manual_start.sh` (or `./scripts/workflow_automation_manual_start.sh`). Cursor in IDE or an agent can run this when the workspace is the cursor repo on the server; from CERES, run the same command via SSH to prichindel. One full run: orchestrator → driver → server executor (Abelard tasks only). Non-Abelard or idle: read `governance/workflow_driver_current.txt` and proceed in IDE, or wait for Grace to add OPEN rows.
- **No OPEN tasks (autonomous idle)**: After the list is done, driver writes `workflow_mode: autonomous_idle` in `workflow_driver_current.txt`; heartbeat reflects zero OPEN. Next work: Grace triage → `active.md`. Ref: [team/Ethan/README.md](../../team/Ethan/README.md) §Autorun team workflow.
- **Historical — Cursor Cloud Agent**: `cluster/workflow-automation/cursor_agent_loop.py` is **deprecated** (product did not report back to repo). Step2 does **not** call it. Do not rely on `workflow_cursor_agent_skips.log` for current automation.

### See also — targeted team runbooks (repeat interfaces)

- [SCRIPT-RUNBOOK-grace-triage-active.md](SCRIPT-RUNBOOK-grace-triage-active.md) — Grace triage → `active.md` row (P6).
- [SCRIPT-RUNBOOK-report-done-workflow.md](SCRIPT-RUNBOOK-report-done-workflow.md) — `report_done` / workflow API (P7 closure).
- [SCRIPT-RUNBOOK-mcp-chroma-session.md](SCRIPT-RUNBOOK-mcp-chroma-session.md) — MCP deploy + Chroma session.
- [SCRIPT-RUNBOOK-approval-gate-destructive.md](SCRIPT-RUNBOOK-approval-gate-destructive.md) — approval gates before destructive work.
- [SCRIPT-RUNBOOK-operational-deliverables.md](SCRIPT-RUNBOOK-operational-deliverables.md) — `operational/` deliverable paths + pre-commit.
- [SCRIPT-RUNBOOK-captain-on-deck-workflow.md](SCRIPT-RUNBOOK-captain-on-deck-workflow.md) — captain on deck → manual workflow mode.
- [SCRIPT-RUNBOOK-escalate-grace.md](SCRIPT-RUNBOOK-escalate-grace.md) — single escalation path (task Grace).
- [SCRIPT-RUNBOOK-end-of-day-collect.md](SCRIPT-RUNBOOK-end-of-day-collect.md) — EOD collect-only snapshot.

### Handoff

- **Sophia**: Owns schedule and infra duration for driver. **Abelard**: Deploy on prichindel per this runbook; captain_on_deck file created by boss when needed.

---

## job_done_effect.py wiring (BF-034)

**Script**: `scripts/job_done_effect.py` — TV flash + Telegram notification on task completion.

**When to use**: After **report_done** completes successfully for a task. Optional; not required for workflow correctness.

**Avoid duplicates**: Do **not** call `job_done_effect.py` if workflow automation (cron/drain mode) is running — automation may complete multiple tasks in sequence; one notification per drain pass is sufficient, not per task.

| Scenario | Call job_done_effect? |
|----------|---------------------|
| Manual Cursor-in-IDE task completion | ✅ Yes (optional, operator preference) |
| Automation drain mode (multiple tasks) | ❌ No (avoid notification spam) |
| Automation once mode (single task) | ✅ Optional |
| Operator explicitly requests | ✅ Yes |

**Owner**: Liam (runbook); Sophia (schedule if automated).

---

## Proceed gates (preflight)

Before driving **Abelard** or **cluster/prod/services** rows, owners should pass **cluster preflight** per [SCRIPT-RUNBOOK-cluster-proceed-preflight.md](SCRIPT-RUNBOOK-cluster-proceed-preflight.md). Umbrella: [SCRIPT-RUNBOOK-workflow-proceed-gates.md](SCRIPT-RUNBOOK-workflow-proceed-gates.md). Driver writes [governance/workflow_context_current.md](../governance/workflow_context_current.md) with owner passport — read gate requirements there before execute.
