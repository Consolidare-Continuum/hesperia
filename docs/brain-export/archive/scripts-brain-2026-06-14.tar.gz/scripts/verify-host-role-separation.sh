#!/usr/bin/env bash
# Audit docs/registry for altitudine vs librarymaster separation. Exit 1 on drift.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO_ROOT"
FAIL=0

check() {
  if eval "$2" >/dev/null 2>&1; then
    echo "PASS: $1"
  else
    echo "FAIL: $1" >&2
    FAIL=1
  fi
}

REG="$REPO_ROOT/cluster/CLUSTER-HOST-REGISTRY.md"
GOV="$REPO_ROOT/governance/HOST-ALTITUDINE-VS-LIBRARYMASTER.md"

check "governance separation doc exists" "test -f '$GOV'"
check "altitudine README exists" "test -f cluster/altitudine/README.md"
check "librarymaster lists Tailscale 100.89.236.59" "grep -q '100.89.236.59' cluster/librarymaster/README.md || grep -q '100.89.236.59' '$REG'"
check "registry: librarymaster has 100.89.236.59" "grep 'librarymaster' '$REG' | grep -q '100.89.236.59'"
check "registry: altitudine row documents IP is not on altitudine" "grep '| \*\*altitudine\*\*' '$REG' | grep -q 'not .100.89.236.59'"
check "detector knows librarymaster" "grep -q librarymaster scripts/detect-cursor-session-mode.sh"
check "detector knows altitudine VM" "grep -q 'dev_vm_ulim' scripts/detect-cursor-session-mode.sh"
check "session rule links separation doc" "grep -q HOST-ALTITUDINE-VS-LIBRARYMASTER .cursor/rules/cursor-session-mode.mdc"

if [[ $FAIL -eq 0 ]]; then
  echo "OK: host-role separation checks passed"
else
  echo "BLOCKED: fix registry/docs per $GOV" >&2
  exit 1
fi
