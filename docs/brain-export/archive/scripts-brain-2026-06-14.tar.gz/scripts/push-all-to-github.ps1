# Push all local changes to GitHub. Run from repo root.
# If you see "index.lock" error: close Cursor Source Control panel and any other app using the repo, then re-run.

$repo = "C:\Users\Olga\Proton Drive\igareosh\Other computers\CERES\ceres_proton_drive\cursor"
$lock = Join-Path $repo ".git\index.lock"

if (Test-Path $lock) {
    Remove-Item $lock -Force -ErrorAction SilentlyContinue
    if (Test-Path $lock) {
        Write-Warning "index.lock still exists — close Cursor Source Control and any git UI, then re-run this script."
        exit 1
    }
}

Set-Location $repo
git add -A
git status -s
$count = (git status -s | Measure-Object -Line).Lines
if ($count -eq 0) {
    Write-Host "Nothing to commit."
    exit 0
}
git commit -m "Sync all: brain repo, cluster, scripts, CLIENTS, biopole removal"
git push origin main
Write-Host "Done."
