#!/usr/bin/env bash
# Cutover cloudmaster VM 110 from migration IP (.72) to production IP (.40).
# Run on alunel after ownCloud data migrated and physical fulgusor powered off.
set -euo pipefail

VMID=110
OLD_IP=192.168.100.72
NEW_IP=192.168.100.40

log() { echo "[cloudmaster-cutover] $*"; }

preflight() {
  log "Confirm physical fulgusor is down (no ARP on .40)"
  if ping -c1 -W2 "$NEW_IP" &>/dev/null; then
    log "ERROR: $NEW_IP still responds — power off physical fulgusor first"
    exit 1
  fi
}

reip_vm() {
  log "Stopping VM $VMID, updating cloud-init IP to $NEW_IP"
  sudo qm stop "$VMID"
  sudo qm set "$VMID" --ipconfig0 "ip=${NEW_IP}/24,gw=192.168.100.1"
  sudo qm cloudinit update "$VMID"
  sudo qm start "$VMID"
  log "Waiting for $NEW_IP..."
  for i in $(seq 1 30); do
    if ping -c1 -W1 "$NEW_IP" &>/dev/null; then
      log "VM reachable at $NEW_IP"
      return 0
    fi
    sleep 5
  done
  log "WARN: $NEW_IP not pingable yet"
}

verify_owncloud() {
  ssh -o BatchMode=yes -o ConnectTimeout=10 "igareosh@${NEW_IP}" \
    'sudo -u www-data php7.4 /var/www/owncloud/occ status 2>/dev/null; curl -sk -o /dev/null -w "%{http_code}\n" -H "Host: cloud.prichindel.com" https://127.0.0.1/ 2>/dev/null || curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1/'
}

main() {
  preflight
  reip_vm
  verify_owncloud
  log "DONE — cloudmaster now on $NEW_IP. Update dnsmaster rewrite fulgusor -> $NEW_IP if needed."
}

main "$@"
