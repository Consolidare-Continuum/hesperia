#!/usr/bin/env bash
# Merge cluster agent SSH CA block into ~/.ssh/config (idempotent).
# Run as igareosh on alunel after agent-ssh-ca-init.sh.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
FRAGMENT="$REPO_ROOT/cluster/agent-ssh/ssh-config-agent-ca.fragment"
MARKER="Cluster agent identity — cert-based"
SSH_CONFIG="${HOME}/.ssh/config"
BEGIN="# BEGIN cluster agent SSH CA"
END="# END cluster agent SSH CA"

mkdir -p "${HOME}/.ssh"
chmod 700 "${HOME}/.ssh"

if [ ! -f "$FRAGMENT" ]; then
    echo "ERROR: missing $FRAGMENT" >&2
    exit 1
fi
if [ ! -f "${HOME}/.ssh/agent-ca/id_agent-cert.pub" ]; then
    echo "ERROR: cert missing — run agent-ssh-ca-init.sh first." >&2
    exit 1
fi

TMP="$(mktemp)"
if [ -f "$SSH_CONFIG" ]; then
    awk -v b="$BEGIN" -v e="$END" '
        $0 == b { skip=1; next }
        $0 == e { skip=0; next }
        !skip { print }
    ' "$SSH_CONFIG" >"$TMP" || cp "$SSH_CONFIG" "$TMP"
else
    : >"$TMP"
fi
{
    echo "$BEGIN"
    cat "$FRAGMENT"
    echo "$END"
} >>"$TMP"
mv "$TMP" "$SSH_CONFIG"
chmod 600 "$SSH_CONFIG"
echo "OK: merged agent SSH CA block into $SSH_CONFIG"
