#!/usr/bin/env bash
# Write CHROMA-2 collection sidecar (schema §14) — PAPRA-32
set -euo pipefail
META_DIR=/data/chroma-2/meta
META_FILE="${META_DIR}/collection.json"
VENV="${CHROMA2_VENV:-/data/chroma-2/venv}"
sudo mkdir -p "$META_DIR"
"$VENV/bin/python" <<'PY' | sudo tee "$META_FILE" >/dev/null
import json, time, uuid, chromadb
c = chromadb.HttpClient(host="127.0.0.1", port=8002)
col = c.get_collection("documents")
n = col.count()
# unique doc_ids from sample scan
seen = set()
offset = 0
while len(seen) < 2000:
    part = col.get(limit=500, offset=offset, include=["metadatas"])
    ids = part.get("ids") or []
    if not ids:
        break
    for m in part.get("metadatas") or []:
        if m and m.get("doc_id"):
            seen.add(m["doc_id"])
    offset += len(ids)
    if len(ids) < 500:
        break
out = {
    "embedding_model": "paraphrase-multilingual-mpnet-base-v2",
    "chunker_version": "papra-v1-char500",
    "schema_version": "1",
    "ingest_run_id": str(uuid.uuid4()),
    "document_count": len(seen),
    "chunk_count": n,
    "updated_ts": int(time.time()),
}
print(json.dumps(out, indent=2))
PY
echo "Wrote ${META_FILE}"
cat "$META_FILE"
