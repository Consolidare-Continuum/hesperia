# Run fluturas-sshd-full-fix.ps1 as Administrator. No prompt if already admin.
$ErrorActionPreference = 'Stop'
$script = Join-Path (Split-Path $MyInvocation.MyCommand.Path) 'fluturas-sshd-full-fix.ps1'
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($isAdmin) {
    & $script
    exit $LASTEXITCODE
}
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = 'powershell.exe'
$psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$script`""
$psi.Verb = 'RunAs'
$psi.UseShellExecute = $true
$psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
$p = [System.Diagnostics.Process]::Start($psi)
$p.WaitForExit(120000)
exit $p.ExitCode
