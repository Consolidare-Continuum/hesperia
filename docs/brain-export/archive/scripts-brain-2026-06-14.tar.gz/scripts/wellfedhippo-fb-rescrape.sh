#!/usr/bin/env bash
# Force Facebook to rescrape a wellfedhippo.com URL (Open Graph cache refresh).
# Requires Meta app or user access token with pages_read_engagement or general app use.
#
# Usage:
#   export FB_ACCESS_TOKEN='your-token'
#   bash scripts/wellfedhippo-fb-rescrape.sh 'https://www.wellfedhippo.com/?p=732'
#
# Or one-liner (token from Meta Graph API Explorer / your app):
#   curl -s -X POST "https://graph.facebook.com/v21.0/?id=$(python3 -c 'import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=\"\"))' "$URL")&scrape=true&access_token=$FB_ACCESS_TOKEN"
#
# UI (no token): https://developers.facebook.com/tools/debug/?q=URL → "Scrape Again"
set -euo pipefail

URL="${1:-https://www.wellfedhippo.com/?p=732}"
TOKEN="${FB_ACCESS_TOKEN:-${FACEBOOK_ACCESS_TOKEN:-}}"

if [ -z "$TOKEN" ]; then
  echo "BLOCKED: set FB_ACCESS_TOKEN (Meta app or user token)."
  echo "Debugger: https://developers.facebook.com/tools/debug/?q=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote('$URL', safe=''))")"
  exit 1
fi

ENC=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$URL")
RESP=$(curl -s -X POST "https://graph.facebook.com/v21.0/?id=${ENC}&scrape=true&access_token=${TOKEN}")
echo "$RESP" | python3 -m json.tool 2>/dev/null || echo "$RESP"

if echo "$RESP" | grep -q '"og_object"'; then
  echo "OK: scrape completed for $URL"
  echo "$RESP" | python3 -c "
import json,sys
d=json.load(sys.stdin)
og=d.get('og_object',{})
print('title:', og.get('title','?'))
for img in (og.get('image') or []):
    if isinstance(img, dict): print('image:', img.get('url'))
    else: print('image:', img)
" 2>/dev/null || true
else
  echo "Check response above for errors."
  exit 1
fi
