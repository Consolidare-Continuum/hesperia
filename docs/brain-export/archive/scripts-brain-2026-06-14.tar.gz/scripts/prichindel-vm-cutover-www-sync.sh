#!/usr/bin/env bash
# Final www + small /data sync physical → VM before cutover. Run on alunel.
set -euo pipefail
PHYS="${PHYS:-192.168.100.21}"
VM="${VM:-192.168.100.121}"
log() { echo "[cutover-sync $(date +%H:%M:%S)] $*"; }

tar_sync() {
  local src_path="$1" dest_parent="$2"
  log "tar $src_path → VM:$dest_parent"
  ssh -o BatchMode=yes "igareosh@${PHYS}" "sudo tar czf - -C ${src_path%/*} ${src_path##*/}" \
    | ssh -o BatchMode=yes "igareosh@${VM}" "sudo tar xzf - -C ${dest_parent}"
}

log "PHYS=$PHYS VM=$VM"
tar_sync /var/www/hesperia-sites /var/www
tar_sync /var/www/tersagor /var/www
tar_sync /var/www/html/navisdei /var/www/html
ssh -o BatchMode=yes "igareosh@${PHYS}" "sudo tar czf - -C /var/www/html bulk-upload.html papra-dedup-upload.js .well-known 2>/dev/null" \
  | ssh -o BatchMode=yes "igareosh@${VM}" "sudo tar xzf - -C /var/www/html" || true
tar_sync /data/tersagor /data
log "DONE www cutover sync"
