---
task_id: "miniflux|authentik|invited_user|mesager"
active_md_anchor: "| operations | miniflux |"
---

# Script runbook — Add Miniflux user via Authentik `invited_user` (Mesager-only scope)

**Purpose**: Provision a new user for Mesager/Miniflux with Authentik login, restrict app visibility to Mesager scope, and validate API readiness.  
**Operator**: Abelard (operational execution).  
**Stack**: Authentik on trustmaster + Miniflux/Postgres on altitudine.

---

## When to use

- A new external user must access `https://mesager.prichindel.com` via Authentik OIDC.
- User must be limited to Mesager flow (no non-Mesager app access).
- API access is required for AI/automation (`X-Auth-Token`).

---

## Preconditions

1. Mesager endpoint healthy:
   - `curl -sf https://mesager.prichindel.com/healthcheck`
2. Miniflux containers healthy on altitudine:
   - `docker ps --filter name=altitudine_miniflux --filter name=altitudine_miniflux_db`
3. Authentik reachable on trustmaster:
   - `curl -sf -o /dev/null -w "%{http_code}\n" "https://trustmaster.prichindel.com/application/o/miniflux-altitudine/.well-known/openid-configuration"` (expect `200`)

---

## Procedure

### 1) Create/prepare user in Authentik and assign `invited_user`

On trustmaster (`docker exec authentik-server-1 /manage.py shell`):

- Ensure Authentik user exists (username like `dima.s`, with real email).
- Ensure group `invited_user` exists.
- Add user to `invited_user`.

### 2) Enforce Mesager-only scope with deny policy on non-Mesager apps

Use expression policy:

```python
return not request.user.groups.filter(name="invited_user").exists()
```

Policy target model: applications.

Rules:
- Bind policy to all non-Mesager applications.
- Do **not** bind this policy to Mesager OAuth app (`client_id` of Mesager provider).
- Verify:
  - deny binding on Mesager app = `0`
  - deny bindings on non-Mesager apps > `0`

Reference Mesager OAuth client_id used in production:
- `yuDpYAtxxEmdTi4IdRXwoy7fzFnQsLnmq26HvH1L`

### 3) First user login (materialize OIDC identity in Miniflux)

User flow:
1. Open `https://mesager.prichindel.com`
2. Authentik login
3. Open Mesager app
4. Complete OpenID auth

Result expected:
- Miniflux user is created/linked with non-empty `openid_connect_id`.

### 4) Validate/fix OIDC mapping in Miniflux

On altitudine (Postgres):

- Inspect users:
  - `SELECT id, username, openid_connect_id FROM users ORDER BY id;`
- Ensure Authentik subject (`uid`) is linked to the intended account.
- If mapped to wrong account, rebind:
  - clear wrong account `openid_connect_id`
  - set correct account `username` + `openid_connect_id`

### 5) API key setup and test

- Create permanent API key for final account.
- Test endpoints with `X-Auth-Token`:
  - `GET /v1/me` -> `200`
  - `GET /v1/entries?status=unread&direction=desc&limit=5` -> `200`
  - `GET /v1/feeds` -> `200`
  - `PUT /v1/feeds/refresh` -> `204`

### 6) Optional data migration (seeded -> final OIDC account)

If a seeded account exists (e.g., `dima.s-seeded`):
- copy feeds by `feed_url` mapping,
- copy entries by `(user_id, feed_id, hash)` dedupe,
- verify counts (`feeds`, `entries`, `unread`) on final account.

---

## Verification checklist (must pass)

- [ ] Authentik user is in `invited_user`.
- [ ] Mesager OAuth app is not blocked by deny policy.
- [ ] Non-Mesager apps are blocked for `invited_user`.
- [ ] Miniflux final username + `openid_connect_id` alignment is correct.
- [ ] Permanent API key exists for final account.
- [ ] API endpoint tests return expected status codes.

---

## Failure modes

| Symptom | Cause | Fix |
|---|---|---|
| Authentik “Access denied” on authorize | deny policy bound to Mesager app | remove binding from exact Mesager OAuth app by `client_id` |
| Miniflux login lands on wrong user | OIDC UID linked to wrong account | rebind `openid_connect_id` to intended account |
| API 401 with key | wrong user/key or stale token | recreate key on final account and retest |
| User sees many apps in Authentik | missing non-Mesager deny bindings | reapply policy binding loop on non-Mesager apps |

---

## Chat-derived walls (must not repeat)

These are concrete failures hit during the 2026-05-28 execution and are now mandatory guardrails.

1. **Wrong Mesager app target in Authentik**
   - Wall: deny policy was removed from slug `mesager`, but active OAuth app for authorize URL was `miniflux-altitudine`.
   - Guardrail: identify Mesager app by OAuth `client_id` first, then bind/unbind policy on that resolved app object only.

2. **Expression policy runtime exceptions**
   - Wall: `ak_is_group_member` failed (`AttributeError`) and malformed quoting produced `NameError`.
   - Guardrail: only use expression:
     - `return not request.user.groups.filter(name="invited_user").exists()`
   - Validate by triggering authorize once and checking no `policy_exception` events.

3. **Incorrect OIDC subject mapping in Miniflux**
   - Wall: Authentik user `dima.s` UID was linked to Miniflux `miniflux` account, not target user.
   - Guardrail: after first login always compare:
     - Authentik `uid`
     - Miniflux `users.openid_connect_id`
   - If mismatch, rebind before issuing permanent key.

4. **Assuming OIDC user exists before first callback**
   - Wall: expected `dima.s` in Miniflux before first successful OIDC callback.
   - Guardrail: treat “first OIDC login” as mandatory materialization step; do not start final migration/key issuance before this.

5. **Policy-binding creation pitfalls**
   - Wall: binding writes failed when required relation fields were not set in custom scripts.
   - Guardrail: use stable create/get-or-create path with explicit defaults for policy bindings; verify binding counts after write.

6. **SSH access wall during ops window**
   - Wall: SSH cert path/session mismatch blocked trustmaster access (`Permission denied (publickey)`), stalling identity fixes.
   - Guardrail: before Authentik ops, verify reachable trust path and working key; if CA cert is stale, use known-good cluster key path or renew CA cert first.

Mandatory pre-flight for this runbook (in addition to Preconditions):

- [ ] Mesager OAuth app resolved by `client_id` and recorded.
- [ ] Authentik expression policy string exactly matches approved expression.
- [ ] Authentik `uid` for target user captured before Miniflux mapping.
- [ ] Miniflux `openid_connect_id` verified after first login callback.
- [ ] Trustmaster SSH path validated before policy/mapping operations.

---

## Output artifact

Record operations in:
- `operational/assignments/reports/MINIFLUX-<USER>-API-CHECK-YYYY-MM-DD.md`

Include:
- user IDs and mapping state,
- API test status codes,
- final permanent key description (token value only in controlled channel).

SIGNED: DevOps (Abelard) | mesager/miniflux authentik onboarding | 2026-05-28 | SCRIPT-RUNBOOK
