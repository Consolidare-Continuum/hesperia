# Disable NetBIOS on all IP-enabled adapters (stops NetBT transport bind errors).
# Run as Administrator. See cluster/olgahere/MAINTENANCE-REPORT-2026-02-07.md.

$ErrorActionPreference = 'Stop'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run as Administrator."
    exit 1
}
Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled } | ForEach-Object {
    $r = $_.SetTcpipNetbios(2)
    if ($r.ReturnValue -eq 0) { Write-Host "NetBIOS disabled on: $($_.Description)" } else { Write-Host "Failed ($($r.ReturnValue)): $($_.Description)" }
}
Write-Host "Done. Reboot optional; NetBT bind errors should stop."
exit 0
