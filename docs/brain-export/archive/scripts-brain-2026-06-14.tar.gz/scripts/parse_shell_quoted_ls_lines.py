#!/usr/bin/env python3
"""Read lines from ls that are one shell-quoted path per line; print bare filenames."""
import shlex
import sys


def main() -> None:
    for line in sys.stdin:
        s = line.strip()
        if not s or "igareosh@" in s or s in ("ls", "$"):
            continue
        if not (s.startswith("'") or s.startswith('"')):
            continue
        try:
            parts = shlex.split(s)
        except ValueError:
            continue
        for p in parts:
            print(p.replace("&amp;", "&"))


if __name__ == "__main__":
    main()
