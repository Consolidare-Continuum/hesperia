#!/usr/bin/env bash
# Patch AdGuard rewrites on dnsmaster — never overwrite full AdGuardHome.yaml from repo.
# Repo cluster/dnsmaster/AdGuardHome.yaml is a template (placeholder password); live config is authoritative.
set -euo pipefail

# Reach dnsmaster: direct `ssh dnsmaster`, or via prichindel (librarymaster and some agents).
DNSMASTER_SSH="${DNSMASTER_SSH:-}"
if [[ -z "$DNSMASTER_SSH" ]]; then
  if ssh -o BatchMode=yes -o ConnectTimeout=4 dnsmaster true 2>/dev/null; then
    DNSMASTER_SSH="ssh dnsmaster"
  elif ssh -o BatchMode=yes -o ConnectTimeout=6 prichindel \
    "ssh -o BatchMode=yes -o ConnectTimeout=4 igareosh@192.168.100.25 true" 2>/dev/null; then
    DNSMASTER_SSH='ssh prichindel "ssh -o BatchMode=yes igareosh@192.168.100.25"'
  else
    echo "BLOCKED: cannot reach dnsmaster (192.168.100.25) — fix SSH from this host or set DNSMASTER_SSH" >&2
    exit 1
  fi
fi

$DNSMASTER_SSH 'sudo python3 -' "$@" <<'PY'
import sys
import yaml

path = "/opt/AdGuardHome/AdGuardHome.yaml"
additions = []
for arg in sys.argv[1:]:
    domain, answer = arg.split("=", 1)
    additions.append((domain.strip(), answer.strip()))

with open(path) as f:
    cfg = yaml.safe_load(f)
rewrites = cfg.setdefault("filtering", {}).setdefault("rewrites", [])

for domain, answer in additions:
    for r in rewrites:
        if r.get("domain") == domain:
            r["answer"] = answer
            r["enabled"] = True
            break
    else:
        rewrites.append({"domain": domain, "answer": answer, "enabled": True})

with open(path, "w") as f:
    yaml.safe_dump(cfg, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
PY

$DNSMASTER_SSH 'sudo systemctl restart AdGuardHome && sleep 2 && systemctl is-active AdGuardHome'
echo "DONE. Patched rewrites: $*"
