#!/usr/bin/env python3
"""Mirror UAIC Baze de Date (RO) course site into user_documents/."""

from __future__ import annotations

import json
import re
import shutil
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path

BASE = "https://edu.info.uaic.ro/baze-de-date/ro/"
REPO_ROOT = Path(__file__).resolve().parents[1]
OUT = REPO_ROOT / "user_documents" / "uaic_baze_de_date_ro"

LAB_SLUGS = [
    "instalare",
    "sql_plus",
    "lab1",
    "lab2",
    "lab3",
    "lab4",
    "lab5",
    "lab6",
    "lab7",
    "lab8",
    "lab9",
    "lab10",
    "lab11",
    "lab12",
    "lab13",
    "lab14",
]

STATIC_PATHS = [
    "index.html",
    "stil.css",
    "imagini/BD.png",
]


class LinkExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.hrefs: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "a":
            return
        for name, value in attrs:
            if name == "href" and value:
                self.hrefs.append(value)


def quote_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    path = urllib.parse.quote(parsed.path, safe="/%")
    return urllib.parse.urlunparse(
        (parsed.scheme, parsed.netloc, path, parsed.params, parsed.query, parsed.fragment)
    )


def fetch(url: str) -> bytes:
    url = quote_url(url)
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "prichindel-scraper/1.0 (local study mirror)"},
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return resp.read()


def save_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def save_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def resolve_url(href: str, page_url: str) -> str | None:
    href = href.strip()
    if not href or href.startswith("#") or href.startswith("javascript:"):
        return None
    if href.startswith("http://") or href.startswith("https://"):
        parsed = urllib.parse.urlparse(href)
        if "edu.info.uaic.ro" not in parsed.netloc:
            return None
        return href
    return urllib.parse.urljoin(page_url, href)


def local_path_for_url(url: str) -> Path:
    parsed = urllib.parse.urlparse(url)
    path = parsed.path
    prefix = "/baze-de-date/ro/"
    if path.startswith(prefix):
        rel = path[len(prefix) :]
    elif path.startswith("/baze-de-date/documente/"):
        rel = "documente/" + path.split("/documente/", 1)[1]
    else:
        rel = path.lstrip("/")
    return OUT / rel


def download_url(url: str, manifest: list[dict]) -> None:
    local = local_path_for_url(url)
    if local.exists() and local.stat().st_size > 0:
        manifest.append(
            {"url": url, "path": str(local.relative_to(REPO_ROOT)), "status": "cached"}
        )
        return
    try:
        data = fetch(url)
    except (urllib.error.HTTPError, urllib.error.URLError) as exc:
        manifest.append(
            {
                "url": url,
                "path": str(local.relative_to(REPO_ROOT)),
                "status": f"error:{getattr(exc, 'code', exc)}",
            }
        )
        return
    save_bytes(local, data)
    manifest.append(
        {
            "url": url,
            "path": str(local.relative_to(REPO_ROOT)),
            "status": "ok",
            "bytes": len(data),
        }
    )


def strip_tags(html: str) -> str:
    text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def build_index_md(manifest: list[dict], lab_entries: list[dict]) -> str:
    docs = sorted(
        (m for m in manifest if "/documente/" in m["url"] and m.get("status") == "ok"),
        key=lambda m: m["path"],
    )
    lines = [
        "# UAIC — Baze de date (RO) — local mirror",
        "",
        f"**Source:** [{BASE}]({BASE})",
        f"**Scraped:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        "",
        "## Curs (documente)",
        "",
    ]
    for item in docs:
        name = Path(item["path"]).name
        lines.append(f"- [{name}]({item['path']})")
    lines.extend(["", "## Laborator (HTML)", ""])
    for lab in lab_entries:
        lines.append(f"- [{lab['title']}]({lab['path']})")
    lines.extend(
        [
            "",
            "## Site shell",
            "",
            f"- [index.html]({OUT.relative_to(REPO_ROOT)}/index.html)",
            f"- [stil.css]({OUT.relative_to(REPO_ROOT)}/stil.css)",
            "",
            "Full download log: `manifest.json`.",
        ]
    )
    return "\n".join(lines) + "\n"


def parse_laboratoare_to_markdown() -> None:
    try:
        import html2text
    except ImportError:
        print("skip parse: html2text not installed")
        return
    h = html2text.HTML2Text()
    h.ignore_links = False
    h.body_width = 0
    parsed_dir = OUT / "parsed" / "laboratoare"
    parsed_dir.mkdir(parents=True, exist_ok=True)
    for html_path in sorted((OUT / "laboratoare").glob("*.html")):
        md_path = parsed_dir / f"{html_path.stem}.md"
        md_path.write_text(
            f"# {html_path.stem}\n\n"
            f"**Source:** `{html_path.relative_to(REPO_ROOT)}`\n\n"
            + h.handle(html_path.read_text(encoding="utf-8", errors="replace")),
            encoding="utf-8",
        )
    index_html = (OUT / "index.html").read_text(encoding="utf-8", errors="replace")
    for section_id in ("paginaprincipala", "curs", "regulament", "cine"):
        m = re.search(
            rf'<div id="{section_id}"[^>]*>(.*?)</div>\s*(?:<!--|<div id=)',
            index_html,
            re.DOTALL | re.IGNORECASE,
        )
        if m:
            (OUT / "parsed" / f"{section_id}.md").write_text(
                f"# {section_id}\n\n" + h.handle(m.group(1)),
                encoding="utf-8",
            )


def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)

    manifest: list[dict] = []
    index_url = urllib.parse.urljoin(BASE, "index.html")

    for rel in STATIC_PATHS:
        download_url(urllib.parse.urljoin(BASE, rel), manifest)

    index_html = (OUT / "index.html").read_text(encoding="utf-8", errors="replace")
    parser = LinkExtractor()
    parser.feed(index_html)
    doc_urls: set[str] = set()
    for href in parser.hrefs:
        resolved = resolve_url(href, index_url)
        if not resolved:
            continue
        if "/documente/" in resolved or resolved.endswith(".sql") or resolved.endswith(".pdf"):
            doc_urls.add(resolved)

    for url in sorted(doc_urls):
        download_url(url, manifest)

    lab_entries: list[dict] = []
    for slug in LAB_SLUGS:
        url = urllib.parse.urljoin(BASE, f"laboratoare/{slug}.html")
        download_url(url, manifest)
        local = OUT / "laboratoare" / f"{slug}.html"
        title = slug
        if local.exists():
            html = local.read_text(encoding="utf-8", errors="replace")
            m = re.search(r"<h[12][^>]*>(.*?)</h[12]>", html, re.IGNORECASE | re.DOTALL)
            if m:
                title = strip_tags(m.group(1))[:120] or slug
        lab_entries.append(
            {
                "slug": slug,
                "title": title,
                "path": str(local.relative_to(REPO_ROOT)),
                "url": url,
            }
        )

    save_text(
        OUT / "manifest.json",
        json.dumps(
            {
                "source": BASE,
                "scraped_at": datetime.now(timezone.utc).isoformat(),
                "downloads": manifest,
                "laboratoare": lab_entries,
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
    )
    save_text(OUT / "INDEX.md", build_index_md(manifest, lab_entries))
    parse_laboratoare_to_markdown()

    ok = sum(1 for m in manifest if m.get("status") == "ok")
    cached = sum(1 for m in manifest if m.get("status") == "cached")
    err = [m for m in manifest if str(m.get("status", "")).startswith("error")]
    print(f"OUT={OUT}")
    print(f"ok={ok} cached={cached} errors={len(err)}")
    for e in err:
        print(f"  FAIL {e['url']} -> {e.get('status')}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--parse-only":
        parse_laboratoare_to_markdown()
        print(f"parsed -> {OUT / 'parsed'}")
    else:
        main()
