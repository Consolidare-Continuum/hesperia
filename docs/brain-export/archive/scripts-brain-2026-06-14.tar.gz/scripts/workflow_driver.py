#!/usr/bin/env python3
# Copyright (c) prichindel.com. All rights reserved.
"""
Workflow driver — trigger-after-result (Phase 2b).

Reads active.md; picks first OPEN task; writes current step to governance/workflow_driver_current.txt;
polls until that row is DONE (or PAUSED) or timeout. Then next OPEN. Captain on deck: if no OPEN
tasks, heartbeat only (no trigger chain). If any OPEN task ("task behind"), still write current step
and exit so step2 runs (start invocations in auto). No credentials; repo + file only.
Phase context: supports P6→P7 (Task division → Execution) per governance/PHASE-INTERFACE-CONTROL-DOCUMENT.md.
Ref: governance/WORKFLOW-AUTOMATION-CODE-PLAN-TASK.md §7.3, scripts/SCRIPT-RUNBOOK-workflow-orchestrator.md §Phase 2b.

Usage:
  workflow_driver.py              # one step: write current, then poll until result or timeout
  workflow_driver.py --max-steps N   # run up to N steps (default 1 for semi-run)
  workflow_driver.py --no-wait       # write current step only; do not poll (fire-and-forget)
  workflow_driver.py --heartbeat-only  # run orchestrator heartbeat only (same as captain on deck)

Env: WORKFLOW_REPO_ROOT, CAPTAIN_ON_DECK (override file), DRIVER_STEP_TIMEOUT_SEC (default 300),
     WORKFLOW_DRIVER_PROJECT (optional: only OPEN rows whose Project column matches, case-insensitive — e.g. im-irc ahead of global P1 queue).
     WORKFLOW_DRIVER_CLAIM_IN_PROGRESS=1 — when picking the current step, set the matching active.md row from OPEN to IN_PROGRESS; any other IN_PROGRESS row in the same Project column reverts to OPEN (single “current” claim per project). While CLAIM is on, the driver **sticks** to an existing same-project IN_PROGRESS row until DONE/PAUSED/ARCHIVED (so the first OPEN in that project is not alternated with the claimed row on every pass).
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

OWNER_CONTEXTS = {
    "cursor": {
        "to": "Cursor (repo/team assistant)",
        "authority": "orchestration, repo brain, workflow execution as assigned owner",
        "docs": ["AGENTS.md", ".cursor/rules/cursor-main-awareness.mdc", ".cursor/rules/cursor-agent-quality-floor.mdc"],
        "invoke": "Cursor, execute the current workflow task.",
    },
    "abelard": {
        "to": "Abelard (DevOps/sysadmin officer, cluster infra)",
        "authority": "cluster infra, services, maintenance, backup, deploy; no code/API ownership",
        "docs": ["AGENTS.md", ".cursor/rules/abelard-cluster.mdc", "agents/abelard/ABELARD_QUICK_OPS.md", "agents/abelard/ABELARD.md"],
        "invoke": "Abelard, execute the current workflow task.",
    },
    "gena": {
        "to": "Gena (main developer, code/API/Java)",
        "authority": "code, APIs, Java/JS/TS, clients when assigned; infra goes to Abelard",
        "docs": ["AGENTS.md", ".cursor/rules/gena-developer.mdc", "agents/gena/GENA.md"],
        "invoke": "Gena, execute the current workflow task.",
    },
    "felix": {
        "to": "Felix (developer, Python/TS/scripts, Hesperia primary)",
        "authority": "Python/TS/scripts/Hesperia; infra goes to Abelard; Java-heavy goes to Gena",
        "docs": ["AGENTS.md", ".cursor/rules/felix-developer.mdc", "agents/felix/FELIX.md"],
        "invoke": "Felix, execute the current workflow task.",
    },
    "grace": {
        "to": "Grace (triage and operational task routing)",
        "authority": "triage, active.md routing, task division, release checklist triggers",
        "docs": ["AGENTS.md", "team/Grace/README.md", "agents/grace/README.md", "scripts/SCRIPT-RUNBOOK-grace-triage-active.md"],
        "invoke": "Grace, execute the current workflow task.",
    },
    "ethan": {
        "to": "Ethan (architecture/team lead authority)",
        "authority": "architecture, WBS approval, integration freeze, technical governance",
        "docs": ["AGENTS.md", "team/Ethan/README.md", "OPERATIONAL-LAYER.md", "ROLE-RESOLUTIONS.md"],
        "invoke": "Ethan, execute the current workflow task.",
    },
    "olivia": {
        "to": "Olivia (backend lead)",
        "authority": "backend implementation, backend tests, API acceptance after gates are ready",
        "docs": ["AGENTS.md", "team/Olivia/README.md", "ROLE-RESOLUTIONS.md"],
        "invoke": "Olivia, execute the current workflow task.",
    },
    "ava": {
        "to": "Ava (frontend/UX lead)",
        "authority": "frontend, UX/performance report, client-side implementation",
        "docs": ["AGENTS.md", "team/Ava/README.md", "ROLE-RESOLUTIONS.md"],
        "invoke": "Ava, execute the current workflow task.",
    },
    "marcus": {
        "to": "Marcus (database lead)",
        "authority": "schema, migrations, DB policy, rollback readiness",
        "docs": ["AGENTS.md", "team/Marcus/README.md", "governance/DB-POLICY.md", "ROLE-RESOLUTIONS.md"],
        "invoke": "Marcus, execute the current workflow task.",
    },
    "sophia": {
        "to": "Sophia (deployment/infra duration lead)",
        "authority": "infra duration estimates, release notice, deployment readiness",
        "docs": ["AGENTS.md", "team/Sophia/README.md", "ROLE-RESOLUTIONS.md"],
        "invoke": "Sophia, execute the current workflow task.",
    },
    "liam": {
        "to": "Liam (automation/runbook lead)",
        "authority": "automation scripts, runbooks, usage/failure-mode documentation",
        "docs": ["AGENTS.md", "team/Liam/README.md", "scripts/SCRIPT-RUNBOOK-workflow-orchestrator.md"],
        "invoke": "Liam, execute the current workflow task.",
    },
    "daniel": {
        "to": "Daniel (security/compliance lead)",
        "authority": "security baseline, veto, release security clearance",
        "docs": ["AGENTS.md", "team/Daniel/README.md", "governance/SECURITY-PROCEDURE.md"],
        "invoke": "Daniel, execute the current workflow task.",
    },
    "noah": {
        "to": "Noah (AI/vector lead)",
        "authority": "AI/vector work, AI test report, retrieval quality",
        "docs": ["AGENTS.md", "team/Noah/README.md", "ROLE-RESOLUTIONS.md"],
        "invoke": "Noah, execute the current workflow task.",
    },
    "emma": {
        "to": "Emma (integration lead)",
        "authority": "external integrations, integration contract authoring",
        "docs": ["AGENTS.md", "team/Emma/README.md", "ROLE-RESOLUTIONS.md"],
        "invoke": "Emma, execute the current workflow task.",
    },
    "aurel": {
        "to": "Aurel (.codex stabilization and context-quality)",
        "authority": "context stabilization, brain wiring, agentic-flu checks; no workflow ownership",
        "docs": ["AGENTS.md", ".codex/AUREL.md", ".codex/STABILIZATION-RUNBOOK.md"],
        "invoke": "Aurel, execute the current workflow task.",
    },
}


def _owner_context(owner: str) -> dict:
    clean_owner = owner.strip()
    return OWNER_CONTEXTS.get(clean_owner.lower(), {
        "to": f"{clean_owner or 'Unknown'} (owner from active.md)",
        "authority": "use owner-specific docs from AGENTS.md/team/ or agents/ before acting",
        "docs": ["AGENTS.md", "docs/AGENTS-USAGE.md", "governance/CONTEXT-SWITCHING-PROTOCOL.md"],
        "invoke": f"{clean_owner or 'Owner'}, execute the current workflow task.",
    })

# Orchestrator: reuse captain_on_deck and repo_root logic
def _repo_root() -> Path:
    root = Path(__file__).resolve().parent.parent
    env_root = os.environ.get("WORKFLOW_REPO_ROOT", "").strip()
    if env_root and Path(env_root).is_dir():
        return Path(env_root)
    return root


def _captain_on_deck(repo_root: Path) -> bool:
    env_val = os.environ.get("CAPTAIN_ON_DECK", "").strip().lower()
    if env_val in ("1", "true", "yes"):
        return True
    if env_val in ("0", "false", "no"):
        return False
    path = repo_root / "governance" / "captain_on_deck"
    if not path.exists():
        return False
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        for line in text.splitlines():
            val = line.strip().lower()
            if not val:
                continue
            if val in ("1", "true", "yes"):
                return True
            return False
    except OSError:
        return False
    return False


def _parse_active_rows(path: Path) -> list[dict]:
    """Parse active.md table; return list of row dicts (priority, project, task, owner, status, link, _index)."""
    rows: list[dict] = []
    if not path.exists():
        return rows
    text = path.read_text(encoding="utf-8", errors="replace")
    index = 0
    for line in text.splitlines():
        if not line.strip().startswith("|") or line.strip() == "|--":
            continue
        parts = [p.strip() for p in line.split("|") if p]
        if len(parts) < 5:
            continue
        rows.append({
            "priority": parts[0],
            "project": parts[1],
            "task": parts[2],
            "owner": parts[3],
            "status": parts[4].upper(),
            "link": parts[5] if len(parts) > 5 else "",
            "_index": index,
        })
        index += 1
    return rows


def _open_tasks(rows: list[dict]) -> list[dict]:
    """Return OPEN rows in order: P1 first, then P2, then file order within same (priority, project)."""
    open_rows = [r for r in rows if r["status"] == "OPEN"]
    def key(r):
        p = r["priority"].upper()
        if p == "P1":
            return (0, r["project"], r.get("_index", 0))
        if p == "P2":
            return (1, r["project"], r.get("_index", 0))
        return (2, r["project"], r.get("_index", 0))
    open_rows.sort(key=key)
    return open_rows


def _filter_by_project(open_list: list[dict], project_filter: str) -> list[dict]:
    """Keep only rows whose Project column matches (case-insensitive)."""
    pf = project_filter.strip().lower()
    if not pf:
        return open_list
    return [r for r in open_list if r["project"].lower() == pf]


def _prio_sort_key(r: dict):
    """Same ordering as _open_tasks (P1, P2, file order)."""
    p = r["priority"].upper()
    if p == "P1":
        return (0, r["project"], r.get("_index", 0))
    if p == "P2":
        return (1, r["project"], r.get("_index", 0))
    return (2, r["project"], r.get("_index", 0))


def _pick_current_step(rows: list[dict], project_filter: str) -> dict | None:
    """
    Next row to drive. When WORKFLOW_DRIVER_CLAIM_IN_PROGRESS is on, if the head OPEN row’s project
    already has an IN_PROGRESS row, return that IN_PROGRESS row (stable current step) instead of
    the next OPEN — prevents flip-flop when many OPEN rows share a project.
    """
    open_list = _filter_by_project(_open_tasks(rows), project_filter)
    if _env_claim_in_progress() and project_filter.strip():
        pf = project_filter.strip().lower()
        inprog_only = [
            r for r in rows
            if r["status"] == "IN_PROGRESS" and r["project"].lower() == pf
        ]
        if inprog_only and not open_list:
            inprog_only.sort(key=_prio_sort_key)
            return inprog_only[0]
    if not open_list:
        return None
    if not _env_claim_in_progress():
        return open_list[0]
    p0 = open_list[0]["project"]
    inprog_same = [r for r in rows if r["status"] == "IN_PROGRESS" and r["project"] == p0]
    if inprog_same:
        inprog_same.sort(key=_prio_sort_key)
        return inprog_same[0]
    return open_list[0]


def _row_fingerprint(r: dict) -> str:
    """Stable id for matching row when polling."""
    task = (r["task"] or "")[:80]
    return f"{r['priority']}|{r['project']}|{r['owner']}|{task}"


def _find_row_status(repo_root: Path, fingerprint: str) -> str | None:
    """Re-parse active.md and return current status of row matching fingerprint, or None if not found."""
    active_path = repo_root / "active.md"
    rows = _parse_active_rows(active_path)
    for r in rows:
        if _row_fingerprint(r) == fingerprint:
            return r["status"]
    return None


def _write_current_step(repo_root: Path, step: dict, ts: str) -> None:
    """Write governance/workflow_driver_current.txt so Cursor/operator knows what to execute."""
    out = repo_root / "governance" / "workflow_driver_current.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    # One line: priority | project | task (truncated) | owner | timestamp
    task_short = (step["task"] or "")[:120]
    line = f"{step['priority']} | {step['project']} | {task_short} | {step['owner']} | {ts}\n"
    out.write_text(line, encoding="utf-8")
    _write_context_passport(repo_root, step, ts, task_short)


def _gate_requirements(step: dict) -> str:
    """Proceed-gate hints for workflow passport (WF-APP-007). Ref: SCRIPT-RUNBOOK-workflow-proceed-gates."""
    owner = (step.get("owner") or "").strip()
    project = (step.get("project") or "").strip().lower()
    lines: list[str] = []
    if owner == "Abelard" or project in {"cluster", "prod", "services"}:
        lines.append(
            "- **Hard gate (cluster preflight)**: get_cluster_snapshot / SCRIPT-RUNBOOK-cluster-proceed-preflight before execute. Critical firing alerts → BLOCKED."
        )
    if project in {"cursor-repo", "hesperia", "clients"} or owner in {"Gena", "Felix", "Cursor"}:
        lines.append(
            "- **Soft gate (CI verify)**: get_branch_ci / SCRIPT-RUNBOOK-github-ci-verify before report_done DONE when PR is open."
        )
    if owner in {"Grace", "Cursor"}:
        lines.append("- **Inbox orient (read-only)**: get_inbox_summary when triaging; Grace owns row creation.")
    if not lines:
        lines.append("- Standard: get_runbook for mandatory triggers; report_done when owner completes row.")
    return "\n".join(lines)


def _write_context_passport(repo_root: Path, step: dict, ts: str, task_short: str) -> None:
    """Write an explicit owner-context handoff for Cursor-in-IDE / MCP execution."""
    ctx = _owner_context(step.get("owner", ""))
    out = repo_root / "governance" / "workflow_context_current.md"
    docs = "\n".join(f"- {d}" for d in ctx["docs"])
    text = f"""# Workflow Context Passport

generated_at: {ts}

current_step: {step['priority']} | {step['project']} | {task_short} | {step['owner']}
assigned_owner: {step['owner']}
required_context: {ctx['to']}
invoke_as: {ctx['invoke']}

## CSP Required

```
CSP:
From: Cursor (workflow runner / repo orchestrator)
To: {ctx['to']}
Reason: active.md current step is assigned to {step['owner']}.
What changes: authority = {ctx['authority']}; allowed outputs = task deliverables plus report_done for the owned row.
```

## Required Context Sources

{docs}

## MCP / Workflow Requirements

- Use query_knowledge first for process, roles, workflow, cluster, agents, and books when available.
- Use get_current_step / get_heartbeat for workflow awareness when available.
- Use get_runbook for triggered SCRIPT-RUNBOOK procedures.
- Use list_pending_approvals / get_approval_status before destructive or high-risk work.
- After completing this owned row, call report_done(task_id, DONE) or the documented backend/API equivalent.
- Do not flatten this into generic Cursor context; execute as the named owner above.

## Proceed gate requirements

{_gate_requirements(step)}
"""
    out.write_text(text, encoding="utf-8")


def _write_idle_context_passport(repo_root: Path, ts: str, mode: str, project_filter: str = "") -> None:
    out = repo_root / "governance" / "workflow_context_current.md"
    target = f" for project {project_filter}" if project_filter else ""
    out.write_text(
        "# Workflow Context Passport\n\n"
        f"generated_at: {ts}\n"
        f"workflow_mode: {mode}\n"
        f"current_step: No OPEN tasks{target}\n\n"
        "No named owner context is active. Next executable work must enter through Grace triage / active.md.\n",
        encoding="utf-8",
    )


def _env_claim_in_progress() -> bool:
    return os.environ.get("WORKFLOW_DRIVER_CLAIM_IN_PROGRESS", "").strip().lower() in ("1", "true", "yes")


def _claim_open_row_in_progress(repo_root: Path, step: dict) -> bool:
    """If enabled, one IN_PROGRESS per project: demote other same-project IN_PROGRESS to OPEN, then claim step row."""
    if not _env_claim_in_progress():
        return False
    target = _row_fingerprint(step)
    proj = (step.get("project") or "").strip()
    if not proj:
        return False
    path = repo_root / "active.md"
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8", errors="replace")
    out: list[str] = []
    changed = False
    for line in text.splitlines(keepends=True):
        if not line.lstrip().startswith("|") or line.strip() == "|--":
            out.append(line)
            continue
        parts = [p.strip() for p in line.split("|") if p]
        if len(parts) < 5:
            out.append(line)
            continue
        r = {
            "priority": parts[0],
            "project": parts[1],
            "task": parts[2],
            "owner": parts[3],
            "status": parts[4].upper(),
        }
        if r["project"] != proj:
            out.append(line)
            continue
        fp = _row_fingerprint(r)
        st = r["status"]
        nl = line
        if st == "IN_PROGRESS" and fp != target:
            nl = line.replace("| IN_PROGRESS |", "| OPEN |", 1)
            if nl != line:
                changed = True
        elif st == "OPEN" and fp == target:
            nl = line.replace("| OPEN |", "| IN_PROGRESS |", 1)
            if nl != line:
                changed = True
        out.append(nl)
    if changed:
        path.write_text("".join(out), encoding="utf-8")
    return changed


def _run_orchestrator_heartbeat(repo_root: Path) -> None:
    """Run orchestrator to refresh heartbeat (read-only awareness)."""
    import subprocess
    orch = repo_root / "scripts" / "workflow_orchestrator.py"
    if orch.exists():
        try:
            subprocess.run(
                [sys.executable, str(orch)],
                cwd=str(repo_root),
                capture_output=True,
                timeout=30,
            )
        except Exception:
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description="Workflow driver: trigger-after-result (one or more steps).")
    parser.add_argument("--max-steps", type=int, default=1, metavar="N", help="Max steps per run (default 1 = semi-run)")
    parser.add_argument("--no-wait", action="store_true", help="Write current step only; do not poll")
    parser.add_argument("--heartbeat-only", action="store_true", help="Only refresh heartbeat and exit")
    parser.add_argument(
        "--project",
        default="",
        metavar="NAME",
        help="Only OPEN rows for this Project column (overrides WORKFLOW_DRIVER_PROJECT env).",
    )
    args = parser.parse_args()

    repo_root = _repo_root()
    captain = _captain_on_deck(repo_root)

    project_filter = (args.project or os.environ.get("WORKFLOW_DRIVER_PROJECT", "")).strip()

    active_path = repo_root / "active.md"
    rows = _parse_active_rows(active_path)
    step = _pick_current_step(rows, project_filter)

    # Heartbeat-only: never write current step or run trigger chain.
    if args.heartbeat_only:
        _run_orchestrator_heartbeat(repo_root)
        return 0

    # Captain on deck: skip invocations only when no tasks behind. If any OPEN task, still start invocations (write current, step2 will run).
    if captain and step is None:
        _run_orchestrator_heartbeat(repo_root)
        return 0

    if captain and step is not None:
        # Tasks behind: write current step and proceed so step2 (executor / agent) runs.
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        _write_current_step(repo_root, step, ts)
        _claim_open_row_in_progress(repo_root, step)
        _run_orchestrator_heartbeat(repo_root)
        return 0

    if step is None:
        # No OPEN tasks (or none matching project filter): idle marker, refresh heartbeat, exit.
        current_file = repo_root / "governance" / "workflow_driver_current.txt"
        current_file.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        if project_filter:
            current_file.write_text(
                f"# No OPEN tasks for project {project_filter}\n"
                f"last_run_iso: {ts}\n"
                "workflow_mode: project_idle\n"
                f"workflow_driver_project_filter: {project_filter}\n",
                encoding="utf-8",
            )
            _write_idle_context_passport(repo_root, ts, "project_idle", project_filter)
        else:
            current_file.write_text(
                "# No OPEN tasks\n"
                f"last_run_iso: {ts}\n"
                "workflow_mode: autonomous_idle\n"
                "# Next: Grace triage (inbox.md / operational) → new OPEN row; or operator invokes proceed when work exists.\n",
                encoding="utf-8",
            )
            _write_idle_context_passport(repo_root, ts, "autonomous_idle")
        _run_orchestrator_heartbeat(repo_root)
        return 0

    timeout_sec = int(os.environ.get("DRIVER_STEP_TIMEOUT_SEC", "300"))
    steps_done = 0
    poll_interval = 30

    while steps_done < args.max_steps:
        rows = _parse_active_rows(active_path)
        step = _pick_current_step(rows, project_filter)
        if step is None:
            break
        fingerprint = _row_fingerprint(step)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        _write_current_step(repo_root, step, ts)
        _claim_open_row_in_progress(repo_root, step)
        _run_orchestrator_heartbeat(repo_root)

        if args.no_wait:
            return 0

        # Poll until result (row status != OPEN and != IN_PROGRESS) or timeout
        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            status = _find_row_status(repo_root, fingerprint)
            if status is None:
                # Row removed from active.md; treat as done and proceed
                steps_done += 1
                break
            if status in ("DONE", "PAUSED", "ARCHIVED"):
                steps_done += 1
                break
            time.sleep(min(poll_interval, max(0, deadline - time.monotonic())))
        else:
            # Timeout: exit (next run will re-pick same or next)
            break

    return 0


if __name__ == "__main__":
    sys.exit(main())
