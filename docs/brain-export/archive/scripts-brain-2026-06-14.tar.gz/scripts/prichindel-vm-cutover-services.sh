#!/usr/bin/env bash
# Enable host services on VM before IP cutover. Run on alunel.
set -euo pipefail
VM="${VM:-192.168.100.21}"

ssh -o BatchMode=yes "igareosh@${VM}" "sudo bash -s" <<'VMEOF'
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3-fastapi python3-uvicorn python3-pydantic postfix mailutils 2>/dev/null || true

REPO=/data/workspaces/cursor
WF=${REPO}/cluster/workflow-automation

if [[ -f "${WF}/workflow-api.service" ]]; then
  sed "s|/data/chroma/venv/bin/uvicorn|/usr/bin/python3 -m uvicorn|" \
    "${WF}/workflow-api.service" | sudo tee /etc/systemd/system/workflow-api.service >/dev/null
fi

EX=${REPO}/cluster/prichindel/vaporas-reverse-tunnel-prichindel-443.service.example
if [[ -f "${EX}" ]]; then
  sudo cp "${EX}" /etc/systemd/system/vaporas-reverse-tunnel-prichindel-443.service
fi

for u in hesperia-api hesperia-inspection-viewer hesperia-output-views; do
  [[ -f "${REPO}/cluster/${u}.service" ]] && sudo cp "${REPO}/cluster/${u}.service" /etc/systemd/system/ || true
  [[ -f "${REPO}/cluster/prichindel/systemd/${u}.service" ]] && \
    sudo cp "${REPO}/cluster/prichindel/systemd/${u}.service" /etc/systemd/system/ || true
done

sudo systemctl daemon-reload
sudo systemctl enable nginx apache2 docker
sudo systemctl enable workflow-api 2>/dev/null || true
sudo systemctl restart workflow-api 2>/dev/null || sudo systemctl start workflow-api 2>/dev/null || true
systemctl is-active workflow-api 2>/dev/null || echo workflow-api-not-active
curl -sf -o /dev/null -w "workflow:%{http_code}\n" http://127.0.0.1:9096/workflow/heartbeat 2>/dev/null || echo workflow_skip
sudo nginx -t && sudo systemctl reload nginx
VMEOF

echo "cutover-services done"
