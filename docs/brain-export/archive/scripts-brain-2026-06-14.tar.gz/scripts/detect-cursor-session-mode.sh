#!/usr/bin/env bash
# Detect session host, role, and connectivity for Cursor agents.
# Writes governance/cursor_session_mode.txt (gitignored).
# Ref: governance/HOST-ALTITUDINE-VS-LIBRARYMASTER.md, .cursor/rules/cursor-session-mode.mdc

set -euo pipefail
REPO_ROOT="${1:-.}"
MODE_FILE="$REPO_ROOT/governance/cursor_session_mode.txt"
H="$(hostname -s 2>/dev/null || hostname | cut -d. -f1)"
REF="governance/HOST-ALTITUDINE-VS-LIBRARYMASTER.md"

# LAN reachability to prichindel (same probe as LAMAITA script)
connectivity="unknown"
if timeout 2 bash -c "echo >/dev/tcp/192.168.100.21/22" 2>/dev/null; then
  connectivity="lan"
fi

brain_path_warning=""
if [[ -d /data/altitudine/prichindel.com ]]; then
  cwd="$(cd "$REPO_ROOT" 2>/dev/null && pwd -P || true)"
  if [[ "$cwd" == /data/altitudine/prichindel.com* ]]; then
    brain_path_warning="workspace_under_/data/altitudine/does_not_imply_hostname_altitudine"
  fi
fi

cluster_ssh_origin_for() {
  case "$1" in
    alunel) echo "alunel" ;;
    prichindel) echo "prichindel" ;;
    *) echo "jump_alunel" ;;
  esac
}

agent_cert_hint() {
  local sf="$REPO_ROOT/governance/agent_ssh_cert_status.txt"
  if [[ ! -f "$sf" ]]; then
    echo "unknown"
    return
  fi
  local vu
  vu=$(grep '^valid_until:' "$sf" 2>/dev/null | cut -d' ' -f2-)
  if [[ -z "$vu" ]]; then
    echo "unknown"
    return
  fi
  local now vu_epoch now_epoch
  now_epoch=$(date +%s)
  vu_epoch=$(date -d "$vu" +%s 2>/dev/null || echo 0)
  if [[ "$vu_epoch" -gt "$now_epoch" ]]; then
    echo "valid"
  else
    echo "expired"
  fi
}

write_mode() {
  local host="$1" role="$2" dev_office="$3" conn="$4"
  local origin hint
  origin="$(cluster_ssh_origin_for "$host")"
  hint="$(agent_cert_hint)"
  {
    echo "host=$host"
    echo "role=$role"
    echo "dev_office=$dev_office"
    echo "connectivity=$conn"
    echo "cluster_ssh_origin=$origin"
    echo "agent_cert=$hint"
    echo "authentik_ui=https://trustmaster.prichindel.com"
    echo "agent_access_mcp=get_agent_access_status"
    echo "agent_access_preflight=scripts/agent-cluster-access-preflight.sh"
    echo "ref=$REF"
    [[ -n "$brain_path_warning" ]] && echo "brain_path_warning=$brain_path_warning"
  } >"$MODE_FILE"
  echo "Session mode: host=$host role=$role dev_office=$dev_office connectivity=$conn cluster_ssh_origin=$origin agent_cert=$hint. Written to $MODE_FILE"
}

case "$H" in
  alunel)
    write_mode "alunel" "team_dev_office" "true" "${connectivity:-lan}"
    ;;
  prichindel)
    write_mode "prichindel" "prod_backend" "false" "N/A"
    ;;
  librarymaster)
    write_mode "librarymaster" "papra_chroma2" "false" "${connectivity:-lan}"
    ;;
  altitudine)
    write_mode "altitudine" "dev_vm_ulim" "false" "${connectivity:-lan}"
    ;;
  izvoras|mugurel|stejarel|voinicel|tersagor|trustmaster|dnsmaster|chronomaster|mediamaster)
    write_mode "$H" "cluster_node" "false" "${connectivity:-unknown}"
    ;;
  *)
    write_mode "$H" "unknown" "false" "${connectivity:-unknown}"
    ;;
esac
