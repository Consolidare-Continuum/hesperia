#!/bin/bash
# Test each Cloudflare token: GET /accounts, then GET /user/tokens/verify, then GET /accounts/{id} if cf-account-id set. Run on prichindel.
BASE="https://api.cloudflare.com/client/v4/accounts?per_page=5"
AID=$(sudo cat /root/.secrets/cloudflare/cf-account-id 2>/dev/null | tr -d '\n\r')
for f in cf-zero-trust-read cf-zero-trust-report cf-zero-trust-edit cf-zero-trust-seats cf-api-token; do
  path="/root/.secrets/cloudflare/$f"
  printf "=== %s === " "$f"
  if ! sudo test -r "$path" 2>/dev/null; then echo "no file"; continue; fi
  T=$(sudo cat "$path" 2>/dev/null | tr -d '\n\r')
  if [ -z "$T" ]; then echo "empty"; continue; fi
  R=$(curl -sS -H 'Authorization: Bearer '"$T" "$BASE")
  success=$(echo "$R" | jq -r '.success // "null"')
  count=$(echo "$R" | jq -r '.result | length // 0')
  err=$(echo "$R" | jq -r '.errors[0].message // empty')
  echo "success=$success result_count=$count err=$err"
  if [ "$count" != "0" ] && [ "$count" != "null" ]; then
    echo "$R" | jq -r '.result[]? | "  \(.name)  id=\(.id)"'
    echo "$R" | jq -r '.result[0].id' >/tmp/cf_account_id.txt 2>/dev/null
  fi
done
if [ -r /tmp/cf_account_id.txt ]; then echo "First account_id: $(cat /tmp/cf_account_id.txt)"; fi
# Token verify (any ZT token) and GET /accounts/{id} when account-scoped
printf "=== user/tokens/verify (Edit token) === "
T=$(sudo cat /root/.secrets/cloudflare/cf-zero-trust-edit 2>/dev/null | tr -d '\n\r')
[ -z "$T" ] && T=$(sudo cat /root/.secrets/cloudflare/cf-zero-trust-read 2>/dev/null | tr -d '\n\r')
if [ -n "$T" ]; then
  curl -sS -H 'Authorization: Bearer '"$T" 'https://api.cloudflare.com/client/v4/user/tokens/verify' | jq -c '{success, status: .result.status, id: .result.id}' 2>/dev/null || echo "jq fail"
fi
if [ -n "$AID" ] && [ -n "$T" ]; then
  printf "=== GET /accounts/%s === " "$AID"
  R=$(curl -sS -H 'Authorization: Bearer '"$T" "https://api.cloudflare.com/client/v4/accounts/$AID")
  echo "$R" | jq -c 'if .success then {success, name: .result.name} else {success, err: .errors[0].message} end' 2>/dev/null || echo "$R"
fi
