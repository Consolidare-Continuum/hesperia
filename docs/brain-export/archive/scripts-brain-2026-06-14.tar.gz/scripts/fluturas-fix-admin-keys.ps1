# Set C:\ProgramData\ssh\administrators_authorized_keys with prichindel key and exact ACL. Run as Administrator.
# Windows OpenSSH requires: no inheritance; Administrators FullControl; SYSTEM FullControl.
$ErrorActionPreference = 'Stop'
$keyFile = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "cluster\fluturas\prichindel.pub"
$keyLine = (Get-Content -LiteralPath $keyFile -Raw).Trim()
$adminKeys = "C:\ProgramData\ssh\administrators_authorized_keys"
$sshDir = "C:\ProgramData\ssh"
if (-not (Test-Path $sshDir)) { New-Item -ItemType Directory -Path $sshDir -Force | Out-Null }
# Write key only (Unix LF); no BOM
[System.IO.File]::WriteAllText($adminKeys, $keyLine + "`n", [System.Text.UTF8Encoding]::new($false))
# Exact ACL: disable inheritance, Administrators + SYSTEM only (required by Windows OpenSSH)
$acl = Get-Acl -LiteralPath $adminKeys
$acl.SetAccessRuleProtection($true, $false)
$administratorsRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators", "FullControl", "Allow")
$systemRule = New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM", "FullControl", "Allow")
$acl.SetAccessRule($administratorsRule)
$acl.SetAccessRule($systemRule)
Set-Acl -LiteralPath $adminKeys -AclObject $acl
Restart-Service sshd -Force -ErrorAction SilentlyContinue
Write-Host "Set administrators_authorized_keys and ACL; restarted sshd."
