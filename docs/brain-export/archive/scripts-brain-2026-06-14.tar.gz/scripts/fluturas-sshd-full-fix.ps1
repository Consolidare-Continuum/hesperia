# Full fix: reset sshd_config, start sshd, set administrators_authorized_keys. Run as Administrator.
# Usage: powershell -ExecutionPolicy Bypass -File "path\to\fluturas-sshd-full-fix.ps1"
$ErrorActionPreference = 'Stop'
$repo = Split-Path (Split-Path $PSScriptRoot)
$keyFile = Join-Path $repo "cluster\fluturas\prichindel.pub"
$sshDir = "$env:ProgramData\ssh"
$cfg = "$sshDir\sshd_config"
$adminKeys = "$sshDir\administrators_authorized_keys"
$clusterIPs = '192.168.100.21,192.168.100.23,192.168.100.40'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run as Administrator."
    exit 1
}

# 1. Reset sshd_config to default + PasswordAuthentication no
$candidates = @("$env:ProgramFiles\OpenSSH\sshd_config_default", "$env:SystemRoot\System32\OpenSSH\sshd_config_default")
$binPath = (Get-WmiObject Win32_Service -Filter "Name='sshd'" -ErrorAction SilentlyContinue).PathName
if ($binPath -match '"([^"]+)\\sshd\.exe"') { $candidates += "$($Matches[1])\sshd_config_default" }
$defaultCfg = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if ($defaultCfg) {
    if (-not (Test-Path $sshDir)) { New-Item -ItemType Directory -Path $sshDir -Force | Out-Null }
    Copy-Item $cfg "$cfg.bak.full_fix_$(Get-Date -Format 'yyyyMMdd-HHmm')" -Force -ErrorAction SilentlyContinue
    Copy-Item $defaultCfg $cfg -Force
    Add-Content -Path $cfg -Value "`n# fluturas: key-only`nPasswordAuthentication no"
    Write-Host "Reset sshd_config; added PasswordAuthentication no."
}

# 2. Firewall
netsh advfirewall firewall delete rule name="OpenSSH SSH Server (cluster only)" dir=in 2>$null
netsh advfirewall firewall add rule name="OpenSSH SSH Server (cluster only)" dir=in action=allow protocol=TCP localport=22 remoteip=$clusterIPs profile=private,domain | Out-Null
Write-Host "Firewall: inbound 22 from $clusterIPs"

# 3. administrators_authorized_keys
$keyLine = (Get-Content -LiteralPath $keyFile -Raw).Trim()
[System.IO.File]::WriteAllText($adminKeys, $keyLine + "`n", [System.Text.UTF8Encoding]::new($false))
$acl = Get-Acl -LiteralPath $adminKeys
$acl.SetAccessRuleProtection($true, $false)
$acl.SetAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators", "FullControl", "Allow")))
$acl.SetAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM", "FullControl", "Allow")))
Set-Acl -LiteralPath $adminKeys -AclObject $acl
Write-Host "Set administrators_authorized_keys and ACL."

# 4. Start sshd
Set-Service sshd -StartupType Automatic
try { Start-Service sshd -ErrorAction Stop } catch { $_.Exception.Message | Out-File "$env:USERPROFILE\fluturas-sshd-start-error.txt"; Write-Host "Start-Service failed: $_"; Write-Host "Error saved to $env:USERPROFILE\fluturas-sshd-start-error.txt" }
$status = (Get-Service sshd -ErrorAction SilentlyContinue).Status
Write-Host "sshd status: $status"
if ($status -ne 'Running') {
    Write-Host "Run in elevated PowerShell: fluturas-sshd-debug-start.ps1 to see sshd -d output (why start fails)."
    exit 1
}
Write-Host "Done. From prichindel: ssh fluturas hostname"
