#!/usr/bin/env python3
"""
Optional Sentry init for Hesperia output_views (T62 stub).

No DSN in repo. If SENTRY_DSN is unset or empty, this is a no-op.
If sentry-sdk is not installed, logs once and continues without raising.

Use from Django settings or WSGI after django.setup():
    from scripts.output_views_sentry_optional import init_sentry_optional
    init_sentry_optional()
"""
from __future__ import annotations

import logging

_log = logging.getLogger(__name__)


def init_sentry_optional() -> None:
    import os

    dsn = (os.environ.get("SENTRY_DSN") or "").strip()
    if not dsn:
        return
    try:
        import sentry_sdk
        from sentry_sdk.integrations.logging import LoggingIntegration
    except ImportError:
        _log.warning("SENTRY_DSN set but sentry-sdk not installed; skipping Sentry init")
        return
    sentry_sdk.init(
        dsn=dsn,
        integrations=[LoggingIntegration(level=logging.INFO, event_level=logging.ERROR)],
        traces_sample_rate=float(os.environ.get("SENTRY_TRACES_SAMPLE_RATE", "0.0")),
    )
