# IM-IRC-T50 — E2E smoke (manual checklist)

**Goal:** One **`correlation_id`** visible web → IRC → n8n → OpenAI → IRC (+ optional Telegram).

| Step | Check |
|------|--------|
| 1 | **Cloudflare Access** session on chosen web hostname (**T43/T45**). |
| 2 | Composer emits envelope **v1** or gateway receives **`cid`** (browser random UUID). |
| 3 | **n8n** webhook receives POST; execution shows **`correlation_id`** in payload. |
| 4 | **OpenAI** node runs (**T20** smoke optional); output branch carries **`cid`**. |
| 5 | **IRC** **`PRIVMSG`** / **`NOTICE`** to **`#agents-ingest`** contains **`cid:`** prefix. |
| 6 | **Eggdrop** **`eggdrop-classify.jsonl`** / gateway forwarder sees line (**T13/T15**). |
| 7 | Optional: **Telegram** bot receives message with same **`cid`** (**T32/T51** secrets path). |

**Fail:** Use **SCRIPT-RUNBOOK-imirc-mesh.md §4** error path; log **`cid`** only.

SIGNED: Abelard / Gena | IM-IRC-T50 | 2026-05-04 | operational checklist
