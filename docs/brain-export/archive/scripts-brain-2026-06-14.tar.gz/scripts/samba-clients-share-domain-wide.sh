#!/usr/bin/env bash
# Make /data/CLIENTS share accessible to all domain users (PRICHINDELAD).
# Run on prichindel (DC) as root. Ref: cluster/SAMBA-AD-RUNBOOK.md §7.
set -e
SMB_CONF=/etc/samba/smb.conf
BACKUP="${SMB_CONF}.bak.$(date +%Y%m%d%H%M%S)"

if [[ ! -f "$SMB_CONF" ]]; then
  echo "ERROR: $SMB_CONF not found. Run on the DC (prichindel)."
  exit 1
fi

# Backup
cp -a "$SMB_CONF" "$BACKUP"
echo "Backed up to $BACKUP"

# Replace valid users in [CLIENTS] section: igare -> all domain users (Domain Users group)
# + prefix = AD group. Quoted so "Domain Users" (space) is one token. Allow leading tab/space (smb.conf often uses tabs).
sed -i '/^\[CLIENTS\]/,/^\[/ s/^[[:space:]]*valid users = igare[[:space:]]*$/	valid users = "+PRICHINDELAD\\\\Domain Users"/' "$SMB_CONF"

if grep -A 20 '^\[CLIENTS\]' "$SMB_CONF" | grep -q 'valid users = "+PRICHINDELAD'; then
  echo "Updated [CLIENTS] valid users to +PRICHINDELAD\\Domain Users (domain-wide)"
else
  echo "WARNING: Replacement may have failed. Check $SMB_CONF [CLIENTS] section."
  echo "Expected: valid users = \"+PRICHINDELAD\\Domain Users\""
  diff "$BACKUP" "$SMB_CONF" || true
  exit 1
fi

# Sanity check
testparm -s "$SMB_CONF" > /dev/null 2>&1 || { echo "testparm failed"; exit 1; }

# Restart DC so share takes effect
systemctl restart samba-ad-dc
echo "Restarted samba-ad-dc. CLIENTS is now domain-wide (any PRICHINDELAD user can map the share)."
