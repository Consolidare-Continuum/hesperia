# Runbook: library file list (Proton / Drive export → TSV)

## Why

Embedding a 400+ row paste in an agent shell command blows up JSON message size. **Always use a file on disk.**

## Steps

1. Open `operational/library_paste_raw.txt`.
2. Paste the full UI export (from `Name` / `Size` / `Modified` through the trailing `N files` line).
3. Save.
4. From repo root:

```bash
bash scripts/library_list_from_paste.sh
```

5. Output: `operational/library-files-inventory.txt` (tab-separated, optional header row).

## Manual

```bash
python3 scripts/parse_library_file_list.py operational/library_paste_raw.txt -o operational/library-files-inventory.txt --header
```

Stdin (small pastes only): `python3 scripts/parse_library_file_list.py -o out.txt --header < paste.txt`

SIGNED: Cursor | repo tooling | 2026-03-21 | library list pipeline
