#!/usr/bin/env bash
# Preflight for Cursor MCP on altitudine dev VM. Run on altitudine from repo root.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO_ROOT"
fail=0
echo "=== verify-altitudine-cursor-env (host=$(hostname -s)) ==="

if getent hosts prichindel | grep -q '192.168.100.21'; then
  echo "OK: getent hosts prichindel"
else
  echo "FAIL: prichindel must resolve to 192.168.100.21"
  fail=1
fi

if [ -f "${HOME}/.ssh/agent-ca/id_agent-cert.pub" ]; then
  echo "OK: agent CA cert present"
else
  echo "FAIL: missing ~/.ssh/agent-ca — run scripts/deploy-mcp-altitudine-remote.sh from alunel"
  fail=1
fi

if ssh -o BatchMode=yes -o ConnectTimeout=8 prichindel 'echo ok' 2>/dev/null | grep -q ok; then
  echo "OK: ssh prichindel"
else
  echo "FAIL: ssh prichindel (renew cert on alunel; deploy-mcp-altitudine-remote.sh)"
  fail=1
fi

MCPC="$REPO_ROOT/governance/mcp-config.json"
DEST="${HOME}/.cursor/mcp.json"
if [ -f "$DEST" ] && cmp -s "$MCPC" "$DEST"; then
  echo "OK: ~/.cursor/mcp.json matches governance/mcp-config.json"
else
  echo "WARN: run bash scripts/deploy-mcp-config-global.sh or deploy-mcp-altitudine-remote.sh"
  fail=1
fi

if bash "$REPO_ROOT/scripts/verify-mcp-handshake.sh"; then
  echo "OK: MCP handshake"
else
  fail=1
fi

if [ "$fail" -eq 0 ]; then
  echo "=== all checks passed ==="
  exit 0
fi
echo "=== some checks failed ==="
exit 1
