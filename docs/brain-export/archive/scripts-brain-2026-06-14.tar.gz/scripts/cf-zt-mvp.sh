#!/bin/bash
# MVP: Test all ZT tokens against ZT endpoints; list some data from first successful call. Run on prichindel.
# Needs: /root/.secrets/cloudflare/cf-account-id and at least one of cf-zero-trust-read, cf-zero-trust-report, cf-zero-trust-edit, cf-zero-trust-seats.
AID=$(sudo cat /root/.secrets/cloudflare/cf-account-id 2>/dev/null | tr -d '\n\r')
if [ -z "$AID" ]; then echo "No cf-account-id. Set it first."; exit 1; fi

BASE="https://api.cloudflare.com/client/v4"
api() { curl -sS -H "Authorization: Bearer $1" "$2"; }

# Endpoints that might return listable data (read-only)
ENDPOINTS=(
  "GET $BASE/accounts/$AID"
  "GET $BASE/accounts/$AID/devices/settings"
  "GET $BASE/accounts/$AID/devices/policies/default"
  "GET $BASE/accounts/$AID/access/apps"
  "GET $BASE/accounts/$AID/access/users"
  "GET $BASE/accounts/$AID/access/logs/access_requests?limit=5"
)

TOKEN_NAMES=()
for name in cf-zero-trust-read cf-zero-trust-report cf-zero-trust-edit cf-zero-trust-seats; do
  path="/root/.secrets/cloudflare/$name"
  if sudo test -r "$path" 2>/dev/null && [ -n "$(sudo cat "$path" 2>/dev/null | tr -d '\n\r')" ]; then
    TOKEN_NAMES+=("$name")
  fi
done

if [ ${#TOKEN_NAMES[@]} -eq 0 ]; then echo "No ZT token files found."; exit 1; fi

echo "=== ZT tokens present: ${#TOKEN_NAMES[@]} ==="
for n in "${TOKEN_NAMES[@]}"; do echo "  $n"; done
echo ""
echo "=== Testing token + endpoint (account $AID) ==="

WORKING_TOKEN=""
WORKING_RESP=""

for name in "${TOKEN_NAMES[@]}"; do
  T=$(sudo cat "/root/.secrets/cloudflare/$name" 2>/dev/null | tr -d '\n\r')
  [ -z "$T" ] && continue
  for spec in "${ENDPOINTS[@]}"; do
    url="${spec#* }"
    resp=$(api "$T" "$url")
    if echo "$resp" | jq -e '.success == true' >/dev/null 2>&1; then
      echo "OK $name -> ${url##*/}"
      WORKING_TOKEN="$name"
      WORKING_RESP="$resp"
      break 2
    fi
    err=$(echo "$resp" | jq -r '.errors[0].message // .errors[0].code // "?"' 2>/dev/null)
    echo "fail $name -> ${url##*/} ($err)"
  done
done

echo ""
if [ -z "$WORKING_TOKEN" ]; then
  echo "MVP: No token+endpoint succeeded. Deploy Edit/Seats or check token scope."
  exit 2
fi

echo "=== MVP: first success ($WORKING_TOKEN) ==="
echo "$WORKING_RESP" | jq '.'
echo ""
echo "=== MVP: list data (result) ==="
echo "$WORKING_RESP" | jq -r '
  if .result | type == "array" then
    (.result | length | "\(.) items"),
    (.result[0:5][]? | (if type == "object" then (.name // .domain // .email // .id // .) | tostring else . end) | "  " + .)
  elif .result | type == "object" then
    .result | to_entries[0:10][]? | "  \(.key): \(.value)"
  else
    "  \(.result)"
  end
' 2>/dev/null || echo "$WORKING_RESP" | jq -c '.result'
