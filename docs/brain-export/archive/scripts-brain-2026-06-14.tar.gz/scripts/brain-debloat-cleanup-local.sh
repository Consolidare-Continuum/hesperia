#!/usr/bin/env bash
# Brain-only cleanup after remote export (wave 2). Replaces moved paths with link stubs.
set -euo pipefail
BRAIN="${BRAIN_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
DRY_RUN=false
[[ "${1:-}" == "--dry-run" ]] && DRY_RUN=true

run() { [[ "$DRY_RUN" == true ]] && echo "[dry-run] $*" || "$@"; }

link_stub_file() {
  local path="$1" target="$2" title="$3"
  [[ -e "$path" ]] || return 0
  run rm -f "$path"
  run mkdir -p "$(dirname "$path")"
  if [[ "$DRY_RUN" == true ]]; then echo "stub file $path"; return; fi
  cat > "$path" <<EOF
# $title

**Moved (wave 2 debloat).** Canonical copy:

→ $target
EOF
}

link_stub_dir() {
  local path="$1" target="$2" title="$3"
  [[ -e "$path" ]] || return 0
  run rm -rf "$path"
  run mkdir -p "$path"
  if [[ "$DRY_RUN" == true ]]; then echo "stub dir $path"; return; fi
  cat > "$path/README.md" <<EOF
# $title

**Moved (wave 2 debloat).** Canonical copy:

→ $target
EOF
}

echo "brain cleanup: $BRAIN dry=$DRY_RUN"

while IFS= read -r -d '' f; do
  rel="${f#"$BRAIN/operational/"}"
  if [[ -d "$f" ]]; then
    link_stub_dir "$f" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/operational/$rel" "$(basename "$f")"
  else
    link_stub_file "$f" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/operational/$rel" "$(basename "$f")"
  fi
done < <(find "$BRAIN/operational" -iname '*hesperia*' -print0 2>/dev/null)

while IFS= read -r -d '' f; do
  base="$(basename "$f")"
  link_stub_file "$f" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/governance/$base" "$base"
done < <(find "$BRAIN/governance" -iname '*hesperia*' ! -name 'ETHAN-POLICY-HESPERIA-*' -print0 2>/dev/null)

for p in cluster/hesperia cluster/tersagor-h063; do
  link_stub_dir "$BRAIN/$p" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/cluster/$(basename "$p")" "$(basename "$p")"
done
for p in cluster/hesperia-api.service cluster/hesperia.prichindel.com.conf; do
  link_stub_file "$BRAIN/$p" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/cluster/$(basename "$p")" "$(basename "$p")"
done
for p in cluster/alunel/systemd/hesperia-analyze-dev.service cluster/alunel/systemd/hesperia-output-views.service; do
  link_stub_file "$BRAIN/$p" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/cluster/alunel/systemd/$(basename "$p")" "$(basename "$p")"
done
for p in cluster/prichindel/nginx-hesperia.prichindel.com.conf \
  cluster/prichindel/systemd/hesperia-output-views-prichindel.service \
  cluster/prichindel/systemd/hesperia-inspection-viewer.service; do
  link_stub_file "$BRAIN/$p" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/cluster/prichindel/$(basename "$p")" "$(basename "$p")"
done

for p in HESPERIA-TFP-RUNTIME-VARIABLES-TABLE.md HESPERIA-TFP-YIELDED-PARAMETERS-TABLE.md \
  hesperia-0.6.3-archive.zip hesperia-0.6.3-archive.SHA256SUMS.txt; do
  link_stub_file "$BRAIN/$p" "https://github.com/igareosh/hesperia/tree/main/docs/brain-export/root/$p" "$p"
done

run rm -rf "$BRAIN/CLIENTS/hesperia/v0.1"

while IFS= read -r -d '' f; do
  base="$(basename "$f")"
  case "$base" in
    hesperia-prod-deploy.sh|hesperia-sync-brain-links-to-dev.sh|verify-hesperia-*|verify-brain-no-hesperia-product-ingest.sh|alunel-hesperia-bootstrap.sh|alunel-hesperia-dev-env.sh|brain-debloat-*)
      continue ;;
  esac
  run rm -f "$f"
done < <(find "$BRAIN/scripts" -maxdepth 1 -iname '*hesperia*' -print0 2>/dev/null)

# Tersagor
while IFS= read -r -d '' f; do
  rel="${f#"$BRAIN/operational/"}"
  link_stub_file "$f" "https://github.com/igareosh/tersagor/tree/main/docs/brain-export/operational/$rel" "$(basename "$f")"
done < <(find "$BRAIN/operational" -iname '*tersagor*' -print0 2>/dev/null)

while IFS= read -r -d '' f; do
  link_stub_file "$f" "https://github.com/igareosh/tersagor/tree/main/docs/brain-export/governance/$(basename "$f")" "$(basename "$f")"
done < <(find "$BRAIN/governance" -iname '*tersagor*' -print0 2>/dev/null)

run rm -rf "$BRAIN/cluster/tersagor"
run mkdir -p "$BRAIN/cluster/tersagor"
if [[ "$DRY_RUN" != true ]]; then
cat > "$BRAIN/cluster/tersagor/README.md" <<'EOF'
# Tersagor — brain link stub

**Canonical:** https://github.com/igareosh/tersagor  
**VM:** `tersagor.prichindel.local` (192.168.100.68) · `/data/tersagor`

Cluster mirror + ops docs: `docs/brain-export/` on **igareosh/tersagor**.

| Need | Where |
|------|--------|
| Existence | `docs/brain-export/cluster-tersagor/EXISTENCE.md` |
| Commands | `docs/COMMANDS.md` |
| Deploy | `deploy/deploy-on-vm.sh` |
| Operator notify | `scripts/tersagor-operator-notify.sh` (brain orchestration) |
EOF
fi

while IFS= read -r -d '' f; do
  base="$(basename "$f")"
  [[ "$base" == "tersagor-operator-notify.sh" || "$base" == "SCRIPT-RUNBOOK-tersagor-operator-notify.md" ]] && continue
  run rm -f "$f"
done < <(find "$BRAIN/scripts" -maxdepth 1 -iname '*tersagor*' -print0 2>/dev/null)

for p in cluster/prichindel/nginx-tersagor.prichindel.com.conf \
  cluster/prichindel/nginx-tersagor-bot.prichindel.com.conf \
  cluster/prichindel/nginx-lounge.tersagor.prichindel.com.conf; do
  link_stub_file "$BRAIN/$p" "https://github.com/igareosh/tersagor/tree/main/docs/brain-export/cluster-prichindel/$(basename "$p")" "$(basename "$p")"
done

run rm -f "$BRAIN/.github/workflows/tersagor-agent-ci.yml" "$BRAIN/src/REMOVED-TERSAGOR-AGENT.md" "$BRAIN/.cursor/rules/cursor-operator-notify-tersagor.mdc" 2>/dev/null || true

bash "$BRAIN/scripts/verify-brain-no-hesperia-product-ingest.sh" "$BRAIN"
echo "brain-cleanup-local: OK"
