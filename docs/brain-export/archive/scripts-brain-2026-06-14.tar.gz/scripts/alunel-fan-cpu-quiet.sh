#!/usr/bin/env bash
# alunel X8DT3-F — pwm1+pwm2 manual, duty from max(CPU cores, RAM DIMM, board zone).
# IPMI enabled (JPB 1-2, 2026-05-26); BMC at 192.168.1.115.
# BIOS override detection: if RPM stays high while OS pwm is low, stop writing pwm.
set -euo pipefail

W83795_DEV="pci0000:00/0000:00:1f.3/i2c-0/0-002f"
PWM_SYSFS="/sys/devices/${W83795_DEV}"
STATE_FILE="${ALUNEL_FAN_STATE:-/run/alunel-fan-pwm.state}"
PWM_MIN=32
PWM_MAX=200
PWM_IDLE=36
TEMP_CPU_START=58
TEMP_CPU_FULL=72
TEMP_RAM_START=68
TEMP_RAM_FULL=78
TEMP_BOARD_START=60   # w83795 temp1 (drive-cage zone); starts contributing at 60°C
TEMP_BOARD_FULL=75    # full PWM_MAX at 75°C; high limit is 85°C
RAMP_UP_MAX=8
RAMP_DOWN_MAX=4
BIOS_OVERRIDE_RPM=2400
BIOS_OVERRIDE_PWM=96

modprobe w83795 jc42 coretemp 2>/dev/null || true

if [[ ! -d "$PWM_SYSFS" ]] || [[ ! -f "${PWM_SYSFS}/pwm1" ]]; then
  echo "alunel-fan-cpu-quiet: W83795 sysfs missing at ${PWM_SYSFS}" >&2
  exit 1
fi

heat_temps_c() {
  sensors -u 2>/dev/null | awk '
    /^coretemp/ { cpu=1; jc42=0; w837=0; next }
    /^jc42/     { jc42=1; cpu=0; w837=0; next }
    /^w83795/   { w837=1; cpu=0; jc42=0; next }
    /^Adapter:/ { next }
    cpu && /_input:/ {
      for (i = 1; i <= NF; i++) if ($i ~ /^[0-9.]+$/) { v = $i + 0; if (v > cmax) cmax = v }
    }
    jc42 && /^  temp1_input:/ { v = $2 + 0; if (v > rmax) rmax = v }
    w837 && /^  temp[78]_input:/ { v = $2 + 0; if (v > cmax) cmax = v }
    w837 && /^  temp1_input:/  { v = $2 + 0; if (v > bmax) bmax = v }
    END {
      if (cmax <= 0) cmax = 45
      if (rmax <= 0) rmax = 55
      if (bmax <= 0) bmax = 50
      printf "%.0f %.0f %.0f\n", cmax, rmax, bmax
    }'
}

calc_pwm_from_temp() {
  local temp="$1" t0="$2" t1="$3"
  awk -v t="$temp" -v t0="$t0" -v t1="$t1" -v pmin="$PWM_MIN" -v pmax="$PWM_MAX" '
    BEGIN {
      if (t <= t0) { print pmin; exit }
      if (t >= t1) { print pmax; exit }
      print int(pmin + (t - t0) * (pmax - pmin) / (t1 - t0))
    }'
}

calc_pwm_target() {
  local cpu_c="$1" ram_c="$2" board_c="$3"
  local p_cpu p_ram p_board
  p_cpu=$(calc_pwm_from_temp "$cpu_c" "$TEMP_CPU_START" "$TEMP_CPU_FULL")
  p_ram=$(calc_pwm_from_temp "$ram_c" "$TEMP_RAM_START" "$TEMP_RAM_FULL")
  p_board=$(calc_pwm_from_temp "$board_c" "$TEMP_BOARD_START" "$TEMP_BOARD_FULL")
  awk -v a="$p_cpu" -v b="$p_ram" -v c="$p_board" -v idle="$PWM_IDLE" '
    BEGIN {
      p = (a > b ? a : b); p = (p > c ? p : c)
      if (p < idle) p = idle
      print p
    }'
}

read_state_pwm() {
  if [[ -f "$STATE_FILE" ]]; then
    awk '{print $1}' "$STATE_FILE" 2>/dev/null || echo "$PWM_IDLE"
  else
    echo "$PWM_IDLE"
  fi
}

read_state_flag() {
  if [[ -f "$STATE_FILE" ]]; then
    awk '{print $2+0}' "$STATE_FILE" 2>/dev/null || echo 0
  else
    echo 0
  fi
}

write_state() {
  local pwm="$1" flag="${2:-0}"
  echo "${pwm} ${flag}" >"$STATE_FILE"
}

ramp_pwm() {
  local target="$1" last="$2"
  awk -v t="$target" -v l="$last" -v up="$RAMP_UP_MAX" -v down="$RAMP_DOWN_MAX" '
    BEGIN {
      if (t > l + up) { print l + up; exit }
      if (t < l - down) { print l - down; exit }
      print t
    }'
}

fan7_rpm() {
  sensors w83795adg-i2c-0-2f 2>/dev/null | awk '/^fan7:/ { gsub(/[^0-9]/,"",$2); print $2+0; exit }'
}

board_temp1_c() {
  sensors w83795adg-i2c-0-2f 2>/dev/null | awk '/^temp1:/ { gsub(/[+°C]/,"",$2); print $2+0; exit }'
}

bios_override_active() {
  local rpm pwm_val
  rpm="$(fan7_rpm)"
  pwm_val="$(cat "${PWM_SYSFS}/pwm1" 2>/dev/null || echo 0)"
  [[ -n "$rpm" && "$rpm" -ge "$BIOS_OVERRIDE_RPM" && "$pwm_val" -le "$BIOS_OVERRIDE_PWM" ]]
}

apply_pwm() {
  local val="$1"
  echo 1 >"${PWM_SYSFS}/pwm1_enable"
  echo 1 >"${PWM_SYSFS}/pwm2_enable"
  echo "$val" >"${PWM_SYSFS}/pwm1"
  echo "$val" >"${PWM_SYSFS}/pwm2"
}

compute_pwm() {
  read -r cpu_c ram_c board_c < <(heat_temps_c)
  local target last smoothed flag=0
  target=$(calc_pwm_target "$cpu_c" "$ram_c" "$board_c")
  last=$(read_state_pwm)
  smoothed=$(ramp_pwm "$target" "$last")

  if bios_override_active; then
    flag=1
    smoothed="$last"
    if [[ "${ALUNEL_FAN_DEBUG:-}" == 1 ]]; then
      logger -t alunel-fan "bios_override rpm=$(fan7_rpm) pwm=$(cat ${PWM_SYSFS}/pwm1) board_temp1=${board_c}C — not writing pwm"
    fi
  fi

  write_state "$smoothed" "$flag"
  printf '%s %s %s %s %s %s\n' "$cpu_c" "$ram_c" "$board_c" "$target" "$smoothed" "$flag"
}

case "${1:-daemon}" in
  report)
    read -r cpu_c ram_c board_c target smoothed flag < <(compute_pwm)
    echo "cpu=${cpu_c}C ram=${ram_c}C board=${board_c}C target_pwm=${target} state_pwm=${smoothed} bios_override=${flag} fan7_rpm=$(fan7_rpm)"
    sensors 2>/dev/null | grep -E '^fan[24678]:|^pwm|intrusion' || true
    ;;
  once|status)
    read -r cpu_c ram_c board_c target smoothed flag < <(compute_pwm)
    if [[ "$flag" != "1" ]]; then
      apply_pwm "$smoothed"
    fi
    echo "cpu=${cpu_c}C ram=${ram_c}C board=${board_c}C pwm=${smoothed}/255 target=${target} bios_override=${flag} fan7=$(fan7_rpm)RPM"
    sensors 2>/dev/null | grep -E '^fan[24678]:|^pwm|intrusion' || true
    ;;
  daemon)
    while true; do
      read -r cpu_c ram_c board_c target smoothed flag < <(compute_pwm)
      if [[ "$flag" != "1" ]]; then
        apply_pwm "$smoothed" 2>/dev/null || true
      fi
      if [[ "${ALUNEL_FAN_DEBUG:-}" == 1 ]]; then
        logger -t alunel-fan "cpu=${cpu_c}C ram=${ram_c}C board=${board_c}C pwm=${smoothed} target=${target} bios_override=${flag} rpm=$(fan7_rpm)"
      fi
      sleep "${ALUNEL_FAN_INTERVAL:-20}"
    done
    ;;
  *)
    echo "Usage: $0 {once|status|report|daemon}" >&2
    exit 2
    ;;
esac
