#!/usr/bin/env bash
# Phase 4: Entry script workflow_automation_run.sh once (Chroma can be skipped in CI / no-venv hosts).
# Exit 0 = chain completed (preflight may still run unless CHROMA_SKIP_PREFLIGHT=1).

set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
cd "$REPO_ROOT"
export REPO_ROOT WORKFLOW_REPO_ROOT="$REPO_ROOT"

# Default: skip Chroma in automated test to avoid prichindel-only venv/SSH; override with CHROMA_SKIP_PREFLIGHT=0
export CHROMA_SKIP_PREFLIGHT="${CHROMA_SKIP_PREFLIGHT:-1}"
export WORKFLOW_QUIET=1

if ! bash "$REPO_ROOT/scripts/workflow_automation_run.sh" once; then
  echo "FAIL: workflow_automation_run.sh once"
  exit 1
fi
if [[ ! -f "$REPO_ROOT/governance/workflow_driver_current.txt" ]]; then
  echo "FAIL: missing workflow_driver_current.txt"
  exit 1
fi
echo "PASS: workflow_automation_run.sh once (CHROMA_SKIP_PREFLIGHT=${CHROMA_SKIP_PREFLIGHT})"
exit 0
