#!/usr/bin/env bash
# Phase 1: Test orchestrator heartbeat. Run from repo root. Exit 0 = pass, 1 = fail.
# Prod-usable: no destructive actions; safe to run on prichindel or in CI.

set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
cd "$REPO_ROOT"

HEARTBEAT_FILE="${REPO_ROOT}/governance/workflow_heartbeat.txt"

python3 scripts/workflow_orchestrator.py --output "$HEARTBEAT_FILE" 2>/dev/null || true

if [[ ! -f "$HEARTBEAT_FILE" ]]; then
  echo "FAIL: heartbeat file not created: $HEARTBEAT_FILE"
  exit 1
fi

content=$(cat "$HEARTBEAT_FILE")
for key in last_run captain_on_deck "OPEN:" "IN_PROGRESS:"; do
  if ! echo "$content" | grep -q "$key"; then
    echo "FAIL: heartbeat missing expected key: $key"
    exit 1
  fi
done

echo "PASS: heartbeat file exists and contains required keys"
exit 0
