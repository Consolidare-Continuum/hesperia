# Workflow automation — phased test scripts

**Purpose**: Production-usable test scripts for the workflow automation product. Phased (one concern per script); no single long script. Ref: [cluster/workflow-automation/README.md](../../cluster/workflow-automation/README.md), [governance/GENA-TASK-TESTING-PRODUCT.md](../../governance/GENA-TASK-TESTING-PRODUCT.md).

**Run from repo root.** Optional: `export WORKFLOW_REPO_ROOT=/path/to/cursor` if not running from repo.

| Script | Phase | What it tests |
|--------|--------|----------------|
| test_01_heartbeat.sh | 1 | Orchestrator writes heartbeat; file exists and contains last_run, captain_on_deck, OPEN, IN_PROGRESS. |
| test_02_driver_current.sh | 2 | Driver (--no-wait) writes workflow_driver_current.txt; file exists and non-empty. |
| test_03_smoke_runner.sh | 3 | Orchestrator + driver --no-wait run; heartbeat and driver current files present. |
| test_04_automation_entry.sh | 4 | `scripts/workflow_automation_run.sh` **once**; driver current present. Default **`CHROMA_SKIP_PREFLIGHT=1`** (set `0` to require live Chroma). |

**Order**: Run 01, 02, 03 in sequence for full check. Each can be run alone. Exit 0 = pass, non-zero = fail.

```bash
cd /data/workspaces/cursor   # or your repo root
bash scripts/workflow_tests/test_01_heartbeat.sh
bash scripts/workflow_tests/test_02_driver_current.sh
bash scripts/workflow_tests/test_03_smoke_runner.sh
```

Or all: `for f in scripts/workflow_tests/test_0*.sh; do bash "$f" || exit 1; done`

**Env**: `WORKFLOW_REPO_ROOT`, `DRIVER_STEP_TIMEOUT_SEC` (test_03 only; default 10).
