#!/usr/bin/env bash
# Phase 3: Smoke test — run step1 (orchestrator + driver --no-wait) then step2 with short timeout.
# Does not wait for executor to finish; only checks that the chain runs and state files exist.
# Prod-usable: runs real scripts; export DRIVER_STEP_TIMEOUT_SEC=5 to avoid long wait if driver polls.

set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
cd "$REPO_ROOT"

export REPO_ROOT
export DRIVER_STEP_TIMEOUT_SEC="${DRIVER_STEP_TIMEOUT_SEC:-10}"
LOG_FILE="${REPO_ROOT}/governance/workflow_automation.log"

# Run step1 only (orchestrator + driver); step2 would run executor — we stop after step1 for smoke
python3 scripts/workflow_orchestrator.py >> "$LOG_FILE" 2>&1
python3 scripts/workflow_driver.py --no-wait >> "$LOG_FILE" 2>&1

for f in governance/workflow_heartbeat.txt governance/workflow_driver_current.txt; do
  if [[ ! -f "$REPO_ROOT/$f" ]]; then
    echo "FAIL: smoke test missing $f"
    exit 1
  fi
done

echo "PASS: smoke runner completed; heartbeat and driver current present"
exit 0
