#!/usr/bin/env bash
# Phase 2: Test driver writes current step. Run from repo root. Exit 0 = pass, 1 = fail.
# Uses --no-wait so we do not poll; only check that current step file is written.
# Prod-usable: read-only plus one driver invocation; safe on prichindel or CI.

set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
cd "$REPO_ROOT"

CURRENT_FILE="${REPO_ROOT}/governance/workflow_driver_current.txt"

python3 scripts/workflow_driver.py --no-wait 2>/dev/null || true

if [[ ! -f "$CURRENT_FILE" ]]; then
  echo "FAIL: driver current file not created: $CURRENT_FILE"
  exit 1
fi

# File may contain "No OPEN tasks" or a task line; either is valid
if ! [[ -s "$CURRENT_FILE" ]]; then
  echo "FAIL: driver current file is empty"
  exit 1
fi

echo "PASS: driver current file exists and non-empty"
exit 0
