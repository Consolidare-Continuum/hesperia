#!/usr/bin/env bash
# Run **on prichindel** as **igareosh** (local shell, console, or existing SSH session).
# Do **not** run as root: git pull needs igareosh's GitHub key; authorized_keys must be igareosh's.
# Idempotent: appends alunel MCP/outbound SSH pubkey if not already present.
# Ref: cluster/alunel/CURSOR-DEV-HOST.md
set -euo pipefail
if [ "$(id -u)" -eq 0 ]; then
  echo "FAIL: run as igareosh, not root. Example: exit (leave root), then:" >&2
  echo "  cd /data/workspaces/cursor && git pull && bash scripts/prichindel-authorize-alunel-ssh.sh" >&2
  echo "Or: sudo -u igareosh -H bash -lc 'cd /data/workspaces/cursor && git pull && bash scripts/prichindel-authorize-alunel-ssh.sh'" >&2
  exit 1
fi
REPO_ROOT="${REPO_ROOT:-/data/workspaces/cursor}"
PUB="$REPO_ROOT/cluster/alunel/alunel-to-prichindel.pub"
AUTH="${HOME}/.ssh/authorized_keys"
if [ ! -f "$PUB" ]; then
  echo "FAIL: missing $PUB (git pull cursor repo on prichindel)" >&2
  exit 1
fi
mkdir -p "${HOME}/.ssh"
chmod 700 "${HOME}/.ssh"
touch "$AUTH"
chmod 600 "$AUTH"
if grep -qF 'alunel-to-prichindel@cluster' "$AUTH" 2>/dev/null; then
  echo "OK: alunel pubkey already in $AUTH"
  exit 0
fi
cat "$PUB" >> "$AUTH"
echo "OK: appended alunel pubkey to $AUTH"
echo "From alunel: ssh prichindel 'echo ok'"
