# Runbook — Windows laptop service (LAMAITA and cluster Windows nodes)

**When**: Routine or on-demand maintenance on a **Windows cluster laptop** — **LAMAITA** (main), **olgahere**, **fluturas** when assigned. Triggers: operator says *"sweep the laptop"*, *"LAMAITA maintenance"*, *"I cleaned Downloads — finish the rest"*, Abelard EOD hygiene, or disk/health check before travel. **Owner: Abelard.**

**Scope**: **Service + diligent sweep** of the machine. **Operator-owned folders** (typically **Downloads**, **Desktop**) are cleaned by **igareosh** first unless the task explicitly includes them. Abelard **does not delete** OneDrive sync roots, Proton paths, or dev trees without a separate task.

**Ref**: [cluster/lamaita/README.md](../cluster/lamaita/README.md) (canonical LAMAITA), [foundational/lessons-learned/session-2026-03-24.md](../foundational/lessons-learned/session-2026-03-24.md), [scripts/SCRIPT-RUNBOOK-connection-resolution.md](SCRIPT-RUNBOOK-connection-resolution.md) (SSH failures).

---

## 1. Roles split

| Who | Does |
|-----|------|
| **Operator (igareosh)** | Cleans **Downloads** / **Desktop** when asked; keeps personal sync folders intentional. |
| **Abelard** | Everything else: temp, recycle bin, DISM/Defender, restore point, caches, WU quality check, health report, close-out. |

**Protected (do not touch without express permission)**:

- **olgahere** **G:** (TOSHIBA EXT) — private; see [cluster/olgahere/README.md](../cluster/olgahere/README.md).
- Operator-declared clean folders — treat as **out of scope** for deletion (still OK to **report** size).

---

## 2. Access (execute from Linux dev office)

**Primary path**: **alunel** → SSH → laptop.

| Item | LAMAITA value |
|------|----------------|
| Hostname | **lamaita** |
| LAN IP | **192.168.100.4** |
| SSH server | **Bitvise** (not OpenSSH) |
| **Maintenance login** | **`ssh -o User=igare -i ~/.ssh/id_rsa 192.168.100.4`** |
| Profile | **`C:\Users\igare`** (real admin; elevation for maintenance) |
| Bitvise session user | **`igareosh`** → `C:\Users\BvSsh_lamaita` — MCP/Cursor only; **not** for elevated maintenance |

**Before SSH-heavy work**: check [governance/agent_ssh_cert_status.txt](../governance/agent_ssh_cert_status.txt). If **host key changed** on alunel: `ssh-keygen -R 192.168.100.4` then reconnect.

**Off-LAN**: Tailscale / MagicDNS per [cluster/lamaita/README.md](../cluster/lamaita/README.md) and [cluster/ceres/HOTSPOT-TUNNEL-FIX.md](../cluster/ceres/HOTSPOT-TUNNEL-FIX.md).

---

## 3. Standard pass (recommended order)

### 3.1 Deploy scripts to the laptop

From **alunel** (repo at `/data/workspaces/cursor`):

```bash
scp scripts/lamaita-abelard-sweep.ps1 alunel:/tmp/
ssh alunel 'scp /tmp/lamaita-abelard-sweep.ps1 igare@192.168.100.4:C:/Users/igare/AppData/Local/Temp/'
scp scripts/lamaita-abelard-finish.ps1 alunel:/tmp/
ssh alunel 'scp /tmp/lamaita-abelard-finish.ps1 igare@192.168.100.4:C:/Users/igare/AppData/Local/Temp/'
```

Replace **192.168.100.4** with the target Windows node IP when not LAMAITA.

### 3.2 Run sweep (excludes Downloads + Desktop in script logic)

```bash
ssh alunel 'ssh -o User=igare -i ~/.ssh/id_rsa 192.168.100.4 \
  "powershell -NoProfile -ExecutionPolicy Bypass -File C:\\Users\\igare\\AppData\\Local\\Temp\\lamaita-abelard-sweep.ps1"'
```

**Script**: [scripts/lamaita-abelard-sweep.ps1](lamaita-abelard-sweep.ps1)

**Does**:

- Recycle bin; user + `%LocalAppData%\Temp` + `C:\Windows\Temp`
- **DISM** `/StartComponentCleanup` then `/ScanHealth`
- **SFC** `/verifyonly` (can run **1–2+ hours** after DISM — see §4)
- **Defender** signature update + quick scan
- Restore point **`Abelard YYYY-MM-DD`**
- Delivery Optimization cache, thumbnail/icon caches
- Profile size report (skips Downloads/Desktop)
- Pending WU count (installs quality updates if ≤15 pending)
- Verifies task **`Abelard-LamaitaDisplayPersist`**

**Log on laptop**: `%TEMP%\abelard-lamaita-sweep-*.log`

### 3.3 If operator already cleaned Downloads

Confirm operator pass complete → run **§3.2 only**. Do **not** purge Downloads/Desktop.

Quick size check (report only):

```bash
ssh alunel 'ssh -o User=igare -i ~/.ssh/id_rsa 192.168.100.4 \
  "powershell -NoProfile -Command \"\$d=Join-Path \$env:USERPROFILE Downloads; \$f=Get-ChildItem \$d -Recurse -Force -EA 0 -File; Write-Output ('\''items='\''+\$f.Count+'\'' MB='\''+[math]::Round((\$f|Measure Length -Sum).Sum/1MB,1))\""'
```

### 3.4 Close-out (SFC stuck or session hung)

If **SFC** or sweep PowerShell runs **>90 minutes** with no log progress, or SSH session dies with **exit 255**:

```bash
ssh alunel 'ssh -o User=igare -i ~/.ssh/id_rsa 192.168.100.4 \
  "powershell -NoProfile -ExecutionPolicy Bypass -File C:\\Users\\igare\\AppData\\Local\\Temp\\lamaita-abelard-finish.ps1"'
```

**Script**: [scripts/lamaita-abelard-finish.ps1](lamaita-abelard-finish.ps1)

**Does**: stops **`lamaita-abelard-sweep`** PowerShell jobs and **`sfc.exe`** if still running; scans **CBS.log** for today's corrupt/repair lines; appends closure to main sweep log; reports disk + **PendingReboot** + display task.

**Acceptance when SFC stopped early**: **DISM ScanHealth exit 0** + CBS today has **no** `Cannot repair` / `corrupt` / `integrity violation` lines.

---

## 4. Verify (must pass before DONE)

```bash
ssh alunel 'ssh -o User=igare -i ~/.ssh/id_rsa 192.168.100.4 \
  "tasklist /FI \"IMAGENAME eq sfc.exe\" & tasklist /FI \"IMAGENAME eq dism.exe\" & \
   powershell -NoProfile -Command \"(Get-PSDrive C).Free/1GB; \
   (New-Object -ComObject Microsoft.Update.Session).CreateUpdateSearcher().Search('\''IsInstalled=0'\'').Updates.Count; \
   Test-Path '\''HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update\\RebootRequired'\''\""'
```

| Check | Pass |
|-------|------|
| No `sfc.exe` / `dism.exe` left from maintenance | INFO: No tasks… |
| **C:** free space | Report GB free (expect improvement after temp/DISM) |
| Pending WU | **0** or documented install + reboot if required |
| PendingReboot | **False** unless WU installed reboot-needed updates |
| Defender quick scan | Exit **0** in sweep log |
| DISM ScanHealth | Exit **0** in sweep log |
| Task **Abelard-LamaitaDisplayPersist** | **Ready** (LAMAITA) |

Update pass summary in [cluster/lamaita/README.md](../cluster/lamaita/README.md) § Abelard standard maintenance.

---

## 5. Optional / periodic (not every sweep)

| Action | Script / doc | When |
|--------|----------------|------|
| AppX debloat (one-shot) | [scripts/lamaita-debloat-once.ps1](lamaita-debloat-once.ps1) | Fresh install or bloat return; run **elevated once** |
| Display stack persist | [scripts/lamaita-abelard-persist-display.cmd](lamaita-abelard-persist-display.cmd), scheduled task | After Intel GPU driver update if shimmer returns |
| WU feature pin | `cluster/lamaita/README.md` | **25H2** + 365d feature defer; quality updates **not** deferred |
| MCP on laptop | [scripts/deploy-mcp-config-global.ps1](deploy-mcp-config-global.ps1) | After mcp-config change — see [SCRIPT-RUNBOOK-mcp-chroma-session.md](SCRIPT-RUNBOOK-mcp-chroma-session.md) |

---

## 6. Failure modes

| Failure | Symptom | Action |
|---------|---------|--------|
| SSH **Permission denied** as `igareosh` | Expected for maintenance | Use **`User=igare`** + **`~/.ssh/id_rsa`** from **alunel** |
| **Host key changed** | SSH fails from alunel | `ssh-keygen -R 192.168.100.4` on alunel; reconnect |
| Nested **PowerShell over SSH** eats `$` | Script errors, empty output | Deploy **`.ps1` file** to laptop; run with `-File`; prefer **`reg.exe`** for registry per session-2026-03-24 |
| **SFC verifyonly** runs 2h+ | Main sweep blocked; SSH exit **255** if killed | Run **lamaita-abelard-finish.ps1**; rely on DISM + CBS check (§3.4) |
| Phase2 **INetCache** hang | Long-running PowerShell | Skip; sweep + finish cover essentials |
| **Checkpoint-Computer** fails | Restore point not created | Confirm System Restore enabled on **C:**; not a blocker if DISM/Defender pass |
| **librarymaster** / wrong host SSH | Commands hit wrong machine | Always hop **alunel** → **192.168.100.4**; never infer host from `/data/altitudine/` path |

---

## 7. What we do not do in this runbook

- **Linux** cluster maintenance → [SCRIPT-RUNBOOK-maintenance.md](SCRIPT-RUNBOOK-maintenance.md)
- **Brain repo sync** to `C:\ceres_proton_drive\cursor` → separate task (git bundle / destructive sync)
- **Mass file deletion** in OneDrive, `.vscode`, `AppData` dev caches — report sizes only unless tasked
- **Feature upgrade** Windows — policy defers features; quality updates OK

---

## 8. Evidence trail

Logs on laptop (retain until next pass):

- `%TEMP%\abelard-lamaita-sweep-*.log`
- `%TEMP%\abelard-lamaita-finish-*.log`
- `%TEMP%\abelard-lamaita-sweep-phase3-*.log` (if split phase used)

Repo: update **cluster/lamaita/README.md** maintenance bullet with date, GB free, DISM/Defender/SFC disposition.

---

SIGNED: Architecture (Ethan) | team runbook | 2026-06-01 | Windows laptop service (LAMAITA 2026-06-01 pass)
