#!/usr/bin/env bash
# One-time init: create SSH CA and agent identity key on alunel.
# Run as igareosh on alunel. Idempotent.
# After running: hand off agent_ca.pub to Abelard for VM-wide trust installation.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CA_DIR="$HOME/.ssh/agent-ca"
mkdir -p "$CA_DIR"
chmod 700 "$CA_DIR"

# CA keypair (permanent — never rotates, never leaves alunel)
if [ ! -f "$CA_DIR/agent_ca" ]; then
    ssh-keygen -t ed25519 -f "$CA_DIR/agent_ca" -C "cluster-agent-ca@alunel" -N ""
    echo "CA created: $CA_DIR/agent_ca"
else
    echo "CA exists: $CA_DIR/agent_ca"
fi

# Agent identity key (stable — private key never changes; cert rotates daily)
if [ ! -f "$CA_DIR/id_agent" ]; then
    ssh-keygen -t ed25519 -f "$CA_DIR/id_agent" -C "agent@cluster" -N ""
    echo "Agent identity key created: $CA_DIR/id_agent"
else
    echo "Agent identity key exists: $CA_DIR/id_agent"
fi

# First cert issuance
bash "$SCRIPT_DIR/agent-ssh-cert-renew.sh"

echo ""
echo "=== HANDOFF TO ABELARD ==="
echo "Run: bash scripts/agent-ssh-deploy-trust.sh"
echo "Or manually per VM: bash scripts/agent-ssh-install-trust.sh $CA_DIR/agent_ca.pub"
echo ""
echo "CA public key to distribute:"
cat "$CA_DIR/agent_ca.pub"
