#!/usr/bin/env bash
# Add ceres.prichindel.com to primary Cloudflare tunnel → ssh://192.168.100.4:22 (CERES OpenSSH).
# Run on prichindel. Needs: cf-api-token (Tunnel Edit), cf-account-id, Zone DNS token for CNAME.
# Usage: sudo bash scripts/cf-tunnel-add-ceres.sh
# If API fails: add ingress and CNAME manually in Cloudflare dashboard (Networks > Tunnels > primary > Public Hostname).

set -e
HOSTNAME="ceres.prichindel.com"
SERVICE="ssh://192.168.100.4:22"

AID=$(sudo cat /root/.secrets/cloudflare/cf-account-id 2>/dev/null | tr -d '\n\r')
if [ -z "$AID" ]; then
  echo "Missing cf-account-id. Set: echo -n '<account_id>' | sudo tee /root/.secrets/cloudflare/cf-account-id"
  exit 1
fi

TOKEN=$(sudo cat /root/.secrets/cloudflare/cf-api-token 2>/dev/null | tr -d '\n\r')
if [ -z "$TOKEN" ]; then
  echo "Missing cf-api-token (Tunnel Edit). Cannot update ingress via API."
  exit 1
fi

api() { curl -sS -H "Authorization: Bearer $TOKEN" "$@"; }

echo "=== List tunnels (account $AID) ==="
TUNNELS=$(api "https://api.cloudflare.com/client/v4/accounts/$AID/cfd_tunnel")
if ! echo "$TUNNELS" | jq -e '.success' >/dev/null 2>&1; then
  echo "List tunnels failed: $(echo "$TUNNELS" | jq -r '.errors[0].message // .')"
  echo "Add ingress manually: Zero Trust > Networks > Tunnels > primary > Public Hostname: $HOSTNAME -> $SERVICE"
  exit 1
fi

TUNNEL_ID=$(echo "$TUNNELS" | jq -r '.result[0].id // empty')
TUNNEL_NAME=$(echo "$TUNNELS" | jq -r '.result[0].name // empty')
if [ -z "$TUNNEL_ID" ]; then
  echo "No tunnel found in account."
  exit 1
fi
echo "Using tunnel: $TUNNEL_NAME ($TUNNEL_ID)"

echo "=== Get tunnel config ==="
CONFIG=$(api "https://api.cloudflare.com/client/v4/accounts/$AID/cfd_tunnel/$TUNNEL_ID/configurations")
if ! echo "$CONFIG" | jq -e '.success' >/dev/null 2>&1; then
  echo "Get config failed: $(echo "$CONFIG" | jq -r '.errors[0].message // .')"
  exit 1
fi

INGRESS=$(echo "$CONFIG" | jq -r '.result.config.ingress // .result.ingress // []')
# Add ceres: drop existing ceres if any, add ceres entry before catch-all
NEW_INGRESS=$(echo "$INGRESS" | jq --arg h "$HOSTNAME" --arg s "$SERVICE" \
  'def catchall: .service == "http_status:404"; ([.[] | select(.hostname != "ceres.prichindel.com" and (catchall | not))] + [{hostname: $h, service: $s}] + [.[] | select(catchall)])')
CFG=$(echo "$CONFIG" | jq -r '.result.config // .result')
BODY=$(echo "$CFG" | jq --argjson ing "$NEW_INGRESS" '. | .ingress = $ing | {config: .}')
PUT=$(api -X PUT "https://api.cloudflare.com/client/v4/accounts/$AID/cfd_tunnel/$TUNNEL_ID/configurations" -H "Content-Type: application/json" -d "$BODY")
if ! echo "$PUT" | jq -e '.success' >/dev/null 2>&1; then
  echo "Put config failed: $(echo "$PUT" | jq -r '.errors[0].message // .')"
  echo "Add manually: Zero Trust > Networks > Tunnels > $TUNNEL_NAME > Public Hostname: $HOSTNAME -> $SERVICE"
  exit 1
fi
echo "Ingress updated: $HOSTNAME -> $SERVICE"

TUNNEL_CNAME="${TUNNEL_ID}.cfargotunnel.com"
ZONE_TOKEN=$(sudo grep -E '^dns_cloudflare_api_token\s*=' /root/.secrets/certbot/cloudflare.ini 2>/dev/null | sed 's/.*=\s*//' | tr -d ' \r\n')
if [ -z "$ZONE_TOKEN" ]; then
  ZONE_TOKEN="$TOKEN"
fi
ZONES=$(curl -sS -H "Authorization: Bearer $ZONE_TOKEN" "https://api.cloudflare.com/client/v4/zones?name=prichindel.com")
ZONE_ID=$(echo "$ZONES" | jq -r '.result[0].id // empty')
if [ -z "$ZONE_ID" ]; then
  echo "Zone prichindel.com not found. Add CNAME manually: ceres -> $TUNNEL_CNAME"
  exit 0
fi
EXISTING=$(curl -sS -H "Authorization: Bearer $ZONE_TOKEN" "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records?name=$HOSTNAME")
if echo "$EXISTING" | jq -e '.result[0]' >/dev/null 2>&1; then
  echo "DNS record $HOSTNAME already exists. Update in dashboard if target changed."
else
  ADD_DNS=$(curl -sS -H "Authorization: Bearer $ZONE_TOKEN" -X POST "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records" \
    -H "Content-Type: application/json" \
    -d "{\"type\":\"CNAME\",\"name\":\"ceres\",\"content\":\"$TUNNEL_CNAME\",\"ttl\":1,\"proxied\":false}")
  if echo "$ADD_DNS" | jq -e '.success' >/dev/null 2>&1; then
    echo "DNS CNAME added: ceres.prichindel.com -> $TUNNEL_CNAME"
  else
    echo "DNS add failed: $(echo "$ADD_DNS" | jq -r '.errors[0].message // .'). Add manually: ceres CNAME $TUNNEL_CNAME (DNS only)."
  fi
fi

echo "Done. SSH via tunnel: ssh igare@ceres.prichindel.com (from anywhere). Set Zero Trust / Access policy for ceres.prichindel.com if required."
