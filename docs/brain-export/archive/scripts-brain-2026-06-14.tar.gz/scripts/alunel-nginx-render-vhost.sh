#!/usr/bin/env bash
# Render alunel Proxmox UI nginx vhost — LAN always; Tailscale listens only when IP exists.
set -euo pipefail

LAN_IP="${ALUNEL_LAN_IP:-192.168.100.62}"
TEMPLATE="${ALUNEL_NGINX_TEMPLATE:-/etc/nginx/templates/alunel.prichindel.com.conf.template}"
OUT="${ALUNEL_NGINX_VHOST:-/etc/nginx/sites-available/alunel.prichindel.com.conf}"
TS_IF="${ALUNEL_NGINX_TAILSCALE_IF:-tailscale0}"

ts_ip=""
if ip link show "$TS_IF" &>/dev/null; then
  ts_ip="$(ip -4 -o addr show dev "$TS_IF" 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1 || true)"
fi
if [[ -z "$ts_ip" ]] && command -v tailscale &>/dev/null; then
  ts_ip="$(tailscale ip -4 2>/dev/null | head -1 || true)"
fi

ts_listen_80=""
ts_listen_https=""
if [[ -n "$ts_ip" ]] && ip -4 addr show dev "$TS_IF" 2>/dev/null | grep -q "inet ${ts_ip}/"; then
  ts_listen_80="    listen ${ts_ip}:80;"
  ts_listen_https="    listen ${ts_ip}:443 ssl;"
fi

if [[ ! -f "$TEMPLATE" ]]; then
  echo "alunel-nginx-render-vhost: missing template $TEMPLATE" >&2
  exit 1
fi

tmp="$(mktemp)"
sed \
  -e "s|@LAN_IP@|${LAN_IP}|g" \
  -e "s|@TS_LISTEN_80@|${ts_listen_80}|g" \
  -e "s|@TS_LISTEN_HTTPS@|${ts_listen_https}|g" \
  "$TEMPLATE" >"$tmp"
install -m 644 "$tmp" "$OUT"
rm -f "$tmp"

if [[ -n "$ts_ip" && -n "$ts_listen_https" ]]; then
  echo "rendered ${OUT} (LAN=${LAN_IP}, tailscale=${ts_ip})"
else
  echo "rendered ${OUT} (LAN=${LAN_IP}, tailscale=deferred)"
fi
