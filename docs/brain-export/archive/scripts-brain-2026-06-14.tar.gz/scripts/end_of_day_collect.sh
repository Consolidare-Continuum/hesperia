#!/usr/bin/env bash
# Collect-only: git diff summary, active.md OPEN hints, Chroma heartbeat, optional workflow API.
# Does not commit. Human or Cursor runs END-OF-DAY-WORKFLOW.md steps after reviewing output.
# Usage: ./scripts/end_of_day_collect.sh [--out FILE]  (default: stdout)

set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO_ROOT"
OUT_FILE=""
if [[ "${1:-}" == "--out" && -n "${2:-}" ]]; then
  OUT_FILE="$2"
fi

section() {
  echo ""
  echo "=== $1 ==="
}

collect() {
  echo "cursor EOD collect $(date -u +"%Y-%m-%dT%H:%M:%SZ")"

  section "git status (short)"
  git status --short || true

  section "git diff --stat (unstaged + staged)"
  git diff --stat HEAD 2>/dev/null || true

  section "active.md (first 120 lines)"
  if [[ -f active.md ]]; then
    head -120 active.md
  else
    echo "(no active.md)"
  fi

  section "Chroma heartbeat"
  CHROMA_URL="${CHROMA_SERVER_URL:-http://127.0.0.1:8002}"
  if curl -sS --max-time 5 "${CHROMA_URL%/}/api/v2/heartbeat" -o /tmp/chroma_hb.json 2>/dev/null; then
    head -c 400 /tmp/chroma_hb.json
    echo ""
  else
    echo "Chroma heartbeat FAILED or curl missing (CHROMA_SERVER_URL=$CHROMA_URL)"
  fi

  section "workflow API (optional)"
  WF="${WORKFLOW_API_BASE:-http://127.0.0.1:9096}"
  HDR=()
  if [[ -n "${WORKFLOW_API_TOKEN:-}" ]]; then
    HDR=(-H "Authorization: Bearer ${WORKFLOW_API_TOKEN}")
  fi
  if curl -sS --max-time 3 "${HDR[@]}" "$WF/workflow/heartbeat" -o /tmp/wf_hb.json 2>/dev/null; then
    echo "GET $WF/workflow/heartbeat"
    head -c 600 /tmp/wf_hb.json
    echo ""
  else
    echo "workflow API not reachable at $WF (expected if workflow-api.service not bound or port shared with metrics exporter)"
  fi
}

if [[ -n "$OUT_FILE" ]]; then
  collect >"$OUT_FILE"
  echo "Wrote $OUT_FILE"
else
  collect
fi
