#!/usr/bin/env bash
# Deploy alunel EDAC/MCE exporter + prichindel Prometheus scrape/alerts.
# Run from brain repo root (host with SSH to alunel + prichindel).
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
PROM_DIR="$REPO_ROOT/cluster/prichindel/prometheus"

echo "=== alunel EDAC/MCE + Prometheus deploy ==="

echo "--- alunel: rasdaemon + node_exporter :9105 ---"
ssh -o BatchMode=yes alunel "cd /data/workspaces/cursor && git pull --rebase origin main"
ssh -o BatchMode=yes alunel "sudo bash /data/workspaces/cursor/scripts/alunel-edac-mce-install.sh"

echo "--- prichindel: Prometheus scrape + rules ---"
scp -o BatchMode=yes "$PROM_DIR/prometheus.yml" "$PROM_DIR/rules.yml" prichindel:/tmp/
ssh -o BatchMode=yes prichindel 'sudo cp /tmp/prometheus.yml /tmp/rules.yml /data/docker/prometheus/config/ && curl -sf -X POST http://127.0.0.1:9090/-/reload && echo prometheus_reload_ok'

echo "--- verify LAN scrape ---"
ssh -o BatchMode=yes prichindel 'curl -sf http://192.168.100.62:9105/metrics | grep -E "^node_edac_" | head -6'

echo "DONE. Alerts → Alertmanager → tersagor /imirc/prometheus → Telegram."
