---
task_id: "operational|deliverables|path"
active_md_anchor: "| operational |"
---

# Script runbook — Operational deliverables path (assignments / partners)

**Purpose**: Task specs, reports, drafts, and one-off deliverables from **boss assignments** and team work land under **operational/** — not repo root, not **governance/** (canonical policy files). Keeps the brain navigable and matches self-service rules. Ref: [REPO-SELF-SERVICE.md](../REPO-SELF-SERVICE.md) §3, [operational/README.md](../operational/README.md).

**Who**: Cursor, Gena, Ethan task outputs, Grace-directed drafts — anyone producing **assignment-driven** artifacts.

---

## When to use

- Creating a new report, PDF companion `.md`, task spec, or working draft from inbox/assignments.
- Before `git add` of a **new** file: check path (see pre-commit below).

---

## Procedure

1. **Choose folder**:
   - **operational/assignments/** — task specs, session outputs, batches; **operational/assignments/reports/** — PDF/HTML bundles and reports.
   - **operational/partners/** — partners/team operational content (not CLIENTS client codebases).
2. **Naming**: Date or task id in filename (e.g. `GRACE-TRIAGE-*-2026-03-30.md`). No clutter in root.
3. **Canonical lists** stay fixed: [active.md](../active.md), [inbox.md](../inbox.md), governance policy files — do **not** move those for "cleanup."

---

## Pre-commit guard (prichindel / dev)

- Install: [scripts/git-hooks/README.md](git-hooks/README.md) — symlink `pre-commit` to `scripts/git-hooks/pre-commit`.
- **New files at repo root** must be allowlisted in [scripts/git-hooks/allowed-root-files.txt](git-hooks/allowed-root-files.txt) or commit is rejected.

---

## Do not

- Do **not** put deliverables in **governance/** unless it is policy (Ethan/team governance process).
- Do **not** add random `REPORT-*.md` at root — use **operational/assignments/reports/**.

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| pre-commit rejects | Move file under `operational/...` or extend allowlist with team agreement. |
| Link rot | Use relative links from operational to `active.md` / governance. |

---

## See also

- [SCRIPT-RUNBOOK-grace-triage-active.md](SCRIPT-RUNBOOK-grace-triage-active.md) — what becomes a row on active.md.
- [operational/templates/grace-triage/README.md](../operational/templates/grace-triage/README.md) — triage drafts.

SIGNED: Architecture (Ethan) | deliverable placement interface | 2026-03-30 | SCRIPT-RUNBOOK
