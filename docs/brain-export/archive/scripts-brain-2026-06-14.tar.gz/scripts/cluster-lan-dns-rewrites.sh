#!/usr/bin/env bash
# Emit AdGuard rewrite pairs (domain=answer) for every name in the cluster LAN hosts block.
# Includes short, *.local, and *.prichindel.local (and other FQDNs on each line).
# Used by: cluster-hostname-compliance.sh --dns-patch
set -euo pipefail

python3 <<'PY'
import re

BLOCK = """
192.168.100.4 lamaita lamaita.local lamaita.prichindel.local
192.168.100.5 olgahere olgahere.local olgahere.prichindel.local
192.168.100.8 fluturas fluturas.local fluturas.prichindel.local
192.168.100.16 voinicel-wifi voinicel-wifi.local voinicel-wifi.prichindel.local
192.168.100.19 stejarel stejarel.local stejarel.prichindel.local
192.168.100.21 prichindel prichindel.local prichindel.prichindel.local
192.168.100.23 corp.prichindel.com corp corp.local
192.168.100.25 dnsmaster dnsmaster.local dnsmaster.prichindel.local
192.168.100.40 fulgusor fulgusor.local fulgusor.prichindel.local
192.168.100.57 mugurel mugurel.local mugurel.prichindel.local furnica furnica.local furnica.prichindel.local
192.168.100.58 izvoras izvoras.local izvoras.prichindel.local
192.168.100.62 alunel alunel.local alunel.prichindel.local alunel.prichindel.com chroma-1 chroma-1.local chroma-1.prichindel.local
192.168.100.63 chronomaster chronomaster.local chronomaster.prichindel.local
192.168.100.64 mediamaster mediamaster.local mediamaster.prichindel.local
192.168.100.65 altitudine altitudine.local altitudine.prichindel.local mesager mesager.local mesager.prichindel.local
192.168.100.66 librarymaster librarymaster.local librarymaster.prichindel.local chroma-2 chroma-2.local chroma-2.prichindel.local
192.168.100.67 trustmaster trustmaster.local trustmaster.prichindel.local
192.168.100.68 tersagor tersagor.local tersagor.prichindel.local irc.tersagor irc.tersagor.local irc.tersagor.prichindel.local lounge.tersagor lounge.tersagor.local lounge.tersagor.prichindel.local
192.168.100.90 voinicel voinicel.local voinicel.prichindel.local
"""

pairs = []
seen = set()
for line in BLOCK.strip().splitlines():
    parts = line.split()
    if not parts or parts[0].startswith("#"):
        continue
    ip = parts[0]
    for name in parts[1:]:
        if name in seen:
            continue
        seen.add(name)
        pairs.append(f"{name}={ip}")

for p in sorted(pairs, key=lambda x: x.lower()):
    print(p)
PY
