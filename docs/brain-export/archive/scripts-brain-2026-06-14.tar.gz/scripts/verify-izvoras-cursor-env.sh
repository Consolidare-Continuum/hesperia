#!/usr/bin/env bash
# Preflight for Cursor on izvoras: DNS, SSH to prichindel/alunel, MCP config drift.
# Run from repo root on izvoras. Ref: cluster/izvoras/README.md § MCP
set -e
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$REPO_ROOT"
fail=0
echo "=== verify-izvoras-cursor-env (host=$(hostname -s)) ==="

if getent hosts prichindel | grep -q '192.168.100.21'; then
  echo "OK: getent hosts prichindel"
else
  echo "FAIL: prichindel must resolve to 192.168.100.21"
  fail=1
fi

if getent hosts alunel | grep -q '192.168.100.62'; then
  echo "OK: getent hosts alunel"
else
  echo "FAIL: alunel must resolve to 192.168.100.62"
  fail=1
fi

if ssh -o BatchMode=yes -o ConnectTimeout=8 prichindel 'echo ok' 2>/dev/null | grep -q ok; then
  echo "OK: ssh prichindel"
else
  echo "FAIL: ssh prichindel (authorize cluster/izvoras/izvoras-to-prichindel.pub)"
  fail=1
fi

if ssh -o BatchMode=yes -o ConnectTimeout=8 alunel 'echo ok' 2>/dev/null | grep -q ok; then
  echo "OK: ssh alunel"
else
  echo "FAIL: ssh alunel (authorize cluster/izvoras/izvoras-to-alunel.pub)"
  fail=1
fi

MCPC="$REPO_ROOT/governance/mcp-config.json"
DEST="${HOME}/.cursor/mcp.json"
if [ -f "$DEST" ] && cmp -s "$MCPC" "$DEST"; then
  echo "OK: ~/.cursor/mcp.json matches governance/mcp-config.json"
else
  echo "WARN: run bash scripts/deploy-mcp-config-global.sh"
  fail=1
fi

n=$(python3 -c "import json; print(len(json.load(open('$DEST'))['mcpServers']))" 2>/dev/null || echo 0)
echo "INFO: mcpServers count=$n (expect 9)"
if [ "$n" -lt 9 ]; then
  echo "FAIL: expected 9 MCP servers in config"
  fail=1
fi

bash "$REPO_ROOT/scripts/mcp_config_drift_check.sh" || fail=1

if [ -x "$REPO_ROOT/scripts/verify-mcp-handshake.sh" ]; then
  bash "$REPO_ROOT/scripts/verify-mcp-handshake.sh" || fail=1
else
  echo "WARN: missing scripts/verify-mcp-handshake.sh"
  fail=1
fi

if [ "$fail" -eq 0 ]; then
  echo "RESULT: PASS"
else
  echo "RESULT: FAIL"
  exit 1
fi
