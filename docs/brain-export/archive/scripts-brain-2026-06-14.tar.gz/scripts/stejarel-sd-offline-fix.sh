#!/bin/bash
# Offline fix stejarel rootfs on SD (izvoras: /media/igareosh/writable).
# Procedure: scripts/SCRIPT-RUNBOOK-stejarel-sd-offline.md
# Lessons (mandatory read): cluster/stejarel/LESSONS-SSH-OFFLINE-2026-05-26.md
# NEVER partial libc6 rsync (noble arm64: use full dpkg-deb -x + rsync + chown).
# If post-boot sudo/samba still SEGV after one pass → reflash, not more live hacks.
set -euo pipefail
ROOT="${1:-/media/igareosh/writable}"
if [[ ! -d "$ROOT/etc" ]]; then
  echo "BLOCKED: mount SD root at $ROOT first (izvoras)." >&2
  exit 1
fi
echo "Fixing $ROOT ..."
sudo chown -R root:root "$ROOT/etc" "$ROOT/var" "$ROOT/usr/bin" "$ROOT/usr/sbin" "$ROOT/lib" "$ROOT/usr/lib"
# Re-apply after any deb overlay: nothing under etc/var may stay uid 1000
sudo find "$ROOT/etc" "$ROOT/var" ! -path "$ROOT/var/lib/samba/*" -user "$(stat -c %u "$ROOT/home/igareosh" 2>/dev/null || echo 1000)" -exec chown root:root {} + 2>/dev/null || true
sudo chown -R root:root "$ROOT/var/lib/samba"
sudo find "$ROOT/etc" -type d -exec chmod 755 {} \;
sudo find "$ROOT/etc" -type f -exec chmod 644 {} \;
sudo chmod 600 "$ROOT/etc/shadow" 2>/dev/null || true
sudo chmod 440 "$ROOT/etc/sudoers" 2>/dev/null || true
sudo chmod 750 "$ROOT/etc/sudoers.d" 2>/dev/null || true
sudo find "$ROOT/etc/sudoers.d" -type f -exec chmod 440 {} \; 2>/dev/null || true
sudo chmod 4755 "$ROOT/usr/bin/sudo" "$ROOT/usr/bin/sudoedit" 2>/dev/null || true
sudo chmod 4755 "$ROOT/bin/mount" "$ROOT/usr/bin/mount" 2>/dev/null || true
sudo chmod 4755 "$ROOT/usr/bin/passwd" "$ROOT/usr/bin/su" 2>/dev/null || true
sudo chown -R root:root "$ROOT/lib" "$ROOT/usr/lib" 2>/dev/null || true
sudo tee "$ROOT/etc/rc.local" >/dev/null <<'EOF'
#!/bin/sh
chmod 4755 /usr/bin/sudo /usr/bin/sudoedit /bin/mount /usr/bin/mount 2>/dev/null || true
systemctl start samba-ad-dc 2>/dev/null || true
exit 0
EOF
sudo chown root:root "$ROOT/etc/rc.local"
sudo chmod 755 "$ROOT/etc/rc.local"
sync
stat -c "%a %U:%G %n" "$ROOT/usr/bin/sudo" "$ROOT/etc" "$ROOT/var" "$ROOT/var/lib"
echo "DONE. Eject SD, boot stejarel."
