---
task_id: "cluster|trustmaster|access-preflight"
---

# Script runbook — trustmaster / Authentik access preflight

**Purpose**: Ensure Abelard (and any cluster agent) can reach **trustmaster** before Authentik, IdP, RADIUS, or outpost work. Prevents repeated SSH auth failure loops.

**Mandatory when**: Any task touching **trustmaster**, **Authentik**, `https://trustmaster.prichindel.com`, or VM **104** on alunel.

**Canonical doc**: [cluster/trustmaster/ACCESS.md](../cluster/trustmaster/ACCESS.md)

---

## When mandatory

| Trigger | Run this first |
|---------|----------------|
| Authentik user/password/OIDC/SAML/outpost ops | Yes |
| `ssh trustmaster` or docker on 192.168.100.67 | Yes |
| Abelard session reports `Permission denied (publickey)` on cluster host | Yes — then fix, do not retry blindly |

---

## Procedure

### 1) Move to alunel

Cluster agent SSH originates from **alunel** only. If Cursor/workspace is on **altitudine**, **librarymaster**, or Windows → `ssh alunel` first.

### 2) Preflight one-liner

```bash
cd /data/workspaces/cursor && bash scripts/trustmaster-access-preflight.sh
```

### 3) If `BLOCKED` or cert expired

```bash
bash scripts/agent-ssh-cert-renew.sh
bash scripts/agent-ssh-merge-config.sh
bash scripts/agent-ssh-install-via-qemu.sh 104   # breakglass + reinstall trust
bash scripts/trustmaster-access-preflight.sh     # re-check
```

### 4) Execute ops

```bash
ssh trustmaster 'cd /opt/authentik && docker compose ps'
```

Guest-agent fallback (SSH still down):

```bash
sudo qm guest exec 104 -- bash -lc 'docker exec authentik-server-1 ak shell -c "..."'
```

---

## Outcomes

| Result | Action |
|--------|--------|
| `OK: ssh trustmaster` | Proceed with Authentik ops |
| `OK: qemu guest exec` only | Proceed via qemu; schedule SSH trust fix |
| `BLOCKED` | Do not burn retries; fix cert/trust; escalate Grace if VM down |

---

## Anti-patterns (2026-06-10 incident)

1. **Do not** SSH trustmaster from **altitudine** without agent CA.
2. **Do not** use prichindel `github_key` for trustmaster (not authorized).
3. **Do not** retry password/login 10× — read `governance/agent_ssh_cert_status.txt` first.
4. **Do not** trust `agent-ssh-verify-trust.sh` `unreachable` without running preflight script (historical false negative fixed 2026-06-10).

SIGNED: Architecture (Ethan) | trustmaster access mandatory runbook | 2026-06-10 | Abelard auth incident
