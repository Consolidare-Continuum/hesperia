#!/usr/bin/env bash
# Remove duplicate cursor folders cluster-wide (Linux). One source = Proton Drive main folder.
# Run on prichindel and fulgusor. Deletes any cursor dir that is NOT a canonical path.
# Usage: ./scripts/remove-duplicate-cursor-folders.sh [--dry-run]
# Canonical: prichindel = /data/proton_backup/cursor, /data/workspaces/cursor ; fulgusor = /mnt/heimdall/fulgusor_proton_drive/cursor, /data/workspaces/cursor

set -e
DRY=
[[ "${1:-}" == "--dry-run" ]] && DRY=1

# Canonical paths (keep these)
KEEP_PRICHINDEL="/data/proton_backup/cursor
/data/workspaces/cursor"
KEEP_FULGUSOR="/mnt/heimdall/fulgusor_proton_drive/cursor
/data/workspaces/cursor"

is_canonical() {
  local path="$1"
  echo "$KEEP_PRICHINDEL" | grep -Fxq -- "$path" 2>/dev/null && return 0
  echo "$KEEP_FULGUSOR"   | grep -Fxq -- "$path" 2>/dev/null && return 0
  return 1
}

# Only consider top-level cursor dirs (not .git/refs/.../cursor etc)
# Search under /data and /home; skip rclone cache and .git
while IFS= read -r -d '' dir; do
  [[ -z "$dir" ]] && continue
  if is_canonical "$dir"; then
    echo "Keep (canonical): $dir"
    continue
  fi
  # Skip rclone vfs cache
  [[ "$dir" == */.cache/rclone/* ]] && continue
  # Skip inside .git
  [[ "$dir" == *"/.git/"* ]] && continue
  if [[ -n "$DRY" ]]; then
    echo "Dry-run: would remove: $dir"
  else
    echo "Removing: $dir"
    rm -rf "$dir"
  fi
done < <(find /data /home /mnt -maxdepth 5 -type d -name 'cursor' -print0 2>/dev/null)

echo "Done."
