#!/usr/bin/env python3
"""IM-IRC-T14 stub — validate stdin JSON against IM-IRC-EVENT-SCHEMA-v1.json (requires jsonschema if available, else key check)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SCHEMA = REPO / "governance" / "IM-IRC-EVENT-SCHEMA-v1.json"
REQUIRED = {"channel", "sender_subject", "correlation_id", "text", "capabilities"}


def main() -> None:
    data = json.load(sys.stdin)
    missing = REQUIRED - set(data.keys())
    if missing:
        print("validation_error", {"missing": sorted(missing)}, file=sys.stderr)
        sys.exit(1)
    print("ok", data.get("correlation_id"))


if __name__ == "__main__":
    main()
