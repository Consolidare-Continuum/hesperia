#!/usr/bin/env bash
# Idempotent: merge cluster LAN name block into /etc/hosts.
# Canonical doc: cluster/HOSTNAME-AND-HOSTS-STANDARD.md
set -euo pipefail

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run as root: sudo $0" >&2
  exit 1
fi

HOSTS=/etc/hosts
cp -a "$HOSTS" "${HOSTS}.bak.$(date +%s)"

python3 <<'PY'
from pathlib import Path
import re
import sys

hosts_path = Path("/etc/hosts")
text = hosts_path.read_text()

BLOCK = """# BEGIN cluster LAN names (managed — cluster/HOSTNAME-AND-HOSTS-STANDARD.md)
192.168.100.4 lamaita lamaita.local lamaita.prichindel.local
192.168.100.5 olgahere olgahere.local olgahere.prichindel.local
192.168.100.8 fluturas fluturas.local fluturas.prichindel.local
192.168.100.16 voinicel-wifi voinicel-wifi.local voinicel-wifi.prichindel.local
192.168.100.19 stejarel stejarel.local stejarel.prichindel.local
192.168.100.21 prichindel prichindel.local prichindel.prichindel.local
192.168.100.23 corp.prichindel.com corp corp.local
192.168.100.25 dnsmaster dnsmaster.local dnsmaster.prichindel.local
192.168.100.40 fulgusor fulgusor.local fulgusor.prichindel.local
192.168.100.57 mugurel mugurel.local mugurel.prichindel.local furnica furnica.local furnica.prichindel.local
192.168.100.58 izvoras izvoras.local izvoras.prichindel.local
192.168.100.62 alunel alunel.local alunel.prichindel.local alunel.prichindel.com chroma-1 chroma-1.local chroma-1.prichindel.local
192.168.100.63 chronomaster chronomaster.local chronomaster.prichindel.local
192.168.100.64 mediamaster mediamaster.local mediamaster.prichindel.local
192.168.100.65 altitudine altitudine.local altitudine.prichindel.local mesager mesager.local mesager.prichindel.local
192.168.100.66 librarymaster librarymaster.local librarymaster.prichindel.local chroma-2 chroma-2.local chroma-2.prichindel.local
192.168.100.67 trustmaster trustmaster.local trustmaster.prichindel.local
192.168.100.68 tersagor tersagor.local tersagor.prichindel.local irc.tersagor irc.tersagor.local irc.tersagor.prichindel.local lounge.tersagor lounge.tersagor.local lounge.tersagor.prichindel.local
192.168.100.90 voinicel voinicel.local voinicel.prichindel.local
# END cluster LAN names
"""

pat = re.compile(
    r"# BEGIN cluster LAN names.*?# END cluster LAN names\n?",
    re.S,
)
if pat.search(text):
    text = pat.sub(BLOCK.rstrip() + "\n", text)
else:
    text = text.rstrip() + "\n\n" + BLOCK.rstrip() + "\n"

hosts_path.write_text(text)
print("OK: cluster LAN block merged into /etc/hosts")
PY

chmod 644 "$HOSTS"
