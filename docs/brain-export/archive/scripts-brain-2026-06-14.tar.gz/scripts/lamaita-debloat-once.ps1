# One-shot AppX debloat for igare profile + provisioned (excludes Security / Store / winget / shell)
# Run elevated once. SIGNED: Abelard | LAMAITA | 2026-03-24

$ErrorActionPreference = 'SilentlyContinue'
$keep = @(
    'Microsoft.SecHealthUI', 'Microsoft.Windows.SecHealthUI', 'Microsoft.Windows.ShellExperienceHost',
    'Microsoft.WindowsStore', 'Microsoft.Windows.ClientStore', 'Microsoft.DesktopAppInstaller',
    'Microsoft.Windows.ShellExperienceHost', 'Microsoft.Windows.Client.CBS', 'Microsoft.Windows.CapturePicker',
    'Microsoft.WindowsCalculator', 'Microsoft.WindowsCamera', 'Microsoft.WindowsNotepad', 'Microsoft.Paint',
    'Microsoft.WindowsTerminal', 'Microsoft.Windows.Photos', 'Microsoft.WindowsAlarms', 'Microsoft.WindowsSoundRecorder',
    'Microsoft.ScreenSketch', 'Microsoft.MicrosoftEdge.Stable', 'Microsoft.MicrosoftEdge', 'Microsoft.WindowsMaps'
)

$removePatterns = @(
    'Microsoft.GetHelp', 'Microsoft.Getstarted', 'Microsoft.Microsoft3DViewer', 'Microsoft.MicrosoftOfficeHub',
    'Microsoft.MicrosoftSolitaireCollection', 'Microsoft.People', 'Microsoft.SkypeApp', 'Microsoft.WindowsFeedbackHub',
    'Microsoft.BingWeather', 'Microsoft.BingNews', 'Microsoft.ZuneMusic', 'Microsoft.ZuneVideo', 'Microsoft.Todos',
    'Microsoft.PowerAutomateDesktop', 'Microsoft.YourPhone', 'Clipchamp.Clipchamp', 'MicrosoftTeams',
    'Microsoft.XboxGamingOverlay', 'Microsoft.XboxGameOverlay', 'Microsoft.GamingApp', 'Microsoft.Xbox.TCUI',
    'Microsoft.XboxSpeechToTextOverlay', 'Microsoft.XboxIdentityProvider', 'Microsoft.Copilot', 'Microsoft.OutlookForWindows',
    'Microsoft.BingSearch', 'Microsoft.StartExperiencesApp', 'Microsoft.WindowsCommunicationsapps',
    'Microsoft.MicrosoftStickyNotes'
)

$removedUser = @()
foreach ($pat in $removePatterns) {
    Get-AppxPackage | Where-Object { $_.Name -like "$pat*" -and ($keep -notcontains $_.Name) } | ForEach-Object {
        try {
            Remove-AppxPackage -Package $_.PackageFullName -ErrorAction Stop
            $removedUser += $_.Name
        } catch { }
    }
}

$removedProv = @()
foreach ($pat in $removePatterns) {
    Get-AppxProvisionedPackage -Online | Where-Object { $_.DisplayName -like "$pat*" -and ($keep -notcontains $_.DisplayName) } | ForEach-Object {
        try {
            Remove-AppxProvisionedPackage -Online -PackageName $_.PackageName -ErrorAction Stop | Out-Null
            $removedProv += $_.DisplayName
        } catch { }
    }
}

[PSCustomObject]@{
    RemovedUserCount    = $removedUser.Count
    RemovedUserSample   = ($removedUser | Select-Object -First 15) -join '; '
    RemovedProvCount    = $removedProv.Count
    RemovedProvSample   = ($removedProv | Select-Object -First 15) -join '; '
} | Format-List
