# Create scheduled task to run port-forward at user logon. Run once on fluturas as Administrator (elevated PowerShell).
# Script and port-forward.ps1 are in C:\fluturas (no spaces) so schtasks gets one argument.
$ErrorActionPreference = 'Stop'
$ps1Path = "C:\fluturas\fluturas-wsl-port-forward.ps1"
if (-not (Test-Path $ps1Path)) {
  Write-Warning "Copy fluturas-wsl-port-forward.ps1 to C:\fluturas\ first (or run from repo; script will use Proton path)."
  $ps1Path = "C:\Users\igare\Proton Drive\igareosh\Other computers\CERES\ceres_proton_drive\cursor\scripts\fluturas-wsl-port-forward.ps1"
}
$tr = 'powershell.exe -ExecutionPolicy Bypass -NoProfile -File "' + $ps1Path + '"'
$args = @('/create', '/tn', 'FluturasWSLPortForward', '/tr', $tr, '/sc', 'onlogon', '/rl', 'highest', '/f')
& schtasks $args
Write-Host "Task FluturasWSLPortForward created. Runs at logon with highest privileges."
