# List installed Windows programs (omit VS Code and Visual Studio Installer)
$uninstallPaths = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
)
$skip = @('vs code', 'visual studio code', 'visual studio installer')
$names = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($base in $uninstallPaths) {
    if (-not (Test-Path $base)) { continue }
    Get-ChildItem $base -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $p = Get-ItemProperty $_.PSPath -ErrorAction Stop
            if ($p.DisplayName) { [void]$names.Add($p.DisplayName.Trim()) }
        } catch { }
    }
}
$sorted = $names | Sort-Object
$sorted | Where-Object {
    $name = $_
    if (-not $name) { return $false }
    $lower = $name.ToLower()
    $omit = $false
    foreach ($s in $skip) {
        if ($lower -like "*$s*") { $omit = $true; break }
    }
    -not $omit
}
