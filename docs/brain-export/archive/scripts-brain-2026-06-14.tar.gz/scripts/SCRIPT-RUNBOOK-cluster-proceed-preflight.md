---
task_id: "WF-APP|cluster-proceed-preflight"
active_md_anchor: "cluster-proceed-preflight"
---

# Script runbook — cluster proceed preflight (hard gate)

**Purpose**: Before **Abelard-owned** rows or **cluster / prod / services** execution, verify live cluster health: Prometheus alerts, CHROMA-1 heartbeat, workflow API, failed systemd units. **Hard gate** — critical firing alerts → **BLOCKED** (do not deploy or destructive work).

**Who**: Abelard (always); any owner when project ∈ {cluster, prod, services}.  
**Automation**: MCP `get_cluster_snapshot` / `list_firing_alerts` (cursor-cluster-snapshot on prichindel).  
**Refs**: [SPEC-ETHAN-MCP-APPENDIX-DAILY-USE.md](../governance/SPEC-ETHAN-MCP-APPENDIX-DAILY-USE.md), [SCRIPT-RUNBOOK-workflow-proceed-gates.md](SCRIPT-RUNBOOK-workflow-proceed-gates.md)

---

## When mandatory

| Trigger | Mandatory |
|---------|-----------|
| Owner = **Abelard** | Yes |
| Project ∈ **cluster**, **prod**, **services** | Yes |
| Destructive / high-risk (also use approval-gates MCP) | Yes + approval gate |

---

## Procedure (MCP — preferred)

1. **get_cluster_snapshot()** — read chroma status, workflow API, firing alert count, failed units summary.
2. If **critical firing alerts > 0** → **BLOCKED**. Report Grace; do not proceed with prod/deploy.
3. If chroma or workflow API down → investigate before claiming DONE on cluster rows.

---

## Procedure (manual — prichindel or via SSH)

```bash
# Prometheus firing alerts (localhost on prichindel only)
curl -s 'http://127.0.0.1:9090/api/v1/alerts' | jq '.data.alerts | map(select(.state=="firing")) | length'

# CHROMA-1
curl -sf -o /dev/null -w '%{http_code}\n' http://chroma-1.prichindel.local:8002/api/v2/heartbeat

# Workflow API
curl -sf -o /dev/null -w '%{http_code}\n' http://127.0.0.1:9096/workflow/heartbeat

# Failed units (prichindel)
systemctl --failed --no-pager
```

From IDE client (izvoras/alunel): `bash scripts/verify-mcp-handshake.sh` confirms MCP path; use **get_cluster_snapshot** in chat.

---

## Outcomes

| Result | Action |
|--------|--------|
| 0 critical alerts, chroma ok, workflow ok | **Proceed** with execute phase |
| Critical alerts firing | **BLOCKED** — triage alerts first |
| CHROMA-1 or workflow API down | **PAUSED** — Abelard infra fix |

---

## Verify script

`bash scripts/verify-mcp-appendix.sh` (from repo root; uses alunel → prichindel hop).

SIGNED: Runbooks (Liam) | cluster proceed preflight | 2026-05-31 | WF-APP-009
