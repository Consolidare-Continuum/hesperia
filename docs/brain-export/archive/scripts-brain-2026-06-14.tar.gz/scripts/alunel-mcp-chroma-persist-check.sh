#!/usr/bin/env bash
# Alunel: log MCP transport + Chroma reachability so drift/outage is visible without opening Cursor.
# Intended for cron (2x/day). Ref: governance/CURSOR-MCP-CHROMA-PERSISTENCE.md
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-/data/workspaces/cursor}"
CHROMA_HOST="${CHROMA_CANONICAL_HOST:-127.0.0.1}"
LOG_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/cursor-repo"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/mcp-chroma-persist.log"
ts() { date -Is; }

{
  echo "$(ts) === alunel-mcp-chroma-persist-check CHROMA-1 host=$(hostname -s) ==="
  MCPC="$REPO_ROOT/governance/mcp-config.json"
  DEST="${HOME}/.cursor/mcp.json"
  if [ -f "$MCPC" ] && [ -f "$DEST" ] && ! cmp -s "$MCPC" "$DEST"; then
    echo "$(ts) WARN: ~/.cursor/mcp.json != governance/mcp-config.json — run: bash $REPO_ROOT/scripts/deploy-mcp-config-global.sh && restart Cursor"
  fi
  if ! bash "$REPO_ROOT/scripts/verify-alunel-cursor-env.sh"; then
    echo "$(ts) FAIL: verify-alunel-cursor-env"
    exit 1
  fi
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://${CHROMA_HOST}:8002/api/v2/heartbeat" || echo 000)
  if [ "$code" != "200" ]; then
    echo "$(ts) FAIL: CHROMA-1 heartbeat http_code=$code"
    exit 1
  fi
  echo "$(ts) OK: CHROMA-1 heartbeat 200"
} >>"$LOG" 2>&1
