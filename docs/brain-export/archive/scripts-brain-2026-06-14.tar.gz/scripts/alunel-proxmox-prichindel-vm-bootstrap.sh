#!/usr/bin/env bash
# Bootstrap VM prichindel (107) on alunel — Debian 13 Trixie, dual NIC .21/.23.
# Run on alunel as igareosh with sudo. Idempotent where possible.
set -euo pipefail

VMID=107
VM_NAME=prichindel
ISO_URL='https://cdimage.debian.org/debian-cd/current/amd64/iso-cd/debian-13.5.0-amd64-netinst.iso'
ISO_PATH='/data/vm-images/debian-13.5.0-amd64-netinst.iso'
CLOUD_URL='https://cdimage.debian.org/cdimage/cloud/trixie/latest/debian-13-genericcloud-amd64.qcow2'
CLOUD_PATH='/data/vm-images/debian-13-genericcloud-amd64.qcow2'
BRIDGE_CFG='/etc/network/interfaces.d/50-prichindel-vm-bridges.cfg'
REPO=''
if [ -d /data/workspaces/cursor ]; then REPO=/data/workspaces/cursor; elif [ -d /data/altitudine/prichindel.com ]; then REPO=/data/altitudine/prichindel.com; else REPO="$(cd "$(dirname "$0")/.." && pwd)"; fi

log() { echo "[prichindel-vm] $*"; }

need_root() {
  if [ "$(id -u)" -ne 0 ]; then
    exec sudo -n bash "$0" "$@"
  fi
}

download_iso() {
  if [ -f "$ISO_PATH" ] && [ "$(stat -c%s "$ISO_PATH")" -gt 500000000 ]; then
    log "ISO present: $ISO_PATH"
    return 0
  fi
  log "Downloading Debian 13.5 netinst ISO..."
  tmp="${ISO_PATH}.partial"
  curl -fL --retry 3 --continue-at - -o "$tmp" "$ISO_URL"
  mv "$tmp" "$ISO_PATH"
  chown igareosh:igareosh "$ISO_PATH"
  log "ISO saved: $ISO_PATH ($(du -h "$ISO_PATH" | awk '{print $1}'))"
}

download_cloud() {
  if [ -f "$CLOUD_PATH" ] && [ "$(stat -c%s "$CLOUD_PATH")" -gt 100000000 ]; then
    log "Cloud image present: $CLOUD_PATH"
    return 0
  fi
  log "Downloading Debian 13 generic cloud image (Trixie)..."
  tmp="${CLOUD_PATH}.partial"
  curl -fL --retry 3 --continue-at - -o "$tmp" "$CLOUD_URL"
  mv "$tmp" "$CLOUD_PATH"
  chown igareosh:igareosh "$CLOUD_PATH"
}

link_iso_storage() {
  mkdir -p /var/lib/vz/template/iso /data/template/iso
  ln -sf "$ISO_PATH" /var/lib/vz/template/iso/debian-13.5.0-amd64-netinst.iso
  ln -sf "$ISO_PATH" /data/template/iso/debian-13.5.0-amd64-netinst.iso
  log "ISO linked in Proxmox template storage"
}

setup_bridges() {
  if [ -f "$BRIDGE_CFG" ] && grep -q vmbr21 "$BRIDGE_CFG"; then
    log "Bridge config already present"
  else
    log "Writing $BRIDGE_CFG (nic0→vmbr21, nic1→vmbr23; vmbr0/.62 on nic2 untouched)"
    cat >"$BRIDGE_CFG" <<'EOF'
# prichindel VM — dual LAN (.21 / .23) on 4-port NIC (nic0/nic1). vmbr0/.62 stays on nic2.
auto vmbr21
iface vmbr21 inet manual
	bridge-ports nic0
	bridge-stp off
	bridge-fd 0

auto vmbr23
iface vmbr23 inet manual
	bridge-ports nic1
	bridge-stp off
	bridge-fd 0
EOF
  fi
  if command -v ifreload >/dev/null 2>&1; then
    ifreload -a || true
  else
    systemctl reload networking 2>/dev/null || true
  fi
  ip link set nic0 up 2>/dev/null || true
  ip link set nic1 up 2>/dev/null || true
  log "Bridges: $(ip -br link show type bridge 2>/dev/null | tr '\n' ' ')"
}

build_sshkeys_file() {
  local f=/tmp/prichindel-vm-107-sshkeys
  : >"$f"
  for src in \
    /home/igareosh/.ssh/authorized_keys \
    "$REPO/cluster/alunel/alunel-to-prichindel.pub" \
    /home/igareosh/.ssh/github_key.pub; do
  if [ -f "$src" ]; then
    cat "$src" >>"$f"
  fi
  done
  if [ -f /home/igareosh/.ssh/id_ed25519_altitudine_travel.pub ]; then
    cat /home/igareosh/.ssh/id_ed25519_altitudine_travel.pub >>"$f"
  fi
  awk '!seen[$0]++' "$f" >"${f}.uniq"
  mv "${f}.uniq" "$f"
  chmod 600 "$f"
  chown igareosh:igareosh "$f"
  echo "$f"
}

create_vm() {
  if sudo qm status "$VMID" &>/dev/null; then
    log "VM $VMID already exists"
    return 0
  fi
  local keys_file
  keys_file="$(build_sshkeys_file)"
  download_cloud
  log "Creating VM $VMID ($VM_NAME)..."
  sudo qm create "$VMID" \
    --name "$VM_NAME" \
    --memory 32768 \
    --cores 8 \
    --cpu host \
    --ostype l26 \
    --agent enabled=1 \
    --serial0 socket \
    --vga serial0 \
    --scsihw virtio-scsi-pci \
    --net0 "virtio,bridge=vmbr21,firewall=0" \
    --net1 "virtio,bridge=vmbr23,firewall=0" \
    --ide2 "local:iso/debian-13.5.0-amd64-netinst.iso,media=cdrom" \
    --boot "order=scsi0;ide2" \
    --ciuser igareosh \
    --sshkeys "$keys_file" \
    --ipconfig0 "ip=192.168.100.21/24,gw=192.168.100.1" \
    --ipconfig1 "ip=192.168.100.23/24" \
    --nameserver "192.168.100.25 192.168.100.19" \
    --searchdomain prichindel.local

  sudo qm importdisk "$VMID" "$CLOUD_PATH" local-lvm
  sudo qm set "$VMID" --scsi0 "local-lvm:vm-${VMID}-disk-0,discard=on,ssd=1"
  sudo qm set "$VMID" --ide0 "local-lvm:cloudinit"
  sudo qm set "$VMID" --bootdisk scsi0
  sudo qm resize "$VMID" scsi0 80G
  log "VM $VMID created"
}

start_vm() {
  local st
  st="$(sudo qm status "$VMID" 2>/dev/null | awk '{print $2}' || echo missing)"
  if [ "$st" = "running" ]; then
    log "VM $VMID already running"
    return 0
  fi
  sudo qm start "$VMID"
  log "VM $VMID started"
}

wait_guest() {
  log "Waiting for qemu-guest-agent on VM $VMID (up to 180s)..."
  local i
  for i in $(seq 1 36); do
    if sudo qm guest cmd "$VMID" ping &>/dev/null; then
      log "Guest agent OK"
      return 0
    fi
    sleep 5
  done
  log "WARN: guest agent not responding yet — cloud-init may still be running"
  return 1
}

post_install() {
  log "Post-install: git, CA trust, cluster SSH, version pin..."
  sudo qm guest exec "$VMID" -- bash -lc '
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq git openssh-server sudo qemu-guest-agent curl ca-certificates
systemctl enable --now qemu-guest-agent ssh
# Ensure point release current (13.5 line)
apt-get dist-upgrade -y -qq || true
grep -q igareosh /etc/sudoers.d/99-igareosh-nopasswd 2>/dev/null || {
  echo "igareosh ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/99-igareosh-nopasswd
  chmod 440 /etc/sudoers.d/99-igareosh-nopasswd
}
hostnamectl set-hostname prichindel.prichindel.local
grep -q prichindel.prichindel.local /etc/hosts || echo "127.0.1.1 prichindel prichindel.prichindel.local prichindel.local" >> /etc/hosts
mkdir -p /home/igareosh/.ssh
chmod 700 /home/igareosh/.ssh
chown -R igareosh:igareosh /home/igareosh/.ssh
git config --global user.email "igareosh@igareosh.com"
git config --global user.name "igareosh"
git --version
cat /etc/os-release | head -5
' || true

  if [ -f /home/igareosh/.ssh/agent-ca/agent_ca.pub ]; then
    bash "$REPO/scripts/agent-ssh-install-via-qemu.sh" "$VMID" || log "WARN: agent CA install deferred"
  fi
}

trustmaster_access() {
  local pub=/home/igareosh/.ssh/id_ed25519_altitudine_travel.pub
  [ -f "$pub" ] || pub=/home/igareosh/.ssh/id_rsa.pub
  [ -f "$pub" ] || { log "WARN: no pubkey for trustmaster"; return 0; }
  local keyline
  keyline="$(cat "$pub")"
  ssh -o BatchMode=yes -o ConnectTimeout=8 igareosh@192.168.100.67 "grep -Fq '${keyline%% *}' ~/.ssh/authorized_keys 2>/dev/null || echo '$keyline' >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys" \
    && log "trustmaster: cluster SSH key present" \
    || log "WARN: trustmaster key update failed (run manually)"
}

write_status() {
  local out="$REPO/operational/assignments/reports/PRICHINDEL-VM-107-STATUS.txt"
  mkdir -p "$(dirname "$out")"
  {
    echo "updated: $(date -Is)"
    echo "host: alunel"
    echo "vmid: $VMID"
    echo "name: $VM_NAME"
    echo "iso: $ISO_PATH"
    echo "bridges: vmbr21(nic0)=.21 vmbr23(nic1)=.23 vmbr0(nic2)=.62 unchanged"
    sudo qm status "$VMID" 2>/dev/null || true
    sudo qm config "$VMID" 2>/dev/null | grep -E '^(memory|cores|net|name)' || true
  } >"$out"
  log "Status: $out"
}

main() {
  need_root "$@"
  download_iso
  link_iso_storage
  setup_bridges
  create_vm
  start_vm
  wait_guest || true
  post_install
  trustmaster_access
  write_status
  log "DONE — VM $VMID prichindel on alunel; ISO at $ISO_PATH"
}

main "$@"
