# Scripts index

**Owner**: Liam (automation lead).
**Purpose**: Inventory of maintained scripts in `scripts/` with purpose, ownership, and runbook references.

---

| Script | Purpose | Owner | Inputs | Outputs | Runbook |
|--------|---------|-------|--------|---------|---------|
| `workflow_orchestrator.py` | Heartbeat: scan active.md, write workflow_heartbeat.txt | Liam | active.md, assignments.md | workflow_heartbeat.txt | [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) |
| `workflow_driver.py` | Pick next OPEN task, write current step + context passport | Liam | active.md, workflow_heartbeat.txt | workflow_driver_current.txt, workflow_context_current.md | [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) |
| `workflow_run.sh` | One-pass IDE workflow runner (orchestrator + driver) | Liam | — | heartbeat + current step files | [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) |
| `workflow_automation_run.sh` | Terminal/cron automation (modes: once, drain, full-auto, drain-irc) | Liam | mode arg, env vars | heartbeat + current step + executor output | [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) |
| `workflow_automation_manual_start.sh` | Manual full automation run | Liam | — | same as workflow_automation_run.sh | [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) |
| `mcp_config_drift_check.sh` | Compare deployed MCP config vs repo canonical | Liam | governance/mcp-config.json, ~/.cursor/mcp.json | stdout drift report | — |
| `end_of_day_collect.sh` | EOD collect: git diff/status, active.md excerpt, Chroma heartbeat, workflow API probe | Liam | `--out` path optional | EOD collect txt | [END-OF-DAY-WORKFLOW.md](../.cursor/END-OF-DAY-WORKFLOW.md) §0 |
| `end_of_week_collect.sh` | EOW collect: ISO week + repo wave row hints + EOD collect | Liam | `--out` path optional | EOW collect txt | [END-OF-WEEK-WORKFLOW.md](../.cursor/END-OF-WEEK-WORKFLOW.md) §0 |
| `end_of_week_research.py` | EOW research: repo signals → **50 execution/integration rows** (5×10); not doc churn | Cursor main | (none) | EOW-RESEARCH / EOW-TASK-REGISTER | [SPEC-ETHAN-END-OF-WEEK-BRAIN-WORKFLOW.md](../governance/SPEC-ETHAN-END-OF-WEEK-BRAIN-WORKFLOW.md) |
| `end_of_week_run.sh` | EOW entry: collect / research / execute / until-done / full | Cursor main | `collect` \| `research` \| `execute` \| `until-done` \| `full` | wave execution | [SCRIPT-RUNBOOK-end-of-week-brain.md](SCRIPT-RUNBOOK-end-of-week-brain.md) |
| `repo_auto_wave_execute.py` | Brain wave batch: cluster README audits + runbook verify + MCP drift | Cursor main | `--wave-label`, `--report` | JSON report | same |
| `deploy-mcp-config-global.sh` | Deploy MCP config from repo to ~/.cursor/mcp.json and .cursor/mcp.json | Liam | governance/mcp-config.json | deployed config files | [SCRIPT-RUNBOOK-mcp.md](SCRIPT-RUNBOOK-mcp.md) |
| `detect-cursor-session-mode.sh` | Detect host, **role**, dev_office, connectivity; write cursor_session_mode.txt | Liam | hostname, network | governance/cursor_session_mode.txt | [HOST-ALTITUDINE-VS-LIBRARYMASTER.md](../governance/HOST-ALTITUDINE-VS-LIBRARYMASTER.md) |
| `verify-host-role-separation.sh` | Audit altitudine vs librarymaster registry/docs (CI/agent) | Abelard | — | exit 0/1 | same |
| `cluster-lan-dns-rewrites.sh` | Print all AdGuard `domain=ip` pairs (short + .local + .prichindel.local) | Abelard | hosts block | stdout | [HOSTNAME-AND-HOSTS-STANDARD.md](../cluster/HOSTNAME-AND-HOSTS-STANDARD.md) |
| `cluster-hostname-compliance.sh` | Audit/apply `/etc/hosts` + dnsmaster rewrites (`--apply` `--dns-patch`) | Abelard | SSH, dnsmaster | — | same |
| `job_done_effect.py` | TV flash + Telegram notification on task completion | Liam | — | TV signal, Telegram message | — |
| `run-maintenance.sh` | System maintenance (updates, cleanup, health checks) | Abelard | — | /data/system_maintenance/latest/ | — |
| `run-backup.sh` | Backup run (data, configs, DB dumps) | Abelard | — | backup artifacts | — |
| `vidaa_tv_control.py` | VIDAA TV control (status, power, volume, input) | Abelard | command args | TV state change | — |
| `plex_play_playlist.py` | Play Plex playlist on TV client | Abelard | playlist name, client | Plex playback | — |

---

**Adding a script**: When a new maintained script is added to `scripts/`, add a row here. One-off or archived scripts do not need an entry.


## Runbooks index (REPO-AUTO wave)

| Runbook | Purpose (first heading) |
|---------|-------------------------|
| [SCRIPT-RUNBOOK-approval-gate-destructive.md](SCRIPT-RUNBOOK-approval-gate-destructive.md) | Script runbook — Approval gate before destructive / high-risk work |
| [SCRIPT-RUNBOOK-backup-prichindel.md](SCRIPT-RUNBOOK-backup-prichindel.md) | Runbook — Backup prichindel (lightweight + optional full) |
| [SCRIPT-RUNBOOK-captain-on-deck-workflow.md](SCRIPT-RUNBOOK-captain-on-deck-workflow.md) | Script runbook — Captain on deck (workflow automation manual) |
| [SCRIPT-RUNBOOK-chroma-alunel-migration.md](SCRIPT-RUNBOOK-chroma-alunel-migration.md) | SCRIPT-RUNBOOK — chroma-new (prichindel) → CHROMA-1 (alunel) |
| [SCRIPT-RUNBOOK-cluster-proceed-preflight.md](SCRIPT-RUNBOOK-cluster-proceed-preflight.md) | Script runbook — cluster proceed preflight (hard gate) |
| [SCRIPT-RUNBOOK-cloudflare.md](SCRIPT-RUNBOOK-cloudflare.md) | Runbook — Cloudflare upkeep (tunnels, tokens, DNS) |
| [SCRIPT-RUNBOOK-connection-resolution.md](SCRIPT-RUNBOOK-connection-resolution.md) | Runbook — Connection resolution (SSH, tunnel, DNS) |
| [SCRIPT-RUNBOOK-end-of-day-collect.md](SCRIPT-RUNBOOK-end-of-day-collect.md) | Script runbook — End-of-day collect (snapshot before consolidation) |
| [SCRIPT-RUNBOOK-escalate-grace.md](SCRIPT-RUNBOOK-escalate-grace.md) | Script runbook — Escalate via Grace (single path) |
| [SCRIPT-RUNBOOK-fpf-chroma.md](SCRIPT-RUNBOOK-fpf-chroma.md) | SCRIPT-RUNBOOK — FPF layer (Chroma catalog) |
| [SCRIPT-RUNBOOK-github.md](SCRIPT-RUNBOOK-github.md) | Runbook: GitHub PR check flow (optional) |
| [SCRIPT-RUNBOOK-github-ci-verify.md](SCRIPT-RUNBOOK-github-ci-verify.md) | Script runbook — GitHub CI verify (soft gate) |
| [SCRIPT-RUNBOOK-grace-triage-active.md](SCRIPT-RUNBOOK-grace-triage-active.md) | Script runbook — Grace triage → active.md row |
| [SCRIPT-RUNBOOK-hesperia-tfp-bundle-inspection.md](SCRIPT-RUNBOOK-hesperia-tfp-bundle-inspection.md) | Script runbook — Hesperia TFP bundle output inspection (Cursor MCP agent) |
| [SCRIPT-RUNBOOK-imirc-mesh.md](SCRIPT-RUNBOOK-imirc-mesh.md) | Script runbook — IM-IRC mesh (skeleton) |
| [SCRIPT-RUNBOOK-library-file-list.md](SCRIPT-RUNBOOK-library-file-list.md) | Runbook: library file list (Proton / Drive export → TSV) |
| [SCRIPT-RUNBOOK-maintenance.md](SCRIPT-RUNBOOK-maintenance.md) | Runbook — Cluster maintenance (prichindel + fulgusor) |
| [SCRIPT-RUNBOOK-mcp-chroma-session.md](SCRIPT-RUNBOOK-mcp-chroma-session.md) | Script runbook — MCP session + Chroma (agent loop) |
| [SCRIPT-RUNBOOK-mcp.md](SCRIPT-RUNBOOK-mcp.md) | Script runbook — MCP config drift and monthly check |
| [SCRIPT-RUNBOOK-miniflux-user-add-authentik-invited-user.md](SCRIPT-RUNBOOK-miniflux-user-add-authentik-invited-user.md) | Script runbook — Add Miniflux user via Authentik `invited_user` (Mesager-only sc |
| [SCRIPT-RUNBOOK-operational-deliverables.md](SCRIPT-RUNBOOK-operational-deliverables.md) | Script runbook — Operational deliverables path (assignments / partners) |
| [SCRIPT-RUNBOOK-reboot-prichindel-eod.md](SCRIPT-RUNBOOK-reboot-prichindel-eod.md) | Runbook — Reboot prichindel (end of day) |
| [SCRIPT-RUNBOOK-report-done-workflow.md](SCRIPT-RUNBOOK-report-done-workflow.md) | Script runbook — report_done (task complete → active.md sync) |
| [SCRIPT-RUNBOOK-stejarel-sd-offline.md](SCRIPT-RUNBOOK-stejarel-sd-offline.md) | SCRIPT-RUNBOOK — stejarel SD offline repair (izvoras) |
| [SCRIPT-RUNBOOK-tersagor-operator-notify.md](SCRIPT-RUNBOOK-tersagor-operator-notify.md) | Script runbook — Notify igareosh via Telegram (Tersagor) |
| [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) | Script runbook — Workflow orchestrator (heartbeat) |
| [SCRIPT-RUNBOOK-workflow-proceed-gates.md](SCRIPT-RUNBOOK-workflow-proceed-gates.md) | Script runbook — workflow proceed gates (umbrella) |
| [verify-mcp-handshake.sh](verify-mcp-handshake.sh) | MCP stdio initialize smoke (9 team servers) |
| [verify-mcp-appendix.sh](verify-mcp-appendix.sh) | Appendix MCP import smoke on prichindel |

REPO-AUTO wave 2026-05-31 — Liam index pass; one row per SCRIPT-RUNBOOK in repo.
SIGNED: Automation Lead (Liam) | Ethan context | 2026-05-14 | BF-035 index
