"""trustmaster: ensure Cloudflare Access callback on every OAuth2 provider (reconcile all)."""

from authentik.providers.oauth2.models import OAuth2Provider, RedirectURI, RedirectURIMatchingMode

CF_STRICT = "https://prichindel.cloudflareaccess.com/cdn-cgi/access/callback"
CF_REGEX = r"https://[^/]+\.cloudflareaccess\.com/cdn-cgi/access/callback"


def ensure_cf(p: OAuth2Provider) -> bool:
    uris = list(p.redirect_uris)
    have_strict = any(
        u.matching_mode == RedirectURIMatchingMode.STRICT and u.url == CF_STRICT for u in uris
    )
    have_regex = any(
        u.matching_mode == RedirectURIMatchingMode.REGEX and CF_REGEX == u.url for u in uris
    )
    changed = False
    if not have_strict:
        uris.append(RedirectURI(matching_mode=RedirectURIMatchingMode.STRICT, url=CF_STRICT))
        changed = True
    if not have_regex:
        uris.append(RedirectURI(matching_mode=RedirectURIMatchingMode.REGEX, url=CF_REGEX))
        changed = True
    if changed:
        p.redirect_uris = uris
        p.save()
    return changed


for p in OAuth2Provider.objects.all().order_by("pk"):
    if ensure_cf(p):
        print("UPDATED pk=", p.pk, p.name)
    else:
        print("ok pk=", p.pk, p.name)
    for u in p.redirect_uris:
        print(" ", u.matching_mode, u.url)
