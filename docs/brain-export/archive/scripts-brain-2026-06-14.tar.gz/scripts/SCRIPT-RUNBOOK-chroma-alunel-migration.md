# SCRIPT-RUNBOOK — chroma-new (prichindel) → CHROMA-1 (alunel)

**Program:** `chroma-mig` · **Instances:** [governance/CHROMA-INSTANCES.md](../governance/CHROMA-INSTANCES.md) · **ADR:** [governance/ADR-CHROMA-CANONICAL-ALUNEL.md](../governance/ADR-CHROMA-CANONICAL-ALUNEL.md)

---

## Operator one-pager (Liam)

1. **Do not purge prichindel** until **CHROMA-MIG-25** and ≥14 days after cutover.
2. **Cutover approval:** set **CHROMA-MIG-23** OPEN only when parallel QA is green; say "approve chroma cutover" in chat.
3. **Autorun:** `WORKFLOW_DRIVER_PROJECT=chroma-mig ./scripts/workflow_automation_run.sh drain`
4. **Rollback:** point `governance/mcp-config.json` back to prichindel `:8002`; restart consumers.

---

## 1. CHROMA-1 stack on alunel (MIG-03/04)

```bash
bash scripts/alunel-deploy-chroma-prod.sh   # installs chroma-1-docker, chroma-1-query-api
```

## 2. Inventory (MIG-06, on prichindel)

```bash
ssh prichindel 'cd /data/altitudine/prichindel.com && CHROMA_MIG_INVENTORY_OUT=operational/assignments/reports/CHROMA-MIG-06-inventory.json /data/chroma/venv/bin/python3 cluster/chroma-server/migrate_inventory.py'
```

## 3. C2C export (MIG-07, prichindel)

```bash
ssh prichindel 'CHROMA_MIG_EXPORT_DIR=/data/chroma/migration/export /data/chroma/venv/bin/python3 /data/altitudine/prichindel.com/cluster/chroma-server/migrate_export.py'
```

## 4. Rsync export → alunel

```bash
rsync -avz prichindel:/data/chroma/migration/export/ /data/chroma/migration/export/
```

## 5. C2C import (MIG-08–11, alunel)

```bash
# all layers
CHROMA_MIG_EXPORT_DIR=/data/chroma/migration/export CHROMA_SERVER_URL=http://chroma-1.prichindel.local:8002 \
  /data/chroma/venv/bin/python3 cluster/chroma-server/migrate_import.py

# per layer
CHROMA_MIG_LAYER=operational ... migrate_import.py
```

## 6. Re-ingest (MIG-12–14, alunel)

```bash
cd /data/altitudine/prichindel.com
CHROMA_SERVER_URL=http://chroma-1.prichindel.local:8002 bash cluster/chroma-server/ingest-whole-repo.sh
bash cluster/chroma-server/ingest-fpf.sh
# books / hesperia / tfp per existing runbooks
```

## 7. QA (MIG-15)

[governance/CHROMA-RETRIEVAL-QA.md](../governance/CHROMA-RETRIEVAL-QA.md)

## 8. MCP cutover (MIG-18)

```bash
bash scripts/deploy-mcp-config-global.sh
# restart Cursor
```

## 9. Stop prichindel (MIG-24, after MIG-23)

Full checklist: [operational/assignments/CHROMA-PRICHINDEL-SHUTDOWN-PREP-2026-05-16.md](../operational/assignments/CHROMA-PRICHINDEL-SHUTDOWN-PREP-2026-05-16.md)

```bash
ssh prichindel 'sudo systemctl stop chroma-new-docker chroma-query-api chroma-new-metrics'
ssh prichindel 'sudo systemctl disable chroma-new-docker chroma-query-api chroma-new-metrics'
```

---

SIGNED: DevOps (Abelard) | chroma alunel migration runbook | 2026-05-16 | CHROMA-MIG-05
