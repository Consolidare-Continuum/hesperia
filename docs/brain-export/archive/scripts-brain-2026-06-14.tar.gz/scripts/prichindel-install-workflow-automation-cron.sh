#!/usr/bin/env bash
# Abelard — install half-hourly workflow automation cron on prichindel (igareosh).
# Repo: /data/workspaces/cursor
set -euo pipefail

REPO="${WORKFLOW_REPO_ROOT:-/data/workspaces/cursor}"
CRON_LINE="*/30 * * * * cd ${REPO} && WORKFLOW_QUIET=1 CHROMA_SKIP_PREFLIGHT=1 ./scripts/workflow_automation_run.sh once >>${REPO}/governance/workflow_automation.cron.log 2>&1"

( crontab -l 2>/dev/null | grep -v 'workflow_automation_run.sh' || true
  echo "$CRON_LINE"
) | crontab -

echo "DONE. igareosh crontab:"
crontab -l | grep workflow_automation_run.sh
echo "Metrics: curl -s http://127.0.0.1:9095/metrics | grep workflow_automation_up"
