#!/usr/bin/env bash
# Prichindel.com — maintenance script (Abelard)
# Run from Abelard workspace: sudo ./scripts/run-maintenance.sh [--dry-run]
# Debian/Ubuntu. No secrets in output.
# Policy: cluster/MAINTENANCE_POLICY.md — every run creates a run dir under
#   /data/system_maintenance/, writes reports + notes, updates latest.

set -euo pipefail
DRY_RUN=false
BACKUP_BASE="${PRICHINDEL_BACKUP_BASE:-/data/backups/prichindel}"
SYSMAINT_BASE="${PRICHINDEL_SYSMAINT:-/data/system_maintenance}"
LOG_PREFIX="[prichindel-maintenance]"

for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=true ;;
  esac
done

run() {
  if "$DRY_RUN"; then
    echo "$LOG_PREFIX [DRY-RUN] $*"
    return 0
  fi
  "$@"
}

RUN_START=$(date +%Y-%m-%d_%H%M%S)
RUN_DATE=$(date +%Y-%m-%d)
RUN_DIR="${SYSMAINT_BASE}/${RUN_DATE}_prichindel_${RUN_START}"

if ! "$DRY_RUN"; then
  mkdir -p "${RUN_DIR}/reports" "${RUN_DIR}/backups" "${RUN_DIR}/notes"
  echo "host=prichindel start=$(date -Iseconds) run=${RUN_DIR}" > "${RUN_DIR}/reports/00-meta.txt"
fi

echo "$LOG_PREFIX $(date -Iseconds) start"

# ——— Packages ———
echo "$LOG_PREFIX apt update"
run apt-get update -qq
echo "$LOG_PREFIX apt upgrade (non-interactive)"
run env DEBIAN_FRONTEND=noninteractive apt-get upgrade -y -qq

# ——— Restart services that need restart (after library upgrades) ———
echo "$LOG_PREFIX needrestart: restart services that need restart"
run needrestart -r a -b -q 2>/dev/null || echo "$LOG_PREFIX needrestart skipped or not available"

# ——— Services ———
echo "$LOG_PREFIX systemd failed units:"
systemctl list-units --state=failed --no-legend --no-pager || true
echo "$LOG_PREFIX systemd active (critical):"
systemctl is-active ssh 2>/dev/null || true

# ——— Disks ———
echo "$LOG_PREFIX disk usage:"
df -h /
echo "$LOG_PREFIX inodes:"
df -i /

# ——— Backups ———
STAMP=$(date +%Y-%m-%d)
BACKUP_DIR="${BACKUP_BASE}/${STAMP}"
echo "$LOG_PREFIX backup dir: $BACKUP_DIR"
if "$DRY_RUN"; then
  echo "$LOG_PREFIX [DRY-RUN] mkdir -p $BACKUP_DIR"
else
  mkdir -p "$BACKUP_DIR"
fi

# ——— Config snapshot (optional) ———
if ! "$DRY_RUN"; then
  TARBALL="${BACKUP_DIR}/etc-snapshot.tar.gz"
  echo "$LOG_PREFIX config snapshot: $TARBALL"
  tar czf "$TARBALL" -C / etc 2>/dev/null || echo "$LOG_PREFIX config snapshot skipped (permissions or missing)"
else
  echo "$LOG_PREFIX [DRY-RUN] config snapshot would be written to $BACKUP_DIR"
fi

# ——— Connectivity ———
echo "$LOG_PREFIX connectivity:"
ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && echo "  gateway/inet: ok" || echo "  gateway/inet: fail"
getent hosts prichindel.com >/dev/null 2>&1 && echo "  DNS prichindel.com: ok" || echo "  DNS prichindel.com: fail"

# ——— Chroma CHROMA-1 on alunel (team brain; prichindel chroma-new retired) ———
echo "$LOG_PREFIX Chroma state (CHROMA-1):"
CHROMA_HEARTBEAT_URL="${CHROMA_HEARTBEAT_URL:-http://chroma-1.prichindel.local:8002}"
if [ "$(hostname -s 2>/dev/null)" = "alunel" ]; then
  CHROMA_HEARTBEAT_URL="${CHROMA_HEARTBEAT_URL:-http://127.0.0.1:8002}"
fi
CHROMA_HTTP=$(curl -s -o /dev/null -w "%{http_code}" "${CHROMA_HEARTBEAT_URL}/api/v2/heartbeat" 2>/dev/null || echo "0")
[ -z "$CHROMA_HTTP" ] && CHROMA_HTTP=0
if [ "$CHROMA_HTTP" = "200" ]; then
  echo "  heartbeat (${CHROMA_HEARTBEAT_URL}): 200 ok"
  CHROMA_STATE="ok"
else
  echo "  heartbeat (${CHROMA_HEARTBEAT_URL}): ${CHROMA_HTTP:-fail} (fix: ssh alunel — systemctl restart chroma-1-docker)"
  CHROMA_STATE="fail"
  if ! "$DRY_RUN" && [ "$(hostname -s 2>/dev/null)" = "alunel" ]; then
    systemctl is-active chroma-1-docker &>/dev/null && run systemctl restart chroma-1-docker chroma-1-query-api && echo "$LOG_PREFIX CHROMA-1 restarted on alunel" || true
  fi
fi
if [ "$(hostname -s 2>/dev/null)" = "alunel" ]; then
  systemctl is-active chroma-1-docker chroma-1-query-api 2>/dev/null || echo "  chroma-1 units: not installed or inactive"
else
  ssh -o BatchMode=yes -o ConnectTimeout=10 alunel 'systemctl is-active chroma-1-docker chroma-1-query-api 2>/dev/null' 2>/dev/null || echo "  chroma-1 units (alunel): ssh check failed"
fi

# ——— Brain repo: workflow API (Phase 2b) ———
echo "$LOG_PREFIX Brain repo workflow API:"
WF_HTTP=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:9096/workflow/heartbeat 2>/dev/null || echo "0")
[ -z "$WF_HTTP" ] && WF_HTTP=0
if [ "$WF_HTTP" = "200" ]; then
  echo "  /workflow/heartbeat: 200 ok"
  WF_STATE="ok"
else
  echo "  /workflow/heartbeat: ${WF_HTTP:-fail} (fix: sudo systemctl restart workflow-api; agents/abelard/MAINTENANCE-BRAIN-REPO-FLOWS.md)"
  WF_STATE="fail"
fi

# ——— Detelina (n8n) — prod pipeline for Detelina Cursor; cluster/DETELINA-PROD-PIPELINE.md ———
echo "$LOG_PREFIX Detelina (n8n) state:"
N8N_UP="no"
if docker ps --format '{{.Names}}' 2>/dev/null | grep -qx n8n; then
  echo "  container: running"
  N8N_UP="yes"
  N8N_HTTP=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:5678/healthz 2>/dev/null || echo "0")
  [ -z "$N8N_HTTP" ] && N8N_HTTP=0
  if [ "$N8N_HTTP" = "200" ]; then
    echo "  healthz: 200 ok"
  else
    echo "  healthz: ${N8N_HTTP:-fail}"
  fi
else
  echo "  container: not running (fix: cd /data/n8n && docker compose up -d n8n)"
fi

# ——— alunel (LAN Linux AD member) ———
echo "$LOG_PREFIX alunel (SSH snapshot):"
if ! "$DRY_RUN"; then
  ALUNEL_REPORT="${RUN_DIR}/reports/06-alunel.txt"
  {
    echo "collected=$(date -Iseconds)"
    sudo -u igareosh ssh -o BatchMode=yes -o ConnectTimeout=10 -o IdentitiesOnly=yes \
      -i /home/igareosh/.ssh/id_rsa igareosh@192.168.100.62 \
      'echo host=$(hostname); df -h / | tail -1; systemctl is-active ssh winbind smbd 2>/dev/null | paste -sd, -; systemctl is-active clamav-daemon.socket clamav-daemon.service 2>/dev/null | paste -sd, -; systemctl is-enabled clamav-freshclam-once.timer 2>/dev/null; sudo net ads testjoin 2>&1 | tail -1' 2>&1 \
      || echo "alunel_ssh=fail"
  } > "$ALUNEL_REPORT" 2>&1 || true
else
  echo "$LOG_PREFIX [DRY-RUN] would write ${RUN_DIR}/reports/06-alunel.txt via ssh alunel"
fi

# ——— izvoras (LAN Linux notebook) ———
echo "$LOG_PREFIX izvoras (SSH snapshot):"
if ! "$DRY_RUN"; then
  IZV_REPORT="${RUN_DIR}/reports/07-izvoras.txt"
  {
    echo "collected=$(date -Iseconds)"
    sudo -u igareosh ssh -o BatchMode=yes -o ConnectTimeout=10 -o IdentitiesOnly=yes \
      -i /home/igareosh/.ssh/id_rsa igareosh@192.168.100.58 \
      'echo host=$(hostname); df -h / | tail -1; systemctl is-active ssh 2>/dev/null || true; systemctl is-active winbind smbd nmbd 2>/dev/null | paste -sd, -; sudo net ads testjoin 2>&1 | tail -1' 2>&1 \
      || echo "izvoras_ssh=fail"
  } > "$IZV_REPORT" 2>&1 || true
else
  echo "$LOG_PREFIX [DRY-RUN] would write ${RUN_DIR}/reports/07-izvoras.txt via ssh izvoras"
fi

# ——— System maintenance run dir (policy: cluster/MAINTENANCE_POLICY.md) ———
if ! "$DRY_RUN"; then
  echo "end=$(date -Iseconds)" >> "${RUN_DIR}/reports/00-meta.txt"
  df -h / /data 2>/dev/null > "${RUN_DIR}/reports/01-disk.txt" || true
  systemctl list-units --state=failed --no-legend --no-pager > "${RUN_DIR}/reports/02-failed-units.txt" 2>/dev/null || true
  {
    echo "heartbeat_http=${CHROMA_HTTP:-0}"
    echo "state=${CHROMA_STATE:-unknown}"
    echo "chroma_heartbeat_url=${CHROMA_HEARTBEAT_URL:-}"
    echo "chroma1_unit=$(ssh -o BatchMode=yes -o ConnectTimeout=5 alunel 'systemctl is-active chroma-1-docker 2>/dev/null' 2>/dev/null || echo 'ssh-fail')"
  } > "${RUN_DIR}/reports/03-chroma.txt" 2>/dev/null || true
  {
    echo "n8n_container_up=${N8N_UP:-no}"
    echo "n8n_healthz_http=${N8N_HTTP:-0}"
  } > "${RUN_DIR}/reports/04-detelina-n8n.txt" 2>/dev/null || true
  {
    echo "workflow_heartbeat_http=${WF_HTTP:-0}"
    echo "state=${WF_STATE:-unknown}"
    echo "unit=$(systemctl is-active workflow-api 2>/dev/null || echo 'not-installed')"
  } > "${RUN_DIR}/reports/05-brain-repo-workflow.txt" 2>/dev/null || true
  if command -v /data/chroma/venv/bin/chops &>/dev/null && [ -d /data/chroma/data ]; then
    /data/chroma/venv/bin/chops db info /data/chroma/data -p &>> "${RUN_DIR}/reports/chroma-chops-db-info.txt" 2>/dev/null || true
  elif command -v /data/chroma/venv/bin/chops &>/dev/null && ssh -o BatchMode=yes -o ConnectTimeout=10 alunel 'test -d /data/chroma/data' 2>/dev/null; then
    ssh -o BatchMode=yes -o ConnectTimeout=10 alunel '/data/chroma/venv/bin/chops db info /data/chroma/data -p' &>> "${RUN_DIR}/reports/chroma-chops-db-info.txt" 2>/dev/null || true
  fi
  {
    echo "# Run summary"
    echo "- **Date**: $(date -Iseconds)"
    echo "- **Host**: prichindel"
    echo "- **Done**: apt update/upgrade, needrestart, disk check, config snapshot to ${BACKUP_DIR}, Chroma state report (and restart if broke), workflow API heartbeat check (reports/05-brain-repo-workflow.txt), Detelina (n8n) state report, alunel SSH snapshot (reports/06-alunel.txt), izvoras SSH snapshot (reports/07-izvoras.txt)"
  } > "${RUN_DIR}/notes/README.md"
  {
    echo "# Next run"
    echo "- Same checklist (apt, needrestart, disk, config snapshot, Chroma state report and fix broke, Detelina (n8n) state report, alunel snapshot reports/06-alunel.txt, izvoras snapshot reports/07-izvoras.txt, system_maintenance run dir)."
    echo "- Chroma: heartbeat + restart if down; if still broken/empty run \`bash cluster/chroma-server/ingest-team10.sh\` (Abelard only). SURVEILLANCE.md §8.2. chops db info in reports/chroma-chops-db-info.txt; if fragmentation/orphans high, plan window for \`chops db clean\` / \`wal commit\` / \`hnsw rebuild\` (stop Chroma first). CHROMA-COOKBOOK-ABELARD.md."
    echo "- Detelina: n8n state in reports/04-detelina-n8n.txt; if down, restart with \`cd /data/n8n && docker compose up -d n8n\`. See cluster/DETELINA-PROD-PIPELINE.md."
    echo "- Brain repo: workflow API in reports/05-brain-repo-workflow.txt; if not 200, \`sudo systemctl restart workflow-api\`. Chroma preflight failures: see agents/abelard/MAINTENANCE-BRAIN-REPO-FLOWS.md."
    echo "- Policy: cluster/MAINTENANCE_POLICY.md"
  } > "${RUN_DIR}/notes/NEXT_RUN.md"
  ln -sfn "${RUN_DIR}" "${SYSMAINT_BASE}/latest"
  echo "$LOG_PREFIX system_maintenance run: $RUN_DIR (latest updated)"
else
  echo "$LOG_PREFIX [DRY-RUN] would create run dir $RUN_DIR (reports, notes, latest)"
fi

echo "$LOG_PREFIX $(date -Iseconds) end"
