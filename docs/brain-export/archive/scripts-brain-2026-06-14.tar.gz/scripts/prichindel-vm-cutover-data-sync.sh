#!/usr/bin/env bash
# Cutover data sync: workspaces + optional hesperia slice. Run on alunel.
set -euo pipefail
PHYS="${PHYS:-192.168.100.21}"
VM="${VM:-192.168.100.121}"
log() { echo "[cutover-data $(date +%H:%M:%S)] $*"; }

tar_path() {
  local path="$1"
  log "tar $path"
  ssh -o BatchMode=yes "igareosh@${PHYS}" "sudo tar czf - -C / ${path#/}" \
    | ssh -o BatchMode=yes "igareosh@${VM}" "sudo tar xzf - -C /"
}

log "PHYS=$PHYS VM=$VM"
tar_path /data/workspaces
log "workspaces done: $(ssh igareosh@${VM} du -sh /data/workspaces/cursor 2>/dev/null || true)"
# Hesperia: only if HESPERIA_SYNC=1 and disk has room (~43G)
if [[ "${HESPERIA_SYNC:-0}" == 1 ]]; then
  tar_path /data/hesperia
  log "hesperia done"
fi
log "DONE"
