#!/usr/bin/env bash
# Deploy agent CA trust to all Linux cluster VMs from alunel.
# Tries short name, .prichindel.local, and LAN IP per host.
# Windows VMs (lamaita, fluturas, olgahere): Abelard scope — see AGENT-SSH-CA.md.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CA_PUB="$HOME/.ssh/agent-ca/agent_ca.pub"
INSTALL_SCRIPT="$SCRIPT_DIR/agent-ssh-install-trust.sh"
SSH_OPTS=(-o ConnectTimeout=6 -o BatchMode=yes)

if [ ! -f "$CA_PUB" ]; then
    echo "ERROR: CA pubkey not found. Run agent-ssh-ca-init.sh first." >&2
    exit 1
fi

# name:ip1:ip2 (optional second IP, e.g. Tailscale)
HOST_ENTRIES=(
    prichindel:192.168.100.21
    alunel:192.168.100.62
    izvoras:192.168.100.58
    stejarel:192.168.100.19
    mugurel:192.168.100.57
    voinicel:192.168.100.90:192.168.100.16
    dnsmaster:192.168.100.25
    chronomaster:192.168.100.63
    mediamaster:192.168.100.64
    altitudine:192.168.100.65
    librarymaster:192.168.100.66:100.89.236.59
    trustmaster:192.168.100.67
    tersagor:192.168.100.68
    fulgusor:192.168.100.40
)

FAILED=()
OK=()
SKIPPED=()

ssh_reachable() {
    local target="$1"
    ssh "${SSH_OPTS[@]}" "igareosh@$target" true 2>/dev/null
}

resolve_target() {
    local name="$1"
    shift
    local ips=("$@")
    local t
    for t in "$name" "${name}.prichindel.local" "${ips[@]}"; do
        [ -n "$t" ] || continue
        if ssh_reachable "$t"; then
            echo "$t"
            return 0
        fi
    done
    return 1
}

install_on_target() {
    local target="$1"
    local label="$2"
    scp -q "${SSH_OPTS[@]}" "$CA_PUB" "igareosh@${target}:/tmp/agent_ca.pub"
    scp -q "${SSH_OPTS[@]}" "$INSTALL_SCRIPT" "igareosh@${target}:/tmp/agent-ssh-install-trust.sh"
    ssh "${SSH_OPTS[@]}" "igareosh@${target}" \
        "sudo bash /tmp/agent-ssh-install-trust.sh /tmp/agent_ca.pub; rm -f /tmp/agent_ca.pub /tmp/agent-ssh-install-trust.sh"
}

already_trusted() {
    local target="$1"
    ssh "${SSH_OPTS[@]}" "igareosh@${target}" \
        'test -f /etc/ssh/agent_ca.pub && grep -q TrustedUserCAKeys /etc/ssh/sshd_config && test -f /etc/sudoers.d/igareosh-agent' \
        2>/dev/null
}

for entry in "${HOST_ENTRIES[@]}"; do
    IFS=: read -r NAME IP1 IP2 <<<"$entry"
    echo "=== $NAME ==="

    if [ "$NAME" = "alunel" ] && [ "$(hostname -s 2>/dev/null || true)" = "alunel" ]; then
        if already_trusted localhost 2>/dev/null || sudo test -f /etc/ssh/agent_ca.pub; then
            OK+=("$NAME")
            echo "OK: $NAME (local, already trusted)"
        elif sudo bash "$INSTALL_SCRIPT" "$CA_PUB"; then
            OK+=("$NAME")
            echo "OK: $NAME (local install)"
        else
            FAILED+=("$NAME")
            echo "FAILED: $NAME (local)"
        fi
        continue
    fi

    IPS=()
    [ -n "${IP1:-}" ] && IPS+=("$IP1")
    [ -n "${IP2:-}" ] && IPS+=("$IP2")

    if ! TARGET=$(resolve_target "$NAME" "${IPS[@]}"); then
        echo "SKIP: $NAME unreachable (name, FQDN, IPs: ${IPS[*]:-none})"
        FAILED+=("$NAME")
        continue
    fi
    echo "Using: igareosh@$TARGET"

    if already_trusted "$TARGET"; then
        OK+=("$NAME")
        echo "OK: $NAME (already trusted via $TARGET)"
        continue
    fi

    if install_on_target "$TARGET" "$NAME"; then
        OK+=("$NAME")
        echo "OK: $NAME"
    else
        echo "FAILED: $NAME (install on $TARGET)"
        FAILED+=("$NAME")
    fi
done

echo ""
echo "=== SUMMARY ==="
echo "OK    (${#OK[@]}): ${OK[*]:-none}"
echo "FAILED(${#FAILED[@]}): ${FAILED[*]:-none}"
echo ""

if [ ${#FAILED[@]} -gt 0 ]; then
    echo "Unreachable or install failed — power on / fix LAN DNS, then re-run this script."
    exit 1
fi

echo "All Linux cluster hosts in registry are CA-trusted."
exit 0
