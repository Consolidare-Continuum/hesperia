#!/usr/bin/env bash
# Run on CERES (WSL or Git Bash) to test SSH to abelard.prichindel.com.
# Usage: bash scripts/test-abelard-tunnel-ceres.sh
ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15 root@abelard.prichindel.com "echo OK; hostname" && echo "PASS" || echo "FAIL"
