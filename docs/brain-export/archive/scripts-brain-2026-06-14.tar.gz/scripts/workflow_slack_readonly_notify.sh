#!/usr/bin/env bash
# Optional: POST workflow snapshot JSON to Slack Incoming Webhook (read-only status).
# Set SLACK_WEBHOOK_URL; no secrets in payload. Same snapshot as workflow_api_snapshot.sh.

set -euo pipefail
if [[ -z "${SLACK_WEBHOOK_URL:-}" ]]; then
  echo "SLACK_WEBHOOK_URL not set; skip." >&2
  exit 0
fi
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
TMP="${TMPDIR:-/tmp}/workflow_snapshot_$$.json"
"$REPO_ROOT/scripts/workflow_api_snapshot.sh" >"$TMP"
payload=$(python3 -c "
import json, sys
snap = json.loads(open(sys.argv[1], encoding='utf-8').read())
text = 'Workflow snapshot (read-only):\\n\\n\`\`\`' + json.dumps(snap, indent=2)[:3500] + '\`\`\`'
print(json.dumps({'text': text}))
" "$TMP")
rm -f "$TMP"
curl -sS -X POST -H 'Content-Type: application/json' -d "$payload" "$SLACK_WEBHOOK_URL" >/dev/null
echo "Posted to Slack webhook (workflow snapshot)."
