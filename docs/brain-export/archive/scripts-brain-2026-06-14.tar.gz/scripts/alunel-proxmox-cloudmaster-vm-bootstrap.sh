#!/usr/bin/env bash
# Bootstrap VM cloudmaster (110) on alunel — Debian 13.5, ownCloud target (fulgusor P2V).
# Run on alunel as igareosh with sudo. Idempotent where possible.
set -euo pipefail

VMID=110
VM_NAME=cloudmaster
# Migration IP; cutover to 192.168.100.40 after physical fulgusor is off.
LAN_IP=192.168.100.72
CLOUD_PATH=/var/lib/vz/template/cache/debian-13-genericcloud-amd64.qcow2
DATA_DISK_GB=512
REPO=''
if [ -d /data/workspaces/cursor ]; then REPO=/data/workspaces/cursor
elif [ -d /data/altitudine/prichindel.com ]; then REPO=/data/altitudine/prichindel.com
else REPO="$(cd "$(dirname "$0")/.." && pwd)"
fi

log() { echo "[cloudmaster-vm] $*"; }

need_root() {
  if [ "$(id -u)" -ne 0 ]; then
    exec sudo -n bash "$0" "$@"
  fi
}

build_sshkeys_file() {
  local f=/tmp/cloudmaster-vm-110-sshkeys
  : >"$f"
  for src in \
    /home/igareosh/.ssh/authorized_keys \
    /home/igareosh/.ssh/id_rsa.pub \
    /home/igareosh/.ssh/id_ed25519_gate_tunnel.pub \
    /home/igareosh/.ssh/fulgusor.pub \
    "$REPO/cluster/alunel/alunel-to-prichindel.pub"; do
    [ -f "$src" ] && cat "$src" >>"$f"
  done
  [ -f /home/igareosh/.ssh/id_ed25519_altitudine_travel.pub ] && \
    cat /home/igareosh/.ssh/id_ed25519_altitudine_travel.pub >>"$f"
  awk '!seen[$0]++' "$f" >"${f}.uniq"
  mv "${f}.uniq" "$f"
  chmod 600 "$f"
  chown igareosh:igareosh "$f"
  echo "$f"
}

create_vm() {
  if qm status "$VMID" &>/dev/null; then
    log "VM $VMID already exists"
    return 0
  fi
  [ -f "$CLOUD_PATH" ] || { log "ERROR: missing $CLOUD_PATH"; exit 1; }
  local keys_file
  keys_file="$(build_sshkeys_file)"
  log "Creating VM $VMID ($VM_NAME) IP $LAN_IP..."
  qm create "$VMID" \
    --name "$VM_NAME" \
    --memory 8192 \
    --cores 4 \
    --cpu host \
    --ostype l26 \
    --agent enabled=1 \
    --serial0 socket \
    --vga serial0 \
    --scsihw virtio-scsi-single \
    --net0 "virtio,bridge=vmbr0,firewall=0" \
    --boot order=scsi0 \
    --ciuser igareosh \
    --sshkeys "$keys_file" \
    --ipconfig0 "ip=${LAN_IP}/24,gw=192.168.100.1" \
    --nameserver "192.168.100.25 192.168.100.19" \
    --searchdomain prichindel.local

  qm importdisk "$VMID" "$CLOUD_PATH" local-lvm
  qm set "$VMID" --scsi0 "local-lvm:vm-${VMID}-disk-0,discard=on,ssd=1"
  qm set "$VMID" --ide0 "local-lvm:cloudinit"
  qm set "$VMID" --bootdisk scsi0
  qm resize "$VMID" scsi0 80G

  log "Adding data disk scsi1 (${DATA_DISK_GB}G on alunel-data)..."
  qm set "$VMID" --scsi1 "alunel-data:${DATA_DISK_GB},discard=on"
  log "VM $VMID created"
}

start_vm() {
  local st
  st="$(qm status "$VMID" 2>/dev/null | awk '{print $2}' || echo missing)"
  if [ "$st" = "running" ]; then
    log "VM $VMID already running"
    return 0
  fi
  qm start "$VMID"
  log "VM $VMID started"
}

wait_guest() {
  log "Waiting for qemu-guest-agent on VM $VMID (up to 180s)..."
  local i
  for i in $(seq 1 36); do
    if qm guest cmd "$VMID" ping &>/dev/null; then
      log "Guest agent OK"
      return 0
    fi
    sleep 5
  done
  log "WARN: guest agent not responding yet"
  return 1
}

post_install_base() {
  log "Post-install: base packages, data disk, hostname..."
  qm guest exec "$VMID" -- bash -lc '
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq openssh-server sudo qemu-guest-agent curl ca-certificates gnupg \
  rsync parted e2fsprogs apache2 mariadb-client ufw
systemctl enable --now qemu-guest-agent ssh
apt-get dist-upgrade -y -qq || true
grep -q igareosh /etc/sudoers.d/99-igareosh-nopasswd 2>/dev/null || {
  echo "igareosh ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/99-igareosh-nopasswd
  chmod 440 /etc/sudoers.d/99-igareosh-nopasswd
}
hostnamectl set-hostname cloudmaster.prichindel.local
grep -q cloudmaster.prichindel.local /etc/hosts || \
  echo "127.0.1.1 cloudmaster cloudmaster.prichindel.local cloudmaster.local" >> /etc/hosts
# Data disk (scsi1) -> /mnt/heimdall
if [ -b /dev/sdb ] && ! grep -q /mnt/heimdall /etc/fstab; then
  parted -s /dev/sdb mklabel gpt mkpart primary ext4 1MiB 100% || true
  sleep 2
  mkfs.ext4 -L heimdall -F /dev/sdb1 2>/dev/null || mkfs.ext4 -L heimdall -F /dev/sdb
  mkdir -p /mnt/heimdall
  UUID=$(blkid -s UUID -o value /dev/sdb1 2>/dev/null || blkid -s UUID -o value /dev/sdb)
  echo "UUID=$UUID /mnt/heimdall ext4 defaults,nofail 0 2" >> /etc/fstab
  mount -a
fi
mkdir -p /mnt/heimdall/owncloud_data
chown www-data:www-data /mnt/heimdall/owncloud_data
ufw --force enable
ufw allow from 192.168.100.0/24 to any port 22 proto tcp
ufw allow from 192.168.100.0/24 to any port 80 proto tcp
ufw allow from 192.168.100.0/24 to any port 443 proto tcp
cat /etc/os-release | head -5
df -h / /mnt/heimdall 2>/dev/null || df -h /
' || true

  if [ -f /home/igareosh/.ssh/agent-ca/agent_ca.pub ]; then
    sudo -u igareosh bash "$REPO/scripts/agent-ssh-install-via-qemu.sh" "$VMID" || \
      log "WARN: agent CA install deferred"
  fi
}

write_status() {
  local out="$REPO/operational/assignments/reports/CLOUDMASTER-VM-110-STATUS.txt"
  mkdir -p "$(dirname "$out")"
  {
    echo "updated: $(date -Is)"
    echo "host: alunel"
    echo "vmid: $VMID"
    echo "name: $VM_NAME"
    echo "lan_ip_migration: $LAN_IP"
    echo "lan_ip_cutover_target: 192.168.100.40"
    echo "cloud_image: $CLOUD_PATH"
    qm status "$VMID" 2>/dev/null || true
    qm config "$VMID" 2>/dev/null | grep -E '^(memory|cores|net|scsi|name)' || true
  } >"$out"
  chown igareosh:igareosh "$out" 2>/dev/null || true
  log "Status: $out"
}

main() {
  need_root "$@"
  create_vm
  start_vm
  wait_guest || true
  post_install_base
  write_status
  log "DONE — VM $VMID cloudmaster on alunel ($LAN_IP); run cloudmaster-migrate-from-fulgusor.sh when fulgusor is reachable"
}

main "$@"
