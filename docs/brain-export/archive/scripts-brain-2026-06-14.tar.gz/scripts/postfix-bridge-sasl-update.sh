#!/usr/bin/env bash
# prichindel — set Postfix sasl_passwd for Proton outbound SMTP. Run as root on prichindel.
# Default relay: smtp.protonmail.ch:587 (TLS). Token = Bridge "external SMTP" / Add device token, not local :1025 secret.
# Ensure main.cf matches: relayhost=[smtp.protonmail.ch]:587, smtp_tls_security_level=encrypt (see ABELARD_QUICK_OPS).
# Ref: agents/abelard/ABELARD_QUICK_OPS.md
set -euo pipefail

USER="${PROTON_SMTP_USER:-${BRIDGE_SMTP_USER:-igareosh@igareosh.com}}"
RELAY="${PROTON_SMTP_RELAY:-${BRIDGE_SMTP_RELAY:-[smtp.protonmail.ch]:587}}"

if [ "$(id -u)" -ne 0 ]; then
  echo "FAIL: run as root (sudo)." >&2
  exit 1
fi

if [ -n "${PROTON_SMTP_TOKEN:-}" ]; then
  PASS="$PROTON_SMTP_TOKEN"
elif [ -n "${BRIDGE_SMTP_PASS:-}" ]; then
  PASS="$BRIDGE_SMTP_PASS"
else
  read -r -s -p "Proton SMTP token / password (no echo): " PASS
  echo "" >&2
fi

if [ -z "$PASS" ]; then
  echo "FAIL: empty password" >&2
  exit 1
fi

cp -a /etc/postfix/sasl_passwd "/etc/postfix/sasl_passwd.bak.$(date +%s)" 2>/dev/null || true
printf '%s\t%s:%s\n' "$RELAY" "$USER" "$PASS" > /etc/postfix/sasl_passwd
chmod 600 /etc/postfix/sasl_passwd
postmap /etc/postfix/sasl_passwd
systemctl reload postfix@-.service
postqueue -f
echo "OK: sasl_passwd updated, postfix reloaded, queue flush triggered. Check: mailq"
