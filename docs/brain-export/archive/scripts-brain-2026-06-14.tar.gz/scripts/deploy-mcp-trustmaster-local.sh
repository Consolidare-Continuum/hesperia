#!/usr/bin/env bash
# Permanent MCP deploy for trustmaster (and any Linux jump host). Idempotent.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
ALUNEL_HOST="${ALUNEL_HOST:-alunel}"
SSH_OPTS=(-o BatchMode=yes -o ConnectTimeout=10)
HERE="$(hostname -s 2>/dev/null || true)"

echo "== deploy-mcp-trustmaster-local (repo=$REPO_ROOT host=$HERE) =="

echo "== fix prichindel known_hosts =="
ssh-keygen -f "${HOME}/.ssh/known_hosts" -R '192.168.100.21' 2>/dev/null || true
ssh-keyscan -t ed25519 192.168.100.21 2>/dev/null >> "${HOME}/.ssh/known_hosts" || true

echo "== sync agent SSH CA cert from alunel =="
mkdir -p "${HOME}/.ssh/agent-ca" && chmod 700 "${HOME}/.ssh/agent-ca"
if [ "$HERE" = "$ALUNEL_HOST" ]; then
  cp "${HOME}/.ssh/agent-ca/id_agent" "${HOME}/.ssh/agent-ca/id_agent-cert.pub" "${HOME}/.ssh/agent-ca/agent_ca.pub" "${HOME}/.ssh/agent-ca/" 2>/dev/null || true
else
  scp "${SSH_OPTS[@]}" \
    "${ALUNEL_HOST}:~/.ssh/agent-ca/id_agent" \
    "${ALUNEL_HOST}:~/.ssh/agent-ca/id_agent-cert.pub" \
    "${ALUNEL_HOST}:~/.ssh/agent-ca/agent_ca.pub" \
    "${HOME}/.ssh/agent-ca/"
fi
chmod 600 "${HOME}/.ssh/agent-ca/id_agent" "${HOME}/.ssh/agent-ca/id_agent-cert.pub" 2>/dev/null || true

echo "== merge agent SSH CA + deploy mcp.json =="
REPO_ROOT="$REPO_ROOT" bash "$REPO_ROOT/scripts/agent-ssh-merge-config.sh"
bash "$REPO_ROOT/scripts/deploy-mcp-config-global.sh"

echo "== ensure LAN hosts =="
grep -q '192.168.100.21.*prichindel' /etc/hosts || echo '192.168.100.21 prichindel prichindel.prichindel.local' | sudo tee -a /etc/hosts >/dev/null
grep -q '192.168.100.62.*alunel' /etc/hosts || echo '192.168.100.62 alunel alunel.prichindel.local' | sudo tee -a /etc/hosts >/dev/null

echo "== verify =="
ssh "${SSH_OPTS[@]}" prichindel 'echo ok' | grep -q ok
ssh "${SSH_OPTS[@]}" alunel 'echo ok' | grep -q ok
bash "$REPO_ROOT/scripts/verify-mcp-handshake.sh"

echo "OK: trustmaster MCP deploy complete. Fully quit and restart Cursor."
