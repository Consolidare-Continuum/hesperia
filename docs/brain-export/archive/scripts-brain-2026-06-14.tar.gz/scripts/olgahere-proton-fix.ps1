# Mass-fix Proton Drive sync folder on olgahere: clear read-only and ensure repo is writable.
# Run on olgahere (as user Olga). Use from prichindel: ssh olgahere 'powershell -ExecutionPolicy Bypass -File -' < scripts/olgahere-proton-fix.ps1
# Or copy script to olgahere and run: powershell -ExecutionPolicy Bypass -File .\olgahere-proton-fix.ps1
# See cluster/olgahere/README.md, REPO-AND-PROTON-POLICY.md.

$ErrorActionPreference = 'Stop'
$script:report = @()

function Find-CursorRepoPath {
    $base = Join-Path $env:USERPROFILE 'Proton Drive'
    if (-not (Test-Path $base)) {
        $script:report += "Proton Drive root not found: $base"
        return $null
    }
    # Common layouts: ...\Proton Drive\igareosh\My files\cursor (canonical), or My files\cursor, or legacy
    $candidates = @(
        (Join-Path $base 'igareosh\My files\cursor'),
        (Join-Path $base 'My files\cursor'),
        (Join-Path $base 'cursor'),
        (Join-Path $base 'igareosh\Other computers\CERES\ceres_proton_drive\cursor'),
        (Join-Path $base 'ceres_proton_drive\cursor')
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) {
            $script:report += "Found cursor repo: $c"
            return $c
        }
    }
    # Fallback: search for cursor under Proton Drive
    $found = Get-ChildItem -Path $base -Filter 'cursor' -Directory -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) {
        $script:report += "Found cursor repo: $($found.FullName)"
        return $found.FullName
    }
    $script:report += "cursor folder not found under $base"
    return $null
}

function Clear-ReadOnlyRecursive {
    param([string]$Path)
    $count = 0
    $errs = 0
    Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            if ($_.Attributes -band [System.IO.FileAttributes]::ReadOnly) {
                $_.Attributes = $_.Attributes -bxor [System.IO.FileAttributes]::ReadOnly
                $count++
            }
        } catch {
            $errs++
        }
    }
    # Clear read-only on the root folder itself
    try {
        $item = Get-Item -Path $Path -Force
        if ($item.Attributes -band [System.IO.FileAttributes]::ReadOnly) {
            $item.Attributes = $item.Attributes -bxor [System.IO.FileAttributes]::ReadOnly
            $count++
        }
    } catch { $errs++ }
    return @{ Cleared = $count; Errors = $errs }
}

# Main
$cursorPath = Find-CursorRepoPath
if (-not $cursorPath) {
    $script:report | ForEach-Object { Write-Host $_ }
    exit 1
}

$result = Clear-ReadOnlyRecursive -Path $cursorPath
$script:report += "Read-only cleared: $($result.Cleared) items; errors: $($result.Errors)"

# Also run attrib -R /S /D for robustness (handles edge cases)
$attribOut = & cmd /c "attrib -R `"$cursorPath\*`" /S /D 2>&1"
# attrib returns 0; ignore stderr if any

$script:report | ForEach-Object { Write-Host $_ }
Write-Host "Done. Retry Proton Drive sync (Activity > Retry syncing)."
exit 0
