#!/bin/bash
# List Cloudflare accounts (and zones for first account). Token from prichindel secret.
# Run on prichindel: bash cf-list-accounts.sh
# Prefers Zero Trust Read (cf-zero-trust-read), then Edit (cf-zero-trust-edit), then cf-api-token. Use from prichindel if token has IP filter.
TOKEN_FILE=""
for f in /root/.secrets/cloudflare/cf-zero-trust-read /root/.secrets/cloudflare/cf-zero-trust-edit /root/.secrets/cloudflare/cf-api-token; do
  if sudo test -r "$f" 2>/dev/null; then TOKEN_FILE="$f"; break; fi
done
if [ -z "$TOKEN_FILE" ]; then echo "No token (cf-zero-trust-read, cf-zero-trust-edit, or cf-api-token)"; exit 1; fi
T=$(sudo cat "$TOKEN_FILE" 2>/dev/null | tr -d '\n\r')
if [ -z "$T" ]; then echo "Empty token in $TOKEN_FILE"; exit 1; fi
CF_EMAIL="${CF_EMAIL:-igareosh@igareosh.com}"

api_accounts() {
  if [ "$AUTH" = "bearer" ]; then
    curl -sS -H 'Authorization: Bearer '"$T" "https://api.cloudflare.com/client/v4/accounts?per_page=50"
  else
    curl -sS -H "X-Auth-Email: $CF_EMAIL" -H "X-Auth-Key: $T" "https://api.cloudflare.com/client/v4/accounts?per_page=50"
  fi
}

api_zones() {
  if [ "$AUTH" = "bearer" ]; then
    curl -sS -H 'Authorization: Bearer '"$T" "https://api.cloudflare.com/client/v4/zones?per_page=50"
  else
    curl -sS -H "X-Auth-Email: $CF_EMAIL" -H "X-Auth-Key: $T" "https://api.cloudflare.com/client/v4/zones?per_page=50"
  fi
}

AUTH=bearer
R=$(api_accounts)
if ! echo "$R" | jq -e '.success == true' >/dev/null 2>&1; then
  AUTH=key
  R=$(api_accounts)
fi
if ! echo "$R" | jq -e '.success == true' >/dev/null 2>&1; then
  echo "API error: $(echo "$R" | jq -r '.errors[]? | "\(.code) \(.message)"' 2>/dev/null || echo "$R")"
  exit 2
fi

echo "=== ACCOUNTS ==="
echo "$R" | jq -r '.result[]? | "  \(.name)  id=\(.id)"'
COUNT=$(echo "$R" | jq -r '.result | length // 0')
AID=$(echo "$R" | jq -r '.result[0].id // empty')

# ZT tokens are account-scoped: GET /accounts returns 0. Use saved cf-account-id and GET /accounts/{id}.
if [ "$COUNT" = "0" ]; then
  AID="${CF_ACCOUNT_ID:-$(sudo cat /root/.secrets/cloudflare/cf-account-id 2>/dev/null | tr -d '\n\r')}"
  if [ -n "$AID" ]; then
    RONE=$(curl -sS -H 'Authorization: Bearer '"$T" "https://api.cloudflare.com/client/v4/accounts/$AID" 2>/dev/null)
    if [ "$AUTH" = "key" ]; then
      RONE=$(curl -sS -H "X-Auth-Email: $CF_EMAIL" -H "X-Auth-Key: $T" "https://api.cloudflare.com/client/v4/accounts/$AID" 2>/dev/null)
    fi
    if echo "$RONE" | jq -e '.success == true' >/dev/null 2>&1; then
      echo "$RONE" | jq -r '.result | "  \(.name)  id=\(.id)  (account-scoped token)"'
    else
      ERR=$(echo "$RONE" | jq -r '.errors[0].message // "use cf-account-id for report/list-seats"')
      echo "(ZT token: 0 accounts listed; account $AID: $ERR)"
    fi
  else
    echo "(none — ZT tokens are account-scoped; set cf-account-id for report/list-seats)"
  fi
fi
echo ""
if [ -n "$AID" ]; then
  echo "=== ZONES (account $AID) ==="
  api_zones | jq -r '.result[]? | "  \(.name)  id=\(.id)  status=\(.status)"'
fi
