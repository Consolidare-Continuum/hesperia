# Runbook — Cluster maintenance (prichindel + fulgusor)

**When**: Daily or on demand; "run maintenance", "maintenance run", or "what do I do for maintenance?". Owner: **Abelard**.

**Where**: Prichindel (local or SSH). Fulgusor data gathered via SSH from prichindel; cluster run = prichindel/ and fulgusor/ subdirs under one run dir.

---

## 1. Policy (every run)

- Create run dir under `/data/system_maintenance/`: `YYYY-MM-DD_<host|cluster>_YYYY-MM-DD_HHMMSS`.
- Required: `reports/` (≥1 file), `backups/` (dir, may be empty), `notes/README.md`, `notes/NEXT_RUN.md`.
- Update symlink: `latest` → this run dir. Access: root-only; use `sudo` to list/read/write.

---

## 2. Script run (prichindel single-host)

**Command** (from repo root on prichindel):
```bash
cd /data/workspaces/cursor
sudo ./scripts/run-maintenance.sh
```

**Optional dry-run**: `sudo ./scripts/run-maintenance.sh --dry-run`

**What it does**: apt update/upgrade, needrestart, disk check, config snapshot to `/data/backups/prichindel/YYYY-MM-DD/`, Chroma state report (and restart if down), Detelina (n8n) state report, **alunel** SSH snapshot (`reports/06-alunel.txt`); creates run dir, reports (00-meta, 01-disk, 02-failed-units, 03-chroma, 04-detelina-n8n, 05-brain-repo-workflow, 06-alunel), notes (README.md, NEXT_RUN.md), updates `latest`.

---

## 3. Manual / cluster run

When running **full cluster** or **manual** maintenance (e.g. fulgusor included, or log cleanup):

1. Create run dir: `sudo mkdir -p /data/system_maintenance/YYYY-MM-DD_cluster_YYYY-MM-DD_HHMMSS/{prichindel,fulgusor}/{reports,backups,notes}`
2. Run prichindel checks; write to `prichindel/reports/`, `prichindel/notes/`.
3. SSH to fulgusor: `ssh igareosh@fulgusor "df -h; free -h; systemctl --failed"` etc.; write output to `fulgusor/reports/`, `fulgusor/notes/`.
4. Optional: SSH to **alunel** (`ssh alunel`) for disk / `net ads testjoin` / winbind; write under `alunel/reports/` or merge into cluster notes (daily script already writes `reports/06-alunel.txt` on prichindel-only runs).
5. Write `notes/README.md` and `notes/NEXT_RUN.md` per host or at cluster level.
6. Update latest: `sudo ln -sfn /data/system_maintenance/<this_run_dir> /data/system_maintenance/latest`

---

## 4. Quick checks (after run or ad hoc)

```bash
sudo ls -la /data/system_maintenance/
sudo ls /data/system_maintenance/latest/
sudo cat /data/system_maintenance/latest/notes/README.md
sudo cat /data/system_maintenance/latest/notes/NEXT_RUN.md
```

---

## Failure modes

| Failure | Symptom | Action |
|---------|---------|--------|
| Run dir not writable | Permission denied | Run with sudo; check /data/system_maintenance ownership (root). |
| Chroma down | reports/03-chroma.txt state=fail | Script restarts chroma-new-docker chroma-new-metrics; if still broken see SURVEILLANCE.md §8.2, CHROMA-COOKBOOK-ABELARD. |
| n8n down | reports/04-detelina-n8n.txt container not running | `cd /data/n8n && docker compose up -d n8n`. See cluster/DETELINA-PROD-PIPELINE. |

---

**Ref**: [cluster/MAINTENANCE_POLICY.md](../cluster/MAINTENANCE_POLICY.md), [cluster/SYSTEM_MAINTENANCE.md](../cluster/SYSTEM_MAINTENANCE.md), [governance/SPEC-ETHAN-DATA-LAYOUT-MAINTENANCE-BACKUP.md](../governance/SPEC-ETHAN-DATA-LAYOUT-MAINTENANCE-BACKUP.md). Owner: Abelard.
