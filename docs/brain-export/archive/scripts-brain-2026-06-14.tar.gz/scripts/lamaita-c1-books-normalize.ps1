# Abelard: normalize C:\1 book filenames + machine list. Run on LAMAITA as igare.
$ErrorActionPreference = 'Stop'
$root = 'C:\1'
$listPath = Join-Path $root 'BOOKS_LIST_MACHINE.txt'
$extBook = @('.pdf', '.epub', '.mobi', '.azw', '.azw3', '.djvu', '.cbz', '.cbr', '.fb2')
$skipNames = @(
    'md5sum.txt', 'README.txt', 'BOOKS_LIST_MACHINE.txt', 'books_list_machine.txt',
    'lamaita-c1-books-normalize.ps1', '_lamaita-c1-books-normalize.ps1', '_abelard_books_normalize.ps1'
)

function Get-RelPath([string]$baseRoot, [string]$fullPath) {
    $b = $baseRoot.TrimEnd('\') + '\'
    if ($fullPath.StartsWith($b, [StringComparison]::OrdinalIgnoreCase)) {
        return $fullPath.Substring($b.Length)
    }
    return $fullPath
}

function Sanitize-Part([string]$s) {
    if ([string]::IsNullOrWhiteSpace($s)) { return 'Unknown' }
    $s = $s -replace '[<>:"/\\|?*]', ''
    $s = $s -replace '\s+', ' '
    $s = $s.Trim()
    if ($s.Length -gt 150) { $s = $s.Substring(0, 150).Trim() }
    if ([string]::IsNullOrWhiteSpace($s)) { return 'Unknown' }
    return $s
}

function Get-AuthorTitle([System.IO.FileInfo]$f) {
    $base = [System.IO.Path]::GetFileNameWithoutExtension($f.Name)
    $base = $base -replace '_-_', ' - '
    $dir = $f.DirectoryName

    # Already normalized (idempotent re-run)
    if ($base -match '^EN\s-\s(.+?)\s-\s(.+)$') {
        return @{ Author = $Matches[1].Trim(); Title = $Matches[2].Trim() }
    }

    if ($dir -like '*Noam Chomsky - 60 Books PDF*') {
        return @{ Author = 'Noam Chomsky'; Title = $base }
    }

    if ($base -match '^(?<title>.+?)\s+by\s+(?<author>.+)$') {
        return @{ Author = $Matches['author'].Trim(); Title = $Matches['title'].Trim() }
    }

    if ($base -match ' - ') {
        $idx = $base.IndexOf(' - ')
        $a = $base.Substring(0, $idx).Trim()
        $t = $base.Substring($idx + 3).Trim()
        if ($t.Length -ge 2 -and $a.Length -ge 1) {
            return @{ Author = $a; Title = $t }
        }
    }

    return @{ Author = 'Unknown'; Title = $base }
}

$all = @(Get-ChildItem -LiteralPath $root -File -Recurse -ErrorAction SilentlyContinue | Where-Object {
    $extBook -contains $_.Extension.ToLowerInvariant() -and ($skipNames -notcontains $_.Name)
})

# Simulate target paths so two planned renames never claim the same final path.
$occupied = @{}
Get-ChildItem -LiteralPath $root -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
    $occupied[$_.FullName.ToLowerInvariant()] = $true
}

function Select-FinalName([string]$dir, [string]$baseNoExt, [string]$ext, [string]$srcFull, [hashtable]$occ) {
    $srcKey = $srcFull.ToLowerInvariant()
    $i = 0
    while ($true) {
        $name = if ($i -eq 0) { "${baseNoExt}${ext}" } else { "${baseNoExt} ($($i + 1))${ext}" }
        $tf = [System.IO.Path]::Combine($dir, $name).ToLowerInvariant()
        if (-not $occ.ContainsKey($tf)) { return @{ Name = $name; TargetKey = $tf } }
        if ($tf -eq $srcKey) { return @{ Name = $name; TargetKey = $tf } }
        $i++
    }
}

$plan = New-Object System.Collections.Generic.List[object]

foreach ($f in ($all | Sort-Object FullName)) {
    $at = Get-AuthorTitle $f
    $auth = Sanitize-Part $at.Author
    $tit = Sanitize-Part $at.Title
    $ext = $f.Extension.ToLowerInvariant()
    if (-not $ext) { $ext = '.pdf' }

    $baseNew = "EN - $auth - $tit"
    $pick = Select-FinalName -dir $f.DirectoryName -baseNoExt $baseNew -ext $ext -srcFull $f.FullName -occ $occupied
    $srcKey = $f.FullName.ToLowerInvariant()
    [void]$occupied.Remove($srcKey)
    $occupied[$pick.TargetKey] = $true
    $finalName = $pick.Name
    $plan.Add([pscustomobject]@{
        Dir       = $f.DirectoryName
        SrcFull   = $f.FullName
        FinalName = $finalName
        Author    = $auth
        Title     = $tit
        Ext       = $ext.TrimStart('.')
    }) | Out-Null
}

foreach ($p in ($plan | Sort-Object { $_.SrcFull.Length } -Descending)) {
    $target = Join-Path $p.Dir $p.FinalName
    if ($p.SrcFull -ieq $target) { continue }
    Rename-Item -LiteralPath $p.SrcFull -NewName $p.FinalName
}

$utf8 = New-Object System.Text.UTF8Encoding $false
$sb = New-Object System.Text.StringBuilder
foreach ($p in ($plan | Sort-Object FinalName)) {
    $finalFull = Join-Path $p.Dir $p.FinalName
    $rel = Get-RelPath $root $finalFull
    $line = "EN`t$($p.Author)`t$($p.Title)`t$($p.Ext)`t$rel"
    [void]$sb.AppendLine($line)
}
[System.IO.File]::WriteAllText($listPath, $sb.ToString(), $utf8)

Write-Output "DONE: $($plan.Count) books; list: $listPath"
