#!/usr/bin/env python3
"""Export approval gate metrics to stdout (JSON) or append weekly line for Ethan visibility."""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent


def main() -> int:
    ap = argparse.ArgumentParser(description="Approval gates metrics export")
    ap.add_argument("--json", action="store_true", help="Pretty JSON to stdout (default)")
    ap.add_argument(
        "--append-weekly-log",
        action="store_true",
        help="Append one markdown row to governance/APPROVAL-GATES-METRICS-LOG.md",
    )
    args = ap.parse_args()

    sys.path.insert(0, str(REPO / "cluster" / "workflow-automation"))
    from approval_metrics import compute_approval_metrics

    data = compute_approval_metrics(REPO)
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    if args.append_weekly_log:
        log_path = REPO / "governance" / "APPROVAL-GATES-METRICS-LOG.md"
        line = (
            f"| {ts[:10]} | pending={data['pending_count']} approved={data['approved_count']} "
            f"rejected={data['rejected_count']} median_s={data['median_seconds_to_decision']} "
            f"mean_s={data['mean_seconds_to_decision']} |\n"
        )
        if not log_path.exists():
            log_path.write_text(
                "# Approval gates metrics (weekly cron / manual)\n\n"
                "| date | summary |\n|------|---------|\n",
                encoding="utf-8",
            )
        with log_path.open("a", encoding="utf-8") as f:
            f.write(line)
        print(f"appended {log_path}", file=sys.stderr)
        return 0

    print(json.dumps({"exported_at": ts, **data}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
