# Harden laptop OpenSSH: key-only, localhost-only.
# Run as Administrator. See cluster/LAPTOP-SECURITY.md.
# Usage: .\scripts\harden-laptop-ssh.ps1 [-WhatIf]

param([switch]$WhatIf)

$ErrorActionPreference = 'Stop'
$cfg = "$env:ProgramData\ssh\sshd_config"

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run as Administrator. Example: Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile -File', (Resolve-Path .\scripts\harden-laptop-ssh.ps1)"
    exit 1
}

if ($WhatIf) {
    Write-Host "WhatIf: would backup $cfg, append PasswordAuthentication no + ListenAddress 127.0.0.1/::1, restart sshd."
    exit 0
}

# Key-only only; ListenAddress 127.0.0.1/::1 was reverted (sshd failed to bind on this build). See cluster/LAPTOP-SECURITY.md.
$add = @"

# Hardening: key-only (cluster/LAPTOP-SECURITY.md)
PasswordAuthentication no
"@

Copy-Item $cfg "$cfg.bak.$(Get-Date -Format 'yyyyMMdd-HHmm')" -Force
Add-Content -Path $cfg -Value $add
Restart-Service sshd
Write-Host "Done. sshd_config hardened and sshd restarted."
