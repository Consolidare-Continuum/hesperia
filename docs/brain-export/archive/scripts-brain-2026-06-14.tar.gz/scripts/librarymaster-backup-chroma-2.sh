#!/usr/bin/env bash
# Backup CHROMA-2 datadir from librarymaster → fulgusor /mnt/arc/backup/chroma-2/
set -euo pipefail
REPO="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
SRC="${CHROMA2_DATA_DIR:-/data/chroma-2/data}"
STAMP=$(date +%Y%m%d-%H%M%S)
DEST_HOST="${CHROMA2_BACKUP_HOST:-fulgusor}"
DEST="/mnt/arc/backup/chroma-2/${STAMP}"

echo "=== CHROMA-2 backup ${STAMP} ==="
[[ -d "$SRC" ]] || { echo "Missing $SRC" >&2; exit 1; }

CHUNKS=0
if curl -sf http://127.0.0.1:8002/api/v2/heartbeat >/dev/null 2>&1 && [[ -x /data/chroma-2/venv/bin/python ]]; then
  CHUNKS=$(/data/chroma-2/venv/bin/python -c "import chromadb; c=chromadb.HttpClient(host='127.0.0.1', port=8002); cols=c.list_collections(); print(c.get_collection('documents').count() if cols else 0)" 2>/dev/null || echo 0)
fi
echo "chunk_count=${CHUNKS} src=${SRC}"

ssh -o BatchMode=yes "${DEST_HOST}" "mkdir -p /mnt/arc/backup/chroma-2"
rsync -a --delete-after "${SRC}/" "${DEST_HOST}:${DEST}/"
ssh -o BatchMode=yes "${DEST_HOST}" "echo chunks=${CHUNKS} stamp=${STAMP} > /mnt/arc/backup/chroma-2/LATEST && du -sh ${DEST}"

echo "OK: ${DEST_HOST}:${DEST}"
