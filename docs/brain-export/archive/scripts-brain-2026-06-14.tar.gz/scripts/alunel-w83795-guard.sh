#!/usr/bin/env bash
# alunel — W83795 fan-mode guard (boot-time restore)
#
# ARCHITECTURE (2026-05-27, confirmed):
#   W83795ADG at i2c-0/0x2f controls fan headers FAN3-FAN8 (all 6 chassis fans).
#   Correct state = pwm2 in THERMAL CRUISE mode (pwm2_enable = 3):
#     bank2 TFMR[0] (reg 0x02) bit 1 = 0x02   ← pwm2 mapped to temp zone 0
#     bank2 FOMC    (reg 0x0F) = 0x01          ← pwm1=DC, pwm2=PWM mode
#   This gives ~1080 RPM idle; ramps with CPU/system temp. BIOS sets this at POST.
#
# WHAT BREAKS IT:
#   Writing pwm2_enable=1 via sysfs (e.g. old alunel-fan-cpu-quiet.service or
#   alunel-fan-passive.sh) clears all TFMR bits → all fans go manual → BIOS
#   override fires → 3000 RPM until BMC mc reset cold or reboot.
#
# THIS SCRIPT:
#   Checks pwm2_enable after w83795 module loads. If it is NOT 3 (thermal cruise),
#   restores the golden state via i2cset to bank 2 registers.
#   NEVER writes pwm2_enable=1, NEVER writes to pwm2 duty directly.
#
# Usage: sudo bash alunel-w83795-guard.sh [check|restore|status]
#   check   — verify state, exit 0 if good, exit 1 + restore if broken (default)
#   restore — force restore golden state regardless
#   status  — print current state only
set -euo pipefail

I2C_BUS=0
I2C_ADDR=0x2f
W83795_DEV="pci0000:00/0000:00:1f.3/i2c-0/0-002f"
PWM_SYSFS="/sys/devices/${W83795_DEV}"

# Golden state (bank 2):
TFMR0_GOLDEN=0x02   # TFMR[0]: bit 1 = pwm2 thermal cruise zone 0
FOMC_GOLDEN=0x01    # FOMC:    bit 0=pwm1 DC, bit 1 clear=pwm2 PWM

log() { echo "$(date -Iseconds) alunel-w83795-guard: $*" | tee -a /var/log/alunel-w83795-guard.log 2>/dev/null || echo "$*"; }

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run as root (sudo)" >&2; exit 1
fi

require_i2c_tools() {
  command -v i2cget >/dev/null 2>&1 && command -v i2cset >/dev/null 2>&1 || {
    log "ERROR: i2c-tools not installed (i2cget/i2cset missing)"; exit 1
  }
}

w83795_loaded() {
  lsmod | grep -q '^w83795'
}

ensure_w83795() {
  if ! w83795_loaded; then
    modprobe w83795 jc42 coretemp 2>/dev/null || true
    sleep 2
  fi
}

read_pwm2_enable() {
  cat "${PWM_SYSFS}/pwm2_enable" 2>/dev/null || echo 0
}

read_bank2_reg() {
  local reg="$1"
  sudo i2cset -y $I2C_BUS $I2C_ADDR 0x00 0x82 2>/dev/null  # select bank 2
  local val; val=$(sudo i2cget -y $I2C_BUS $I2C_ADDR "$reg" 2>/dev/null || echo 0xff)
  sudo i2cset -y $I2C_BUS $I2C_ADDR 0x00 0x80 2>/dev/null  # restore bank 0
  echo "$val"
}

restore_golden() {
  require_i2c_tools
  log "Restoring W83795 golden state (unload module for clean i2c access)..."

  local was_loaded=0
  if w83795_loaded; then
    was_loaded=1
    modprobe -r w83795 2>/dev/null || { log "WARNING: could not unload w83795 — attempting i2cset with module loaded (may fail)"; }
    sleep 1
  fi

  # Select bank 2, write TFMR[0] and FOMC, restore bank 0
  i2cset -y $I2C_BUS $I2C_ADDR 0x00 0x82            # bank 2
  i2cset -y $I2C_BUS $I2C_ADDR 0x02 $TFMR0_GOLDEN   # TFMR[0] = 0x02
  i2cset -y $I2C_BUS $I2C_ADDR 0x0f $FOMC_GOLDEN    # FOMC    = 0x01
  i2cset -y $I2C_BUS $I2C_ADDR 0x00 0x80            # bank 0

  log "Written: TFMR[0]=0x02 FOMC=0x01 (bank 2)"

  if [[ "$was_loaded" == 1 ]]; then
    modprobe w83795 jc42 coretemp 2>/dev/null || true
    sleep 3
    local pwm2_en; pwm2_en=$(read_pwm2_enable)
    if [[ "$pwm2_en" == 3 ]]; then
      log "OK: pwm2_enable=3 (thermal cruise) confirmed after restore."
    else
      log "WARNING: pwm2_enable=$pwm2_en after restore — may need cold reboot."
    fi
  fi
}

print_status() {
  ensure_w83795
  local pwm2_en; pwm2_en=$(read_pwm2_enable)
  echo "pwm2_enable = $pwm2_en (3=thermal cruise, 1=manual=broken)"
  sensors w83795adg-i2c-0-2f 2>/dev/null | grep -E 'fan[24678]:|pwm1:|pwm2:|temp1:|temp7:|temp8:' || true
  echo "System Temp (BMC):" && ipmitool sdr elist 2>/dev/null | grep 'System Temp' || true
}

CMD="${1:-check}"
case "$CMD" in
  status)
    print_status
    ;;
  restore)
    restore_golden
    print_status
    ;;
  check)
    ensure_w83795
    pwm2_en=$(read_pwm2_enable)
    if [[ "$pwm2_en" == 3 ]]; then
      log "OK: pwm2_enable=3 (thermal cruise). Fans nominal."
      exit 0
    else
      log "BROKEN: pwm2_enable=$pwm2_en (expected 3=thermal cruise). Triggering restore..."
      restore_golden
    fi
    ;;
  *)
    echo "Usage: $0 {check|restore|status}" >&2; exit 2
    ;;
esac
