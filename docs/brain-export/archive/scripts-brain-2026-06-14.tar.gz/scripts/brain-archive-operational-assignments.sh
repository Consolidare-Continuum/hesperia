#!/usr/bin/env bash
# Compress operational/assignments → dev repo archive; slim brain to live triage only.
set -euo pipefail

BRAIN="${BRAIN_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
ASSIGN="$BRAIN/operational/assignments"
STAMP="${ARCHIVE_STAMP:-$(date -u +%Y-%m-%d)}"
ARCHIVE_NAME="operational-assignments-${STAMP}.tar.gz"
SUMS_NAME="operational-assignments-${STAMP}.SHA256SUMS.txt"
REMOTE="${ARCHIVE_REMOTE:-altitudine}"
HES_DEV="${HESPERIA_DEV:-/data/workspaces/atomic-commit-hesperia}"
ARCHIVE_DIR="$HES_DEV/docs/brain-export/archive"
GIT="-c user.email=igareosh@igareosh.com -c user.name=igareosh"

KEEP=(
  "README.md"
  "GRACE-TRIAGE-PAPRA-CHROMA-2-SCHEMA-2026-06-14.md"
  "GRACE-TRIAGE-HES-DEBLOAT-WAVE2-2026-06-14.md"
)

[[ -d "$ASSIGN" ]] || { echo "FAIL: missing $ASSIGN" >&2; exit 1; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "=== archive operational/assignments ($STAMP) ==="
tar -C "$BRAIN/operational" -czf "$TMP/$ARCHIVE_NAME" assignments
sha256sum "$TMP/$ARCHIVE_NAME" | tee "$TMP/$SUMS_NAME"
ls -lh "$TMP/$ARCHIVE_NAME"

scp "$TMP/$ARCHIVE_NAME" "$TMP/$SUMS_NAME" "$REMOTE:/tmp/"

ssh "$REMOTE" "set -e
mkdir -p $ARCHIVE_DIR
mv /tmp/$ARCHIVE_NAME /tmp/$SUMS_NAME $ARCHIVE_DIR/
cd $HES_DEV
git $GIT add docs/brain-export/archive/$ARCHIVE_NAME docs/brain-export/archive/$SUMS_NAME
cat >> docs/brain-export/archive/README.md <<EOF

## $ARCHIVE_NAME

- **Created:** $(date -u +%Y-%m-%dT%H:%MZ)
- **Source:** brain \`operational/assignments/\` (full tree before slim)
- **SHA256:** \$(grep $ARCHIVE_NAME $ARCHIVE_DIR/$SUMS_NAME | awk '{print \$1}')
EOF
git $GIT add docs/brain-export/archive/README.md
git $GIT diff --cached --quiet || git $GIT commit -m 'docs(dev): archive operational/assignments brain tree ($STAMP)'
git $GIT push dev main
echo remote: \$(git rev-parse --short HEAD)
"

# Slim brain: save keep files, wipe, restore
SAVE="$TMP/keep"
mkdir -p "$SAVE"
for f in "${KEEP[@]}"; do
  [[ -f "$ASSIGN/$f" ]] && cp -a "$ASSIGN/$f" "$SAVE/" || true
done

find "$ASSIGN" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
mkdir -p "$SAVE-reports" 2>/dev/null || true

cat > "$ASSIGN/README.md" <<EOF
# operational/assignments — slim index (archived ${STAMP})

**Full tree archived** — not deleted. Canonical copy:

| Artifact | Location |
|----------|----------|
| **Tarball** | [\`docs/brain-export/archive/${ARCHIVE_NAME}\`](https://github.com/igareosh/hesperia/tree/main/docs/brain-export/archive) on **igareosh/hesperia** |
| **Hesperia/Tersagor exports** | \`docs/brain-export/\` on **igareosh/hesperia** |
| **Checksums** | \`${SUMS_NAME}\` alongside tarball on dev repo |

## Live triage (brain only)

| File | Wave |
|------|------|
| [GRACE-TRIAGE-PAPRA-CHROMA-2-SCHEMA-2026-06-14.md](GRACE-TRIAGE-PAPRA-CHROMA-2-SCHEMA-2026-06-14.md) | PAPRA reindex (IN_PROGRESS) |
| [GRACE-TRIAGE-HES-DEBLOAT-WAVE2-2026-06-14.md](GRACE-TRIAGE-HES-DEBLOAT-WAVE2-2026-06-14.md) | Hesperia debloat closure |

Historical \`active.md\` links to moved paths → open tarball or \`docs/brain-export/operational/\` on dev repo.

**Do not** re-expand this folder in brain — add new triage packets here; archive again when wave closes.
EOF

for f in "${KEEP[@]}"; do
  [[ "$f" == "README.md" ]] && continue
  [[ -f "$SAVE/$f" ]] && cp -a "$SAVE/$f" "$ASSIGN/"
done

echo "=== slim complete ==="
echo "brain files left: $(find "$ASSIGN" -type f | wc -l)"
du -sh "$ASSIGN"
echo "archive: $ARCHIVE_DIR/$ARCHIVE_NAME on igareosh/hesperia"
