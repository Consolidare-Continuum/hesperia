#!/usr/bin/env bash
# Ghost-deploy prod stacks from physical prichindel → VM 107 (.121) before cutover.
# Run on alunel as igareosh. Requires: ssh to prichindel (physical .21) and VM (.121).
set -euo pipefail

PHYS="${PHYS:-192.168.100.21}"
VM="${VM:-192.168.100.121}"
PHYS_USER="${PHYS_USER:-igareosh}"
VM_USER="${VM_USER:-igareosh}"
LOG="${LOG:-/tmp/prichindel-vm-ghost-deploy.log}"

log() { echo "[ghost-deploy $(date +%H:%M:%S)] $*" | tee -a "$LOG"; }

rsync_from_phys() {
  local src="$1" dest="$2"
  local stage="/data/workspaces/cursor/tmp/ghost-rsync-stage"
  log "rsync $src → VM:$dest (via alunel staging)"
  mkdir -p "$stage"
  rsync -aHAX --partial -e "ssh -o BatchMode=yes" --rsync-path="sudo rsync" \
    "${PHYS_USER}@${PHYS}:${src}" "${stage}/"
  rsync -aHAX --partial -e "ssh -o BatchMode=yes" \
    "${stage}/" "${VM_USER}@${VM}:${dest}"
  rm -rf "$stage"
}

vm_exec() {
  ssh -o BatchMode=yes "${VM_USER}@${VM}" "$@"
}

phys_exec() {
  ssh -o BatchMode=yes "${PHYS_USER}@${PHYS}" "$@"
}

install_base() {
  log "Install Docker, nginx, apache on VM"
  vm_exec "sudo bash -lc '
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq ca-certificates curl gnupg rsync locales-all
# Docker CE (official)
install -d /etc/apt/keyrings
if [ ! -f /etc/apt/keyrings/docker.gpg ]; then
  curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo \"deb [arch=\$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian trixie stable\" > /etc/apt/sources.list.d/docker.list
fi
apt-get update -qq
apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
systemctl enable --now docker
usermod -aG docker igareosh
# Web stack
apt-get install -y -qq nginx
systemctl enable nginx
# Apache: install but do not bind :80 until prod vhosts synced (nginx owns :80)
apt-get install -y -qq apache2 libapache2-mod-security2 ssl-cert \
  certbot python3-certbot-nginx msmtp msmtp-mta
systemctl stop apache2 2>/dev/null || true
a2dissite 000-default.conf 2>/dev/null || true
a2enmod proxy proxy_http proxy_fcgi ssl headers rewrite remoteip 2>/dev/null || true
a2enmod php8.4 2>/dev/null || true
mkdir -p /data/docker /data/CLIENTS /data/n8n /var/www/html /var/www/acc /srv/msmtp/conf /srv/msmtp/log /srv/msmtp/php
mkdir -p /etc/ssl/cloudflare
docker --version
docker compose version
'"
}

sync_data() {
  log "Sync /data/docker"
  vm_exec "sudo mkdir -p /data/docker && sudo chown igareosh:igareosh /data/docker"
  rsync_from_phys "/data/docker/" "/data/docker/"

  log "Sync /data/CLIENTS (--exclude .git — physical biopole .git may I/O-error)"
  vm_exec "sudo mkdir -p /data/CLIENTS && sudo chown igareosh:igareosh /data/CLIENTS"
  local stage="/data/workspaces/cursor/tmp/ghost-rsync-stage"
  mkdir -p "$stage"
  rsync -aHAX --partial -e "ssh -o BatchMode=yes" --rsync-path="sudo rsync" \
    --exclude='.git' "${PHYS_USER}@${PHYS}:/data/CLIENTS/" "${stage}/"
  rsync -aHAX --partial -e "ssh -o BatchMode=yes" "${stage}/" "${VM_USER}@${VM}:/data/CLIENTS/"
  rm -rf "$stage"

  log "Sync /data/n8n"
  vm_exec "sudo chown -R igareosh:igareosh /data/n8n 2>/dev/null || sudo mkdir -p /data/n8n && sudo chown igareosh:igareosh /data/n8n"
  rsync_from_phys "/data/n8n/" "/data/n8n/"

  log "Sync web roots and msmtp"
  vm_exec "sudo mkdir -p /var/www /srv/msmtp && sudo chown -R igareosh:igareosh /var/www /srv/msmtp"
  rsync_from_phys "/var/www/html/" "/var/www/html/"
  phys_exec "sudo tar czf - -C /var/www/html prichindel" | vm_exec "sudo tar xzf - -C /var/www/html"
  rsync_from_phys "/var/www/acc/" "/var/www/acc/" || rsync_from_phys "/data/CLIENTS/acc/" "/var/www/acc/"
  rsync_from_phys "/srv/msmtp/" "/srv/msmtp/"

  log "Superset config file at biopole mount path (physical may have had empty dir)"
  phys_exec "sudo rm -rf /data/biopole/acc_volume/python/superset_config.py 2>/dev/null; \
    sudo mkdir -p /data/biopole/acc_volume/python && \
    sudo cp /data/docker/superset/docker/pythonpath_dev/superset_config.py /data/biopole/acc_volume/python/superset_config.py 2>/dev/null || \
    sudo cp /data/docker/superset/config/superset_config.py /data/biopole/acc_volume/python/superset_config.py"
  phys_exec "sudo tar czf - -C / data/biopole/acc_volume/python/superset_config.py" | vm_exec "sudo tar xzf - -C /"
}

sync_web_config() {
  log "Sync nginx + apache + cloudflare origin certs (ghost copy)"
  vm_exec "sudo mkdir -p /etc/nginx /etc/apache2 /etc/ssl/cloudflare"
  rsync_from_phys "/etc/nginx/nginx.conf" "/tmp/nginx.conf"
  rsync_from_phys "/etc/nginx/conf.d/" "/tmp/nginx-conf.d/"
  rsync_from_phys "/etc/nginx/sites-available/" "/tmp/nginx-sites-available/" 2>/dev/null || true
  rsync_from_phys "/etc/nginx/sites-enabled/" "/tmp/nginx-sites-enabled/" 2>/dev/null || true
  rsync_from_phys "/etc/apache2/sites-available/" "/tmp/apache-sites-available/" 2>/dev/null || true
  rsync_from_phys "/etc/apache2/sites-enabled/" "/tmp/apache-sites-enabled/" 2>/dev/null || true
  rsync_from_phys "/etc/apache2/apache2.conf" "/tmp/apache2.conf" 2>/dev/null || true
  rsync_from_phys "/etc/apache2/ports.conf" "/tmp/ports.conf" 2>/dev/null || true
  rsync_from_phys "/etc/ssl/cloudflare/" "/tmp/cloudflare-ssl/" 2>/dev/null || true
  # letsencrypt live certs + options (nginx sites reference these paths)
  phys_exec "sudo tar czf - -C / etc/letsencrypt" | vm_exec "sudo tar xzf - -C /" || true
  vm_exec "sudo bash -lc '
    mkdir -p /etc/letsencrypt
    if [ ! -f /etc/letsencrypt/options-ssl-nginx.conf ]; then
      cp /usr/lib/python3/dist-packages/certbot_nginx/_internal/tls_configs/options-ssl-nginx.conf /etc/letsencrypt/ 2>/dev/null || true
    fi
  '"

  vm_exec "sudo bash -lc '
set -e
cp /tmp/nginx.conf /etc/nginx/nginx.conf
rm -rf /etc/nginx/conf.d && cp -a /tmp/nginx-conf.d /etc/nginx/conf.d
rm -f /etc/nginx/sites-enabled/default
[ -d /tmp/nginx-sites-available ] && cp -a /tmp/nginx-sites-available/* /etc/nginx/sites-available/ 2>/dev/null || true
[ -d /tmp/nginx-sites-enabled ] && rm -f /etc/nginx/sites-enabled/* && cp -a /tmp/nginx-sites-enabled/* /etc/nginx/sites-enabled/ 2>/dev/null || true
[ -f /tmp/apache2.conf ] && cp /tmp/apache2.conf /etc/apache2/apache2.conf
[ -f /tmp/ports.conf ] && cp /tmp/ports.conf /etc/apache2/ports.conf
[ -d /tmp/apache-sites-available ] && cp -a /tmp/apache-sites-available/* /etc/apache2/sites-available/ 2>/dev/null || true
[ -d /tmp/apache-sites-enabled ] && rm -f /etc/apache2/sites-enabled/* && cp -a /tmp/apache-sites-enabled/* /etc/apache2/sites-enabled/ 2>/dev/null || true
[ -d /tmp/cloudflare-ssl ] && cp -a /tmp/cloudflare-ssl/* /etc/ssl/cloudflare/ 2>/dev/null || true
nginx -t
apache2ctl configtest
'"
}

sync_secrets() {
  log "Sync full /root/.secrets tree from physical"
  phys_exec "sudo tar czf - -C /root .secrets" | vm_exec "sudo tar xzf - -C /root"
  vm_exec "sudo find /root/.secrets -type f -exec chmod 600 {} \\; 2>/dev/null || true"
}

deploy_authentik_proxy() {
  log "authentik-proxy-shetiyya (standalone — env from physical container)"
  local envf="/tmp/authentik-proxy-ghost.env"
  phys_exec "docker inspect authentik-proxy-shetiyya -f '{{range .Config.Env}}{{println .}}{{end}}'" >"$envf"
  local img
  img="$(phys_exec "docker inspect authentik-proxy-shetiyya -f '{{.Config.Image}}'")"
  scp -q -o BatchMode=yes "$envf" "${VM_USER}@${VM}:/tmp/authentik-proxy.env"
  vm_exec "docker rm -f authentik-proxy-shetiyya 2>/dev/null || true; \
    docker run -d --name authentik-proxy-shetiyya --restart unless-stopped \
    -p 127.0.0.1:19000:9000 --env-file /tmp/authentik-proxy.env ${img} && rm -f /tmp/authentik-proxy.env"
  rm -f "$envf"
}

start_stacks() {
  sync_secrets

  log "Start Docker stacks on VM (order: databases → php81 → prometheus → superset → n8n → acc → biopole → authentik)"
  vm_exec "bash -lc '
set -e
cd /data/docker/databases && docker compose up -d
sleep 5
cd /data/docker/php81 && docker compose build --quiet 2>/dev/null || docker compose build
cd /data/docker/php81 && docker compose up -d
sudo chown -R 65534:65534 /data/docker/prometheus
cd /data/docker/prometheus && docker compose up -d
cd /data/docker/superset && docker compose up -d
cd /data/n8n && sudo docker compose up -d
[ -f /var/www/acc/docker-compose.yml ] && cd /var/www/acc && docker compose up -d || \
  [ -f /data/CLIENTS/acc/docker-compose.yml ] && cd /data/CLIENTS/acc && docker compose up -d || true
BOT=/data/CLIENTS/biopole/biopole_cursor_repo/telegram_ai_bot_repo
if [ -f \"\$BOT/docker-compose.yml\" ]; then
  cd \"\$BOT\" && docker compose build && docker compose up -d
fi
docker ps --format \"table {{.Names}}\\t{{.Status}}\" | head -28
'"
  deploy_authentik_proxy
}

start_web() {
  log "Enable nginx + apache (ghost — reachable on .121 / .21 when cabled)"
  vm_exec "sudo systemctl enable nginx apache2 && sudo systemctl restart nginx apache2 && systemctl is-active nginx apache2"
}

smoke() {
  log "Smoke on VM localhost"
  vm_exec "bash -lc '
curl -sf -o /dev/null -w \"nginx:%{http_code}\\n\" http://127.0.0.1/ || echo nginx_fail
curl -sf -o /dev/null -w \"superset:%{http_code}\\n\" http://127.0.0.1:8088/health 2>/dev/null || echo superset_skip
curl -sf -o /dev/null -w \"n8n:%{http_code}\\n\" http://127.0.0.1:5678/ 2>/dev/null || echo n8n_skip
curl -sf -o /dev/null -w \"bot:%{http_code}\\n\" http://127.0.0.1:18080/health 2>/dev/null || echo bot_skip
curl -sf -o /dev/null -w \"authentik:%{http_code}\\n\" http://127.0.0.1:19000/outpost.goauthentik.io/ping 2>/dev/null || echo authentik_skip
ss -tlnp | grep -E \":(80|443|8088|5678|18080|19000|3306|5432|9090)\" | head -15
'"
}

main() {
  : >"$LOG"
  log "PHYS=$PHYS VM=$VM"
  if [ "${SKIP_INSTALL:-0}" != 1 ]; then
    install_base
  else
    log "SKIP_INSTALL=1"
  fi
  sync_data
  sync_web_config
  start_stacks
  vm_exec "sudo apache2ctl configtest 2>&1 | tail -2"
  start_web
  smoke
  log "DONE — ghost stacks on VM; test: curl http://${VM}/ from alunel"
}

main "$@"
