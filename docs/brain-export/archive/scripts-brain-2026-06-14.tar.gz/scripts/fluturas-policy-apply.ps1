# fluturas-policy-apply.ps1 — Abelard policy: Defender off, firewall default + SSH allow, WSL down by default.
# Run on fluturas as Administrator. Do NOT lock SSH to subnet or block Cloudflare.
# Requires: -ExecutionPolicy Bypass

$ErrorActionPreference = 'Stop'
# Self-elevate if not Admin
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

Write-Host "=== 1. Disable Windows Defender ==="
# Policy: disable Defender entirely
$defPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender'
if (-not (Test-Path $defPath)) { New-Item -Path $defPath -Force | Out-Null }
Set-ItemProperty -Path $defPath -Name DisableAntiSpyware -Value 1 -Type DWord -Force
# Real-time off (if module loaded)
try {
    Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue
} catch {}
# Stop and disable services (by index to avoid "collection modified" during iteration)
$svcs = @('WinDefend', 'WdNisSvc', 'WdNisDrv', 'SecurityHealthService')
for ($i = 0; $i -lt $svcs.Count; $i++) {
    $s = $svcs[$i]
    if (Get-Service -Name $s -ErrorAction SilentlyContinue) {
        try { Stop-Service -Name $s -Force -ErrorAction Stop } catch { Write-Host "  $s stop: $_" }
        try { Set-Service -Name $s -StartupType Disabled -ErrorAction Stop } catch { Write-Host "  $s disable: $_" }
        Write-Host "  $s stopped and disabled"
    }
}
# WdNisDrv is a driver; disabling WinDefend and WdNisSvc is the main step.
Write-Host "Defender policy set; services stopped/disabled."

Write-Host "`n=== 2. Firewall: reset to default, then allow SSH 22 ==="
& netsh advfirewall reset
# Allow TCP 22 inbound — do NOT restrict to subnet; allow any (Private + Public so Cloudflare not locked)
$ruleName = 'OpenSSH (Abelard)'
# Remove if exists so we don't duplicate
netsh advfirewall firewall delete rule name="$ruleName" 2>$null
netsh advfirewall firewall add rule name="$ruleName" dir=in action=allow protocol=TCP localport=22
Write-Host "Firewall reset; rule '$ruleName' added (TCP 22 inbound, no subnet lock)."

Write-Host "`n=== 3. Windows OpenSSH Server on 22 (so SSH works without WSL) ==="
# Remove portproxy for 22 so Windows sshd gets traffic (not WSL)
netsh interface portproxy delete v4tov4 listenport=22 listenaddress=0.0.0.0 2>$null
netsh interface portproxy delete v4tov4 listenport=22 listenaddress=:: 2>$null
if (Get-Service -Name sshd -ErrorAction SilentlyContinue) {
    Set-Service -Name sshd -StartupType Automatic -ErrorAction SilentlyContinue
    Start-Service -Name sshd -ErrorAction SilentlyContinue
    Write-Host "sshd set Auto and started (port 22)."
} else {
    Write-Host "sshd not found. Install OpenSSH Server (Settings > Apps > Optional features) then re-run."
}

Write-Host "`n=== 4. WSL down by default ==="
if (Get-Service -Name LxssManager -ErrorAction SilentlyContinue) {
    Stop-Service -Name LxssManager -Force -ErrorAction SilentlyContinue
    Set-Service -Name LxssManager -StartupType Disabled -ErrorAction SilentlyContinue
    Write-Host "LxssManager stopped and disabled (WSL down by default)."
} else {
    Write-Host "LxssManager not found (WSL may not be installed)."
}

Write-Host "`n=== Done. Reboot recommended. SSH (22) = Windows sshd; Defender off; WSL disabled at boot. ==="
