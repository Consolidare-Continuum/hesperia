#!/usr/bin/env bash
# Archive DONE (and optionally ARCHIVED) rows from active.md to archive/active_archive.md.
# Keeps: header, table header, OPEN / IN_PROGRESS / PAUSED rows.
# Run from repo root. Safe: writes archive first, then rewrites active.md.
#
# USAGE:
#   ./scripts/active_md_archive.sh              # dry run — shows what would move
#   ./scripts/active_md_archive.sh --run        # execute archive
#   ./scripts/active_md_archive.sh --run --also-paused   # also archive PAUSED rows
#
# Ref: governance/SPEC-ETHAN-FULL-AUTO-ACTIVE-MD-PRODUCT.md, active.md §STATUS

set -euo pipefail
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
ACTIVE="${REPO_ROOT}/active.md"
ARCHIVE_DIR="${REPO_ROOT}/archive"
ARCHIVE="${ARCHIVE_DIR}/active_archive.md"

RUN=0
ALSO_PAUSED=0
for arg in "$@"; do
  case "$arg" in
    --run)        RUN=1 ;;
    --also-paused) ALSO_PAUSED=1 ;;
    --help|-h)
      sed -n '2,15p' "$0"
      exit 0
      ;;
  esac
done

if [[ ! -f "$ACTIVE" ]]; then
  echo "ERROR: $ACTIVE not found." >&2
  exit 1
fi
mkdir -p "$ARCHIVE_DIR"

# Build status filter: always archive DONE; optionally ARCHIVED status rows too.
# PAUSED rows stay unless --also-paused.
archive_status() {
  local s="$1"
  [[ "$s" == "DONE" ]] && return 0
  [[ "$s" == "ARCHIVED" ]] && return 0
  [[ "$ALSO_PAUSED" == "1" && "$s" == "PAUSED" ]] && return 0
  return 1
}

HEADER_LINES=()
TABLE_HEADER=()
KEEP_ROWS=()
ARCHIVE_ROWS=()
in_table=0

while IFS= read -r line; do
  if [[ "$line" =~ ^\|[[:space:]]*Priority ]]; then
    in_table=1
    TABLE_HEADER+=("$line")
    continue
  fi
  if [[ "$in_table" == "0" ]]; then
    HEADER_LINES+=("$line")
    continue
  fi
  if [[ "$line" =~ ^\|[[:space:]]*[-|[:space:]]+$ ]]; then
    TABLE_HEADER+=("$line")
    continue
  fi
  if [[ ! "$line" =~ ^\| ]]; then
    KEEP_ROWS+=("$line")
    continue
  fi
  # Parse status field (column 5, 0-indexed: Priority|Project|Task|Owner|Status|Link)
  IFS='|' read -ra cols <<< "$line"
  status=""
  if [[ ${#cols[@]} -ge 6 ]]; then
    status=$(echo "${cols[5]}" | tr -d '[:space:]' | tr '[:lower:]' '[:upper:]')
  fi
  if archive_status "$status"; then
    ARCHIVE_ROWS+=("$line")
  else
    KEEP_ROWS+=("$line")
  fi
done < "$ACTIVE"

echo "active.md: ${#ARCHIVE_ROWS[@]} rows to archive, ${#KEEP_ROWS[@]} rows to keep."

if [[ "${#ARCHIVE_ROWS[@]}" -eq 0 ]]; then
  echo "Nothing to archive."
  exit 0
fi

if [[ "$RUN" == "0" ]]; then
  echo "(dry run — pass --run to execute)"
  echo ""
  echo "Sample rows that would be archived:"
  for r in "${ARCHIVE_ROWS[@]}"; do
    echo "  $r"
  done | head -20
  exit 0
fi

# Write archive (append)
{
  echo ""
  echo "## Archived $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo ""
  echo "| Priority | Project | Task | Owner | Status | Link |"
  echo "|----------|---------|------|--------|--------|------|"
  for r in "${ARCHIVE_ROWS[@]}"; do
    echo "$r"
  done
} >> "$ARCHIVE"

# Rewrite active.md (header + table header + kept rows)
{
  for h in "${HEADER_LINES[@]}"; do echo "$h"; done
  for h in "${TABLE_HEADER[@]}"; do echo "$h"; done
  for r in "${KEEP_ROWS[@]}"; do echo "$r"; done
} > "${ACTIVE}.tmp"
mv "${ACTIVE}.tmp" "$ACTIVE"

echo "Done. Archived ${#ARCHIVE_ROWS[@]} rows to $ARCHIVE."
echo "active.md now has ${#KEEP_ROWS[@]} data rows."
