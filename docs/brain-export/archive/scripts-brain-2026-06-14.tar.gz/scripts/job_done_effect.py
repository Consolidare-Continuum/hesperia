#!/usr/bin/env python3
"""
Job Done Effect — audiovisual feedback when tasks complete.

Usage:
  job_done_effect.py                    # Default effect (TV flash + telegram)
  job_done_effect.py --tv-only          # TV flash only
  job_done_effect.py --telegram-only    # Telegram only
  job_done_effect.py --message "Done!"  # Custom message for Telegram
  job_done_effect.py --silent           # TV only, no telegram
  job_done_effect.py --flash N          # Flash TV N times (default 2)

Effects:
  - TV: Brief brightness flash (dims then restores)
  - Telegram: "✓ Job done" notification to @igareosh

Requires: vidaa_tv_control.py, telegram_send.py in same scripts/ dir or cluster paths.
"""

import argparse
import subprocess
import sys
import time
from pathlib import Path

# Find scripts
SCRIPT_DIR = Path(__file__).parent.resolve()
VIDAA_CONTROL = SCRIPT_DIR / "vidaa_tv_control.py"
TELEGRAM_SEND = SCRIPT_DIR.parent / "cluster" / "abelard-headless" / "scripts" / "telegram_send.py"

# Fallback paths
if not TELEGRAM_SEND.exists():
    TELEGRAM_SEND = Path("/data/workspaces/cursor/cluster/abelard-headless/scripts/telegram_send.py")
if not TELEGRAM_SEND.exists():
    TELEGRAM_SEND = Path("/home/agent/cursor/cluster/abelard-headless/scripts/telegram_send.py")


def run_cmd(cmd: list[str], timeout: int = 10) -> tuple[bool, str]:
    """Run command, return (success, output)."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout.strip() + result.stderr.strip()
    except subprocess.TimeoutExpired:
        return False, "timeout"
    except Exception as e:
        return False, str(e)


def get_tv_brightness() -> int | None:
    """Get current TV brightness (0-100) or None if unavailable."""
    if not VIDAA_CONTROL.exists():
        return None
    ok, out = run_cmd([sys.executable, str(VIDAA_CONTROL), "status"])
    if not ok:
        return None
    for line in out.splitlines():
        if "Brightness:" in line:
            try:
                return int(line.split(":")[1].strip().rstrip("%"))
            except (ValueError, IndexError):
                pass
    return None


def set_tv_brightness(level: int) -> bool:
    """Set TV brightness (0-100)."""
    if not VIDAA_CONTROL.exists():
        return False
    ok, _ = run_cmd([sys.executable, str(VIDAA_CONTROL), "brightness", str(level)])
    return ok


def flash_tv(times: int = 2, dim_level: int = 20, delay: float = 0.3) -> bool:
    """Flash TV brightness: dim → restore, repeated."""
    original = get_tv_brightness()
    if original is None:
        print("TV not available or brightness read failed.", file=sys.stderr)
        return False
    
    # Ensure we have a noticeable difference
    target_dim = min(dim_level, max(0, original - 40))
    
    print(f"Flashing TV (brightness {original}% → {target_dim}% → {original}%) x{times}")
    
    success = True
    for i in range(times):
        # Dim
        if not set_tv_brightness(target_dim):
            success = False
            break
        time.sleep(delay)
        # Restore
        if not set_tv_brightness(original):
            success = False
            break
        if i < times - 1:
            time.sleep(delay)
    
    # Ensure restore on failure
    if not success:
        set_tv_brightness(original)
    
    return success


def send_telegram(message: str) -> bool:
    """Send Telegram notification."""
    if not TELEGRAM_SEND.exists():
        print(f"telegram_send.py not found at {TELEGRAM_SEND}", file=sys.stderr)
        return False
    ok, out = run_cmd([sys.executable, str(TELEGRAM_SEND), message])
    if not ok:
        print(f"Telegram send failed: {out}", file=sys.stderr)
    return ok


def job_done_effect(
    message: str = "✓ Job done",
    flash_times: int = 2,
    tv: bool = True,
    telegram: bool = True,
    silent: bool = False
) -> bool:
    """Run job done effect: TV flash and/or Telegram notification."""
    results = []
    
    if tv:
        tv_ok = flash_tv(times=flash_times)
        results.append(("TV flash", tv_ok))
    
    if telegram and not silent:
        tg_ok = send_telegram(message)
        results.append(("Telegram", tg_ok))
    
    # Report
    for name, ok in results:
        status = "✓" if ok else "✗"
        print(f"{status} {name}")
    
    return all(ok for _, ok in results) if results else True


def main():
    parser = argparse.ArgumentParser(description="Job done audiovisual effect")
    parser.add_argument("--message", "-m", default="✓ Job done", help="Telegram message (default: '✓ Job done')")
    parser.add_argument("--flash", "-f", type=int, default=2, help="Flash TV N times (default: 2)")
    parser.add_argument("--tv-only", action="store_true", help="TV flash only, no Telegram")
    parser.add_argument("--telegram-only", action="store_true", help="Telegram only, no TV")
    parser.add_argument("--silent", "-s", action="store_true", help="TV only (alias for --tv-only)")
    parser.add_argument("--no-tv", action="store_true", help="Skip TV flash")
    parser.add_argument("--no-telegram", action="store_true", help="Skip Telegram")
    args = parser.parse_args()
    
    # Determine what to do
    do_tv = True
    do_telegram = True
    
    if args.tv_only or args.silent:
        do_telegram = False
    if args.telegram_only:
        do_tv = False
    if args.no_tv:
        do_tv = False
    if args.no_telegram:
        do_telegram = False
    
    ok = job_done_effect(
        message=args.message,
        flash_times=args.flash,
        tv=do_tv,
        telegram=do_telegram,
        silent=args.silent
    )
    
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
