# Restore latest sshd_config backup and start sshd. Run as Administrator.
$cfg = "C:\ProgramData\ssh\sshd_config"
$bak = Get-ChildItem "$cfg.bak.*" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($bak) { Copy-Item $bak.FullName $cfg -Force; Write-Host "Restored $($bak.Name)" }
Set-Service sshd -StartupType Automatic
Start-Service sshd -ErrorAction SilentlyContinue
Write-Host "sshd status:" (Get-Service sshd -ErrorAction SilentlyContinue).Status
