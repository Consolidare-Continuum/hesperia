---
task_id: "cursor-repo|mcp|chroma-session"
active_md_anchor: "| MCP |"
---

# Script runbook — MCP session + Chroma (agent loop)

**Purpose**: Every agent session uses the **same** brain path: MCP tools + Chroma `query_knowledge`. Fixes "tool not in session" and empty context. Ref: [governance/MCP-COMPLIANCE-AND-OPERATIONAL.md](../governance/MCP-COMPLIANCE-AND-OPERATIONAL.md), [governance/CHROMA-USAGE-POLICY.md](../governance/CHROMA-USAGE-POLICY.md).

**Who**: Cursor (default), Abelard, Gena — any entity using the repo on a workstation or prichindel.

---

## When to use

- Starting work on **process, roles, workflow, cluster, agents**, or book-backed reasoning — **query_knowledge first**, not repo grep as first move.
- After editing [governance/mcp-config.json](../governance/mcp-config.json) or adding MCP servers.
- Chroma preflight failed in [scripts/workflow_automation_run.sh](workflow_automation_run.sh) logs.

---

## Procedure

1. **Deploy MCP config** (Linux/macOS from repo root): `bash scripts/deploy-mcp-config-global.sh` — updates `~/.cursor/mcp.json` and `.cursor/mcp.json`.
2. **Restart Cursor** fully (MCP loads at start).
3. **Verify**: In session, `query_knowledge` must succeed. On prichindel: Chroma heartbeat `curl -s -o /dev/null -w '%{http_code}' http://chroma-1.prichindel.local:8002/api/v2/heartbeat` → 200.
4. **Preflight** (automation): [scripts/chroma_preflight.sh](chroma_preflight.sh) uses `agent_mcp_knowledge.store.query` — same path as MCP.

---

## Do not

- Do **not** treat missing MCP as "optional" — fix config (deploy script + restart).
- Do **not** bulk ingest Chroma from Cursor — mass ingest = **Abelard only** per policy.

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| query_knowledge missing | Run deploy script; restart Cursor; see [agent_mcp_knowledge/CURSOR-MCP-SETUP.md](../agent_mcp_knowledge/CURSOR-MCP-SETUP.md). |
| Chroma 500 / empty | Abelard: SURVEILLANCE §8.2; restart chroma services; ingest if needed. |
| SSH MCP to prichindel fails | Check LAN/tunnel; SSH config `prichindel`. |

---

## See also

- [agents/abelard/MAINTENANCE-BRAIN-REPO-FLOWS.md](../agents/abelard/MAINTENANCE-BRAIN-REPO-FLOWS.md) — prichindel automation + Chroma preflight.
- [SCRIPT-RUNBOOK-workflow-orchestrator.md](SCRIPT-RUNBOOK-workflow-orchestrator.md) — cron chain.

SIGNED: Architecture (Ethan) | agent session compliance | 2026-03-30 | SCRIPT-RUNBOOK
