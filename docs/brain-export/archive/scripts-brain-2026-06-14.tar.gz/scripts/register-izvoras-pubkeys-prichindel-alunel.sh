#!/usr/bin/env bash
# Run on prichindel as igareosh, from repo root. Appends izvoras outbound pubkeys
# to authorized_keys on prichindel and alunel (if .pub files exist and are non-empty).
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
P_PR="${REPO}/cluster/izvoras/izvoras-to-prichindel.pub"
P_AL="${REPO}/cluster/izvoras/izvoras-to-alunel.pub"
AUTH="$HOME/.ssh/authorized_keys"

append_local() {
  local file="$1" name="$2"
  [[ -s "$file" ]] || { echo "skip $name (missing or empty $file)"; return 0; }
  local line t b
  line="$(head -1 "$file")"
  t="$(awk '{print $1}' <<<"$line")"
  b="$(awk '{print $2}' <<<"$line")"
  touch "$AUTH"
  chmod 600 "$AUTH" 2>/dev/null || true
  if grep -qF "${t} ${b}" "$AUTH" 2>/dev/null; then
    echo "$name already on prichindel authorized_keys"
  else
    printf '%s\n' "$line" >> "$AUTH"
    echo "Appended $name to prichindel authorized_keys"
  fi
}

append_local "$P_PR" "izvoras-to-prichindel"

if [[ -s "$P_AL" ]]; then
  if scp -o BatchMode=yes -o ConnectTimeout=10 -o IdentitiesOnly=yes \
    -i "$HOME/.ssh/id_rsa" "$P_AL" igareosh@192.168.100.62:/tmp/izvoras-to-alunel.pub &&
    ssh -o BatchMode=yes -o ConnectTimeout=10 -o IdentitiesOnly=yes \
      -i "$HOME/.ssh/id_rsa" igareosh@192.168.100.62 \
      'AUTH="$HOME/.ssh/authorized_keys"; install -d -m 700 "$HOME/.ssh"; K=$(cat /tmp/izvoras-to-alunel.pub); B=$(echo "$K" | awk "{print \$2}"); touch "$AUTH"; chmod 600 "$AUTH"; grep -qF "$B" "$AUTH" 2>/dev/null || echo "$K" >> "$AUTH"; rm -f /tmp/izvoras-to-alunel.pub; echo alunel_ok'; then
    :
  else
    echo "WARN: alunel pubkey step failed (unreachable or auth)"
  fi
else
  echo "skip alunel (no cluster/izvoras/izvoras-to-alunel.pub yet)"
fi

echo "DONE register-izvoras-pubkeys-prichindel-alunel.sh"
