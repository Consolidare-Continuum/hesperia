#!/usr/bin/env bash
# trustmaster: set Authentik user password; store exact bytes on host (no trailing newline).
# Order: set DB hash first, then write file, then verify file matches DB (avoids drift).
#
# Identify user by exactly one of: USER_EMAIL or USERNAME (Authentik core User).
#
# Usage on trustmaster:
#   USER_EMAIL=igareosh@protonmail.com OUT=/home/igareosh/.authentik-igareosh.password ./scripts/trustmaster_set_user_password_file.sh
#   USERNAME=akadmin OUT=/home/igareosh/.authentik-akadmin.password ./scripts/trustmaster_set_user_password_file.sh
#
# Optional: AUTHENTIK_CONTAINER=authentik-server-1 (default)
set -euo pipefail
CTR="${AUTHENTIK_CONTAINER:-authentik-server-1}"
PY="/ak-root/.venv/bin/python"
MG="/manage.py"
: "${OUT:?set OUT to host path for one-line password file}"

if [[ -n "${USER_EMAIL:-}" && -n "${USERNAME:-}" ]]; then
  echo "use only one of USER_EMAIL or USERNAME" >&2
  exit 1
fi
if [[ -z "${USER_EMAIL:-}" && -z "${USERNAME:-}" ]]; then
  echo "set USER_EMAIL or USERNAME" >&2
  exit 1
fi

if [[ -n "${USER_EMAIL:-}" ]]; then
  export LOOKUP=email
  export LOOKUP_VAL="$USER_EMAIL"
else
  export LOOKUP=username
  export LOOKUP_VAL="$USERNAME"
fi

# Hex: no +/= ; paste-safe in browsers; 32 bytes = 64 hex chars.
PW=$(openssl rand -hex 32)

docker exec -e PW="$PW" -e LOOKUP -e LOOKUP_VAL "$CTR" "$PY" "$MG" shell -c "
from authentik.core.models import User
import os
pw = os.environ['PW']
kind = os.environ['LOOKUP']
val = os.environ['LOOKUP_VAL']
if kind == 'email':
    u = User.objects.get(email__iexact=val)
else:
    u = User.objects.get(username=val)
u.set_password(pw)
u.save()
assert u.check_password(pw)
print('SET_OK', u.username, u.email)
"

umask 077
printf '%s' "$PW" > "$OUT"
chmod 600 "$OUT"
PW2=$(tr -d '\n\r' <"$OUT")

docker exec -e PW="$PW2" -e LOOKUP -e LOOKUP_VAL "$CTR" "$PY" "$MG" shell -c "
from authentik.core.models import User
import os
kind = os.environ['LOOKUP']
val = os.environ['LOOKUP_VAL']
if kind == 'email':
    u = User.objects.get(email__iexact=val)
else:
    u = User.objects.get(username=val)
assert u.check_password(os.environ['PW']), 'file does not match DB'
print('FROM_FILE_OK')
"

echo "STORED_FILE=$OUT bytes=$(wc -c <"$OUT") LOOKUP=$LOOKUP"
