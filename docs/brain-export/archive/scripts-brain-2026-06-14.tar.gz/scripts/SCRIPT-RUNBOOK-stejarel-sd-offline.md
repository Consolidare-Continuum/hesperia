# SCRIPT-RUNBOOK — stejarel SD offline repair (izvoras)

**When:** Pi won't elevate (`sudo` broken/SEGV), `samba-ad-dc` down, or ownership corrupt after bad offline copy. **Where:** SD root partition on **izvoras** at **`/media/igareosh/writable`** (Pi **off**, SD in reader).

**Not a substitute for reflash:** If **after one** offline pass + boot, **`sudo -n true`** or **`/usr/sbin/samba -V`** still **SEGV** → **reflash image + DC re-join** ([SAMBA-AD-RUNBOOK.md](../cluster/SAMBA-AD-RUNBOOK.md) §8). Stop live hacks.

**Lessons:** [cluster/stejarel/LESSONS-SSH-OFFLINE-2026-05-26.md](../cluster/stejarel/LESSONS-SSH-OFFLINE-2026-05-26.md)

---

## Before touching SD

- [ ] Pi **powered off**; SD in izvoras reader (not mounted on running Pi only).
- [ ] `findmnt /media/igareosh/writable` — ext4, **`writable`** label.
- [ ] Read [cluster/stejarel/NOTES.md](../cluster/stejarel/NOTES.md) boot-failure section (OpenSSH SEGV → Dropbear; no `testparm` in `is-configured`).

---

## Repair (one shot)

```bash
# On izvoras, from brain repo root:
bash scripts/stejarel-sd-offline-fix.sh
# Or full pass with deb overlay (see LESSONS doc — use correct samba filename samba_4.19.5+dfsg-4ubuntu9.4_arm64.deb, NOT samba_2%3a...)
```

**Optional chroot reinstall (reflash-lite, when SEGV expected):**

```bash
ROOT=/media/igareosh/writable
sudo apt-get install -y qemu-user-static
sudo cp /usr/bin/qemu-aarch64-static "$ROOT/usr/bin/"
sudo mount --bind /dev "$ROOT/dev"
sudo mount --bind /proc "$ROOT/proc"
sudo mount --bind /sys "$ROOT/sys"
sudo chroot "$ROOT" apt-get update
sudo chroot "$ROOT" apt-get install --reinstall -y samba samba-libs python3-samba sudo libpam-modules
# unmount binds; sync
```

---

## Before eject (mandatory)

```bash
ROOT=/media/igareosh/writable
stat -c '%a %U:%G' "$ROOT/usr/bin/sudo" "$ROOT/etc" "$ROOT/var/lib"
find "$ROOT/etc" "$ROOT/var" -user igareosh | wc -l   # must be 0
grep -r pam_winbind "$ROOT/etc/pam.d/" || echo pam_ok
grep ExecStart "$ROOT/etc/systemd/system/dropbear.service" | grep -F ' -p 22 '
sudo test -f "$ROOT/var/lib/samba/private/sam.ldb" && echo sam_ldb_ok
sync
```

---

## After boot (from prichindel)

```bash
ping -c1 192.168.100.19
ssh stejarel 'systemctl is-active dropbear'
ssh stejarel 'sudo -n true && echo sudo_ok'
ssh stejarel 'systemctl is-active samba-ad-dc'
ssh stejarel 'sudo samba-tool user list | head -5'
```

| Result | Action |
|--------|--------|
| All pass | Update [cluster/stejarel/README.md](../cluster/stejarel/README.md) status; optional NOTES. |
| **SEGV** on sudo/samba after clean offline pass | **Reflash**; primary DC stays **prichindel** (.23). |
| SSH refused | Check Dropbear unit `-p 22`; see NOTES fix3. |

---

## Never

- Partial **`libc6`** rsync via non-existent `ex-libc/lib/` on noble arm64.
- Live **`rsync`** from debs without root on running Pi.
- Cron / `rc2.d` hijacks on live system without root.
- Claim **data loss** before `findmnt` / mount sanity on prichindel (brain rule); on stejarel SD, check **`sam.ldb`** before reflash.

SIGNED: Cursor (repo entity) | stejarel SD offline runbook | 2026-05-26
