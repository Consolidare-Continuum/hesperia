#!/usr/bin/env bash
# Permanent MCP deploy for LAMAITA (Windows). Run from alunel or prichindel. Idempotent.
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
LAMAITA="${LAMAITA:-igareosh@192.168.100.4}"
SSH_OPTS=(-o BatchMode=yes -o ConnectTimeout=12)
# Cursor on LAMAITA uses Bitvise session profile BvSsh_lamaita (SSH login igareosh).
WIN_PROFILES=("BvSsh_lamaita")
# Optional admin profile (elevated maintenance SSH: igare@lamaita) — set DEPLOY_IGARE_PROFILE=1
if [ "${DEPLOY_IGARE_PROFILE:-0}" = "1" ]; then
  WIN_PROFILES+=("igare")
  LAMAITA_ADMIN="${LAMAITA_ADMIN:-igare@192.168.100.4}"
fi

echo "== deploy-mcp-lamaita-remote (repo=$REPO_ROOT target=$LAMAITA) =="

remote_ps() {
  ssh "${SSH_OPTS[@]}" "$LAMAITA" "powershell -NoProfile -ExecutionPolicy Bypass -Command \"$1\""
}

echo "== ensure .cursor dirs =="
for p in "${WIN_PROFILES[@]}"; do
  remote_ps "if (!(Test-Path C:\\Users\\$p\\.cursor)) { New-Item -ItemType Directory -Path C:\\Users\\$p\\.cursor -Force | Out-Null }"
  remote_ps "if (!(Test-Path C:\\Users\\$p\\.ssh)) { New-Item -ItemType Directory -Path C:\\Users\\$p\\.ssh -Force | Out-Null }"
done

echo "== deploy run-mcp-ssh.ps1 + SSH snippets + known_hosts fix =="
for p in "${WIN_PROFILES[@]}"; do
  scp "${SSH_OPTS[@]}" "$REPO_ROOT/cluster/ceres/run-mcp-ssh.ps1" "$LAMAITA:C:/Users/$p/.cursor/run-mcp-ssh.ps1"
  scp "${SSH_OPTS[@]}" "$REPO_ROOT/cluster/ceres/prichindel-lan-ssh-config-snippet.txt" "$LAMAITA:C:/Users/$p/.cursor/prichindel-lan-ssh-config-snippet.txt"
  scp "${SSH_OPTS[@]}" "$REPO_ROOT/cluster/ceres/add-prichindel-lan-ssh-config.ps1" "$LAMAITA:C:/Users/$p/.cursor/add-prichindel-lan-ssh-config.ps1"
  scp "${SSH_OPTS[@]}" "$REPO_ROOT/scripts/lamaita-fix-prichindel-known-hosts.ps1" "$LAMAITA:C:/Users/$p/.cursor/lamaita-fix-prichindel-known-hosts.ps1"
  scp "${SSH_OPTS[@]}" "$REPO_ROOT/scripts/lamaita-fix-ssh-key-acl.ps1" "$LAMAITA:C:/Users/$p/.cursor/lamaita-fix-ssh-key-acl.ps1"
done

echo "== fix SSH key ACLs (OpenSSH Permission denied) =="
for p in "${WIN_PROFILES[@]}"; do
  remote_ps "& C:\\Users\\$p\\.cursor\\lamaita-fix-ssh-key-acl.ps1 -ProfileName $p"
done

echo "== fix stale prichindel host keys =="
for p in "${WIN_PROFILES[@]}"; do
  remote_ps "& C:\\Users\\$p\\.cursor\\lamaita-fix-prichindel-known-hosts.ps1 -ProfileName $p"
done

echo "== merge Host prichindel (LAN) =="
for p in "${WIN_PROFILES[@]}"; do
  remote_ps "& C:\\Users\\$p\\.cursor\\add-prichindel-lan-ssh-config.ps1"
done

echo "== deploy mcp.json (BvSsh_lamaita = full lamaita config) =="
scp "${SSH_OPTS[@]}" "$REPO_ROOT/governance/mcp-config-windows-lamaita.json" "$LAMAITA:C:/Users/BvSsh_lamaita/.cursor/mcp.json"
if [ "${DEPLOY_IGARE_PROFILE:-0}" = "1" ]; then
  scp "${SSH_OPTS[@]}" -o User=igare "$REPO_ROOT/governance/mcp-config-windows.json" "${LAMAITA_ADMIN}:C:/Users/igare/.cursor/mcp.json"
fi

echo "== verify ssh prichindel from BvSsh_lamaita profile =="
ssh "${SSH_OPTS[@]}" "$LAMAITA" 'ssh -o BatchMode=yes -o ConnectTimeout=8 prichindel hostname' | grep -qi prichindel

echo "== count MCP servers in deployed config =="
count=$(remote_ps "(Get-Content C:\\Users\\BvSsh_lamaita\\.cursor\\mcp.json -Raw | Select-String -Pattern '\"chroma-knowledge\"|\"cursor-' -AllMatches).Matches.Count" | tr -d '\r')
echo "BvSsh_lamaita mcp server entries: $count"
if [ "${count:-0}" -lt 9 ]; then
  echo "FAIL: expected 9 MCP servers in lamaita config" >&2
  exit 1
fi

echo "OK: LAMAITA MCP deploy complete. Fully quit and restart Cursor on LAMAITA."
