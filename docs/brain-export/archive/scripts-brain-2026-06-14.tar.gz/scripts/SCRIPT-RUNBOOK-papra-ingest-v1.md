# Papra ingest v1 — CHROMA-2 (librarymaster)

**Spec:** [governance/SPEC-ETHAN-PAPRA-CHROMA-2-LIBRARY-SCHEMA.md](../governance/SPEC-ETHAN-PAPRA-CHROMA-2-LIBRARY-SCHEMA.md)  
**Host:** librarymaster only

## Order (mandatory)

1. **DEV** — schema ratified (PAPRA-01/02)
2. **DEPLOY** — `librarymaster-chroma2-schema-deploy.sh` + G0 dry-run (≤3 docs)
3. **DATA** — `ALLOW_PAPRA_REINDEX=1 librarymaster-papra-evening-reindex.sh`

## G0 dry-run (≤3 docs)

```bash
bash scripts/librarymaster-papra-g0-dry-run-3.sh
```

Env: `DRY_RUN_MAX_DOCS=3` on `papra-ingest.service`.

## Full reindex (operator-approved PAPRA-18)

```bash
bash scripts/librarymaster-backup-chroma-2.sh
bash scripts/verify-chroma2-persist.sh
ALLOW_PAPRA_REINDEX=1 bash scripts/librarymaster-papra-evening-reindex.sh
```

Monitor: `ssh librarymaster journalctl -u papra-ingest -f`

## Skip OCR (machine-readable only)

For faster ingest: no tesseract on image-only PDF pages. Scanned docs are tagged **`OCR_req`** in Papra (shetiyya UI) and listed in `ocr_req.json` beside `processed.json`.

```bash
# On librarymaster — enable for next run (not current job until restart):
sudo cp /data/workspaces/cursor/cluster/librarymaster/papra/papra-ingest.service.d/skip-ocr.conf \
  /etc/systemd/system/papra-ingest.service.d/
sudo systemctl daemon-reload
# restart only when ready — preserves processed.json skip logic
```

Env: `SKIP_OCR=1` · tag name: `OCR_REQ_TAG_NAME=OCR_req` (default)

Progress file (every 30 min + startup): `/data/docker/papra/ingest/reindex_progress.txt`

## Operator file ingest

Desktop batch: [cluster/librarymaster/papra/PAPRA-DESKTOP-INGEST-2026-06-01.md](../cluster/librarymaster/papra/PAPRA-DESKTOP-INGEST-2026-06-01.md)

SIGNED: Liam (ops docs) | Papra ingest v1 runbook | 2026-06-14
