#!/usr/bin/env bash
# Re-join alunel to PRICHINDEL.LOCAL (run from prichindel; needs /root/.secrets/samba-ad-admin).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SMB_MEMBER="${REPO_ROOT}/cluster/alunel/smb.conf.member"

pass="$(sudo cat /root/.secrets/samba-ad-admin)"
[[ -n "$pass" ]] || { echo "BLOCKED: no samba-ad-admin secret on prichindel"; exit 1; }

scp -o BatchMode=yes "$SMB_MEMBER" alunel:/tmp/smb.conf.member
ssh -o BatchMode=yes alunel 'sudo cp /tmp/smb.conf.member /etc/samba/smb.conf && sudo testparm -s >/dev/null'

ssh -o BatchMode=yes alunel "sudo net ads join -S prichindel.prichindel.local -U Administrator%${pass}" || true
ssh -o BatchMode=yes alunel 'sudo systemctl enable --now winbind smbd nmbd; sudo systemctl restart winbind smbd nmbd'
ssh -o BatchMode=yes alunel 'sudo net ads testjoin; systemctl is-active winbind smbd'

echo "DONE alunel Samba AD rejoin"
