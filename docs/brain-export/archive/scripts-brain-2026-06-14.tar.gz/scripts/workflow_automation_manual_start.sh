#!/usr/bin/env bash
# Manual start of team workflow automation (orchestrator + driver + Abelard executor + Cursor agent when not handled).
# Use to test without waiting for half-hourly cron. Same as cron run.
# Ref: cluster/workflow-automation/README.md

set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
exec "$REPO_ROOT/scripts/workflow_automation_run.sh" "$@"
