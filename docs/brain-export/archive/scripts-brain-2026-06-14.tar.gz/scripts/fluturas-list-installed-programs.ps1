# Run on fluturas (PowerShell). Output: installed Windows programs to stdout.
# To save to repo: .\scripts\fluturas-list-installed-programs.ps1 | Out-File -FilePath cluster\fluturas\installed-programs.txt -Encoding utf8
# Same logic as list-installed-programs.ps1 (registry Uninstall keys; omit VS Code / VS Installer).
$ErrorActionPreference = 'SilentlyContinue'
$uninstallPaths = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
$skip = @('vs code', 'visual studio code', 'visual studio installer')
$names = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($base in $uninstallPaths) {
    Get-ItemProperty -Path $base -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName } | ForEach-Object {
        [void]$names.Add($_.DisplayName.Trim())
    }
}
$sorted = $names | Sort-Object
$sorted | Where-Object {
    $name = $_
    if (-not $name) { return $false }
    $lower = $name.ToLower()
    $omit = $false
    foreach ($s in $skip) {
        if ($lower -like "*$s*") { $omit = $true; break }
    }
    -not $omit
}
