---
task_id: "team|escalation|grace"
active_md_anchor: "| Grace |"
---

# Script runbook — Escalate via Grace (single path)

**Purpose**: **One** escalation path for tasks, decisions, operator involvement, and important reports: **task Grace** to triage — brief statement of **what** needs triage. Ref: [AGENTS.md](../AGENTS.md), [OPERATIONAL-LAYER.md](../OPERATIONAL-LAYER.md), [governance/ENTITIES-AND-CURSOR-ONE-WHOLE-POLICY.md](../governance/ENTITIES-AND-CURSOR-ONE-WHOLE-POLICY.md).

**Who**: Any agent (Cursor, Abelard, Gena) or lead; **Grace** triages into [active.md](../active.md) or assignments pattern.

---

## When to use

- Create a task, escalate a blocker, need **igareosh** as a task (not a side channel).
- Something important must not get lost when operator uses workflow.
- After triage: optional **report to Ethan** for team outcomes per [governance/README.md](../governance/README.md) (archive path for REPORT-TO-ETHAN when applicable).

---

## Procedure

1. **Message Grace** (team channel / formal handoff per your process): one short block — **what** to triage, **why** it matters, **suggested owner** if known (Grace decides).
2. **Do not** append `active.md` yourself unless you are Grace.
3. **After** Grace adds a row: owner executes; **report_done** when complete.

---

## Do not

- Do **not** open parallel private task lists that never hit `active.md` / awareness path.
- Do **not** bypass Grace for **team** work that belongs on the single list.

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| Duplicate triage | Grace merges; one row per outcome. |
| Urgent prod | Still one path — mark priority P1 in triage language Grace uses. |

---

## See also

- [SCRIPT-RUNBOOK-grace-triage-active.md](SCRIPT-RUNBOOK-grace-triage-active.md) — row creation.
- [SCRIPT-RUNBOOK-report-done-workflow.md](SCRIPT-RUNBOOK-report-done-workflow.md) — completion.

SIGNED: Architecture (Ethan) | escalation interface | 2026-03-30 | SCRIPT-RUNBOOK
