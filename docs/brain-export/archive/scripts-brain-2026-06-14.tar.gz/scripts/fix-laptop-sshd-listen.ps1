# Remove ListenAddress from sshd_config so sshd binds to all interfaces again.
# Keeps PasswordAuthentication no. Run as Administrator.
$cfg = "$env:ProgramData\ssh\sshd_config"
$content = Get-Content $cfg -Raw
$content = $content -replace "ListenAddress 127.0.0.1\r?\n", "" -replace "ListenAddress ::1\r?\n", ""
Set-Content -Path $cfg -Value $content -NoNewline
Restart-Service sshd
Write-Host "Removed ListenAddress lines; sshd restarted."
