#!/usr/bin/env bash
# Repo-local git identity for product repos on alunel (no global git config required).
# Usage: git -c user.name="$(bash scripts/git-repo-identity.sh name)" \
#           -c user.email="$(bash scripts/git-repo-identity.sh email)" commit ...
set -euo pipefail
case "${1:-}" in
  name)  echo "igareosh" ;;
  email) echo "igareosh@igareosh.com" ;;
  *) echo "usage: $0 name|email" >&2; exit 1 ;;
esac
