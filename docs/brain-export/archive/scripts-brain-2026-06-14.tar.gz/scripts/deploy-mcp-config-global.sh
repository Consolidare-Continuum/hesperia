#!/usr/bin/env bash
# Deploy MCP config globally. One design: governance/mcp-config.json → Cursor user config
# AND workspace .cursor/mcp.json so Agent / merged MCP always loads repo servers (Cursor merges project + global).
# Run from repo root on Linux/macOS. After run: restart Cursor. No conditionals; no plan B.
set -e
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
SRC="$REPO_ROOT/governance/mcp-config.json"
DEST="${HOME}/.cursor/mcp.json"
PROJECT_MCP="$REPO_ROOT/.cursor/mcp.json"
mkdir -p "$(dirname "$DEST")"
mkdir -p "$(dirname "$PROJECT_MCP")"
cp "$SRC" "$DEST"
cp "$SRC" "$PROJECT_MCP"
echo "Deployed $SRC -> $DEST and $PROJECT_MCP."
echo "Restart Cursor."
