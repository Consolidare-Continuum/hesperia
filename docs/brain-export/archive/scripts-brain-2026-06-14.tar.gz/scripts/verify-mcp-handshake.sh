#!/usr/bin/env bash
# MCP stdio initialize smoke for all 9 team servers (run from izvoras/LAMAITA/alunel client).
set -euo pipefail
REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
INIT='{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"verify","version":"1"}}}'
fail=0

smoke() {
  local name="$1" host="$2" remote="$3"
  local out rc
  if [ "$host" = "localhost" ] || [ "$host" = "127.0.0.1" ]; then
    out=$(timeout 10 bash -lc "$remote" 2>&1 <<<"$INIT" | head -1) || rc=$?
  else
    out=$(timeout 10 ssh -o BatchMode=yes -o ConnectTimeout=8 "$host" "$remote" 2>&1 <<<"$INIT" | head -1) || rc=$?
  fi
  if echo "$out" | grep -q '"result"'; then
    echo "OK  $name ($host)"
  else
    echo "FAIL $name ($host): $(echo "$out" | tr '\n' ' ' | cut -c1-140)"
    fail=$((fail + 1))
  fi
}

R='REPO=/data/altitudine/prichindel.com; [ -d "$REPO" ] || REPO=/data/workspaces/cursor; cd "$REPO"'

CHROMA_SSH_HOST="${MCP_CHROMA_SSH_HOST:-alunel}"
if [ "$(hostname -s 2>/dev/null)" = "alunel" ]; then
  CHROMA_SSH_HOST="localhost"
fi

smoke chroma-knowledge "$CHROMA_SSH_HOST" \
  'REPO=/data/workspaces/cursor; cd "$REPO" && CHROMA_INSTANCE=CHROMA-1 CHROMA_SERVER_URL=http://127.0.0.1:8002 PYTHONPATH="$REPO" /data/chroma/venv/bin/python -m agent_mcp_knowledge'
smoke cursor-pipeline-status prichindel \
  "$R && PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" /data/chroma/venv/bin/python -m agent_mcp_pipeline_status"
smoke cursor-runbook prichindel \
  "$R && PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" /data/chroma/venv/bin/python -m agent_mcp_runbook"
smoke cursor-approval-gates prichindel \
  "$R && PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" /data/chroma/venv/bin/python -m agent_mcp_approval_gates"
smoke cursor-postfix-mail prichindel \
  "$R && PROTON_SMTP_CREDS_FILE=/data/smtp-outbound/proton-external.env MCP_POSTFIX_FROM=igareosh@igareosh.com PYTHONPATH=\"\$REPO\" /data/chroma/venv/bin/python -m agent_mcp_postfix_mail"
smoke cursor-cluster-snapshot prichindel \
  "$R && CHROMA_SERVER_URL=http://chroma-1.prichindel.local:8002 PROMETHEUS_URL=http://127.0.0.1:9090 WORKFLOW_API_BASE=http://127.0.0.1:9096 PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" /data/chroma/venv/bin/python -m agent_mcp_cluster_snapshot"
smoke cursor-github-ci prichindel \
  "$R && PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" GITHUB_DEFAULT_REPO=igareosh/cursor /data/chroma/venv/bin/python -m agent_mcp_github_ci"
smoke cursor-context-rag prichindel \
  "$R && CHROMA_SERVER_URL=http://chroma-1.prichindel.local:8002 PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" /data/chroma/venv/bin/python -m agent_mcp_context_rag"
smoke cursor-inbox-reader prichindel \
  "$R && PYTHONPATH=\"\$REPO\" CURSOR_REPO_ROOT=\"\$REPO\" /data/chroma/venv/bin/python -m agent_mcp_inbox_reader"
smoke colombo-library alunel \
  "ssh -o BatchMode=yes librarymaster 'REPO=/data/altitudine/prichindel.com; cd \"\$REPO\" && CHROMA_INSTANCE=CHROMA-2 CHROMA_SERVER_URL=http://127.0.0.1:8002 CHROMA_COLLECTION=documents PYTHONPATH=\"\$REPO\" /data/chroma-alunel/venv/bin/python -m agent_mcp_colombo_library'"

if [ "$fail" -eq 0 ]; then
  echo "OK: all 10 MCP handshake checks passed"
else
  echo "FAIL: $fail/10 MCP servers failed handshake"
  exit 1
fi
