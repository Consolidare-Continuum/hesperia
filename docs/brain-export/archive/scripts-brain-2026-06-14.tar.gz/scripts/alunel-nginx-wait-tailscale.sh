#!/usr/bin/env bash
# Wait for tailscale0 IPv4, render vhost, reload/start nginx.
set -euo pipefail

MAX_WAIT="${ALUNEL_NGINX_TAILSCALE_WAIT_SEC:-120}"
TS_IF="${ALUNEL_NGINX_TAILSCALE_IF:-tailscale0}"
RENDER="${ALUNEL_NGINX_RENDER:-/usr/local/sbin/alunel-nginx-render-vhost.sh}"

deadline=$((SECONDS + MAX_WAIT))
while (( SECONDS < deadline )); do
  if ip -4 addr show dev "$TS_IF" 2>/dev/null | grep -q 'inet '; then
    break
  fi
  sleep 2
done

if ! ip -4 addr show dev "$TS_IF" 2>/dev/null | grep -q 'inet '; then
  echo "WARN: ${TS_IF} has no IPv4 after ${MAX_WAIT}s; nginx serves LAN only" >&2
fi

if [[ -x "$RENDER" ]]; then
  "$RENDER"
elif [[ -x /usr/local/sbin/alunel-nginx-render-vhost.sh ]]; then
  /usr/local/sbin/alunel-nginx-render-vhost.sh
fi

if command -v nginx >/dev/null 2>&1; then
  nginx -t
  if systemctl is-active --quiet nginx; then
    nginx -s reload
  else
    systemctl start nginx
  fi
fi
