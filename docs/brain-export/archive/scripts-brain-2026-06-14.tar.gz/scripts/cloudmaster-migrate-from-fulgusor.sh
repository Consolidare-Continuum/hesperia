#!/usr/bin/env bash
# P2V ownCloud stack: physical fulgusor (192.168.100.40) -> cloudmaster VM (110).
# Run on alunel. Requires fulgusor SSH reachable from alunel or prichindel jump.
set -euo pipefail

FULGUSOR_SRC="${FULGUSOR_SRC:-192.168.100.40}"
FULGUSOR_USER="${FULGUSOR_USER:-igareosh}"
CLOUDMASTER_IP="${CLOUDMASTER_IP:-192.168.100.72}"
CLOUDMASTER_USER="${CLOUDMASTER_USER:-igareosh}"
FULGUSOR_RSH="${FULGUSOR_RSH:-/home/igareosh/tmp/fulgusor-rsh.sh}"
SSH_FULGUSOR="ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -i /home/igareosh/.ssh/fulgusor -o IdentitiesOnly=yes ${FULGUSOR_USER}@${FULGUSOR_SRC}"
REPO=''
if [ -d /data/workspaces/cursor ]; then REPO=/data/workspaces/cursor
elif [ -d /data/altitudine/prichindel.com ]; then REPO=/data/altitudine/prichindel.com
else REPO="$(cd "$(dirname "$0")/.." && pwd)"
fi

log() { echo "[cloudmaster-migrate] $*"; }

setup_fulgusor_rsh() {
  cat >"$FULGUSOR_RSH" <<'EOF'
#!/bin/bash
exec ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new \
  -i /home/igareosh/.ssh/fulgusor -o IdentitiesOnly=yes "$@"
EOF
  chmod 700 "$FULGUSOR_RSH"
}

preflight() {
  setup_fulgusor_rsh
  log "Preflight: fulgusor + cloudmaster reachability"
  $SSH_FULGUSOR 'hostname; test -d /var/www/owncloud; test -d /mnt/heimdall/owncloud_data'
  ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" 'hostname; test -d /mnt/heimdall'
}

install_owncloud_stack() {
  log "Install ownCloud stack on cloudmaster (MariaDB 11.7, PHP 7.4, ownCloud 10.15.x)..."
  ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" 'sudo bash -s' <<'REMOTE'
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
# MariaDB 11.7 (match fulgusor)
if ! command -v mariadb &>/dev/null; then
  curl -fsSL https://supplychain.mariadb.com/mariadb-keyring-2025.gpg \
    | gpg --dearmor -o /etc/apt/trusted.gpg.d/mariadb-keyring-2025.gpg
  cat >/etc/apt/sources.list.d/mariadb.list <<EOF
deb [signed-by=/etc/apt/trusted.gpg.d/mariadb-keyring-2025.gpg] https://dlm.mariadb.com/repo/mariadb-server/11.7/repo/debian trixie main
EOF
  apt-get update -qq
  apt-get install -y -qq mariadb-server
  systemctl enable --now mariadb
fi
# PHP 7.4 for ownCloud 10.15 (same major as fulgusor)
if ! command -v php7.4 &>/dev/null; then
  apt-get install -y -qq lsb-release apt-transport-https ca-certificates wget
  wget -qO /etc/apt/trusted.gpg.d/php.gpg https://packages.sury.org/php/apt.gpg
  echo "deb [signed-by=/etc/apt/trusted.gpg.d/php.gpg] https://packages.sury.org/php/ $(lsb_release -sc) main" \
    > /etc/apt/sources.list.d/php-sury.list
  apt-get update -qq
  apt-get install -y -qq php7.4 php7.4-cli php7.4-common php7.4-mysql php7.4-xml \
    php7.4-mbstring php7.4-gd php7.4-curl php7.4-zip php7.4-intl php7.4-apache2 \
    libapache2-mod-php7.4 redis-server
  a2dismod php8.* 2>/dev/null || true
  a2enmod php7.4 rewrite headers env ssl
  systemctl enable --now redis-server apache2
fi
mkdir -p /var/www/owncloud
REMOTE
}

rsync_owncloud() {
  local staging="${STAGING:-/home/igareosh/tmp/cloudmaster-migrate}"
  mkdir -p "$staging/owncloud-app" "$staging/owncloud_data" "$staging/apache-sites"
  log "Rsync ownCloud app + config fulgusor -> alunel staging..."
  rsync -aHAX --info=progress2 \
    -e "$FULGUSOR_RSH" \
    --exclude 'data/' \
    "${FULGUSOR_USER}@${FULGUSOR_SRC}:/var/www/owncloud/" \
    "$staging/owncloud-app/"
  log "Push app staging -> cloudmaster..."
  rsync -aHAX --info=progress2 \
    "$staging/owncloud-app/" \
    "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}:/tmp/owncloud-app/"
  ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" \
    'sudo rsync -a /tmp/owncloud-app/ /var/www/owncloud/ && sudo chown -R www-data:www-data /var/www/owncloud'

  log "Rsync ownCloud data fulgusor -> cloudmaster direct pull (~99G; may take a while)..."
  scp -o BatchMode=yes /home/igareosh/.ssh/fulgusor "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}:/tmp/fulgusor-migrate-key"
  ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" 'sudo bash -s' <<REMOTE
set -euo pipefail
chmod 600 /tmp/fulgusor-migrate-key
chown igareosh:igareosh /tmp/fulgusor-migrate-key
ssh-keyscan -H ${FULGUSOR_SRC} >> ~/.ssh/known_hosts 2>/dev/null || true
rsync -aHAX --info=progress2 \
  -e "ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -i /tmp/fulgusor-migrate-key -o IdentitiesOnly=yes" \
  ${FULGUSOR_USER}@${FULGUSOR_SRC}:/mnt/heimdall/owncloud_data/ \
  /mnt/heimdall/owncloud_data/
chown -R www-data:www-data /mnt/heimdall/owncloud_data
rm -f /tmp/fulgusor-migrate-key
REMOTE

  log "Rsync Apache vhosts + SSL..."
  rsync -aHAX -e "$FULGUSOR_RSH" \
    "${FULGUSOR_USER}@${FULGUSOR_SRC}:/etc/apache2/sites-available/" \
    "$staging/apache-sites/" || true
  rsync -aHAX "$staging/apache-sites/" \
    "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}:/tmp/apache-sites/" || true
  rsync -aHAX -e "$FULGUSOR_RSH" \
    "${FULGUSOR_USER}@${FULGUSOR_SRC}:/etc/ssl/letsencrypt/cloud.prichindel.com/" \
    "$staging/cloud-ssl/" 2>/dev/null || true
  if [ -d "$staging/cloud-ssl" ]; then
    rsync -aHAX "$staging/cloud-ssl/" \
      "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}:/tmp/cloud-ssl/" 2>/dev/null || true
  fi
  ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" 'sudo bash -s' <<'REMOTE'
set -e
if [ -d /tmp/apache-sites ]; then
  rsync -a /tmp/apache-sites/ /etc/apache2/sites-available/
  a2ensite owncloud.conf 2>/dev/null || a2ensite 000-default.conf 2>/dev/null || true
fi
if [ -d /tmp/cloud-ssl ]; then
  mkdir -p /etc/ssl/letsencrypt/cloud.prichindel.com
  rsync -a /tmp/cloud-ssl/ /etc/ssl/letsencrypt/cloud.prichindel.com/
fi
apache2ctl configtest
systemctl reload apache2
REMOTE
}

migrate_database() {
  log "MariaDB dump from fulgusor -> cloudmaster..."
  $SSH_FULGUSOR 'sudo mysqldump --single-transaction owncloud' \
    | ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" \
      'sudo mariadb owncloud'
}

fix_config_paths() {
  log "Patch config.php datadirectory if needed..."
  ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" \
    "sudo -u www-data php7.4 /var/www/owncloud/occ files:scan --all" || true
}

verify() {
  log "Verify ownCloud..."
  ssh -o BatchMode=yes "${CLOUDMASTER_USER}@${CLOUDMASTER_IP}" \
    'sudo -u www-data php7.4 /var/www/owncloud/occ status; curl -sk -o /dev/null -w "%{http_code}\n" -H "Host: cloud.prichindel.com" https://127.0.0.1/ || curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1/'
}

main() {
  preflight
  install_owncloud_stack
  rsync_owncloud
  migrate_database
  fix_config_paths
  verify
  log "DONE — ownCloud migrated to cloudmaster ($CLOUDMASTER_IP). Cutover: power off physical fulgusor, re-IP VM to .40, update DNS."
}

main "$@"
