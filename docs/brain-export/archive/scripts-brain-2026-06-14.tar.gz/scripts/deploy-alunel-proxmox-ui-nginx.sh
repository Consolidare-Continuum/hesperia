#!/usr/bin/env bash
# Deploy internal nginx for https://alunel.prichindel.com → Proxmox UI (:8006).
# LAN + Tailscale dual-listen on alunel; optional relay on prichindel VM.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PRICH_CONF="$REPO_ROOT/cluster/prichindel/nginx-alunel.prichindel.com.conf"

ssh_alunel() { ssh -o BatchMode=yes -o ConnectTimeout=10 alunel "$@"; }
ssh_prich() { ssh -o BatchMode=yes -o ConnectTimeout=15 prichindel "$@"; }

echo "==> alunel: install nginx + origin cert + vhost (template render)"
ssh_alunel 'sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nginx 2>/dev/null || true'
ssh_alunel "sudo mkdir -p /etc/ssl/cloudflare /etc/nginx/templates"
scp -q "$REPO_ROOT/cluster/alunel/nginx-alunel.prichindel.com.conf.template" alunel:/tmp/nginx-alunel.prichindel.com.conf.template
scp -q "$REPO_ROOT/scripts/alunel-nginx-render-vhost.sh" alunel:/tmp/alunel-nginx-render-vhost.sh
ssh_prich 'sudo cat /etc/ssl/cloudflare/prichindel.origin.pem' | ssh_alunel 'sudo tee /etc/ssl/cloudflare/prichindel.origin.pem >/dev/null'
ssh_prich 'sudo cat /etc/ssl/cloudflare/prichindel.origin.key' | ssh_alunel 'sudo tee /etc/ssl/cloudflare/prichindel.origin.key >/dev/null'
ssh_alunel 'sudo chmod 644 /etc/ssl/cloudflare/prichindel.origin.pem; sudo chmod 600 /etc/ssl/cloudflare/prichindel.origin.key'
ssh_alunel 'sudo cp /tmp/nginx-alunel.prichindel.com.conf.template /etc/nginx/templates/alunel.prichindel.com.conf.template
  sudo install -m 755 /tmp/alunel-nginx-render-vhost.sh /usr/local/sbin/alunel-nginx-render-vhost.sh
  sudo /usr/local/sbin/alunel-nginx-render-vhost.sh
  sudo ln -sf /etc/nginx/sites-available/alunel.prichindel.com.conf /etc/nginx/sites-enabled/
  sudo rm -f /etc/nginx/sites-enabled/default /etc/nginx/conf.d/default.conf
  sudo nginx -t && sudo systemctl enable --now nginx && sudo systemctl restart nginx'

echo "==> prichindel VM: relay vhost (optional second hop)"
scp -q "$PRICH_CONF" prichindel:/tmp/nginx-alunel.prichindel.com.conf
ssh_prich 'sudo cp /tmp/nginx-alunel.prichindel.com.conf /etc/nginx/conf.d/alunel.prichindel.com.conf
  sudo nginx -t && sudo systemctl reload nginx'

echo "==> dnsmaster: ensure alunel.prichindel.com → 192.168.100.62"
if [[ -x "$REPO_ROOT/scripts/dnsmaster-agh-patch-rewrites.sh" ]]; then
  bash "$REPO_ROOT/scripts/dnsmaster-agh-patch-rewrites.sh" alunel.prichindel.com=192.168.100.62 || true
fi

echo "==> verify"
ssh_alunel 'systemctl is-active nginx; ss -tlnp | grep -E ":443.*nginx" | head -4'
curl -sk -o /dev/null -w "alunel LAN : %{http_code}\n" --resolve alunel.prichindel.com:443:192.168.100.62 https://alunel.prichindel.com/ || true
curl -sk -o /dev/null -w "alunel TS  : %{http_code}\n" --resolve alunel.prichindel.com:443:100.75.161.108 https://alunel.prichindel.com/ || true

echo "==> post-boot units (nginx after tailscaled, VM order, tunnels)"
bash "$REPO_ROOT/scripts/alunel-post-boot-fixups.sh" || true

echo "==> alunel: UFW (80/443 LAN+tailnet, 8006 LAN for relay)"
ssh_alunel 'sudo ufw allow from 192.168.100.0/24 to any port 80 proto tcp comment "internal-http-redirect" 2>/dev/null || true
  sudo ufw allow from 100.64.0.0/10 to any port 80 proto tcp comment "tailnet-http-redirect" 2>/dev/null || true
  sudo ufw allow from 192.168.100.0/24 to any port 443 proto tcp comment "internal-https-nginx" 2>/dev/null || true
  sudo ufw allow from 100.64.0.0/10 to any port 443 proto tcp comment "tailnet-https-nginx" 2>/dev/null || true
  sudo ufw allow from 192.168.100.0/24 to any port 8006 proto tcp comment "proxmox-pve-from-lan" 2>/dev/null || true'

echo "DONE. Use https://alunel.prichindel.com (LAN DNS → .62; tailnet-only → .108 or relay via prichindel .21 / 100.122.228.36)."
