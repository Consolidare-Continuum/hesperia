#!/usr/bin/env bash
# Abelard: audit + apply cluster hostname compliance (LAN hosts block + dnsmaster rewrites).
# Canonical: cluster/CLUSTER-HOST-REGISTRY.md, cluster/HOSTNAME-AND-HOSTS-STANDARD.md
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

APPLY=0
DNS_PATCH=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --apply) APPLY=1; shift ;;
    --dns-patch) DNS_PATCH=1; shift ;;
    -h|--help)
      echo "Usage: $0 [--apply] [--dns-patch]"
      echo "  --apply      run cluster-merge-lan-hosts.sh locally (sudo) and on SSH targets"
      echo "  --dns-patch  push AdGuard rewrites to dnsmaster (requires: ssh dnsmaster)"
      exit 0
      ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done

# AdGuard rewrite pairs: every name on cluster LAN hosts block (short, .local, .prichindel.local, …)
mapfile -t DNS_REWRITES < <(bash "$REPO_ROOT/scripts/cluster-lan-dns-rewrites.sh")
# Public admin names (not on LAN hosts block)
DNS_REWRITES+=(
  dns.prichindel.com=192.168.100.21
  lounge.tersagor.prichindel.com=192.168.100.21
)

LINUX_TARGETS=(
  localhost
  prichindel
  alunel
  izvoras
  stejarel
  dnsmaster
  trustmaster
  tersagor
  chronomaster
  mediamaster
  librarymaster
  altitudine
  voinicel
  fulgusor
  mugurel
)

echo "=== cluster hostname compliance ($(date -Iseconds)) ==="
echo "Host: $(hostname -f 2>/dev/null || hostname)"
echo ""

fail=0
if [[ -f /etc/hosts ]] && grep -q 'BEGIN cluster LAN names' /etc/hosts; then
  echo "OK  local /etc/hosts has cluster block"
else
  echo "MISS local /etc/hosts cluster block"
  fail=$((fail + 1))
fi

if command -v dig >/dev/null 2>&1; then
  for pair in "${DNS_REWRITES[@]}"; do
    domain="${pair%%=*}"
    ip="${pair#*=}"
    ans="$(dig +short +time=2 +tries=1 @"192.168.100.25" "$domain" 2>/dev/null | head -1 || true)"
    if [[ "$ans" == "$ip" ]]; then
      echo "OK  DNS $domain -> $ans"
    elif [[ -z "$ans" ]]; then
      echo "MISS DNS $domain (want $ip)"
      fail=$((fail + 1))
    else
      echo "WARN DNS $domain -> $ans (want $ip)"
      fail=$((fail + 1))
    fi
  done
else
  echo "SKIP DNS audit (dig not installed)"
fi

echo ""
echo "--- SSH targets (merge block) ---"
for t in "${LINUX_TARGETS[@]}"; do
  if [[ "$t" == "localhost" ]]; then
    continue
  fi
  if ssh -o BatchMode=yes -o ConnectTimeout=4 "$t" 'grep -q "BEGIN cluster LAN names" /etc/hosts && echo OK || echo MISS' 2>/dev/null; then
    :
  else
    echo "SKIP $t (ssh unreachable)"
  fi
done

if [[ "$APPLY" -eq 1 ]]; then
  echo ""
  echo "--- apply: local merge ---"
  sudo bash "$REPO_ROOT/scripts/cluster-merge-lan-hosts.sh"
  for t in "${LINUX_TARGETS[@]}"; do
    [[ "$t" == "localhost" ]] && continue
    if ssh -o BatchMode=yes -o ConnectTimeout=6 "$t" "sudo bash -s" <"$REPO_ROOT/scripts/cluster-merge-lan-hosts.sh" 2>/dev/null; then
      echo "OK  merged on $t"
    else
      echo "SKIP merge on $t"
    fi
  done
fi

if [[ "$DNS_PATCH" -eq 1 ]]; then
  echo ""
  echo "--- dnsmaster rewrites ---"
  bash "$REPO_ROOT/scripts/dnsmaster-agh-patch-rewrites.sh" "${DNS_REWRITES[@]}"
fi

echo ""
if [[ "$fail" -gt 0 ]]; then
  echo "RESULT: WARN ($fail DNS mismatches or local miss). Fix when LAN/dnsmaster reachable."
  exit 1
fi
echo "RESULT: audit complete."
exit 0
