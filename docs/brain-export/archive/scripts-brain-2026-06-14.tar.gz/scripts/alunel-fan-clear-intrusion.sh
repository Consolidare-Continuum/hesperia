#!/usr/bin/env bash
# alunel X8DT3 — clear W83795 chassis intrusion latch after case open during power-on.
# BIOS may keep fans at full until intrusion is cleared and host reboots with case closed.
set -euo pipefail

W83795_DEV="pci0000:00/0000:00:1f.3/i2c-0/0-002f"
INTR="/sys/devices/${W83795_DEV}/intrusion0_alarm"

if [[ ! -f "$INTR" ]]; then
  echo "alunel-fan-clear-intrusion: missing $INTR" >&2
  exit 1
fi

before="$(cat "$INTR")"
if [[ "$before" == "0" ]]; then
  echo "intrusion0_alarm already clear (0)"
  sensors 2>/dev/null | grep intrusion0 || true
  exit 0
fi

echo 0 >"$INTR"
after="$(cat "$INTR")"
echo "intrusion0_alarm: ${before} -> ${after}"
sensors 2>/dev/null | grep intrusion0 || true
if [[ "$after" != "0" ]]; then
  echo "alunel-fan-clear-intrusion: latch still set — close case, reboot, or clear in BIOS (Del → HW Monitor)" >&2
  exit 1
fi
echo "If fans stay loud: reboot once with case fully latched (BIOS fail-safe after open-case boot)."
