# Complete list of C:\Program Files and C:\Program Files (x86) with local paths
# Omit: VS Code, Visual Studio Installer (per user request)
$omit = @('vs code', 'visual studio installer')
$base64 = @(
    'C:\Program Files',
    'C:\Program Files (x86)'
)
$results = [System.Collections.ArrayList]::new()
foreach ($base in $base64) {
    if (-not (Test-Path $base)) { continue }
    Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        $fullPath = Join-Path $base $_.Name
        $name = $_.Name
        $skip = $false
        foreach ($s in $omit) {
            if ($name -match [regex]::Escape($s) -or $name.ToLower().Contains($s)) { $skip = $true; break }
        }
        if (-not $skip) { [void]$results.Add($fullPath) }
    }
}
$results | Sort-Object
