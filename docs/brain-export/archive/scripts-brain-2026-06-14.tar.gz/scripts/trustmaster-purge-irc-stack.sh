#!/usr/bin/env bash
# Disable IM-IRC / girc user units on trustmaster (IRC lives on tersagor since v0.1.0).
# Ref: cluster/trustmaster/IRC-STACK-RETIRED.md
set -euo pipefail

TARGET="${TRUSTMASTER_SSH:-igareosh@192.168.100.67}"

ssh -o ConnectTimeout=15 "$TARGET" 'bash -s' <<'REMOTE'
set -euo pipefail
units=(
  ergo-girc
  imirc-eggdrop
  imirc-delegate-bot
  imirc-gateway-forwarder
  imirc-ingest-bot
  imirc-mcp-host
  imirc-metrics
  imirc-slo-alert
  imirc-backup
)
for u in "${units[@]}"; do
  systemctl --user disable --now "${u}.service" 2>/dev/null || true
done
echo "DONE: disabled ${#units[@]} user units on $(hostname)"
systemctl --user list-units 'ergo*' 'imirc*' --all --no-pager 2>/dev/null | head -20 || true
REMOTE
