#Requires -Version 5.1
# Run on LAMAITA (Cursor repo root or any path): appends Host stejarel to current user's OpenSSH config if missing.
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File scripts/lamaita-append-stejarel-ssh.ps1

$ErrorActionPreference = "Stop"
$sshDir = Join-Path $env:USERPROFILE ".ssh"
$config = Join-Path $sshDir "config"
$marker = "Host stejarel"

if (-not (Test-Path $sshDir)) {
    New-Item -ItemType Directory -Path $sshDir -Force | Out-Null
}

$fragment = @"

Host stejarel
    HostName 192.168.100.19
    User igareosh
    IdentityFile ~/.ssh/id_rsa
    IdentitiesOnly yes
    ServerAliveInterval 60
    ConnectTimeout 15

"@

if ((Test-Path $config) -and (Select-String -Path $config -Pattern "^\s*Host\s+stejarel\s*$" -Quiet)) {
    Write-Host "OK: $config already contains Host stejarel"
    exit 0
}

Add-Content -Path $config -Value $fragment -Encoding utf8
Write-Host "OK: appended Host stejarel to $config"
Write-Host "Test: ssh stejarel hostname"
