# Runbook — Connection resolution (SSH, tunnel, DNS)

**When**: "Can't connect", "SSH fails", "tunnel not working", "Cursor can't reach prichindel", or connectivity issue from any cluster node (LAMAITA, olgahere, fluturas, mugurel, izvoras) to prichindel or fulgusor. Owner: **Abelard**. Resolution is **from** or **toward** prichindel (main station).

---

## 1. Where is the user / where is the failure?

- **Cursor on prichindel** (Remote-SSH): Shell is on prichindel; no SSH to self. If terminal empty or "connection refused", user may need to reconnect (Connect to Host → prichindel → `/data/workspaces/cursor`).
- **Cursor on LAMAITA** (Windows): Reach prichindel via **SSH**. Two modes only: **LAN** (192.168.100.21) or **tunnel** (prichindel-remote via Cloudflare). Run session detector: `scripts/detect-cursor-session-mode.ps1` (Windows) or from repo root; read `governance/cursor_session_mode.txt`.
- **Cursor on olgahere/fluturas**: Same Proton repo; SSH to prichindel: `ssh prichindel`. Read cluster/olgahere/ or cluster/fluturas/ for node-specific SSH and keys.

---

## 2. SSH to prichindel fails (from laptop)

**LAN**: Ensure WiFi on same network as prichindel (192.168.100.21). Run `cluster/ceres/add-prichindel-lan-ssh-config.ps1` so `prichindel` points to 192.168.100.21. Test: `ssh prichindel "hostname"`.

**Tunnel (off-LAN)**: Use host **prichindel-remote** with ProxyCommand (cloudflared access ssh). One-time: `cluster/ceres/add-prichindel-remote-ssh-config.ps1`. Tunnel must be up on prichindel (`cloudflared.service`); if tunnel down, fix Cloudflare first (see SCRIPT-RUNBOOK-cloudflare).

**Key**: Same GitHub/cluster key as used elsewhere. No key → check `~/.ssh/` (or Windows %USERPROFILE%\.ssh\); add key to prichindel `~/.ssh/authorized_keys` if missing.

---

## 3. SSH to fulgusor (from prichindel)

**Command**: `ssh igareosh@fulgusor` or `ssh igareosh@192.168.100.40`. Key: `~/.ssh/fulgusor` (Host FULGUSOR in config). If fails: check network (ping); check key and authorized_keys on fulgusor.

---

## 4. SSH to cluster nodes (from prichindel)

- **olgahere**: `ssh olgahere` (192.168.100.5). G: = PRIVATE. Key in Olga's administrators_authorized_keys if needed. See cluster/olgahere/README.md.
- **fluturas**: `ssh fluturas` (192.168.100.8, User igare, WSL). See cluster/fluturas/README.md, TAKEOVER-COMMANDS.
- **mugurel**: `ssh mugurel` or `ssh igareosh@<LAN_IP>` — travel Linux; often **192.168.100.57**; confirm in `~/.ssh/config`. See cluster/mugurel/README.md.

---

## 5. DNS / name resolution

If hostname doesn't resolve: check `/etc/hosts` or DNS. prichindel.com, prichindel.prichindel.com — DNS may be Cloudflare-managed; Zone DNS token for changes. From prichindel: `getent hosts prichindel.com`.

---

## 6. MCP / Chroma unreachable

MCPs run on prichindel (fixed host). If Cursor is on LAMAITA or another laptop, MCP config uses ssh prichindel. If "query_knowledge failed" or MCP not in session: run deploy script from repo root (`scripts/deploy-mcp-config-global.ps1` on Windows, `scripts/deploy-mcp-config-global.sh` on Linux); restart Cursor. Ref: governance/MCP-COMPLIANCE-AND-OPERATIONAL.

---

## Failure modes

| Failure | Symptom | Action |
|---------|---------|--------|
| SSH timeout (to prichindel from laptop) | Connection timed out | LAN: check WiFi, IP 192.168.100.21. Tunnel: check cloudflared on prichindel; use prichindel-remote config. |
| SSH "Permission denied (publickey)" | No key accepted | Check key in authorized_keys on target; use correct user (igareosh, Olga, igare). |
| Tunnel 502 or unreachable | cloudflared up but service not reachable | Check tunnel ingress in Cloudflare dashboard; origin service (e.g. sshd) listening; leave prichindel.prichindel.com tunnel config unchanged. |

---

**Ref**: [cluster/ceres/README.md](../cluster/ceres/README.md), [cluster/ceres/ssh-connectivity-rules/MASTER-RULES.md](../cluster/ceres/ssh-connectivity-rules/MASTER-RULES.md), [cluster/olgahere/README.md](../cluster/olgahere/README.md), [cluster/fluturas/README.md](../cluster/fluturas/README.md), [cluster/fulgusor/README.md](../cluster/fulgusor/README.md), [governance/SPEC-ETHAN-ABELARD-CLUSTER-DEVOPS-ENTITY.md](../governance/SPEC-ETHAN-ABELARD-CLUSTER-DEVOPS-ENTITY.md) §7. Owner: Abelard.
