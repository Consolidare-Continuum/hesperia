#!/usr/bin/env python3
"""Reject likely lexical leakage in CD jsonl: long unbroken alpha tokens in values."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# Cyrillic or Latin run ≥ 12 chars inside a JSON string value → fail
_TOKEN = re.compile(r"[\u0400-\u04FFa-zA-Z]{12,}")


def _walk(obj: object, path: str) -> list[str]:
    bad: list[str] = []
    if isinstance(obj, dict):
        for k, v in sorted(obj.items()):
            bad.extend(_walk(v, f"{path}.{k}"))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            bad.extend(_walk(v, f"{path}[{i}]"))
    elif isinstance(obj, str):
        if _TOKEN.search(obj):
            bad.append(f"{path}: {obj[:80]!r}")
    return bad


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("jsonl", type=Path)
    args = ap.parse_args()
    if not args.jsonl.is_file():
        print("SKIP: file missing", file=sys.stderr)
        return 0
    for line_no, line in enumerate(args.jsonl.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as e:
            print(f"FAIL line {line_no}: JSON {e}", file=sys.stderr)
            return 1
        hits = _walk(row, f"line{line_no}")
        if hits:
            for h in hits:
                print(f"FAIL {h}", file=sys.stderr)
            return 1
    print("OK: no long lexical tokens in CD jsonl")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
