#!/usr/bin/env bash
# Deprecated path: WORKFLOW_DRIVER_PROJECT=im-irc ./scripts/workflow_automation_run.sh
set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
export REPO_ROOT WORKFLOW_REPO_ROOT="$REPO_ROOT"
export WORKFLOW_DRIVER_PROJECT="${WORKFLOW_DRIVER_PROJECT:-im-irc}"
exec "$REPO_ROOT/scripts/workflow_automation_run.sh" "$@"
