#!/usr/bin/env bash
# Deprecated path: use ./scripts/workflow_automation_run.sh drain
set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
exec "$REPO_ROOT/scripts/workflow_automation_run.sh" drain "$@"
