#!/bin/bash
# List Zero Trust seats (via Access users: access_seat, gateway_seat). Uses ZT token on prichindel (Edit preferred for Access).
# Run on prichindel: bash scripts/cf-list-seats.sh
# Needs account_id: CF_ACCOUNT_ID or /root/.secrets/cloudflare/cf-account-id.
TOKEN_FILE=""
for f in /root/.secrets/cloudflare/cf-zero-trust-edit /root/.secrets/cloudflare/cf-zero-trust-seats /root/.secrets/cloudflare/cf-zero-trust-read; do
  if sudo test -r "$f" 2>/dev/null; then TOKEN_FILE="$f"; break; fi
done
if [ -z "$TOKEN_FILE" ]; then echo "No token (cf-zero-trust-edit, cf-zero-trust-seats, or cf-zero-trust-read)"; exit 1; fi
T=$(sudo cat "$TOKEN_FILE" 2>/dev/null | tr -d '\n\r')
if [ -z "$T" ]; then echo "Empty token"; exit 1; fi

AID="${CF_ACCOUNT_ID:-$(sudo cat /root/.secrets/cloudflare/cf-account-id 2>/dev/null | tr -d '\n\r')}"
if [ -z "$AID" ]; then
  echo "No account_id. Set CF_ACCOUNT_ID or: echo -n '<account_id>' | sudo tee /root/.secrets/cloudflare/cf-account-id"
  exit 1
fi

api() {
  curl -sS -H 'Authorization: Bearer '"$T" "$1"
}

echo "=== ACCESS USERS (seats, account $AID) ==="
R=$(api "https://api.cloudflare.com/client/v4/accounts/$AID/access/users")
if ! echo "$R" | jq -e '.success == true' >/dev/null 2>&1; then
  echo "API error: $(echo "$R" | jq -r '.errors[0].message // .')"
  exit 2
fi
echo "$R" | jq -r '.result[]? | "  \(.name // .email)  access_seat=\(.access_seat)  gateway_seat=\(.gateway_seat)  id=\(.id)"'
echo ""
echo "=== RAW (first 3) ==="
echo "$R" | jq '.result[0:3]'
