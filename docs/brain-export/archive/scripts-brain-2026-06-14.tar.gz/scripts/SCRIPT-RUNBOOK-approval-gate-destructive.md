---
task_id: "governance|approval|destructive"
active_md_anchor: "| approval |"
---

# Script runbook — Approval gate before destructive / high-risk work

**Purpose**: Block or record **destructive and high-risk** actions through **cursor-approval-gates** MCP so outcomes are traceable. Ref: [governance/MCP-COMPLIANCE-AND-OPERATIONAL.md](../governance/MCP-COMPLIANCE-AND-OPERATIONAL.md), [governance/approval_gates.json](../governance/approval_gates.json) (generated).

**Who**: Executor (Abelard, Gena, Cursor) **before** the action; **authorized** role **record_approval** when approving/rejecting.

---

## When to use

- Drop production DB, delete backups that violate retention policy, expose credentials, disable firewall, SSH changes that risk lockout, mass deletion in `/data/`, production cutover without sign-off — **and** any task your governance flags as high-risk.
- **Before** executing: **list_pending_approvals** / **get_approval_status**.

---

## Procedure

1. **List**: `list_pending_approvals()` — JSON from [governance/approval_gates.json](../governance/approval_gates.json).
2. **If not approved**: **request_approval(scope, reason)** → get `approval_id`; report **BLOCKED** to operator/Grace until decided.
3. **When authorized**: **record_approval(approval_id, approved|rejected)**.
4. **Metrics** (optional): `get_approval_metrics_summary` or GET `/workflow/approval_metrics` for friction signals.

---

## Do not

- Do **not** skip the gate for "small" destructive ops — if policy says risk, use the gate.
- Do **not** paste secrets into approval **reason** text in chat logs — scope + short reason only.

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| JSON not writable | Check `governance/` permissions; repo root `CURSOR_REPO_ROOT`. |
| Stale pending | Owner records outcome; Grace may triage stuck items. |

---

## See also

- [SCRIPT-RUNBOOK-report-done-workflow.md](SCRIPT-RUNBOOK-report-done-workflow.md) — task completion (separate from approval).
- [cluster/workflow-automation/approval_metrics.py](../cluster/workflow-automation/approval_metrics.py) — metrics aggregation.

SIGNED: Architecture (Ethan) | risk gate interface | 2026-03-30 | SCRIPT-RUNBOOK
