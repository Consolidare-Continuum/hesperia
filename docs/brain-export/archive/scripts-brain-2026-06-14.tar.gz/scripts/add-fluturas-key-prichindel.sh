#!/bin/bash
# Run on prichindel as igareosh. Appends fluturas's key to ~/.ssh/authorized_keys.
# Key line read from cluster/fluturas/fluturas.pub (one line). Safe: append only; owner stays igareosh.
# See cluster/fluturas/README.md and TAKEOVER-COMMANDS.md.
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
KEYFILE="$REPO_ROOT/cluster/fluturas/fluturas.pub"
AUTH="$HOME/.ssh/authorized_keys"

if [ ! -f "$KEYFILE" ]; then
  echo "Missing $KEYFILE. Paste fluturas public key (one line, comment fluturas@prichindel) into that file, then re-run."
  exit 1
fi
KEYLINE="$(grep -v '^#' "$KEYFILE" | grep -v '^$' | head -1)"
if [ -z "$KEYLINE" ]; then
  echo "No key line in $KEYFILE. Paste fluturas public key (one line), then re-run."
  exit 1
fi

if grep -q "fluturas@prichindel" "$AUTH" 2>/dev/null; then
  echo "fluturas key already in authorized_keys"
  exit 0
fi
chmod 700 "$HOME/.ssh" 2>/dev/null || true
chmod 600 "$AUTH" 2>/dev/null || true
echo "$KEYLINE" >> "$AUTH"
echo "Appended fluturas key. Verify: tail -1 $AUTH"
tail -1 "$AUTH"
