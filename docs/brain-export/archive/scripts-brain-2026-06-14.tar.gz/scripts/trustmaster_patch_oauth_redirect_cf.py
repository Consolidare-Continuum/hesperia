"""trustmaster: append Cloudflare Access callback to OAuth2 provider pk=1 (shetiyya-papra-proxy).

Cloudflare Zero Trust always sends redirect_uri:
  https://prichindel.cloudflareaccess.com/cdn-cgi/access/callback
for team prichindel (even.prichindel.com, shetiyya, etc.) when using the same IdP client.

docker exec authentik-server-1 /ak-root/.venv/bin/python /manage.py shell < scripts/trustmaster_patch_oauth_redirect_cf.py
(run from repo on a machine with repo mounted, or paste into shell on trustmaster)
"""
from authentik.providers.oauth2.models import OAuth2Provider, RedirectURI

CF_CB = "https://prichindel.cloudflareaccess.com/cdn-cgi/access/callback"
p = OAuth2Provider.objects.get(pk=1)
uris = list(p.redirect_uris)


def uri_str(u):
    if isinstance(u, dict):
        return u.get("url", "")
    return getattr(u, "url", str(u))


found = any(uri_str(u).rstrip("/") == CF_CB.rstrip("/") for u in uris)
print("BEFORE count", len(uris), "has_cf_cb", found)
if not found:
    uris.append(RedirectURI(url=CF_CB, matching_mode="strict"))
    p.redirect_uris = uris
    p.save()
    print("ADDED", CF_CB)
else:
    print("ALREADY_PRESENT")
print("AFTER count", len(list(p.redirect_uris)))
