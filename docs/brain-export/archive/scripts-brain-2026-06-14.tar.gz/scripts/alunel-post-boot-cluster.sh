#!/usr/bin/env bash
# alunel Proxmox host: post-boot cluster hygiene (VM SSH keys, Proxmox pid warnings, hwmon, CHROMA/Tailscale sanity).
# Install: cluster/alunel/systemd/alunel-post-boot-cluster.service (WantedBy=multi-user.target).
set -uo pipefail

VM_IPS=(63 64 65 66 67 68)
VMIDS=(100 101 102 103 104 105)

log() { echo "[alunel-post-boot] $*"; }

# Supermicro W83795ADG fan control (see cluster/alunel/FANS-W83795.md)
if [[ -f /etc/modules-load.d/alunel-hwmon.conf ]]; then
  modprobe w83795 2>/dev/null || true
  modprobe jc42 2>/dev/null || true
  modprobe coretemp 2>/dev/null || true
fi
if systemctl is-enabled alunel-fan-cpu-quiet.service &>/dev/null; then
  systemctl start alunel-fan-cpu-quiet.service 2>/dev/null || true
fi

# Proxmox "pid modified in the future" after host clock jump / unclean shutdown
for vmid in "${VMIDS[@]}"; do
  pidf="/run/qemu-server/${vmid}.pid"
  if [[ -f "$pidf" ]]; then
    touch -c "$pidf" 2>/dev/null || true
  fi
done

# Hypervisor SSH: refresh LAN VM host keys (guest keys change after template rebuild / cloud-init)
ALUNEL_USER="${ALUNEL_USER:-igareosh}"
ALUNEL_HOME="$(getent passwd "$ALUNEL_USER" | cut -d: -f6)"
ALUNEL_HOME="${ALUNEL_HOME:-/home/igareosh}"
kh="${ALUNEL_HOME}/.ssh/known_hosts"
mkdir -p "${ALUNEL_HOME}/.ssh"
chmod 700 "${ALUNEL_HOME}/.ssh"
for last in "${VM_IPS[@]}"; do
  ip="192.168.100.${last}"
  ssh-keyscan -T 5 -H "$ip" 2>/dev/null >>"$kh" || true
done
if [[ -f "$kh" ]]; then
  sort -u "$kh" -o "${kh}.tmp" && mv "${kh}.tmp" "$kh"
  chmod 600 "$kh"
fi

# Stale winbind on hypervisor can break local tools; restart only if join config present
if [[ -f /etc/samba/smb.conf ]] && grep -q 'security = ads' /etc/samba/smb.conf 2>/dev/null; then
  if ! timeout 5 systemctl is-active --quiet winbind 2>/dev/null; then
    log "winbind not active; attempting restart"
    timeout 30 systemctl restart winbind 2>/dev/null || true
  fi
fi

# CHROMA-1 + Mullvad exit (units must use exit-node IP — see alunel-tailscale-exit-de-fra.service)
for u in chroma-1-docker chroma-1-metrics chroma-1-query-api alunel-tailscale-exit-de-fra; do
  systemctl is-enabled "$u" &>/dev/null && systemctl start "$u" 2>/dev/null || true
done

log "done"
