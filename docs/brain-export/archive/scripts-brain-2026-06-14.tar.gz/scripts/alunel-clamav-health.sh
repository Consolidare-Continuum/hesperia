#!/usr/bin/env bash
# alunel — non-destructive ClamAV health (run on alunel; sudo for clamdscan).
# Exit 0 if daemon responds and timer is enabled. Ref: cluster/alunel/CLAMAV.md
set -euo pipefail
FAIL=0

for u in clamav-daemon.socket clamav-daemon.service; do
  if ! systemctl is-active --quiet "$u"; then
    echo "FAIL: $u not active" >&2
    FAIL=1
  fi
done

if ! systemctl is-enabled --quiet clamav-freshclam-once.timer 2>/dev/null; then
  echo "WARN: clamav-freshclam-once.timer not enabled (daily DB updates)" >&2
  FAIL=1
fi

if ! sudo -n true 2>/dev/null; then
  echo "WARN: sudo needed for clamdscan probe; skipping version check" >&2
else
  sudo clamdscan --version 2>/dev/null | head -1 || { echo "FAIL: clamdscan cannot talk to clamd" >&2; FAIL=1; }
fi

if [ "$FAIL" -ne 0 ]; then
  exit 1
fi
echo "OK: alunel ClamAV"
