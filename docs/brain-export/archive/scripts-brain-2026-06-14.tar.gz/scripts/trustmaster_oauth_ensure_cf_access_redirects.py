"""trustmaster: ensure Cloudflare Zero Trust Access callback URIs on OAuth2 providers.

Adds strict + regex entries so OIDC works whether Access uses shetiyya or even-minio client_id."""

from authentik.providers.oauth2.models import OAuth2Provider, RedirectURI, RedirectURIMatchingMode

CF_STRICT = "https://prichindel.cloudflareaccess.com/cdn-cgi/access/callback"
CF_REGEX = r"https://[^/]+\.cloudflareaccess\.com/cdn-cgi/access/callback"

PROVIDER_PKS = (1,)  # shetiyya-papra-proxy only (even MinIO app reverted 2026-04-29)


def ensure_cf(p: OAuth2Provider) -> bool:
    uris = list(p.redirect_uris)
    have_strict = any(
        u.matching_mode == RedirectURIMatchingMode.STRICT and u.url == CF_STRICT for u in uris
    )
    have_regex = any(
        u.matching_mode == RedirectURIMatchingMode.REGEX and CF_REGEX == u.url for u in uris
    )
    changed = False
    if not have_strict:
        uris.append(RedirectURI(matching_mode=RedirectURIMatchingMode.STRICT, url=CF_STRICT))
        changed = True
    if not have_regex:
        uris.append(RedirectURI(matching_mode=RedirectURIMatchingMode.REGEX, url=CF_REGEX))
        changed = True
    if changed:
        p.redirect_uris = uris
        p.save()
    return changed


for pk in PROVIDER_PKS:
    p = OAuth2Provider.objects.get(pk=pk)
    if ensure_cf(p):
        print("updated pk=", pk, p.name)
    else:
        print("unchanged pk=", pk, p.name)
    for u in p.redirect_uris:
        print(" ", u.matching_mode, u.url)
