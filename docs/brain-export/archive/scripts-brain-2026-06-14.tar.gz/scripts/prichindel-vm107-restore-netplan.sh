#!/usr/bin/env bash
# Restore prichindel VM 107 LAN when netplan used eth0/eth1 but guest has ens18/ens19.
# Run from alunel (Proxmox host) with guest agent on VM 107.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NETPLAN_SRC="${REPO_ROOT}/cluster/alunel/netplan/99-prichindel-production.yaml"
VMID="${VMID:-107}"

if [[ ! -f "${NETPLAN_SRC}" ]]; then
  echo "Missing ${NETPLAN_SRC}" >&2
  exit 1
fi

if ! sudo qm status "${VMID}" | grep -q running; then
  echo "VM ${VMID} not running" >&2
  exit 1
fi

B64="$(base64 -w0 "${NETPLAN_SRC}")"
sudo qm guest exec "${VMID}" -- bash -lc "
set -e
echo '${B64}' | base64 -d > /etc/netplan/99-prichindel-production.yaml
chmod 600 /etc/netplan/99-prichindel-production.yaml
netplan apply
ip -4 -br addr show ens18 ens19 2>/dev/null || ip -4 -br addr
"

echo "Netplan applied on VM ${VMID}. Test: nc -zv 192.168.100.21 22"
