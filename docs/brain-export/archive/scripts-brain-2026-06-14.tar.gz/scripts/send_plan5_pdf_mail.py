#!/usr/bin/env python3
"""Send Plan 5 PDF to igareosh@igareosh.com via local Postfix (Proton Bridge). One-off; Abelard. Do not log secrets."""
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
PDF = REPO / "CLIENTS/biopole/docs/plans/PLAN-5-INTEGRATION-CLIENT-RU.pdf"
TO = "igareosh@igareosh.com"
FROM = "igareosh@igareosh.com"
SUBJECT = "План 5. Интеграция Cursor, n8n, Chroma, GitHub, Planfix API (prichindel.com)"

def main():
    if not PDF.exists():
        raise SystemExit(f"PDF not found: {PDF}")
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = TO
    msg["Subject"] = SUBJECT
    msg.attach(MIMEText("Во вложении — План 5 для клиента (1–2 стр., 12pt). prichindel.com", "plain", "utf-8"))
    with open(PDF, "rb") as f:
        part = MIMEApplication(f.read(), _subtype="pdf")
        part.add_header("Content-Disposition", "attachment", filename=PDF.name)
        msg.attach(part)
    with smtplib.SMTP("127.0.0.1", 25) as s:
        s.sendmail(FROM, [TO], msg.as_string())
    print("Sent to", TO)

if __name__ == "__main__":
    main()
