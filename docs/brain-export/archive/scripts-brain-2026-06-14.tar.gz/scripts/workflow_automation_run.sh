#!/bin/bash
# =============================================================================
# TEAM WORKFLOW AUTOMATION — ONE ENTRY
# =============================================================================
# Chroma preflight → orchestrator → driver → Abelard server executor.
#
# Product "full auto" (active.md OPEN → zero) is defined in:
#   governance/SPEC-ETHAN-FULL-AUTO-ACTIVE-MD-PRODUCT.md
# Modes drain / full-auto repeat passes until done or max rounds; full-auto also runs
# scripts/workflow_full_auto_dispatch.py (Chroma hint + JSONL escalation trail + stuck detection).
# Non-Abelard work still requires Cursor/agent execution + report_done — automation routes & surfaces.
#
# USAGE (repo root):
#   ./scripts/workflow_automation_run.sh             # one pass (default)
#   ./scripts/workflow_automation_run.sh drain       # until zero OPEN (global)
#   ./scripts/workflow_automation_run.sh full-auto    # drain + dispatch trail (product loop)
#   ./scripts/workflow_automation_run.sh drain-irc    # until im-irc mesh rows DONE/ARCHIVED
#
# PROJECT FILTER (e.g. im-irc first):
#   WORKFLOW_DRIVER_PROJECT=im-irc ./scripts/workflow_automation_run.sh full-auto
#
# CRON (half-hourly, quiet):
#   */30 * * * * cd /path/to/repo && WORKFLOW_QUIET=1 ./scripts/workflow_automation_run.sh once
#   With WORKFLOW_QUIET=1 you still get Chroma JSON on stderr; one summary line per pass unless
#   WORKFLOW_QUIET_SUMMARY=0 (OPEN count + current step snippet).
#   WORKFLOW_QUIET_STATUS_CHANGES=1 — with WORKFLOW_QUIET=1, print summary only when digest changes:
#   active.md + workflow_driver_current.txt + OPEN/IN_PROGRESS/PAUSED counts (so driver timestamp/current step still emits).
#
# DRAIN / FULL-AUTO ENV:
#   WORKFLOW_ACTIVE_*  WORKFLOW_QUIET  WORKFLOW_DRIVER_PROJECT
#   WORKFLOW_DRIVER_CLAIM_IN_PROGRESS=1 — driver sets active.md row OPEN→IN_PROGRESS when it picks current step (optional)
#   WORKFLOW_FULL_AUTO_STUCK_ROUNDS (default 8)
#   WORKFLOW_PASS_ON_ERROR=continue|exit  (default continue for drain / full-auto / drain-irc)
#     — one bad Chroma preflight or flake must not kill a long full-auto loop; use exit for strict CI.
#   WORKFLOW_PASS_MAX_CONSECUTIVE_FAIL (default 15) — abort if this many passes fail in a row.
#   WORKFLOW_CHROMA_PREFLIGHT_RETRIES (default 3)  WORKFLOW_CHROMA_PREFLIGHT_RETRY_SEC (default 2)
#
# Ref: governance/SPEC-ETHAN-FULL-AUTO-ACTIVE-MD-PRODUCT.md, governance/WORKFLOW-SCRIPT-NAMES.md
# =============================================================================

set -e
REPO_ROOT="${WORKFLOW_REPO_ROOT:-$(cd "$(dirname "$0")/.." && pwd)}"
# prichindel brain host has no local chromadb; team MCP reaches CHROMA-1 via alunel.
export CHROMA_SKIP_PREFLIGHT="${CHROMA_SKIP_PREFLIGHT:-1}"
export REPO_ROOT
export WORKFLOW_REPO_ROOT="$REPO_ROOT"
export LOG_FILE="${REPO_ROOT}/governance/workflow_automation.log"
export STATE_FILE="${REPO_ROOT}/governance/workflow_automation_state.txt"
export EXECUTOR="${REPO_ROOT}/cluster/workflow-automation/abelard_executor.py"
export AGENT_LOOP="${REPO_ROOT}/cluster/workflow-automation/cursor_agent_loop.py"
# Valid python for chroma_preflight + full-auto dispatch (altitudine often has no /data/chroma/venv).
if [[ -n "${CHROMA_PYTHON:-}" && ! -x "${CHROMA_PYTHON}" ]]; then
  unset CHROMA_PYTHON
fi
if [[ -z "${CHROMA_PYTHON:-}" ]]; then
  if [[ -x "/data/chroma/venv/bin/python3" ]]; then
    export CHROMA_PYTHON="/data/chroma/venv/bin/python3"
  else
    export CHROMA_PYTHON="python3"
  fi
fi

MODE="${1:-once}"
if [[ "$MODE" == "help" || "$MODE" == "-h" ]]; then
  sed -n '1,42p' "$0" >&2
  exit 0
fi

count_open() {
  WORKFLOW_REPO_ROOT="$REPO_ROOT" python3 - <<'PY'
import os
from pathlib import Path
root = Path(os.environ["WORKFLOW_REPO_ROOT"])
path = root / "active.md"
if not path.exists():
    print(0)
    raise SystemExit
text = path.read_text(encoding="utf-8", errors="replace")
n = 0
for line in text.splitlines():
    if not line.strip().startswith("|"):
        continue
    parts = [p.strip() for p in line.split("|") if p]
    if len(parts) < 5:
        continue
    if parts[0] in ("Priority", "----------") or parts[0].startswith("---"):
        continue
    if parts[4] == "OPEN":
        n += 1
print(n)
PY
}

# Space-separated: OPEN_count IN_PROGRESS_count PAUSED_count (active.md table body)
count_board_counters() {
  WORKFLOW_REPO_ROOT="$REPO_ROOT" python3 - <<'PY'
import os
from pathlib import Path
root = Path(os.environ["WORKFLOW_REPO_ROOT"])
path = root / "active.md"
o = ip = pz = 0
if path.exists():
    text = path.read_text(encoding="utf-8", errors="replace")
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            continue
        parts = [p.strip() for p in line.split("|") if p]
        if len(parts) < 5:
            continue
        if parts[0] in ("Priority", "----------") or parts[0].startswith("---"):
            continue
        st = parts[4].upper()
        if st == "OPEN":
            o += 1
        elif st == "IN_PROGRESS":
            ip += 1
        elif st == "PAUSED":
            pz += 1
print(o, ip, pz)
PY
}

count_imirc_incomplete() {
  local active="${WORKFLOW_ACTIVE_MD:-$REPO_ROOT/active.md}"
  awk -F'|' '
    /^\|[[:space:]]*Priority/ { next }
    /^\|[[:space:]]*[-|[:space:]]+$/ { next }
    {
      p=$3; gsub(/^[ \t]+|[ \t]+$/, "", p)
      if (tolower(p) != "im-irc") next
      s=$6; gsub(/^[ \t]+|[ \t]+$/, "", s)
      if (s == "DONE" || s == "ARCHIVED" || s == "") next
      c++
    }
    END { print c+0 }
  ' "$active"
}

single_pass() {
  cd "$REPO_ROOT"
  export CHROMA_PREFLIGHT_LOG="$LOG_FILE"
  if [[ "${CHROMA_SKIP_PREFLIGHT:-}" != "1" ]]; then
    local _maxr="${WORKFLOW_CHROMA_PREFLIGHT_RETRIES:-3}"
    local _sleep="${WORKFLOW_CHROMA_PREFLIGHT_RETRY_SEC:-2}"
    local _attempt=0
    local _ok=0
    while [[ "$_attempt" -lt "$_maxr" ]]; do
      _attempt=$((_attempt + 1))
      if "$REPO_ROOT/scripts/chroma_preflight.sh"; then
        _ok=1
        break
      fi
      if [[ "$_attempt" -lt "$_maxr" ]]; then
        sleep "$_sleep"
      fi
    done
    if [[ "$_ok" -ne 1 ]]; then
      ts_fail=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
      echo "--- $ts_fail CHROMA_PREFLIGHT_FAIL (after ${_maxr} attempts) ---" >> "$LOG_FILE"
      return 1
    fi
  fi
  ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  echo "--- $ts START ---" >> "$LOG_FILE"
  bash "$REPO_ROOT/scripts/workflow/step1_orchestrator_driver.sh"
  _run_ec=$?

  if [[ "${WORKFLOW_QUIET:-}" != "1" ]]; then
    echo "" >&2
    if [[ -n "${WORKFLOW_DRIVER_PROJECT:-}" ]]; then
      echo "Note: WORKFLOW_DRIVER_PROJECT=${WORKFLOW_DRIVER_PROJECT} — current step is filtered to that project; heartbeat OPEN sample below is still board-wide." >&2
      echo "" >&2
    fi
    echo "--- workflow_automation.log (last 18 lines) — full: $LOG_FILE ---" >&2
    tail -n 18 "$LOG_FILE" 1>&2 2>/dev/null || true
    echo "" >&2
    echo "--- Heartbeat (task list sample) — full: $REPO_ROOT/governance/workflow_heartbeat.txt ---" >&2
    head -n 22 "$REPO_ROOT/governance/workflow_heartbeat.txt" 1>&2 2>/dev/null || true
    echo "" >&2
    echo "--- Current step — full: $REPO_ROOT/governance/workflow_driver_current.txt ---" >&2
    cat "$REPO_ROOT/governance/workflow_driver_current.txt" 1>&2 2>/dev/null || true
    echo "" >&2
    echo "--- Owner context passport — full: $REPO_ROOT/governance/workflow_context_current.md ---" >&2
    sed -n '1,80p' "$REPO_ROOT/governance/workflow_context_current.md" 1>&2 2>/dev/null || true
  elif [[ "${WORKFLOW_QUIET_SUMMARY:-1}" != "0" ]]; then
    local _oc _cur _tsl _md _mdcur _lastf _ip _pz _newd
    read -r _oc _ip _pz <<< "$(count_board_counters)"
    _cur=$(head -n 1 "$REPO_ROOT/governance/workflow_driver_current.txt" 2>/dev/null | tr -d '\r' | tr '\n' ' ' | cut -c1-200)
    _tsl=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    _md=$(md5sum "$REPO_ROOT/active.md" 2>/dev/null | awk '{print $1}')
    _mdcur=$(md5sum "$REPO_ROOT/governance/workflow_driver_current.txt" 2>/dev/null | awk '{print $1}')
    if [[ "${WORKFLOW_QUIET_STATUS_CHANGES:-}" == "1" ]]; then
      _lastf="${REPO_ROOT}/governance/workflow_last_quiet_digest.txt"
      _newd="${_md}|${_mdcur}|${_oc}|${_ip}|${_pz}"
      if [[ -f "$_lastf" ]] && [[ "$(cat "$_lastf" 2>/dev/null)" == "$_newd" ]]; then
        :
      else
        echo "[workflow quiet $_tsl] OPEN=${_oc} IN_PROGRESS=${_ip} PAUSED=${_pz} | ${_cur:-current step (none)}" >&2
        echo "$_newd" >"$_lastf"
      fi
    else
      echo "[workflow quiet $_tsl] OPEN=${_oc} IN_PROGRESS=${_ip} PAUSED=${_pz} | ${_cur:-current step (none)}" >&2
    fi
  fi
  return "$_run_ec"
}

# Looping modes: transient single_pass failure (Chroma, SSH) should not abort the whole run.
_handle_pass_failure() {
  local ec="$1"
  local round="$2"
  local mode="$3"
  if [[ "$ec" -eq 0 ]]; then
    return 0
  fi
  if [[ "$ec" -eq 130 || "$ec" -eq 143 ]]; then
    echo "Interrupted (exit $ec) — $mode round $round." >&2
    exit "$ec"
  fi
  if [[ "${WORKFLOW_PASS_ON_ERROR:-continue}" == "exit" ]]; then
    echo "ERROR: pass exited $ec ($mode round $round)." >&2
    exit "$ec"
  fi
  local maxc="${WORKFLOW_PASS_MAX_CONSECUTIVE_FAIL:-15}"
  echo "WARN: single_pass exited $ec ($mode round $round, consecutive_fail=${4:-?}/$maxc); continuing (WORKFLOW_PASS_ON_ERROR=continue)." >&2
  if [[ "${4:-0}" -ge "$maxc" ]]; then
    echo "ERROR: $maxc consecutive pass failures — aborting ($mode)." >&2
    exit "$ec"
  fi
  return 0
}

run_drain_open() {
  local MAX_ROUNDS="${WORKFLOW_ACTIVE_MAX_ROUNDS:-10000}"
  local SLEEP_SEC="${WORKFLOW_ACTIVE_SLEEP_SEC:-1}"
  local CHROMA_EVERY="${WORKFLOW_ACTIVE_CHROMA_EVERY:-1}"
  local round=0
  local consec_fail=0

  local n
  n=$(count_open)
  if [[ "$n" -eq 0 ]]; then
    echo "workflow_automation_run drain: no OPEN rows — idle." >&2
    exit 0
  fi
  echo "workflow_automation_run drain: OPEN=$n (max_rounds=$MAX_ROUNDS sleep=${SLEEP_SEC}s)" >&2

  while [[ $round -lt $MAX_ROUNDS ]]; do
    n=$(count_open)
    if [[ "$n" -eq 0 ]]; then
      echo "Drain complete: zero OPEN rows." >&2
      exit 0
    fi
    round=$((round + 1))
    if [[ "$CHROMA_EVERY" =~ ^[0-9]+$ ]] && [[ "$CHROMA_EVERY" -gt 1 ]]; then
      if (( (round - 1) % CHROMA_EVERY != 0 )); then
        export CHROMA_SKIP_PREFLIGHT=1
      else
        unset CHROMA_SKIP_PREFLIGHT || true
      fi
    else
      unset CHROMA_SKIP_PREFLIGHT || true
    fi
    set +e
    single_pass
    ec=$?
    set -e
    if [[ "$ec" -eq 0 ]]; then
      consec_fail=0
    else
      consec_fail=$((consec_fail + 1))
      _handle_pass_failure "$ec" "$round" "drain" "$consec_fail" || true
    fi
    sleep "$SLEEP_SEC"
  done
  n=$(count_open)
  echo "ERROR: max rounds reached; OPEN rows remaining: $n" >&2
  exit 1
}

run_full_auto() {
  export PYTHONPATH="${REPO_ROOT}${PYTHONPATH:+:$PYTHONPATH}"
  local MAX_ROUNDS="${WORKFLOW_ACTIVE_MAX_ROUNDS:-10000}"
  local SLEEP_SEC="${WORKFLOW_ACTIVE_SLEEP_SEC:-1}"
  local CHROMA_EVERY="${WORKFLOW_ACTIVE_CHROMA_EVERY:-1}"
  local round=0
  local consec_fail=0
  local n

  n=$(count_open)
  if [[ "$n" -eq 0 ]]; then
    echo "workflow_automation_run full-auto: no OPEN rows — idle." >&2
    exit 0
  fi
  read -r _fb_o _fb_ip _fb_pz <<< "$(count_board_counters)"
  echo "workflow_automation_run full-auto: OPEN=${n} board(IN_PROGRESS=${_fb_ip} PAUSED=${_fb_pz}) — product loop + dispatch | log ${LOG_FILE} | heartbeat ${REPO_ROOT}/governance/workflow_heartbeat.txt (SPEC: governance/SPEC-ETHAN-FULL-AUTO-ACTIVE-MD-PRODUCT.md) (CHROMA_PYTHON=${CHROMA_PYTHON})" >&2

  while [[ $round -lt $MAX_ROUNDS ]]; do
    n=$(count_open)
    if [[ "$n" -eq 0 ]]; then
      echo "Full-auto complete: zero OPEN rows." >&2
      exit 0
    fi
    round=$((round + 1))
    if [[ "$CHROMA_EVERY" =~ ^[0-9]+$ ]] && [[ "$CHROMA_EVERY" -gt 1 ]]; then
      if (( (round - 1) % CHROMA_EVERY != 0 )); then
        export CHROMA_SKIP_PREFLIGHT=1
      else
        unset CHROMA_SKIP_PREFLIGHT || true
      fi
    else
      unset CHROMA_SKIP_PREFLIGHT || true
    fi
    set +e
    single_pass
    ec=$?
    set -e
    # Dispatch after every pass so stuck_rounds / escalation trail advance even when preflight flakes.
    "$CHROMA_PYTHON" "$REPO_ROOT/scripts/workflow_full_auto_dispatch.py" >>"$LOG_FILE" 2>&1 || true
    if [[ "$ec" -eq 0 ]]; then
      consec_fail=0
    else
      consec_fail=$((consec_fail + 1))
      _handle_pass_failure "$ec" "$round" "full-auto" "$consec_fail" || true
    fi
    sleep "$SLEEP_SEC"
  done
  n=$(count_open)
  echo "ERROR: full-auto max rounds; OPEN remaining: $n" >&2
  exit 1
}

run_drain_irc() {
  export WORKFLOW_DRIVER_PROJECT="${WORKFLOW_DRIVER_PROJECT:-im-irc}"
  local MAX_ROUNDS="${WORKFLOW_IMIRC_MAX_ROUNDS:-2000}"
  local SLEEP_SEC="${WORKFLOW_IMIRC_SLEEP_SEC:-2}"
  local round=0
  local consec_fail=0
  local n

  n=$(count_imirc_incomplete)
  if [[ "$n" -eq 0 ]]; then
    echo "workflow_automation_run drain-irc: no incomplete im-irc rows." >&2
    exit 0
  fi
  echo "workflow_automation_run drain-irc: incomplete im-irc rows=$n WORKFLOW_DRIVER_PROJECT=$WORKFLOW_DRIVER_PROJECT (max_rounds=$MAX_ROUNDS)" >&2

  while [[ $round -lt $MAX_ROUNDS ]]; do
    n=$(count_imirc_incomplete)
    if [[ "$n" -eq 0 ]]; then
      echo "drain-irc complete." >&2
      exit 0
    fi
    round=$((round + 1))
    unset CHROMA_SKIP_PREFLIGHT || true
    set +e
    single_pass
    ec=$?
    set -e
    if [[ "$ec" -eq 0 ]]; then
      consec_fail=0
    else
      consec_fail=$((consec_fail + 1))
      _handle_pass_failure "$ec" "$round" "drain-irc" "$consec_fail" || true
    fi
    sleep "$SLEEP_SEC"
  done
  n=$(count_imirc_incomplete)
  echo "ERROR: drain-irc max rounds; incomplete rows: $n" >&2
  exit 1
}

cd "$REPO_ROOT"

case "$MODE" in
  once)
    # Honor CHROMA_SKIP_PREFLIGHT from env (cron sets it); do not unset here.
    single_pass
    exit $?
    ;;
  drain)
    run_drain_open
    ;;
  full-auto)
    run_full_auto
    ;;
  drain-irc)
    run_drain_irc
    ;;
  *)
    echo "Unknown mode: $MODE (use: once, drain, full-auto, drain-irc, help)" >&2
    exit 2
    ;;
esac
