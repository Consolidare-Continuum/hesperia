"""Attach even-minio-console ProxyProvider to embedded outpost. Run:
docker exec -i authentik-server-1 ak shell < scripts/trustmaster_outpost_attach_even_proxy.py
"""
from authentik.outposts.models import Outpost
from authentik.providers.proxy.models import ProxyProvider

outpost = Outpost.objects.get(name="authentik Embedded Outpost")
even = ProxyProvider.objects.get(name="even-minio-console-proxy")
outpost.providers.add(even)
outpost.save()
print("Attached:", even.name, "to", outpost.name)
for p in outpost.providers.all():
    print("  provider:", p.pk, p.name)
