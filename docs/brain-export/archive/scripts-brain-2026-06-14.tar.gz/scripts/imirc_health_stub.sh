#!/usr/bin/env bash
# IM-IRC-T41 — minimal health: ergo, eggdrop gateway chain (trustmaster; SSH or local).
set -euo pipefail
ok=0
check() { if "$@"; then echo "OK $*"; else echo "FAIL $*"; ok=1; fi; }
check systemctl --user is-active --quiet ergo-girc
check systemctl --user is-active --quiet imirc-eggdrop 2>/dev/null || true
check systemctl --user is-active --quiet imirc-gateway-forwarder 2>/dev/null || true
exit "$ok"
