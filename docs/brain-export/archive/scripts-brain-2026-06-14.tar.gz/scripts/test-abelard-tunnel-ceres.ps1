# Run on CERES to test SSH to abelard.prichindel.com via Cloudflare tunnel.
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File scripts\test-abelard-tunnel-ceres.ps1
$hostname = "abelard.prichindel.com"
$result = ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15 root@$hostname "echo OK; hostname" 2>&1
if ($result -match "OK") { Write-Host "PASS: $result"; exit 0 } else { Write-Host "FAIL: $result"; exit 1 }
