"""Bind group team-admin to Application even-minio-console (forward-auth access).
docker exec -i authentik-server-1 ak shell < scripts/trustmaster_even_minio_bind_team_admin.py
"""
from authentik.core.models import Application, Group
from authentik.policies.models import PolicyBinding

app = Application.objects.get(slug="even-minio-console")
g = Group.objects.get(name="team-admin")
if PolicyBinding.objects.filter(target=app, group=g).exists():
    print("ALREADY_BOUND")
else:
    PolicyBinding.objects.create(target=app, group=g, order=0)
    print("BOUND_GROUP_TEAM_ADMIN")
