# Mass-fix Proton Drive sync: clear read-only on full Proton sync root (and optional app cache).
# Use on any Windows node (CERES, olgahere) where Proton shows "File is read-only" sync issues.
# Run: powershell -ExecutionPolicy Bypass -File .\scripts\proton-drive-mass-fix.ps1 [-Path "C:\path\to\proton\root"]
# Optional -Path: Proton sync root. If omitted, auto-detects from current dir or common paths.
# Reason: Proton sync fails on Git object files (.git/objects/2f, 79, 8d, b2, etc.) because Git marks them read-only.
# See REPO-AND-PROTON-POLICY.md, cluster/olgahere/README.md.

param(
    [string]$Path = ''
)

$ErrorActionPreference = 'Stop'
$script:report = @()

function Find-ProtonSyncRoot {
    # 1. If we're inside a Proton path, walk up to sync root (folder that contains "cursor" or "ceres_proton_drive")
    $current = (Get-Location).Path
    $p = $current
    while ($p -and (Test-Path $p)) {
        $cursorPath = Join-Path $p 'cursor'
        $ceresPath = Join-Path $p 'ceres_proton_drive'
        if ((Test-Path $cursorPath) -and (Get-Item $cursorPath -Force).PSIsContainer) {
            $script:report += "Found Proton sync root (has cursor): $p"
            return $p
        }
        if ($p -match 'ceres_proton_drive$') {
            $script:report += "Found Proton sync root (ceres_proton_drive): $p"
            return $p
        }
        if ($p -match 'Proton Drive\\My files') {
            $script:report += "Found Proton sync root (My files): $p"
            return $p
        }
        $parent = Split-Path -Parent $p
        if ($parent -eq $p) { break }
        $p = $parent
    }
    # 2. Common roots (default Proton path = canonical)
    $candidates = @(
        (Join-Path $env:USERPROFILE 'Proton Drive\igareosh\My files'),
        (Join-Path $env:USERPROFILE 'Proton Drive\igareosh\Other computers\CERES\ceres_proton_drive'),
        (Join-Path $env:USERPROFILE 'Proton Drive\My files'),
        (Join-Path $env:USERPROFILE 'Proton Drive'),
        'C:\ceres_proton_drive'
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) {
            $script:report += "Using Proton sync root: $c"
            return $c
        }
    }
    $script:report += "Proton sync root not found. Specify -Path or run from inside Protoned repo."
    return $null
}

function Clear-ReadOnlyRecursive {
    param([string]$RootPath)
    $count = 0
    $errs = 0
    $rootItem = Get-Item -LiteralPath $RootPath -Force -ErrorAction SilentlyContinue
    if (-not $rootItem) { return @{ Cleared = 0; Errors = 1 } }
    if ($rootItem.Attributes -band [System.IO.FileAttributes]::ReadOnly) {
        $rootItem.Attributes = $rootItem.Attributes -bxor [System.IO.FileAttributes]::ReadOnly
        $count++
    }
    Get-ChildItem -LiteralPath $RootPath -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            if ($_.Attributes -band [System.IO.FileAttributes]::ReadOnly) {
                $_.Attributes = $_.Attributes -bxor [System.IO.FileAttributes]::ReadOnly
                $count++
            }
        } catch {
            $errs++
        }
    }
    return @{ Cleared = $count; Errors = $errs }
}

# Resolve target path
$targetPath = $Path
if (-not $targetPath) {
    $targetPath = Find-ProtonSyncRoot
}
if (-not $targetPath -or -not (Test-Path $targetPath)) {
    $script:report | ForEach-Object { Write-Host $_ }
    exit 1
}

$targetPath = (Get-Item -LiteralPath $targetPath -Force).FullName
Write-Host "Clearing read-only on: $targetPath"

$result = Clear-ReadOnlyRecursive -RootPath $targetPath
$script:report += "Read-only cleared: $($result.Cleared) items; errors: $($result.Errors)"

# attrib -R for robustness
$attribOut = & cmd /c "attrib -R `"$targetPath\*`" /S /D 2>&1"

# Explicit .git pass: Git object files (.git/objects/XX/...) are read-only; Proton fails on them (sync issues 2f, 79, 8d, b2)
$gitDirs = @()
if (Test-Path (Join-Path $targetPath 'cursor\.git')) { $gitDirs += (Join-Path $targetPath 'cursor\.git') }
if (Test-Path (Join-Path $targetPath '.git')) { $gitDirs += (Join-Path $targetPath '.git') }
foreach ($cursorGit in $gitDirs) {
    $rGit = Clear-ReadOnlyRecursive -RootPath $cursorGit
    $script:report += ".git read-only cleared: $($rGit.Cleared) items; errors: $($rGit.Errors)"
    # Run attrib from inside .git so paths with spaces don't break cmd
    Push-Location -LiteralPath $cursorGit
    try { & cmd /c 'attrib -R * /S /D 2>&1' | Out-Null } finally { Pop-Location }
}

# Optional: clear read-only on Proton Drive app data (local cache)
$appDataPath = Join-Path $env:LOCALAPPDATA 'Proton\Proton Drive'
if (Test-Path $appDataPath) {
    $r2 = Clear-ReadOnlyRecursive -RootPath $appDataPath
    $script:report += "AppData Proton Drive: cleared $($r2.Cleared) items; errors: $($r2.Errors)"
    & cmd /c "attrib -R `"$appDataPath\*`" /S /D 2>&1" | Out-Null
}

$script:report | ForEach-Object { Write-Host $_ }
Write-Host "Done. In Proton Drive: Activity > Retry syncing."
exit 0
