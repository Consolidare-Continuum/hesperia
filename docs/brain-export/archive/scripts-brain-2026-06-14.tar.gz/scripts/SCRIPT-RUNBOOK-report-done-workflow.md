---
task_id: "P7|execution|report-done"
active_md_anchor: "| report_done |"
---

# Script runbook — report_done (task complete → active.md sync)

**Purpose**: After completing **your** row as owner, mark the task DONE (or PAUSED / IN_PROGRESS) so heartbeat, driver, and automation stay aligned. Ref: [governance/MCP-COMPLIANCE-AND-OPERATIONAL.md](../governance/MCP-COMPLIANCE-AND-OPERATIONAL.md), [BACKEND-API-CONTRACT-PHASE2B.md](../governance/BACKEND-API-CONTRACT-PHASE2B.md).

**Who**: Task owner (Cursor-in-IDE, Gena, Abelard when owner, or script with token). **No new rows** — update existing row only.

---

## When to use

- Current step in [governance/workflow_driver_current.txt](../governance/workflow_driver_current.txt) matches your work and you finished the step.
- Operator or automation expects **one** status transition on the matching `active.md` row.

---

## Procedure (IDE — MCP)

1. Resolve **task_id** to match the row (pipeline-status uses project|owner or task cell match — see MCP `get_task_row` if unsure).
2. **Soft gate (code rows)**: If row involves open PR / merge, run [SCRIPT-RUNBOOK-github-ci-verify.md](SCRIPT-RUNBOOK-github-ci-verify.md) or MCP `get_branch_ci` — PAUSE if CI red unless operator accepts risk.
3. Call **report_done(task_id, DONE)** (or PAUSED / IN_PROGRESS) via cursor-pipeline-status MCP.
4. If MCP missing: config bug — [scripts/deploy-mcp-config-global.sh](deploy-mcp-config-global.sh), restart Cursor.

---

## Procedure (server / API)

- **POST** `/workflow/report_done` on `127.0.0.1:9096` with Bearer token if `WORKFLOW_API_TOKEN` set. Body: `task_id`, `status`, optional `outcome_summary`.
- Ref: [cluster/workflow-automation/README.md](../cluster/workflow-automation/README.md), [cluster/workflow-automation/workflow_api.py](../cluster/workflow-automation/workflow_api.py).

---

## Do not

- Do **not** create a new row for "done" — update STATUS cell only.
- Do **not** mark DONE without matching an OPEN or IN_PROGRESS row (API returns 404).

---

## Failure modes

| Symptom | Fix |
|---------|-----|
| 404 task_id | Align `task_id` with row text / project|owner per contract. |
| active.md not writable | Check repo path, permissions, lock. |

---

## See also

- [SCRIPT-RUNBOOK-workflow-proceed-gates.md](SCRIPT-RUNBOOK-workflow-proceed-gates.md) — when cluster preflight / CI verify apply.
- [SCRIPT-RUNBOOK-cluster-proceed-preflight.md](SCRIPT-RUNBOOK-cluster-proceed-preflight.md) — before Abelard/cluster/prod execute.
- [SCRIPT-RUNBOOK-grace-triage-active.md](SCRIPT-RUNBOOK-grace-triage-active.md) — row creation.

SIGNED: Architecture (Ethan) | execution closure interface | 2026-03-30 | SCRIPT-RUNBOOK
