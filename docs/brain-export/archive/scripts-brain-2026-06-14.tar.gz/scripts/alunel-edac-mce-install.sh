#!/usr/bin/env bash
# alunel — EDAC + MCE monitoring (rasdaemon + prometheus-node-exporter :9105)
# Canonical: cluster/alunel/EDAC-MCE-MONITORING.md
# Run on alunel as root: sudo bash scripts/alunel-edac-mce-install.sh
set -euo pipefail

if [[ "$(id -u)" -ne 0 ]]; then
  echo "alunel-edac-mce-install: run as root (sudo)" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
for try in "${REPO_ROOT}" /data/workspaces/cursor /data/altitudine/prichindel.com; do
  if [[ -f "${try}/cluster/alunel/prometheus-node-exporter.default" ]]; then
    REPO_ROOT="${try}"
    break
  fi
done

SRC_DEFAULT="${REPO_ROOT}/cluster/alunel/prometheus-node-exporter.default"
MARKER="/etc/alunel-edac-mce.installed"

apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq rasdaemon prometheus-node-exporter

modprobe edac_core 2>/dev/null || true
modprobe amd64_edac 2>/dev/null || true
# Westmere / i5500 — EDAC driver usually loaded as i5000_edac or sb_edac via DMI

install -m 644 "${SRC_DEFAULT}" /etc/default/prometheus-node-exporter

systemctl daemon-reload
systemctl enable rasdaemon.service prometheus-node-exporter.service
systemctl restart rasdaemon.service prometheus-node-exporter.service

# LAN scrape from prichindel Prometheus
if command -v ufw >/dev/null; then
  ufw allow from 192.168.100.0/24 to any port 9105 proto tcp comment 'alunel-node-exporter-edac' 2>/dev/null || true
fi

{
  echo "installed_at=$(date -Iseconds)"
  echo "repo_root=${REPO_ROOT}"
  echo "rasdaemon=$(systemctl is-active rasdaemon.service)"
  echo "node_exporter=$(systemctl is-active prometheus-node-exporter.service)"
  echo "scrape_port=9105"
  echo "policy_doc=cluster/alunel/EDAC-MCE-MONITORING.md"
} >"${MARKER}"

echo "=== alunel EDAC/MCE monitoring installed ==="
systemctl is-enabled rasdaemon.service prometheus-node-exporter.service
systemctl is-active rasdaemon.service prometheus-node-exporter.service
echo "--- EDAC sysfs ---"
grep -H . /sys/devices/system/edac/mc/mc*/{ce_count,ue_count} 2>/dev/null || true
echo "--- metrics sample ---"
curl -sf http://127.0.0.1:9105/metrics | grep -E '^node_edac_|^node_systemd_unit_state.*rasdaemon' | head -10 || echo "WARN: metrics curl failed"
echo "marker: ${MARKER}"
