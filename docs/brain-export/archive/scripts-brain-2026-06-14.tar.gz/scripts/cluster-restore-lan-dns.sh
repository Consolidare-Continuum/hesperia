#!/usr/bin/env bash
# Restore LAN DNS basics after prichindel-vm cutover (physical unplugged, VM on alunel).
# Run on alunel as igareosh (sudo). Patches dnsmaster AD delegation → actarus .19.
set -euo pipefail

REPO="${REPO:-}"
if [[ -z "$REPO" ]]; then
  if [[ -d /data/workspaces/cursor ]]; then REPO=/data/workspaces/cursor
  elif [[ -d /data/altitudine/prichindel.com ]]; then REPO=/data/altitudine/prichindel.com
  else REPO="$(cd "$(dirname "$0")/.." && pwd)"; fi
fi

DROPIN_SRC="$REPO/cluster/dnsmaster/10-dnsmaster.conf"
DNSMASTER_IP=192.168.100.25
ACTARUS_IP=192.168.100.19
VM_CORP_IP=192.168.100.23

log() { echo "[lan-dns] $*"; }

patch_dnsmaster_ad_upstream() {
  log "dnsmaster: delegate prichindel.local → actarus $ACTARUS_IP"
  ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes -o ConnectTimeout=8 "igareosh@${DNSMASTER_IP}" 'sudo python3 -' <<PY
import yaml
path = "/opt/AdGuardHome/AdGuardHome.yaml"
with open(path) as f:
    cfg = yaml.safe_load(f)
dns = cfg.setdefault("dns", {})
up = dns.get("upstream_dns", [])
new_up = []
for u in up:
    if isinstance(u, str):
        u = u.replace("192.168.100.23", "${ACTARUS_IP}")
    new_up.append(u)
dns["upstream_dns"] = new_up
ptr = dns.get("local_ptr_upstreams", [])
dns["local_ptr_upstreams"] = [("${ACTARUS_IP}" if "192.168.100.23" in str(x) else x) for x in ptr]
if "${ACTARUS_IP}" not in dns.get("local_ptr_upstreams", []):
    dns["local_ptr_upstreams"] = ["${ACTARUS_IP}"]
with open(path, "w") as f:
    yaml.safe_dump(cfg, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
print("upstream_dns:", dns["upstream_dns"][:4])
PY
  ssh -o BatchMode=yes "igareosh@${DNSMASTER_IP}" \
    'sudo systemctl restart AdGuardHome && sleep 2 && systemctl is-active AdGuardHome'
}

apply_dropin_local() {
  log "alunel host: $DROPIN_SRC"
  sudo cp "$DROPIN_SRC" /etc/systemd/resolved.conf.d/10-dnsmaster.conf
  sudo systemctl restart systemd-resolved
}

apply_dropin_guest() {
  local vmid="$1" name="$2"
  if ! sudo qm status "$vmid" 2>/dev/null | grep -q running; then
    log "skip VM $vmid $name (not running)"
    return 0
  fi
  if [[ "$vmid" == "106" ]]; then
    log "skip VM 106 dnsmaster (self)"
    return 0
  fi
  log "VM $vmid $name: resolved drop-in"
  local b64
  b64=$(base64 -w0 <"$DROPIN_SRC")
  sudo qm guest exec "$vmid" -- bash -lc "
set -e
mkdir -p /etc/systemd/resolved.conf.d
echo '$b64' | base64 -d > /etc/systemd/resolved.conf.d/10-dnsmaster.conf
systemctl restart systemd-resolved 2>/dev/null || true
resolvectl status 2>/dev/null | grep -E 'DNS Server|Fallback' | head -4 || true
" 2>/dev/null || log "WARN: guest exec failed on $vmid"
}

verify_dns() {
  log "verify dig @${DNSMASTER_IP}"
  host prichindel.local "${DNSMASTER_IP}" | head -2 || true
  host -t SRV _ldap._tcp.dc._msdcs.prichindel.local "${DNSMASTER_IP}" 2>/dev/null | head -4 || true
  host actarus.prichindel.local "${DNSMASTER_IP}" | head -2 || true
  log "verify actarus DC"
  ssh -o BatchMode=yes -o ConnectTimeout=8 "igareosh@${ACTARUS_IP}" \
    'systemctl is-active samba-ad-dc; samba-tool user list 2>/dev/null | wc -l' || true
}

main() {
  [[ -f "$DROPIN_SRC" ]] || { echo "missing $DROPIN_SRC" >&2; exit 1; }
  patch_dnsmaster_ad_upstream
  apply_dropin_local
  for spec in 100:chronomaster 101:mediamaster 102:altitudine 103:librarymaster \
    104:trustmaster 105:tersagor 107:prichindel; do
    apply_dropin_guest "${spec%%:*}" "${spec##*:}"
  done
  sudo qm set 107 --nameserver "${DNSMASTER_IP} ${ACTARUS_IP}" 2>/dev/null || true
  verify_dns
  log "DONE"
}

main "$@"
