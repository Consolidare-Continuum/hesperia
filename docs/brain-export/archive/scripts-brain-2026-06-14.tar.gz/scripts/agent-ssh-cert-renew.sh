#!/usr/bin/env bash
# Daily cert renewal for the cluster agent SSH identity.
# Run as igareosh on alunel (cron: see cluster/agent-ssh/AGENT-SSH-CA.md).
# Signs id_agent with 25h validity (1h overlap keeps access alive across midnight).
set -euo pipefail

CA_DIR="$HOME/.ssh/agent-ca"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
STATUS_FILE="$REPO_ROOT/governance/agent_ssh_cert_status.txt"

if [ ! -f "$CA_DIR/agent_ca" ]; then
    echo "ERROR: CA not found at $CA_DIR/agent_ca. Run agent-ssh-ca-init.sh first." >&2
    exit 1
fi

if [ ! -f "$CA_DIR/id_agent.pub" ]; then
    echo "ERROR: Agent pubkey not found at $CA_DIR/id_agent.pub." >&2
    exit 1
fi

# Remove old cert before re-signing
rm -f "$CA_DIR/id_agent-cert.pub"

ssh-keygen -s "$CA_DIR/agent_ca" \
    -I "agent@cluster" \
    -n "igareosh" \
    -V "+25h" \
    "$CA_DIR/id_agent.pub"

VALID_UNTIL=$(date -d '+25 hours' -Iseconds)
RENEWED_AT=$(date -Iseconds)

echo "Cert renewed at $RENEWED_AT, valid until $VALID_UNTIL"
ssh-keygen -L -f "$CA_DIR/id_agent-cert.pub" | grep -E 'Key ID|Valid|Principals'

# Write non-secret status to brain repo for workflow visibility
cat > "$STATUS_FILE" <<EOF
last_renewed: $RENEWED_AT
valid_until: $VALID_UNTIL
identity: agent@cluster
principal: igareosh
ca_location: alunel:$CA_DIR/agent_ca
cert_location: alunel:$CA_DIR/id_agent-cert.pub
EOF

echo "Status written: $STATUS_FILE"

# Keep client config aligned after every renew (agents use cert immediately)
if [ -x "$SCRIPT_DIR/agent-ssh-merge-config.sh" ]; then
    bash "$SCRIPT_DIR/agent-ssh-merge-config.sh" >/dev/null || true
fi

# Sync status to prichindel brain copy (MCP reads prichindel repo)
if ssh -o BatchMode=yes -o ConnectTimeout=5 prichindel 'test -d /data/workspaces/cursor/governance' 2>/dev/null; then
    scp -q "$STATUS_FILE" prichindel:/data/workspaces/cursor/governance/agent_ssh_cert_status.txt 2>/dev/null || true
fi
