# CONN-MAP naming surfaces inventory (Susanin A)

**Date:** 2026-09-02 · **Task:** CONN-MAP-02 · **Owner:** Colombo

| Surface | Location | Drift class |
|---------|----------|-------------|
| conn registry | `cluster/conn/hub/registry.json` | SOT for agent lan_ip |
| HOSTNAME standard | `cluster/HOSTNAME-AND-HOSTS-STANDARD.md` | Human canon |
| hosts block | `scripts/cluster/dns-cluster/bin/cluster-merge-lan-hosts.sh` | Linux merge |
| dnsmaster | AdGuard rewrites via `cluster-lan-dns-rewrites.sh` | DNS plane |
| agent-ssh | `scripts/cluster/agent-ssh/agent-ssh-merge-config.sh` | SSH Host aliases |
| Tailscale | MagicDNS short names per host README | Overlay |

**Dual-IP nodes:** lamaita (.81/.4), olgahere (.9/.5), voinicel (.90/.16).

SIGNED: Researcher (Colombo) | CONN-MAP-02 inventory | 2026-09-02
