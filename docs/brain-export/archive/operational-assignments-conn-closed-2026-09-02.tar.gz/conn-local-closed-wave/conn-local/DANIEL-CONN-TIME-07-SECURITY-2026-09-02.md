# CONN-TIME security note — Daniel PASS

**Date:** 2026-09-02 · **Task:** CONN-TIME-07

- Read-only GET routes; no token; LAN/TS same as `/api/status`
- No operator PII; city aliases are static JSON in repo
- Flight endpoint carries mandatory non-schedule disclaimer
- Not added to default destructive inquiry chains

**Verdict:** PASS

SIGNED: Security (Daniel) | CONN-TIME-07 | 2026-09-02
