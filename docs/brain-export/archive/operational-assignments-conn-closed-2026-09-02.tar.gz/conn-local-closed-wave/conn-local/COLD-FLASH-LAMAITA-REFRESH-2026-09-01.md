# conn.local cold flash refresh — LAMAITA up

**Date:** 2026-09-01  
**Session:** execution_host=altitudine · LAN  
**Trigger:** Operator — cold flash LAMAITA up; refresh `D:\conn.local` + repo mirror

## Verdict

**DONE.** Live prichindel conn hub state + API snapshots copied to LAMAITA flash and `operational/assignments/conn-local/`.

## Live grip (post-refresh)

| Check | Result |
|-------|--------|
| `get_conn_status` | 14 up / 0 down · dbs **4/4** |
| `get_conn_host lamaita` | **up** · `.81` · TS `100.114.133.33` · ConnAgent fresh (~4s) |
| Actions catalog | **27** actions (incl. mx v2) |

## Flash (`D:\conn.local`)

| Path | Contents |
|------|----------|
| `hub/` | Live `/data/docker/conn/hub/` incl. `actions_catalog.json` |
| `agent/` | `/opt/conn/agent/` |
| `var-lib-conn/` | `state.json` (~137KB) |
| `etc-conn/` | token + `imirc_web_token.LINK.txt` (symlink target note) |
| `etc-ssl-conn/` | TLS leaf |
| `systemd/` · `nginx/` | Unit + vhost |
| `api-snapshots/` | health, status, pyramid, dbs, github, **actions**, **host-lamaita** |
| `conn.local-cold-20260901T151523Z.tar.gz` | Portable archive (no symlinks) |

Removed stale `hub-root/` and prior `20260820` tar.

## Repo mirror

`operational/assignments/conn-local/` — `api-snapshots/`, `MANIFEST-2026-09-01.txt`, `SHA256SUMS-2026-09-01.txt`, `README-cold-backup.txt`.

**Repeat:** `bash scripts/conn/conn-local-cold-export.sh`

SIGNED: DevOps (Abelard) | conn.local cold flash LAMAITA | 2026-09-01
