# CONN-MAP dual-IP smoke — Ava PASS (partial deploy)

**Date:** 2026-09-02 · **Task:** CONN-MAP-08

| Host | conn `/api/names` | Expected |
|------|-----------------|----------|
| olgahere | lan_ip=.9 lan_ip_wifi=.5 drift=false after reconcile | PASS |
| lamaita | lan_ip=.81 (wifi in registry if present) | PASS read |
| voinicel | lan_ip=.90 | PASS read |

**Verdict:** PASS for conn API surface; dnsmaster/hosts merge deploy pending operator window (Abelard CONN-MAP-07 docs updated in repo).

SIGNED: QA (Ava) | CONN-MAP-08 smoke | 2026-09-02
