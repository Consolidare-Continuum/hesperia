# CONN-TIME agentic smoke — Ava PASS

**Date:** 2026-09-02 · **Task:** CONN-TIME-10 · **Via:** https://conn.local (deployed hub)

| Query | Result |
|-------|--------|
| `/api/time?place=Belgrade` | 200 · `Europe/Belgrade` · CEST offset +02:00 |
| `/api/time?place=Santiago` | 200 · `America/Santiago` (Chile alias) |
| `/api/time/calc?from=Berlin&to=Madrid` | 200 · ~1869 km · ~167 min estimate · disclaimer present |
| `/api/timestamp` | 200 · epoch_ms + iso8601_utc |

**Verdict:** PASS

SIGNED: QA (Ava) | CONN-TIME-10 smoke | 2026-09-02
