conn.local cold backup — live deployed state from prichindel
Layout: hub/, agent/, var-lib-conn/, etc-conn/, etc-ssl-conn/, systemd/, nginx/, api-snapshots/, MANIFEST.txt
Restore via Abelard install-hub path after unpack. Keep etc-conn/token private.
LAMAITA refresh: cold flash up 2026-09-01 — ConnAgent reporting .81
