# MCP-OPS-06 — Security: boarding flags (boolean only)

**Owner:** Daniel  
**Date:** 2026-08-29  
**SPEC:** [SPEC-ETHAN-MCP-OPS-STATE-2026-08-29.md](../../../governance/SPEC-ETHAN-MCP-OPS-STATE-2026-08-29.md)

## Verdict: PASS (policy)

1. Stamps and `get_mcp_ops_state` may expose **names** of deferred/needs_auth servers and **0|1** boarding flags only.
2. **Forbidden** in stamp/MCP JSON: OAuth client secrets, refresh tokens, passwords, cert private keys, contents of `/root/.secrets/**`.
3. `neos_secrets_present` = `test -f` (or sudo -n test -f) result only.
4. Cloudflare `mcp_needs_auth` means session OAuth incomplete — not a credential dump cue.
5. Trustmaster remains custody for any credential material; agents never paste secrets into active.md or Telegram.

SIGNED: Daniel (security) | MCP-OPS-06 | 2026-08-29 | boolean boarding
