# Grace triage — MCP ops-state variables (brain capacity consolidation)

**Date:** 2026-08-29  
**From:** Cursor (variable inventory) → Grace (task team)  
**Operator:** Grace triage them all and task team  
**Project:** `cursor-repo` · tag **MCP**  
**Packet:** `pkt-contexts-fitness` / `pkt-agentic-compliance`  
**LS-cap:** `folder_ls_cap_checked` — wave in this subgroup (reports SOFT; do not dump flat into reports/)  
**Source chat:** Ethan MCP-wide inspection → Gena catalog/Colombo fix → Cursor named encode variables

## Outcome: PROJECT-CREATED

Encode cluster-wide **MCP operational state variables** so agents stop rediscovering catalog drift, session exposure, Colombo client pin split, OAuth needsAuth, and deferred boarding. Consolidate into one readable `mcp_ops_state` surface (stamp ± MCP tool).

**Partial already done (Gena, uncommitted on branch/worktree):** stamps `count=33`, fitness dynamic SOT, client mcp sync `drift=0`, Colombo `venv/colombo-chroma2` + HTTP count fallback. Wave **absorbs and finishes** — do not re-do; verify and land.

## Do not

- Invent parallel task boards outside active.md  
- Bump shared `/data/chroma/venv` chromadb off **0.6.3** (CHROMA-1 pin stays)  
- Put secrets values in stamps (booleans / paths only)  
- Lecture operator on CHROMA-1 routine ops  
- Flat-dump more packets into `operational/assignments/reports/` (SOFT)

## Variable → owner map (all named encode targets)

### Catalog / session

| Variable | Owner row | Note |
|----------|-----------|------|
| `mcp_sot_key_count` | Ethan + Gena | = `len(mcp-config.json)`; stamps must match |
| `mcp_client_sync_epoch` / `mcp_drift` | Abelard + Gena | deploy-global + drift check |
| `mcp_session_exposed_keys` / delta | Gena (+ Cursor reload) | deployed ≠ session |
| `mcp_oauth_ready` / `mcp_needs_auth[]` | Gena + Daniel | Cloudflare class |
| `mcp_boarded[]` / `mcp_deferred[]` | Abelard + Ethan | e.g. `cursor-neos-cc` |

### Runtime / Chroma

| Variable | Owner row | Note |
|----------|-----------|------|
| `colombo_chroma2_python` | Felix + Abelard | `venv/colombo-chroma2` hard path |
| `colombo_chromadb_client_version` | Felix | `1.5.5` — **split stamp** from CHROMA-1 pin |
| `chroma_client_pin` (`0.6.3`) | Abelard | keep; document dual-pin |
| `chroma2_server_version` / `chroma2_url` / `chroma2_collection` | Felix | live or stamp mirror |
| `chroma2_chunk_count` / `chroma2_client_collection_ok` | Felix | status JSON; inquiry evidence |

### Host / trust

| Variable | Owner row | Note |
|----------|-----------|------|
| `mcp_execution_host` | = session mode | already; wire into ops_state |
| `mcp_remote_brain_repo` | Abelard | `prichindel:/data/workspaces/cursor` |
| `trustmaster_hub_bin` | Abelard | `/opt/trustmaster-hub` |
| `conn_status_ok` / cert fields | evidence from existing MCP | fold into composite |

### Product boarding

| Variable | Owner row | Note |
|----------|-----------|------|
| `neos_cc_boarded` / `neos_secrets_present` | Abelard + Daniel | boolean only |
| `cc_brain_lane_a_ready` / `cc_brain_lane_b_ready` | Felix / Gena | existing lane stamps |
| `suitecrm_mcp_ok` / `runbook_catalog_count` | capacity stamp | Gena wire |

### Composite

| Variable | Owner row | Note |
|----------|-----------|------|
| `mcp_ops_state` (aggregate) | Ethan SPEC → Gena tool → Abelard writer | single agent read-first |

## Shape (executable rows)

| ID | Owner | Task | Status gate |
|----|-------|------|-------------|
| **MCP-OPS-00** | Grace | This triage + board | DONE at triage |
| **MCP-OPS-01** | Ethan | SPEC: `mcp_ops_state` schema + stamp keys + tool contract + dual chroma pin policy | OPEN |
| **MCP-OPS-02** | Abelard | Stamp writer + deploy path: dual pin, deferred/needs_auth flags, hub_bin, remote brain repo, sync epoch | OPEN (after 01 or parallel draft) |
| **MCP-OPS-03** | Gena | `get_mcp_ops_state` MCP surface (prefer `cursor-cc-brain` or cluster-snapshot) + fitness/handshake stamp write-back; land prior catalog=33 work | OPEN |
| **MCP-OPS-04** | Felix | Colombo plane: stamps + launcher always resolve colombo-chroma2 venv; status fields stable; inquiry tokens | OPEN |
| **MCP-OPS-05** | Ava | Smoke DoD: fitness PASS, drift 0, colombo chunk≫0 + client_ok, ops_state fields present | PAUSED until 02–04 |
| **MCP-OPS-06** | Daniel | Security: boolean boarding flags; no secret material in stamps/MCP output | OPEN (parallel 01) |
| **MCP-OPS-07** | Aurel | CONTEXTS-FITNESS + inquiry chain `mcp_ops` / registry evidence tokens | OPEN (after 01) |
| **MCP-OPS-08** | Liam | Risk card: catalog lag + false-empty library + session/deploy mismatch | OPEN |
| **MCP-OPS-09** | Grace | Wrap wave when 01–08 DONE | PAUSED |

## Definition of done (wave)

- [ ] SPEC signed (Ethan) for `mcp_ops_state` field set  
- [ ] Dual chroma pins documented and stamped (0.6.3 shared vs 1.5.5 Colombo)  
- [ ] Stamp writer + MCP tool return same keys  
- [ ] Fitness/handshake/drift green against SOT count  
- [ ] Ava smoke PASS  
- [ ] Daniel OK on secret surface  
- [ ] Grace wrap  

## Parallel

Ethan 01 ∥ Daniel 06 ∥ Liam 08. Abelard 02 + Gena 03 + Felix 04 after SPEC draft fields exist (may start from Cursor inventory). Ava 05 after 02–04. Aurel 07 after SPEC. Grace 09 last.

SIGNED: Triage (Grace) | Grace context | 2026-08-29 | MCP-OPS-00..09
