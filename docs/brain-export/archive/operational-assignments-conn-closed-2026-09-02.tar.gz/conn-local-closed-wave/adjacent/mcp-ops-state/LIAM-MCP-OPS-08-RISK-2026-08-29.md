# MCP-OPS-08 — Risk card: catalog / session / false-empty library

**Owner:** Liam  
**Date:** 2026-08-29

| Risk | Likelihood | Impact | Mitigation (now encoded) |
|------|------------|--------|---------------------------|
| Stamp count lags SOT (`30`≠`33`) | High (observed) | Agents invent “undeployed” | `sot_count` + fitness vs stamp |
| Client mcp.json missing key | High (neos) | Session hole | `drift` + deploy-global |
| Session exposed ≠ deployed | Med | False BLOCKED | Advise-not-deny + reload; later session delta |
| Colombo 0.6.3 vs server 1.x | High (observed) | False empty library | Dual pin + colombo venv + HTTP count |
| OAuth needsAuth treated as outage | Med | Skip Cloudflare work | `mcp_needs_auth` list |
| Secrets in stamps | Low if policy held | Credential leak | MCP-OPS-06 PASS |

SIGNED: Liam | MCP-OPS-08 | 2026-08-29 | risk card
