# Grace triage — MCP runbook wave (packet-bound books)

**Date:** 2026-08-20  
**From:** Ethan (architecture) → Grace (task team)  
**Operator:** task team as required  
**Project:** `cursor-repo` · tag **MCP**  
**Packet:** `pkt-brain-fitness` for authors; each book binds one live `pkt-*`  
**LS-cap:** `folder_ls_cap_checked` — assignments SOFT 55; this wave lives in this subgroup (not another flat packet)

## Outcome: PROJECT-CREATED

Ethan: MCP catalog (30) and packets (20) are ahead of `get_runbook`. Need **one proper procedure per live muscle**, not more cluster-host books and not a 40-page MCP essay. Copilot CLI follows **`SCRIPT-RUNBOOK-*` ids only** (same 30 keys as Cursor). No Goose YAML. No extra `.copilot/*.md`.

**Do not duplicate:** Table A core (triage, report_done, session opener, Chroma session, proceed gates, packets, thinking-map, folder LS, Telegram, CI, Hesperia modular/wiki, cluster preflight, trustmaster, tailscale logout, SuiteCRM sync, Defuddle). Do not rewrite Abelard backup/holy-cow, Colombo Papra/Susanin, Gena CI.

**Do not schedule:** Olivia (no UI product), Sophia (no duration gate), Noah (no extra retrieval QA), Emma (SuiteCRM close already exists), Marcus (no new security object), ops-method authors.

## Shape (12 books + bind)

Each new file under `scripts/runbooks/` (topic folder that matches muscle). Template: Who / Trigger / `packet_id` / exact tools / evidence token / Do not / SIGNED. One to two pages. `list_runbooks` must show the id.

| ID | Owner | Runbook id to ship | `packet_id` | Merge note |
|----|-------|--------------------|-------------|------------|
| **RB-00** | Grace | (this packet) | — | Triage |
| **RB-01** | Felix | `SCRIPT-RUNBOOK-conn-local` | `pkt-lan-machinery` | `get_conn_status` / `get_conn_map` before SSH |
| **RB-02** | Daniel | `SCRIPT-RUNBOOK-prometheus-mcp` | `pkt-observability` | PromQL; alerts stay snapshot `list_firing_alerts` |
| **RB-03** | Abelard | `SCRIPT-RUNBOOK-docker-mcp-gateway` | `pkt-mcp-catalog` | **Includes malus vs `MCP_DOCKER` boundary** |
| **RB-04** | Ava | `SCRIPT-RUNBOOK-playwright-e2e` | `pkt-browser-e2e` | Protocol/E2E; not Defuddle |
| **RB-05** | Colombo | `SCRIPT-RUNBOOK-markitdown-convert` | `pkt-document-convert` | Office/binary → text |
| **RB-06** | Abelard | `SCRIPT-RUNBOOK-stackql-inventory` | `pkt-cloud-inventory` | Discover → describe → validate SELECT |
| **RB-07** | Colombo | `SCRIPT-RUNBOOK-vendor-chroma-lab` | `pkt-vendor-chroma-lab` | Never replace CHROMA-1/2 |
| **RB-08** | Aegle | `SCRIPT-RUNBOOK-copilot-catalog` | `pkt-copilot-catalog` | `search` → `download`/`load_skill_directory`; harvest untrusted; CLI restart after MCP config |
| **RB-09** | Felix | `SCRIPT-RUNBOOK-hesperia-context-session` | `pkt-hesperia-context` | router + fpf-inspect + context-rag + `cursor-fpf-test-mcp`; wiki runbook stays |
| **RB-10** | Grace | `SCRIPT-RUNBOOK-inbox-reader` | (session / Grace) | `get_inbox_summary` / `get_inbox_entry`; no row writes |
| **RB-11** | Abelard | `SCRIPT-RUNBOOK-tailscale-mcp` | cluster + Tailscale MCP | Status/audit/repair; **logout stays** `SCRIPT-RUNBOOK-tailscale-logout` |
| **RB-12** | Gena | `SCRIPT-RUNBOOK-cloudflare-product-mcp` + thicken postfix vs Mailcow | `pkt-cloudflare` / `pkt-mail-out` | Tunnel book stays; this is bindings/builds/observability session. Postfix vs Mailcow: extend `SCRIPT-RUNBOOK-mailcow-agent-mail` or add `SCRIPT-RUNBOOK-postfix-mail` — one deliverable, two files OK if still short |
| **RB-13** | Ethan | Table A/B deltas | — | Bind **only** real triggers. After RB-01..12 exist |

## Definition of done (wave)

- [ ] Twelve callable `SCRIPT-RUNBOOK-*` ids (RB-12 may be two short files)
- [ ] Ethan Table A/B updated only where trigger is real
- [ ] `get_runbook` returns each id; Copilot path unchanged (MCP `cursor-runbook`)
- [ ] No Goose recipe YAML; no new `.copilot/*.md`

## Parallel

Abelard RB-03 / RB-06 / RB-11 parallel. Felix RB-01 + RB-09 parallel. Colombo RB-05 + RB-07 parallel. Others independent. **RB-13** after books land (PAUSED until then).

SIGNED: Triage (Grace) | Grace context | 2026-08-20 | RB-00..13
