# Grace triage — RB verify wave (MCP runbook host sync)

**Date:** 2026-08-20  
**From:** Ethan audit → Grace  
**Project:** `cursor-repo` · tag **MCP**  
**Parent wave:** [GRACE-TRIAGE-MCP-RUNBOOK-WAVE-2026-08-20.md](GRACE-TRIAGE-MCP-RUNBOOK-WAVE-2026-08-20.md)  
**Audit:** [ETHAN-RUNBOOKS-STATE-AUDIT-2026-08-20.md](../reports/ETHAN-RUNBOOKS-STATE-AUDIT-2026-08-20.md)

## Outcome: PROJECT-CREATED

Ethan audit accepted: RB-01..13 content **DONE** on disk + governance; production **`cursor-runbook` MCP** was stale on prichindel until surgical checkout (session fix). Durable hygiene still required.

**Accept (wrap):** RB wave books + Table A/B — **accepted**. MCP spot-check **PASS** post-checkout. Full prichindel clone ff-only **not** done (dirty `active.md`).

## Rows

| ID | Owner | Task | Status at triage |
|----|-------|------|------------------|
| **RB-VERIFY-00** | Grace | Triage RB verify wave (clone sync + smoke). | DONE (this packet) |
| **RB-VERIFY-01** | Abelard | Reconcile `/data/workspaces/cursor` on prichindel with `origin/main`; resolve dirty `active.md` without losing lawful automation writes. | OPEN |
| **RB-VERIFY-02** | Ava | Smoke: `list_runbooks` ≥ **90**; `get_runbook` on all **13** RB-wave ids + Table A spot ids; file evidence. | OPEN (after 01) |
| **RB-VERIFY-03** | Liam | Optional: extend `verify-mcp-handshake.sh` with runbook count floor + RB id spot list. | OPEN |

## Execution order

1. **Abelard** RB-VERIFY-01 — full clone aligned (not surgical checkout only).
2. **Ava** RB-VERIFY-02 — MCP smoke from IDE path (SSH prichindel launcher).
3. **Liam** RB-VERIFY-03 — optional guardrail; may run parallel to 02.

## Definition of done

- [ ] prichindel `/data/workspaces/cursor` at `origin/main` HEAD (no `[behind N]`)
- [ ] `list_runbooks` ≥ 90 via live MCP
- [ ] Ava evidence file in `operational/assignments/reports/`
- [ ] Optional: handshake script enforces floor

SIGNED: Triage (Grace) | Grace context | 2026-08-20 | RB-VERIFY-00..03
