# MCP runbook wave (2026-08-20)

Subgroup for LS-cap (assignments depth-1 was SOFT 55). Live packet only.

- [GRACE-TRIAGE-MCP-RUNBOOK-WAVE-2026-08-20.md](GRACE-TRIAGE-MCP-RUNBOOK-WAVE-2026-08-20.md)
